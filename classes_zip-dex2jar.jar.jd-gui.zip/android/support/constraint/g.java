package android.support.constraint;

public final class g {
  public static final int barrier = 2131296321;
  
  public static final int bottom = 2131296328;
  
  public static final int chains = 2131296379;
  
  public static final int dimensions = 2131296415;
  
  public static final int direct = 2131296416;
  
  public static final int end = 2131296432;
  
  public static final int gone = 2131296452;
  
  public static final int invisible = 2131296553;
  
  public static final int left = 2131296562;
  
  public static final int none = 2131296645;
  
  public static final int packed = 2131296659;
  
  public static final int parent = 2131296662;
  
  public static final int percent = 2131296665;
  
  public static final int right = 2131296690;
  
  public static final int spread = 2131296746;
  
  public static final int spread_inside = 2131296747;
  
  public static final int standard = 2131296753;
  
  public static final int start = 2131296754;
  
  public static final int top = 2131296840;
  
  public static final int wrap = 2131296939;
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */