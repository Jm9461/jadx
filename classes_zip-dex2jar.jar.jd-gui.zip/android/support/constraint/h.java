package android.support.constraint;

public final class h {
  public static final int[] ConstraintLayout_Layout = new int[] { 
      16842948, 16843039, 16843040, 16843071, 16843072, 2130968644, 2130968645, 2130968701, 2130968760, 2130968761, 
      2130969053, 2130969054, 2130969055, 2130969056, 2130969057, 2130969058, 2130969059, 2130969060, 2130969061, 2130969062, 
      2130969063, 2130969064, 2130969065, 2130969066, 2130969067, 2130969068, 2130969069, 2130969070, 2130969071, 2130969072, 
      2130969073, 2130969074, 2130969075, 2130969076, 2130969077, 2130969078, 2130969079, 2130969080, 2130969081, 2130969082, 
      2130969083, 2130969084, 2130969085, 2130969086, 2130969087, 2130969088, 2130969089, 2130969090, 2130969091, 2130969092, 
      2130969093, 2130969095, 2130969096, 2130969097, 2130969098, 2130969099, 2130969100, 2130969101, 2130969102, 2130969105 };
  
  public static final int ConstraintLayout_Layout_android_maxHeight = 2;
  
  public static final int ConstraintLayout_Layout_android_maxWidth = 1;
  
  public static final int ConstraintLayout_Layout_android_minHeight = 4;
  
  public static final int ConstraintLayout_Layout_android_minWidth = 3;
  
  public static final int ConstraintLayout_Layout_android_orientation = 0;
  
  public static final int ConstraintLayout_Layout_barrierAllowsGoneWidgets = 5;
  
  public static final int ConstraintLayout_Layout_barrierDirection = 6;
  
  public static final int ConstraintLayout_Layout_chainUseRtl = 7;
  
  public static final int ConstraintLayout_Layout_constraintSet = 8;
  
  public static final int ConstraintLayout_Layout_constraint_referenced_ids = 9;
  
  public static final int ConstraintLayout_Layout_layout_constrainedHeight = 10;
  
  public static final int ConstraintLayout_Layout_layout_constrainedWidth = 11;
  
  public static final int ConstraintLayout_Layout_layout_constraintBaseline_creator = 12;
  
  public static final int ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf = 13;
  
  public static final int ConstraintLayout_Layout_layout_constraintBottom_creator = 14;
  
  public static final int ConstraintLayout_Layout_layout_constraintBottom_toBottomOf = 15;
  
  public static final int ConstraintLayout_Layout_layout_constraintBottom_toTopOf = 16;
  
  public static final int ConstraintLayout_Layout_layout_constraintCircle = 17;
  
  public static final int ConstraintLayout_Layout_layout_constraintCircleAngle = 18;
  
  public static final int ConstraintLayout_Layout_layout_constraintCircleRadius = 19;
  
  public static final int ConstraintLayout_Layout_layout_constraintDimensionRatio = 20;
  
  public static final int ConstraintLayout_Layout_layout_constraintEnd_toEndOf = 21;
  
  public static final int ConstraintLayout_Layout_layout_constraintEnd_toStartOf = 22;
  
  public static final int ConstraintLayout_Layout_layout_constraintGuide_begin = 23;
  
  public static final int ConstraintLayout_Layout_layout_constraintGuide_end = 24;
  
  public static final int ConstraintLayout_Layout_layout_constraintGuide_percent = 25;
  
  public static final int ConstraintLayout_Layout_layout_constraintHeight_default = 26;
  
  public static final int ConstraintLayout_Layout_layout_constraintHeight_max = 27;
  
  public static final int ConstraintLayout_Layout_layout_constraintHeight_min = 28;
  
  public static final int ConstraintLayout_Layout_layout_constraintHeight_percent = 29;
  
  public static final int ConstraintLayout_Layout_layout_constraintHorizontal_bias = 30;
  
  public static final int ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle = 31;
  
  public static final int ConstraintLayout_Layout_layout_constraintHorizontal_weight = 32;
  
  public static final int ConstraintLayout_Layout_layout_constraintLeft_creator = 33;
  
  public static final int ConstraintLayout_Layout_layout_constraintLeft_toLeftOf = 34;
  
  public static final int ConstraintLayout_Layout_layout_constraintLeft_toRightOf = 35;
  
  public static final int ConstraintLayout_Layout_layout_constraintRight_creator = 36;
  
  public static final int ConstraintLayout_Layout_layout_constraintRight_toLeftOf = 37;
  
  public static final int ConstraintLayout_Layout_layout_constraintRight_toRightOf = 38;
  
  public static final int ConstraintLayout_Layout_layout_constraintStart_toEndOf = 39;
  
  public static final int ConstraintLayout_Layout_layout_constraintStart_toStartOf = 40;
  
  public static final int ConstraintLayout_Layout_layout_constraintTop_creator = 41;
  
  public static final int ConstraintLayout_Layout_layout_constraintTop_toBottomOf = 42;
  
  public static final int ConstraintLayout_Layout_layout_constraintTop_toTopOf = 43;
  
  public static final int ConstraintLayout_Layout_layout_constraintVertical_bias = 44;
  
  public static final int ConstraintLayout_Layout_layout_constraintVertical_chainStyle = 45;
  
  public static final int ConstraintLayout_Layout_layout_constraintVertical_weight = 46;
  
  public static final int ConstraintLayout_Layout_layout_constraintWidth_default = 47;
  
  public static final int ConstraintLayout_Layout_layout_constraintWidth_max = 48;
  
  public static final int ConstraintLayout_Layout_layout_constraintWidth_min = 49;
  
  public static final int ConstraintLayout_Layout_layout_constraintWidth_percent = 50;
  
  public static final int ConstraintLayout_Layout_layout_editor_absoluteX = 51;
  
  public static final int ConstraintLayout_Layout_layout_editor_absoluteY = 52;
  
  public static final int ConstraintLayout_Layout_layout_goneMarginBottom = 53;
  
  public static final int ConstraintLayout_Layout_layout_goneMarginEnd = 54;
  
  public static final int ConstraintLayout_Layout_layout_goneMarginLeft = 55;
  
  public static final int ConstraintLayout_Layout_layout_goneMarginRight = 56;
  
  public static final int ConstraintLayout_Layout_layout_goneMarginStart = 57;
  
  public static final int ConstraintLayout_Layout_layout_goneMarginTop = 58;
  
  public static final int ConstraintLayout_Layout_layout_optimizationLevel = 59;
  
  public static final int[] ConstraintLayout_placeholder = new int[] { 2130968762, 2130968892 };
  
  public static final int ConstraintLayout_placeholder_content = 0;
  
  public static final int ConstraintLayout_placeholder_emptyVisibility = 1;
  
  public static final int[] ConstraintSet = new int[] { 
      16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843551, 
      16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843701, 
      16843702, 16843770, 16843840, 2130969053, 2130969054, 2130969055, 2130969056, 2130969057, 2130969058, 2130969059, 
      2130969060, 2130969061, 2130969062, 2130969063, 2130969064, 2130969065, 2130969066, 2130969067, 2130969068, 2130969069, 
      2130969070, 2130969071, 2130969072, 2130969073, 2130969074, 2130969075, 2130969076, 2130969077, 2130969078, 2130969079, 
      2130969080, 2130969081, 2130969082, 2130969083, 2130969084, 2130969085, 2130969086, 2130969087, 2130969088, 2130969089, 
      2130969090, 2130969091, 2130969092, 2130969093, 2130969095, 2130969096, 2130969097, 2130969098, 2130969099, 2130969100, 
      2130969101, 2130969102 };
  
  public static final int ConstraintSet_android_alpha = 9;
  
  public static final int ConstraintSet_android_elevation = 22;
  
  public static final int ConstraintSet_android_id = 1;
  
  public static final int ConstraintSet_android_layout_height = 4;
  
  public static final int ConstraintSet_android_layout_marginBottom = 8;
  
  public static final int ConstraintSet_android_layout_marginEnd = 20;
  
  public static final int ConstraintSet_android_layout_marginLeft = 5;
  
  public static final int ConstraintSet_android_layout_marginRight = 7;
  
  public static final int ConstraintSet_android_layout_marginStart = 19;
  
  public static final int ConstraintSet_android_layout_marginTop = 6;
  
  public static final int ConstraintSet_android_layout_width = 3;
  
  public static final int ConstraintSet_android_orientation = 0;
  
  public static final int ConstraintSet_android_rotation = 16;
  
  public static final int ConstraintSet_android_rotationX = 17;
  
  public static final int ConstraintSet_android_rotationY = 18;
  
  public static final int ConstraintSet_android_scaleX = 14;
  
  public static final int ConstraintSet_android_scaleY = 15;
  
  public static final int ConstraintSet_android_transformPivotX = 10;
  
  public static final int ConstraintSet_android_transformPivotY = 11;
  
  public static final int ConstraintSet_android_translationX = 12;
  
  public static final int ConstraintSet_android_translationY = 13;
  
  public static final int ConstraintSet_android_translationZ = 21;
  
  public static final int ConstraintSet_android_visibility = 2;
  
  public static final int ConstraintSet_layout_constrainedHeight = 23;
  
  public static final int ConstraintSet_layout_constrainedWidth = 24;
  
  public static final int ConstraintSet_layout_constraintBaseline_creator = 25;
  
  public static final int ConstraintSet_layout_constraintBaseline_toBaselineOf = 26;
  
  public static final int ConstraintSet_layout_constraintBottom_creator = 27;
  
  public static final int ConstraintSet_layout_constraintBottom_toBottomOf = 28;
  
  public static final int ConstraintSet_layout_constraintBottom_toTopOf = 29;
  
  public static final int ConstraintSet_layout_constraintCircle = 30;
  
  public static final int ConstraintSet_layout_constraintCircleAngle = 31;
  
  public static final int ConstraintSet_layout_constraintCircleRadius = 32;
  
  public static final int ConstraintSet_layout_constraintDimensionRatio = 33;
  
  public static final int ConstraintSet_layout_constraintEnd_toEndOf = 34;
  
  public static final int ConstraintSet_layout_constraintEnd_toStartOf = 35;
  
  public static final int ConstraintSet_layout_constraintGuide_begin = 36;
  
  public static final int ConstraintSet_layout_constraintGuide_end = 37;
  
  public static final int ConstraintSet_layout_constraintGuide_percent = 38;
  
  public static final int ConstraintSet_layout_constraintHeight_default = 39;
  
  public static final int ConstraintSet_layout_constraintHeight_max = 40;
  
  public static final int ConstraintSet_layout_constraintHeight_min = 41;
  
  public static final int ConstraintSet_layout_constraintHeight_percent = 42;
  
  public static final int ConstraintSet_layout_constraintHorizontal_bias = 43;
  
  public static final int ConstraintSet_layout_constraintHorizontal_chainStyle = 44;
  
  public static final int ConstraintSet_layout_constraintHorizontal_weight = 45;
  
  public static final int ConstraintSet_layout_constraintLeft_creator = 46;
  
  public static final int ConstraintSet_layout_constraintLeft_toLeftOf = 47;
  
  public static final int ConstraintSet_layout_constraintLeft_toRightOf = 48;
  
  public static final int ConstraintSet_layout_constraintRight_creator = 49;
  
  public static final int ConstraintSet_layout_constraintRight_toLeftOf = 50;
  
  public static final int ConstraintSet_layout_constraintRight_toRightOf = 51;
  
  public static final int ConstraintSet_layout_constraintStart_toEndOf = 52;
  
  public static final int ConstraintSet_layout_constraintStart_toStartOf = 53;
  
  public static final int ConstraintSet_layout_constraintTop_creator = 54;
  
  public static final int ConstraintSet_layout_constraintTop_toBottomOf = 55;
  
  public static final int ConstraintSet_layout_constraintTop_toTopOf = 56;
  
  public static final int ConstraintSet_layout_constraintVertical_bias = 57;
  
  public static final int ConstraintSet_layout_constraintVertical_chainStyle = 58;
  
  public static final int ConstraintSet_layout_constraintVertical_weight = 59;
  
  public static final int ConstraintSet_layout_constraintWidth_default = 60;
  
  public static final int ConstraintSet_layout_constraintWidth_max = 61;
  
  public static final int ConstraintSet_layout_constraintWidth_min = 62;
  
  public static final int ConstraintSet_layout_constraintWidth_percent = 63;
  
  public static final int ConstraintSet_layout_editor_absoluteX = 64;
  
  public static final int ConstraintSet_layout_editor_absoluteY = 65;
  
  public static final int ConstraintSet_layout_goneMarginBottom = 66;
  
  public static final int ConstraintSet_layout_goneMarginEnd = 67;
  
  public static final int ConstraintSet_layout_goneMarginLeft = 68;
  
  public static final int ConstraintSet_layout_goneMarginRight = 69;
  
  public static final int ConstraintSet_layout_goneMarginStart = 70;
  
  public static final int ConstraintSet_layout_goneMarginTop = 71;
  
  public static final int[] LinearConstraintLayout = new int[] { 16842948 };
  
  public static final int LinearConstraintLayout_android_orientation = 0;
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */