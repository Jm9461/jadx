package android.support.constraint;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.support.constraint.i.j.e;
import android.support.constraint.i.j.h;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import java.util.Arrays;

public abstract class b extends View {
  protected int[] c = new int[32];
  
  protected int d = 0;
  
  protected Context e;
  
  protected h f = null;
  
  protected boolean g = false;
  
  private String h;
  
  public b(Context paramContext) {
    super(paramContext);
    this.e = paramContext;
    a((AttributeSet)null);
  }
  
  private void a(String paramString) {
    if (paramString == null)
      return; 
    if (this.e == null)
      return; 
    paramString = paramString.trim();
    int j = 0;
    try {
      int k = g.class.getField(paramString).getInt(null);
      j = k;
    } catch (Exception exception) {}
    int i = j;
    if (j == 0)
      i = this.e.getResources().getIdentifier(paramString, "id", this.e.getPackageName()); 
    j = i;
    if (i == 0) {
      j = i;
      if (isInEditMode()) {
        j = i;
        if (getParent() instanceof ConstraintLayout) {
          Object object = ((ConstraintLayout)getParent()).a(0, paramString);
          j = i;
          if (object != null) {
            j = i;
            if (object instanceof Integer)
              j = ((Integer)object).intValue(); 
          } 
        } 
      } 
    } 
    if (j != 0) {
      setTag(j, null);
    } else {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not find id of \"");
      stringBuilder.append(paramString);
      stringBuilder.append("\"");
      Log.w("ConstraintHelper", stringBuilder.toString());
    } 
  }
  
  private void setIds(String paramString) {
    if (paramString == null)
      return; 
    for (int i = 0;; i = j + 1) {
      int j = paramString.indexOf(',', i);
      if (j == -1) {
        a(paramString.substring(i));
        return;
      } 
      a(paramString.substring(i, j));
    } 
  }
  
  public void a() {
    if (this.f == null)
      return; 
    ViewGroup.LayoutParams layoutParams = getLayoutParams();
    if (layoutParams instanceof ConstraintLayout.a)
      ((ConstraintLayout.a)layoutParams).k0 = (e)this.f; 
  }
  
  public void a(ConstraintLayout paramConstraintLayout) {}
  
  protected void a(AttributeSet paramAttributeSet) {
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, h.ConstraintLayout_Layout);
      int i = typedArray.getIndexCount();
      for (byte b1 = 0; b1 < i; b1++) {
        int j = typedArray.getIndex(b1);
        if (j == h.ConstraintLayout_Layout_constraint_referenced_ids) {
          this.h = typedArray.getString(j);
          setIds(this.h);
        } 
      } 
    } 
  }
  
  public void b(ConstraintLayout paramConstraintLayout) {}
  
  public void c(ConstraintLayout paramConstraintLayout) {
    if (isInEditMode())
      setIds(this.h); 
    h h1 = this.f;
    if (h1 == null)
      return; 
    h1.H();
    for (byte b1 = 0; b1 < this.d; b1++) {
      View view = paramConstraintLayout.findViewById(this.c[b1]);
      if (view != null)
        this.f.b(paramConstraintLayout.a(view)); 
    } 
  }
  
  public int[] getReferencedIds() {
    return Arrays.copyOf(this.c, this.d);
  }
  
  public void onDraw(Canvas paramCanvas) {}
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.g) {
      super.onMeasure(paramInt1, paramInt2);
    } else {
      setMeasuredDimension(0, 0);
    } 
  }
  
  public void setReferencedIds(int[] paramArrayOfint) {
    this.d = 0;
    for (byte b1 = 0; b1 < paramArrayOfint.length; b1++)
      setTag(paramArrayOfint[b1], null); 
  }
  
  public void setTag(int paramInt, Object paramObject) {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : I
    //   4: istore_3
    //   5: aload_0
    //   6: getfield c : [I
    //   9: astore_2
    //   10: iload_3
    //   11: iconst_1
    //   12: iadd
    //   13: aload_2
    //   14: arraylength
    //   15: if_icmple -> 30
    //   18: aload_0
    //   19: aload_2
    //   20: aload_2
    //   21: arraylength
    //   22: iconst_2
    //   23: imul
    //   24: invokestatic copyOf : ([II)[I
    //   27: putfield c : [I
    //   30: aload_0
    //   31: getfield c : [I
    //   34: astore_2
    //   35: aload_0
    //   36: getfield d : I
    //   39: istore_3
    //   40: aload_2
    //   41: iload_3
    //   42: iload_1
    //   43: iastore
    //   44: aload_0
    //   45: iload_3
    //   46: iconst_1
    //   47: iadd
    //   48: putfield d : I
    //   51: return
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */