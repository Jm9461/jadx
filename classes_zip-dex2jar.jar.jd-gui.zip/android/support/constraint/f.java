package android.support.constraint;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.view.View;

public class f extends View {
  private int c;
  
  private View d;
  
  private int e;
  
  public void a(ConstraintLayout paramConstraintLayout) {
    if (this.d == null)
      return; 
    ConstraintLayout.a a2 = (ConstraintLayout.a)getLayoutParams();
    ConstraintLayout.a a1 = (ConstraintLayout.a)this.d.getLayoutParams();
    a1.k0.j(0);
    a2.k0.k(a1.k0.t());
    a2.k0.c(a1.k0.i());
    a1.k0.j(8);
  }
  
  public void b(ConstraintLayout paramConstraintLayout) {
    if (this.c == -1 && !isInEditMode())
      setVisibility(this.e); 
    this.d = paramConstraintLayout.findViewById(this.c);
    View view = this.d;
    if (view != null) {
      ((ConstraintLayout.a)view.getLayoutParams()).Z = true;
      this.d.setVisibility(0);
      setVisibility(0);
    } 
  }
  
  public View getContent() {
    return this.d;
  }
  
  public int getEmptyVisibility() {
    return this.e;
  }
  
  public void onDraw(Canvas paramCanvas) {
    if (isInEditMode()) {
      paramCanvas.drawRGB(223, 223, 223);
      Paint paint = new Paint();
      paint.setARGB(255, 210, 210, 210);
      paint.setTextAlign(Paint.Align.CENTER);
      paint.setTypeface(Typeface.create(Typeface.DEFAULT, 0));
      Rect rect = new Rect();
      paramCanvas.getClipBounds(rect);
      paint.setTextSize(rect.height());
      int i = rect.height();
      int j = rect.width();
      paint.setTextAlign(Paint.Align.LEFT);
      paint.getTextBounds("?", 0, "?".length(), rect);
      paramCanvas.drawText("?", j / 2.0F - rect.width() / 2.0F - rect.left, i / 2.0F + rect.height() / 2.0F - rect.bottom, paint);
    } 
  }
  
  public void setContentId(int paramInt) {
    if (this.c == paramInt)
      return; 
    View view = this.d;
    if (view != null) {
      view.setVisibility(0);
      ((ConstraintLayout.a)this.d.getLayoutParams()).Z = false;
      this.d = null;
    } 
    this.c = paramInt;
    if (paramInt != -1) {
      view = ((View)getParent()).findViewById(paramInt);
      if (view != null)
        view.setVisibility(8); 
    } 
  }
  
  public void setEmptyVisibility(int paramInt) {
    this.e = paramInt;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */