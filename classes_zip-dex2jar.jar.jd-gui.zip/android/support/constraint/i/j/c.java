package android.support.constraint.i.j;

import java.util.ArrayList;

public class c {
  protected e a;
  
  protected e b;
  
  protected e c;
  
  protected e d;
  
  protected e e;
  
  protected e f;
  
  protected e g;
  
  protected ArrayList<e> h;
  
  protected int i;
  
  protected int j;
  
  protected float k = 0.0F;
  
  private int l;
  
  private boolean m = false;
  
  protected boolean n;
  
  protected boolean o;
  
  protected boolean p;
  
  private boolean q;
  
  public c(e parame, int paramInt, boolean paramBoolean) {
    this.a = parame;
    this.l = paramInt;
    this.m = paramBoolean;
  }
  
  private static boolean a(e parame, int paramInt) {
    if (parame.s() != 8 && parame.B[paramInt] == e.b.e) {
      int[] arrayOfInt = parame.g;
      if (arrayOfInt[paramInt] == 0 || arrayOfInt[paramInt] == 3)
        return true; 
    } 
    return false;
  }
  
  private void b() {
    int i = this.l * 2;
    e e2 = this.a;
    e e1 = this.a;
    boolean bool = false;
    while (true) {
      boolean bool1 = true;
      if (!bool) {
        e e3;
        this.i++;
        e[] arrayOfE = e2.c0;
        int j = this.l;
        arrayOfE[j] = null;
        e2.b0[j] = null;
        if (e2.s() != 8) {
          if (this.b == null)
            this.b = e2; 
          e e4 = this.d;
          if (e4 != null)
            e4.c0[this.l] = e2; 
          this.d = e2;
          e.b[] arrayOfB = e2.B;
          j = this.l;
          if (arrayOfB[j] == e.b.e) {
            int[] arrayOfInt = e2.g;
            if (arrayOfInt[j] == 0 || arrayOfInt[j] == 3 || arrayOfInt[j] == 2) {
              this.j++;
              float[] arrayOfFloat = e2.a0;
              j = this.l;
              float f = arrayOfFloat[j];
              if (f > 0.0F)
                this.k += arrayOfFloat[j]; 
              if (a(e2, this.l)) {
                if (f < 0.0F) {
                  this.n = true;
                } else {
                  this.o = true;
                } 
                if (this.h == null)
                  this.h = new ArrayList<e>(); 
                this.h.add(e2);
              } 
              if (this.f == null)
                this.f = e2; 
              e3 = this.g;
              if (e3 != null)
                e3.b0[this.l] = e2; 
              this.g = e2;
            } 
          } 
        } 
        d d = (e2.z[i + 1]).d;
        if (d != null) {
          e3 = d.b;
          d[] arrayOfD = e3.z;
          if ((arrayOfD[i]).d == null || (arrayOfD[i]).d.b != e2)
            e3 = null; 
        } else {
          d = null;
        } 
        if (d == null) {
          bool = true;
          e3 = e2;
        } 
        e2 = e3;
        continue;
      } 
      this.c = e2;
      if (this.l == 0 && this.m) {
        this.e = this.c;
      } else {
        this.e = this.a;
      } 
      if (!this.o || !this.n)
        bool1 = false; 
      this.p = bool1;
      return;
    } 
  }
  
  public void a() {
    if (!this.q)
      b(); 
    this.q = true;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\i\j\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */