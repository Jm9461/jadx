package android.support.constraint.i.j;

import java.util.Arrays;

public class h extends e {
  protected e[] e0 = new e[4];
  
  protected int f0 = 0;
  
  public void H() {
    this.f0 = 0;
  }
  
  public void b(e parame) {
    int i = this.f0;
    e[] arrayOfE = this.e0;
    if (i + 1 > arrayOfE.length)
      this.e0 = Arrays.<e>copyOf(arrayOfE, arrayOfE.length * 2); 
    arrayOfE = this.e0;
    i = this.f0;
    arrayOfE[i] = parame;
    this.f0 = i + 1;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\i\j\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */