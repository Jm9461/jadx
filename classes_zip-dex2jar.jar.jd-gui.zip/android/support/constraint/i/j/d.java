package android.support.constraint.i.j;

import android.support.constraint.i.i;

public class d {
  private k a = new k(this);
  
  final e b;
  
  final d c;
  
  d d;
  
  public int e = 0;
  
  int f = -1;
  
  private c g = c.c;
  
  private int h;
  
  i i;
  
  public d(e parame, d paramd) {
    b b = b.c;
    this.h = 0;
    this.b = parame;
    this.c = paramd;
  }
  
  public int a() {
    return this.h;
  }
  
  public void a(android.support.constraint.i.c paramc) {
    i i1 = this.i;
    if (i1 == null) {
      this.i = new i(i.a.c, null);
    } else {
      i1.a();
    } 
  }
  
  public boolean a(d paramd) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #5
    //   3: iconst_0
    //   4: istore_3
    //   5: iconst_0
    //   6: istore #4
    //   8: aload_1
    //   9: ifnonnull -> 14
    //   12: iconst_0
    //   13: ireturn
    //   14: aload_1
    //   15: invokevirtual h : ()Landroid/support/constraint/i/j/d$d;
    //   18: astore #6
    //   20: aload_0
    //   21: getfield c : Landroid/support/constraint/i/j/d$d;
    //   24: astore #7
    //   26: aload #6
    //   28: aload #7
    //   30: if_acmpne -> 65
    //   33: aload #7
    //   35: getstatic android/support/constraint/i/j/d$d.h : Landroid/support/constraint/i/j/d$d;
    //   38: if_acmpne -> 63
    //   41: aload_1
    //   42: invokevirtual c : ()Landroid/support/constraint/i/j/e;
    //   45: invokevirtual y : ()Z
    //   48: ifeq -> 61
    //   51: aload_0
    //   52: invokevirtual c : ()Landroid/support/constraint/i/j/e;
    //   55: invokevirtual y : ()Z
    //   58: ifne -> 63
    //   61: iconst_0
    //   62: ireturn
    //   63: iconst_1
    //   64: ireturn
    //   65: getstatic android/support/constraint/i/j/d$a.a : [I
    //   68: aload #7
    //   70: invokevirtual ordinal : ()I
    //   73: iaload
    //   74: tableswitch default -> 124, 1 -> 259, 2 -> 200, 3 -> 200, 4 -> 141, 5 -> 141, 6 -> 139, 7 -> 139, 8 -> 139, 9 -> 139
    //   124: new java/lang/AssertionError
    //   127: dup
    //   128: aload_0
    //   129: getfield c : Landroid/support/constraint/i/j/d$d;
    //   132: invokevirtual name : ()Ljava/lang/String;
    //   135: invokespecial <init> : (Ljava/lang/Object;)V
    //   138: athrow
    //   139: iconst_0
    //   140: ireturn
    //   141: aload #6
    //   143: getstatic android/support/constraint/i/j/d$d.e : Landroid/support/constraint/i/j/d$d;
    //   146: if_acmpeq -> 165
    //   149: aload #6
    //   151: getstatic android/support/constraint/i/j/d$d.g : Landroid/support/constraint/i/j/d$d;
    //   154: if_acmpne -> 160
    //   157: goto -> 165
    //   160: iconst_0
    //   161: istore_2
    //   162: goto -> 167
    //   165: iconst_1
    //   166: istore_2
    //   167: iload_2
    //   168: istore_3
    //   169: aload_1
    //   170: invokevirtual c : ()Landroid/support/constraint/i/j/e;
    //   173: instanceof android/support/constraint/i/j/g
    //   176: ifeq -> 198
    //   179: iload_2
    //   180: ifne -> 194
    //   183: iload #4
    //   185: istore_2
    //   186: aload #6
    //   188: getstatic android/support/constraint/i/j/d$d.k : Landroid/support/constraint/i/j/d$d;
    //   191: if_acmpne -> 196
    //   194: iconst_1
    //   195: istore_2
    //   196: iload_2
    //   197: istore_3
    //   198: iload_3
    //   199: ireturn
    //   200: aload #6
    //   202: getstatic android/support/constraint/i/j/d$d.d : Landroid/support/constraint/i/j/d$d;
    //   205: if_acmpeq -> 224
    //   208: aload #6
    //   210: getstatic android/support/constraint/i/j/d$d.f : Landroid/support/constraint/i/j/d$d;
    //   213: if_acmpne -> 219
    //   216: goto -> 224
    //   219: iconst_0
    //   220: istore_2
    //   221: goto -> 226
    //   224: iconst_1
    //   225: istore_2
    //   226: iload_2
    //   227: istore_3
    //   228: aload_1
    //   229: invokevirtual c : ()Landroid/support/constraint/i/j/e;
    //   232: instanceof android/support/constraint/i/j/g
    //   235: ifeq -> 257
    //   238: iload_2
    //   239: ifne -> 253
    //   242: iload #5
    //   244: istore_2
    //   245: aload #6
    //   247: getstatic android/support/constraint/i/j/d$d.j : Landroid/support/constraint/i/j/d$d;
    //   250: if_acmpne -> 255
    //   253: iconst_1
    //   254: istore_2
    //   255: iload_2
    //   256: istore_3
    //   257: iload_3
    //   258: ireturn
    //   259: iload_3
    //   260: istore_2
    //   261: aload #6
    //   263: getstatic android/support/constraint/i/j/d$d.h : Landroid/support/constraint/i/j/d$d;
    //   266: if_acmpeq -> 291
    //   269: iload_3
    //   270: istore_2
    //   271: aload #6
    //   273: getstatic android/support/constraint/i/j/d$d.j : Landroid/support/constraint/i/j/d$d;
    //   276: if_acmpeq -> 291
    //   279: iload_3
    //   280: istore_2
    //   281: aload #6
    //   283: getstatic android/support/constraint/i/j/d$d.k : Landroid/support/constraint/i/j/d$d;
    //   286: if_acmpeq -> 291
    //   289: iconst_1
    //   290: istore_2
    //   291: iload_2
    //   292: ireturn
  }
  
  public boolean a(d paramd, int paramInt1, int paramInt2, c paramc, int paramInt3, boolean paramBoolean) {
    if (paramd == null) {
      this.d = null;
      this.e = 0;
      this.f = -1;
      this.g = c.c;
      this.h = 2;
      return true;
    } 
    if (!paramBoolean && !a(paramd))
      return false; 
    this.d = paramd;
    if (paramInt1 > 0) {
      this.e = paramInt1;
    } else {
      this.e = 0;
    } 
    this.f = paramInt2;
    this.g = paramc;
    this.h = paramInt3;
    return true;
  }
  
  public boolean a(d paramd, int paramInt1, c paramc, int paramInt2) {
    return a(paramd, paramInt1, -1, paramc, paramInt2, false);
  }
  
  public int b() {
    if (this.b.s() == 8)
      return 0; 
    if (this.f > -1) {
      d d1 = this.d;
      if (d1 != null && d1.b.s() == 8)
        return this.f; 
    } 
    return this.e;
  }
  
  public e c() {
    return this.b;
  }
  
  public k d() {
    return this.a;
  }
  
  public i e() {
    return this.i;
  }
  
  public c f() {
    return this.g;
  }
  
  public d g() {
    return this.d;
  }
  
  public d h() {
    return this.c;
  }
  
  public boolean i() {
    boolean bool;
    if (this.d != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void j() {
    this.d = null;
    this.e = 0;
    this.f = -1;
    this.g = c.d;
    this.h = 0;
    b b = b.c;
    this.a.d();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.b.f());
    stringBuilder.append(":");
    stringBuilder.append(this.c.toString());
    return stringBuilder.toString();
  }
  
  public enum b {
    c, d;
    
    private static final b[] e = new b[] { c, d };
  }
  
  public enum c {
    c, d, e;
    
    private static final c[] f = new c[] { c, d, e };
  }
  
  public enum d {
    c, d, e, f, g, h, i, j, k;
    
    private static final d[] l = new d[] { c, d, e, f, g, h, i, j, k };
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\i\j\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */