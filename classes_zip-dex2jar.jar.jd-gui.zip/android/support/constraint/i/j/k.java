package android.support.constraint.i.j;

import android.support.constraint.i.e;
import android.support.constraint.i.f;
import android.support.constraint.i.i;

public class k extends m {
  d c;
  
  k d;
  
  float e;
  
  k f;
  
  float g;
  
  int h = 0;
  
  private k i;
  
  private l j = null;
  
  private int k = 1;
  
  private l l = null;
  
  private int m = 1;
  
  public k(d paramd) {
    this.c = paramd;
  }
  
  String a(int paramInt) {
    return (paramInt == 1) ? "DIRECT" : ((paramInt == 2) ? "CENTER" : ((paramInt == 3) ? "MATCH" : ((paramInt == 4) ? "CHAIN" : ((paramInt == 5) ? "BARRIER" : "UNCONNECTED"))));
  }
  
  public void a(int paramInt1, k paramk, int paramInt2) {
    this.h = paramInt1;
    this.d = paramk;
    this.e = paramInt2;
    this.d.a(this);
  }
  
  void a(e parame) {
    i i = this.c.e();
    k k1 = this.f;
    if (k1 == null) {
      parame.a(i, (int)this.g);
    } else {
      parame.a(i, parame.a(k1.c), (int)this.g, 6);
    } 
  }
  
  public void a(k paramk, float paramFloat) {
    if (this.b == 0 || (this.f != paramk && this.g != paramFloat)) {
      this.f = paramk;
      this.g = paramFloat;
      if (this.b == 1)
        b(); 
      a();
    } 
  }
  
  public void a(k paramk, int paramInt) {
    this.d = paramk;
    this.e = paramInt;
    this.d.a(this);
  }
  
  public void a(k paramk, int paramInt, l paraml) {
    this.d = paramk;
    this.d.a(this);
    this.j = paraml;
    this.k = paramInt;
    this.j.a(this);
  }
  
  public void b(int paramInt) {
    this.h = paramInt;
  }
  
  public void b(k paramk, float paramFloat) {
    this.i = paramk;
  }
  
  public void b(k paramk, int paramInt, l paraml) {
    this.i = paramk;
    this.l = paraml;
    this.m = paramInt;
  }
  
  public void d() {
    super.d();
    this.d = null;
    this.e = 0.0F;
    this.j = null;
    this.k = 1;
    this.l = null;
    this.m = 1;
    this.f = null;
    this.g = 0.0F;
    this.i = null;
    this.h = 0;
  }
  
  public void e() {
    int i = this.b;
    int j = 1;
    if (i == 1)
      return; 
    if (this.h == 4)
      return; 
    l l1 = this.j;
    if (l1 != null) {
      if (l1.b != 1)
        return; 
      this.e = this.k * l1.c;
    } 
    l1 = this.l;
    if (l1 != null) {
      if (l1.b != 1)
        return; 
      float f = l1.c;
    } 
    if (this.h == 1) {
      k k1 = this.d;
      if (k1 == null || k1.b == 1) {
        k1 = this.d;
        if (k1 == null) {
          this.f = this;
          this.g = this.e;
        } else {
          this.f = k1.f;
          k1.g += this.e;
        } 
        a();
        return;
      } 
    } 
    if (this.h == 2) {
      k k1 = this.d;
      if (k1 != null && k1.b == 1) {
        k1 = this.i;
        if (k1 != null) {
          k1 = k1.d;
          if (k1 != null && k1.b == 1) {
            float f1;
            if (e.h() != null) {
              f f = e.h();
              f.v++;
            } 
            this.f = this.d.f;
            k1 = this.i;
            k1.f = k1.d.f;
            d.d d1 = this.c.c;
            i = j;
            if (d1 != d.d.f)
              if (d1 == d.d.g) {
                i = j;
              } else {
                i = 0;
              }  
            if (i != 0) {
              f1 = this.d.g - this.i.d.g;
            } else {
              f1 = this.i.d.g - this.d.g;
            } 
            d d2 = this.c;
            d1 = d2.c;
            if (d1 == d.d.d || d1 == d.d.f) {
              f2 = f1 - this.c.b.t();
              f1 = this.c.b.S;
            } else {
              f2 = f1 - d2.b.i();
              f1 = this.c.b.T;
            } 
            int n = this.c.b();
            j = this.i.c.b();
            if (this.c.g() == this.i.c.g()) {
              f1 = 0.5F;
              n = 0;
              j = 0;
            } 
            float f2 = f2 - n - j;
            if (i != 0) {
              k k2 = this.i;
              k2.g = k2.d.g + j + f2 * f1;
              this.g = this.d.g - n - (1.0F - f1) * f2;
            } else {
              this.g = this.d.g + n + f2 * f1;
              k k2 = this.i;
              k2.g = k2.d.g - j - (1.0F - f1) * f2;
            } 
            a();
            this.i.a();
            return;
          } 
        } 
      } 
    } 
    if (this.h == 3) {
      k k1 = this.d;
      if (k1 != null && k1.b == 1) {
        k1 = this.i;
        if (k1 != null) {
          k1 = k1.d;
          if (k1 != null && k1.b == 1) {
            if (e.h() != null) {
              f f = e.h();
              f.w++;
            } 
            k k2 = this.d;
            this.f = k2.f;
            k1 = this.i;
            k k3 = k1.d;
            k1.f = k3.f;
            k2.g += this.e;
            k3.g += k1.e;
            a();
            this.i.a();
            return;
          } 
        } 
      } 
    } 
    if (this.h == 5)
      this.c.b.E(); 
  }
  
  public float f() {
    return this.g;
  }
  
  public void g() {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Landroid/support/constraint/i/j/d;
    //   4: invokevirtual g : ()Landroid/support/constraint/i/j/d;
    //   7: astore #4
    //   9: aload #4
    //   11: ifnonnull -> 15
    //   14: return
    //   15: aload #4
    //   17: invokevirtual g : ()Landroid/support/constraint/i/j/d;
    //   20: aload_0
    //   21: getfield c : Landroid/support/constraint/i/j/d;
    //   24: if_acmpne -> 41
    //   27: aload_0
    //   28: iconst_4
    //   29: putfield h : I
    //   32: aload #4
    //   34: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   37: iconst_4
    //   38: putfield h : I
    //   41: aload_0
    //   42: getfield c : Landroid/support/constraint/i/j/d;
    //   45: invokevirtual b : ()I
    //   48: istore_2
    //   49: aload_0
    //   50: getfield c : Landroid/support/constraint/i/j/d;
    //   53: getfield c : Landroid/support/constraint/i/j/d$d;
    //   56: astore_3
    //   57: aload_3
    //   58: getstatic android/support/constraint/i/j/d$d.f : Landroid/support/constraint/i/j/d$d;
    //   61: if_acmpeq -> 73
    //   64: iload_2
    //   65: istore_1
    //   66: aload_3
    //   67: getstatic android/support/constraint/i/j/d$d.g : Landroid/support/constraint/i/j/d$d;
    //   70: if_acmpne -> 76
    //   73: iload_2
    //   74: ineg
    //   75: istore_1
    //   76: aload_0
    //   77: aload #4
    //   79: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   82: iload_1
    //   83: invokevirtual a : (Landroid/support/constraint/i/j/k;I)V
    //   86: return
  }
  
  public String toString() {
    if (this.b == 1) {
      if (this.f == this) {
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("[");
        stringBuilder2.append(this.c);
        stringBuilder2.append(", RESOLVED: ");
        stringBuilder2.append(this.g);
        stringBuilder2.append("]  type: ");
        stringBuilder2.append(a(this.h));
        return stringBuilder2.toString();
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("[");
      stringBuilder1.append(this.c);
      stringBuilder1.append(", RESOLVED: ");
      stringBuilder1.append(this.f);
      stringBuilder1.append(":");
      stringBuilder1.append(this.g);
      stringBuilder1.append("] type: ");
      stringBuilder1.append(a(this.h));
      return stringBuilder1.toString();
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("{ ");
    stringBuilder.append(this.c);
    stringBuilder.append(" UNRESOLVED} type: ");
    stringBuilder.append(a(this.h));
    return stringBuilder.toString();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\i\j\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */