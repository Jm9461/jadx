package android.support.constraint.i.j;

import java.util.ArrayList;

public class n {
  private int a;
  
  private int b;
  
  private int c;
  
  private int d;
  
  private ArrayList<a> e = new ArrayList<a>();
  
  public n(e parame) {
    this.a = parame.w();
    this.b = parame.x();
    this.c = parame.t();
    this.d = parame.i();
    ArrayList<d> arrayList = parame.b();
    byte b = 0;
    int i = arrayList.size();
    while (b < i) {
      d d = arrayList.get(b);
      this.e.add(new a(d));
      b++;
    } 
  }
  
  public void a(e parame) {
    parame.n(this.a);
    parame.o(this.b);
    parame.k(this.c);
    parame.c(this.d);
    byte b = 0;
    int i = this.e.size();
    while (b < i) {
      ((a)this.e.get(b)).a(parame);
      b++;
    } 
  }
  
  public void b(e parame) {
    this.a = parame.w();
    this.b = parame.x();
    this.c = parame.t();
    this.d = parame.i();
    int i = this.e.size();
    for (byte b = 0; b < i; b++)
      ((a)this.e.get(b)).b(parame); 
  }
  
  static class a {
    private d a;
    
    private d b;
    
    private int c;
    
    private d.c d;
    
    private int e;
    
    public a(d param1d) {
      this.a = param1d;
      this.b = param1d.g();
      this.c = param1d.b();
      this.d = param1d.f();
      this.e = param1d.a();
    }
    
    public void a(e param1e) {
      param1e.a(this.a.h()).a(this.b, this.c, this.d, this.e);
    }
    
    public void b(e param1e) {
      this.a = param1e.a(this.a.h());
      d d1 = this.a;
      if (d1 != null) {
        this.b = d1.g();
        this.c = this.a.b();
        this.d = this.a.f();
        this.e = this.a.a();
      } else {
        this.b = null;
        this.c = 0;
        this.d = d.c.d;
        this.e = 0;
      } 
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\i\j\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */