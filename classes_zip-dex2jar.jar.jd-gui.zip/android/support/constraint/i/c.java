package android.support.constraint.i;

public class c {
  g<b> a = new h<b>(256);
  
  g<i> b = new h<i>(256);
  
  i[] c = new i[32];
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\i\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */