package android.support.v7.view.menu;

import a.b.g.b.a.b;
import android.content.Context;
import android.support.v4.view.c;
import android.view.ActionProvider;
import android.view.MenuItem;
import android.view.View;

class m extends l {
  m(Context paramContext, b paramb) {
    super(paramContext, paramb);
  }
  
  l.a a(ActionProvider paramActionProvider) {
    return new a(this, this.b, paramActionProvider);
  }
  
  class a extends l.a implements ActionProvider.VisibilityListener {
    c.b d;
    
    public a(m this$0, Context param1Context, ActionProvider param1ActionProvider) {
      super(this$0, param1Context, param1ActionProvider);
    }
    
    public View a(MenuItem param1MenuItem) {
      return this.b.onCreateActionView(param1MenuItem);
    }
    
    public void a(c.b param1b) {
      this.d = param1b;
      ActionProvider actionProvider = this.b;
      if (param1b != null) {
        a a1 = this;
      } else {
        param1b = null;
      } 
      actionProvider.setVisibilityListener((ActionProvider.VisibilityListener)param1b);
    }
    
    public boolean b() {
      return this.b.isVisible();
    }
    
    public boolean e() {
      return this.b.overridesItemVisibility();
    }
    
    public void onActionProviderVisibilityChanged(boolean param1Boolean) {
      c.b b1 = this.d;
      if (b1 != null)
        b1.onActionProviderVisibilityChanged(param1Boolean); 
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\view\menu\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */