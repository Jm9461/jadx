package android.support.v7.view.menu;

import a.b.h.a.j;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.support.v7.widget.ActionMenuView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.l0;
import android.support.v7.widget.l1;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class ActionMenuItemView extends AppCompatTextView implements q.a, View.OnClickListener, ActionMenuView.a {
  k f;
  
  private CharSequence g;
  
  private Drawable h;
  
  h.b i;
  
  private l0 j;
  
  b k;
  
  private boolean l;
  
  private boolean m;
  
  private int n;
  
  private int o;
  
  private int p;
  
  public ActionMenuItemView(Context paramContext) {
    this(paramContext, null);
  }
  
  public ActionMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public ActionMenuItemView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    Resources resources = paramContext.getResources();
    this.l = e();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, j.ActionMenuItemView, paramInt, 0);
    this.n = typedArray.getDimensionPixelSize(j.ActionMenuItemView_android_minWidth, 0);
    typedArray.recycle();
    this.p = (int)(32.0F * (resources.getDisplayMetrics()).density + 0.5F);
    setOnClickListener(this);
    this.o = -1;
    setSaveEnabled(false);
  }
  
  private boolean e() {
    Configuration configuration = getContext().getResources().getConfiguration();
    int i = configuration.screenWidthDp;
    int j = configuration.screenHeightDp;
    return (i >= 480 || (i >= 640 && j >= 480) || configuration.orientation == 2);
  }
  
  private void f() {
    boolean bool = TextUtils.isEmpty(this.g);
    int i = 1;
    if (this.h != null && (!this.f.n() || (!this.l && !this.m)))
      i = 0; 
    i = (bool ^ true) & i;
    CharSequence charSequence2 = null;
    if (i != 0) {
      charSequence1 = this.g;
    } else {
      charSequence1 = null;
    } 
    setText(charSequence1);
    CharSequence charSequence1 = this.f.getContentDescription();
    if (TextUtils.isEmpty(charSequence1)) {
      if (i != 0) {
        charSequence1 = null;
      } else {
        charSequence1 = this.f.getTitle();
      } 
      setContentDescription(charSequence1);
    } else {
      setContentDescription(charSequence1);
    } 
    charSequence1 = this.f.getTooltipText();
    if (TextUtils.isEmpty(charSequence1)) {
      if (i != 0) {
        charSequence1 = charSequence2;
      } else {
        charSequence1 = this.f.getTitle();
      } 
      l1.a((View)this, charSequence1);
    } else {
      l1.a((View)this, charSequence1);
    } 
  }
  
  public void a(k paramk, int paramInt) {
    this.f = paramk;
    setIcon(paramk.getIcon());
    setTitle(paramk.a(this));
    setId(paramk.getItemId());
    if (paramk.isVisible()) {
      paramInt = 0;
    } else {
      paramInt = 8;
    } 
    setVisibility(paramInt);
    setEnabled(paramk.isEnabled());
    if (paramk.hasSubMenu() && this.j == null)
      this.j = new a(this); 
  }
  
  public boolean a() {
    return true;
  }
  
  public boolean b() {
    return d();
  }
  
  public boolean c() {
    boolean bool;
    if (d() && this.f.getIcon() == null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean d() {
    return TextUtils.isEmpty(getText()) ^ true;
  }
  
  public k getItemData() {
    return this.f;
  }
  
  public void onClick(View paramView) {
    h.b b1 = this.i;
    if (b1 != null)
      b1.a(this.f); 
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    this.l = e();
    f();
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    boolean bool = d();
    if (bool) {
      int m = this.o;
      if (m >= 0)
        super.setPadding(m, getPaddingTop(), getPaddingRight(), getPaddingBottom()); 
    } 
    super.onMeasure(paramInt1, paramInt2);
    int i = View.MeasureSpec.getMode(paramInt1);
    paramInt1 = View.MeasureSpec.getSize(paramInt1);
    int j = getMeasuredWidth();
    if (i == Integer.MIN_VALUE) {
      paramInt1 = Math.min(paramInt1, this.n);
    } else {
      paramInt1 = this.n;
    } 
    if (i != 1073741824 && this.n > 0 && j < paramInt1)
      super.onMeasure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), paramInt2); 
    if (!bool && this.h != null)
      super.setPadding((getMeasuredWidth() - this.h.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom()); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    super.onRestoreInstanceState(null);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (this.f.hasSubMenu()) {
      l0 l01 = this.j;
      if (l01 != null && l01.onTouch((View)this, paramMotionEvent))
        return true; 
    } 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public void setCheckable(boolean paramBoolean) {}
  
  public void setChecked(boolean paramBoolean) {}
  
  public void setExpandedFormat(boolean paramBoolean) {
    if (this.m != paramBoolean) {
      this.m = paramBoolean;
      k k1 = this.f;
      if (k1 != null)
        k1.b(); 
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.h = paramDrawable;
    if (paramDrawable != null) {
      int n = paramDrawable.getIntrinsicWidth();
      int m = paramDrawable.getIntrinsicHeight();
      int i1 = this.p;
      int j = n;
      int i = m;
      if (n > i1) {
        float f = i1 / n;
        j = this.p;
        i = (int)(m * f);
      } 
      i1 = this.p;
      n = j;
      m = i;
      if (i > i1) {
        float f = i1 / i;
        m = this.p;
        n = (int)(j * f);
      } 
      paramDrawable.setBounds(0, 0, n, m);
    } 
    setCompoundDrawables(paramDrawable, null, null, null);
    f();
  }
  
  public void setItemInvoker(h.b paramb) {
    this.i = paramb;
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.o = paramInt1;
    super.setPadding(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void setPopupCallback(b paramb) {
    this.k = paramb;
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.g = paramCharSequence;
    f();
  }
  
  private class a extends l0 {
    final ActionMenuItemView l;
    
    public a(ActionMenuItemView this$0) {
      super((View)this$0);
    }
    
    public t a() {
      ActionMenuItemView.b b = this.l.k;
      return (b != null) ? b.a() : null;
    }
    
    protected boolean b() {
      ActionMenuItemView actionMenuItemView = this.l;
      h.b b = actionMenuItemView.i;
      boolean bool = false;
      if (b != null && b.a(actionMenuItemView.f)) {
        t t = a();
        boolean bool1 = bool;
        if (t != null) {
          bool1 = bool;
          if (t.e())
            bool1 = true; 
        } 
        return bool1;
      } 
      return false;
    }
  }
  
  public static abstract class b {
    public abstract t a();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\view\menu\ActionMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */