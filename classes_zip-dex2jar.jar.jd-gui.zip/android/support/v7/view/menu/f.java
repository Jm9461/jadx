package android.support.v7.view.menu;

import a.b.h.a.g;
import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import java.util.ArrayList;

public class f implements p, AdapterView.OnItemClickListener {
  Context c;
  
  LayoutInflater d;
  
  h e;
  
  ExpandedMenuView f;
  
  int g;
  
  int h;
  
  int i;
  
  private p.a j;
  
  a k;
  
  private int l;
  
  public f(int paramInt1, int paramInt2) {
    this.i = paramInt1;
    this.h = paramInt2;
  }
  
  public f(Context paramContext, int paramInt) {
    this(paramInt, 0);
    this.c = paramContext;
    this.d = LayoutInflater.from(this.c);
  }
  
  public int a() {
    return this.l;
  }
  
  public q a(ViewGroup paramViewGroup) {
    if (this.f == null) {
      this.f = (ExpandedMenuView)this.d.inflate(g.abc_expanded_menu_layout, paramViewGroup, false);
      if (this.k == null)
        this.k = new a(this); 
      this.f.setAdapter((ListAdapter)this.k);
      this.f.setOnItemClickListener(this);
    } 
    return this.f;
  }
  
  public void a(Context paramContext, h paramh) {
    int i = this.h;
    if (i != 0) {
      this.c = (Context)new ContextThemeWrapper(paramContext, i);
      this.d = LayoutInflater.from(this.c);
    } else if (this.c != null) {
      this.c = paramContext;
      if (this.d == null)
        this.d = LayoutInflater.from(this.c); 
    } 
    this.e = paramh;
    a a1 = this.k;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public void a(Bundle paramBundle) {
    SparseArray sparseArray = paramBundle.getSparseParcelableArray("android:menu:list");
    if (sparseArray != null)
      this.f.restoreHierarchyState(sparseArray); 
  }
  
  public void a(Parcelable paramParcelable) {
    a((Bundle)paramParcelable);
  }
  
  public void a(h paramh, boolean paramBoolean) {
    p.a a1 = this.j;
    if (a1 != null)
      a1.a(paramh, paramBoolean); 
  }
  
  public void a(p.a parama) {
    this.j = parama;
  }
  
  public void a(boolean paramBoolean) {
    a a1 = this.k;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public boolean a(h paramh, k paramk) {
    return false;
  }
  
  public boolean a(v paramv) {
    if (!paramv.hasVisibleItems())
      return false; 
    (new i(paramv)).a((IBinder)null);
    p.a a1 = this.j;
    if (a1 != null)
      a1.a(paramv); 
    return true;
  }
  
  public void b(Bundle paramBundle) {
    SparseArray sparseArray = new SparseArray();
    ExpandedMenuView expandedMenuView = this.f;
    if (expandedMenuView != null)
      expandedMenuView.saveHierarchyState(sparseArray); 
    paramBundle.putSparseParcelableArray("android:menu:list", sparseArray);
  }
  
  public boolean b() {
    return false;
  }
  
  public boolean b(h paramh, k paramk) {
    return false;
  }
  
  public Parcelable c() {
    if (this.f == null)
      return null; 
    Bundle bundle = new Bundle();
    b(bundle);
    return (Parcelable)bundle;
  }
  
  public ListAdapter d() {
    if (this.k == null)
      this.k = new a(this); 
    return (ListAdapter)this.k;
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    this.e.a((MenuItem)this.k.getItem(paramInt), this, 0);
  }
  
  private class a extends BaseAdapter {
    private int c = -1;
    
    final f d;
    
    public a(f this$0) {
      a();
    }
    
    void a() {
      k k = this.d.e.f();
      if (k != null) {
        ArrayList<k> arrayList = this.d.e.j();
        int i = arrayList.size();
        for (byte b = 0; b < i; b++) {
          if ((k)arrayList.get(b) == k) {
            this.c = b;
            return;
          } 
        } 
      } 
      this.c = -1;
    }
    
    public int getCount() {
      int i = this.d.e.j().size() - this.d.g;
      return (this.c < 0) ? i : (i - 1);
    }
    
    public k getItem(int param1Int) {
      ArrayList<k> arrayList = this.d.e.j();
      int i = param1Int + this.d.g;
      int j = this.c;
      param1Int = i;
      if (j >= 0) {
        param1Int = i;
        if (i >= j)
          param1Int = i + 1; 
      } 
      return arrayList.get(param1Int);
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      View view = param1View;
      if (param1View == null) {
        f f1 = this.d;
        view = f1.d.inflate(f1.i, param1ViewGroup, false);
      } 
      ((q.a)view).a(getItem(param1Int), 0);
      return view;
    }
    
    public void notifyDataSetChanged() {
      a();
      super.notifyDataSetChanged();
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\view\menu\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */