package android.support.v7.view.menu;

import a.b.g.b.a.a;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.c;
import android.support.v4.view.v;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class h implements a {
  private static final int[] A = new int[] { 1, 4, 5, 3, 2, 0 };
  
  private final Context a;
  
  private final Resources b;
  
  private boolean c;
  
  private boolean d;
  
  private a e;
  
  private ArrayList<k> f;
  
  private ArrayList<k> g;
  
  private boolean h;
  
  private ArrayList<k> i;
  
  private ArrayList<k> j;
  
  private boolean k;
  
  private int l = 0;
  
  private ContextMenu.ContextMenuInfo m;
  
  CharSequence n;
  
  Drawable o;
  
  View p;
  
  private boolean q = false;
  
  private boolean r = false;
  
  private boolean s = false;
  
  private boolean t = false;
  
  private boolean u = false;
  
  private ArrayList<k> v = new ArrayList<k>();
  
  private CopyOnWriteArrayList<WeakReference<p>> w = new CopyOnWriteArrayList<WeakReference<p>>();
  
  private k x;
  
  private boolean y = false;
  
  private boolean z;
  
  public h(Context paramContext) {
    this.a = paramContext;
    this.b = paramContext.getResources();
    this.f = new ArrayList<k>();
    this.g = new ArrayList<k>();
    this.h = true;
    this.i = new ArrayList<k>();
    this.j = new ArrayList<k>();
    this.k = true;
    e(true);
  }
  
  private static int a(ArrayList<k> paramArrayList, int paramInt) {
    for (int i = paramArrayList.size() - 1; i >= 0; i--) {
      if (((k)paramArrayList.get(i)).c() <= paramInt)
        return i + 1; 
    } 
    return 0;
  }
  
  private k a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, CharSequence paramCharSequence, int paramInt5) {
    return new k(this, paramInt1, paramInt2, paramInt3, paramInt4, paramCharSequence, paramInt5);
  }
  
  private void a(int paramInt1, CharSequence paramCharSequence, int paramInt2, Drawable paramDrawable, View paramView) {
    Resources resources = l();
    if (paramView != null) {
      this.p = paramView;
      this.n = null;
      this.o = null;
    } else {
      if (paramInt1 > 0) {
        this.n = resources.getText(paramInt1);
      } else if (paramCharSequence != null) {
        this.n = paramCharSequence;
      } 
      if (paramInt2 > 0) {
        this.o = android.support.v4.content.a.c(e(), paramInt2);
      } else if (paramDrawable != null) {
        this.o = paramDrawable;
      } 
      this.p = null;
    } 
    b(false);
  }
  
  private void a(int paramInt, boolean paramBoolean) {
    if (paramInt < 0 || paramInt >= this.f.size())
      return; 
    this.f.remove(paramInt);
    if (paramBoolean)
      b(true); 
  }
  
  private boolean a(v paramv, p paramp) {
    if (this.w.isEmpty())
      return false; 
    boolean bool = false;
    if (paramp != null)
      bool = paramp.a(paramv); 
    for (WeakReference<p> weakReference : this.w) {
      boolean bool1;
      paramp = weakReference.get();
      if (paramp == null) {
        this.w.remove(weakReference);
        bool1 = bool;
      } else {
        bool1 = bool;
        if (!bool)
          bool1 = paramp.a(paramv); 
      } 
      bool = bool1;
    } 
    return bool;
  }
  
  private void d(boolean paramBoolean) {
    if (this.w.isEmpty())
      return; 
    s();
    for (WeakReference<p> weakReference : this.w) {
      p p = weakReference.get();
      if (p == null) {
        this.w.remove(weakReference);
        continue;
      } 
      p.a(paramBoolean);
    } 
    r();
  }
  
  private void e(Bundle paramBundle) {
    SparseArray sparseArray = paramBundle.getSparseParcelableArray("android:menu:presenters");
    if (sparseArray == null || this.w.isEmpty())
      return; 
    for (WeakReference<p> weakReference : this.w) {
      p p = weakReference.get();
      if (p == null) {
        this.w.remove(weakReference);
        continue;
      } 
      int i = p.a();
      if (i > 0) {
        Parcelable parcelable = (Parcelable)sparseArray.get(i);
        if (parcelable != null)
          p.a(parcelable); 
      } 
    } 
  }
  
  private void e(boolean paramBoolean) {
    boolean bool = true;
    if (paramBoolean && (this.b.getConfiguration()).keyboard != 1 && v.d(ViewConfiguration.get(this.a), this.a)) {
      paramBoolean = bool;
    } else {
      paramBoolean = false;
    } 
    this.d = paramBoolean;
  }
  
  private static int f(int paramInt) {
    int i = (0xFFFF0000 & paramInt) >> 16;
    if (i >= 0) {
      int[] arrayOfInt = A;
      if (i < arrayOfInt.length)
        return arrayOfInt[i] << 16 | 0xFFFF & paramInt; 
    } 
    throw new IllegalArgumentException("order does not contain a valid category.");
  }
  
  private void f(Bundle paramBundle) {
    if (this.w.isEmpty())
      return; 
    SparseArray sparseArray = new SparseArray();
    for (WeakReference<p> weakReference : this.w) {
      p p = weakReference.get();
      if (p == null) {
        this.w.remove(weakReference);
        continue;
      } 
      int i = p.a();
      if (i > 0) {
        Parcelable parcelable = p.c();
        if (parcelable != null)
          sparseArray.put(i, parcelable); 
      } 
    } 
    paramBundle.putSparseParcelableArray("android:menu:presenters", sparseArray);
  }
  
  public int a(int paramInt) {
    return a(paramInt, 0);
  }
  
  public int a(int paramInt1, int paramInt2) {
    int j = size();
    int i = paramInt2;
    if (paramInt2 < 0)
      i = 0; 
    while (i < j) {
      if (((k)this.f.get(i)).getGroupId() == paramInt1)
        return i; 
      i++;
    } 
    return -1;
  }
  
  protected h a(Drawable paramDrawable) {
    a(0, null, 0, paramDrawable, null);
    return this;
  }
  
  protected h a(View paramView) {
    a(0, null, 0, null, paramView);
    return this;
  }
  
  protected h a(CharSequence paramCharSequence) {
    a(0, paramCharSequence, 0, null, null);
    return this;
  }
  
  k a(int paramInt, KeyEvent paramKeyEvent) {
    ArrayList<k> arrayList = this.v;
    arrayList.clear();
    a(arrayList, paramInt, paramKeyEvent);
    if (arrayList.isEmpty())
      return null; 
    int j = paramKeyEvent.getMetaState();
    KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
    paramKeyEvent.getKeyData(keyData);
    int i = arrayList.size();
    if (i == 1)
      return arrayList.get(0); 
    boolean bool = p();
    for (byte b = 0; b < i; b++) {
      char c;
      k k1 = arrayList.get(b);
      if (bool) {
        c = k1.getAlphabeticShortcut();
      } else {
        c = k1.getNumericShortcut();
      } 
      if ((c == keyData.meta[0] && (j & 0x2) == 0) || (c == keyData.meta[2] && (j & 0x2) != 0) || (bool && c == '\b' && paramInt == 67))
        return k1; 
    } 
    return null;
  }
  
  protected MenuItem a(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    int i = f(paramInt3);
    k k1 = a(paramInt1, paramInt2, paramInt3, i, paramCharSequence, this.l);
    ContextMenu.ContextMenuInfo contextMenuInfo = this.m;
    if (contextMenuInfo != null)
      k1.a(contextMenuInfo); 
    ArrayList<k> arrayList = this.f;
    arrayList.add(a(arrayList, i), k1);
    b(true);
    return (MenuItem)k1;
  }
  
  public void a() {
    a a1 = this.e;
    if (a1 != null)
      a1.a(this); 
  }
  
  public void a(Bundle paramBundle) {
    if (paramBundle == null)
      return; 
    SparseArray sparseArray = paramBundle.getSparseParcelableArray(d());
    int j = size();
    int i;
    for (i = 0; i < j; i++) {
      MenuItem menuItem = getItem(i);
      View view = menuItem.getActionView();
      if (view != null && view.getId() != -1)
        view.restoreHierarchyState(sparseArray); 
      if (menuItem.hasSubMenu())
        ((v)menuItem.getSubMenu()).a(paramBundle); 
    } 
    i = paramBundle.getInt("android:menu:expandedactionview");
    if (i > 0) {
      MenuItem menuItem = findItem(i);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
  }
  
  public void a(a parama) {
    this.e = parama;
  }
  
  public void a(p paramp) {
    a(paramp, this.a);
  }
  
  public void a(p paramp, Context paramContext) {
    this.w.add(new WeakReference<p>(paramp));
    paramp.a(paramContext, this);
    this.k = true;
  }
  
  void a(MenuItem paramMenuItem) {
    int i = paramMenuItem.getGroupId();
    int j = this.f.size();
    s();
    for (byte b = 0; b < j; b++) {
      k k1 = this.f.get(b);
      if (k1.getGroupId() == i && k1.i() && k1.isCheckable()) {
        boolean bool;
        if (k1 == paramMenuItem) {
          bool = true;
        } else {
          bool = false;
        } 
        k1.b(bool);
      } 
    } 
    r();
  }
  
  void a(List<k> paramList, int paramInt, KeyEvent paramKeyEvent) {
    boolean bool = p();
    int j = paramKeyEvent.getModifiers();
    KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
    if (!paramKeyEvent.getKeyData(keyData) && paramInt != 67)
      return; 
    int i = this.f.size();
    for (byte b = 0; b < i; b++) {
      char c;
      int m;
      k k1 = this.f.get(b);
      if (k1.hasSubMenu())
        ((h)k1.getSubMenu()).a(paramList, paramInt, paramKeyEvent); 
      if (bool) {
        c = k1.getAlphabeticShortcut();
      } else {
        c = k1.getNumericShortcut();
      } 
      if (bool) {
        m = k1.getAlphabeticModifiers();
      } else {
        m = k1.getNumericModifiers();
      } 
      if ((j & 0x1100F) == (0x1100F & m)) {
        m = 1;
      } else {
        m = 0;
      } 
      if (m != 0 && c != '\000') {
        char[] arrayOfChar = keyData.meta;
        if ((c == arrayOfChar[0] || c == arrayOfChar[2] || (bool && c == '\b' && paramInt == 67)) && k1.isEnabled())
          paramList.add(k1); 
      } 
    } 
  }
  
  public final void a(boolean paramBoolean) {
    if (this.u)
      return; 
    this.u = true;
    for (WeakReference<p> weakReference : this.w) {
      p p = weakReference.get();
      if (p == null) {
        this.w.remove(weakReference);
        continue;
      } 
      p.a(this, paramBoolean);
    } 
    this.u = false;
  }
  
  boolean a(h paramh, MenuItem paramMenuItem) {
    boolean bool;
    a a1 = this.e;
    if (a1 != null && a1.a(paramh, paramMenuItem)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean a(k paramk) {
    boolean bool2;
    if (this.w.isEmpty() || this.x != paramk)
      return false; 
    boolean bool1 = false;
    s();
    Iterator<WeakReference<p>> iterator = this.w.iterator();
    while (true) {
      bool2 = bool1;
      if (iterator.hasNext()) {
        WeakReference<p> weakReference = iterator.next();
        p p = weakReference.get();
        if (p == null) {
          this.w.remove(weakReference);
          bool2 = bool1;
        } else {
          boolean bool = p.a(this, paramk);
          bool1 = bool;
          bool2 = bool1;
          if (bool) {
            bool2 = bool1;
            break;
          } 
        } 
        bool1 = bool2;
        continue;
      } 
      break;
    } 
    r();
    if (bool2)
      this.x = null; 
    return bool2;
  }
  
  public boolean a(MenuItem paramMenuItem, int paramInt) {
    return a(paramMenuItem, (p)null, paramInt);
  }
  
  public boolean a(MenuItem paramMenuItem, p paramp, int paramInt) {
    boolean bool;
    boolean bool1;
    k k1 = (k)paramMenuItem;
    if (k1 == null || !k1.isEnabled())
      return false; 
    boolean bool2 = k1.g();
    c c = k1.a();
    if (c != null && c.a()) {
      bool = true;
    } else {
      bool = false;
    } 
    if (k1.f()) {
      bool2 |= k1.expandActionView();
      bool1 = bool2;
      if (bool2) {
        a(true);
        bool1 = bool2;
      } 
    } else {
      if (k1.hasSubMenu() || bool) {
        if ((paramInt & 0x4) == 0)
          a(false); 
        if (!k1.hasSubMenu())
          k1.a(new v(e(), this, k1)); 
        v v = (v)k1.getSubMenu();
        if (bool)
          c.a(v); 
        boolean bool3 = bool2 | a(v, paramp);
        if (!bool3)
          a(true); 
        return bool3;
      } 
      bool1 = bool2;
      if ((paramInt & 0x1) == 0) {
        a(true);
        bool1 = bool2;
      } 
    } 
    return bool1;
  }
  
  public MenuItem add(int paramInt) {
    return a(0, 0, 0, this.b.getString(paramInt));
  }
  
  public MenuItem add(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return a(paramInt1, paramInt2, paramInt3, this.b.getString(paramInt4));
  }
  
  public MenuItem add(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    return a(paramInt1, paramInt2, paramInt3, paramCharSequence);
  }
  
  public MenuItem add(CharSequence paramCharSequence) {
    return a(0, 0, 0, paramCharSequence);
  }
  
  public int addIntentOptions(int paramInt1, int paramInt2, int paramInt3, ComponentName paramComponentName, Intent[] paramArrayOfIntent, Intent paramIntent, int paramInt4, MenuItem[] paramArrayOfMenuItem) {
    PackageManager packageManager = this.a.getPackageManager();
    int i = 0;
    List<ResolveInfo> list = packageManager.queryIntentActivityOptions(paramComponentName, paramArrayOfIntent, paramIntent, 0);
    if (list != null)
      i = list.size(); 
    if ((paramInt4 & 0x1) == 0)
      removeGroup(paramInt1); 
    for (paramInt4 = 0; paramInt4 < i; paramInt4++) {
      ResolveInfo resolveInfo = list.get(paramInt4);
      int j = resolveInfo.specificIndex;
      if (j < 0) {
        intent = paramIntent;
      } else {
        intent = paramArrayOfIntent[j];
      } 
      Intent intent = new Intent(intent);
      intent.setComponent(new ComponentName(resolveInfo.activityInfo.applicationInfo.packageName, resolveInfo.activityInfo.name));
      MenuItem menuItem = add(paramInt1, paramInt2, paramInt3, resolveInfo.loadLabel(packageManager)).setIcon(resolveInfo.loadIcon(packageManager)).setIntent(intent);
      if (paramArrayOfMenuItem != null) {
        j = resolveInfo.specificIndex;
        if (j >= 0)
          paramArrayOfMenuItem[j] = menuItem; 
      } 
    } 
    return i;
  }
  
  public SubMenu addSubMenu(int paramInt) {
    return addSubMenu(0, 0, 0, this.b.getString(paramInt));
  }
  
  public SubMenu addSubMenu(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return addSubMenu(paramInt1, paramInt2, paramInt3, this.b.getString(paramInt4));
  }
  
  public SubMenu addSubMenu(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    k k1 = (k)a(paramInt1, paramInt2, paramInt3, paramCharSequence);
    v v = new v(this.a, this, k1);
    k1.a(v);
    return v;
  }
  
  public SubMenu addSubMenu(CharSequence paramCharSequence) {
    return addSubMenu(0, 0, 0, paramCharSequence);
  }
  
  public int b(int paramInt) {
    int i = size();
    for (byte b = 0; b < i; b++) {
      if (((k)this.f.get(b)).getItemId() == paramInt)
        return b; 
    } 
    return -1;
  }
  
  public void b() {
    ArrayList<k> arrayList = n();
    if (!this.k)
      return; 
    boolean bool = false;
    for (WeakReference<p> weakReference : this.w) {
      p p = weakReference.get();
      if (p == null) {
        this.w.remove(weakReference);
        continue;
      } 
      bool |= p.b();
    } 
    if (bool) {
      this.i.clear();
      this.j.clear();
      int i = arrayList.size();
      for (bool = false; bool < i; bool++) {
        k k1 = arrayList.get(bool);
        if (k1.h()) {
          this.i.add(k1);
        } else {
          this.j.add(k1);
        } 
      } 
    } else {
      this.i.clear();
      this.j.clear();
      this.j.addAll(n());
    } 
    this.k = false;
  }
  
  public void b(Bundle paramBundle) {
    e(paramBundle);
  }
  
  public void b(p paramp) {
    for (WeakReference<p> weakReference : this.w) {
      p p1 = weakReference.get();
      if (p1 == null || p1 == paramp)
        this.w.remove(weakReference); 
    } 
  }
  
  public void b(boolean paramBoolean) {
    if (!this.q) {
      if (paramBoolean) {
        this.h = true;
        this.k = true;
      } 
      d(paramBoolean);
    } else {
      this.r = true;
      if (paramBoolean)
        this.s = true; 
    } 
  }
  
  public boolean b(k paramk) {
    boolean bool2;
    if (this.w.isEmpty())
      return false; 
    boolean bool1 = false;
    s();
    Iterator<WeakReference<p>> iterator = this.w.iterator();
    while (true) {
      bool2 = bool1;
      if (iterator.hasNext()) {
        WeakReference<p> weakReference = iterator.next();
        p p = weakReference.get();
        if (p == null) {
          this.w.remove(weakReference);
          bool2 = bool1;
        } else {
          boolean bool = p.b(this, paramk);
          bool1 = bool;
          bool2 = bool1;
          if (bool) {
            bool2 = bool1;
            break;
          } 
        } 
        bool1 = bool2;
        continue;
      } 
      break;
    } 
    r();
    if (bool2)
      this.x = paramk; 
    return bool2;
  }
  
  public h c(int paramInt) {
    this.l = paramInt;
    return this;
  }
  
  public ArrayList<k> c() {
    b();
    return this.i;
  }
  
  public void c(Bundle paramBundle) {
    SparseArray sparseArray = null;
    int i = size();
    byte b = 0;
    while (b < i) {
      MenuItem menuItem = getItem(b);
      View view = menuItem.getActionView();
      SparseArray sparseArray1 = sparseArray;
      if (view != null) {
        sparseArray1 = sparseArray;
        if (view.getId() != -1) {
          SparseArray sparseArray2 = sparseArray;
          if (sparseArray == null)
            sparseArray2 = new SparseArray(); 
          view.saveHierarchyState(sparseArray2);
          sparseArray1 = sparseArray2;
          if (menuItem.isActionViewExpanded()) {
            paramBundle.putInt("android:menu:expandedactionview", menuItem.getItemId());
            sparseArray1 = sparseArray2;
          } 
        } 
      } 
      if (menuItem.hasSubMenu())
        ((v)menuItem.getSubMenu()).c(paramBundle); 
      b++;
      sparseArray = sparseArray1;
    } 
    if (sparseArray != null)
      paramBundle.putSparseParcelableArray(d(), sparseArray); 
  }
  
  void c(k paramk) {
    this.k = true;
    b(true);
  }
  
  public void c(boolean paramBoolean) {
    this.z = paramBoolean;
  }
  
  public void clear() {
    k k1 = this.x;
    if (k1 != null)
      a(k1); 
    this.f.clear();
    b(true);
  }
  
  public void clearHeader() {
    this.o = null;
    this.n = null;
    this.p = null;
    b(false);
  }
  
  public void close() {
    a(true);
  }
  
  protected h d(int paramInt) {
    a(0, null, paramInt, null, null);
    return this;
  }
  
  protected String d() {
    return "android:menu:actionviewstates";
  }
  
  public void d(Bundle paramBundle) {
    f(paramBundle);
  }
  
  void d(k paramk) {
    this.h = true;
    b(true);
  }
  
  public Context e() {
    return this.a;
  }
  
  protected h e(int paramInt) {
    a(paramInt, null, 0, null, null);
    return this;
  }
  
  public k f() {
    return this.x;
  }
  
  public MenuItem findItem(int paramInt) {
    int i = size();
    for (byte b = 0; b < i; b++) {
      k k1 = this.f.get(b);
      if (k1.getItemId() == paramInt)
        return (MenuItem)k1; 
      if (k1.hasSubMenu()) {
        MenuItem menuItem = k1.getSubMenu().findItem(paramInt);
        if (menuItem != null)
          return menuItem; 
      } 
    } 
    return null;
  }
  
  public Drawable g() {
    return this.o;
  }
  
  public MenuItem getItem(int paramInt) {
    return (MenuItem)this.f.get(paramInt);
  }
  
  public CharSequence h() {
    return this.n;
  }
  
  public boolean hasVisibleItems() {
    if (this.z)
      return true; 
    int i = size();
    for (byte b = 0; b < i; b++) {
      if (((k)this.f.get(b)).isVisible())
        return true; 
    } 
    return false;
  }
  
  public View i() {
    return this.p;
  }
  
  public boolean isShortcutKey(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool;
    if (a(paramInt, paramKeyEvent) != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public ArrayList<k> j() {
    b();
    return this.j;
  }
  
  boolean k() {
    return this.t;
  }
  
  Resources l() {
    return this.b;
  }
  
  public h m() {
    return this;
  }
  
  public ArrayList<k> n() {
    if (!this.h)
      return this.g; 
    this.g.clear();
    int i = this.f.size();
    for (byte b = 0; b < i; b++) {
      k k1 = this.f.get(b);
      if (k1.isVisible())
        this.g.add(k1); 
    } 
    this.h = false;
    this.k = true;
    return this.g;
  }
  
  public boolean o() {
    return this.y;
  }
  
  boolean p() {
    return this.c;
  }
  
  public boolean performIdentifierAction(int paramInt1, int paramInt2) {
    return a(findItem(paramInt1), paramInt2);
  }
  
  public boolean performShortcut(int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    k k1 = a(paramInt1, paramKeyEvent);
    boolean bool = false;
    if (k1 != null)
      bool = a((MenuItem)k1, paramInt2); 
    if ((paramInt2 & 0x2) != 0)
      a(true); 
    return bool;
  }
  
  public boolean q() {
    return this.d;
  }
  
  public void r() {
    this.q = false;
    if (this.r) {
      this.r = false;
      b(this.s);
    } 
  }
  
  public void removeGroup(int paramInt) {
    int i = a(paramInt);
    if (i >= 0) {
      int j = this.f.size();
      for (byte b = 0; b < j - i && ((k)this.f.get(i)).getGroupId() == paramInt; b++)
        a(i, false); 
      b(true);
    } 
  }
  
  public void removeItem(int paramInt) {
    a(b(paramInt), true);
  }
  
  public void s() {
    if (!this.q) {
      this.q = true;
      this.r = false;
      this.s = false;
    } 
  }
  
  public void setGroupCheckable(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    int i = this.f.size();
    for (byte b = 0; b < i; b++) {
      k k1 = this.f.get(b);
      if (k1.getGroupId() == paramInt) {
        k1.c(paramBoolean2);
        k1.setCheckable(paramBoolean1);
      } 
    } 
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    this.y = paramBoolean;
  }
  
  public void setGroupEnabled(int paramInt, boolean paramBoolean) {
    int i = this.f.size();
    for (byte b = 0; b < i; b++) {
      k k1 = this.f.get(b);
      if (k1.getGroupId() == paramInt)
        k1.setEnabled(paramBoolean); 
    } 
  }
  
  public void setGroupVisible(int paramInt, boolean paramBoolean) {
    int i = this.f.size();
    boolean bool = false;
    byte b = 0;
    while (b < i) {
      k k1 = this.f.get(b);
      boolean bool1 = bool;
      if (k1.getGroupId() == paramInt) {
        bool1 = bool;
        if (k1.e(paramBoolean))
          bool1 = true; 
      } 
      b++;
      bool = bool1;
    } 
    if (bool)
      b(true); 
  }
  
  public void setQwertyMode(boolean paramBoolean) {
    this.c = paramBoolean;
    b(false);
  }
  
  public int size() {
    return this.f.size();
  }
  
  public static interface a {
    void a(h param1h);
    
    boolean a(h param1h, MenuItem param1MenuItem);
  }
  
  public static interface b {
    boolean a(k param1k);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\view\menu\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */