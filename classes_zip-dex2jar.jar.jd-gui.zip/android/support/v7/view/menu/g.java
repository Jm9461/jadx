package android.support.v7.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;

public class g extends BaseAdapter {
  h c;
  
  private int d = -1;
  
  private boolean e;
  
  private final boolean f;
  
  private final LayoutInflater g;
  
  private final int h;
  
  public g(h paramh, LayoutInflater paramLayoutInflater, boolean paramBoolean, int paramInt) {
    this.f = paramBoolean;
    this.g = paramLayoutInflater;
    this.c = paramh;
    this.h = paramInt;
    a();
  }
  
  void a() {
    k k = this.c.f();
    if (k != null) {
      ArrayList<k> arrayList = this.c.j();
      int i = arrayList.size();
      for (byte b = 0; b < i; b++) {
        if ((k)arrayList.get(b) == k) {
          this.d = b;
          return;
        } 
      } 
    } 
    this.d = -1;
  }
  
  public void a(boolean paramBoolean) {
    this.e = paramBoolean;
  }
  
  public h b() {
    return this.c;
  }
  
  public int getCount() {
    ArrayList<k> arrayList;
    if (this.f) {
      arrayList = this.c.j();
    } else {
      arrayList = this.c.n();
    } 
    return (this.d < 0) ? arrayList.size() : (arrayList.size() - 1);
  }
  
  public k getItem(int paramInt) {
    ArrayList<k> arrayList;
    if (this.f) {
      arrayList = this.c.j();
    } else {
      arrayList = this.c.n();
    } 
    int j = this.d;
    int i = paramInt;
    if (j >= 0) {
      i = paramInt;
      if (paramInt >= j)
        i = paramInt + 1; 
    } 
    return arrayList.get(i);
  }
  
  public long getItemId(int paramInt) {
    return paramInt;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    int i;
    boolean bool;
    View view = paramView;
    if (paramView == null)
      view = this.g.inflate(this.h, paramViewGroup, false); 
    int j = getItem(paramInt).getGroupId();
    if (paramInt - 1 >= 0) {
      i = getItem(paramInt - 1).getGroupId();
    } else {
      i = j;
    } 
    ListMenuItemView listMenuItemView = (ListMenuItemView)view;
    if (this.c.o() && j != i) {
      bool = true;
    } else {
      bool = false;
    } 
    listMenuItemView.setGroupDividerEnabled(bool);
    q.a a = (q.a)view;
    if (this.e)
      ((ListMenuItemView)view).setForceShowIcon(true); 
    a.a(getItem(paramInt), 0);
    return view;
  }
  
  public void notifyDataSetChanged() {
    a();
    super.notifyDataSetChanged();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\view\menu\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */