package android.support.v7.view.menu;

import a.b.g.b.a.a;
import a.b.g.b.a.b;
import a.b.g.b.a.c;
import android.content.Context;
import android.os.Build;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;

public final class r {
  public static Menu a(Context paramContext, a parama) {
    return new s(paramContext, parama);
  }
  
  public static MenuItem a(Context paramContext, b paramb) {
    return (Build.VERSION.SDK_INT >= 16) ? new m(paramContext, paramb) : new l(paramContext, paramb);
  }
  
  public static SubMenu a(Context paramContext, c paramc) {
    return new w(paramContext, paramc);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\view\menu\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */