package android.support.v7.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

public abstract class b implements p {
  protected Context c;
  
  protected Context d;
  
  protected h e;
  
  protected LayoutInflater f;
  
  private p.a g;
  
  private int h;
  
  private int i;
  
  protected q j;
  
  private int k;
  
  public b(Context paramContext, int paramInt1, int paramInt2) {
    this.c = paramContext;
    this.f = LayoutInflater.from(paramContext);
    this.h = paramInt1;
    this.i = paramInt2;
  }
  
  public int a() {
    return this.k;
  }
  
  public q.a a(ViewGroup paramViewGroup) {
    return (q.a)this.f.inflate(this.i, paramViewGroup, false);
  }
  
  public View a(k paramk, View paramView, ViewGroup paramViewGroup) {
    q.a a1;
    if (paramView instanceof q.a) {
      a1 = (q.a)paramView;
    } else {
      a1 = a(paramViewGroup);
    } 
    a(paramk, a1);
    return (View)a1;
  }
  
  public void a(int paramInt) {
    this.k = paramInt;
  }
  
  public void a(Context paramContext, h paramh) {
    this.d = paramContext;
    LayoutInflater.from(this.d);
    this.e = paramh;
  }
  
  public void a(h paramh, boolean paramBoolean) {
    p.a a1 = this.g;
    if (a1 != null)
      a1.a(paramh, paramBoolean); 
  }
  
  public abstract void a(k paramk, q.a parama);
  
  public void a(p.a parama) {
    this.g = parama;
  }
  
  protected void a(View paramView, int paramInt) {
    ViewGroup viewGroup = (ViewGroup)paramView.getParent();
    if (viewGroup != null)
      viewGroup.removeView(paramView); 
    ((ViewGroup)this.j).addView(paramView, paramInt);
  }
  
  public void a(boolean paramBoolean) {
    ViewGroup viewGroup = (ViewGroup)this.j;
    if (viewGroup == null)
      return; 
    int j = 0;
    int i = 0;
    h h1 = this.e;
    if (h1 != null) {
      h1.b();
      ArrayList<k> arrayList = this.e.n();
      int k = arrayList.size();
      byte b1 = 0;
      while (true) {
        j = i;
        if (b1 < k) {
          k k1 = arrayList.get(b1);
          j = i;
          if (a(i, k1)) {
            View view1 = viewGroup.getChildAt(i);
            if (view1 instanceof q.a) {
              k k2 = ((q.a)view1).getItemData();
            } else {
              h1 = null;
            } 
            View view2 = a(k1, view1, viewGroup);
            if (k1 != h1) {
              view2.setPressed(false);
              view2.jumpDrawablesToCurrentState();
            } 
            if (view2 != view1)
              a(view2, i); 
            j = i + 1;
          } 
          b1++;
          i = j;
          continue;
        } 
        break;
      } 
    } 
    while (j < viewGroup.getChildCount()) {
      if (!a(viewGroup, j))
        j++; 
    } 
  }
  
  public abstract boolean a(int paramInt, k paramk);
  
  public boolean a(h paramh, k paramk) {
    return false;
  }
  
  public boolean a(v paramv) {
    p.a a1 = this.g;
    return (a1 != null) ? a1.a(paramv) : false;
  }
  
  protected boolean a(ViewGroup paramViewGroup, int paramInt) {
    paramViewGroup.removeViewAt(paramInt);
    return true;
  }
  
  public q b(ViewGroup paramViewGroup) {
    if (this.j == null) {
      this.j = (q)this.f.inflate(this.h, paramViewGroup, false);
      this.j.a(this.e);
      a(true);
    } 
    return this.j;
  }
  
  public boolean b(h paramh, k paramk) {
    return false;
  }
  
  public p.a d() {
    return this.g;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\view\menu\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */