package android.support.v7.app;

import a.b.h.f.i;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.support.v4.view.u;
import android.support.v7.view.menu.h;
import android.support.v7.view.menu.p;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.f0;
import android.support.v7.widget.k1;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import java.util.ArrayList;

class k extends a {
  f0 a;
  
  boolean b;
  
  Window.Callback c;
  
  private boolean d;
  
  private boolean e;
  
  private ArrayList<a.b> f = new ArrayList<a.b>();
  
  private final Runnable g = new a(this);
  
  private final Toolbar.f h = new b(this);
  
  k(Toolbar paramToolbar, CharSequence paramCharSequence, Window.Callback paramCallback) {
    this.a = (f0)new k1(paramToolbar, false);
    this.c = (Window.Callback)new e(this, paramCallback);
    this.a.setWindowCallback(this.c);
    paramToolbar.setOnMenuItemClickListener(this.h);
    this.a.setWindowTitle(paramCharSequence);
  }
  
  private Menu n() {
    if (!this.d) {
      this.a.a(new c(this), new d(this));
      this.d = true;
    } 
    return this.a.i();
  }
  
  public void a(float paramFloat) {
    u.a((View)this.a.j(), paramFloat);
  }
  
  public void a(int paramInt1, int paramInt2) {
    int i = this.a.h();
    this.a.d(paramInt1 & paramInt2 | (paramInt2 ^ 0xFFFFFFFF) & i);
  }
  
  public void a(Configuration paramConfiguration) {
    super.a(paramConfiguration);
  }
  
  public void a(Drawable paramDrawable) {
    this.a.a(paramDrawable);
  }
  
  public void a(CharSequence paramCharSequence) {
    this.a.setTitle(paramCharSequence);
  }
  
  public boolean a(int paramInt, KeyEvent paramKeyEvent) {
    Menu menu = n();
    if (menu != null) {
      if (paramKeyEvent != null) {
        i = paramKeyEvent.getDeviceId();
      } else {
        i = -1;
      } 
      int i = KeyCharacterMap.load(i).getKeyboardType();
      boolean bool = true;
      if (i == 1)
        bool = false; 
      menu.setQwertyMode(bool);
      return menu.performShortcut(paramInt, paramKeyEvent, 0);
    } 
    return false;
  }
  
  public boolean a(KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1)
      k(); 
    return true;
  }
  
  public void b(int paramInt) {
    this.a.c(paramInt);
  }
  
  public void b(Drawable paramDrawable) {
    this.a.b(paramDrawable);
  }
  
  public void b(CharSequence paramCharSequence) {
    this.a.setWindowTitle(paramCharSequence);
  }
  
  public void b(boolean paramBoolean) {
    if (paramBoolean == this.e)
      return; 
    this.e = paramBoolean;
    int i = this.f.size();
    for (byte b = 0; b < i; b++)
      ((a.b)this.f.get(b)).a(paramBoolean); 
  }
  
  public void c(boolean paramBoolean) {}
  
  public void d(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    a(bool, 4);
  }
  
  public void e(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    a(bool, 8);
  }
  
  public boolean e() {
    return this.a.c();
  }
  
  public void f(boolean paramBoolean) {}
  
  public boolean f() {
    if (this.a.n()) {
      this.a.collapseActionView();
      return true;
    } 
    return false;
  }
  
  public int g() {
    return this.a.h();
  }
  
  public void g(boolean paramBoolean) {}
  
  public Context h() {
    return this.a.k();
  }
  
  public boolean i() {
    this.a.j().removeCallbacks(this.g);
    u.a((View)this.a.j(), this.g);
    return true;
  }
  
  void j() {
    this.a.j().removeCallbacks(this.g);
  }
  
  public boolean k() {
    return this.a.d();
  }
  
  public Window.Callback l() {
    return this.c;
  }
  
  void m() {
    h h;
    null = n();
    if (null instanceof h) {
      h = (h)null;
    } else {
      h = null;
    } 
    if (h != null)
      h.s(); 
    try {
      null.clear();
      if (!this.c.onCreatePanelMenu(0, null) || !this.c.onPreparePanel(0, null, null))
        null.clear(); 
      return;
    } finally {
      if (h != null)
        h.r(); 
    } 
  }
  
  class a implements Runnable {
    final k c;
    
    a(k this$0) {}
    
    public void run() {
      this.c.m();
    }
  }
  
  class b implements Toolbar.f {
    final k a;
    
    b(k this$0) {}
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      return this.a.c.onMenuItemSelected(0, param1MenuItem);
    }
  }
  
  private final class c implements p.a {
    private boolean c;
    
    final k d;
    
    c(k this$0) {}
    
    public void a(h param1h, boolean param1Boolean) {
      if (this.c)
        return; 
      this.c = true;
      this.d.a.g();
      Window.Callback callback = this.d.c;
      if (callback != null)
        callback.onPanelClosed(108, (Menu)param1h); 
      this.c = false;
    }
    
    public boolean a(h param1h) {
      Window.Callback callback = this.d.c;
      if (callback != null) {
        callback.onMenuOpened(108, (Menu)param1h);
        return true;
      } 
      return false;
    }
  }
  
  private final class d implements h.a {
    final k c;
    
    d(k this$0) {}
    
    public void a(h param1h) {
      k k1 = this.c;
      if (k1.c != null)
        if (k1.a.b()) {
          this.c.c.onPanelClosed(108, (Menu)param1h);
        } else if (this.c.c.onPreparePanel(0, null, (Menu)param1h)) {
          this.c.c.onMenuOpened(108, (Menu)param1h);
        }  
    }
    
    public boolean a(h param1h, MenuItem param1MenuItem) {
      return false;
    }
  }
  
  private class e extends i {
    final k d;
    
    public e(k this$0, Window.Callback param1Callback) {
      super(param1Callback);
    }
    
    public View onCreatePanelView(int param1Int) {
      return (param1Int == 0) ? new View(this.d.a.k()) : super.onCreatePanelView(param1Int);
    }
    
    public boolean onPreparePanel(int param1Int, View param1View, Menu param1Menu) {
      boolean bool = super.onPreparePanel(param1Int, param1View, param1Menu);
      if (bool) {
        k k1 = this.d;
        if (!k1.b) {
          k1.a.e();
          this.d.b = true;
        } 
      } 
      return bool;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\app\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */