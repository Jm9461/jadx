package android.support.v7.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;

public abstract class g {
  private static int c = -1;
  
  public static g a(Activity paramActivity, f paramf) {
    return new h((Context)paramActivity, paramActivity.getWindow(), paramf);
  }
  
  public static g a(Dialog paramDialog, f paramf) {
    return new h(paramDialog.getContext(), paramDialog.getWindow(), paramf);
  }
  
  public static int k() {
    return c;
  }
  
  public abstract <T extends View> T a(int paramInt);
  
  public abstract void a(Configuration paramConfiguration);
  
  public abstract void a(Bundle paramBundle);
  
  public abstract void a(Toolbar paramToolbar);
  
  public abstract void a(View paramView);
  
  public abstract void a(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  public abstract void a(CharSequence paramCharSequence);
  
  public abstract boolean a();
  
  public abstract b.b b();
  
  public abstract void b(Bundle paramBundle);
  
  public abstract void b(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  public abstract boolean b(int paramInt);
  
  public abstract MenuInflater c();
  
  public abstract void c(int paramInt);
  
  public abstract void c(Bundle paramBundle);
  
  public abstract a d();
  
  public abstract void e();
  
  public abstract void f();
  
  public abstract void g();
  
  public abstract void h();
  
  public abstract void i();
  
  public abstract void j();
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\app\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */