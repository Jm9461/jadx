package android.support.v7.app;

import a.b.h.a.j;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.u;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.widget.o0;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.CursorAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import java.lang.ref.WeakReference;

class AlertController {
  NestedScrollView A;
  
  private int B = 0;
  
  private Drawable C;
  
  private ImageView D;
  
  private TextView E;
  
  private TextView F;
  
  private View G;
  
  ListAdapter H;
  
  int I = -1;
  
  private int J;
  
  private int K;
  
  int L;
  
  int M;
  
  int N;
  
  int O;
  
  private boolean P;
  
  private int Q = 0;
  
  Handler R;
  
  private final View.OnClickListener S = new a(this);
  
  private final Context a;
  
  final i b;
  
  private final Window c;
  
  private final int d;
  
  private CharSequence e;
  
  private CharSequence f;
  
  ListView g;
  
  private View h;
  
  private int i;
  
  private int j;
  
  private int k;
  
  private int l;
  
  private int m;
  
  private boolean n = false;
  
  Button o;
  
  private CharSequence p;
  
  Message q;
  
  private Drawable r;
  
  Button s;
  
  private CharSequence t;
  
  Message u;
  
  private Drawable v;
  
  Button w;
  
  private CharSequence x;
  
  Message y;
  
  private Drawable z;
  
  public AlertController(Context paramContext, i parami, Window paramWindow) {
    this.a = paramContext;
    this.b = parami;
    this.c = paramWindow;
    this.R = new g((DialogInterface)parami);
    TypedArray typedArray = paramContext.obtainStyledAttributes(null, j.AlertDialog, a.b.h.a.a.alertDialogStyle, 0);
    this.J = typedArray.getResourceId(j.AlertDialog_android_layout, 0);
    this.K = typedArray.getResourceId(j.AlertDialog_buttonPanelSideLayout, 0);
    this.L = typedArray.getResourceId(j.AlertDialog_listLayout, 0);
    this.M = typedArray.getResourceId(j.AlertDialog_multiChoiceItemLayout, 0);
    this.N = typedArray.getResourceId(j.AlertDialog_singleChoiceItemLayout, 0);
    this.O = typedArray.getResourceId(j.AlertDialog_listItemLayout, 0);
    this.P = typedArray.getBoolean(j.AlertDialog_showTitle, true);
    this.d = typedArray.getDimensionPixelSize(j.AlertDialog_buttonIconDimen, 0);
    typedArray.recycle();
    parami.a(1);
  }
  
  private ViewGroup a(View paramView1, View paramView2) {
    if (paramView1 == null) {
      paramView1 = paramView2;
      if (paramView2 instanceof ViewStub)
        paramView1 = ((ViewStub)paramView2).inflate(); 
      return (ViewGroup)paramView1;
    } 
    if (paramView2 != null) {
      ViewParent viewParent = paramView2.getParent();
      if (viewParent instanceof ViewGroup)
        ((ViewGroup)viewParent).removeView(paramView2); 
    } 
    paramView2 = paramView1;
    if (paramView1 instanceof ViewStub)
      paramView2 = ((ViewStub)paramView1).inflate(); 
    return (ViewGroup)paramView2;
  }
  
  static void a(View paramView1, View paramView2, View paramView3) {
    boolean bool = false;
    if (paramView2 != null) {
      byte b;
      if (paramView1.canScrollVertically(-1)) {
        b = 0;
      } else {
        b = 4;
      } 
      paramView2.setVisibility(b);
    } 
    if (paramView3 != null) {
      byte b;
      if (paramView1.canScrollVertically(1)) {
        b = bool;
      } else {
        b = 4;
      } 
      paramView3.setVisibility(b);
    } 
  }
  
  private void a(ViewGroup paramViewGroup) {
    int j = 0;
    this.o = (Button)paramViewGroup.findViewById(16908313);
    this.o.setOnClickListener(this.S);
    boolean bool1 = TextUtils.isEmpty(this.p);
    boolean bool = false;
    if (bool1 && this.r == null) {
      this.o.setVisibility(8);
    } else {
      this.o.setText(this.p);
      Drawable drawable = this.r;
      if (drawable != null) {
        j = this.d;
        drawable.setBounds(0, 0, j, j);
        this.o.setCompoundDrawables(this.r, null, null, null);
      } 
      this.o.setVisibility(0);
      j = false | true;
    } 
    this.s = (Button)paramViewGroup.findViewById(16908314);
    this.s.setOnClickListener(this.S);
    if (TextUtils.isEmpty(this.t) && this.v == null) {
      this.s.setVisibility(8);
    } else {
      this.s.setText(this.t);
      Drawable drawable = this.v;
      if (drawable != null) {
        int k = this.d;
        drawable.setBounds(0, 0, k, k);
        this.s.setCompoundDrawables(this.v, null, null, null);
      } 
      this.s.setVisibility(0);
      j |= 0x2;
    } 
    this.w = (Button)paramViewGroup.findViewById(16908315);
    this.w.setOnClickListener(this.S);
    if (TextUtils.isEmpty(this.x) && this.z == null) {
      this.w.setVisibility(8);
    } else {
      this.w.setText(this.x);
      Drawable drawable = this.r;
      if (drawable != null) {
        int k = this.d;
        drawable.setBounds(0, 0, k, k);
        this.o.setCompoundDrawables(this.r, null, null, null);
      } 
      this.w.setVisibility(0);
      j |= 0x4;
    } 
    if (a(this.a))
      if (j == 1) {
        a(this.o);
      } else if (j == 2) {
        a(this.s);
      } else if (j == 4) {
        a(this.w);
      }  
    if (j != 0)
      bool = true; 
    if (!bool)
      paramViewGroup.setVisibility(8); 
  }
  
  private void a(ViewGroup paramViewGroup, View paramView, int paramInt1, int paramInt2) {
    View view1 = this.c.findViewById(a.b.h.a.f.scrollIndicatorUp);
    View view2 = this.c.findViewById(a.b.h.a.f.scrollIndicatorDown);
    if (Build.VERSION.SDK_INT >= 23) {
      u.a(paramView, paramInt1, paramInt2);
      if (view1 != null)
        paramViewGroup.removeView(view1); 
      if (view2 != null)
        paramViewGroup.removeView(view2); 
    } else {
      paramView = view1;
      if (view1 != null) {
        paramView = view1;
        if ((paramInt1 & 0x1) == 0) {
          paramViewGroup.removeView(view1);
          paramView = null;
        } 
      } 
      view1 = view2;
      if (view2 != null) {
        view1 = view2;
        if ((paramInt1 & 0x2) == 0) {
          paramViewGroup.removeView(view2);
          view1 = null;
        } 
      } 
      if (paramView != null || view1 != null)
        if (this.f != null) {
          this.A.setOnScrollChangeListener(new b(this, paramView, view1));
          this.A.post(new c(this, paramView, view1));
        } else {
          ListView listView = this.g;
          if (listView != null) {
            listView.setOnScrollListener(new d(this, paramView, view1));
            this.g.post(new e(this, paramView, view1));
          } else {
            if (paramView != null)
              paramViewGroup.removeView(paramView); 
            if (view1 != null)
              paramViewGroup.removeView(view1); 
          } 
        }  
    } 
  }
  
  private void a(Button paramButton) {
    LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)paramButton.getLayoutParams();
    layoutParams.gravity = 1;
    layoutParams.weight = 0.5F;
    paramButton.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
  }
  
  private static boolean a(Context paramContext) {
    TypedValue typedValue = new TypedValue();
    Resources.Theme theme = paramContext.getTheme();
    int j = a.b.h.a.a.alertDialogCenterButtons;
    boolean bool = true;
    theme.resolveAttribute(j, typedValue, true);
    if (typedValue.data == 0)
      bool = false; 
    return bool;
  }
  
  private int b() {
    int j = this.K;
    return (j == 0) ? this.J : ((this.Q == 1) ? j : this.J);
  }
  
  private void b(ViewGroup paramViewGroup) {
    this.A = (NestedScrollView)this.c.findViewById(a.b.h.a.f.scrollView);
    this.A.setFocusable(false);
    this.A.setNestedScrollingEnabled(false);
    this.F = (TextView)paramViewGroup.findViewById(16908299);
    TextView textView = this.F;
    if (textView == null)
      return; 
    CharSequence charSequence = this.f;
    if (charSequence != null) {
      textView.setText(charSequence);
    } else {
      textView.setVisibility(8);
      this.A.removeView((View)this.F);
      if (this.g != null) {
        paramViewGroup = (ViewGroup)this.A.getParent();
        int j = paramViewGroup.indexOfChild((View)this.A);
        paramViewGroup.removeViewAt(j);
        paramViewGroup.addView((View)this.g, j, new ViewGroup.LayoutParams(-1, -1));
      } else {
        paramViewGroup.setVisibility(8);
      } 
    } 
  }
  
  private void c() {
    int j;
    boolean bool1;
    boolean bool2;
    View view4 = this.c.findViewById(a.b.h.a.f.parentPanel);
    View view3 = view4.findViewById(a.b.h.a.f.topPanel);
    View view2 = view4.findViewById(a.b.h.a.f.contentPanel);
    View view1 = view4.findViewById(a.b.h.a.f.buttonPanel);
    ViewGroup viewGroup4 = (ViewGroup)view4.findViewById(a.b.h.a.f.customPanel);
    c(viewGroup4);
    View view7 = viewGroup4.findViewById(a.b.h.a.f.topPanel);
    View view6 = viewGroup4.findViewById(a.b.h.a.f.contentPanel);
    View view5 = viewGroup4.findViewById(a.b.h.a.f.buttonPanel);
    ViewGroup viewGroup3 = a(view7, view3);
    ViewGroup viewGroup2 = a(view6, view2);
    ViewGroup viewGroup1 = a(view5, view1);
    b(viewGroup2);
    a(viewGroup1);
    d(viewGroup3);
    if (viewGroup4 != null && viewGroup4.getVisibility() != 8) {
      j = 1;
    } else {
      j = 0;
    } 
    if (viewGroup3 != null && viewGroup3.getVisibility() != 8) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (viewGroup1 != null && viewGroup1.getVisibility() != 8) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (!bool2 && viewGroup2 != null) {
      View view = viewGroup2.findViewById(a.b.h.a.f.textSpacerNoButtons);
      if (view != null)
        view.setVisibility(0); 
    } 
    if (bool1) {
      View view;
      NestedScrollView nestedScrollView = this.A;
      if (nestedScrollView != null)
        nestedScrollView.setClipToPadding(true); 
      nestedScrollView = null;
      if (this.f != null || this.g != null)
        view = viewGroup3.findViewById(a.b.h.a.f.titleDividerNoCustom); 
      if (view != null)
        view.setVisibility(0); 
    } else if (viewGroup2 != null) {
      View view = viewGroup2.findViewById(a.b.h.a.f.textSpacerNoTitle);
      if (view != null)
        view.setVisibility(0); 
    } 
    ListView listView1 = this.g;
    if (listView1 instanceof RecycleListView)
      ((RecycleListView)listView1).a(bool1, bool2); 
    if (!j) {
      NestedScrollView nestedScrollView;
      listView1 = this.g;
      if (listView1 == null)
        nestedScrollView = this.A; 
      if (nestedScrollView != null) {
        byte b;
        if (bool1) {
          j = 1;
        } else {
          j = 0;
        } 
        if (bool2) {
          b = 2;
        } else {
          b = 0;
        } 
        a(viewGroup2, (View)nestedScrollView, j | b, 3);
      } 
    } 
    ListView listView2 = this.g;
    if (listView2 != null) {
      ListAdapter listAdapter = this.H;
      if (listAdapter != null) {
        listView2.setAdapter(listAdapter);
        j = this.I;
        if (j > -1) {
          listView2.setItemChecked(j, true);
          listView2.setSelection(j);
        } 
      } 
    } 
  }
  
  private void c(ViewGroup paramViewGroup) {
    View view = this.h;
    boolean bool = false;
    if (view != null) {
      view = this.h;
    } else if (this.i != 0) {
      view = LayoutInflater.from(this.a).inflate(this.i, paramViewGroup, false);
    } else {
      view = null;
    } 
    if (view != null)
      bool = true; 
    if (!bool || !c(view))
      this.c.setFlags(131072, 131072); 
    if (bool) {
      FrameLayout frameLayout = (FrameLayout)this.c.findViewById(a.b.h.a.f.custom);
      frameLayout.addView(view, new ViewGroup.LayoutParams(-1, -1));
      if (this.n)
        frameLayout.setPadding(this.j, this.k, this.l, this.m); 
      if (this.g != null)
        ((o0.a)paramViewGroup.getLayoutParams()).a = 0.0F; 
    } else {
      paramViewGroup.setVisibility(8);
    } 
  }
  
  static boolean c(View paramView) {
    if (paramView.onCheckIsTextEditor())
      return true; 
    if (!(paramView instanceof ViewGroup))
      return false; 
    ViewGroup viewGroup = (ViewGroup)paramView;
    int j = viewGroup.getChildCount();
    while (j > 0) {
      int k = j - 1;
      j = k;
      if (c(viewGroup.getChildAt(k)))
        return true; 
    } 
    return false;
  }
  
  private void d(ViewGroup paramViewGroup) {
    if (this.G != null) {
      ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-1, -2);
      paramViewGroup.addView(this.G, 0, layoutParams);
      this.c.findViewById(a.b.h.a.f.title_template).setVisibility(8);
    } else {
      Drawable drawable;
      this.D = (ImageView)this.c.findViewById(16908294);
      if ((TextUtils.isEmpty(this.e) ^ true) != 0 && this.P) {
        this.E = (TextView)this.c.findViewById(a.b.h.a.f.alertTitle);
        this.E.setText(this.e);
        int j = this.B;
        if (j != 0) {
          this.D.setImageResource(j);
        } else {
          drawable = this.C;
          if (drawable != null) {
            this.D.setImageDrawable(drawable);
          } else {
            this.E.setPadding(this.D.getPaddingLeft(), this.D.getPaddingTop(), this.D.getPaddingRight(), this.D.getPaddingBottom());
            this.D.setVisibility(8);
          } 
        } 
      } else {
        this.c.findViewById(a.b.h.a.f.title_template).setVisibility(8);
        this.D.setVisibility(8);
        drawable.setVisibility(8);
      } 
    } 
  }
  
  public int a(int paramInt) {
    TypedValue typedValue = new TypedValue();
    this.a.getTheme().resolveAttribute(paramInt, typedValue, true);
    return typedValue.resourceId;
  }
  
  public void a() {
    int j = b();
    this.b.setContentView(j);
    c();
  }
  
  public void a(int paramInt, CharSequence paramCharSequence, DialogInterface.OnClickListener paramOnClickListener, Message paramMessage, Drawable paramDrawable) {
    Message message = paramMessage;
    if (paramMessage == null) {
      message = paramMessage;
      if (paramOnClickListener != null)
        message = this.R.obtainMessage(paramInt, paramOnClickListener); 
    } 
    if (paramInt != -3) {
      if (paramInt != -2) {
        if (paramInt == -1) {
          this.p = paramCharSequence;
          this.q = message;
          this.r = paramDrawable;
        } else {
          throw new IllegalArgumentException("Button does not exist");
        } 
      } else {
        this.t = paramCharSequence;
        this.u = message;
        this.v = paramDrawable;
      } 
    } else {
      this.x = paramCharSequence;
      this.y = message;
      this.z = paramDrawable;
    } 
  }
  
  public void a(Drawable paramDrawable) {
    this.C = paramDrawable;
    this.B = 0;
    ImageView imageView = this.D;
    if (imageView != null)
      if (paramDrawable != null) {
        imageView.setVisibility(0);
        this.D.setImageDrawable(paramDrawable);
      } else {
        imageView.setVisibility(8);
      }  
  }
  
  public void a(View paramView) {
    this.G = paramView;
  }
  
  public void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.h = paramView;
    this.i = 0;
    this.n = true;
    this.j = paramInt1;
    this.k = paramInt2;
    this.l = paramInt3;
    this.m = paramInt4;
  }
  
  public void a(CharSequence paramCharSequence) {
    this.f = paramCharSequence;
    TextView textView = this.F;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
  
  public boolean a(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool;
    NestedScrollView nestedScrollView = this.A;
    if (nestedScrollView != null && nestedScrollView.a(paramKeyEvent)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void b(int paramInt) {
    this.C = null;
    this.B = paramInt;
    ImageView imageView = this.D;
    if (imageView != null)
      if (paramInt != 0) {
        imageView.setVisibility(0);
        this.D.setImageResource(this.B);
      } else {
        imageView.setVisibility(8);
      }  
  }
  
  public void b(View paramView) {
    this.h = paramView;
    this.i = 0;
    this.n = false;
  }
  
  public void b(CharSequence paramCharSequence) {
    this.e = paramCharSequence;
    TextView textView = this.E;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
  
  public boolean b(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool;
    NestedScrollView nestedScrollView = this.A;
    if (nestedScrollView != null && nestedScrollView.a(paramKeyEvent)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void c(int paramInt) {
    this.h = null;
    this.i = paramInt;
    this.n = false;
  }
  
  public static class RecycleListView extends ListView {
    private final int c;
    
    private final int d;
    
    public RecycleListView(Context param1Context) {
      this(param1Context, null);
    }
    
    public RecycleListView(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, j.RecycleListView);
      this.d = typedArray.getDimensionPixelOffset(j.RecycleListView_paddingBottomNoButtons, -1);
      this.c = typedArray.getDimensionPixelOffset(j.RecycleListView_paddingTopNoTitle, -1);
    }
    
    public void a(boolean param1Boolean1, boolean param1Boolean2) {
      if (!param1Boolean2 || !param1Boolean1) {
        int i;
        int j;
        int k = getPaddingLeft();
        if (param1Boolean1) {
          i = getPaddingTop();
        } else {
          i = this.c;
        } 
        int m = getPaddingRight();
        if (param1Boolean2) {
          j = getPaddingBottom();
        } else {
          j = this.d;
        } 
        setPadding(k, i, m, j);
      } 
    }
  }
  
  class a implements View.OnClickListener {
    final AlertController c;
    
    a(AlertController this$0) {}
    
    public void onClick(View param1View) {
      // Byte code:
      //   0: aload_0
      //   1: getfield c : Landroid/support/v7/app/AlertController;
      //   4: astore_2
      //   5: aload_1
      //   6: aload_2
      //   7: getfield o : Landroid/widget/Button;
      //   10: if_acmpne -> 30
      //   13: aload_2
      //   14: getfield q : Landroid/os/Message;
      //   17: astore_2
      //   18: aload_2
      //   19: ifnull -> 30
      //   22: aload_2
      //   23: invokestatic obtain : (Landroid/os/Message;)Landroid/os/Message;
      //   26: astore_1
      //   27: goto -> 92
      //   30: aload_0
      //   31: getfield c : Landroid/support/v7/app/AlertController;
      //   34: astore_2
      //   35: aload_1
      //   36: aload_2
      //   37: getfield s : Landroid/widget/Button;
      //   40: if_acmpne -> 60
      //   43: aload_2
      //   44: getfield u : Landroid/os/Message;
      //   47: astore_2
      //   48: aload_2
      //   49: ifnull -> 60
      //   52: aload_2
      //   53: invokestatic obtain : (Landroid/os/Message;)Landroid/os/Message;
      //   56: astore_1
      //   57: goto -> 92
      //   60: aload_0
      //   61: getfield c : Landroid/support/v7/app/AlertController;
      //   64: astore_2
      //   65: aload_1
      //   66: aload_2
      //   67: getfield w : Landroid/widget/Button;
      //   70: if_acmpne -> 90
      //   73: aload_2
      //   74: getfield y : Landroid/os/Message;
      //   77: astore_1
      //   78: aload_1
      //   79: ifnull -> 90
      //   82: aload_1
      //   83: invokestatic obtain : (Landroid/os/Message;)Landroid/os/Message;
      //   86: astore_1
      //   87: goto -> 92
      //   90: aconst_null
      //   91: astore_1
      //   92: aload_1
      //   93: ifnull -> 100
      //   96: aload_1
      //   97: invokevirtual sendToTarget : ()V
      //   100: aload_0
      //   101: getfield c : Landroid/support/v7/app/AlertController;
      //   104: astore_1
      //   105: aload_1
      //   106: getfield R : Landroid/os/Handler;
      //   109: iconst_1
      //   110: aload_1
      //   111: getfield b : Landroid/support/v7/app/i;
      //   114: invokevirtual obtainMessage : (ILjava/lang/Object;)Landroid/os/Message;
      //   117: invokevirtual sendToTarget : ()V
      //   120: return
    }
  }
  
  class b implements NestedScrollView.b {
    final View a;
    
    final View b;
    
    b(AlertController this$0, View param1View1, View param1View2) {}
    
    public void a(NestedScrollView param1NestedScrollView, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      AlertController.a((View)param1NestedScrollView, this.a, this.b);
    }
  }
  
  class c implements Runnable {
    final View c;
    
    final View d;
    
    final AlertController e;
    
    c(AlertController this$0, View param1View1, View param1View2) {}
    
    public void run() {
      AlertController.a((View)this.e.A, this.c, this.d);
    }
  }
  
  class d implements AbsListView.OnScrollListener {
    final View c;
    
    final View d;
    
    d(AlertController this$0, View param1View1, View param1View2) {}
    
    public void onScroll(AbsListView param1AbsListView, int param1Int1, int param1Int2, int param1Int3) {
      AlertController.a((View)param1AbsListView, this.c, this.d);
    }
    
    public void onScrollStateChanged(AbsListView param1AbsListView, int param1Int) {}
  }
  
  class e implements Runnable {
    final View c;
    
    final View d;
    
    final AlertController e;
    
    e(AlertController this$0, View param1View1, View param1View2) {}
    
    public void run() {
      AlertController.a((View)this.e.g, this.c, this.d);
    }
  }
  
  public static class f {
    public int A;
    
    public int B;
    
    public int C;
    
    public int D;
    
    public boolean E = false;
    
    public boolean[] F;
    
    public boolean G;
    
    public boolean H;
    
    public int I = -1;
    
    public DialogInterface.OnMultiChoiceClickListener J;
    
    public Cursor K;
    
    public String L;
    
    public String M;
    
    public AdapterView.OnItemSelectedListener N;
    
    public e O;
    
    public final Context a;
    
    public final LayoutInflater b;
    
    public int c = 0;
    
    public Drawable d;
    
    public int e = 0;
    
    public CharSequence f;
    
    public View g;
    
    public CharSequence h;
    
    public CharSequence i;
    
    public Drawable j;
    
    public DialogInterface.OnClickListener k;
    
    public CharSequence l;
    
    public Drawable m;
    
    public DialogInterface.OnClickListener n;
    
    public CharSequence o;
    
    public Drawable p;
    
    public DialogInterface.OnClickListener q;
    
    public boolean r;
    
    public DialogInterface.OnCancelListener s;
    
    public DialogInterface.OnDismissListener t;
    
    public DialogInterface.OnKeyListener u;
    
    public CharSequence[] v;
    
    public ListAdapter w;
    
    public DialogInterface.OnClickListener x;
    
    public int y;
    
    public View z;
    
    public f(Context param1Context) {
      this.a = param1Context;
      this.r = true;
      this.b = (LayoutInflater)param1Context.getSystemService("layout_inflater");
    }
    
    private void b(AlertController param1AlertController) {
      AlertController.h h;
      AlertController.RecycleListView recycleListView = (AlertController.RecycleListView)this.b.inflate(param1AlertController.L, null);
      if (this.G) {
        a a;
        Cursor cursor = this.K;
        if (cursor == null) {
          a = new a(this, this.a, param1AlertController.M, 16908308, this.v, recycleListView);
        } else {
          b b = new b(this, this.a, (Cursor)a, false, recycleListView, param1AlertController);
        } 
      } else {
        int i;
        if (this.H) {
          i = param1AlertController.N;
        } else {
          i = param1AlertController.O;
        } 
        Cursor cursor = this.K;
        if (cursor != null) {
          SimpleCursorAdapter simpleCursorAdapter = new SimpleCursorAdapter(this.a, i, cursor, new String[] { this.L }, new int[] { 16908308 });
        } else if (this.w != null) {
          ListAdapter listAdapter = this.w;
        } else {
          h = new AlertController.h(this.a, i, 16908308, this.v);
        } 
      } 
      e e1 = this.O;
      if (e1 != null)
        e1.a(recycleListView); 
      param1AlertController.H = (ListAdapter)h;
      param1AlertController.I = this.I;
      if (this.x != null) {
        recycleListView.setOnItemClickListener(new c(this, param1AlertController));
      } else if (this.J != null) {
        recycleListView.setOnItemClickListener(new d(this, recycleListView, param1AlertController));
      } 
      AdapterView.OnItemSelectedListener onItemSelectedListener = this.N;
      if (onItemSelectedListener != null)
        recycleListView.setOnItemSelectedListener(onItemSelectedListener); 
      if (this.H) {
        recycleListView.setChoiceMode(1);
      } else if (this.G) {
        recycleListView.setChoiceMode(2);
      } 
      param1AlertController.g = recycleListView;
    }
    
    public void a(AlertController param1AlertController) {
      View view2 = this.g;
      if (view2 != null) {
        param1AlertController.a(view2);
      } else {
        CharSequence charSequence1 = this.f;
        if (charSequence1 != null)
          param1AlertController.b(charSequence1); 
        Drawable drawable = this.d;
        if (drawable != null)
          param1AlertController.a(drawable); 
        int i = this.c;
        if (i != 0)
          param1AlertController.b(i); 
        i = this.e;
        if (i != 0)
          param1AlertController.b(param1AlertController.a(i)); 
      } 
      CharSequence charSequence = this.h;
      if (charSequence != null)
        param1AlertController.a(charSequence); 
      if (this.i != null || this.j != null)
        param1AlertController.a(-1, this.i, this.k, (Message)null, this.j); 
      if (this.l != null || this.m != null)
        param1AlertController.a(-2, this.l, this.n, (Message)null, this.m); 
      if (this.o != null || this.p != null)
        param1AlertController.a(-3, this.o, this.q, (Message)null, this.p); 
      if (this.v != null || this.K != null || this.w != null)
        b(param1AlertController); 
      View view1 = this.z;
      if (view1 != null) {
        if (this.E) {
          param1AlertController.a(view1, this.A, this.B, this.C, this.D);
        } else {
          param1AlertController.b(view1);
        } 
      } else {
        int i = this.y;
        if (i != 0)
          param1AlertController.c(i); 
      } 
    }
    
    class a extends ArrayAdapter<CharSequence> {
      final AlertController.RecycleListView c;
      
      final AlertController.f d;
      
      a(AlertController.f this$0, Context param2Context, int param2Int1, int param2Int2, CharSequence[] param2ArrayOfCharSequence, AlertController.RecycleListView param2RecycleListView) {
        super(param2Context, param2Int1, param2Int2, (Object[])param2ArrayOfCharSequence);
      }
      
      public View getView(int param2Int, View param2View, ViewGroup param2ViewGroup) {
        View view = super.getView(param2Int, param2View, param2ViewGroup);
        boolean[] arrayOfBoolean = this.d.F;
        if (arrayOfBoolean != null && arrayOfBoolean[param2Int])
          this.c.setItemChecked(param2Int, true); 
        return view;
      }
    }
    
    class b extends CursorAdapter {
      private final int c;
      
      private final int d;
      
      final AlertController.RecycleListView e;
      
      final AlertController f;
      
      final AlertController.f g;
      
      b(AlertController.f this$0, Context param2Context, Cursor param2Cursor, boolean param2Boolean, AlertController.RecycleListView param2RecycleListView, AlertController param2AlertController) {
        super(param2Context, param2Cursor, param2Boolean);
        Cursor cursor = getCursor();
        this.c = cursor.getColumnIndexOrThrow(this.g.L);
        this.d = cursor.getColumnIndexOrThrow(this.g.M);
      }
      
      public void bindView(View param2View, Context param2Context, Cursor param2Cursor) {
        ((CheckedTextView)param2View.findViewById(16908308)).setText(param2Cursor.getString(this.c));
        AlertController.RecycleListView recycleListView = this.e;
        int i = param2Cursor.getPosition();
        int j = param2Cursor.getInt(this.d);
        boolean bool = true;
        if (j != 1)
          bool = false; 
        recycleListView.setItemChecked(i, bool);
      }
      
      public View newView(Context param2Context, Cursor param2Cursor, ViewGroup param2ViewGroup) {
        return this.g.b.inflate(this.f.M, param2ViewGroup, false);
      }
    }
    
    class c implements AdapterView.OnItemClickListener {
      final AlertController c;
      
      final AlertController.f d;
      
      c(AlertController.f this$0, AlertController param2AlertController) {}
      
      public void onItemClick(AdapterView<?> param2AdapterView, View param2View, int param2Int, long param2Long) {
        this.d.x.onClick((DialogInterface)this.c.b, param2Int);
        if (!this.d.H)
          this.c.b.dismiss(); 
      }
    }
    
    class d implements AdapterView.OnItemClickListener {
      final AlertController.RecycleListView c;
      
      final AlertController d;
      
      final AlertController.f e;
      
      d(AlertController.f this$0, AlertController.RecycleListView param2RecycleListView, AlertController param2AlertController) {}
      
      public void onItemClick(AdapterView<?> param2AdapterView, View param2View, int param2Int, long param2Long) {
        boolean[] arrayOfBoolean = this.e.F;
        if (arrayOfBoolean != null)
          arrayOfBoolean[param2Int] = this.c.isItemChecked(param2Int); 
        this.e.J.onClick((DialogInterface)this.d.b, param2Int, this.c.isItemChecked(param2Int));
      }
    }
    
    public static interface e {
      void a(ListView param2ListView);
    }
  }
  
  class a extends ArrayAdapter<CharSequence> {
    final AlertController.RecycleListView c;
    
    final AlertController.f d;
    
    a(AlertController this$0, Context param1Context, int param1Int1, int param1Int2, CharSequence[] param1ArrayOfCharSequence, AlertController.RecycleListView param1RecycleListView) {
      super(param1Context, param1Int1, param1Int2, (Object[])param1ArrayOfCharSequence);
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      View view = super.getView(param1Int, param1View, param1ViewGroup);
      boolean[] arrayOfBoolean = this.d.F;
      if (arrayOfBoolean != null && arrayOfBoolean[param1Int])
        this.c.setItemChecked(param1Int, true); 
      return view;
    }
  }
  
  class b extends CursorAdapter {
    private final int c;
    
    private final int d;
    
    final AlertController.RecycleListView e;
    
    final AlertController f;
    
    final AlertController.f g;
    
    b(AlertController this$0, Context param1Context, Cursor param1Cursor, boolean param1Boolean, AlertController.RecycleListView param1RecycleListView, AlertController param1AlertController) {
      super(param1Context, param1Cursor, param1Boolean);
      Cursor cursor = getCursor();
      this.c = cursor.getColumnIndexOrThrow(this.g.L);
      this.d = cursor.getColumnIndexOrThrow(this.g.M);
    }
    
    public void bindView(View param1View, Context param1Context, Cursor param1Cursor) {
      ((CheckedTextView)param1View.findViewById(16908308)).setText(param1Cursor.getString(this.c));
      AlertController.RecycleListView recycleListView = this.e;
      int i = param1Cursor.getPosition();
      int j = param1Cursor.getInt(this.d);
      boolean bool = true;
      if (j != 1)
        bool = false; 
      recycleListView.setItemChecked(i, bool);
    }
    
    public View newView(Context param1Context, Cursor param1Cursor, ViewGroup param1ViewGroup) {
      return this.g.b.inflate(this.f.M, param1ViewGroup, false);
    }
  }
  
  class c implements AdapterView.OnItemClickListener {
    final AlertController c;
    
    final AlertController.f d;
    
    c(AlertController this$0, AlertController param1AlertController) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.d.x.onClick((DialogInterface)this.c.b, param1Int);
      if (!this.d.H)
        this.c.b.dismiss(); 
    }
  }
  
  class d implements AdapterView.OnItemClickListener {
    final AlertController.RecycleListView c;
    
    final AlertController d;
    
    final AlertController.f e;
    
    d(AlertController this$0, AlertController.RecycleListView param1RecycleListView, AlertController param1AlertController) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      boolean[] arrayOfBoolean = this.e.F;
      if (arrayOfBoolean != null)
        arrayOfBoolean[param1Int] = this.c.isItemChecked(param1Int); 
      this.e.J.onClick((DialogInterface)this.d.b, param1Int, this.c.isItemChecked(param1Int));
    }
  }
  
  public static interface e {
    void a(ListView param1ListView);
  }
  
  private static final class g extends Handler {
    private WeakReference<DialogInterface> a;
    
    public g(DialogInterface param1DialogInterface) {
      this.a = new WeakReference<DialogInterface>(param1DialogInterface);
    }
    
    public void handleMessage(Message param1Message) {
      int i = param1Message.what;
      if (i != -3 && i != -2 && i != -1) {
        if (i == 1)
          ((DialogInterface)param1Message.obj).dismiss(); 
      } else {
        ((DialogInterface.OnClickListener)param1Message.obj).onClick(this.a.get(), param1Message.what);
      } 
    }
  }
  
  private static class h extends ArrayAdapter<CharSequence> {
    public h(Context param1Context, int param1Int1, int param1Int2, CharSequence[] param1ArrayOfCharSequence) {
      super(param1Context, param1Int1, param1Int2, (Object[])param1ArrayOfCharSequence);
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public boolean hasStableIds() {
      return true;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\app\AlertController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */