package android.support.v7.app;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ListAdapter;

public class d extends i implements DialogInterface {
  final AlertController e = new AlertController(getContext(), this, getWindow());
  
  protected d(Context paramContext, int paramInt) {
    super(paramContext, a(paramContext, paramInt));
  }
  
  static int a(Context paramContext, int paramInt) {
    if ((paramInt >>> 24 & 0xFF) >= 1)
      return paramInt; 
    TypedValue typedValue = new TypedValue();
    paramContext.getTheme().resolveAttribute(a.b.h.a.a.alertDialogTheme, typedValue, true);
    return typedValue.resourceId;
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.e.a();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    return this.e.a(paramInt, paramKeyEvent) ? true : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    return this.e.b(paramInt, paramKeyEvent) ? true : super.onKeyUp(paramInt, paramKeyEvent);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    super.setTitle(paramCharSequence);
    this.e.b(paramCharSequence);
  }
  
  public static class a {
    private final AlertController.f a;
    
    private final int b;
    
    public a(Context param1Context) {
      this(param1Context, d.a(param1Context, 0));
    }
    
    public a(Context param1Context, int param1Int) {
      this.a = new AlertController.f((Context)new ContextThemeWrapper(param1Context, d.a(param1Context, param1Int)));
      this.b = param1Int;
    }
    
    public a a(DialogInterface.OnKeyListener param1OnKeyListener) {
      this.a.u = param1OnKeyListener;
      return this;
    }
    
    public a a(Drawable param1Drawable) {
      this.a.d = param1Drawable;
      return this;
    }
    
    public a a(View param1View) {
      this.a.g = param1View;
      return this;
    }
    
    public a a(ListAdapter param1ListAdapter, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.f f1 = this.a;
      f1.w = param1ListAdapter;
      f1.x = param1OnClickListener;
      return this;
    }
    
    public a a(CharSequence param1CharSequence) {
      this.a.f = param1CharSequence;
      return this;
    }
    
    public d a() {
      d d = new d(this.a.a, this.b);
      this.a.a(d.e);
      d.setCancelable(this.a.r);
      if (this.a.r)
        d.setCanceledOnTouchOutside(true); 
      d.setOnCancelListener(this.a.s);
      d.setOnDismissListener(this.a.t);
      DialogInterface.OnKeyListener onKeyListener = this.a.u;
      if (onKeyListener != null)
        d.setOnKeyListener(onKeyListener); 
      return d;
    }
    
    public Context b() {
      return this.a.a;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\app\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */