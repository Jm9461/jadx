package android.support.v7.app;

import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.v;
import android.support.v4.view.a0;
import android.support.v4.view.c0;
import android.support.v4.view.p;
import android.support.v4.view.u;
import android.support.v4.view.y;
import android.support.v4.view.z;
import android.support.v7.view.menu.h;
import android.support.v7.view.menu.p;
import android.support.v7.view.menu.q;
import android.support.v7.widget.ActionBarContextView;
import android.support.v7.widget.ContentFrameLayout;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.ViewStubCompat;
import android.support.v7.widget.e0;
import android.support.v7.widget.j1;
import android.support.v7.widget.k0;
import android.support.v7.widget.o1;
import android.support.v7.widget.r1;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;

class h extends g implements h.a, LayoutInflater.Factory2 {
  private static final boolean U;
  
  private static final int[] V = new int[] { 16842836 };
  
  private static boolean W;
  
  boolean A;
  
  boolean B;
  
  boolean C;
  
  boolean D;
  
  boolean E;
  
  private boolean F;
  
  private n[] G;
  
  private n H;
  
  private boolean I;
  
  boolean J;
  
  private int K = -100;
  
  private boolean L;
  
  private l M;
  
  boolean N;
  
  int O;
  
  private final Runnable P = new b(this);
  
  private boolean Q;
  
  private Rect R;
  
  private Rect S;
  
  private AppCompatViewInflater T;
  
  final Context d;
  
  final Window e;
  
  final Window.Callback f;
  
  final Window.Callback g;
  
  final f h;
  
  a i;
  
  MenuInflater j;
  
  private CharSequence k;
  
  private e0 l;
  
  private i m;
  
  private o n;
  
  a.b.h.f.b o;
  
  ActionBarContextView p;
  
  PopupWindow q;
  
  Runnable r;
  
  y s = null;
  
  private boolean t = true;
  
  private boolean u;
  
  private ViewGroup v;
  
  private TextView w;
  
  private View x;
  
  private boolean y;
  
  private boolean z;
  
  static {
    if (U && !W) {
      Thread.setDefaultUncaughtExceptionHandler(new a(Thread.getDefaultUncaughtExceptionHandler()));
      W = true;
    } 
  }
  
  h(Context paramContext, Window paramWindow, f paramf) {
    this.d = paramContext;
    this.e = paramWindow;
    this.h = paramf;
    this.f = this.e.getCallback();
    Window.Callback callback = this.f;
    if (!(callback instanceof k)) {
      this.g = (Window.Callback)new k(this, callback);
      this.e.setCallback(this.g);
      j1 j1 = j1.a(paramContext, null, V);
      Drawable drawable = j1.c(0);
      if (drawable != null)
        this.e.setBackgroundDrawable(drawable); 
      j1.a();
      return;
    } 
    throw new IllegalStateException("AppCompat has already installed itself into the Window");
  }
  
  private boolean A() {
    boolean bool1 = this.L;
    boolean bool = false;
    if (bool1) {
      Context context = this.d;
      if (context instanceof Activity) {
        PackageManager packageManager = context.getPackageManager();
        try {
          ComponentName componentName = new ComponentName();
          this(this.d, this.d.getClass());
          int j = (packageManager.getActivityInfo(componentName, 0)).configChanges;
          if ((j & 0x200) == 0)
            bool = true; 
          return bool;
        } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
          Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", (Throwable)nameNotFoundException);
          return true;
        } 
      } 
    } 
    return false;
  }
  
  private void B() {
    if (!this.u)
      return; 
    throw new AndroidRuntimeException("Window feature must be requested before adding content");
  }
  
  private void a(n paramn, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_1
    //   1: getfield o : Z
    //   4: ifne -> 427
    //   7: aload_0
    //   8: getfield J : Z
    //   11: ifeq -> 17
    //   14: goto -> 427
    //   17: aload_1
    //   18: getfield a : I
    //   21: ifne -> 56
    //   24: aload_0
    //   25: getfield d : Landroid/content/Context;
    //   28: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   31: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   34: getfield screenLayout : I
    //   37: bipush #15
    //   39: iand
    //   40: iconst_4
    //   41: if_icmpne -> 49
    //   44: iconst_1
    //   45: istore_3
    //   46: goto -> 51
    //   49: iconst_0
    //   50: istore_3
    //   51: iload_3
    //   52: ifeq -> 56
    //   55: return
    //   56: aload_0
    //   57: invokevirtual p : ()Landroid/view/Window$Callback;
    //   60: astore #5
    //   62: aload #5
    //   64: ifnull -> 92
    //   67: aload #5
    //   69: aload_1
    //   70: getfield a : I
    //   73: aload_1
    //   74: getfield j : Landroid/support/v7/view/menu/h;
    //   77: invokeinterface onMenuOpened : (ILandroid/view/Menu;)Z
    //   82: ifne -> 92
    //   85: aload_0
    //   86: aload_1
    //   87: iconst_1
    //   88: invokevirtual a : (Landroid/support/v7/app/h$n;Z)V
    //   91: return
    //   92: aload_0
    //   93: getfield d : Landroid/content/Context;
    //   96: ldc_w 'window'
    //   99: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   102: checkcast android/view/WindowManager
    //   105: astore #6
    //   107: aload #6
    //   109: ifnonnull -> 113
    //   112: return
    //   113: aload_0
    //   114: aload_1
    //   115: aload_2
    //   116: invokespecial b : (Landroid/support/v7/app/h$n;Landroid/view/KeyEvent;)Z
    //   119: ifne -> 123
    //   122: return
    //   123: bipush #-2
    //   125: istore #4
    //   127: aload_1
    //   128: getfield g : Landroid/view/ViewGroup;
    //   131: ifnull -> 187
    //   134: aload_1
    //   135: getfield q : Z
    //   138: ifeq -> 144
    //   141: goto -> 187
    //   144: aload_1
    //   145: getfield i : Landroid/view/View;
    //   148: astore_2
    //   149: aload_2
    //   150: ifnull -> 181
    //   153: aload_2
    //   154: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   157: astore_2
    //   158: iload #4
    //   160: istore_3
    //   161: aload_2
    //   162: ifnull -> 360
    //   165: iload #4
    //   167: istore_3
    //   168: aload_2
    //   169: getfield width : I
    //   172: iconst_m1
    //   173: if_icmpne -> 360
    //   176: iconst_m1
    //   177: istore_3
    //   178: goto -> 360
    //   181: iload #4
    //   183: istore_3
    //   184: goto -> 360
    //   187: aload_1
    //   188: getfield g : Landroid/view/ViewGroup;
    //   191: astore_2
    //   192: aload_2
    //   193: ifnonnull -> 212
    //   196: aload_0
    //   197: aload_1
    //   198: invokespecial b : (Landroid/support/v7/app/h$n;)Z
    //   201: ifeq -> 211
    //   204: aload_1
    //   205: getfield g : Landroid/view/ViewGroup;
    //   208: ifnonnull -> 233
    //   211: return
    //   212: aload_1
    //   213: getfield q : Z
    //   216: ifeq -> 233
    //   219: aload_2
    //   220: invokevirtual getChildCount : ()I
    //   223: ifle -> 233
    //   226: aload_1
    //   227: getfield g : Landroid/view/ViewGroup;
    //   230: invokevirtual removeAllViews : ()V
    //   233: aload_0
    //   234: aload_1
    //   235: invokespecial a : (Landroid/support/v7/app/h$n;)Z
    //   238: ifeq -> 426
    //   241: aload_1
    //   242: invokevirtual a : ()Z
    //   245: ifne -> 251
    //   248: goto -> 426
    //   251: aload_1
    //   252: getfield h : Landroid/view/View;
    //   255: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   258: astore #5
    //   260: aload #5
    //   262: astore_2
    //   263: aload #5
    //   265: ifnonnull -> 280
    //   268: new android/view/ViewGroup$LayoutParams
    //   271: dup
    //   272: bipush #-2
    //   274: bipush #-2
    //   276: invokespecial <init> : (II)V
    //   279: astore_2
    //   280: aload_1
    //   281: getfield b : I
    //   284: istore_3
    //   285: aload_1
    //   286: getfield g : Landroid/view/ViewGroup;
    //   289: iload_3
    //   290: invokevirtual setBackgroundResource : (I)V
    //   293: aload_1
    //   294: getfield h : Landroid/view/View;
    //   297: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   300: astore #5
    //   302: aload #5
    //   304: ifnull -> 327
    //   307: aload #5
    //   309: instanceof android/view/ViewGroup
    //   312: ifeq -> 327
    //   315: aload #5
    //   317: checkcast android/view/ViewGroup
    //   320: aload_1
    //   321: getfield h : Landroid/view/View;
    //   324: invokevirtual removeView : (Landroid/view/View;)V
    //   327: aload_1
    //   328: getfield g : Landroid/view/ViewGroup;
    //   331: aload_1
    //   332: getfield h : Landroid/view/View;
    //   335: aload_2
    //   336: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   339: aload_1
    //   340: getfield h : Landroid/view/View;
    //   343: invokevirtual hasFocus : ()Z
    //   346: ifne -> 181
    //   349: aload_1
    //   350: getfield h : Landroid/view/View;
    //   353: invokevirtual requestFocus : ()Z
    //   356: pop
    //   357: goto -> 181
    //   360: aload_1
    //   361: iconst_0
    //   362: putfield n : Z
    //   365: new android/view/WindowManager$LayoutParams
    //   368: dup
    //   369: iload_3
    //   370: bipush #-2
    //   372: aload_1
    //   373: getfield d : I
    //   376: aload_1
    //   377: getfield e : I
    //   380: sipush #1002
    //   383: ldc_w 8519680
    //   386: bipush #-3
    //   388: invokespecial <init> : (IIIIIII)V
    //   391: astore_2
    //   392: aload_2
    //   393: aload_1
    //   394: getfield c : I
    //   397: putfield gravity : I
    //   400: aload_2
    //   401: aload_1
    //   402: getfield f : I
    //   405: putfield windowAnimations : I
    //   408: aload #6
    //   410: aload_1
    //   411: getfield g : Landroid/view/ViewGroup;
    //   414: aload_2
    //   415: invokeinterface addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   420: aload_1
    //   421: iconst_1
    //   422: putfield o : Z
    //   425: return
    //   426: return
    //   427: return
  }
  
  private void a(h paramh, boolean paramBoolean) {
    e0 e01 = this.l;
    if (e01 != null && e01.f() && (!ViewConfiguration.get(this.d).hasPermanentMenuKey() || this.l.a())) {
      Window.Callback callback = p();
      if (!this.l.b() || !paramBoolean) {
        if (callback != null && !this.J) {
          if (this.N && (this.O & 0x1) != 0) {
            this.e.getDecorView().removeCallbacks(this.P);
            this.P.run();
          } 
          n n2 = a(0, true);
          h h1 = n2.j;
          if (h1 != null && !n2.r && callback.onPreparePanel(0, n2.i, (Menu)h1)) {
            callback.onMenuOpened(108, (Menu)n2.j);
            this.l.d();
          } 
        } 
        return;
      } 
      this.l.c();
      if (!this.J)
        callback.onPanelClosed(108, (Menu)(a(0, true)).j); 
      return;
    } 
    n n1 = a(0, true);
    n1.q = true;
    a(n1, false);
    a(n1, (KeyEvent)null);
  }
  
  private boolean a(n paramn) {
    View view = paramn.i;
    boolean bool = true;
    if (view != null) {
      paramn.h = view;
      return true;
    } 
    if (paramn.j == null)
      return false; 
    if (this.n == null)
      this.n = new o(this); 
    paramn.h = (View)paramn.a(this.n);
    if (paramn.h == null)
      bool = false; 
    return bool;
  }
  
  private boolean a(n paramn, int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    // Byte code:
    //   0: aload_3
    //   1: invokevirtual isSystem : ()Z
    //   4: ifeq -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: iconst_0
    //   10: istore #6
    //   12: aload_1
    //   13: getfield m : Z
    //   16: ifne -> 32
    //   19: iload #6
    //   21: istore #5
    //   23: aload_0
    //   24: aload_1
    //   25: aload_3
    //   26: invokespecial b : (Landroid/support/v7/app/h$n;Landroid/view/KeyEvent;)Z
    //   29: ifeq -> 58
    //   32: aload_1
    //   33: getfield j : Landroid/support/v7/view/menu/h;
    //   36: astore #7
    //   38: iload #6
    //   40: istore #5
    //   42: aload #7
    //   44: ifnull -> 58
    //   47: aload #7
    //   49: iload_2
    //   50: aload_3
    //   51: iload #4
    //   53: invokevirtual performShortcut : (ILandroid/view/KeyEvent;I)Z
    //   56: istore #5
    //   58: iload #5
    //   60: ifeq -> 83
    //   63: iload #4
    //   65: iconst_1
    //   66: iand
    //   67: ifne -> 83
    //   70: aload_0
    //   71: getfield l : Landroid/support/v7/widget/e0;
    //   74: ifnonnull -> 83
    //   77: aload_0
    //   78: aload_1
    //   79: iconst_1
    //   80: invokevirtual a : (Landroid/support/v7/app/h$n;Z)V
    //   83: iload #5
    //   85: ireturn
  }
  
  private boolean a(ViewParent paramViewParent) {
    if (paramViewParent == null)
      return false; 
    View view = this.e.getDecorView();
    while (true) {
      if (paramViewParent == null)
        return true; 
      if (paramViewParent == view || !(paramViewParent instanceof View) || u.x((View)paramViewParent))
        break; 
      paramViewParent = paramViewParent.getParent();
    } 
    return false;
  }
  
  private boolean b(n paramn) {
    paramn.a(n());
    paramn.g = (ViewGroup)new m(this, paramn.l);
    paramn.c = 81;
    return true;
  }
  
  private boolean b(n paramn, KeyEvent paramKeyEvent) {
    e0 e01;
    if (this.J)
      return false; 
    if (paramn.m)
      return true; 
    n n1 = this.H;
    if (n1 != null && n1 != paramn)
      a(n1, false); 
    Window.Callback callback = p();
    if (callback != null)
      paramn.i = callback.onCreatePanelView(paramn.a); 
    int j = paramn.a;
    if (j == 0 || j == 108) {
      j = 1;
    } else {
      j = 0;
    } 
    if (j != 0) {
      e0 e02 = this.l;
      if (e02 != null)
        e02.e(); 
    } 
    if (paramn.i == null && (j == 0 || !(s() instanceof k))) {
      e0 e02;
      boolean bool;
      if (paramn.j == null || paramn.r) {
        if (paramn.j == null && (!c(paramn) || paramn.j == null))
          return false; 
        if (j != 0 && this.l != null) {
          if (this.m == null)
            this.m = new i(this); 
          this.l.a((Menu)paramn.j, this.m);
        } 
        paramn.j.s();
        if (!callback.onCreatePanelMenu(paramn.a, (Menu)paramn.j)) {
          paramn.a((h)null);
          if (j != 0) {
            e01 = this.l;
            if (e01 != null)
              e01.a(null, this.m); 
          } 
          return false;
        } 
        ((n)e01).r = false;
      } 
      ((n)e01).j.s();
      Bundle bundle = ((n)e01).s;
      if (bundle != null) {
        ((n)e01).j.a(bundle);
        ((n)e01).s = null;
      } 
      if (!callback.onPreparePanel(0, ((n)e01).i, (Menu)((n)e01).j)) {
        if (j != 0) {
          e02 = this.l;
          if (e02 != null)
            e02.a(null, this.m); 
        } 
        ((n)e01).j.r();
        return false;
      } 
      if (e02 != null) {
        j = e02.getDeviceId();
      } else {
        j = -1;
      } 
      if (KeyCharacterMap.load(j).getKeyboardType() != 1) {
        bool = true;
      } else {
        bool = false;
      } 
      ((n)e01).p = bool;
      ((n)e01).j.setQwertyMode(((n)e01).p);
      ((n)e01).j.r();
    } 
    ((n)e01).m = true;
    ((n)e01).n = false;
    this.H = (n)e01;
    return true;
  }
  
  private boolean c(n paramn) {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : Landroid/content/Context;
    //   4: astore #5
    //   6: aload_1
    //   7: getfield a : I
    //   10: istore_2
    //   11: iload_2
    //   12: ifeq -> 24
    //   15: aload #5
    //   17: astore_3
    //   18: iload_2
    //   19: bipush #108
    //   21: if_icmpne -> 197
    //   24: aload #5
    //   26: astore_3
    //   27: aload_0
    //   28: getfield l : Landroid/support/v7/widget/e0;
    //   31: ifnull -> 197
    //   34: new android/util/TypedValue
    //   37: dup
    //   38: invokespecial <init> : ()V
    //   41: astore #7
    //   43: aload #5
    //   45: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   48: astore #6
    //   50: aload #6
    //   52: getstatic a/b/h/a/a.actionBarTheme : I
    //   55: aload #7
    //   57: iconst_1
    //   58: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   61: pop
    //   62: aconst_null
    //   63: astore_3
    //   64: aload #7
    //   66: getfield resourceId : I
    //   69: ifeq -> 111
    //   72: aload #5
    //   74: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   77: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   80: astore_3
    //   81: aload_3
    //   82: aload #6
    //   84: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   87: aload_3
    //   88: aload #7
    //   90: getfield resourceId : I
    //   93: iconst_1
    //   94: invokevirtual applyStyle : (IZ)V
    //   97: aload_3
    //   98: getstatic a/b/h/a/a.actionBarWidgetTheme : I
    //   101: aload #7
    //   103: iconst_1
    //   104: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   107: pop
    //   108: goto -> 123
    //   111: aload #6
    //   113: getstatic a/b/h/a/a.actionBarWidgetTheme : I
    //   116: aload #7
    //   118: iconst_1
    //   119: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   122: pop
    //   123: aload_3
    //   124: astore #4
    //   126: aload #7
    //   128: getfield resourceId : I
    //   131: ifeq -> 169
    //   134: aload_3
    //   135: astore #4
    //   137: aload_3
    //   138: ifnonnull -> 158
    //   141: aload #5
    //   143: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   146: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   149: astore #4
    //   151: aload #4
    //   153: aload #6
    //   155: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   158: aload #4
    //   160: aload #7
    //   162: getfield resourceId : I
    //   165: iconst_1
    //   166: invokevirtual applyStyle : (IZ)V
    //   169: aload #5
    //   171: astore_3
    //   172: aload #4
    //   174: ifnull -> 197
    //   177: new a/b/h/f/d
    //   180: dup
    //   181: aload #5
    //   183: iconst_0
    //   184: invokespecial <init> : (Landroid/content/Context;I)V
    //   187: astore_3
    //   188: aload_3
    //   189: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   192: aload #4
    //   194: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   197: new android/support/v7/view/menu/h
    //   200: dup
    //   201: aload_3
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: astore_3
    //   206: aload_3
    //   207: aload_0
    //   208: invokevirtual a : (Landroid/support/v7/view/menu/h$a;)V
    //   211: aload_1
    //   212: aload_3
    //   213: invokevirtual a : (Landroid/support/v7/view/menu/h;)V
    //   216: iconst_1
    //   217: ireturn
  }
  
  private boolean d(int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getRepeatCount() == 0) {
      n n1 = a(paramInt, true);
      if (!n1.o)
        return b(n1, paramKeyEvent); 
    } 
    return false;
  }
  
  private boolean e(int paramInt, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield o : La/b/h/f/b;
    //   4: ifnull -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: iconst_0
    //   10: istore #5
    //   12: aload_0
    //   13: iload_1
    //   14: iconst_1
    //   15: invokevirtual a : (IZ)Landroid/support/v7/app/h$n;
    //   18: astore #6
    //   20: iload_1
    //   21: ifne -> 119
    //   24: aload_0
    //   25: getfield l : Landroid/support/v7/widget/e0;
    //   28: astore #7
    //   30: aload #7
    //   32: ifnull -> 119
    //   35: aload #7
    //   37: invokeinterface f : ()Z
    //   42: ifeq -> 119
    //   45: aload_0
    //   46: getfield d : Landroid/content/Context;
    //   49: invokestatic get : (Landroid/content/Context;)Landroid/view/ViewConfiguration;
    //   52: invokevirtual hasPermanentMenuKey : ()Z
    //   55: ifne -> 119
    //   58: aload_0
    //   59: getfield l : Landroid/support/v7/widget/e0;
    //   62: invokeinterface b : ()Z
    //   67: ifne -> 106
    //   70: iload #5
    //   72: istore_3
    //   73: aload_0
    //   74: getfield J : Z
    //   77: ifne -> 208
    //   80: iload #5
    //   82: istore_3
    //   83: aload_0
    //   84: aload #6
    //   86: aload_2
    //   87: invokespecial b : (Landroid/support/v7/app/h$n;Landroid/view/KeyEvent;)Z
    //   90: ifeq -> 208
    //   93: aload_0
    //   94: getfield l : Landroid/support/v7/widget/e0;
    //   97: invokeinterface d : ()Z
    //   102: istore_3
    //   103: goto -> 208
    //   106: aload_0
    //   107: getfield l : Landroid/support/v7/widget/e0;
    //   110: invokeinterface c : ()Z
    //   115: istore_3
    //   116: goto -> 208
    //   119: aload #6
    //   121: getfield o : Z
    //   124: ifne -> 195
    //   127: aload #6
    //   129: getfield n : Z
    //   132: ifeq -> 138
    //   135: goto -> 195
    //   138: iload #5
    //   140: istore_3
    //   141: aload #6
    //   143: getfield m : Z
    //   146: ifeq -> 208
    //   149: iconst_1
    //   150: istore #4
    //   152: aload #6
    //   154: getfield r : Z
    //   157: ifeq -> 175
    //   160: aload #6
    //   162: iconst_0
    //   163: putfield m : Z
    //   166: aload_0
    //   167: aload #6
    //   169: aload_2
    //   170: invokespecial b : (Landroid/support/v7/app/h$n;Landroid/view/KeyEvent;)Z
    //   173: istore #4
    //   175: iload #5
    //   177: istore_3
    //   178: iload #4
    //   180: ifeq -> 208
    //   183: aload_0
    //   184: aload #6
    //   186: aload_2
    //   187: invokespecial a : (Landroid/support/v7/app/h$n;Landroid/view/KeyEvent;)V
    //   190: iconst_1
    //   191: istore_3
    //   192: goto -> 208
    //   195: aload #6
    //   197: getfield o : Z
    //   200: istore_3
    //   201: aload_0
    //   202: aload #6
    //   204: iconst_1
    //   205: invokevirtual a : (Landroid/support/v7/app/h$n;Z)V
    //   208: iload_3
    //   209: ifeq -> 247
    //   212: aload_0
    //   213: getfield d : Landroid/content/Context;
    //   216: ldc_w 'audio'
    //   219: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   222: checkcast android/media/AudioManager
    //   225: astore_2
    //   226: aload_2
    //   227: ifnull -> 238
    //   230: aload_2
    //   231: iconst_0
    //   232: invokevirtual playSoundEffect : (I)V
    //   235: goto -> 247
    //   238: ldc 'AppCompatDelegate'
    //   240: ldc_w 'Couldn't get audio manager'
    //   243: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   246: pop
    //   247: iload_3
    //   248: ireturn
  }
  
  private void j(int paramInt) {
    this.O |= 1 << paramInt;
    if (!this.N) {
      u.a(this.e.getDecorView(), this.P);
      this.N = true;
    } 
  }
  
  private int k(int paramInt) {
    if (paramInt == 8) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
      return 108;
    } 
    if (paramInt == 9) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
      return 109;
    } 
    return paramInt;
  }
  
  private boolean l(int paramInt) {
    Resources resources = this.d.getResources();
    Configuration configuration = resources.getConfiguration();
    int j = configuration.uiMode;
    if (paramInt == 2) {
      paramInt = 32;
    } else {
      paramInt = 16;
    } 
    if ((j & 0x30) != paramInt) {
      if (A()) {
        ((Activity)this.d).recreate();
      } else {
        configuration = new Configuration(configuration);
        DisplayMetrics displayMetrics = resources.getDisplayMetrics();
        configuration.uiMode = configuration.uiMode & 0xFFFFFFCF | paramInt;
        resources.updateConfiguration(configuration, displayMetrics);
        if (Build.VERSION.SDK_INT < 26)
          j.a(resources); 
      } 
      return true;
    } 
    return false;
  }
  
  private void u() {
    ContentFrameLayout contentFrameLayout = (ContentFrameLayout)this.v.findViewById(16908290);
    View view = this.e.getDecorView();
    contentFrameLayout.a(view.getPaddingLeft(), view.getPaddingTop(), view.getPaddingRight(), view.getPaddingBottom());
    TypedArray typedArray = this.d.obtainStyledAttributes(a.b.h.a.j.AppCompatTheme);
    typedArray.getValue(a.b.h.a.j.AppCompatTheme_windowMinWidthMajor, contentFrameLayout.getMinWidthMajor());
    typedArray.getValue(a.b.h.a.j.AppCompatTheme_windowMinWidthMinor, contentFrameLayout.getMinWidthMinor());
    if (typedArray.hasValue(a.b.h.a.j.AppCompatTheme_windowFixedWidthMajor))
      typedArray.getValue(a.b.h.a.j.AppCompatTheme_windowFixedWidthMajor, contentFrameLayout.getFixedWidthMajor()); 
    if (typedArray.hasValue(a.b.h.a.j.AppCompatTheme_windowFixedWidthMinor))
      typedArray.getValue(a.b.h.a.j.AppCompatTheme_windowFixedWidthMinor, contentFrameLayout.getFixedWidthMinor()); 
    if (typedArray.hasValue(a.b.h.a.j.AppCompatTheme_windowFixedHeightMajor))
      typedArray.getValue(a.b.h.a.j.AppCompatTheme_windowFixedHeightMajor, contentFrameLayout.getFixedHeightMajor()); 
    if (typedArray.hasValue(a.b.h.a.j.AppCompatTheme_windowFixedHeightMinor))
      typedArray.getValue(a.b.h.a.j.AppCompatTheme_windowFixedHeightMinor, contentFrameLayout.getFixedHeightMinor()); 
    typedArray.recycle();
    contentFrameLayout.requestLayout();
  }
  
  private ViewGroup v() {
    StringBuilder stringBuilder;
    TypedArray typedArray = this.d.obtainStyledAttributes(a.b.h.a.j.AppCompatTheme);
    if (typedArray.hasValue(a.b.h.a.j.AppCompatTheme_windowActionBar)) {
      ViewGroup viewGroup;
      if (typedArray.getBoolean(a.b.h.a.j.AppCompatTheme_windowNoTitle, false)) {
        b(1);
      } else if (typedArray.getBoolean(a.b.h.a.j.AppCompatTheme_windowActionBar, false)) {
        b(108);
      } 
      if (typedArray.getBoolean(a.b.h.a.j.AppCompatTheme_windowActionBarOverlay, false))
        b(109); 
      if (typedArray.getBoolean(a.b.h.a.j.AppCompatTheme_windowActionModeOverlay, false))
        b(10); 
      this.D = typedArray.getBoolean(a.b.h.a.j.AppCompatTheme_android_windowIsFloating, false);
      typedArray.recycle();
      this.e.getDecorView();
      LayoutInflater layoutInflater = LayoutInflater.from(this.d);
      typedArray = null;
      if (!this.E) {
        if (this.D) {
          viewGroup = (ViewGroup)layoutInflater.inflate(a.b.h.a.g.abc_dialog_title_material, null);
          this.B = false;
          this.A = false;
        } else if (this.A) {
          Context context;
          TypedValue typedValue = new TypedValue();
          this.d.getTheme().resolveAttribute(a.b.h.a.a.actionBarTheme, typedValue, true);
          int j = typedValue.resourceId;
          if (j != 0) {
            a.b.h.f.d d = new a.b.h.f.d(this.d, j);
          } else {
            context = this.d;
          } 
          viewGroup = (ViewGroup)LayoutInflater.from(context).inflate(a.b.h.a.g.abc_screen_toolbar, null);
          this.l = (e0)viewGroup.findViewById(a.b.h.a.f.decor_content_parent);
          this.l.setWindowCallback(p());
          if (this.B)
            this.l.a(109); 
          if (this.y)
            this.l.a(2); 
          if (this.z)
            this.l.a(5); 
        } 
      } else {
        if (this.C) {
          viewGroup = (ViewGroup)layoutInflater.inflate(a.b.h.a.g.abc_screen_simple_overlay_action_mode, null);
        } else {
          viewGroup = (ViewGroup)layoutInflater.inflate(a.b.h.a.g.abc_screen_simple, null);
        } 
        if (Build.VERSION.SDK_INT >= 21) {
          u.a((View)viewGroup, new c(this));
        } else {
          ((k0)viewGroup).setOnFitSystemWindowsListener(new d(this));
        } 
      } 
      if (viewGroup != null) {
        if (this.l == null)
          this.w = (TextView)viewGroup.findViewById(a.b.h.a.f.title); 
        r1.b((View)viewGroup);
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout)viewGroup.findViewById(a.b.h.a.f.action_bar_activity_content);
        ViewGroup viewGroup1 = (ViewGroup)this.e.findViewById(16908290);
        if (viewGroup1 != null) {
          while (viewGroup1.getChildCount() > 0) {
            View view = viewGroup1.getChildAt(0);
            viewGroup1.removeViewAt(0);
            contentFrameLayout.addView(view);
          } 
          viewGroup1.setId(-1);
          contentFrameLayout.setId(16908290);
          if (viewGroup1 instanceof FrameLayout)
            ((FrameLayout)viewGroup1).setForeground(null); 
        } 
        this.e.setContentView((View)viewGroup);
        contentFrameLayout.setAttachListener(new e(this));
        return viewGroup;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("AppCompat does not support the current theme features: { windowActionBar: ");
      stringBuilder.append(this.A);
      stringBuilder.append(", windowActionBarOverlay: ");
      stringBuilder.append(this.B);
      stringBuilder.append(", android:windowIsFloating: ");
      stringBuilder.append(this.D);
      stringBuilder.append(", windowActionModeOverlay: ");
      stringBuilder.append(this.C);
      stringBuilder.append(", windowNoTitle: ");
      stringBuilder.append(this.E);
      stringBuilder.append(" }");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    stringBuilder.recycle();
    IllegalStateException illegalStateException = new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
    throw illegalStateException;
  }
  
  private void w() {
    if (this.M == null)
      this.M = new l(this, m.a(this.d)); 
  }
  
  private void x() {
    if (!this.u) {
      this.v = v();
      CharSequence charSequence = o();
      if (!TextUtils.isEmpty(charSequence)) {
        e0 e01 = this.l;
        if (e01 != null) {
          e01.setWindowTitle(charSequence);
        } else if (s() != null) {
          s().b(charSequence);
        } else {
          TextView textView = this.w;
          if (textView != null)
            textView.setText(charSequence); 
        } 
      } 
      u();
      a(this.v);
      this.u = true;
      n n1 = a(0, false);
      if (!this.J && (n1 == null || n1.j == null))
        j(108); 
    } 
  }
  
  private int y() {
    int j = this.K;
    if (j == -100)
      j = g.k(); 
    return j;
  }
  
  private void z() {
    x();
    if (!this.A || this.i != null)
      return; 
    Window.Callback callback = this.f;
    if (callback instanceof Activity) {
      this.i = new n((Activity)callback, this.B);
    } else if (callback instanceof Dialog) {
      this.i = new n((Dialog)callback);
    } 
    a a1 = this.i;
    if (a1 != null)
      a1.c(this.Q); 
  }
  
  public a.b.h.f.b a(a.b.h.f.b.a parama) {
    if (parama != null) {
      a.b.h.f.b b1 = this.o;
      if (b1 != null)
        b1.a(); 
      parama = new j(this, parama);
      a a1 = d();
      if (a1 != null) {
        this.o = a1.a(parama);
        a.b.h.f.b b2 = this.o;
        if (b2 != null) {
          f f1 = this.h;
          if (f1 != null)
            f1.b(b2); 
        } 
      } 
      if (this.o == null)
        this.o = b(parama); 
      return this.o;
    } 
    throw new IllegalArgumentException("ActionMode callback can not be null.");
  }
  
  protected n a(int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield G : [Landroid/support/v7/app/h$n;
    //   4: astore_3
    //   5: aload_3
    //   6: astore #4
    //   8: aload_3
    //   9: ifnull -> 22
    //   12: aload #4
    //   14: astore_3
    //   15: aload #4
    //   17: arraylength
    //   18: iload_1
    //   19: if_icmpgt -> 56
    //   22: iload_1
    //   23: iconst_1
    //   24: iadd
    //   25: anewarray android/support/v7/app/h$n
    //   28: astore #5
    //   30: aload #4
    //   32: ifnull -> 47
    //   35: aload #4
    //   37: iconst_0
    //   38: aload #5
    //   40: iconst_0
    //   41: aload #4
    //   43: arraylength
    //   44: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   47: aload #5
    //   49: astore_3
    //   50: aload_0
    //   51: aload #5
    //   53: putfield G : [Landroid/support/v7/app/h$n;
    //   56: aload_3
    //   57: iload_1
    //   58: aaload
    //   59: astore #5
    //   61: aload #5
    //   63: astore #4
    //   65: aload #5
    //   67: ifnonnull -> 89
    //   70: new android/support/v7/app/h$n
    //   73: dup
    //   74: iload_1
    //   75: invokespecial <init> : (I)V
    //   78: astore #5
    //   80: aload #5
    //   82: astore #4
    //   84: aload_3
    //   85: iload_1
    //   86: aload #5
    //   88: aastore
    //   89: aload #4
    //   91: areturn
  }
  
  n a(Menu paramMenu) {
    byte b1;
    n[] arrayOfN = this.G;
    if (arrayOfN != null) {
      b1 = arrayOfN.length;
    } else {
      b1 = 0;
    } 
    for (byte b2 = 0; b2 < b1; b2++) {
      n n1 = arrayOfN[b2];
      if (n1 != null && n1.j == paramMenu)
        return n1; 
    } 
    return null;
  }
  
  public <T extends View> T a(int paramInt) {
    x();
    return (T)this.e.findViewById(paramInt);
  }
  
  public View a(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    AppCompatViewInflater appCompatViewInflater = this.T;
    boolean bool2 = false;
    if (appCompatViewInflater == null) {
      String str = this.d.obtainStyledAttributes(a.b.h.a.j.AppCompatTheme).getString(a.b.h.a.j.AppCompatTheme_viewInflaterClass);
      if (str == null || AppCompatViewInflater.class.getName().equals(str)) {
        this.T = new AppCompatViewInflater();
      } else {
        try {
          this.T = Class.forName(str).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } finally {
          appCompatViewInflater = null;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to instantiate custom view inflater ");
          stringBuilder.append(str);
          stringBuilder.append(". Falling back to default.");
          Log.i("AppCompatDelegate", stringBuilder.toString(), (Throwable)appCompatViewInflater);
        } 
      } 
    } 
    boolean bool1 = false;
    if (U)
      if (paramAttributeSet instanceof XmlPullParser) {
        bool1 = bool2;
        if (((XmlPullParser)paramAttributeSet).getDepth() > 1)
          bool1 = true; 
      } else {
        bool1 = a((ViewParent)paramView);
      }  
    return this.T.createView(paramView, paramString, paramContext, paramAttributeSet, bool1, U, true, o1.b());
  }
  
  void a(int paramInt, n paramn, Menu paramMenu) {
    h h1;
    n n1 = paramn;
    Menu menu = paramMenu;
    if (paramMenu == null) {
      n n2 = paramn;
      if (paramn == null) {
        n2 = paramn;
        if (paramInt >= 0) {
          n[] arrayOfN = this.G;
          n2 = paramn;
          if (paramInt < arrayOfN.length)
            n2 = arrayOfN[paramInt]; 
        } 
      } 
      n1 = n2;
      menu = paramMenu;
      if (n2 != null) {
        h1 = n2.j;
        n1 = n2;
      } 
    } 
    if (n1 != null && !n1.o)
      return; 
    if (!this.J)
      this.f.onPanelClosed(paramInt, (Menu)h1); 
  }
  
  public void a(Configuration paramConfiguration) {
    if (this.A && this.u) {
      a a1 = d();
      if (a1 != null)
        a1.a(paramConfiguration); 
    } 
    android.support.v7.widget.j.a().a(this.d);
    a();
  }
  
  public void a(Bundle paramBundle) {
    Window.Callback callback = this.f;
    if (callback instanceof Activity) {
      String str = null;
      try {
        String str1 = v.b((Activity)callback);
        str = str1;
      } catch (IllegalArgumentException illegalArgumentException) {}
      if (str != null) {
        a a1 = s();
        if (a1 == null) {
          this.Q = true;
        } else {
          a1.c(true);
        } 
      } 
    } 
    if (paramBundle != null && this.K == -100)
      this.K = paramBundle.getInt("appcompat:local_night_mode", -100); 
  }
  
  void a(n paramn, boolean paramBoolean) {
    if (paramBoolean && paramn.a == 0) {
      e0 e01 = this.l;
      if (e01 != null && e01.b()) {
        b(paramn.j);
        return;
      } 
    } 
    WindowManager windowManager = (WindowManager)this.d.getSystemService("window");
    if (windowManager != null && paramn.o) {
      ViewGroup viewGroup = paramn.g;
      if (viewGroup != null) {
        windowManager.removeView((View)viewGroup);
        if (paramBoolean)
          a(paramn.a, paramn, null); 
      } 
    } 
    paramn.m = false;
    paramn.n = false;
    paramn.o = false;
    paramn.h = null;
    paramn.q = true;
    if (this.H == paramn)
      this.H = null; 
  }
  
  public void a(h paramh) {
    a(paramh, true);
  }
  
  public void a(Toolbar paramToolbar) {
    if (!(this.f instanceof Activity))
      return; 
    a a1 = d();
    if (!(a1 instanceof n)) {
      this.j = null;
      if (a1 != null)
        a1.j(); 
      if (paramToolbar != null) {
        k k = new k(paramToolbar, ((Activity)this.f).getTitle(), this.g);
        this.i = k;
        this.e.setCallback(k.l());
      } else {
        this.i = null;
        this.e.setCallback(this.g);
      } 
      f();
      return;
    } 
    throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
  }
  
  public void a(View paramView) {
    x();
    ViewGroup viewGroup = (ViewGroup)this.v.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView);
    this.f.onContentChanged();
  }
  
  public void a(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    x();
    ((ViewGroup)this.v.findViewById(16908290)).addView(paramView, paramLayoutParams);
    this.f.onContentChanged();
  }
  
  void a(ViewGroup paramViewGroup) {}
  
  public final void a(CharSequence paramCharSequence) {
    this.k = paramCharSequence;
    e0 e01 = this.l;
    if (e01 != null) {
      e01.setWindowTitle(paramCharSequence);
    } else if (s() != null) {
      s().b(paramCharSequence);
    } else {
      TextView textView = this.w;
      if (textView != null)
        textView.setText(paramCharSequence); 
    } 
  }
  
  public boolean a() {
    boolean bool = false;
    int j = y();
    int k = f(j);
    if (k != -1)
      bool = l(k); 
    if (j == 0) {
      w();
      this.M.d();
    } 
    this.L = true;
    return bool;
  }
  
  boolean a(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool = true;
    if (paramInt != 4) {
      if (paramInt == 82) {
        d(0, paramKeyEvent);
        return true;
      } 
    } else {
      if ((paramKeyEvent.getFlags() & 0x80) == 0)
        bool = false; 
      this.I = bool;
    } 
    return false;
  }
  
  public boolean a(h paramh, MenuItem paramMenuItem) {
    Window.Callback callback = p();
    if (callback != null && !this.J) {
      n n1 = a((Menu)paramh.m());
      if (n1 != null)
        return callback.onMenuItemSelected(n1.a, paramMenuItem); 
    } 
    return false;
  }
  
  boolean a(KeyEvent paramKeyEvent) {
    Window.Callback callback = this.f;
    boolean bool1 = callback instanceof android.support.v4.view.e.a;
    boolean bool = true;
    if (bool1 || callback instanceof i) {
      View view = this.e.getDecorView();
      if (view != null && android.support.v4.view.e.a(view, paramKeyEvent))
        return true; 
    } 
    if (paramKeyEvent.getKeyCode() == 82 && this.f.dispatchKeyEvent(paramKeyEvent))
      return true; 
    int j = paramKeyEvent.getKeyCode();
    if (paramKeyEvent.getAction() != 0)
      bool = false; 
    if (bool) {
      bool1 = a(j, paramKeyEvent);
    } else {
      bool1 = c(j, paramKeyEvent);
    } 
    return bool1;
  }
  
  a.b.h.f.b b(a.b.h.f.b.a parama) {
    a.b.h.f.b.a a1;
    m();
    a.b.h.f.b b2 = this.o;
    if (b2 != null)
      b2.a(); 
    a.b.h.f.b.a a2 = parama;
    if (!(parama instanceof j))
      a2 = new j(this, parama); 
    a.b.h.f.b.a a3 = null;
    f f1 = this.h;
    parama = a3;
    if (f1 != null) {
      parama = a3;
      if (!this.J)
        try {
          a.b.h.f.b b3 = f1.a(a2);
        } catch (AbstractMethodError abstractMethodError) {
          a1 = a3;
        }  
    } 
    if (a1 != null) {
      this.o = (a.b.h.f.b)a1;
    } else {
      ActionBarContextView actionBarContextView = this.p;
      boolean bool = true;
      if (actionBarContextView == null)
        if (this.D) {
          Context context;
          TypedValue typedValue = new TypedValue();
          Resources.Theme theme = this.d.getTheme();
          theme.resolveAttribute(a.b.h.a.a.actionBarTheme, typedValue, true);
          if (typedValue.resourceId != 0) {
            Resources.Theme theme1 = this.d.getResources().newTheme();
            theme1.setTo(theme);
            theme1.applyStyle(typedValue.resourceId, true);
            a.b.h.f.d d = new a.b.h.f.d(this.d, 0);
            d.getTheme().setTo(theme1);
          } else {
            context = this.d;
          } 
          this.p = new ActionBarContextView(context);
          this.q = new PopupWindow(context, null, a.b.h.a.a.actionModePopupWindowStyle);
          android.support.v4.widget.n.a(this.q, 2);
          this.q.setContentView((View)this.p);
          this.q.setWidth(-1);
          context.getTheme().resolveAttribute(a.b.h.a.a.actionBarSize, typedValue, true);
          int j = TypedValue.complexToDimensionPixelSize(typedValue.data, context.getResources().getDisplayMetrics());
          this.p.setContentHeight(j);
          this.q.setHeight(-2);
          this.r = new f(this);
        } else {
          ViewStubCompat viewStubCompat = (ViewStubCompat)this.v.findViewById(a.b.h.a.f.action_mode_bar_stub);
          if (viewStubCompat != null) {
            viewStubCompat.setLayoutInflater(LayoutInflater.from(n()));
            this.p = (ActionBarContextView)viewStubCompat.a();
          } 
        }  
      if (this.p != null) {
        m();
        this.p.c();
        Context context = this.p.getContext();
        ActionBarContextView actionBarContextView1 = this.p;
        if (this.q != null)
          bool = false; 
        a.b.h.f.e e = new a.b.h.f.e(context, actionBarContextView1, a2, bool);
        if (a2.a((a.b.h.f.b)e, e.c())) {
          e.i();
          this.p.a((a.b.h.f.b)e);
          this.o = (a.b.h.f.b)e;
          if (t()) {
            this.p.setAlpha(0.0F);
            y y1 = u.a((View)this.p);
            y1.a(1.0F);
            this.s = y1;
            this.s.a((z)new g(this));
          } else {
            this.p.setAlpha(1.0F);
            this.p.setVisibility(0);
            this.p.sendAccessibilityEvent(32);
            if (this.p.getParent() instanceof View)
              u.C((View)this.p.getParent()); 
          } 
          if (this.q != null)
            this.e.getDecorView().post(this.r); 
        } else {
          this.o = null;
        } 
      } 
    } 
    a.b.h.f.b b1 = this.o;
    if (b1 != null) {
      f f2 = this.h;
      if (f2 != null)
        f2.b(b1); 
    } 
    return this.o;
  }
  
  public final b.b b() {
    return new h(this);
  }
  
  public void b(Bundle paramBundle) {
    x();
  }
  
  void b(h paramh) {
    if (this.F)
      return; 
    this.F = true;
    this.l.g();
    Window.Callback callback = p();
    if (callback != null && !this.J)
      callback.onPanelClosed(108, (Menu)paramh); 
    this.F = false;
  }
  
  public void b(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    x();
    ViewGroup viewGroup = (ViewGroup)this.v.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView, paramLayoutParams);
    this.f.onContentChanged();
  }
  
  public boolean b(int paramInt) {
    paramInt = k(paramInt);
    if (this.E && paramInt == 108)
      return false; 
    if (this.A && paramInt == 1)
      this.A = false; 
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 5) {
          if (paramInt != 10) {
            if (paramInt != 108) {
              if (paramInt != 109)
                return this.e.requestFeature(paramInt); 
              B();
              this.B = true;
              return true;
            } 
            B();
            this.A = true;
            return true;
          } 
          B();
          this.C = true;
          return true;
        } 
        B();
        this.z = true;
        return true;
      } 
      B();
      this.y = true;
      return true;
    } 
    B();
    this.E = true;
    return true;
  }
  
  boolean b(int paramInt, KeyEvent paramKeyEvent) {
    n n1;
    a a1 = d();
    if (a1 != null && a1.a(paramInt, paramKeyEvent))
      return true; 
    n n2 = this.H;
    if (n2 != null && a(n2, paramKeyEvent.getKeyCode(), paramKeyEvent, 1)) {
      n1 = this.H;
      if (n1 != null)
        n1.n = true; 
      return true;
    } 
    if (this.H == null) {
      n2 = a(0, true);
      b(n2, (KeyEvent)n1);
      boolean bool = a(n2, n1.getKeyCode(), (KeyEvent)n1, 1);
      n2.m = false;
      if (bool)
        return true; 
    } 
    return false;
  }
  
  public MenuInflater c() {
    if (this.j == null) {
      Context context;
      z();
      a a1 = this.i;
      if (a1 != null) {
        context = a1.h();
      } else {
        context = this.d;
      } 
      this.j = (MenuInflater)new a.b.h.f.g(context);
    } 
    return this.j;
  }
  
  public void c(int paramInt) {
    x();
    ViewGroup viewGroup = (ViewGroup)this.v.findViewById(16908290);
    viewGroup.removeAllViews();
    LayoutInflater.from(this.d).inflate(paramInt, viewGroup);
    this.f.onContentChanged();
  }
  
  public void c(Bundle paramBundle) {
    int j = this.K;
    if (j != -100)
      paramBundle.putInt("appcompat:local_night_mode", j); 
  }
  
  boolean c(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt != 4) {
      if (paramInt == 82) {
        e(0, paramKeyEvent);
        return true;
      } 
    } else {
      boolean bool = this.I;
      this.I = false;
      n n1 = a(0, false);
      if (n1 != null && n1.o) {
        if (!bool)
          a(n1, true); 
        return true;
      } 
      if (r())
        return true; 
    } 
    return false;
  }
  
  public a d() {
    z();
    return this.i;
  }
  
  void d(int paramInt) {
    a(a(paramInt, true), true);
  }
  
  public void e() {
    LayoutInflater layoutInflater = LayoutInflater.from(this.d);
    if (layoutInflater.getFactory() == null) {
      android.support.v4.view.f.b(layoutInflater, this);
    } else if (!(layoutInflater.getFactory2() instanceof h)) {
      Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's");
    } 
  }
  
  void e(int paramInt) {
    n n1 = a(paramInt, true);
    if (n1.j != null) {
      Bundle bundle = new Bundle();
      n1.j.c(bundle);
      if (bundle.size() > 0)
        n1.s = bundle; 
      n1.j.s();
      n1.j.clear();
    } 
    n1.r = true;
    n1.q = true;
    if ((paramInt == 108 || paramInt == 0) && this.l != null) {
      n1 = a(0, false);
      if (n1 != null) {
        n1.m = false;
        b(n1, (KeyEvent)null);
      } 
    } 
  }
  
  int f(int paramInt) {
    if (paramInt != -100) {
      if (paramInt != 0)
        return paramInt; 
      if (Build.VERSION.SDK_INT >= 23 && ((UiModeManager)this.d.getSystemService(UiModeManager.class)).getNightMode() == 0)
        return -1; 
      w();
      return this.M.c();
    } 
    return -1;
  }
  
  public void f() {
    a a1 = d();
    if (a1 != null && a1.i())
      return; 
    j(0);
  }
  
  public void g() {
    if (this.N)
      this.e.getDecorView().removeCallbacks(this.P); 
    this.J = true;
    a a1 = this.i;
    if (a1 != null)
      a1.j(); 
    l l1 = this.M;
    if (l1 != null)
      l1.a(); 
  }
  
  void g(int paramInt) {
    if (paramInt == 108) {
      a a1 = d();
      if (a1 != null)
        a1.b(true); 
    } 
  }
  
  public void h() {
    a a1 = d();
    if (a1 != null)
      a1.g(true); 
  }
  
  void h(int paramInt) {
    if (paramInt == 108) {
      a a1 = d();
      if (a1 != null)
        a1.b(false); 
    } else if (paramInt == 0) {
      n n1 = a(paramInt, true);
      if (n1.o)
        a(n1, false); 
    } 
  }
  
  int i(int paramInt) {
    int j = 0;
    boolean bool2 = false;
    ActionBarContextView actionBarContextView = this.p;
    boolean bool1 = false;
    int m = j;
    int k = paramInt;
    if (actionBarContextView != null) {
      m = j;
      k = paramInt;
      if (actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
        boolean bool;
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.p.getLayoutParams();
        int i1 = 0;
        j = 0;
        if (this.p.isShown()) {
          if (this.R == null) {
            this.R = new Rect();
            this.S = new Rect();
          } 
          Rect rect2 = this.R;
          Rect rect1 = this.S;
          rect2.set(0, paramInt, 0, 0);
          r1.a((View)this.v, rect2, rect1);
          if (rect1.top == 0) {
            bool = paramInt;
          } else {
            bool = false;
          } 
          if (marginLayoutParams.topMargin != bool) {
            bool = true;
            marginLayoutParams.topMargin = paramInt;
            View view1 = this.x;
            if (view1 == null) {
              this.x = new View(this.d);
              this.x.setBackgroundColor(this.d.getResources().getColor(a.b.h.a.c.abc_input_method_navigation_guard));
              this.v.addView(this.x, -1, new ViewGroup.LayoutParams(-1, paramInt));
              j = bool;
            } else {
              ViewGroup.LayoutParams layoutParams = view1.getLayoutParams();
              j = bool;
              if (layoutParams.height != paramInt) {
                layoutParams.height = paramInt;
                this.x.setLayoutParams(layoutParams);
                j = bool;
              } 
            } 
          } 
          if (this.x != null) {
            bool = true;
          } else {
            bool = false;
          } 
          k = paramInt;
          if (!this.C) {
            k = paramInt;
            if (bool)
              k = 0; 
          } 
          i1 = j;
          j = k;
        } else {
          bool = bool2;
          j = paramInt;
          if (marginLayoutParams.topMargin != 0) {
            i1 = 1;
            marginLayoutParams.topMargin = 0;
            j = paramInt;
            bool = bool2;
          } 
        } 
        m = bool;
        k = j;
        if (i1 != 0) {
          this.p.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams);
          k = j;
          m = bool;
        } 
      } 
    } 
    View view = this.x;
    if (view != null) {
      if (m != 0) {
        paramInt = bool1;
      } else {
        paramInt = 8;
      } 
      view.setVisibility(paramInt);
    } 
    return k;
  }
  
  public void i() {
    a();
  }
  
  public void j() {
    a a1 = d();
    if (a1 != null)
      a1.g(false); 
    l l1 = this.M;
    if (l1 != null)
      l1.a(); 
  }
  
  void l() {
    e0 e01 = this.l;
    if (e01 != null)
      e01.g(); 
    if (this.q != null) {
      this.e.getDecorView().removeCallbacks(this.r);
      if (this.q.isShowing())
        try {
          this.q.dismiss();
        } catch (IllegalArgumentException illegalArgumentException) {} 
      this.q = null;
    } 
    m();
    n n1 = a(0, false);
    if (n1 != null) {
      h h1 = n1.j;
      if (h1 != null)
        h1.close(); 
    } 
  }
  
  void m() {
    y y1 = this.s;
    if (y1 != null)
      y1.a(); 
  }
  
  final Context n() {
    Context context1 = null;
    a a1 = d();
    if (a1 != null)
      context1 = a1.h(); 
    Context context2 = context1;
    if (context1 == null)
      context2 = this.d; 
    return context2;
  }
  
  final CharSequence o() {
    Window.Callback callback = this.f;
    return (callback instanceof Activity) ? ((Activity)callback).getTitle() : this.k;
  }
  
  public final View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return a(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  final Window.Callback p() {
    return this.e.getCallback();
  }
  
  public boolean q() {
    return this.t;
  }
  
  boolean r() {
    a.b.h.f.b b1 = this.o;
    if (b1 != null) {
      b1.a();
      return true;
    } 
    a a1 = d();
    return (a1 != null && a1.f());
  }
  
  final a s() {
    return this.i;
  }
  
  final boolean t() {
    if (this.u) {
      ViewGroup viewGroup = this.v;
      if (viewGroup != null && u.y((View)viewGroup))
        return true; 
    } 
    return false;
  }
  
  static {
    boolean bool;
    if (Build.VERSION.SDK_INT < 21) {
      bool = true;
    } else {
      bool = false;
    } 
    U = bool;
  }
  
  static final class a implements Thread.UncaughtExceptionHandler {
    final Thread.UncaughtExceptionHandler a;
    
    a(Thread.UncaughtExceptionHandler param1UncaughtExceptionHandler) {}
    
    private boolean a(Throwable param1Throwable) {
      boolean bool1 = param1Throwable instanceof Resources.NotFoundException;
      boolean bool = false;
      if (bool1) {
        String str = param1Throwable.getMessage();
        if (str != null && (str.contains("drawable") || str.contains("Drawable")))
          bool = true; 
        return bool;
      } 
      return false;
    }
    
    public void uncaughtException(Thread param1Thread, Throwable param1Throwable) {
      if (a(param1Throwable)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(param1Throwable.getMessage());
        stringBuilder.append(". If the resource you are trying to use is a vector resource, you may be referencing it in an unsupported way. See AppCompatDelegate.setCompatVectorFromResourcesEnabled() for more info.");
        Resources.NotFoundException notFoundException = new Resources.NotFoundException(stringBuilder.toString());
        notFoundException.initCause(param1Throwable.getCause());
        notFoundException.setStackTrace(param1Throwable.getStackTrace());
        this.a.uncaughtException(param1Thread, (Throwable)notFoundException);
      } else {
        this.a.uncaughtException(param1Thread, param1Throwable);
      } 
    }
  }
  
  class b implements Runnable {
    final h c;
    
    b(h this$0) {}
    
    public void run() {
      h h1 = this.c;
      if ((h1.O & 0x1) != 0)
        h1.e(0); 
      h1 = this.c;
      if ((h1.O & 0x1000) != 0)
        h1.e(108); 
      h1 = this.c;
      h1.N = false;
      h1.O = 0;
    }
  }
  
  class c implements p {
    final h a;
    
    c(h this$0) {}
    
    public c0 a(View param1View, c0 param1c0) {
      int j = param1c0.e();
      int i = this.a.i(j);
      c0 c01 = param1c0;
      if (j != i)
        c01 = param1c0.a(param1c0.c(), i, param1c0.d(), param1c0.b()); 
      return u.b(param1View, c01);
    }
  }
  
  class d implements k0.a {
    final h a;
    
    d(h this$0) {}
    
    public void a(Rect param1Rect) {
      param1Rect.top = this.a.i(param1Rect.top);
    }
  }
  
  class e implements ContentFrameLayout.a {
    final h a;
    
    e(h this$0) {}
    
    public void a() {}
    
    public void onDetachedFromWindow() {
      this.a.l();
    }
  }
  
  class f implements Runnable {
    final h c;
    
    f(h this$0) {}
    
    public void run() {
      h h1 = this.c;
      h1.q.showAtLocation((View)h1.p, 55, 0, 0);
      this.c.m();
      if (this.c.t()) {
        this.c.p.setAlpha(0.0F);
        h1 = this.c;
        y y = u.a((View)h1.p);
        y.a(1.0F);
        h1.s = y;
        this.c.s.a((z)new a(this));
      } else {
        this.c.p.setAlpha(1.0F);
        this.c.p.setVisibility(0);
      } 
    }
    
    class a extends a0 {
      final h.f a;
      
      a(h.f this$0) {}
      
      public void a(View param2View) {
        this.a.c.p.setAlpha(1.0F);
        this.a.c.s.a(null);
        this.a.c.s = null;
      }
      
      public void b(View param2View) {
        this.a.c.p.setVisibility(0);
      }
    }
  }
  
  class a extends a0 {
    final h.f a;
    
    a(h this$0) {}
    
    public void a(View param1View) {
      this.a.c.p.setAlpha(1.0F);
      this.a.c.s.a(null);
      this.a.c.s = null;
    }
    
    public void b(View param1View) {
      this.a.c.p.setVisibility(0);
    }
  }
  
  class g extends a0 {
    final h a;
    
    g(h this$0) {}
    
    public void a(View param1View) {
      this.a.p.setAlpha(1.0F);
      this.a.s.a(null);
      this.a.s = null;
    }
    
    public void b(View param1View) {
      this.a.p.setVisibility(0);
      this.a.p.sendAccessibilityEvent(32);
      if (this.a.p.getParent() instanceof View)
        u.C((View)this.a.p.getParent()); 
    }
  }
  
  private class h implements b.b {
    final h a;
    
    h(h this$0) {}
    
    public Context a() {
      return this.a.n();
    }
    
    public void a(int param1Int) {
      a a = this.a.d();
      if (a != null)
        a.b(param1Int); 
    }
    
    public void a(Drawable param1Drawable, int param1Int) {
      a a = this.a.d();
      if (a != null) {
        a.b(param1Drawable);
        a.b(param1Int);
      } 
    }
    
    public boolean b() {
      boolean bool;
      a a = this.a.d();
      if (a != null && (a.g() & 0x4) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public Drawable c() {
      j1 j1 = j1.a(a(), null, new int[] { a.b.h.a.a.homeAsUpIndicator });
      Drawable drawable = j1.b(0);
      j1.a();
      return drawable;
    }
  }
  
  private final class i implements p.a {
    final h c;
    
    i(h this$0) {}
    
    public void a(h param1h, boolean param1Boolean) {
      this.c.b(param1h);
    }
    
    public boolean a(h param1h) {
      Window.Callback callback = this.c.p();
      if (callback != null)
        callback.onMenuOpened(108, (Menu)param1h); 
      return true;
    }
  }
  
  class j implements a.b.h.f.b.a {
    private a.b.h.f.b.a a;
    
    final h b;
    
    public j(h this$0, a.b.h.f.b.a param1a) {
      this.a = param1a;
    }
    
    public void a(a.b.h.f.b param1b) {
      this.a.a(param1b);
      h h1 = this.b;
      if (h1.q != null)
        h1.e.getDecorView().removeCallbacks(this.b.r); 
      h1 = this.b;
      if (h1.p != null) {
        h1.m();
        h1 = this.b;
        y y = u.a((View)h1.p);
        y.a(0.0F);
        h1.s = y;
        this.b.s.a((z)new a(this));
      } 
      h1 = this.b;
      f f = h1.h;
      if (f != null)
        f.a(h1.o); 
      this.b.o = null;
    }
    
    public boolean a(a.b.h.f.b param1b, Menu param1Menu) {
      return this.a.a(param1b, param1Menu);
    }
    
    public boolean a(a.b.h.f.b param1b, MenuItem param1MenuItem) {
      return this.a.a(param1b, param1MenuItem);
    }
    
    public boolean b(a.b.h.f.b param1b, Menu param1Menu) {
      return this.a.b(param1b, param1Menu);
    }
    
    class a extends a0 {
      final h.j a;
      
      a(h.j this$0) {}
      
      public void a(View param2View) {
        this.a.b.p.setVisibility(8);
        h h = this.a.b;
        PopupWindow popupWindow = h.q;
        if (popupWindow != null) {
          popupWindow.dismiss();
        } else if (h.p.getParent() instanceof View) {
          u.C((View)this.a.b.p.getParent());
        } 
        this.a.b.p.removeAllViews();
        this.a.b.s.a(null);
        this.a.b.s = null;
      }
    }
  }
  
  class a extends a0 {
    final h.j a;
    
    a(h this$0) {}
    
    public void a(View param1View) {
      this.a.b.p.setVisibility(8);
      h h = this.a.b;
      PopupWindow popupWindow = h.q;
      if (popupWindow != null) {
        popupWindow.dismiss();
      } else if (h.p.getParent() instanceof View) {
        u.C((View)this.a.b.p.getParent());
      } 
      this.a.b.p.removeAllViews();
      this.a.b.s.a(null);
      this.a.b.s = null;
    }
  }
  
  class k extends a.b.h.f.i {
    final h d;
    
    k(h this$0, Window.Callback param1Callback) {
      super(param1Callback);
    }
    
    final ActionMode a(ActionMode.Callback param1Callback) {
      a.b.h.f.f.a a = new a.b.h.f.f.a(this.d.d, param1Callback);
      a.b.h.f.b b = this.d.a((a.b.h.f.b.a)a);
      return (b != null) ? a.b(b) : null;
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return (this.d.a(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent));
    }
    
    public boolean dispatchKeyShortcutEvent(KeyEvent param1KeyEvent) {
      return (super.dispatchKeyShortcutEvent(param1KeyEvent) || this.d.b(param1KeyEvent.getKeyCode(), param1KeyEvent));
    }
    
    public void onContentChanged() {}
    
    public boolean onCreatePanelMenu(int param1Int, Menu param1Menu) {
      return (param1Int == 0 && !(param1Menu instanceof h)) ? false : super.onCreatePanelMenu(param1Int, param1Menu);
    }
    
    public boolean onMenuOpened(int param1Int, Menu param1Menu) {
      super.onMenuOpened(param1Int, param1Menu);
      this.d.g(param1Int);
      return true;
    }
    
    public void onPanelClosed(int param1Int, Menu param1Menu) {
      super.onPanelClosed(param1Int, param1Menu);
      this.d.h(param1Int);
    }
    
    public boolean onPreparePanel(int param1Int, View param1View, Menu param1Menu) {
      h h1;
      if (param1Menu instanceof h) {
        h1 = (h)param1Menu;
      } else {
        h1 = null;
      } 
      if (param1Int == 0 && h1 == null)
        return false; 
      if (h1 != null)
        h1.c(true); 
      boolean bool = super.onPreparePanel(param1Int, param1View, param1Menu);
      if (h1 != null)
        h1.c(false); 
      return bool;
    }
    
    public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> param1List, Menu param1Menu, int param1Int) {
      h.n n = this.d.a(0, true);
      if (n != null) {
        h h1 = n.j;
        if (h1 != null) {
          super.onProvideKeyboardShortcuts(param1List, (Menu)h1, param1Int);
          return;
        } 
      } 
      super.onProvideKeyboardShortcuts(param1List, param1Menu, param1Int);
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback) {
      return (Build.VERSION.SDK_INT >= 23) ? null : (this.d.q() ? a(param1Callback) : super.onWindowStartingActionMode(param1Callback));
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback, int param1Int) {
      return (!this.d.q() || param1Int != 0) ? super.onWindowStartingActionMode(param1Callback, param1Int) : a(param1Callback);
    }
  }
  
  final class l {
    private m a;
    
    private boolean b;
    
    private BroadcastReceiver c;
    
    private IntentFilter d;
    
    final h e;
    
    l(h this$0, m param1m) {
      this.a = param1m;
      this.b = param1m.a();
    }
    
    void a() {
      BroadcastReceiver broadcastReceiver = this.c;
      if (broadcastReceiver != null) {
        this.e.d.unregisterReceiver(broadcastReceiver);
        this.c = null;
      } 
    }
    
    void b() {
      boolean bool = this.a.a();
      if (bool != this.b) {
        this.b = bool;
        this.e.a();
      } 
    }
    
    int c() {
      boolean bool;
      this.b = this.a.a();
      if (this.b) {
        bool = true;
      } else {
        bool = true;
      } 
      return bool;
    }
    
    void d() {
      a();
      if (this.c == null)
        this.c = new a(this); 
      if (this.d == null) {
        this.d = new IntentFilter();
        this.d.addAction("android.intent.action.TIME_SET");
        this.d.addAction("android.intent.action.TIMEZONE_CHANGED");
        this.d.addAction("android.intent.action.TIME_TICK");
      } 
      this.e.d.registerReceiver(this.c, this.d);
    }
    
    class a extends BroadcastReceiver {
      final h.l a;
      
      a(h.l this$0) {}
      
      public void onReceive(Context param2Context, Intent param2Intent) {
        this.a.b();
      }
    }
  }
  
  class a extends BroadcastReceiver {
    final h.l a;
    
    a(h this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      this.a.b();
    }
  }
  
  private class m extends ContentFrameLayout {
    final h k;
    
    public m(h this$0, Context param1Context) {
      super(param1Context);
    }
    
    private boolean a(int param1Int1, int param1Int2) {
      return (param1Int1 < -5 || param1Int2 < -5 || param1Int1 > getWidth() + 5 || param1Int2 > getHeight() + 5);
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return (this.k.a(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent));
    }
    
    public boolean onInterceptTouchEvent(MotionEvent param1MotionEvent) {
      if (param1MotionEvent.getAction() == 0 && a((int)param1MotionEvent.getX(), (int)param1MotionEvent.getY())) {
        this.k.d(0);
        return true;
      } 
      return super.onInterceptTouchEvent(param1MotionEvent);
    }
    
    public void setBackgroundResource(int param1Int) {
      setBackgroundDrawable(a.b.h.c.a.a.c(getContext(), param1Int));
    }
  }
  
  protected static final class n {
    int a;
    
    int b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    ViewGroup g;
    
    View h;
    
    View i;
    
    h j;
    
    android.support.v7.view.menu.f k;
    
    Context l;
    
    boolean m;
    
    boolean n;
    
    boolean o;
    
    public boolean p;
    
    boolean q;
    
    boolean r;
    
    Bundle s;
    
    n(int param1Int) {
      this.a = param1Int;
      this.q = false;
    }
    
    q a(p.a param1a) {
      if (this.j == null)
        return null; 
      if (this.k == null) {
        this.k = new android.support.v7.view.menu.f(this.l, a.b.h.a.g.abc_list_menu_item_layout);
        this.k.a(param1a);
        this.j.a((p)this.k);
      } 
      return this.k.a(this.g);
    }
    
    void a(Context param1Context) {
      TypedValue typedValue = new TypedValue();
      Resources.Theme theme = param1Context.getResources().newTheme();
      theme.setTo(param1Context.getTheme());
      theme.resolveAttribute(a.b.h.a.a.actionBarPopupTheme, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0)
        theme.applyStyle(i, true); 
      theme.resolveAttribute(a.b.h.a.a.panelMenuListTheme, typedValue, true);
      i = typedValue.resourceId;
      if (i != 0) {
        theme.applyStyle(i, true);
      } else {
        theme.applyStyle(a.b.h.a.i.Theme_AppCompat_CompactMenu, true);
      } 
      a.b.h.f.d d = new a.b.h.f.d(param1Context, 0);
      d.getTheme().setTo(theme);
      this.l = (Context)d;
      TypedArray typedArray = d.obtainStyledAttributes(a.b.h.a.j.AppCompatTheme);
      this.b = typedArray.getResourceId(a.b.h.a.j.AppCompatTheme_panelBackground, 0);
      this.f = typedArray.getResourceId(a.b.h.a.j.AppCompatTheme_android_windowAnimationStyle, 0);
      typedArray.recycle();
    }
    
    void a(h param1h) {
      h h1 = this.j;
      if (param1h == h1)
        return; 
      if (h1 != null)
        h1.b((p)this.k); 
      this.j = param1h;
      if (param1h != null) {
        android.support.v7.view.menu.f f1 = this.k;
        if (f1 != null)
          param1h.a((p)f1); 
      } 
    }
    
    public boolean a() {
      View view = this.h;
      boolean bool = false;
      if (view == null)
        return false; 
      if (this.i != null)
        return true; 
      if (this.k.d().getCount() > 0)
        bool = true; 
      return bool;
    }
  }
  
  private final class o implements p.a {
    final h c;
    
    o(h this$0) {}
    
    public void a(h param1h, boolean param1Boolean) {
      boolean bool;
      h h1 = param1h.m();
      if (h1 != param1h) {
        bool = true;
      } else {
        bool = false;
      } 
      h h2 = this.c;
      if (bool)
        param1h = h1; 
      h.n n = h2.a((Menu)param1h);
      if (n != null)
        if (bool) {
          this.c.a(n.a, n, (Menu)h1);
          this.c.a(n, true);
        } else {
          this.c.a(n, param1Boolean);
        }  
    }
    
    public boolean a(h param1h) {
      if (param1h == null) {
        h h1 = this.c;
        if (h1.A) {
          Window.Callback callback = h1.p();
          if (callback != null && !this.c.J)
            callback.onMenuOpened(108, (Menu)param1h); 
        } 
      } 
      return true;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\app\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */