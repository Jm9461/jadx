package android.support.v7.app;

import a.b.h.f.b;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.a;
import android.support.v4.app.f0;
import android.support.v4.app.g;
import android.support.v4.app.v;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.o1;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

public class e extends g implements f, f0.a, b.c {
  private g o;
  
  private int p = 0;
  
  private Resources q;
  
  private boolean a(int paramInt, KeyEvent paramKeyEvent) {
    if (Build.VERSION.SDK_INT < 26 && !paramKeyEvent.isCtrlPressed() && !KeyEvent.metaStateHasNoModifiers(paramKeyEvent.getMetaState()) && paramKeyEvent.getRepeatCount() == 0 && !KeyEvent.isModifierKey(paramKeyEvent.getKeyCode())) {
      Window window = getWindow();
      if (window != null && window.getDecorView() != null && window.getDecorView().dispatchKeyShortcutEvent(paramKeyEvent))
        return true; 
    } 
    return false;
  }
  
  public b a(b.a parama) {
    return null;
  }
  
  public void a(b paramb) {}
  
  public void a(Intent paramIntent) {
    v.a((Activity)this, paramIntent);
  }
  
  public void a(f0 paramf0) {
    paramf0.a((Activity)this);
  }
  
  public void a(Toolbar paramToolbar) {
    i().a(paramToolbar);
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    i().a(paramView, paramLayoutParams);
  }
  
  public void b(b paramb) {}
  
  public void b(f0 paramf0) {}
  
  public boolean b(Intent paramIntent) {
    return v.b((Activity)this, paramIntent);
  }
  
  public Intent c() {
    return v.a((Activity)this);
  }
  
  public void closeOptionsMenu() {
    a a1 = j();
    if (getWindow().hasFeature(0) && (a1 == null || !a1.e()))
      super.closeOptionsMenu(); 
  }
  
  public b.b d() {
    return i().b();
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    int i = paramKeyEvent.getKeyCode();
    a a1 = j();
    return (i == 82 && a1 != null && a1.a(paramKeyEvent)) ? true : super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public <T extends View> T findViewById(int paramInt) {
    return i().a(paramInt);
  }
  
  public MenuInflater getMenuInflater() {
    return i().c();
  }
  
  public Resources getResources() {
    if (this.q == null && o1.b())
      this.q = (Resources)new o1((Context)this, super.getResources()); 
    Resources resources2 = this.q;
    Resources resources1 = resources2;
    if (resources2 == null)
      resources1 = super.getResources(); 
    return resources1;
  }
  
  public void h() {
    i().f();
  }
  
  public g i() {
    if (this.o == null)
      this.o = g.a((Activity)this, this); 
    return this.o;
  }
  
  public void invalidateOptionsMenu() {
    i().f();
  }
  
  public a j() {
    return i().d();
  }
  
  @Deprecated
  public void k() {}
  
  public boolean l() {
    Intent intent = c();
    if (intent != null) {
      if (b(intent)) {
        f0 f0 = f0.a((Context)this);
        a(f0);
        b(f0);
        f0.a();
        try {
          a.a((Activity)this);
        } catch (IllegalStateException illegalStateException) {
          finish();
        } 
      } else {
        a((Intent)illegalStateException);
      } 
      return true;
    } 
    return false;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    i().a(paramConfiguration);
    if (this.q != null) {
      DisplayMetrics displayMetrics = super.getResources().getDisplayMetrics();
      this.q.updateConfiguration(paramConfiguration, displayMetrics);
    } 
  }
  
  public void onContentChanged() {
    k();
  }
  
  protected void onCreate(Bundle paramBundle) {
    g g1 = i();
    g1.e();
    g1.a(paramBundle);
    if (g1.a()) {
      int i = this.p;
      if (i != 0)
        if (Build.VERSION.SDK_INT >= 23) {
          onApplyThemeResource(getTheme(), this.p, false);
        } else {
          setTheme(i);
        }  
    } 
    super.onCreate(paramBundle);
  }
  
  protected void onDestroy() {
    super.onDestroy();
    i().g();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    return a(paramInt, paramKeyEvent) ? true : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public final boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    if (super.onMenuItemSelected(paramInt, paramMenuItem))
      return true; 
    a a1 = j();
    return (paramMenuItem.getItemId() == 16908332 && a1 != null && (a1.g() & 0x4) != 0) ? l() : false;
  }
  
  public boolean onMenuOpened(int paramInt, Menu paramMenu) {
    return super.onMenuOpened(paramInt, paramMenu);
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  protected void onPostCreate(Bundle paramBundle) {
    super.onPostCreate(paramBundle);
    i().b(paramBundle);
  }
  
  protected void onPostResume() {
    super.onPostResume();
    i().h();
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    i().c(paramBundle);
  }
  
  protected void onStart() {
    super.onStart();
    i().i();
  }
  
  protected void onStop() {
    super.onStop();
    i().j();
  }
  
  protected void onTitleChanged(CharSequence paramCharSequence, int paramInt) {
    super.onTitleChanged(paramCharSequence, paramInt);
    i().a(paramCharSequence);
  }
  
  public void openOptionsMenu() {
    a a1 = j();
    if (getWindow().hasFeature(0) && (a1 == null || !a1.k()))
      super.openOptionsMenu(); 
  }
  
  public void setContentView(int paramInt) {
    i().c(paramInt);
  }
  
  public void setContentView(View paramView) {
    i().a(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    i().b(paramView, paramLayoutParams);
  }
  
  public void setTheme(int paramInt) {
    super.setTheme(paramInt);
    this.p = paramInt;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\app\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */