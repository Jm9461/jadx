package android.support.v7.widget;

import a.b.h.a.j;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.view.u;
import android.support.v7.view.menu.h;
import android.support.v7.view.menu.k;
import android.support.v7.view.menu.p;
import android.support.v7.view.menu.v;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class Toolbar extends ViewGroup {
  private CharSequence A;
  
  private int B;
  
  private int C;
  
  private boolean D;
  
  private boolean E;
  
  private final ArrayList<View> F = new ArrayList<View>();
  
  private final ArrayList<View> G = new ArrayList<View>();
  
  private final int[] H = new int[2];
  
  f I;
  
  private final ActionMenuView.e J = new a(this);
  
  private k1 K;
  
  private c L;
  
  private d M;
  
  private p.a N;
  
  private h.a O;
  
  private boolean P;
  
  private final Runnable Q = new b(this);
  
  private ActionMenuView c;
  
  private TextView d;
  
  private TextView e;
  
  private ImageButton f;
  
  private ImageView g;
  
  private Drawable h;
  
  private CharSequence i;
  
  ImageButton j;
  
  View k;
  
  private Context l;
  
  private int m;
  
  private int n;
  
  private int o;
  
  int p;
  
  private int q;
  
  private int r;
  
  private int s;
  
  private int t;
  
  private int u;
  
  private z0 v;
  
  private int w;
  
  private int x;
  
  private int y = 8388627;
  
  private CharSequence z;
  
  public Toolbar(Context paramContext) {
    this(paramContext, null);
  }
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.b.h.a.a.toolbarStyle);
  }
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    j1 j1 = j1.a(getContext(), paramAttributeSet, j.Toolbar, paramInt, 0);
    this.n = j1.g(j.Toolbar_titleTextAppearance, 0);
    this.o = j1.g(j.Toolbar_subtitleTextAppearance, 0);
    this.y = j1.e(j.Toolbar_android_gravity, this.y);
    this.p = j1.e(j.Toolbar_buttonGravity, 48);
    int i = j1.b(j.Toolbar_titleMargin, 0);
    paramInt = i;
    if (j1.g(j.Toolbar_titleMargins))
      paramInt = j1.b(j.Toolbar_titleMargins, i); 
    this.u = paramInt;
    this.t = paramInt;
    this.s = paramInt;
    this.r = paramInt;
    paramInt = j1.b(j.Toolbar_titleMarginStart, -1);
    if (paramInt >= 0)
      this.r = paramInt; 
    paramInt = j1.b(j.Toolbar_titleMarginEnd, -1);
    if (paramInt >= 0)
      this.s = paramInt; 
    paramInt = j1.b(j.Toolbar_titleMarginTop, -1);
    if (paramInt >= 0)
      this.t = paramInt; 
    paramInt = j1.b(j.Toolbar_titleMarginBottom, -1);
    if (paramInt >= 0)
      this.u = paramInt; 
    this.q = j1.c(j.Toolbar_maxButtonHeight, -1);
    int k = j1.b(j.Toolbar_contentInsetStart, -2147483648);
    i = j1.b(j.Toolbar_contentInsetEnd, -2147483648);
    int j = j1.c(j.Toolbar_contentInsetLeft, 0);
    paramInt = j1.c(j.Toolbar_contentInsetRight, 0);
    l();
    this.v.a(j, paramInt);
    if (k != Integer.MIN_VALUE || i != Integer.MIN_VALUE)
      this.v.b(k, i); 
    this.w = j1.b(j.Toolbar_contentInsetStartWithNavigation, -2147483648);
    this.x = j1.b(j.Toolbar_contentInsetEndWithActions, -2147483648);
    this.h = j1.b(j.Toolbar_collapseIcon);
    this.i = j1.e(j.Toolbar_collapseContentDescription);
    CharSequence charSequence3 = j1.e(j.Toolbar_title);
    if (!TextUtils.isEmpty(charSequence3))
      setTitle(charSequence3); 
    charSequence3 = j1.e(j.Toolbar_subtitle);
    if (!TextUtils.isEmpty(charSequence3))
      setSubtitle(charSequence3); 
    this.l = getContext();
    setPopupTheme(j1.g(j.Toolbar_popupTheme, 0));
    Drawable drawable2 = j1.b(j.Toolbar_navigationIcon);
    if (drawable2 != null)
      setNavigationIcon(drawable2); 
    CharSequence charSequence2 = j1.e(j.Toolbar_navigationContentDescription);
    if (!TextUtils.isEmpty(charSequence2))
      setNavigationContentDescription(charSequence2); 
    Drawable drawable1 = j1.b(j.Toolbar_logo);
    if (drawable1 != null)
      setLogo(drawable1); 
    CharSequence charSequence1 = j1.e(j.Toolbar_logoDescription);
    if (!TextUtils.isEmpty(charSequence1))
      setLogoDescription(charSequence1); 
    if (j1.g(j.Toolbar_titleTextColor))
      setTitleTextColor(j1.a(j.Toolbar_titleTextColor, -1)); 
    if (j1.g(j.Toolbar_subtitleTextColor))
      setSubtitleTextColor(j1.a(j.Toolbar_subtitleTextColor, -1)); 
    j1.a();
  }
  
  private int a(int paramInt) {
    int i = u.k((View)this);
    int j = android.support.v4.view.d.a(paramInt, i) & 0x7;
    if (j != 1) {
      paramInt = 3;
      if (j != 3 && j != 5) {
        if (i == 1)
          paramInt = 5; 
        return paramInt;
      } 
    } 
    return j;
  }
  
  private int a(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return android.support.v4.view.g.b(marginLayoutParams) + android.support.v4.view.g.a(marginLayoutParams);
  }
  
  private int a(View paramView, int paramInt) {
    e e1 = (e)paramView.getLayoutParams();
    int j = paramView.getMeasuredHeight();
    if (paramInt > 0) {
      paramInt = (j - paramInt) / 2;
    } else {
      paramInt = 0;
    } 
    int i = b(e1.a);
    if (i != 48) {
      if (i != 80) {
        int k = getPaddingTop();
        int m = getPaddingBottom();
        paramInt = getHeight();
        i = (paramInt - k - m - j) / 2;
        if (i < ((ViewGroup.MarginLayoutParams)e1).topMargin) {
          paramInt = ((ViewGroup.MarginLayoutParams)e1).topMargin;
        } else {
          j = paramInt - m - j - i - k;
          m = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
          paramInt = i;
          if (j < m)
            paramInt = Math.max(0, i - m - j); 
        } 
        return k + paramInt;
      } 
      return getHeight() - getPaddingBottom() - j - ((ViewGroup.MarginLayoutParams)e1).bottomMargin - paramInt;
    } 
    return getPaddingTop() - paramInt;
  }
  
  private int a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int j = marginLayoutParams.leftMargin - paramArrayOfint[0];
    int k = marginLayoutParams.rightMargin - paramArrayOfint[1];
    int i = Math.max(0, j) + Math.max(0, k);
    paramArrayOfint[0] = Math.max(0, -j);
    paramArrayOfint[1] = Math.max(0, -k);
    paramInt1 = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + i + paramInt2, marginLayoutParams.width);
    paramView.measure(paramInt1, ViewGroup.getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height));
    return paramView.getMeasuredWidth() + i;
  }
  
  private int a(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)e1).leftMargin - paramArrayOfint[0];
    paramInt1 += Math.max(0, i);
    paramArrayOfint[0] = Math.max(0, -i);
    paramInt2 = a(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1, paramInt2, paramInt1 + i, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 + ((ViewGroup.MarginLayoutParams)e1).rightMargin + i;
  }
  
  private int a(List<View> paramList, int[] paramArrayOfint) {
    int k = paramArrayOfint[0];
    int j = paramArrayOfint[1];
    int i = 0;
    int m = paramList.size();
    for (byte b = 0; b < m; b++) {
      View view = paramList.get(b);
      e e1 = (e)view.getLayoutParams();
      k = ((ViewGroup.MarginLayoutParams)e1).leftMargin - k;
      j = ((ViewGroup.MarginLayoutParams)e1).rightMargin - j;
      int n = Math.max(0, k);
      int i1 = Math.max(0, j);
      k = Math.max(0, -k);
      j = Math.max(0, -j);
      i += view.getMeasuredWidth() + n + i1;
    } 
    return i;
  }
  
  private void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width);
    paramInt2 = ViewGroup.getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height);
    paramInt3 = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = paramInt2;
    if (paramInt3 != 1073741824) {
      paramInt1 = paramInt2;
      if (paramInt5 >= 0) {
        if (paramInt3 != 0) {
          paramInt1 = Math.min(View.MeasureSpec.getSize(paramInt2), paramInt5);
        } else {
          paramInt1 = paramInt5;
        } 
        paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
      } 
    } 
    paramView.measure(i, paramInt1);
  }
  
  private void a(View paramView, boolean paramBoolean) {
    e e1;
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams == null) {
      e1 = generateDefaultLayoutParams();
    } else if (!checkLayoutParams((ViewGroup.LayoutParams)e1)) {
      e1 = generateLayoutParams((ViewGroup.LayoutParams)e1);
    } else {
      e1 = e1;
    } 
    e1.b = 1;
    if (paramBoolean && this.k != null) {
      paramView.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.G.add(paramView);
    } else {
      addView(paramView, (ViewGroup.LayoutParams)e1);
    } 
  }
  
  private void a(List<View> paramList, int paramInt) {
    int i = u.k((View)this);
    boolean bool = true;
    if (i != 1)
      bool = false; 
    int j = getChildCount();
    i = android.support.v4.view.d.a(paramInt, u.k((View)this));
    paramList.clear();
    if (bool) {
      for (paramInt = j - 1; paramInt >= 0; paramInt--) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && d(view) && a(e1.a) == i)
          paramList.add(view); 
      } 
    } else {
      for (paramInt = 0; paramInt < j; paramInt++) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && d(view) && a(e1.a) == i)
          paramList.add(view); 
      } 
    } 
  }
  
  private int b(int paramInt) {
    paramInt &= 0x70;
    return (paramInt != 16 && paramInt != 48 && paramInt != 80) ? (this.y & 0x70) : paramInt;
  }
  
  private int b(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
  }
  
  private int b(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)e1).rightMargin - paramArrayOfint[1];
    paramInt1 -= Math.max(0, i);
    paramArrayOfint[1] = Math.max(0, -i);
    paramInt2 = a(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1 - i, paramInt2, paramInt1, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 - ((ViewGroup.MarginLayoutParams)e1).leftMargin + i;
  }
  
  private boolean c(View paramView) {
    return (paramView.getParent() == this || this.G.contains(paramView));
  }
  
  private boolean d(View paramView) {
    boolean bool;
    if (paramView != null && paramView.getParent() == this && paramView.getVisibility() != 8) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private MenuInflater getMenuInflater() {
    return (MenuInflater)new a.b.h.f.g(getContext());
  }
  
  private void l() {
    if (this.v == null)
      this.v = new z0(); 
  }
  
  private void m() {
    if (this.g == null)
      this.g = new o(getContext()); 
  }
  
  private void n() {
    o();
    if (this.c.j() == null) {
      h h = (h)this.c.getMenu();
      if (this.M == null)
        this.M = new d(this); 
      this.c.setExpandedActionViewsExclusive(true);
      h.a(this.M, this.l);
    } 
  }
  
  private void o() {
    if (this.c == null) {
      this.c = new ActionMenuView(getContext());
      this.c.setPopupTheme(this.m);
      this.c.setOnMenuItemClickListener(this.J);
      this.c.a(this.N, this.O);
      e e1 = generateDefaultLayoutParams();
      e1.a = 0x800005 | this.p & 0x70;
      this.c.setLayoutParams((ViewGroup.LayoutParams)e1);
      a((View)this.c, false);
    } 
  }
  
  private void p() {
    if (this.f == null) {
      this.f = new m(getContext(), null, a.b.h.a.a.toolbarNavigationButtonStyle);
      e e1 = generateDefaultLayoutParams();
      e1.a = 0x800003 | this.p & 0x70;
      this.f.setLayoutParams((ViewGroup.LayoutParams)e1);
    } 
  }
  
  private void q() {
    removeCallbacks(this.Q);
    post(this.Q);
  }
  
  private boolean r() {
    if (!this.P)
      return false; 
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      if (d(view) && view.getMeasuredWidth() > 0 && view.getMeasuredHeight() > 0)
        return false; 
    } 
    return true;
  }
  
  void a() {
    for (int i = this.G.size() - 1; i >= 0; i--)
      addView(this.G.get(i)); 
    this.G.clear();
  }
  
  public void a(int paramInt1, int paramInt2) {
    l();
    this.v.a(paramInt1, paramInt2);
  }
  
  public void a(Context paramContext, int paramInt) {
    this.o = paramInt;
    TextView textView = this.e;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public void a(h paramh, c paramc) {
    if (paramh == null && this.c == null)
      return; 
    o();
    h h1 = this.c.j();
    if (h1 == paramh)
      return; 
    if (h1 != null) {
      h1.b((p)this.L);
      h1.b(this.M);
    } 
    if (this.M == null)
      this.M = new d(this); 
    paramc.b(true);
    if (paramh != null) {
      paramh.a((p)paramc, this.l);
      paramh.a(this.M, this.l);
    } else {
      paramc.a(this.l, (h)null);
      this.M.a(this.l, (h)null);
      paramc.a(true);
      this.M.a(true);
    } 
    this.c.setPopupTheme(this.m);
    this.c.setPresenter(paramc);
    this.L = paramc;
  }
  
  public void a(p.a parama, h.a parama1) {
    this.N = parama;
    this.O = parama1;
    ActionMenuView actionMenuView = this.c;
    if (actionMenuView != null)
      actionMenuView.a(parama, parama1); 
  }
  
  public void b(int paramInt1, int paramInt2) {
    l();
    this.v.b(paramInt1, paramInt2);
  }
  
  public void b(Context paramContext, int paramInt) {
    this.n = paramInt;
    TextView textView = this.d;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public boolean b() {
    if (getVisibility() == 0) {
      ActionMenuView actionMenuView = this.c;
      if (actionMenuView != null && actionMenuView.i())
        return true; 
    } 
    return false;
  }
  
  public void c() {
    k k;
    d d1 = this.M;
    if (d1 == null) {
      d1 = null;
    } else {
      k = d1.d;
    } 
    if (k != null)
      k.collapseActionView(); 
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    boolean bool;
    if (super.checkLayoutParams(paramLayoutParams) && paramLayoutParams instanceof e) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void d() {
    ActionMenuView actionMenuView = this.c;
    if (actionMenuView != null)
      actionMenuView.d(); 
  }
  
  void e() {
    if (this.j == null) {
      this.j = new m(getContext(), null, a.b.h.a.a.toolbarNavigationButtonStyle);
      this.j.setImageDrawable(this.h);
      this.j.setContentDescription(this.i);
      e e1 = generateDefaultLayoutParams();
      e1.a = 0x800003 | this.p & 0x70;
      e1.b = 2;
      this.j.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.j.setOnClickListener(new c(this));
    } 
  }
  
  public boolean f() {
    boolean bool;
    d d1 = this.M;
    if (d1 != null && d1.d != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean g() {
    boolean bool;
    ActionMenuView actionMenuView = this.c;
    if (actionMenuView != null && actionMenuView.f()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  protected e generateDefaultLayoutParams() {
    return new e(-2, -2);
  }
  
  public e generateLayoutParams(AttributeSet paramAttributeSet) {
    return new e(getContext(), paramAttributeSet);
  }
  
  protected e generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof e) ? new e((e)paramLayoutParams) : ((paramLayoutParams instanceof android.support.v7.app.a.a) ? new e((android.support.v7.app.a.a)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new e((ViewGroup.MarginLayoutParams)paramLayoutParams) : new e(paramLayoutParams)));
  }
  
  public int getContentInsetEnd() {
    boolean bool;
    z0 z01 = this.v;
    if (z01 != null) {
      bool = z01.a();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int getContentInsetEndWithActions() {
    int i = this.x;
    if (i == Integer.MIN_VALUE)
      i = getContentInsetEnd(); 
    return i;
  }
  
  public int getContentInsetLeft() {
    boolean bool;
    z0 z01 = this.v;
    if (z01 != null) {
      bool = z01.b();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int getContentInsetRight() {
    boolean bool;
    z0 z01 = this.v;
    if (z01 != null) {
      bool = z01.c();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int getContentInsetStart() {
    boolean bool;
    z0 z01 = this.v;
    if (z01 != null) {
      bool = z01.d();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int getContentInsetStartWithNavigation() {
    int i = this.w;
    if (i == Integer.MIN_VALUE)
      i = getContentInsetStart(); 
    return i;
  }
  
  public int getCurrentContentInsetEnd() {
    int i = 0;
    ActionMenuView actionMenuView = this.c;
    if (actionMenuView != null) {
      h h = actionMenuView.j();
      if (h != null && h.hasVisibleItems()) {
        i = 1;
      } else {
        i = 0;
      } 
    } 
    if (i) {
      i = Math.max(getContentInsetEnd(), Math.max(this.x, 0));
    } else {
      i = getContentInsetEnd();
    } 
    return i;
  }
  
  public int getCurrentContentInsetLeft() {
    int i;
    if (u.k((View)this) == 1) {
      i = getCurrentContentInsetEnd();
    } else {
      i = getCurrentContentInsetStart();
    } 
    return i;
  }
  
  public int getCurrentContentInsetRight() {
    int i;
    if (u.k((View)this) == 1) {
      i = getCurrentContentInsetStart();
    } else {
      i = getCurrentContentInsetEnd();
    } 
    return i;
  }
  
  public int getCurrentContentInsetStart() {
    int i;
    if (getNavigationIcon() != null) {
      i = Math.max(getContentInsetStart(), Math.max(this.w, 0));
    } else {
      i = getContentInsetStart();
    } 
    return i;
  }
  
  public Drawable getLogo() {
    ImageView imageView = this.g;
    if (imageView != null) {
      Drawable drawable = imageView.getDrawable();
    } else {
      imageView = null;
    } 
    return (Drawable)imageView;
  }
  
  public CharSequence getLogoDescription() {
    ImageView imageView = this.g;
    if (imageView != null) {
      CharSequence charSequence = imageView.getContentDescription();
    } else {
      imageView = null;
    } 
    return (CharSequence)imageView;
  }
  
  public Menu getMenu() {
    n();
    return this.c.getMenu();
  }
  
  public CharSequence getNavigationContentDescription() {
    ImageButton imageButton = this.f;
    if (imageButton != null) {
      CharSequence charSequence = imageButton.getContentDescription();
    } else {
      imageButton = null;
    } 
    return (CharSequence)imageButton;
  }
  
  public Drawable getNavigationIcon() {
    ImageButton imageButton = this.f;
    if (imageButton != null) {
      Drawable drawable = imageButton.getDrawable();
    } else {
      imageButton = null;
    } 
    return (Drawable)imageButton;
  }
  
  c getOuterActionMenuPresenter() {
    return this.L;
  }
  
  public Drawable getOverflowIcon() {
    n();
    return this.c.getOverflowIcon();
  }
  
  Context getPopupContext() {
    return this.l;
  }
  
  public int getPopupTheme() {
    return this.m;
  }
  
  public CharSequence getSubtitle() {
    return this.A;
  }
  
  public CharSequence getTitle() {
    return this.z;
  }
  
  public int getTitleMarginBottom() {
    return this.u;
  }
  
  public int getTitleMarginEnd() {
    return this.s;
  }
  
  public int getTitleMarginStart() {
    return this.r;
  }
  
  public int getTitleMarginTop() {
    return this.t;
  }
  
  public f0 getWrapper() {
    if (this.K == null)
      this.K = new k1(this, true); 
    return this.K;
  }
  
  public boolean h() {
    boolean bool;
    ActionMenuView actionMenuView = this.c;
    if (actionMenuView != null && actionMenuView.g()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean i() {
    boolean bool;
    ActionMenuView actionMenuView = this.c;
    if (actionMenuView != null && actionMenuView.h()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  void j() {
    for (int i = getChildCount() - 1; i >= 0; i--) {
      View view = getChildAt(i);
      if (((e)view.getLayoutParams()).b != 2 && view != this.c) {
        removeViewAt(i);
        this.G.add(view);
      } 
    } 
  }
  
  public boolean k() {
    boolean bool;
    ActionMenuView actionMenuView = this.c;
    if (actionMenuView != null && actionMenuView.k()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    removeCallbacks(this.Q);
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.E = false; 
    if (!this.E) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.E = true; 
    } 
    if (i == 10 || i == 3)
      this.E = false; 
    return true;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    boolean bool;
    int i;
    if (u.k((View)this) == 1) {
      i = 1;
    } else {
      i = 0;
    } 
    int i1 = getWidth();
    int i3 = getHeight();
    int n = getPaddingLeft();
    int i2 = getPaddingRight();
    int k = getPaddingTop();
    int m = getPaddingBottom();
    paramInt1 = n;
    int j = i1 - i2;
    int[] arrayOfInt = this.H;
    arrayOfInt[1] = 0;
    arrayOfInt[0] = 0;
    paramInt3 = u.l((View)this);
    if (paramInt3 >= 0) {
      bool = Math.min(paramInt3, paramInt4 - paramInt2);
    } else {
      bool = false;
    } 
    paramInt4 = paramInt1;
    paramInt3 = j;
    if (d((View)this.f))
      if (i) {
        paramInt3 = b((View)this.f, j, arrayOfInt, bool);
        paramInt4 = paramInt1;
      } else {
        paramInt4 = a((View)this.f, paramInt1, arrayOfInt, bool);
        paramInt3 = j;
      }  
    paramInt2 = paramInt4;
    paramInt1 = paramInt3;
    if (d((View)this.j))
      if (i) {
        paramInt1 = b((View)this.j, paramInt3, arrayOfInt, bool);
        paramInt2 = paramInt4;
      } else {
        paramInt2 = a((View)this.j, paramInt4, arrayOfInt, bool);
        paramInt1 = paramInt3;
      }  
    paramInt4 = paramInt2;
    paramInt3 = paramInt1;
    if (d((View)this.c))
      if (i) {
        paramInt4 = a((View)this.c, paramInt2, arrayOfInt, bool);
        paramInt3 = paramInt1;
      } else {
        paramInt3 = b((View)this.c, paramInt1, arrayOfInt, bool);
        paramInt4 = paramInt2;
      }  
    paramInt2 = getCurrentContentInsetLeft();
    paramInt1 = getCurrentContentInsetRight();
    arrayOfInt[0] = Math.max(0, paramInt2 - paramInt4);
    arrayOfInt[1] = Math.max(0, paramInt1 - i1 - i2 - paramInt3);
    paramInt2 = Math.max(paramInt4, paramInt2);
    paramInt3 = Math.min(paramInt3, i1 - i2 - paramInt1);
    paramInt4 = paramInt2;
    paramInt1 = paramInt3;
    if (d(this.k))
      if (i) {
        paramInt1 = b(this.k, paramInt3, arrayOfInt, bool);
        paramInt4 = paramInt2;
      } else {
        paramInt4 = a(this.k, paramInt2, arrayOfInt, bool);
        paramInt1 = paramInt3;
      }  
    paramInt2 = paramInt4;
    paramInt3 = paramInt1;
    if (d((View)this.g))
      if (i) {
        paramInt3 = b((View)this.g, paramInt1, arrayOfInt, bool);
        paramInt2 = paramInt4;
      } else {
        paramInt2 = a((View)this.g, paramInt4, arrayOfInt, bool);
        paramInt3 = paramInt1;
      }  
    paramBoolean = d((View)this.d);
    boolean bool1 = d((View)this.e);
    paramInt1 = 0;
    if (paramBoolean) {
      e e1 = (e)this.d.getLayoutParams();
      paramInt1 = 0 + ((ViewGroup.MarginLayoutParams)e1).topMargin + this.d.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
    } 
    j = paramInt1;
    if (bool1) {
      e e1 = (e)this.e.getLayoutParams();
      j = paramInt1 + ((ViewGroup.MarginLayoutParams)e1).topMargin + this.e.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
    } 
    if (paramBoolean || bool1) {
      TextView textView1;
      TextView textView2;
      if (paramBoolean) {
        textView1 = this.d;
      } else {
        textView1 = this.e;
      } 
      if (bool1) {
        textView2 = this.e;
      } else {
        textView2 = this.d;
      } 
      e e1 = (e)textView1.getLayoutParams();
      e e2 = (e)textView2.getLayoutParams();
      if ((paramBoolean && this.d.getMeasuredWidth() > 0) || (bool1 && this.e.getMeasuredWidth() > 0)) {
        paramInt4 = 1;
      } else {
        paramInt4 = 0;
      } 
      paramInt1 = this.y & 0x70;
      if (paramInt1 != 48) {
        if (paramInt1 != 80) {
          paramInt1 = (i3 - k - m - j) / 2;
          int i5 = ((ViewGroup.MarginLayoutParams)e1).topMargin;
          int i4 = this.t;
          if (paramInt1 < i5 + i4) {
            paramInt1 = i5 + i4;
          } else {
            m = i3 - m - j - paramInt1 - k;
            i3 = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
            j = this.u;
            if (m < i3 + j)
              paramInt1 = Math.max(0, paramInt1 - ((ViewGroup.MarginLayoutParams)e2).bottomMargin + j - m); 
          } 
          paramInt1 = k + paramInt1;
        } else {
          paramInt1 = i3 - m - ((ViewGroup.MarginLayoutParams)e2).bottomMargin - this.u - j;
        } 
      } else {
        paramInt1 = getPaddingTop() + ((ViewGroup.MarginLayoutParams)e1).topMargin + this.t;
      } 
      j = paramInt2;
      if (i) {
        if (paramInt4 != 0) {
          paramInt2 = this.r;
        } else {
          paramInt2 = 0;
        } 
        i = paramInt2 - arrayOfInt[1];
        paramInt2 = paramInt3 - Math.max(0, i);
        arrayOfInt[1] = Math.max(0, -i);
        i = paramInt2;
        paramInt3 = paramInt2;
        if (paramBoolean) {
          e1 = (e)this.d.getLayoutParams();
          m = i - this.d.getMeasuredWidth();
          k = this.d.getMeasuredHeight() + paramInt1;
          this.d.layout(m, paramInt1, i, k);
          paramInt1 = m - this.s;
          k += ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          k = paramInt1;
          paramInt1 = i;
        } 
        i = paramInt3;
        if (bool1) {
          e1 = (e)this.e.getLayoutParams();
          i = k + ((ViewGroup.MarginLayoutParams)e1).topMargin;
          m = this.e.getMeasuredWidth();
          k = this.e.getMeasuredHeight() + i;
          this.e.layout(paramInt3 - m, i, paramInt3, k);
          i = paramInt3 - this.s;
          paramInt3 = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } 
        if (paramInt4 != 0)
          paramInt2 = Math.min(paramInt1, i); 
        paramInt1 = j;
      } else {
        if (paramInt4 != 0) {
          paramInt2 = this.r;
        } else {
          paramInt2 = 0;
        } 
        i = paramInt2 - arrayOfInt[0];
        paramInt2 = j + Math.max(0, i);
        arrayOfInt[0] = Math.max(0, -i);
        j = paramInt2;
        i = paramInt2;
        if (paramBoolean) {
          e1 = (e)this.d.getLayoutParams();
          m = this.d.getMeasuredWidth() + j;
          k = this.d.getMeasuredHeight() + paramInt1;
          this.d.layout(j, paramInt1, m, k);
          j = m + this.s;
          k += ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          k = paramInt1;
        } 
        paramInt1 = paramInt2;
        m = i;
        if (bool1) {
          e1 = (e)this.e.getLayoutParams();
          paramInt2 = k + ((ViewGroup.MarginLayoutParams)e1).topMargin;
          m = this.e.getMeasuredWidth() + i;
          k = this.e.getMeasuredHeight() + paramInt2;
          this.e.layout(i, paramInt2, m, k);
          m += this.s;
          paramInt2 = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } 
        paramInt2 = paramInt3;
        if (paramInt4 != 0) {
          paramInt1 = Math.max(j, m);
          paramInt2 = paramInt3;
        } 
      } 
    } else {
      paramInt1 = paramInt2;
      paramInt2 = paramInt3;
    } 
    a(this.F, 3);
    paramInt4 = this.F.size();
    for (paramInt3 = 0; paramInt3 < paramInt4; paramInt3++)
      paramInt1 = a(this.F.get(paramInt3), paramInt1, arrayOfInt, bool); 
    a(this.F, 5);
    paramInt4 = this.F.size();
    for (paramInt3 = 0; paramInt3 < paramInt4; paramInt3++)
      paramInt2 = b(this.F.get(paramInt3), paramInt2, arrayOfInt, bool); 
    a(this.F, 1);
    paramInt4 = a(this.F, arrayOfInt);
    paramInt3 = n + (i1 - n - i2) / 2 - paramInt4 / 2;
    paramInt4 = paramInt3 + paramInt4;
    if (paramInt3 >= paramInt1) {
      paramInt1 = paramInt3;
      if (paramInt4 > paramInt2)
        paramInt1 = paramInt3 - paramInt4 - paramInt2; 
    } 
    paramInt3 = this.F.size();
    paramInt2 = paramInt1;
    for (paramInt1 = 0; paramInt1 < paramInt3; paramInt1++)
      paramInt2 = a(this.F.get(paramInt1), paramInt2, arrayOfInt, bool); 
    this.F.clear();
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int m = 0;
    int k = 0;
    int[] arrayOfInt = this.H;
    if (r1.a((View)this)) {
      i2 = 1;
      i1 = 0;
    } else {
      i2 = 0;
      i1 = 1;
    } 
    int n = 0;
    if (d((View)this.f)) {
      a((View)this.f, paramInt1, 0, paramInt2, 0, this.q);
      n = this.f.getMeasuredWidth() + a((View)this.f);
      m = Math.max(0, this.f.getMeasuredHeight() + b((View)this.f));
      k = View.combineMeasuredStates(0, this.f.getMeasuredState());
    } 
    int j = m;
    int i = k;
    if (d((View)this.j)) {
      a((View)this.j, paramInt1, 0, paramInt2, 0, this.q);
      n = this.j.getMeasuredWidth() + a((View)this.j);
      j = Math.max(m, this.j.getMeasuredHeight() + b((View)this.j));
      i = View.combineMeasuredStates(k, this.j.getMeasuredState());
    } 
    k = getCurrentContentInsetStart();
    m = 0 + Math.max(k, n);
    arrayOfInt[i2] = Math.max(0, k - n);
    if (d((View)this.c)) {
      a((View)this.c, paramInt1, m, paramInt2, 0, this.q);
      i2 = this.c.getMeasuredWidth();
      n = a((View)this.c);
      j = Math.max(j, this.c.getMeasuredHeight() + b((View)this.c));
      k = View.combineMeasuredStates(i, this.c.getMeasuredState());
      i = i2 + n;
    } else {
      k = i;
      i = 0;
    } 
    int i2 = getCurrentContentInsetEnd();
    n = m + Math.max(i2, i);
    arrayOfInt[i1] = Math.max(0, i2 - i);
    if (d(this.k)) {
      i1 = n + a(this.k, paramInt1, n, paramInt2, 0, arrayOfInt);
      m = Math.max(j, this.k.getMeasuredHeight() + b(this.k));
      k = View.combineMeasuredStates(k, this.k.getMeasuredState());
    } else {
      m = j;
      i1 = n;
    } 
    i2 = i1;
    n = m;
    j = k;
    if (d((View)this.g)) {
      i2 = i1 + a((View)this.g, paramInt1, i1, paramInt2, 0, arrayOfInt);
      n = Math.max(m, this.g.getMeasuredHeight() + b((View)this.g));
      j = View.combineMeasuredStates(k, this.g.getMeasuredState());
    } 
    m = getChildCount();
    int i3 = n;
    int i1 = i2;
    n = 0;
    k = i;
    i = i3;
    while (n < m) {
      View view = getChildAt(n);
      if (((e)view.getLayoutParams()).b == 0 && d(view)) {
        i1 += a(view, paramInt1, i1, paramInt2, 0, arrayOfInt);
        i = Math.max(i, view.getMeasuredHeight() + b(view));
        j = View.combineMeasuredStates(j, view.getMeasuredState());
      } 
      n++;
    } 
    n = 0;
    k = 0;
    i2 = this.t + this.u;
    i3 = this.r + this.s;
    m = j;
    if (d((View)this.d)) {
      a((View)this.d, paramInt1, i1 + i3, paramInt2, i2, arrayOfInt);
      n = this.d.getMeasuredWidth() + a((View)this.d);
      k = this.d.getMeasuredHeight() + b((View)this.d);
      m = View.combineMeasuredStates(j, this.d.getMeasuredState());
    } 
    if (d((View)this.e)) {
      n = Math.max(n, a((View)this.e, paramInt1, i1 + i3, paramInt2, k + i2, arrayOfInt));
      i2 = this.e.getMeasuredHeight();
      j = b((View)this.e);
      m = View.combineMeasuredStates(m, this.e.getMeasuredState());
      j = k + i2 + j;
    } else {
      j = k;
    } 
    k = Math.max(i, j);
    i2 = getPaddingLeft();
    i3 = getPaddingRight();
    j = getPaddingTop();
    i = getPaddingBottom();
    n = View.resolveSizeAndState(Math.max(i1 + n + i2 + i3, getSuggestedMinimumWidth()), paramInt1, 0xFF000000 & m);
    paramInt1 = View.resolveSizeAndState(Math.max(k + j + i, getSuggestedMinimumHeight()), paramInt2, m << 16);
    if (r())
      paramInt1 = 0; 
    setMeasuredDimension(n, paramInt1);
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof g)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    g g = (g)paramParcelable;
    super.onRestoreInstanceState(g.a());
    ActionMenuView actionMenuView = this.c;
    if (actionMenuView != null) {
      h h = actionMenuView.j();
    } else {
      actionMenuView = null;
    } 
    int i = g.e;
    if (i != 0 && this.M != null && actionMenuView != null) {
      MenuItem menuItem = actionMenuView.findItem(i);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
    if (g.f)
      q(); 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    if (Build.VERSION.SDK_INT >= 17)
      super.onRtlPropertiesChanged(paramInt); 
    l();
    z0 z01 = this.v;
    boolean bool = true;
    if (paramInt != 1)
      bool = false; 
    z01.a(bool);
  }
  
  protected Parcelable onSaveInstanceState() {
    g g = new g(super.onSaveInstanceState());
    d d1 = this.M;
    if (d1 != null) {
      k k = d1.d;
      if (k != null)
        g.e = k.getItemId(); 
    } 
    g.f = i();
    return (Parcelable)g;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.D = false; 
    if (!this.D) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.D = true; 
    } 
    if (i == 1 || i == 3)
      this.D = false; 
    return true;
  }
  
  public void setCollapsible(boolean paramBoolean) {
    this.P = paramBoolean;
    requestLayout();
  }
  
  public void setContentInsetEndWithActions(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.x) {
      this.x = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setContentInsetStartWithNavigation(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.w) {
      this.w = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setLogo(int paramInt) {
    setLogo(a.b.h.c.a.a.c(getContext(), paramInt));
  }
  
  public void setLogo(Drawable paramDrawable) {
    if (paramDrawable != null) {
      m();
      if (!c((View)this.g))
        a((View)this.g, true); 
    } else {
      ImageView imageView1 = this.g;
      if (imageView1 != null && c((View)imageView1)) {
        removeView((View)this.g);
        this.G.remove(this.g);
      } 
    } 
    ImageView imageView = this.g;
    if (imageView != null)
      imageView.setImageDrawable(paramDrawable); 
  }
  
  public void setLogoDescription(int paramInt) {
    setLogoDescription(getContext().getText(paramInt));
  }
  
  public void setLogoDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      m(); 
    ImageView imageView = this.g;
    if (imageView != null)
      imageView.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setNavigationContentDescription(charSequence);
  }
  
  public void setNavigationContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      p(); 
    ImageButton imageButton = this.f;
    if (imageButton != null)
      imageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationIcon(int paramInt) {
    setNavigationIcon(a.b.h.c.a.a.c(getContext(), paramInt));
  }
  
  public void setNavigationIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      p();
      if (!c((View)this.f))
        a((View)this.f, true); 
    } else {
      ImageButton imageButton1 = this.f;
      if (imageButton1 != null && c((View)imageButton1)) {
        removeView((View)this.f);
        this.G.remove(this.f);
      } 
    } 
    ImageButton imageButton = this.f;
    if (imageButton != null)
      imageButton.setImageDrawable(paramDrawable); 
  }
  
  public void setNavigationOnClickListener(View.OnClickListener paramOnClickListener) {
    p();
    this.f.setOnClickListener(paramOnClickListener);
  }
  
  public void setOnMenuItemClickListener(f paramf) {
    this.I = paramf;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    n();
    this.c.setOverflowIcon(paramDrawable);
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.m != paramInt) {
      this.m = paramInt;
      if (paramInt == 0) {
        this.l = getContext();
      } else {
        this.l = (Context)new ContextThemeWrapper(getContext(), paramInt);
      } 
    } 
  }
  
  public void setSubtitle(int paramInt) {
    setSubtitle(getContext().getText(paramInt));
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.e == null) {
        Context context = getContext();
        this.e = new AppCompatTextView(context);
        this.e.setSingleLine();
        this.e.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.o;
        if (i != 0)
          this.e.setTextAppearance(context, i); 
        i = this.C;
        if (i != 0)
          this.e.setTextColor(i); 
      } 
      if (!c((View)this.e))
        a((View)this.e, true); 
    } else {
      TextView textView1 = this.e;
      if (textView1 != null && c((View)textView1)) {
        removeView((View)this.e);
        this.G.remove(this.e);
      } 
    } 
    TextView textView = this.e;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.A = paramCharSequence;
  }
  
  public void setSubtitleTextColor(int paramInt) {
    this.C = paramInt;
    TextView textView = this.e;
    if (textView != null)
      textView.setTextColor(paramInt); 
  }
  
  public void setTitle(int paramInt) {
    setTitle(getContext().getText(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.d == null) {
        Context context = getContext();
        this.d = new AppCompatTextView(context);
        this.d.setSingleLine();
        this.d.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.n;
        if (i != 0)
          this.d.setTextAppearance(context, i); 
        i = this.B;
        if (i != 0)
          this.d.setTextColor(i); 
      } 
      if (!c((View)this.d))
        a((View)this.d, true); 
    } else {
      TextView textView1 = this.d;
      if (textView1 != null && c((View)textView1)) {
        removeView((View)this.d);
        this.G.remove(this.d);
      } 
    } 
    TextView textView = this.d;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.z = paramCharSequence;
  }
  
  public void setTitleMarginBottom(int paramInt) {
    this.u = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginEnd(int paramInt) {
    this.s = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginStart(int paramInt) {
    this.r = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginTop(int paramInt) {
    this.t = paramInt;
    requestLayout();
  }
  
  public void setTitleTextColor(int paramInt) {
    this.B = paramInt;
    TextView textView = this.d;
    if (textView != null)
      textView.setTextColor(paramInt); 
  }
  
  class a implements ActionMenuView.e {
    final Toolbar a;
    
    a(Toolbar this$0) {}
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      Toolbar.f f = this.a.I;
      return (f != null) ? f.onMenuItemClick(param1MenuItem) : false;
    }
  }
  
  class b implements Runnable {
    final Toolbar c;
    
    b(Toolbar this$0) {}
    
    public void run() {
      this.c.k();
    }
  }
  
  class c implements View.OnClickListener {
    final Toolbar c;
    
    c(Toolbar this$0) {}
    
    public void onClick(View param1View) {
      this.c.c();
    }
  }
  
  private class d implements p {
    h c;
    
    k d;
    
    final Toolbar e;
    
    d(Toolbar this$0) {}
    
    public int a() {
      return 0;
    }
    
    public void a(Context param1Context, h param1h) {
      h h1 = this.c;
      if (h1 != null) {
        k k1 = this.d;
        if (k1 != null)
          h1.a(k1); 
      } 
      this.c = param1h;
    }
    
    public void a(Parcelable param1Parcelable) {}
    
    public void a(h param1h, boolean param1Boolean) {}
    
    public void a(boolean param1Boolean) {
      if (this.d != null) {
        boolean bool2 = false;
        h h1 = this.c;
        boolean bool1 = bool2;
        if (h1 != null) {
          int i = h1.size();
          byte b = 0;
          while (true) {
            bool1 = bool2;
            if (b < i) {
              if (this.c.getItem(b) == this.d) {
                bool1 = true;
                break;
              } 
              b++;
              continue;
            } 
            break;
          } 
        } 
        if (!bool1)
          a(this.c, this.d); 
      } 
    }
    
    public boolean a(h param1h, k param1k) {
      View view = this.e.k;
      if (view instanceof a.b.h.f.c)
        ((a.b.h.f.c)view).c(); 
      Toolbar toolbar = this.e;
      toolbar.removeView(toolbar.k);
      toolbar = this.e;
      toolbar.removeView((View)toolbar.j);
      toolbar = this.e;
      toolbar.k = null;
      toolbar.a();
      this.d = null;
      this.e.requestLayout();
      param1k.a(false);
      return true;
    }
    
    public boolean a(v param1v) {
      return false;
    }
    
    public boolean b() {
      return false;
    }
    
    public boolean b(h param1h, k param1k) {
      this.e.e();
      ViewParent viewParent = this.e.j.getParent();
      Toolbar toolbar = this.e;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView((View)toolbar.j); 
        Toolbar toolbar1 = this.e;
        toolbar1.addView((View)toolbar1.j);
      } 
      this.e.k = param1k.getActionView();
      this.d = param1k;
      viewParent = this.e.k.getParent();
      toolbar = this.e;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView(toolbar.k); 
        Toolbar.e e = this.e.generateDefaultLayoutParams();
        Toolbar toolbar1 = this.e;
        e.a = 0x800003 | toolbar1.p & 0x70;
        e.b = 2;
        toolbar1.k.setLayoutParams((ViewGroup.LayoutParams)e);
        toolbar1 = this.e;
        toolbar1.addView(toolbar1.k);
      } 
      this.e.j();
      this.e.requestLayout();
      param1k.a(true);
      View view = this.e.k;
      if (view instanceof a.b.h.f.c)
        ((a.b.h.f.c)view).b(); 
      return true;
    }
    
    public Parcelable c() {
      return null;
    }
  }
  
  public static class e extends android.support.v7.app.a.a {
    int b = 0;
    
    public e(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = 8388627;
    }
    
    public e(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public e(android.support.v7.app.a.a param1a) {
      super(param1a);
    }
    
    public e(e param1e) {
      super(param1e);
      this.b = param1e.b;
    }
    
    public e(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public e(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super((ViewGroup.LayoutParams)param1MarginLayoutParams);
      a(param1MarginLayoutParams);
    }
    
    void a(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      ((ViewGroup.MarginLayoutParams)this).leftMargin = param1MarginLayoutParams.leftMargin;
      ((ViewGroup.MarginLayoutParams)this).topMargin = param1MarginLayoutParams.topMargin;
      ((ViewGroup.MarginLayoutParams)this).rightMargin = param1MarginLayoutParams.rightMargin;
      ((ViewGroup.MarginLayoutParams)this).bottomMargin = param1MarginLayoutParams.bottomMargin;
    }
  }
  
  public static interface f {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
  
  public static class g extends android.support.v4.view.a {
    public static final Parcelable.Creator<g> CREATOR = (Parcelable.Creator<g>)new a();
    
    int e;
    
    boolean f;
    
    public g(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      boolean bool;
      this.e = param1Parcel.readInt();
      if (param1Parcel.readInt() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.f = bool;
    }
    
    public g(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.e);
      param1Parcel.writeInt(this.f);
    }
    
    static final class a implements Parcelable.ClassLoaderCreator<g> {
      public Toolbar.g createFromParcel(Parcel param2Parcel) {
        return new Toolbar.g(param2Parcel, null);
      }
      
      public Toolbar.g createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new Toolbar.g(param2Parcel, param2ClassLoader);
      }
      
      public Toolbar.g[] newArray(int param2Int) {
        return new Toolbar.g[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.ClassLoaderCreator<g> {
    public Toolbar.g createFromParcel(Parcel param1Parcel) {
      return new Toolbar.g(param1Parcel, null);
    }
    
    public Toolbar.g createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new Toolbar.g(param1Parcel, param1ClassLoader);
    }
    
    public Toolbar.g[] newArray(int param1Int) {
      return new Toolbar.g[param1Int];
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\Toolbar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */