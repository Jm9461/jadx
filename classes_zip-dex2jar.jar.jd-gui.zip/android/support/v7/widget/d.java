package android.support.v7.widget;

import a.b.g.g.j;
import a.b.g.g.k;
import java.util.ArrayList;
import java.util.List;

class d implements s0.a {
  private j<b> a = (j<b>)new k(30);
  
  final ArrayList<b> b = new ArrayList<b>();
  
  final ArrayList<b> c = new ArrayList<b>();
  
  final a d;
  
  Runnable e;
  
  final boolean f;
  
  final s0 g;
  
  private int h = 0;
  
  d(a parama) {
    this(parama, false);
  }
  
  d(a parama, boolean paramBoolean) {
    this.d = parama;
    this.f = paramBoolean;
    this.g = new s0(this);
  }
  
  private int b(int paramInt1, int paramInt2) {
    int k = this.c.size() - 1;
    int i;
    for (i = paramInt1; k >= 0; i = paramInt1) {
      b b = this.c.get(k);
      int m = b.a;
      if (m == 8) {
        if (b.b < b.d) {
          paramInt1 = b.b;
          m = b.d;
        } else {
          paramInt1 = b.d;
          m = b.b;
        } 
        if (i >= paramInt1 && i <= m) {
          m = b.b;
          if (paramInt1 == m) {
            if (paramInt2 == 1) {
              b.d++;
            } else if (paramInt2 == 2) {
              b.d--;
            } 
            paramInt1 = i + 1;
          } else {
            if (paramInt2 == 1) {
              b.b = m + 1;
            } else if (paramInt2 == 2) {
              b.b = m - 1;
            } 
            paramInt1 = i - 1;
          } 
        } else {
          m = b.b;
          paramInt1 = i;
          if (i < m)
            if (paramInt2 == 1) {
              b.b = m + 1;
              b.d++;
              paramInt1 = i;
            } else {
              paramInt1 = i;
              if (paramInt2 == 2) {
                b.b = m - 1;
                b.d--;
                paramInt1 = i;
              } 
            }  
        } 
      } else {
        int n = b.b;
        if (n <= i) {
          if (m == 1) {
            paramInt1 = i - b.d;
          } else {
            paramInt1 = i;
            if (m == 2)
              paramInt1 = i + b.d; 
          } 
        } else if (paramInt2 == 1) {
          b.b = n + 1;
          paramInt1 = i;
        } else {
          paramInt1 = i;
          if (paramInt2 == 2) {
            b.b = n - 1;
            paramInt1 = i;
          } 
        } 
      } 
      k--;
    } 
    for (paramInt1 = this.c.size() - 1; paramInt1 >= 0; paramInt1--) {
      b b = this.c.get(paramInt1);
      if (b.a == 8) {
        paramInt2 = b.d;
        if (paramInt2 == b.b || paramInt2 < 0) {
          this.c.remove(paramInt1);
          a(b);
        } 
      } else if (b.d <= 0) {
        this.c.remove(paramInt1);
        a(b);
      } 
    } 
    return i;
  }
  
  private void b(b paramb) {
    g(paramb);
  }
  
  private void c(b paramb) {
    g(paramb);
  }
  
  private void d(b paramb) {
    int n = paramb.b;
    int m = 0;
    int k = paramb.b + paramb.d;
    byte b1 = -1;
    for (int i = paramb.b; i < k; i = i1) {
      byte b3 = 0;
      int i1 = 0;
      if (this.d.a(i) != null || d(i)) {
        if (b1 == 0) {
          f(a(2, n, m, null));
          b3 = 1;
        } 
        b1 = 1;
        i1 = b3;
        b3 = b1;
      } else {
        if (b1 == 1) {
          g(a(2, n, m, null));
          i1 = 1;
        } 
        b3 = 0;
      } 
      if (i1 != 0) {
        i1 = i - m;
        k -= m;
        i = 1;
      } else {
        m++;
        i1 = i;
        i = m;
      } 
      i1++;
      m = i;
      b1 = b3;
    } 
    b b2 = paramb;
    if (m != paramb.d) {
      a(paramb);
      b2 = a(2, n, m, null);
    } 
    if (b1 == 0) {
      f(b2);
    } else {
      g(b2);
    } 
  }
  
  private boolean d(int paramInt) {
    int i = this.c.size();
    for (byte b = 0; b < i; b++) {
      b b1 = this.c.get(b);
      int k = b1.a;
      if (k == 8) {
        if (a(b1.d, b + 1) == paramInt)
          return true; 
      } else if (k == 1) {
        int n = b1.b;
        int m = b1.d;
        for (k = b1.b; k < n + m; k++) {
          if (a(k, b + 1) == paramInt)
            return true; 
        } 
      } 
    } 
    return false;
  }
  
  private void e(b paramb) {
    int m = paramb.b;
    int k = 0;
    int i1 = paramb.b;
    int i2 = paramb.d;
    int n = -1;
    int i = paramb.b;
    while (i < i1 + i2) {
      int i3;
      int i4;
      if (this.d.a(i) != null || d(i)) {
        int i5 = m;
        i4 = k;
        if (n == 0) {
          f(a(4, m, k, paramb.c));
          i4 = 0;
          i5 = i;
        } 
        i3 = 1;
        m = i5;
      } else {
        int i5 = m;
        i3 = k;
        if (n == 1) {
          g(a(4, m, k, paramb.c));
          i3 = 0;
          i5 = i;
        } 
        k = 0;
        m = i5;
        i4 = i3;
        i3 = k;
      } 
      k = i4 + 1;
      i++;
      n = i3;
    } 
    Object object = paramb;
    if (k != paramb.d) {
      object = paramb.c;
      a(paramb);
      object = a(4, m, k, object);
    } 
    if (n == 0) {
      f((b)object);
    } else {
      g((b)object);
    } 
  }
  
  private void f(b paramb) {
    int i = paramb.a;
    if (i != 1 && i != 8) {
      byte b1;
      int m = b(paramb.b, i);
      int n = 1;
      i = paramb.b;
      int k = paramb.a;
      if (k != 2) {
        if (k == 4) {
          b1 = 1;
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("op should be remove or update.");
          stringBuilder.append(paramb);
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } else {
        b1 = 0;
      } 
      byte b2 = 1;
      while (b2 < paramb.d) {
        int i1 = b(paramb.b + b1 * b2, paramb.a);
        boolean bool2 = false;
        int i2 = paramb.a;
        boolean bool1 = false;
        k = 0;
        if (i2 != 2) {
          if (i2 != 4) {
            k = bool2;
          } else if (i1 == m + 1) {
            k = 1;
          } 
        } else {
          k = bool1;
          if (i1 == m)
            k = 1; 
        } 
        if (k != 0) {
          k = n + 1;
        } else {
          b b3 = a(paramb.a, m, n, paramb.c);
          a(b3, i);
          a(b3);
          k = i;
          if (paramb.a == 4)
            k = i + n; 
          m = i1;
          n = 1;
          i = k;
          k = n;
        } 
        b2++;
        n = k;
      } 
      Object object = paramb.c;
      a(paramb);
      if (n > 0) {
        paramb = a(paramb.a, m, n, object);
        a(paramb, i);
        a(paramb);
      } 
      return;
    } 
    IllegalArgumentException illegalArgumentException = new IllegalArgumentException("should not dispatch add or move for pre layout");
    throw illegalArgumentException;
  }
  
  private void g(b paramb) {
    this.c.add(paramb);
    int i = paramb.a;
    if (i != 1) {
      if (i != 2) {
        if (i != 4) {
          if (i == 8) {
            this.d.a(paramb.b, paramb.d);
          } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unknown update op type for ");
            stringBuilder.append(paramb);
            throw new IllegalArgumentException(stringBuilder.toString());
          } 
        } else {
          this.d.a(paramb.b, paramb.d, paramb.c);
        } 
      } else {
        this.d.c(paramb.b, paramb.d);
      } 
    } else {
      this.d.d(paramb.b, paramb.d);
    } 
  }
  
  public int a(int paramInt) {
    int k = this.b.size();
    byte b = 0;
    int i;
    for (i = paramInt; b < k; i = paramInt) {
      b b1 = this.b.get(b);
      paramInt = b1.a;
      if (paramInt != 1) {
        if (paramInt != 2) {
          if (paramInt != 8) {
            paramInt = i;
          } else {
            paramInt = b1.b;
            if (paramInt == i) {
              paramInt = b1.d;
            } else {
              int m = i;
              if (paramInt < i)
                m = i - 1; 
              paramInt = m;
              if (b1.d <= m)
                paramInt = m + 1; 
            } 
          } 
        } else {
          int m = b1.b;
          paramInt = i;
          if (m <= i) {
            paramInt = b1.d;
            if (m + paramInt > i)
              return -1; 
            paramInt = i - paramInt;
          } 
        } 
      } else {
        paramInt = i;
        if (b1.b <= i)
          paramInt = i + b1.d; 
      } 
      b++;
    } 
    return i;
  }
  
  int a(int paramInt1, int paramInt2) {
    int k = this.c.size();
    int i = paramInt2;
    for (paramInt2 = paramInt1; i < k; paramInt2 = paramInt1) {
      b b = this.c.get(i);
      int m = b.a;
      if (m == 8) {
        paramInt1 = b.b;
        if (paramInt1 == paramInt2) {
          paramInt1 = b.d;
        } else {
          int n = paramInt2;
          if (paramInt1 < paramInt2)
            n = paramInt2 - 1; 
          paramInt1 = n;
          if (b.d <= n)
            paramInt1 = n + 1; 
        } 
      } else {
        int n = b.b;
        paramInt1 = paramInt2;
        if (n <= paramInt2)
          if (m == 2) {
            paramInt1 = b.d;
            if (paramInt2 < n + paramInt1)
              return -1; 
            paramInt1 = paramInt2 - paramInt1;
          } else {
            paramInt1 = paramInt2;
            if (m == 1)
              paramInt1 = paramInt2 + b.d; 
          }  
      } 
      i++;
    } 
    return paramInt2;
  }
  
  public b a(int paramInt1, int paramInt2, int paramInt3, Object paramObject) {
    b b = (b)this.a.a();
    if (b == null) {
      paramObject = new b(paramInt1, paramInt2, paramInt3, paramObject);
    } else {
      b.a = paramInt1;
      b.b = paramInt2;
      b.d = paramInt3;
      b.c = paramObject;
      paramObject = b;
    } 
    return (b)paramObject;
  }
  
  void a() {
    int i = this.c.size();
    for (byte b = 0; b < i; b++)
      this.d.b(this.c.get(b)); 
    a(this.c);
    this.h = 0;
  }
  
  public void a(b paramb) {
    if (!this.f) {
      paramb.c = null;
      this.a.a(paramb);
    } 
  }
  
  void a(b paramb, int paramInt) {
    this.d.a(paramb);
    int i = paramb.a;
    if (i != 2) {
      if (i == 4) {
        this.d.a(paramInt, paramb.d, paramb.c);
      } else {
        throw new IllegalArgumentException("only remove and update ops can be dispatched in first pass");
      } 
    } else {
      this.d.b(paramInt, paramb.d);
    } 
  }
  
  void a(List<b> paramList) {
    int i = paramList.size();
    for (byte b = 0; b < i; b++)
      a(paramList.get(b)); 
    paramList.clear();
  }
  
  boolean a(int paramInt1, int paramInt2, Object paramObject) {
    boolean bool = false;
    if (paramInt2 < 1)
      return false; 
    this.b.add(a(4, paramInt1, paramInt2, paramObject));
    this.h |= 0x4;
    if (this.b.size() == 1)
      bool = true; 
    return bool;
  }
  
  int b(int paramInt) {
    return a(paramInt, 0);
  }
  
  void b() {
    a();
    int i = this.b.size();
    for (byte b = 0; b < i; b++) {
      b b1 = this.b.get(b);
      int k = b1.a;
      if (k != 1) {
        if (k != 2) {
          if (k != 4) {
            if (k == 8) {
              this.d.b(b1);
              this.d.a(b1.b, b1.d);
            } 
          } else {
            this.d.b(b1);
            this.d.a(b1.b, b1.d, b1.c);
          } 
        } else {
          this.d.b(b1);
          this.d.b(b1.b, b1.d);
        } 
      } else {
        this.d.b(b1);
        this.d.d(b1.b, b1.d);
      } 
      Runnable runnable = this.e;
      if (runnable != null)
        runnable.run(); 
    } 
    a(this.b);
    this.h = 0;
  }
  
  boolean c() {
    boolean bool;
    if (this.b.size() > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  boolean c(int paramInt) {
    boolean bool;
    if ((this.h & paramInt) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  boolean d() {
    boolean bool;
    if (!this.c.isEmpty() && !this.b.isEmpty()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  void e() {
    this.g.a(this.b);
    int i = this.b.size();
    for (byte b = 0; b < i; b++) {
      b b1 = this.b.get(b);
      int k = b1.a;
      if (k != 1) {
        if (k != 2) {
          if (k != 4) {
            if (k == 8)
              c(b1); 
          } else {
            e(b1);
          } 
        } else {
          d(b1);
        } 
      } else {
        b(b1);
      } 
      Runnable runnable = this.e;
      if (runnable != null)
        runnable.run(); 
    } 
    this.b.clear();
  }
  
  void f() {
    a(this.b);
    a(this.c);
    this.h = 0;
  }
  
  static interface a {
    RecyclerView.d0 a(int param1Int);
    
    void a(int param1Int1, int param1Int2);
    
    void a(int param1Int1, int param1Int2, Object param1Object);
    
    void a(d.b param1b);
    
    void b(int param1Int1, int param1Int2);
    
    void b(d.b param1b);
    
    void c(int param1Int1, int param1Int2);
    
    void d(int param1Int1, int param1Int2);
  }
  
  static class b {
    int a;
    
    int b;
    
    Object c;
    
    int d;
    
    b(int param1Int1, int param1Int2, int param1Int3, Object param1Object) {
      this.a = param1Int1;
      this.b = param1Int2;
      this.d = param1Int3;
      this.c = param1Object;
    }
    
    String a() {
      int i = this.a;
      return (i != 1) ? ((i != 2) ? ((i != 4) ? ((i != 8) ? "??" : "mv") : "up") : "rm") : "add";
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object == null || getClass() != param1Object.getClass())
        return false; 
      param1Object = param1Object;
      int i = this.a;
      if (i != ((b)param1Object).a)
        return false; 
      if (i == 8 && Math.abs(this.d - this.b) == 1 && this.d == ((b)param1Object).b && this.b == ((b)param1Object).d)
        return true; 
      if (this.d != ((b)param1Object).d)
        return false; 
      if (this.b != ((b)param1Object).b)
        return false; 
      Object object = this.c;
      if (object != null) {
        if (!object.equals(((b)param1Object).c))
          return false; 
      } else if (((b)param1Object).c != null) {
        return false;
      } 
      return true;
    }
    
    public int hashCode() {
      return (this.a * 31 + this.b) * 31 + this.d;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append("[");
      stringBuilder.append(a());
      stringBuilder.append(",s:");
      stringBuilder.append(this.b);
      stringBuilder.append("c:");
      stringBuilder.append(this.d);
      stringBuilder.append(",p:");
      stringBuilder.append(this.c);
      stringBuilder.append("]");
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */