package android.support.v7.widget;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.os.Build;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class g1 extends ContextWrapper {
  private static final Object c = new Object();
  
  private static ArrayList<WeakReference<g1>> d;
  
  private final Resources a;
  
  private final Resources.Theme b;
  
  private g1(Context paramContext) {
    super(paramContext);
    if (o1.b()) {
      this.a = new o1((Context)this, paramContext.getResources());
      this.b = this.a.newTheme();
      this.b.setTo(paramContext.getTheme());
    } else {
      this.a = new i1((Context)this, paramContext.getResources());
      this.b = null;
    } 
  }
  
  private static boolean a(Context paramContext) {
    boolean bool1 = paramContext instanceof g1;
    boolean bool = false;
    if (bool1 || paramContext.getResources() instanceof i1 || paramContext.getResources() instanceof o1)
      return false; 
    if (Build.VERSION.SDK_INT < 21 || o1.b())
      bool = true; 
    return bool;
  }
  
  public static Context b(Context paramContext) {
    if (a(paramContext))
      synchronized (c) {
        if (d == null) {
          ArrayList<WeakReference<g1>> arrayList1 = new ArrayList();
          this();
          d = arrayList1;
        } else {
          int i;
          for (i = d.size() - 1; i >= 0; i--) {
            WeakReference weakReference1 = d.get(i);
            if (weakReference1 == null || weakReference1.get() == null)
              d.remove(i); 
          } 
          for (i = d.size() - 1; i >= 0; i--) {
            WeakReference<g1> weakReference1 = d.get(i);
            if (weakReference1 != null) {
              g1 g12 = weakReference1.get();
            } else {
              weakReference1 = null;
            } 
            if (weakReference1 != null && weakReference1.getBaseContext() == paramContext)
              return (Context)weakReference1; 
          } 
        } 
        g1 g11 = new g1();
        this(paramContext);
        ArrayList<WeakReference<g1>> arrayList = d;
        WeakReference<g1> weakReference = new WeakReference();
        this((T)g11);
        arrayList.add(weakReference);
        return (Context)g11;
      }  
    return paramContext;
  }
  
  public AssetManager getAssets() {
    return this.a.getAssets();
  }
  
  public Resources getResources() {
    return this.a;
  }
  
  public Resources.Theme getTheme() {
    Resources.Theme theme2 = this.b;
    Resources.Theme theme1 = theme2;
    if (theme2 == null)
      theme1 = super.getTheme(); 
    return theme1;
  }
  
  public void setTheme(int paramInt) {
    Resources.Theme theme = this.b;
    if (theme == null) {
      super.setTheme(paramInt);
    } else {
      theme.applyStyle(paramInt, true);
    } 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\g1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */