package android.support.v7.widget;

import a.b.h.a.a;
import a.b.h.c.a.a;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.v4.view.t;
import android.support.v4.widget.p;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;

public class e extends AutoCompleteTextView implements t {
  private static final int[] e = new int[] { 16843126 };
  
  private final f c;
  
  private final w d;
  
  public e(Context paramContext) {
    this(paramContext, null);
  }
  
  public e(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.autoCompleteTextViewStyle);
  }
  
  public e(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(g1.b(paramContext), paramAttributeSet, paramInt);
    j1 j1 = j1.a(getContext(), paramAttributeSet, e, paramInt, 0);
    if (j1.g(0))
      setDropDownBackgroundDrawable(j1.b(0)); 
    j1.a();
    this.c = new f((View)this);
    this.c.a(paramAttributeSet, paramInt);
    this.d = new w((TextView)this);
    this.d.a(paramAttributeSet, paramInt);
    this.d.a();
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    f f1 = this.c;
    if (f1 != null)
      f1.a(); 
    w w1 = this.d;
    if (w1 != null)
      w1.a(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    f f1 = this.c;
    if (f1 != null) {
      ColorStateList colorStateList = f1.b();
    } else {
      f1 = null;
    } 
    return (ColorStateList)f1;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    f f1 = this.c;
    if (f1 != null) {
      PorterDuff.Mode mode = f1.c();
    } else {
      f1 = null;
    } 
    return (PorterDuff.Mode)f1;
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = super.onCreateInputConnection(paramEditorInfo);
    l.a(inputConnection, paramEditorInfo, (View)this);
    return inputConnection;
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    f f1 = this.c;
    if (f1 != null)
      f1.a(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    f f1 = this.c;
    if (f1 != null)
      f1.a(paramInt); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(p.a((TextView)this, paramCallback));
  }
  
  public void setDropDownBackgroundResource(int paramInt) {
    setDropDownBackgroundDrawable(a.c(getContext(), paramInt));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    f f1 = this.c;
    if (f1 != null)
      f1.b(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    f f1 = this.c;
    if (f1 != null)
      f1.a(paramMode); 
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    w w1 = this.d;
    if (w1 != null)
      w1.a(paramContext, paramInt); 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */