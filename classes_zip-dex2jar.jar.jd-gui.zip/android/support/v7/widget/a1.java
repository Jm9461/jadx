package android.support.v7.widget;

import android.view.View;

class a1 {
  static int a(RecyclerView.a0 parama0, t0 paramt0, View paramView1, View paramView2, RecyclerView.o paramo, boolean paramBoolean) {
    if (paramo.e() == 0 || parama0.a() == 0 || paramView1 == null || paramView2 == null)
      return 0; 
    if (!paramBoolean)
      return Math.abs(paramo.l(paramView1) - paramo.l(paramView2)) + 1; 
    int i = paramt0.a(paramView2);
    int j = paramt0.d(paramView1);
    return Math.min(paramt0.g(), i - j);
  }
  
  static int a(RecyclerView.a0 parama0, t0 paramt0, View paramView1, View paramView2, RecyclerView.o paramo, boolean paramBoolean1, boolean paramBoolean2) {
    if (paramo.e() == 0 || parama0.a() == 0 || paramView1 == null || paramView2 == null)
      return 0; 
    int i = Math.min(paramo.l(paramView1), paramo.l(paramView2));
    int j = Math.max(paramo.l(paramView1), paramo.l(paramView2));
    if (paramBoolean2) {
      i = Math.max(0, parama0.a() - j - 1);
    } else {
      i = Math.max(0, i);
    } 
    if (!paramBoolean1)
      return i; 
    j = Math.abs(paramt0.a(paramView2) - paramt0.d(paramView1));
    int k = Math.abs(paramo.l(paramView1) - paramo.l(paramView2));
    float f = j / (k + 1);
    return Math.round(i * f + (paramt0.f() - paramt0.d(paramView1)));
  }
  
  static int b(RecyclerView.a0 parama0, t0 paramt0, View paramView1, View paramView2, RecyclerView.o paramo, boolean paramBoolean) {
    if (paramo.e() == 0 || parama0.a() == 0 || paramView1 == null || paramView2 == null)
      return 0; 
    if (!paramBoolean)
      return parama0.a(); 
    int i = paramt0.a(paramView2);
    int j = paramt0.d(paramView1);
    int k = Math.abs(paramo.l(paramView1) - paramo.l(paramView2));
    return (int)((i - j) / (k + 1) * parama0.a());
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\a1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */