package android.support.v7.widget;

import android.support.v7.view.menu.p;
import android.view.Menu;
import android.view.Window;

public interface e0 {
  void a(int paramInt);
  
  void a(Menu paramMenu, p.a parama);
  
  boolean a();
  
  boolean b();
  
  boolean c();
  
  boolean d();
  
  void e();
  
  boolean f();
  
  void g();
  
  void setWindowCallback(Window.Callback paramCallback);
  
  void setWindowTitle(CharSequence paramCharSequence);
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */