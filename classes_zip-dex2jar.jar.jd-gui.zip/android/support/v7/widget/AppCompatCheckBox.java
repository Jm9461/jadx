package android.support.v7.widget;

import a.b.h.a.a;
import a.b.h.c.a.a;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.v4.widget.q;
import android.util.AttributeSet;
import android.widget.CheckBox;
import android.widget.CompoundButton;

public class AppCompatCheckBox extends CheckBox implements q {
  private final i c = new i((CompoundButton)this);
  
  public AppCompatCheckBox(Context paramContext) {
    this(paramContext, null);
  }
  
  public AppCompatCheckBox(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.checkboxStyle);
  }
  
  public AppCompatCheckBox(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(g1.b(paramContext), paramAttributeSet, paramInt);
    this.c.a(paramAttributeSet, paramInt);
  }
  
  public int getCompoundPaddingLeft() {
    int j = super.getCompoundPaddingLeft();
    i i1 = this.c;
    if (i1 != null)
      j = i1.a(j); 
    return j;
  }
  
  public ColorStateList getSupportButtonTintList() {
    i i1 = this.c;
    if (i1 != null) {
      ColorStateList colorStateList = i1.b();
    } else {
      i1 = null;
    } 
    return (ColorStateList)i1;
  }
  
  public PorterDuff.Mode getSupportButtonTintMode() {
    i i1 = this.c;
    if (i1 != null) {
      PorterDuff.Mode mode = i1.c();
    } else {
      i1 = null;
    } 
    return (PorterDuff.Mode)i1;
  }
  
  public void setButtonDrawable(int paramInt) {
    setButtonDrawable(a.c(getContext(), paramInt));
  }
  
  public void setButtonDrawable(Drawable paramDrawable) {
    super.setButtonDrawable(paramDrawable);
    i i1 = this.c;
    if (i1 != null)
      i1.d(); 
  }
  
  public void setSupportButtonTintList(ColorStateList paramColorStateList) {
    i i1 = this.c;
    if (i1 != null)
      i1.a(paramColorStateList); 
  }
  
  public void setSupportButtonTintMode(PorterDuff.Mode paramMode) {
    i i1 = this.c;
    if (i1 != null)
      i1.a(paramMode); 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\AppCompatCheckBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */