package android.support.v7.widget;

import a.b.h.f.c;
import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.view.u;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import java.lang.reflect.Method;
import java.util.WeakHashMap;

public class SearchView extends o0 implements c {
  static final k s0 = new k();
  
  private p A;
  
  private Rect B = new Rect();
  
  private Rect C = new Rect();
  
  private int[] D = new int[2];
  
  private int[] E = new int[2];
  
  private final ImageView F;
  
  private final Drawable G;
  
  private final int H;
  
  private final int I;
  
  private final Intent J;
  
  private final Intent K;
  
  private final CharSequence L;
  
  private m M;
  
  private l N;
  
  View.OnFocusChangeListener O;
  
  private n P;
  
  private View.OnClickListener Q;
  
  private boolean R;
  
  private boolean S;
  
  android.support.v4.widget.d T;
  
  private boolean U;
  
  private CharSequence V;
  
  private boolean W;
  
  private boolean a0;
  
  private int b0;
  
  private boolean c0;
  
  private CharSequence d0;
  
  private CharSequence e0;
  
  private boolean f0;
  
  private int g0;
  
  SearchableInfo h0;
  
  private Bundle i0;
  
  private final Runnable j0 = new b(this);
  
  private Runnable k0 = new c(this);
  
  private final WeakHashMap<String, Drawable.ConstantState> l0 = new WeakHashMap<String, Drawable.ConstantState>();
  
  private final View.OnClickListener m0 = new f(this);
  
  View.OnKeyListener n0 = new g(this);
  
  private final TextView.OnEditorActionListener o0 = new h(this);
  
  private final AdapterView.OnItemClickListener p0 = new i(this);
  
  private final AdapterView.OnItemSelectedListener q0 = new j(this);
  
  final SearchAutoComplete r;
  
  private TextWatcher r0 = new a(this);
  
  private final View s;
  
  private final View t;
  
  private final View u;
  
  final ImageView v;
  
  final ImageView w;
  
  final ImageView x;
  
  final ImageView y;
  
  private final View z;
  
  public SearchView(Context paramContext) {
    this(paramContext, null);
  }
  
  public SearchView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.b.h.a.a.searchViewStyle);
  }
  
  public SearchView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    j1 j1 = j1.a(paramContext, paramAttributeSet, a.b.h.a.j.SearchView, paramInt, 0);
    LayoutInflater.from(paramContext).inflate(j1.g(a.b.h.a.j.SearchView_layout, a.b.h.a.g.abc_search_view), this, true);
    this.r = (SearchAutoComplete)findViewById(a.b.h.a.f.search_src_text);
    this.r.setSearchView(this);
    this.s = findViewById(a.b.h.a.f.search_edit_frame);
    this.t = findViewById(a.b.h.a.f.search_plate);
    this.u = findViewById(a.b.h.a.f.submit_area);
    this.v = (ImageView)findViewById(a.b.h.a.f.search_button);
    this.w = (ImageView)findViewById(a.b.h.a.f.search_go_btn);
    this.x = (ImageView)findViewById(a.b.h.a.f.search_close_btn);
    this.y = (ImageView)findViewById(a.b.h.a.f.search_voice_btn);
    this.F = (ImageView)findViewById(a.b.h.a.f.search_mag_icon);
    u.a(this.t, j1.b(a.b.h.a.j.SearchView_queryBackground));
    u.a(this.u, j1.b(a.b.h.a.j.SearchView_submitBackground));
    this.v.setImageDrawable(j1.b(a.b.h.a.j.SearchView_searchIcon));
    this.w.setImageDrawable(j1.b(a.b.h.a.j.SearchView_goIcon));
    this.x.setImageDrawable(j1.b(a.b.h.a.j.SearchView_closeIcon));
    this.y.setImageDrawable(j1.b(a.b.h.a.j.SearchView_voiceIcon));
    this.F.setImageDrawable(j1.b(a.b.h.a.j.SearchView_searchIcon));
    this.G = j1.b(a.b.h.a.j.SearchView_searchHintIcon);
    l1.a((View)this.v, getResources().getString(a.b.h.a.h.abc_searchview_description_search));
    this.H = j1.g(a.b.h.a.j.SearchView_suggestionRowLayout, a.b.h.a.g.abc_search_dropdown_item_icons_2line);
    this.I = j1.g(a.b.h.a.j.SearchView_commitIcon, 0);
    this.v.setOnClickListener(this.m0);
    this.x.setOnClickListener(this.m0);
    this.w.setOnClickListener(this.m0);
    this.y.setOnClickListener(this.m0);
    this.r.setOnClickListener(this.m0);
    this.r.addTextChangedListener(this.r0);
    this.r.setOnEditorActionListener(this.o0);
    this.r.setOnItemClickListener(this.p0);
    this.r.setOnItemSelectedListener(this.q0);
    this.r.setOnKeyListener(this.n0);
    this.r.setOnFocusChangeListener(new d(this));
    setIconifiedByDefault(j1.a(a.b.h.a.j.SearchView_iconifiedByDefault, true));
    paramInt = j1.c(a.b.h.a.j.SearchView_android_maxWidth, -1);
    if (paramInt != -1)
      setMaxWidth(paramInt); 
    this.L = j1.e(a.b.h.a.j.SearchView_defaultQueryHint);
    this.V = j1.e(a.b.h.a.j.SearchView_queryHint);
    paramInt = j1.d(a.b.h.a.j.SearchView_android_imeOptions, -1);
    if (paramInt != -1)
      setImeOptions(paramInt); 
    paramInt = j1.d(a.b.h.a.j.SearchView_android_inputType, -1);
    if (paramInt != -1)
      setInputType(paramInt); 
    setFocusable(j1.a(a.b.h.a.j.SearchView_android_focusable, true));
    j1.a();
    this.J = new Intent("android.speech.action.WEB_SEARCH");
    this.J.addFlags(268435456);
    this.J.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
    this.K = new Intent("android.speech.action.RECOGNIZE_SPEECH");
    this.K.addFlags(268435456);
    this.z = findViewById(this.r.getDropDownAnchor());
    View view = this.z;
    if (view != null)
      view.addOnLayoutChangeListener(new e(this)); 
    b(this.R);
    r();
  }
  
  private Intent a(Intent paramIntent, SearchableInfo paramSearchableInfo) {
    String str2;
    ComponentName componentName = paramSearchableInfo.getSearchActivity();
    Intent intent1 = new Intent("android.intent.action.SEARCH");
    intent1.setComponent(componentName);
    PendingIntent pendingIntent = PendingIntent.getActivity(getContext(), 0, intent1, 1073741824);
    Bundle bundle2 = new Bundle();
    Bundle bundle1 = this.i0;
    if (bundle1 != null)
      bundle2.putParcelable("app_data", (Parcelable)bundle1); 
    Intent intent2 = new Intent(paramIntent);
    String str1 = "free_form";
    bundle1 = null;
    String str3 = null;
    int i = 1;
    Resources resources = getResources();
    if (paramSearchableInfo.getVoiceLanguageModeId() != 0)
      str1 = resources.getString(paramSearchableInfo.getVoiceLanguageModeId()); 
    if (paramSearchableInfo.getVoicePromptTextId() != 0)
      str2 = resources.getString(paramSearchableInfo.getVoicePromptTextId()); 
    if (paramSearchableInfo.getVoiceLanguageId() != 0)
      str3 = resources.getString(paramSearchableInfo.getVoiceLanguageId()); 
    if (paramSearchableInfo.getVoiceMaxResults() != 0)
      i = paramSearchableInfo.getVoiceMaxResults(); 
    intent2.putExtra("android.speech.extra.LANGUAGE_MODEL", str1);
    intent2.putExtra("android.speech.extra.PROMPT", str2);
    intent2.putExtra("android.speech.extra.LANGUAGE", str3);
    intent2.putExtra("android.speech.extra.MAX_RESULTS", i);
    if (componentName == null) {
      str1 = null;
    } else {
      str1 = componentName.flattenToShortString();
    } 
    intent2.putExtra("calling_package", str1);
    intent2.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", (Parcelable)pendingIntent);
    intent2.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle2);
    return intent2;
  }
  
  private Intent a(Cursor paramCursor, int paramInt, String paramString) {
    try {
      Uri uri;
      String str2 = d1.a(paramCursor, "suggest_intent_action");
      String str1 = str2;
      if (str2 == null)
        str1 = this.h0.getSuggestIntentAction(); 
      str2 = str1;
      if (str1 == null)
        str2 = "android.intent.action.SEARCH"; 
      String str3 = d1.a(paramCursor, "suggest_intent_data");
      str1 = str3;
      if (str3 == null)
        str1 = this.h0.getSuggestIntentData(); 
      if (str1 != null) {
        String str = d1.a(paramCursor, "suggest_intent_data_id");
        if (str != null) {
          StringBuilder stringBuilder = new StringBuilder();
          this();
          stringBuilder.append(str1);
          stringBuilder.append("/");
          stringBuilder.append(Uri.encode(str));
          str1 = stringBuilder.toString();
        } 
      } 
      if (str1 == null) {
        str1 = null;
      } else {
        uri = Uri.parse(str1);
      } 
      str3 = d1.a(paramCursor, "suggest_intent_query");
      return a(str2, uri, d1.a(paramCursor, "suggest_intent_extra_data"), str3, paramInt, paramString);
    } catch (RuntimeException runtimeException) {
      try {
        paramInt = paramCursor.getPosition();
      } catch (RuntimeException runtimeException1) {
        paramInt = -1;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Search suggestions cursor at row ");
      stringBuilder.append(paramInt);
      stringBuilder.append(" returned exception.");
      Log.w("SearchView", stringBuilder.toString(), runtimeException);
      return null;
    } 
  }
  
  private Intent a(String paramString1, Uri paramUri, String paramString2, String paramString3, int paramInt, String paramString4) {
    Intent intent = new Intent(paramString1);
    intent.addFlags(268435456);
    if (paramUri != null)
      intent.setData(paramUri); 
    intent.putExtra("user_query", this.e0);
    if (paramString3 != null)
      intent.putExtra("query", paramString3); 
    if (paramString2 != null)
      intent.putExtra("intent_extra_data_key", paramString2); 
    Bundle bundle = this.i0;
    if (bundle != null)
      intent.putExtra("app_data", bundle); 
    if (paramInt != 0) {
      intent.putExtra("action_key", paramInt);
      intent.putExtra("action_msg", paramString4);
    } 
    intent.setComponent(this.h0.getSearchActivity());
    return intent;
  }
  
  private void a(Intent paramIntent) {
    if (paramIntent == null)
      return; 
    try {
      getContext().startActivity(paramIntent);
    } catch (RuntimeException runtimeException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed launch activity: ");
      stringBuilder.append(paramIntent);
      Log.e("SearchView", stringBuilder.toString(), runtimeException);
    } 
  }
  
  private void a(View paramView, Rect paramRect) {
    paramView.getLocationInWindow(this.D);
    getLocationInWindow(this.E);
    int[] arrayOfInt2 = this.D;
    int i = arrayOfInt2[1];
    int[] arrayOfInt1 = this.E;
    i -= arrayOfInt1[1];
    int j = arrayOfInt2[0] - arrayOfInt1[0];
    paramRect.set(j, i, paramView.getWidth() + j, paramView.getHeight() + i);
  }
  
  private void a(boolean paramBoolean) {
    // Byte code:
    //   0: bipush #8
    //   2: istore_3
    //   3: iload_3
    //   4: istore_2
    //   5: aload_0
    //   6: getfield U : Z
    //   9: ifeq -> 45
    //   12: iload_3
    //   13: istore_2
    //   14: aload_0
    //   15: invokespecial o : ()Z
    //   18: ifeq -> 45
    //   21: iload_3
    //   22: istore_2
    //   23: aload_0
    //   24: invokevirtual hasFocus : ()Z
    //   27: ifeq -> 45
    //   30: iload_1
    //   31: ifne -> 43
    //   34: iload_3
    //   35: istore_2
    //   36: aload_0
    //   37: getfield c0 : Z
    //   40: ifne -> 45
    //   43: iconst_0
    //   44: istore_2
    //   45: aload_0
    //   46: getfield w : Landroid/widget/ImageView;
    //   49: iload_2
    //   50: invokevirtual setVisibility : (I)V
    //   53: return
  }
  
  static boolean a(Context paramContext) {
    boolean bool;
    if ((paramContext.getResources().getConfiguration()).orientation == 2) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private Intent b(Intent paramIntent, SearchableInfo paramSearchableInfo) {
    String str;
    Intent intent = new Intent(paramIntent);
    ComponentName componentName = paramSearchableInfo.getSearchActivity();
    if (componentName == null) {
      componentName = null;
    } else {
      str = componentName.flattenToShortString();
    } 
    intent.putExtra("calling_package", str);
    return intent;
  }
  
  private void b(boolean paramBoolean) {
    byte b1;
    this.S = paramBoolean;
    byte b2 = 8;
    boolean bool = false;
    if (paramBoolean) {
      b1 = 0;
    } else {
      b1 = 8;
    } 
    int i = TextUtils.isEmpty((CharSequence)this.r.getText()) ^ true;
    this.v.setVisibility(b1);
    a(i);
    View view = this.s;
    if (paramBoolean) {
      b1 = b2;
    } else {
      b1 = 0;
    } 
    view.setVisibility(b1);
    if (this.F.getDrawable() == null || this.R) {
      b1 = 8;
    } else {
      b1 = 0;
    } 
    this.F.setVisibility(b1);
    q();
    paramBoolean = bool;
    if (i == 0)
      paramBoolean = true; 
    c(paramBoolean);
    t();
  }
  
  private boolean b(int paramInt1, int paramInt2, String paramString) {
    Cursor cursor = this.T.a();
    if (cursor != null && cursor.moveToPosition(paramInt1)) {
      a(a(cursor, paramInt2, paramString));
      return true;
    } 
    return false;
  }
  
  private CharSequence c(CharSequence paramCharSequence) {
    if (!this.R || this.G == null)
      return paramCharSequence; 
    double d1 = this.r.getTextSize();
    Double.isNaN(d1);
    int i = (int)(d1 * 1.25D);
    this.G.setBounds(0, 0, i, i);
    SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("   ");
    spannableStringBuilder.setSpan(new ImageSpan(this.G), 1, 2, 33);
    spannableStringBuilder.append(paramCharSequence);
    return (CharSequence)spannableStringBuilder;
  }
  
  private void c(boolean paramBoolean) {
    byte b2 = 8;
    byte b1 = b2;
    if (this.c0) {
      b1 = b2;
      if (!f()) {
        b1 = b2;
        if (paramBoolean) {
          b1 = 0;
          this.w.setVisibility(8);
        } 
      } 
    } 
    this.y.setVisibility(b1);
  }
  
  private void e(int paramInt) {
    Editable editable = this.r.getText();
    Cursor cursor = this.T.a();
    if (cursor == null)
      return; 
    if (cursor.moveToPosition(paramInt)) {
      CharSequence charSequence = this.T.a(cursor);
      if (charSequence != null) {
        setQuery(charSequence);
      } else {
        setQuery((CharSequence)editable);
      } 
    } else {
      setQuery((CharSequence)editable);
    } 
  }
  
  private int getPreferredHeight() {
    return getContext().getResources().getDimensionPixelSize(a.b.h.a.d.abc_search_view_preferred_height);
  }
  
  private int getPreferredWidth() {
    return getContext().getResources().getDimensionPixelSize(a.b.h.a.d.abc_search_view_preferred_width);
  }
  
  private void m() {
    this.r.dismissDropDown();
  }
  
  private boolean n() {
    SearchableInfo searchableInfo = this.h0;
    boolean bool = false;
    if (searchableInfo != null && searchableInfo.getVoiceSearchEnabled()) {
      Intent intent;
      searchableInfo = null;
      if (this.h0.getVoiceSearchLaunchWebSearch()) {
        intent = this.J;
      } else if (this.h0.getVoiceSearchLaunchRecognizer()) {
        intent = this.K;
      } 
      if (intent != null) {
        if (getContext().getPackageManager().resolveActivity(intent, 65536) != null)
          bool = true; 
        return bool;
      } 
    } 
    return false;
  }
  
  private boolean o() {
    boolean bool;
    if ((this.U || this.c0) && !f()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private void p() {
    post(this.j0);
  }
  
  private void q() {
    boolean bool = TextUtils.isEmpty((CharSequence)this.r.getText());
    byte b3 = 1;
    int i = bool ^ true;
    byte b2 = 0;
    byte b1 = b3;
    if (i == 0)
      if (this.R && !this.f0) {
        b1 = b3;
      } else {
        b1 = 0;
      }  
    ImageView imageView = this.x;
    if (b1) {
      b1 = b2;
    } else {
      b1 = 8;
    } 
    imageView.setVisibility(b1);
    Drawable drawable = this.x.getDrawable();
    if (drawable != null) {
      int[] arrayOfInt;
      if (i != 0) {
        arrayOfInt = ViewGroup.ENABLED_STATE_SET;
      } else {
        arrayOfInt = ViewGroup.EMPTY_STATE_SET;
      } 
      drawable.setState(arrayOfInt);
    } 
  }
  
  private void r() {
    CharSequence charSequence = getQueryHint();
    SearchAutoComplete searchAutoComplete = this.r;
    if (charSequence == null)
      charSequence = ""; 
    searchAutoComplete.setHint(c(charSequence));
  }
  
  private void s() {
    this.r.setThreshold(this.h0.getSuggestThreshold());
    this.r.setImeOptions(this.h0.getImeOptions());
    int j = this.h0.getInputType();
    boolean bool = true;
    int i = j;
    if ((j & 0xF) == 1) {
      j &= 0xFFFEFFFF;
      i = j;
      if (this.h0.getSuggestAuthority() != null)
        i = j | 0x10000 | 0x80000; 
    } 
    this.r.setInputType(i);
    android.support.v4.widget.d d1 = this.T;
    if (d1 != null)
      d1.b(null); 
    if (this.h0.getSuggestAuthority() != null) {
      this.T = (android.support.v4.widget.d)new d1(getContext(), this, this.h0, this.l0);
      this.r.setAdapter((ListAdapter)this.T);
      d1 d11 = (d1)this.T;
      i = bool;
      if (this.W)
        i = 2; 
      d11.a(i);
    } 
  }
  
  private void setQuery(CharSequence paramCharSequence) {
    int i;
    this.r.setText(paramCharSequence);
    SearchAutoComplete searchAutoComplete = this.r;
    if (TextUtils.isEmpty(paramCharSequence)) {
      i = 0;
    } else {
      i = paramCharSequence.length();
    } 
    searchAutoComplete.setSelection(i);
  }
  
  private void t() {
    // Byte code:
    //   0: bipush #8
    //   2: istore_2
    //   3: iload_2
    //   4: istore_1
    //   5: aload_0
    //   6: invokespecial o : ()Z
    //   9: ifeq -> 36
    //   12: aload_0
    //   13: getfield w : Landroid/widget/ImageView;
    //   16: invokevirtual getVisibility : ()I
    //   19: ifeq -> 34
    //   22: iload_2
    //   23: istore_1
    //   24: aload_0
    //   25: getfield y : Landroid/widget/ImageView;
    //   28: invokevirtual getVisibility : ()I
    //   31: ifne -> 36
    //   34: iconst_0
    //   35: istore_1
    //   36: aload_0
    //   37: getfield u : Landroid/view/View;
    //   40: iload_1
    //   41: invokevirtual setVisibility : (I)V
    //   44: return
  }
  
  void a(int paramInt, String paramString1, String paramString2) {
    Intent intent = a("android.intent.action.SEARCH", null, null, paramString2, paramInt, paramString1);
    getContext().startActivity(intent);
  }
  
  void a(CharSequence paramCharSequence) {
    setQuery(paramCharSequence);
  }
  
  public void a(CharSequence paramCharSequence, boolean paramBoolean) {
    this.r.setText(paramCharSequence);
    if (paramCharSequence != null) {
      SearchAutoComplete searchAutoComplete = this.r;
      searchAutoComplete.setSelection(searchAutoComplete.length());
      this.e0 = paramCharSequence;
    } 
    if (paramBoolean && !TextUtils.isEmpty(paramCharSequence))
      i(); 
  }
  
  boolean a(int paramInt1, int paramInt2, String paramString) {
    n n1 = this.P;
    if (n1 == null || !n1.b(paramInt1)) {
      b(paramInt1, 0, null);
      this.r.setImeVisibility(false);
      m();
      return true;
    } 
    return false;
  }
  
  boolean a(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (this.h0 == null)
      return false; 
    if (this.T == null)
      return false; 
    if (paramKeyEvent.getAction() == 0 && paramKeyEvent.hasNoModifiers()) {
      if (paramInt == 66 || paramInt == 84 || paramInt == 61)
        return a(this.r.getListSelection(), 0, (String)null); 
      if (paramInt == 21 || paramInt == 22) {
        if (paramInt == 21) {
          paramInt = 0;
        } else {
          paramInt = this.r.length();
        } 
        this.r.setSelection(paramInt);
        this.r.setListSelection(0);
        this.r.clearListSelection();
        s0.a(this.r, true);
        return true;
      } 
      if (paramInt == 19 && this.r.getListSelection() == 0)
        return false; 
    } 
    return false;
  }
  
  public void b() {
    if (this.f0)
      return; 
    this.f0 = true;
    this.g0 = this.r.getImeOptions();
    this.r.setImeOptions(this.g0 | 0x2000000);
    this.r.setText("");
    setIconified(false);
  }
  
  void b(CharSequence paramCharSequence) {
    Editable editable = this.r.getText();
    this.e0 = (CharSequence)editable;
    boolean bool1 = TextUtils.isEmpty((CharSequence)editable);
    boolean bool = true;
    int i = bool1 ^ true;
    a(i);
    if (i != 0)
      bool = false; 
    c(bool);
    q();
    t();
    if (this.M != null && !TextUtils.equals(paramCharSequence, this.d0))
      this.M.a(paramCharSequence.toString()); 
    this.d0 = paramCharSequence.toString();
  }
  
  public void c() {
    a("", false);
    clearFocus();
    b(true);
    this.r.setImeOptions(this.g0);
    this.f0 = false;
  }
  
  public void clearFocus() {
    this.a0 = true;
    super.clearFocus();
    this.r.clearFocus();
    this.r.setImeVisibility(false);
    this.a0 = false;
  }
  
  void d() {
    if (this.z.getWidth() > 1) {
      byte b;
      Resources resources = getContext().getResources();
      int j = this.t.getPaddingLeft();
      Rect rect = new Rect();
      boolean bool = r1.a((View)this);
      if (this.R) {
        b = resources.getDimensionPixelSize(a.b.h.a.d.abc_dropdownitem_icon_width) + resources.getDimensionPixelSize(a.b.h.a.d.abc_dropdownitem_text_padding_left);
      } else {
        b = 0;
      } 
      this.r.getDropDownBackground().getPadding(rect);
      if (bool) {
        i = -rect.left;
      } else {
        i = j - rect.left + b;
      } 
      this.r.setDropDownHorizontalOffset(i);
      int i2 = this.z.getWidth();
      int i = rect.left;
      int i1 = rect.right;
      this.r.setDropDownWidth(i2 + i + i1 + b - j);
    } 
  }
  
  boolean d(int paramInt) {
    n n1 = this.P;
    if (n1 == null || !n1.a(paramInt)) {
      e(paramInt);
      return true;
    } 
    return false;
  }
  
  void e() {
    s0.b(this.r);
    s0.a(this.r);
  }
  
  public boolean f() {
    return this.S;
  }
  
  void g() {
    if (TextUtils.isEmpty((CharSequence)this.r.getText())) {
      if (this.R) {
        l l1 = this.N;
        if (l1 == null || !l1.a()) {
          clearFocus();
          b(true);
        } 
      } 
    } else {
      this.r.setText("");
      this.r.requestFocus();
      this.r.setImeVisibility(true);
    } 
  }
  
  public int getImeOptions() {
    return this.r.getImeOptions();
  }
  
  public int getInputType() {
    return this.r.getInputType();
  }
  
  public int getMaxWidth() {
    return this.b0;
  }
  
  public CharSequence getQuery() {
    return (CharSequence)this.r.getText();
  }
  
  public CharSequence getQueryHint() {
    CharSequence charSequence;
    if (this.V != null) {
      charSequence = this.V;
    } else {
      SearchableInfo searchableInfo = this.h0;
      if (searchableInfo != null && searchableInfo.getHintId() != 0) {
        charSequence = getContext().getText(this.h0.getHintId());
      } else {
        charSequence = this.L;
      } 
    } 
    return charSequence;
  }
  
  int getSuggestionCommitIconResId() {
    return this.I;
  }
  
  int getSuggestionRowLayout() {
    return this.H;
  }
  
  public android.support.v4.widget.d getSuggestionsAdapter() {
    return this.T;
  }
  
  void h() {
    b(false);
    this.r.requestFocus();
    this.r.setImeVisibility(true);
    View.OnClickListener onClickListener = this.Q;
    if (onClickListener != null)
      onClickListener.onClick((View)this); 
  }
  
  void i() {
    Editable editable = this.r.getText();
    if (editable != null && TextUtils.getTrimmedLength((CharSequence)editable) > 0) {
      m m1 = this.M;
      if (m1 == null || !m1.b(editable.toString())) {
        if (this.h0 != null)
          a(0, (String)null, editable.toString()); 
        this.r.setImeVisibility(false);
        m();
      } 
    } 
  }
  
  void j() {
    b(f());
    p();
    if (this.r.hasFocus())
      e(); 
  }
  
  void k() {
    if (this.h0 == null)
      return; 
    SearchableInfo searchableInfo = this.h0;
    try {
      Intent intent;
      if (searchableInfo.getVoiceSearchLaunchWebSearch()) {
        intent = b(this.J, searchableInfo);
        getContext().startActivity(intent);
      } else if (intent.getVoiceSearchLaunchRecognizer()) {
        intent = a(this.K, (SearchableInfo)intent);
        getContext().startActivity(intent);
      } 
    } catch (ActivityNotFoundException activityNotFoundException) {
      Log.w("SearchView", "Could not find voice search activity");
    } 
  }
  
  void l() {
    int[] arrayOfInt;
    if (this.r.hasFocus()) {
      arrayOfInt = ViewGroup.FOCUSED_STATE_SET;
    } else {
      arrayOfInt = ViewGroup.EMPTY_STATE_SET;
    } 
    Drawable drawable = this.t.getBackground();
    if (drawable != null)
      drawable.setState(arrayOfInt); 
    drawable = this.u.getBackground();
    if (drawable != null)
      drawable.setState(arrayOfInt); 
    invalidate();
  }
  
  protected void onDetachedFromWindow() {
    removeCallbacks(this.j0);
    post(this.k0);
    super.onDetachedFromWindow();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramBoolean) {
      a((View)this.r, this.B);
      Rect rect2 = this.C;
      Rect rect1 = this.B;
      rect2.set(rect1.left, 0, rect1.right, paramInt4 - paramInt2);
      p p1 = this.A;
      if (p1 == null) {
        this.A = new p(this.C, this.B, (View)this.r);
        setTouchDelegate(this.A);
      } else {
        p1.a(this.C, this.B);
      } 
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (f()) {
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    int j = View.MeasureSpec.getMode(paramInt1);
    int i = View.MeasureSpec.getSize(paramInt1);
    if (j != Integer.MIN_VALUE) {
      if (j != 0) {
        if (j != 1073741824) {
          paramInt1 = i;
        } else {
          j = this.b0;
          paramInt1 = i;
          if (j > 0)
            paramInt1 = Math.min(j, i); 
        } 
      } else {
        paramInt1 = this.b0;
        if (paramInt1 <= 0)
          paramInt1 = getPreferredWidth(); 
      } 
    } else {
      paramInt1 = this.b0;
      if (paramInt1 > 0) {
        paramInt1 = Math.min(paramInt1, i);
      } else {
        paramInt1 = Math.min(getPreferredWidth(), i);
      } 
    } 
    i = View.MeasureSpec.getMode(paramInt2);
    paramInt2 = View.MeasureSpec.getSize(paramInt2);
    if (i != Integer.MIN_VALUE) {
      if (i == 0)
        paramInt2 = getPreferredHeight(); 
    } else {
      paramInt2 = Math.min(getPreferredHeight(), paramInt2);
    } 
    super.onMeasure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824));
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof o)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    o o = (o)paramParcelable;
    super.onRestoreInstanceState(o.a());
    b(o.e);
    requestLayout();
  }
  
  protected Parcelable onSaveInstanceState() {
    o o = new o(super.onSaveInstanceState());
    o.e = f();
    return (Parcelable)o;
  }
  
  public void onWindowFocusChanged(boolean paramBoolean) {
    super.onWindowFocusChanged(paramBoolean);
    p();
  }
  
  public boolean requestFocus(int paramInt, Rect paramRect) {
    if (this.a0)
      return false; 
    if (!isFocusable())
      return false; 
    if (!f()) {
      boolean bool = this.r.requestFocus(paramInt, paramRect);
      if (bool)
        b(false); 
      return bool;
    } 
    return super.requestFocus(paramInt, paramRect);
  }
  
  public void setAppSearchData(Bundle paramBundle) {
    this.i0 = paramBundle;
  }
  
  public void setIconified(boolean paramBoolean) {
    if (paramBoolean) {
      g();
    } else {
      h();
    } 
  }
  
  public void setIconifiedByDefault(boolean paramBoolean) {
    if (this.R == paramBoolean)
      return; 
    this.R = paramBoolean;
    b(paramBoolean);
    r();
  }
  
  public void setImeOptions(int paramInt) {
    this.r.setImeOptions(paramInt);
  }
  
  public void setInputType(int paramInt) {
    this.r.setInputType(paramInt);
  }
  
  public void setMaxWidth(int paramInt) {
    this.b0 = paramInt;
    requestLayout();
  }
  
  public void setOnCloseListener(l paraml) {
    this.N = paraml;
  }
  
  public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener paramOnFocusChangeListener) {
    this.O = paramOnFocusChangeListener;
  }
  
  public void setOnQueryTextListener(m paramm) {
    this.M = paramm;
  }
  
  public void setOnSearchClickListener(View.OnClickListener paramOnClickListener) {
    this.Q = paramOnClickListener;
  }
  
  public void setOnSuggestionListener(n paramn) {
    this.P = paramn;
  }
  
  public void setQueryHint(CharSequence paramCharSequence) {
    this.V = paramCharSequence;
    r();
  }
  
  public void setQueryRefinementEnabled(boolean paramBoolean) {
    this.W = paramBoolean;
    android.support.v4.widget.d d1 = this.T;
    if (d1 instanceof d1) {
      boolean bool;
      d1 d11 = (d1)d1;
      if (paramBoolean) {
        bool = true;
      } else {
        bool = true;
      } 
      d11.a(bool);
    } 
  }
  
  public void setSearchableInfo(SearchableInfo paramSearchableInfo) {
    this.h0 = paramSearchableInfo;
    if (this.h0 != null) {
      s();
      r();
    } 
    this.c0 = n();
    if (this.c0)
      this.r.setPrivateImeOptions("nm"); 
    b(f());
  }
  
  public void setSubmitButtonEnabled(boolean paramBoolean) {
    this.U = paramBoolean;
    b(f());
  }
  
  public void setSuggestionsAdapter(android.support.v4.widget.d paramd) {
    this.T = paramd;
    this.r.setAdapter((ListAdapter)this.T);
  }
  
  public static class SearchAutoComplete extends e {
    private int f = getThreshold();
    
    private SearchView g;
    
    private boolean h;
    
    final Runnable i = new a(this);
    
    public SearchAutoComplete(Context param1Context) {
      this(param1Context, null);
    }
    
    public SearchAutoComplete(Context param1Context, AttributeSet param1AttributeSet) {
      this(param1Context, param1AttributeSet, a.b.h.a.a.autoCompleteTextViewStyle);
    }
    
    public SearchAutoComplete(Context param1Context, AttributeSet param1AttributeSet, int param1Int) {
      super(param1Context, param1AttributeSet, param1Int);
    }
    
    private int getSearchViewTextMinWidthDp() {
      Configuration configuration = getResources().getConfiguration();
      int i = configuration.screenWidthDp;
      int j = configuration.screenHeightDp;
      return (i >= 960 && j >= 720 && configuration.orientation == 2) ? 256 : ((i >= 600 || (i >= 640 && j >= 480)) ? 192 : 160);
    }
    
    boolean a() {
      boolean bool;
      if (TextUtils.getTrimmedLength((CharSequence)getText()) == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    void b() {
      if (this.h) {
        ((InputMethodManager)getContext().getSystemService("input_method")).showSoftInput((View)this, 0);
        this.h = false;
      } 
    }
    
    public boolean enoughToFilter() {
      return (this.f <= 0 || super.enoughToFilter());
    }
    
    public InputConnection onCreateInputConnection(EditorInfo param1EditorInfo) {
      InputConnection inputConnection = super.onCreateInputConnection(param1EditorInfo);
      if (this.h) {
        removeCallbacks(this.i);
        post(this.i);
      } 
      return inputConnection;
    }
    
    protected void onFinishInflate() {
      super.onFinishInflate();
      DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
      setMinWidth((int)TypedValue.applyDimension(1, getSearchViewTextMinWidthDp(), displayMetrics));
    }
    
    protected void onFocusChanged(boolean param1Boolean, int param1Int, Rect param1Rect) {
      super.onFocusChanged(param1Boolean, param1Int, param1Rect);
      this.g.j();
    }
    
    public boolean onKeyPreIme(int param1Int, KeyEvent param1KeyEvent) {
      if (param1Int == 4) {
        if (param1KeyEvent.getAction() == 0 && param1KeyEvent.getRepeatCount() == 0) {
          KeyEvent.DispatcherState dispatcherState = getKeyDispatcherState();
          if (dispatcherState != null)
            dispatcherState.startTracking(param1KeyEvent, this); 
          return true;
        } 
        if (param1KeyEvent.getAction() == 1) {
          KeyEvent.DispatcherState dispatcherState = getKeyDispatcherState();
          if (dispatcherState != null)
            dispatcherState.handleUpEvent(param1KeyEvent); 
          if (param1KeyEvent.isTracking() && !param1KeyEvent.isCanceled()) {
            this.g.clearFocus();
            setImeVisibility(false);
            return true;
          } 
        } 
      } 
      return super.onKeyPreIme(param1Int, param1KeyEvent);
    }
    
    public void onWindowFocusChanged(boolean param1Boolean) {
      super.onWindowFocusChanged(param1Boolean);
      if (param1Boolean && this.g.hasFocus() && getVisibility() == 0) {
        this.h = true;
        if (SearchView.a(getContext()))
          SearchView.s0.a(this, true); 
      } 
    }
    
    public void performCompletion() {}
    
    protected void replaceText(CharSequence param1CharSequence) {}
    
    void setImeVisibility(boolean param1Boolean) {
      InputMethodManager inputMethodManager = (InputMethodManager)getContext().getSystemService("input_method");
      if (!param1Boolean) {
        this.h = false;
        removeCallbacks(this.i);
        inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
        return;
      } 
      if (inputMethodManager.isActive((View)this)) {
        this.h = false;
        removeCallbacks(this.i);
        inputMethodManager.showSoftInput((View)this, 0);
        return;
      } 
      this.h = true;
    }
    
    void setSearchView(SearchView param1SearchView) {
      this.g = param1SearchView;
    }
    
    public void setThreshold(int param1Int) {
      super.setThreshold(param1Int);
      this.f = param1Int;
    }
    
    class a implements Runnable {
      final SearchView.SearchAutoComplete c;
      
      a(SearchView.SearchAutoComplete this$0) {}
      
      public void run() {
        this.c.b();
      }
    }
  }
  
  class a implements Runnable {
    final SearchView.SearchAutoComplete c;
    
    a(SearchView this$0) {}
    
    public void run() {
      this.c.b();
    }
  }
  
  class a implements TextWatcher {
    final SearchView c;
    
    a(SearchView this$0) {}
    
    public void afterTextChanged(Editable param1Editable) {}
    
    public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {
      this.c.b(param1CharSequence);
    }
  }
  
  class b implements Runnable {
    final SearchView c;
    
    b(SearchView this$0) {}
    
    public void run() {
      this.c.l();
    }
  }
  
  class c implements Runnable {
    final SearchView c;
    
    c(SearchView this$0) {}
    
    public void run() {
      android.support.v4.widget.d d = this.c.T;
      if (d != null && d instanceof d1)
        d.b(null); 
    }
  }
  
  class d implements View.OnFocusChangeListener {
    final SearchView c;
    
    d(SearchView this$0) {}
    
    public void onFocusChange(View param1View, boolean param1Boolean) {
      SearchView searchView = this.c;
      View.OnFocusChangeListener onFocusChangeListener = searchView.O;
      if (onFocusChangeListener != null)
        onFocusChangeListener.onFocusChange((View)searchView, param1Boolean); 
    }
  }
  
  class e implements View.OnLayoutChangeListener {
    final SearchView a;
    
    e(SearchView this$0) {}
    
    public void onLayoutChange(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, int param1Int8) {
      this.a.d();
    }
  }
  
  class f implements View.OnClickListener {
    final SearchView c;
    
    f(SearchView this$0) {}
    
    public void onClick(View param1View) {
      SearchView searchView = this.c;
      if (param1View == searchView.v) {
        searchView.h();
      } else if (param1View == searchView.x) {
        searchView.g();
      } else if (param1View == searchView.w) {
        searchView.i();
      } else if (param1View == searchView.y) {
        searchView.k();
      } else if (param1View == searchView.r) {
        searchView.e();
      } 
    }
  }
  
  class g implements View.OnKeyListener {
    final SearchView c;
    
    g(SearchView this$0) {}
    
    public boolean onKey(View param1View, int param1Int, KeyEvent param1KeyEvent) {
      SearchView searchView = this.c;
      if (searchView.h0 == null)
        return false; 
      if (searchView.r.isPopupShowing() && this.c.r.getListSelection() != -1)
        return this.c.a(param1View, param1Int, param1KeyEvent); 
      if (!this.c.r.a() && param1KeyEvent.hasNoModifiers() && param1KeyEvent.getAction() == 1 && param1Int == 66) {
        param1View.cancelLongPress();
        SearchView searchView1 = this.c;
        searchView1.a(0, (String)null, searchView1.r.getText().toString());
        return true;
      } 
      return false;
    }
  }
  
  class h implements TextView.OnEditorActionListener {
    final SearchView a;
    
    h(SearchView this$0) {}
    
    public boolean onEditorAction(TextView param1TextView, int param1Int, KeyEvent param1KeyEvent) {
      this.a.i();
      return true;
    }
  }
  
  class i implements AdapterView.OnItemClickListener {
    final SearchView c;
    
    i(SearchView this$0) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.c.a(param1Int, 0, (String)null);
    }
  }
  
  class j implements AdapterView.OnItemSelectedListener {
    final SearchView c;
    
    j(SearchView this$0) {}
    
    public void onItemSelected(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.c.d(param1Int);
    }
    
    public void onNothingSelected(AdapterView<?> param1AdapterView) {}
  }
  
  private static class k {
    private Method a;
    
    private Method b;
    
    private Method c;
    
    k() {
      try {
        this.a = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", new Class[0]);
        this.a.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {}
      try {
        this.b = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", new Class[0]);
        this.b.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {}
      try {
        this.c = AutoCompleteTextView.class.getMethod("ensureImeVisible", new Class[] { boolean.class });
        this.c.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {}
    }
    
    void a(AutoCompleteTextView param1AutoCompleteTextView) {
      Method method = this.b;
      if (method != null)
        try {
          method.invoke(param1AutoCompleteTextView, new Object[0]);
        } catch (Exception exception) {} 
    }
    
    void a(AutoCompleteTextView param1AutoCompleteTextView, boolean param1Boolean) {
      Method method = this.c;
      if (method != null)
        try {
          method.invoke(param1AutoCompleteTextView, new Object[] { Boolean.valueOf(param1Boolean) });
        } catch (Exception exception) {} 
    }
    
    void b(AutoCompleteTextView param1AutoCompleteTextView) {
      Method method = this.a;
      if (method != null)
        try {
          method.invoke(param1AutoCompleteTextView, new Object[0]);
        } catch (Exception exception) {} 
    }
  }
  
  public static interface l {
    boolean a();
  }
  
  public static interface m {
    boolean a(String param1String);
    
    boolean b(String param1String);
  }
  
  public static interface n {
    boolean a(int param1Int);
    
    boolean b(int param1Int);
  }
  
  static class o extends android.support.v4.view.a {
    public static final Parcelable.Creator<o> CREATOR = (Parcelable.Creator<o>)new a();
    
    boolean e;
    
    public o(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      this.e = ((Boolean)param1Parcel.readValue(null)).booleanValue();
    }
    
    o(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SearchView.SavedState{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" isIconified=");
      stringBuilder.append(this.e);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeValue(Boolean.valueOf(this.e));
    }
    
    static final class a implements Parcelable.ClassLoaderCreator<o> {
      public SearchView.o createFromParcel(Parcel param2Parcel) {
        return new SearchView.o(param2Parcel, null);
      }
      
      public SearchView.o createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new SearchView.o(param2Parcel, param2ClassLoader);
      }
      
      public SearchView.o[] newArray(int param2Int) {
        return new SearchView.o[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.ClassLoaderCreator<o> {
    public SearchView.o createFromParcel(Parcel param1Parcel) {
      return new SearchView.o(param1Parcel, null);
    }
    
    public SearchView.o createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new SearchView.o(param1Parcel, param1ClassLoader);
    }
    
    public SearchView.o[] newArray(int param1Int) {
      return new SearchView.o[param1Int];
    }
  }
  
  private static class p extends TouchDelegate {
    private final View a;
    
    private final Rect b;
    
    private final Rect c;
    
    private final Rect d;
    
    private final int e;
    
    private boolean f;
    
    public p(Rect param1Rect1, Rect param1Rect2, View param1View) {
      super(param1Rect1, param1View);
      this.e = ViewConfiguration.get(param1View.getContext()).getScaledTouchSlop();
      this.b = new Rect();
      this.d = new Rect();
      this.c = new Rect();
      a(param1Rect1, param1Rect2);
      this.a = param1View;
    }
    
    public void a(Rect param1Rect1, Rect param1Rect2) {
      this.b.set(param1Rect1);
      this.d.set(param1Rect1);
      param1Rect1 = this.d;
      int i = this.e;
      param1Rect1.inset(-i, -i);
      this.c.set(param1Rect2);
    }
    
    public boolean onTouchEvent(MotionEvent param1MotionEvent) {
      int j = (int)param1MotionEvent.getX();
      int k = (int)param1MotionEvent.getY();
      boolean bool1 = false;
      boolean bool = true;
      boolean bool2 = false;
      int i = param1MotionEvent.getAction();
      if (i != 0) {
        if (i != 1 && i != 2) {
          if (i != 3) {
            i = bool;
          } else {
            bool1 = this.f;
            this.f = false;
            i = bool;
          } 
        } else {
          boolean bool3 = this.f;
          bool1 = bool3;
          i = bool;
          if (bool3) {
            bool1 = bool3;
            i = bool;
            if (!this.d.contains(j, k)) {
              i = 0;
              bool1 = bool3;
            } 
          } 
        } 
      } else {
        i = bool;
        if (this.b.contains(j, k)) {
          this.f = true;
          bool1 = true;
          i = bool;
        } 
      } 
      if (bool1) {
        if (i != 0 && !this.c.contains(j, k)) {
          param1MotionEvent.setLocation((this.a.getWidth() / 2), (this.a.getHeight() / 2));
        } else {
          Rect rect = this.c;
          param1MotionEvent.setLocation((j - rect.left), (k - rect.top));
        } 
        bool2 = this.a.dispatchTouchEvent(param1MotionEvent);
      } 
      return bool2;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\SearchView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */