package android.support.v7.widget;

import a.b.g.a.a;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.TypedValue;

class e1 {
  private static final ThreadLocal<TypedValue> a = new ThreadLocal<TypedValue>();
  
  static final int[] b = new int[] { -16842910 };
  
  static final int[] c = new int[] { 16842908 };
  
  static final int[] d = new int[] { 16842919 };
  
  static final int[] e = new int[] { 16842912 };
  
  static final int[] f = new int[0];
  
  private static final int[] g = new int[1];
  
  public static int a(Context paramContext, int paramInt) {
    ColorStateList colorStateList = c(paramContext, paramInt);
    if (colorStateList != null && colorStateList.isStateful())
      return colorStateList.getColorForState(b, colorStateList.getDefaultColor()); 
    TypedValue typedValue = a();
    paramContext.getTheme().resolveAttribute(16842803, typedValue, true);
    return a(paramContext, paramInt, typedValue.getFloat());
  }
  
  static int a(Context paramContext, int paramInt, float paramFloat) {
    paramInt = b(paramContext, paramInt);
    return a.c(paramInt, Math.round(Color.alpha(paramInt) * paramFloat));
  }
  
  private static TypedValue a() {
    TypedValue typedValue2 = a.get();
    TypedValue typedValue1 = typedValue2;
    if (typedValue2 == null) {
      typedValue1 = new TypedValue();
      a.set(typedValue1);
    } 
    return typedValue1;
  }
  
  public static int b(Context paramContext, int paramInt) {
    null = g;
    null[0] = paramInt;
    j1 j1 = j1.a(paramContext, (AttributeSet)null, null);
    try {
      paramInt = j1.a(0, 0);
      return paramInt;
    } finally {
      j1.a();
    } 
  }
  
  public static ColorStateList c(Context paramContext, int paramInt) {
    null = g;
    null[0] = paramInt;
    j1 j1 = j1.a(paramContext, (AttributeSet)null, null);
    try {
      return j1.a(0);
    } finally {
      j1.a();
    } 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\e1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */