package android.support.v7.widget;

import a.b.h.a.f;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.view.d;
import android.support.v4.view.u;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

public class AlertDialogLayout extends o0 {
  public AlertDialogLayout(Context paramContext) {
    super(paramContext);
  }
  
  public AlertDialogLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  private void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramView.layout(paramInt1, paramInt2, paramInt1 + paramInt3, paramInt2 + paramInt4);
  }
  
  private static int c(View paramView) {
    int i = u.l(paramView);
    if (i > 0)
      return i; 
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      if (viewGroup.getChildCount() == 1)
        return c(viewGroup.getChildAt(0)); 
    } 
    return 0;
  }
  
  private void c(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
    for (byte b = 0; b < paramInt1; b++) {
      View view = getChildAt(b);
      if (view.getVisibility() != 8) {
        o0.a a = (o0.a)view.getLayoutParams();
        if (a.width == -1) {
          int j = a.height;
          a.height = view.getMeasuredHeight();
          measureChildWithMargins(view, i, 0, paramInt2, 0);
          a.height = j;
        } 
      } 
    } 
  }
  
  private boolean d(int paramInt1, int paramInt2) {
    View view3 = null;
    View view1 = null;
    View view2 = null;
    int i5 = getChildCount();
    int i;
    for (i = 0; i < i5; i++) {
      View view = getChildAt(i);
      if (view.getVisibility() != 8) {
        int i8 = view.getId();
        if (i8 == f.topPanel) {
          view3 = view;
        } else if (i8 == f.buttonPanel) {
          view1 = view;
        } else if (i8 == f.contentPanel || i8 == f.customPanel) {
          if (view2 != null)
            return false; 
          view2 = view;
        } else {
          return false;
        } 
      } 
    } 
    int i7 = View.MeasureSpec.getMode(paramInt2);
    int i1 = View.MeasureSpec.getSize(paramInt2);
    int i6 = View.MeasureSpec.getMode(paramInt1);
    int m = 0;
    i = getPaddingTop() + getPaddingBottom();
    int n = i;
    if (view3 != null) {
      view3.measure(paramInt1, 0);
      n = i + view3.getMeasuredHeight();
      m = View.combineMeasuredStates(0, view3.getMeasuredState());
    } 
    i = 0;
    int i3 = 0;
    int j = m;
    int k = n;
    if (view1 != null) {
      view1.measure(paramInt1, 0);
      i = c(view1);
      i3 = view1.getMeasuredHeight() - i;
      k = n + i;
      j = View.combineMeasuredStates(m, view1.getMeasuredState());
    } 
    int i2 = 0;
    if (view2 != null) {
      if (i7 == 0) {
        m = 0;
      } else {
        m = View.MeasureSpec.makeMeasureSpec(Math.max(0, i1 - k), i7);
      } 
      view2.measure(paramInt1, m);
      i2 = view2.getMeasuredHeight();
      k += i2;
      j = View.combineMeasuredStates(j, view2.getMeasuredState());
    } 
    int i4 = i1 - k;
    i1 = i4;
    n = j;
    m = k;
    if (view1 != null) {
      i1 = Math.min(i4, i3);
      m = i4;
      n = i;
      if (i1 > 0) {
        m = i4 - i1;
        n = i + i1;
      } 
      view1.measure(paramInt1, View.MeasureSpec.makeMeasureSpec(n, 1073741824));
      i = k - i + view1.getMeasuredHeight();
      n = View.combineMeasuredStates(j, view1.getMeasuredState());
      i1 = m;
      m = i;
    } 
    k = i1;
    j = n;
    i = m;
    if (view2 != null) {
      k = i1;
      j = n;
      i = m;
      if (i1 > 0) {
        view2.measure(paramInt1, View.MeasureSpec.makeMeasureSpec(i2 + i1, i7));
        i = m - i2 + view2.getMeasuredHeight();
        j = View.combineMeasuredStates(n, view2.getMeasuredState());
        k = i1 - i1;
      } 
    } 
    n = 0;
    k = 0;
    while (k < i5) {
      View view = getChildAt(k);
      m = n;
      if (view.getVisibility() != 8)
        m = Math.max(n, view.getMeasuredWidth()); 
      k++;
      n = m;
    } 
    setMeasuredDimension(View.resolveSizeAndState(n + getPaddingLeft() + getPaddingRight(), paramInt1, j), View.resolveSizeAndState(i, paramInt2, 0));
    if (i6 != 1073741824)
      c(i5, paramInt2); 
    return true;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = getPaddingLeft();
    int j = paramInt3 - paramInt1;
    int m = getPaddingRight();
    int k = getPaddingRight();
    paramInt1 = getMeasuredHeight();
    int n = getChildCount();
    int i1 = getGravity();
    paramInt3 = i1 & 0x70;
    if (paramInt3 != 16) {
      if (paramInt3 != 80) {
        paramInt1 = getPaddingTop();
      } else {
        paramInt1 = getPaddingTop() + paramInt4 - paramInt2 - paramInt1;
      } 
    } else {
      paramInt1 = getPaddingTop() + (paramInt4 - paramInt2 - paramInt1) / 2;
    } 
    Drawable drawable = getDividerDrawable();
    if (drawable == null) {
      paramInt3 = 0;
    } else {
      paramInt3 = drawable.getIntrinsicHeight();
    } 
    for (paramInt4 = 0; paramInt4 < n; paramInt4++) {
      View view = getChildAt(paramInt4);
      if (view != null && view.getVisibility() != 8) {
        int i4 = view.getMeasuredWidth();
        int i3 = view.getMeasuredHeight();
        o0.a a = (o0.a)view.getLayoutParams();
        paramInt2 = a.b;
        if (paramInt2 < 0)
          paramInt2 = i1 & 0x800007; 
        paramInt2 = d.a(paramInt2, u.k((View)this)) & 0x7;
        if (paramInt2 != 1) {
          if (paramInt2 != 5) {
            paramInt2 = a.leftMargin + i;
          } else {
            paramInt2 = j - m - i4 - a.rightMargin;
          } 
        } else {
          paramInt2 = (j - i - k - i4) / 2 + i + a.leftMargin - a.rightMargin;
        } 
        int i2 = paramInt1;
        if (b(paramInt4))
          i2 = paramInt1 + paramInt3; 
        paramInt1 = i2 + a.topMargin;
        a(view, paramInt2, paramInt1, i4, i3);
        paramInt1 += i3 + a.bottomMargin;
      } 
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (!d(paramInt1, paramInt2))
      super.onMeasure(paramInt1, paramInt2); 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\AlertDialogLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */