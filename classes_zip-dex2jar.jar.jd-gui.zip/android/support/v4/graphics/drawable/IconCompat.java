package android.support.v4.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Parcelable;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;

public class IconCompat extends CustomVersionedParcelable {
  static final PorterDuff.Mode j = PorterDuff.Mode.SRC_IN;
  
  public int a;
  
  Object b;
  
  public byte[] c;
  
  public Parcelable d;
  
  public int e;
  
  public int f;
  
  public ColorStateList g = null;
  
  PorterDuff.Mode h = j;
  
  public String i;
  
  private static int a(Icon paramIcon) {
    if (Build.VERSION.SDK_INT >= 28)
      return paramIcon.getResId(); 
    try {
      return ((Integer)paramIcon.getClass().getMethod("getResId", new Class[0]).invoke(paramIcon, new Object[0])).intValue();
    } catch (IllegalAccessException illegalAccessException) {
      Log.e("IconCompat", "Unable to get icon resource", illegalAccessException);
      return 0;
    } catch (InvocationTargetException invocationTargetException) {
      Log.e("IconCompat", "Unable to get icon resource", invocationTargetException);
      return 0;
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.e("IconCompat", "Unable to get icon resource", noSuchMethodException);
      return 0;
    } 
  }
  
  private static String a(int paramInt) {
    return (paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? "UNKNOWN" : "BITMAP_MASKABLE") : "URI") : "DATA") : "RESOURCE") : "BITMAP";
  }
  
  private static String b(Icon paramIcon) {
    if (Build.VERSION.SDK_INT >= 28)
      return paramIcon.getResPackage(); 
    try {
      return (String)paramIcon.getClass().getMethod("getResPackage", new Class[0]).invoke(paramIcon, new Object[0]);
    } catch (IllegalAccessException illegalAccessException) {
      Log.e("IconCompat", "Unable to get icon package", illegalAccessException);
      return null;
    } catch (InvocationTargetException invocationTargetException) {
      Log.e("IconCompat", "Unable to get icon package", invocationTargetException);
      return null;
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.e("IconCompat", "Unable to get icon package", noSuchMethodException);
      return null;
    } 
  }
  
  public int a() {
    if (this.a == -1 && Build.VERSION.SDK_INT >= 23)
      return a((Icon)this.b); 
    if (this.a == 2)
      return this.e; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getResId() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void a(boolean paramBoolean) {
    this.i = this.h.name();
    int i = this.a;
    if (i != -1) {
      if (i != 1)
        if (i != 2) {
          if (i != 3) {
            if (i != 4) {
              if (i != 5)
                return; 
            } else {
              this.c = this.b.toString().getBytes(Charset.forName("UTF-16"));
              return;
            } 
          } else {
            this.c = (byte[])this.b;
            return;
          } 
        } else {
          this.c = ((String)this.b).getBytes(Charset.forName("UTF-16"));
          return;
        }  
      if (paramBoolean) {
        Bitmap bitmap = (Bitmap)this.b;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 90, byteArrayOutputStream);
        this.c = byteArrayOutputStream.toByteArray();
      } else {
        this.d = (Parcelable)this.b;
      } 
    } else {
      if (!paramBoolean) {
        this.d = (Parcelable)this.b;
        return;
      } 
      throw new IllegalArgumentException("Can't serialize Icon created with IconCompat#createFromIcon");
    } 
  }
  
  public String b() {
    if (this.a == -1 && Build.VERSION.SDK_INT >= 23)
      return b((Icon)this.b); 
    if (this.a == 2)
      return ((String)this.b).split(":", -1)[0]; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getResPackage() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void c() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield i : Ljava/lang/String;
    //   5: invokestatic valueOf : (Ljava/lang/String;)Landroid/graphics/PorterDuff$Mode;
    //   8: putfield h : Landroid/graphics/PorterDuff$Mode;
    //   11: aload_0
    //   12: getfield a : I
    //   15: istore_1
    //   16: iload_1
    //   17: iconst_m1
    //   18: if_icmpeq -> 129
    //   21: iload_1
    //   22: iconst_1
    //   23: if_icmpeq -> 83
    //   26: iload_1
    //   27: iconst_2
    //   28: if_icmpeq -> 60
    //   31: iload_1
    //   32: iconst_3
    //   33: if_icmpeq -> 49
    //   36: iload_1
    //   37: iconst_4
    //   38: if_icmpeq -> 60
    //   41: iload_1
    //   42: iconst_5
    //   43: if_icmpeq -> 83
    //   46: goto -> 143
    //   49: aload_0
    //   50: aload_0
    //   51: getfield c : [B
    //   54: putfield b : Ljava/lang/Object;
    //   57: goto -> 143
    //   60: aload_0
    //   61: new java/lang/String
    //   64: dup
    //   65: aload_0
    //   66: getfield c : [B
    //   69: ldc 'UTF-16'
    //   71: invokestatic forName : (Ljava/lang/String;)Ljava/nio/charset/Charset;
    //   74: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   77: putfield b : Ljava/lang/Object;
    //   80: goto -> 143
    //   83: aload_0
    //   84: getfield d : Landroid/os/Parcelable;
    //   87: astore_2
    //   88: aload_2
    //   89: ifnull -> 100
    //   92: aload_0
    //   93: aload_2
    //   94: putfield b : Ljava/lang/Object;
    //   97: goto -> 143
    //   100: aload_0
    //   101: getfield c : [B
    //   104: astore_2
    //   105: aload_0
    //   106: aload_2
    //   107: putfield b : Ljava/lang/Object;
    //   110: aload_0
    //   111: iconst_3
    //   112: putfield a : I
    //   115: aload_0
    //   116: iconst_0
    //   117: putfield e : I
    //   120: aload_0
    //   121: aload_2
    //   122: arraylength
    //   123: putfield f : I
    //   126: goto -> 143
    //   129: aload_0
    //   130: getfield d : Landroid/os/Parcelable;
    //   133: astore_2
    //   134: aload_2
    //   135: ifnull -> 144
    //   138: aload_0
    //   139: aload_2
    //   140: putfield b : Ljava/lang/Object;
    //   143: return
    //   144: new java/lang/IllegalArgumentException
    //   147: dup
    //   148: ldc 'Invalid icon'
    //   150: invokespecial <init> : (Ljava/lang/String;)V
    //   153: athrow
  }
  
  public String toString() {
    if (this.a == -1)
      return String.valueOf(this.b); 
    StringBuilder stringBuilder = (new StringBuilder("Icon(typ=")).append(a(this.a));
    int i = this.a;
    if (i != 1)
      if (i != 2) {
        if (i != 3) {
          if (i != 4) {
            if (i != 5)
              if (this.g != null) {
                stringBuilder.append(" tint=");
                stringBuilder.append(this.g);
              }  
          } else {
            stringBuilder.append(" uri=");
            stringBuilder.append(this.b);
            if (this.g != null) {
              stringBuilder.append(" tint=");
              stringBuilder.append(this.g);
            } 
          } 
        } else {
          stringBuilder.append(" len=");
          stringBuilder.append(this.e);
          if (this.f != 0) {
            stringBuilder.append(" off=");
            stringBuilder.append(this.f);
          } 
          if (this.g != null) {
            stringBuilder.append(" tint=");
            stringBuilder.append(this.g);
          } 
        } 
      } else {
        stringBuilder.append(" pkg=");
        stringBuilder.append(b());
        stringBuilder.append(" id=");
        stringBuilder.append(String.format("0x%08x", new Object[] { Integer.valueOf(a()) }));
        if (this.g != null) {
          stringBuilder.append(" tint=");
          stringBuilder.append(this.g);
        } 
      }  
    stringBuilder.append(" size=");
    stringBuilder.append(((Bitmap)this.b).getWidth());
    stringBuilder.append("x");
    stringBuilder.append(((Bitmap)this.b).getHeight());
    if (this.g != null) {
      stringBuilder.append(" tint=");
      stringBuilder.append(this.g);
    } 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\graphics\drawable\IconCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */