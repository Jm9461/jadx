package android.support.v4.view;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.os.Build;
import android.view.View;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;

public final class y {
  private WeakReference<View> a;
  
  Runnable b = null;
  
  Runnable c = null;
  
  int d = -1;
  
  y(View paramView) {
    this.a = new WeakReference<View>(paramView);
  }
  
  private void a(View paramView, z paramz) {
    if (paramz != null) {
      paramView.animate().setListener((Animator.AnimatorListener)new a(this, paramz, paramView));
    } else {
      paramView.animate().setListener(null);
    } 
  }
  
  public y a(float paramFloat) {
    View view = this.a.get();
    if (view != null)
      view.animate().alpha(paramFloat); 
    return this;
  }
  
  public y a(long paramLong) {
    View view = this.a.get();
    if (view != null)
      view.animate().setDuration(paramLong); 
    return this;
  }
  
  public y a(b0 paramb0) {
    View view = this.a.get();
    if (view != null && Build.VERSION.SDK_INT >= 19) {
      b b = null;
      if (paramb0 != null)
        b = new b(this, paramb0, view); 
      view.animate().setUpdateListener(b);
    } 
    return this;
  }
  
  public y a(z paramz) {
    View view = this.a.get();
    if (view != null)
      if (Build.VERSION.SDK_INT >= 16) {
        a(view, paramz);
      } else {
        view.setTag(2113929216, paramz);
        a(view, new c(this));
      }  
    return this;
  }
  
  public y a(Interpolator paramInterpolator) {
    View view = this.a.get();
    if (view != null)
      view.animate().setInterpolator((TimeInterpolator)paramInterpolator); 
    return this;
  }
  
  public void a() {
    View view = this.a.get();
    if (view != null)
      view.animate().cancel(); 
  }
  
  public long b() {
    View view = this.a.get();
    return (view != null) ? view.animate().getDuration() : 0L;
  }
  
  public y b(float paramFloat) {
    View view = this.a.get();
    if (view != null)
      view.animate().translationY(paramFloat); 
    return this;
  }
  
  public y b(long paramLong) {
    View view = this.a.get();
    if (view != null)
      view.animate().setStartDelay(paramLong); 
    return this;
  }
  
  public void c() {
    View view = this.a.get();
    if (view != null)
      view.animate().start(); 
  }
  
  class a extends AnimatorListenerAdapter {
    final z a;
    
    final View b;
    
    a(y this$0, z param1z, View param1View) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      this.a.c(this.b);
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.a(this.b);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.a.b(this.b);
    }
  }
  
  class b implements ValueAnimator.AnimatorUpdateListener {
    final b0 a;
    
    final View b;
    
    b(y this$0, b0 param1b0, View param1View) {}
    
    public void onAnimationUpdate(ValueAnimator param1ValueAnimator) {
      this.a.a(this.b);
    }
  }
  
  static class c implements z {
    y a;
    
    boolean b;
    
    c(y param1y) {
      this.a = param1y;
    }
    
    public void a(View param1View) {
      int i = this.a.d;
      if (i > -1) {
        param1View.setLayerType(i, null);
        this.a.d = -1;
      } 
      if (Build.VERSION.SDK_INT >= 16 || !this.b) {
        z z1;
        y y1 = this.a;
        if (y1.c != null) {
          Runnable runnable = y1.c;
          y1.c = null;
          runnable.run();
        } 
        Object object = param1View.getTag(2113929216);
        y1 = null;
        if (object instanceof z)
          z1 = (z)object; 
        if (z1 != null)
          z1.a(param1View); 
        this.b = true;
      } 
    }
    
    public void b(View param1View) {
      z z1;
      this.b = false;
      if (this.a.d > -1)
        param1View.setLayerType(2, null); 
      y y1 = this.a;
      if (y1.b != null) {
        Runnable runnable = y1.b;
        y1.b = null;
        runnable.run();
      } 
      Object object = param1View.getTag(2113929216);
      y1 = null;
      if (object instanceof z)
        z1 = (z)object; 
      if (z1 != null)
        z1.b(param1View); 
    }
    
    public void c(View param1View) {
      Object object = param1View.getTag(2113929216);
      z z1 = null;
      if (object instanceof z)
        z1 = (z)object; 
      if (z1 != null)
        z1.c(param1View); 
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\view\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */