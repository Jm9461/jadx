package android.support.v4.view;

import android.view.MotionEvent;

public final class i {
  public static boolean a(MotionEvent paramMotionEvent, int paramInt) {
    boolean bool;
    if ((paramMotionEvent.getSource() & paramInt) == paramInt) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\view\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */