package android.support.v4.view;

import android.view.View;

public class a0 implements z {
  public void b(View paramView) {}
  
  public void c(View paramView) {}
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\view\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */