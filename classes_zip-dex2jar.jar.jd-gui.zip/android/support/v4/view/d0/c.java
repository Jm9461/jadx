package android.support.v4.view.d0;

import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;

public class c {
  private final AccessibilityNodeInfo a;
  
  public int b = -1;
  
  private c(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    this.a = paramAccessibilityNodeInfo;
  }
  
  public static c a(c paramc) {
    return a(AccessibilityNodeInfo.obtain(paramc.a));
  }
  
  public static c a(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    return new c(paramAccessibilityNodeInfo);
  }
  
  private void a(int paramInt, boolean paramBoolean) {
    Bundle bundle = e();
    if (bundle != null) {
      int i = 0;
      int j = bundle.getInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.BOOLEAN_PROPERTY_KEY", 0);
      if (paramBoolean)
        i = paramInt; 
      bundle.putInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.BOOLEAN_PROPERTY_KEY", i | j & (paramInt ^ 0xFFFFFFFF));
    } 
  }
  
  private static String b(int paramInt) {
    if (paramInt != 1) {
      if (paramInt != 2) {
        switch (paramInt) {
          default:
            return "ACTION_UNKNOWN";
          case 131072:
            return "ACTION_SET_SELECTION";
          case 65536:
            return "ACTION_CUT";
          case 32768:
            return "ACTION_PASTE";
          case 16384:
            return "ACTION_COPY";
          case 8192:
            return "ACTION_SCROLL_BACKWARD";
          case 4096:
            return "ACTION_SCROLL_FORWARD";
          case 2048:
            return "ACTION_PREVIOUS_HTML_ELEMENT";
          case 1024:
            return "ACTION_NEXT_HTML_ELEMENT";
          case 512:
            return "ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY";
          case 256:
            return "ACTION_NEXT_AT_MOVEMENT_GRANULARITY";
          case 128:
            return "ACTION_CLEAR_ACCESSIBILITY_FOCUS";
          case 64:
            return "ACTION_ACCESSIBILITY_FOCUS";
          case 32:
            return "ACTION_LONG_CLICK";
          case 16:
            return "ACTION_CLICK";
          case 8:
            return "ACTION_CLEAR_SELECTION";
          case 4:
            break;
        } 
        return "ACTION_SELECT";
      } 
      return "ACTION_CLEAR_FOCUS";
    } 
    return "ACTION_FOCUS";
  }
  
  public static c d(View paramView) {
    return a(AccessibilityNodeInfo.obtain(paramView));
  }
  
  public static c w() {
    return a(AccessibilityNodeInfo.obtain());
  }
  
  public int a() {
    return this.a.getActions();
  }
  
  public void a(int paramInt) {
    this.a.addAction(paramInt);
  }
  
  public void a(Rect paramRect) {
    this.a.getBoundsInParent(paramRect);
  }
  
  public void a(View paramView) {
    this.a.addChild(paramView);
  }
  
  public void a(View paramView, int paramInt) {
    if (Build.VERSION.SDK_INT >= 16)
      this.a.addChild(paramView, paramInt); 
  }
  
  public void a(CharSequence paramCharSequence) {
    this.a.setClassName(paramCharSequence);
  }
  
  public void a(Object paramObject) {
    if (Build.VERSION.SDK_INT >= 19) {
      AccessibilityNodeInfo accessibilityNodeInfo = this.a;
      if (paramObject == null) {
        paramObject = null;
      } else {
        paramObject = ((b)paramObject).a;
      } 
      accessibilityNodeInfo.setCollectionInfo((AccessibilityNodeInfo.CollectionInfo)paramObject);
    } 
  }
  
  public void a(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT >= 16)
      this.a.setAccessibilityFocused(paramBoolean); 
  }
  
  public boolean a(a parama) {
    return (Build.VERSION.SDK_INT >= 21) ? this.a.removeAction((AccessibilityNodeInfo.AccessibilityAction)parama.a) : false;
  }
  
  public int b() {
    return this.a.getChildCount();
  }
  
  public void b(Rect paramRect) {
    this.a.getBoundsInScreen(paramRect);
  }
  
  public void b(View paramView) {
    this.a.setParent(paramView);
  }
  
  public void b(View paramView, int paramInt) {
    this.b = paramInt;
    if (Build.VERSION.SDK_INT >= 16)
      this.a.setParent(paramView, paramInt); 
  }
  
  public void b(CharSequence paramCharSequence) {
    this.a.setContentDescription(paramCharSequence);
  }
  
  public void b(Object paramObject) {
    if (Build.VERSION.SDK_INT >= 19) {
      AccessibilityNodeInfo accessibilityNodeInfo = this.a;
      if (paramObject == null) {
        paramObject = null;
      } else {
        paramObject = ((c)paramObject).a;
      } 
      accessibilityNodeInfo.setCollectionItemInfo((AccessibilityNodeInfo.CollectionItemInfo)paramObject);
    } 
  }
  
  public void b(boolean paramBoolean) {
    this.a.setCheckable(paramBoolean);
  }
  
  public CharSequence c() {
    return this.a.getClassName();
  }
  
  public void c(Rect paramRect) {
    this.a.setBoundsInParent(paramRect);
  }
  
  public void c(View paramView) {
    this.a.setSource(paramView);
  }
  
  public void c(View paramView, int paramInt) {
    if (Build.VERSION.SDK_INT >= 16)
      this.a.setSource(paramView, paramInt); 
  }
  
  public void c(CharSequence paramCharSequence) {
    if (Build.VERSION.SDK_INT >= 21)
      this.a.setError(paramCharSequence); 
  }
  
  public void c(boolean paramBoolean) {
    this.a.setChecked(paramBoolean);
  }
  
  public CharSequence d() {
    return this.a.getContentDescription();
  }
  
  public void d(Rect paramRect) {
    this.a.setBoundsInScreen(paramRect);
  }
  
  public void d(CharSequence paramCharSequence) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 26) {
      this.a.setHintText(paramCharSequence);
    } else if (i >= 19) {
      this.a.getExtras().putCharSequence("androidx.view.accessibility.AccessibilityNodeInfoCompat.HINT_TEXT_KEY", paramCharSequence);
    } 
  }
  
  public void d(boolean paramBoolean) {
    this.a.setClickable(paramBoolean);
  }
  
  public Bundle e() {
    return (Build.VERSION.SDK_INT >= 19) ? this.a.getExtras() : new Bundle();
  }
  
  public void e(CharSequence paramCharSequence) {
    this.a.setPackageName(paramCharSequence);
  }
  
  public void e(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT >= 19)
      this.a.setContentInvalid(paramBoolean); 
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject == null)
      return false; 
    if (getClass() != paramObject.getClass())
      return false; 
    c c1 = (c)paramObject;
    paramObject = this.a;
    if (paramObject == null) {
      if (c1.a != null)
        return false; 
    } else if (!paramObject.equals(c1.a)) {
      return false;
    } 
    return true;
  }
  
  public CharSequence f() {
    return this.a.getPackageName();
  }
  
  public void f(CharSequence paramCharSequence) {
    this.a.setText(paramCharSequence);
  }
  
  public void f(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT >= 19)
      this.a.setDismissable(paramBoolean); 
  }
  
  public CharSequence g() {
    return this.a.getText();
  }
  
  public void g(boolean paramBoolean) {
    this.a.setEnabled(paramBoolean);
  }
  
  public String h() {
    return (Build.VERSION.SDK_INT >= 18) ? this.a.getViewIdResourceName() : null;
  }
  
  public void h(boolean paramBoolean) {
    this.a.setFocusable(paramBoolean);
  }
  
  public int hashCode() {
    int i;
    AccessibilityNodeInfo accessibilityNodeInfo = this.a;
    if (accessibilityNodeInfo == null) {
      i = 0;
    } else {
      i = accessibilityNodeInfo.hashCode();
    } 
    return i;
  }
  
  public void i(boolean paramBoolean) {
    this.a.setFocused(paramBoolean);
  }
  
  public boolean i() {
    return (Build.VERSION.SDK_INT >= 16) ? this.a.isAccessibilityFocused() : false;
  }
  
  public void j(boolean paramBoolean) {
    this.a.setLongClickable(paramBoolean);
  }
  
  public boolean j() {
    return this.a.isCheckable();
  }
  
  public void k(boolean paramBoolean) {
    this.a.setScrollable(paramBoolean);
  }
  
  public boolean k() {
    return this.a.isChecked();
  }
  
  public void l(boolean paramBoolean) {
    this.a.setSelected(paramBoolean);
  }
  
  public boolean l() {
    return this.a.isClickable();
  }
  
  public void m(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT >= 26) {
      this.a.setShowingHintText(paramBoolean);
    } else {
      a(4, paramBoolean);
    } 
  }
  
  public boolean m() {
    return this.a.isEnabled();
  }
  
  public void n(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT >= 16)
      this.a.setVisibleToUser(paramBoolean); 
  }
  
  public boolean n() {
    return this.a.isFocusable();
  }
  
  public boolean o() {
    return this.a.isFocused();
  }
  
  public boolean p() {
    return this.a.isLongClickable();
  }
  
  public boolean q() {
    return this.a.isPassword();
  }
  
  public boolean r() {
    return this.a.isScrollable();
  }
  
  public boolean s() {
    return this.a.isSelected();
  }
  
  public boolean t() {
    return (Build.VERSION.SDK_INT >= 16) ? this.a.isVisibleToUser() : false;
  }
  
  public String toString() {
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(super.toString());
    Rect rect = new Rect();
    a(rect);
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append("; boundsInParent: ");
    stringBuilder3.append(rect);
    stringBuilder1.append(stringBuilder3.toString());
    b(rect);
    stringBuilder3 = new StringBuilder();
    stringBuilder3.append("; boundsInScreen: ");
    stringBuilder3.append(rect);
    stringBuilder1.append(stringBuilder3.toString());
    stringBuilder1.append("; packageName: ");
    stringBuilder1.append(f());
    stringBuilder1.append("; className: ");
    stringBuilder1.append(c());
    stringBuilder1.append("; text: ");
    stringBuilder1.append(g());
    stringBuilder1.append("; contentDescription: ");
    stringBuilder1.append(d());
    stringBuilder1.append("; viewId: ");
    stringBuilder1.append(h());
    stringBuilder1.append("; checkable: ");
    stringBuilder1.append(j());
    stringBuilder1.append("; checked: ");
    stringBuilder1.append(k());
    stringBuilder1.append("; focusable: ");
    stringBuilder1.append(n());
    stringBuilder1.append("; focused: ");
    stringBuilder1.append(o());
    stringBuilder1.append("; selected: ");
    stringBuilder1.append(s());
    stringBuilder1.append("; clickable: ");
    stringBuilder1.append(l());
    stringBuilder1.append("; longClickable: ");
    stringBuilder1.append(p());
    stringBuilder1.append("; enabled: ");
    stringBuilder1.append(m());
    stringBuilder1.append("; password: ");
    stringBuilder1.append(q());
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("; scrollable: ");
    stringBuilder2.append(r());
    stringBuilder1.append(stringBuilder2.toString());
    stringBuilder1.append("; [");
    int i = a();
    while (i != 0) {
      int j = 1 << Integer.numberOfTrailingZeros(i);
      i &= j ^ 0xFFFFFFFF;
      stringBuilder1.append(b(j));
      if (i != 0)
        stringBuilder1.append(", "); 
    } 
    stringBuilder1.append("]");
    return stringBuilder1.toString();
  }
  
  public void u() {
    this.a.recycle();
  }
  
  public AccessibilityNodeInfo v() {
    return this.a;
  }
  
  public static class a {
    public static final a b = new a(1, null);
    
    public static final a c = new a(2, null);
    
    final Object a;
    
    static {
      new a(4, null);
      new a(8, null);
      new a(16, null);
      new a(32, null);
      new a(64, null);
      new a(128, null);
      new a(256, null);
      new a(512, null);
      new a(1024, null);
      new a(2048, null);
      new a(4096, null);
      new a(8192, null);
      new a(16384, null);
      new a(32768, null);
      new a(65536, null);
      new a(131072, null);
      new a(262144, null);
      new a(524288, null);
      new a(1048576, null);
      new a(2097152, null);
      if (Build.VERSION.SDK_INT >= 23) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SHOW_ON_SCREEN;
      } else {
        accessibilityAction1 = null;
      } 
      new a(accessibilityAction1);
      if (Build.VERSION.SDK_INT >= 23) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_TO_POSITION;
      } else {
        accessibilityAction1 = null;
      } 
      new a(accessibilityAction1);
      if (Build.VERSION.SDK_INT >= 23) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP;
      } else {
        accessibilityAction1 = null;
      } 
      new a(accessibilityAction1);
      if (Build.VERSION.SDK_INT >= 23) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT;
      } else {
        accessibilityAction1 = null;
      } 
      new a(accessibilityAction1);
      if (Build.VERSION.SDK_INT >= 23) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN;
      } else {
        accessibilityAction1 = null;
      } 
      new a(accessibilityAction1);
      if (Build.VERSION.SDK_INT >= 23) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT;
      } else {
        accessibilityAction1 = null;
      } 
      new a(accessibilityAction1);
      if (Build.VERSION.SDK_INT >= 23) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_CONTEXT_CLICK;
      } else {
        accessibilityAction1 = null;
      } 
      new a(accessibilityAction1);
      if (Build.VERSION.SDK_INT >= 24) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SET_PROGRESS;
      } else {
        accessibilityAction1 = null;
      } 
      new a(accessibilityAction1);
      if (Build.VERSION.SDK_INT >= 26) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_MOVE_WINDOW;
      } else {
        accessibilityAction1 = null;
      } 
      new a(accessibilityAction1);
      if (Build.VERSION.SDK_INT >= 28) {
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SHOW_TOOLTIP;
      } else {
        accessibilityAction1 = null;
      } 
      new a(accessibilityAction1);
      AccessibilityNodeInfo.AccessibilityAction accessibilityAction1 = accessibilityAction2;
      if (Build.VERSION.SDK_INT >= 28)
        accessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_HIDE_TOOLTIP; 
      new a(accessibilityAction1);
    }
    
    public a(int param1Int, CharSequence param1CharSequence) {
      this(param1CharSequence);
    }
    
    a(Object param1Object) {
      this.a = param1Object;
    }
    
    static {
      AccessibilityNodeInfo.AccessibilityAction accessibilityAction2 = null;
    }
  }
  
  public static class b {
    final Object a;
    
    b(Object param1Object) {
      this.a = param1Object;
    }
    
    public static b a(int param1Int1, int param1Int2, boolean param1Boolean, int param1Int3) {
      int i = Build.VERSION.SDK_INT;
      return (i >= 21) ? new b(AccessibilityNodeInfo.CollectionInfo.obtain(param1Int1, param1Int2, param1Boolean, param1Int3)) : ((i >= 19) ? new b(AccessibilityNodeInfo.CollectionInfo.obtain(param1Int1, param1Int2, param1Boolean)) : new b(null));
    }
  }
  
  public static class c {
    final Object a;
    
    c(Object param1Object) {
      this.a = param1Object;
    }
    
    public static c a(int param1Int1, int param1Int2, int param1Int3, int param1Int4, boolean param1Boolean1, boolean param1Boolean2) {
      int i = Build.VERSION.SDK_INT;
      return (i >= 21) ? new c(AccessibilityNodeInfo.CollectionItemInfo.obtain(param1Int1, param1Int2, param1Int3, param1Int4, param1Boolean1, param1Boolean2)) : ((i >= 19) ? new c(AccessibilityNodeInfo.CollectionItemInfo.obtain(param1Int1, param1Int2, param1Int3, param1Int4, param1Boolean1)) : new c(null));
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\view\d0\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */