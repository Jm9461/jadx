package android.support.v4.view;

import a.b.a.c;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;

public final class w {
  public static boolean a(ViewGroup paramViewGroup) {
    if (Build.VERSION.SDK_INT >= 21)
      return paramViewGroup.isTransitionGroup(); 
    Boolean bool = (Boolean)paramViewGroup.getTag(c.tag_transition_group);
    return ((bool != null && bool.booleanValue()) || paramViewGroup.getBackground() != null || u.q((View)paramViewGroup) != null);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\view\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */