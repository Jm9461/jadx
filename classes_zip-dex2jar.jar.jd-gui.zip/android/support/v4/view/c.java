package android.support.v4.view;

import android.content.Context;
import android.util.Log;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

public abstract class c {
  private b a;
  
  public c(Context paramContext) {}
  
  public View a(MenuItem paramMenuItem) {
    return c();
  }
  
  public void a(a parama) {}
  
  public void a(b paramb) {
    if (this.a != null && paramb != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("setVisibilityListener: Setting a new ActionProvider.VisibilityListener when one is already set. Are you reusing this ");
      stringBuilder.append(getClass().getSimpleName());
      stringBuilder.append(" instance while it is still in use somewhere else?");
      Log.w("ActionProvider(support)", stringBuilder.toString());
    } 
    this.a = paramb;
  }
  
  public void a(SubMenu paramSubMenu) {}
  
  public boolean a() {
    return false;
  }
  
  public boolean b() {
    return true;
  }
  
  public abstract View c();
  
  public boolean d() {
    return false;
  }
  
  public boolean e() {
    return false;
  }
  
  public void f() {
    this.a = null;
  }
  
  public static interface a {}
  
  public static interface b {
    void onActionProviderVisibilityChanged(boolean param1Boolean);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\view\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */