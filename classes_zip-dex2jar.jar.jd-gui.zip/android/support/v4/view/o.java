package android.support.v4.view;

import android.view.View;
import android.view.ViewGroup;

public class o {
  private int a;
  
  public o(ViewGroup paramViewGroup) {}
  
  public int a() {
    return this.a;
  }
  
  public void a(View paramView, int paramInt) {
    this.a = 0;
  }
  
  public void a(View paramView1, View paramView2, int paramInt) {
    a(paramView1, paramView2, paramInt, 0);
  }
  
  public void a(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    this.a = paramInt1;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\view\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */