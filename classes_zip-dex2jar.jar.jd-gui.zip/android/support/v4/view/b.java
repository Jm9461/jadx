package android.support.v4.view;

import android.os.Build;
import android.os.Bundle;
import android.support.v4.view.d0.c;
import android.support.v4.view.d0.d;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;

public class b {
  private static final View.AccessibilityDelegate b = new View.AccessibilityDelegate();
  
  private final View.AccessibilityDelegate a = new a(this);
  
  public d a(View paramView) {
    if (Build.VERSION.SDK_INT >= 16) {
      AccessibilityNodeProvider accessibilityNodeProvider = b.getAccessibilityNodeProvider(paramView);
      if (accessibilityNodeProvider != null)
        return new d(accessibilityNodeProvider); 
    } 
    return null;
  }
  
  View.AccessibilityDelegate a() {
    return this.a;
  }
  
  public void a(View paramView, int paramInt) {
    b.sendAccessibilityEvent(paramView, paramInt);
  }
  
  public void a(View paramView, c paramc) {
    b.onInitializeAccessibilityNodeInfo(paramView, paramc.v());
  }
  
  public boolean a(View paramView, int paramInt, Bundle paramBundle) {
    return (Build.VERSION.SDK_INT >= 16) ? b.performAccessibilityAction(paramView, paramInt, paramBundle) : false;
  }
  
  public boolean a(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    return b.dispatchPopulateAccessibilityEvent(paramView, paramAccessibilityEvent);
  }
  
  public boolean a(ViewGroup paramViewGroup, View paramView, AccessibilityEvent paramAccessibilityEvent) {
    return b.onRequestSendAccessibilityEvent(paramViewGroup, paramView, paramAccessibilityEvent);
  }
  
  public void b(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    b.onInitializeAccessibilityEvent(paramView, paramAccessibilityEvent);
  }
  
  public void c(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    b.onPopulateAccessibilityEvent(paramView, paramAccessibilityEvent);
  }
  
  public void d(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    b.sendAccessibilityEventUnchecked(paramView, paramAccessibilityEvent);
  }
  
  private static final class a extends View.AccessibilityDelegate {
    private final b a;
    
    a(b param1b) {
      this.a = param1b;
    }
    
    public boolean dispatchPopulateAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      return this.a.a(param1View, param1AccessibilityEvent);
    }
    
    public AccessibilityNodeProvider getAccessibilityNodeProvider(View param1View) {
      d d = this.a.a(param1View);
      if (d != null) {
        AccessibilityNodeProvider accessibilityNodeProvider = (AccessibilityNodeProvider)d.a();
      } else {
        d = null;
      } 
      return (AccessibilityNodeProvider)d;
    }
    
    public void onInitializeAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      this.a.b(param1View, param1AccessibilityEvent);
    }
    
    public void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfo param1AccessibilityNodeInfo) {
      this.a.a(param1View, c.a(param1AccessibilityNodeInfo));
    }
    
    public void onPopulateAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      this.a.c(param1View, param1AccessibilityEvent);
    }
    
    public boolean onRequestSendAccessibilityEvent(ViewGroup param1ViewGroup, View param1View, AccessibilityEvent param1AccessibilityEvent) {
      return this.a.a(param1ViewGroup, param1View, param1AccessibilityEvent);
    }
    
    public boolean performAccessibilityAction(View param1View, int param1Int, Bundle param1Bundle) {
      return this.a.a(param1View, param1Int, param1Bundle);
    }
    
    public void sendAccessibilityEvent(View param1View, int param1Int) {
      this.a.a(param1View, param1Int);
    }
    
    public void sendAccessibilityEventUnchecked(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      this.a.d(param1View, param1AccessibilityEvent);
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\view\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */