package android.support.v4.widget;

import a.b.g.g.o;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.v4.view.b;
import android.support.v4.view.d0.d;
import android.support.v4.view.d0.e;
import android.support.v4.view.u;
import android.support.v4.view.x;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityRecord;
import java.util.ArrayList;
import java.util.List;

public abstract class h extends b {
  private static final Rect m = new Rect(2147483647, 2147483647, -2147483648, -2147483648);
  
  private final Rect c = new Rect();
  
  private final Rect d = new Rect();
  
  private final Rect e = new Rect();
  
  private final int[] f = new int[2];
  
  private final AccessibilityManager g;
  
  private final View h;
  
  private c i;
  
  int j = Integer.MIN_VALUE;
  
  int k = Integer.MIN_VALUE;
  
  private int l = Integer.MIN_VALUE;
  
  static {
    new a();
    new b();
  }
  
  public h(View paramView) {
    if (paramView != null) {
      this.h = paramView;
      this.g = (AccessibilityManager)paramView.getContext().getSystemService("accessibility");
      paramView.setFocusable(true);
      if (u.i(paramView) == 0)
        u.f(paramView, 1); 
      return;
    } 
    throw new IllegalArgumentException("View may not be null");
  }
  
  private boolean a(int paramInt, Bundle paramBundle) {
    return u.a(this.h, paramInt, paramBundle);
  }
  
  private boolean a(Rect paramRect) {
    boolean bool = false;
    if (paramRect == null || paramRect.isEmpty())
      return false; 
    if (this.h.getWindowVisibility() != 0)
      return false; 
    ViewParent viewParent = this.h.getParent();
    while (viewParent instanceof View) {
      View view = (View)viewParent;
      if (view.getAlpha() <= 0.0F || view.getVisibility() != 0)
        return false; 
      viewParent = view.getParent();
    } 
    if (viewParent != null)
      bool = true; 
    return bool;
  }
  
  private AccessibilityEvent c(int paramInt1, int paramInt2) {
    return (paramInt1 != -1) ? d(paramInt1, paramInt2) : e(paramInt2);
  }
  
  private boolean c(int paramInt1, int paramInt2, Bundle paramBundle) {
    return (paramInt2 != 1) ? ((paramInt2 != 2) ? ((paramInt2 != 64) ? ((paramInt2 != 128) ? a(paramInt1, paramInt2, paramBundle) : d(paramInt1)) : g(paramInt1)) : a(paramInt1)) : c(paramInt1);
  }
  
  private AccessibilityEvent d(int paramInt1, int paramInt2) {
    AccessibilityEvent accessibilityEvent = AccessibilityEvent.obtain(paramInt2);
    android.support.v4.view.d0.c c1 = b(paramInt1);
    accessibilityEvent.getText().add(c1.g());
    accessibilityEvent.setContentDescription(c1.d());
    accessibilityEvent.setScrollable(c1.r());
    accessibilityEvent.setPassword(c1.q());
    accessibilityEvent.setEnabled(c1.m());
    accessibilityEvent.setChecked(c1.k());
    a(paramInt1, accessibilityEvent);
    if (!accessibilityEvent.getText().isEmpty() || accessibilityEvent.getContentDescription() != null) {
      accessibilityEvent.setClassName(c1.c());
      e.a((AccessibilityRecord)accessibilityEvent, this.h, paramInt1);
      accessibilityEvent.setPackageName(this.h.getContext().getPackageName());
      return accessibilityEvent;
    } 
    throw new RuntimeException("Callbacks must add text or a content description in populateEventForVirtualViewId()");
  }
  
  private boolean d(int paramInt) {
    if (this.j == paramInt) {
      this.j = Integer.MIN_VALUE;
      this.h.invalidate();
      b(paramInt, 65536);
      return true;
    } 
    return false;
  }
  
  private android.support.v4.view.d0.c e() {
    android.support.v4.view.d0.c c1 = android.support.v4.view.d0.c.d(this.h);
    u.a(this.h, c1);
    ArrayList<Integer> arrayList = new ArrayList();
    a(arrayList);
    if (c1.b() <= 0 || arrayList.size() <= 0) {
      byte b1 = 0;
      int i = arrayList.size();
      while (b1 < i) {
        c1.a(this.h, ((Integer)arrayList.get(b1)).intValue());
        b1++;
      } 
      return c1;
    } 
    throw new RuntimeException("Views cannot have both real and virtual children");
  }
  
  private AccessibilityEvent e(int paramInt) {
    AccessibilityEvent accessibilityEvent = AccessibilityEvent.obtain(paramInt);
    this.h.onInitializeAccessibilityEvent(accessibilityEvent);
    return accessibilityEvent;
  }
  
  private android.support.v4.view.d0.c f(int paramInt) {
    android.support.v4.view.d0.c c1 = android.support.v4.view.d0.c.w();
    c1.g(true);
    c1.h(true);
    c1.a("android.view.View");
    c1.c(m);
    c1.d(m);
    c1.b(this.h);
    a(paramInt, c1);
    if (c1.g() != null || c1.d() != null) {
      c1.a(this.d);
      if (!this.d.equals(m)) {
        int i = c1.a();
        if ((i & 0x40) == 0) {
          if ((i & 0x80) == 0) {
            boolean bool;
            c1.e(this.h.getContext().getPackageName());
            c1.c(this.h, paramInt);
            if (this.j == paramInt) {
              c1.a(true);
              c1.a(128);
            } else {
              c1.a(false);
              c1.a(64);
            } 
            if (this.k == paramInt) {
              bool = true;
            } else {
              bool = false;
            } 
            if (bool) {
              c1.a(2);
            } else if (c1.n()) {
              c1.a(1);
            } 
            c1.i(bool);
            this.h.getLocationOnScreen(this.f);
            c1.b(this.c);
            if (this.c.equals(m)) {
              c1.a(this.c);
              if (c1.b != -1) {
                android.support.v4.view.d0.c c2 = android.support.v4.view.d0.c.w();
                for (paramInt = c1.b; paramInt != -1; paramInt = c2.b) {
                  c2.b(this.h, -1);
                  c2.c(m);
                  a(paramInt, c2);
                  c2.a(this.d);
                  Rect rect2 = this.c;
                  Rect rect1 = this.d;
                  rect2.offset(rect1.left, rect1.top);
                } 
                c2.u();
              } 
              this.c.offset(this.f[0] - this.h.getScrollX(), this.f[1] - this.h.getScrollY());
            } 
            if (this.h.getLocalVisibleRect(this.e)) {
              this.e.offset(this.f[0] - this.h.getScrollX(), this.f[1] - this.h.getScrollY());
              if (this.c.intersect(this.e)) {
                c1.d(this.c);
                if (a(this.c))
                  c1.n(true); 
              } 
            } 
            return c1;
          } 
          throw new RuntimeException("Callbacks must not add ACTION_CLEAR_ACCESSIBILITY_FOCUS in populateNodeForVirtualViewId()");
        } 
        throw new RuntimeException("Callbacks must not add ACTION_ACCESSIBILITY_FOCUS in populateNodeForVirtualViewId()");
      } 
      RuntimeException runtimeException = new RuntimeException("Callbacks must set parent bounds in populateNodeForVirtualViewId()");
      throw runtimeException;
    } 
    throw new RuntimeException("Callbacks must add text or a content description in populateNodeForVirtualViewId()");
  }
  
  private boolean g(int paramInt) {
    if (!this.g.isEnabled() || !this.g.isTouchExplorationEnabled())
      return false; 
    int i = this.j;
    if (i != paramInt) {
      if (i != Integer.MIN_VALUE)
        d(i); 
      this.j = paramInt;
      this.h.invalidate();
      b(paramInt, 32768);
      return true;
    } 
    return false;
  }
  
  private void h(int paramInt) {
    if (this.l == paramInt)
      return; 
    int i = this.l;
    this.l = paramInt;
    b(paramInt, 128);
    b(i, 256);
  }
  
  protected abstract int a(float paramFloat1, float paramFloat2);
  
  public d a(View paramView) {
    if (this.i == null)
      this.i = new c(this); 
    return this.i;
  }
  
  public final void a(int paramInt1, int paramInt2) {
    if (paramInt1 != Integer.MIN_VALUE && this.g.isEnabled()) {
      ViewParent viewParent = this.h.getParent();
      if (viewParent != null) {
        AccessibilityEvent accessibilityEvent = c(paramInt1, 2048);
        android.support.v4.view.d0.a.a(accessibilityEvent, paramInt2);
        x.a(viewParent, this.h, accessibilityEvent);
      } 
    } 
  }
  
  protected abstract void a(int paramInt, android.support.v4.view.d0.c paramc);
  
  protected abstract void a(int paramInt, AccessibilityEvent paramAccessibilityEvent);
  
  protected void a(int paramInt, boolean paramBoolean) {}
  
  protected void a(android.support.v4.view.d0.c paramc) {}
  
  public void a(View paramView, android.support.v4.view.d0.c paramc) {
    super.a(paramView, paramc);
    a(paramc);
  }
  
  protected void a(AccessibilityEvent paramAccessibilityEvent) {}
  
  protected abstract void a(List<Integer> paramList);
  
  public final boolean a(int paramInt) {
    if (this.k != paramInt)
      return false; 
    this.k = Integer.MIN_VALUE;
    a(paramInt, false);
    b(paramInt, 8);
    return true;
  }
  
  protected abstract boolean a(int paramInt1, int paramInt2, Bundle paramBundle);
  
  public final boolean a(MotionEvent paramMotionEvent) {
    boolean bool1 = this.g.isEnabled();
    boolean bool = false;
    if (!bool1 || !this.g.isTouchExplorationEnabled())
      return false; 
    int i = paramMotionEvent.getAction();
    if (i != 7 && i != 9) {
      if (i != 10)
        return false; 
      if (this.l != Integer.MIN_VALUE) {
        h(-2147483648);
        return true;
      } 
      return false;
    } 
    i = a(paramMotionEvent.getX(), paramMotionEvent.getY());
    h(i);
    if (i != Integer.MIN_VALUE)
      bool = true; 
    return bool;
  }
  
  public final int b() {
    return this.j;
  }
  
  android.support.v4.view.d0.c b(int paramInt) {
    return (paramInt == -1) ? e() : f(paramInt);
  }
  
  public void b(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    super.b(paramView, paramAccessibilityEvent);
    a(paramAccessibilityEvent);
  }
  
  public final boolean b(int paramInt1, int paramInt2) {
    if (paramInt1 == Integer.MIN_VALUE || !this.g.isEnabled())
      return false; 
    ViewParent viewParent = this.h.getParent();
    if (viewParent == null)
      return false; 
    AccessibilityEvent accessibilityEvent = c(paramInt1, paramInt2);
    return x.a(viewParent, this.h, accessibilityEvent);
  }
  
  boolean b(int paramInt1, int paramInt2, Bundle paramBundle) {
    return (paramInt1 != -1) ? c(paramInt1, paramInt2, paramBundle) : a(paramInt2, paramBundle);
  }
  
  @Deprecated
  public int c() {
    return b();
  }
  
  public final boolean c(int paramInt) {
    if (!this.h.isFocused() && !this.h.requestFocus())
      return false; 
    int i = this.k;
    if (i == paramInt)
      return false; 
    if (i != Integer.MIN_VALUE)
      a(i); 
    this.k = paramInt;
    a(paramInt, true);
    b(paramInt, 8);
    return true;
  }
  
  public final void d() {
    a(-1, 1);
  }
  
  static final class a implements i<android.support.v4.view.d0.c> {}
  
  static final class b implements j<o<android.support.v4.view.d0.c>, android.support.v4.view.d0.c> {}
  
  private class c extends d {
    final h b;
    
    c(h this$0) {}
    
    public android.support.v4.view.d0.c a(int param1Int) {
      return android.support.v4.view.d0.c.a(this.b.b(param1Int));
    }
    
    public boolean a(int param1Int1, int param1Int2, Bundle param1Bundle) {
      return this.b.b(param1Int1, param1Int2, param1Bundle);
    }
    
    public android.support.v4.view.d0.c b(int param1Int) {
      if (param1Int == 2) {
        param1Int = this.b.j;
      } else {
        param1Int = this.b.k;
      } 
      return (param1Int == Integer.MIN_VALUE) ? null : a(param1Int);
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\widget\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */