package android.support.v4.widget;

import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;

public abstract class d extends BaseAdapter implements Filterable, e.a {
  protected boolean c;
  
  protected boolean d;
  
  protected Cursor e;
  
  protected Context f;
  
  protected int g;
  
  protected a h;
  
  protected DataSetObserver i;
  
  protected e j;
  
  public d(Context paramContext, Cursor paramCursor, boolean paramBoolean) {
    byte b;
    if (paramBoolean) {
      b = 1;
    } else {
      b = 2;
    } 
    a(paramContext, paramCursor, b);
  }
  
  public Cursor a() {
    return this.e;
  }
  
  public abstract View a(Context paramContext, Cursor paramCursor, ViewGroup paramViewGroup);
  
  public abstract CharSequence a(Cursor paramCursor);
  
  void a(Context paramContext, Cursor paramCursor, int paramInt) {
    byte b;
    boolean bool = false;
    if ((paramInt & 0x1) == 1) {
      paramInt |= 0x2;
      this.d = true;
    } else {
      this.d = false;
    } 
    if (paramCursor != null)
      bool = true; 
    this.e = paramCursor;
    this.c = bool;
    this.f = paramContext;
    if (bool) {
      b = paramCursor.getColumnIndexOrThrow("_id");
    } else {
      b = -1;
    } 
    this.g = b;
    if ((paramInt & 0x2) == 2) {
      this.h = new a(this);
      this.i = new b(this);
    } else {
      this.h = null;
      this.i = null;
    } 
    if (bool) {
      a a1 = this.h;
      if (a1 != null)
        paramCursor.registerContentObserver(a1); 
      DataSetObserver dataSetObserver = this.i;
      if (dataSetObserver != null)
        paramCursor.registerDataSetObserver(dataSetObserver); 
    } 
  }
  
  public abstract void a(View paramView, Context paramContext, Cursor paramCursor);
  
  public abstract View b(Context paramContext, Cursor paramCursor, ViewGroup paramViewGroup);
  
  protected void b() {
    if (this.d) {
      Cursor cursor = this.e;
      if (cursor != null && !cursor.isClosed())
        this.c = this.e.requery(); 
    } 
  }
  
  public void b(Cursor paramCursor) {
    paramCursor = c(paramCursor);
    if (paramCursor != null)
      paramCursor.close(); 
  }
  
  public Cursor c(Cursor paramCursor) {
    if (paramCursor == this.e)
      return null; 
    Cursor cursor = this.e;
    if (cursor != null) {
      a a1 = this.h;
      if (a1 != null)
        cursor.unregisterContentObserver(a1); 
      DataSetObserver dataSetObserver = this.i;
      if (dataSetObserver != null)
        cursor.unregisterDataSetObserver(dataSetObserver); 
    } 
    this.e = paramCursor;
    if (paramCursor != null) {
      a a1 = this.h;
      if (a1 != null)
        paramCursor.registerContentObserver(a1); 
      DataSetObserver dataSetObserver = this.i;
      if (dataSetObserver != null)
        paramCursor.registerDataSetObserver(dataSetObserver); 
      this.g = paramCursor.getColumnIndexOrThrow("_id");
      this.c = true;
      notifyDataSetChanged();
    } else {
      this.g = -1;
      this.c = false;
      notifyDataSetInvalidated();
    } 
    return cursor;
  }
  
  public int getCount() {
    if (this.c) {
      Cursor cursor = this.e;
      if (cursor != null)
        return cursor.getCount(); 
    } 
    return 0;
  }
  
  public View getDropDownView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    if (this.c) {
      this.e.moveToPosition(paramInt);
      if (paramView == null)
        paramView = a(this.f, this.e, paramViewGroup); 
      a(paramView, this.f, this.e);
      return paramView;
    } 
    return null;
  }
  
  public Filter getFilter() {
    if (this.j == null)
      this.j = new e(this); 
    return this.j;
  }
  
  public Object getItem(int paramInt) {
    if (this.c) {
      Cursor cursor = this.e;
      if (cursor != null) {
        cursor.moveToPosition(paramInt);
        return this.e;
      } 
    } 
    return null;
  }
  
  public long getItemId(int paramInt) {
    if (this.c) {
      Cursor cursor = this.e;
      if (cursor != null)
        return cursor.moveToPosition(paramInt) ? this.e.getLong(this.g) : 0L; 
    } 
    return 0L;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    if (this.c) {
      if (this.e.moveToPosition(paramInt)) {
        if (paramView == null)
          paramView = b(this.f, this.e, paramViewGroup); 
        a(paramView, this.f, this.e);
        return paramView;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("couldn't move cursor to position ");
      stringBuilder.append(paramInt);
      throw new IllegalStateException(stringBuilder.toString());
    } 
    throw new IllegalStateException("this should only be called when the cursor is valid");
  }
  
  private class a extends ContentObserver {
    final d a;
    
    a(d this$0) {
      super(new Handler());
    }
    
    public boolean deliverSelfNotifications() {
      return true;
    }
    
    public void onChange(boolean param1Boolean) {
      this.a.b();
    }
  }
  
  private class b extends DataSetObserver {
    final d a;
    
    b(d this$0) {}
    
    public void onChanged() {
      d d1 = this.a;
      d1.c = true;
      d1.notifyDataSetChanged();
    }
    
    public void onInvalidated() {
      d d1 = this.a;
      d1.c = false;
      d1.notifyDataSetInvalidated();
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\widget\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */