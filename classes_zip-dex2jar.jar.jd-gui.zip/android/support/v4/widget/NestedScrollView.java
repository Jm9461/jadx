package android.support.v4.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.view.d0.e;
import android.support.v4.view.j;
import android.support.v4.view.l;
import android.support.v4.view.m;
import android.support.v4.view.o;
import android.support.v4.view.s;
import android.support.v4.view.u;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityRecord;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import java.util.ArrayList;

public class NestedScrollView extends FrameLayout implements m, j, s {
  private static final a C = new a();
  
  private static final int[] D = new int[] { 16843130 };
  
  private float A;
  
  private b B;
  
  private long c;
  
  private final Rect d = new Rect();
  
  private OverScroller e;
  
  private EdgeEffect f;
  
  private EdgeEffect g;
  
  private int h;
  
  private boolean i = true;
  
  private boolean j = false;
  
  private View k = null;
  
  private boolean l = false;
  
  private VelocityTracker m;
  
  private boolean n;
  
  private boolean o = true;
  
  private int p;
  
  private int q;
  
  private int r;
  
  private int s = -1;
  
  private final int[] t = new int[2];
  
  private final int[] u = new int[2];
  
  private int v;
  
  private int w;
  
  private c x;
  
  private final o y;
  
  private final l z;
  
  public NestedScrollView(Context paramContext) {
    this(paramContext, null);
  }
  
  public NestedScrollView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public NestedScrollView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    e();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, D, paramInt, 0);
    setFillViewport(typedArray.getBoolean(0, false));
    typedArray.recycle();
    this.y = new o((ViewGroup)this);
    this.z = new l((View)this);
    setNestedScrollingEnabled(true);
    u.a((View)this, C);
  }
  
  private static int a(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt2 >= paramInt3 || paramInt1 < 0) ? 0 : ((paramInt2 + paramInt1 > paramInt3) ? (paramInt3 - paramInt2) : paramInt1);
  }
  
  private View a(boolean paramBoolean, int paramInt1, int paramInt2) {
    ArrayList<View> arrayList = getFocusables(2);
    View view = null;
    boolean bool = false;
    int i = arrayList.size();
    byte b1 = 0;
    while (b1 < i) {
      View view2 = arrayList.get(b1);
      int k = view2.getTop();
      int n = view2.getBottom();
      View view1 = view;
      boolean bool1 = bool;
      if (paramInt1 < n) {
        view1 = view;
        bool1 = bool;
        if (k < paramInt2) {
          boolean bool2;
          boolean bool3 = false;
          if (paramInt1 < k && n < paramInt2) {
            bool2 = true;
          } else {
            bool2 = false;
          } 
          if (view == null) {
            view1 = view2;
            bool1 = bool2;
          } else {
            if ((paramBoolean && k < view.getTop()) || (!paramBoolean && n > view.getBottom()))
              bool3 = true; 
            if (bool) {
              view1 = view;
              bool1 = bool;
              if (bool2) {
                view1 = view;
                bool1 = bool;
                if (bool3) {
                  view1 = view2;
                  bool1 = bool;
                } 
              } 
            } else if (bool2) {
              view1 = view2;
              bool1 = true;
            } else {
              view1 = view;
              bool1 = bool;
              if (bool3) {
                view1 = view2;
                bool1 = bool;
              } 
            } 
          } 
        } 
      } 
      b1++;
      view = view1;
      bool = bool1;
    } 
    return view;
  }
  
  private void a(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(i) == this.s) {
      if (i == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      this.h = (int)paramMotionEvent.getY(i);
      this.s = paramMotionEvent.getPointerId(i);
      VelocityTracker velocityTracker = this.m;
      if (velocityTracker != null)
        velocityTracker.clear(); 
    } 
  }
  
  private boolean a() {
    int i = getChildCount();
    boolean bool = false;
    if (i > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      if (view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin > getHeight() - getPaddingTop() - getPaddingBottom())
        bool = true; 
      return bool;
    } 
    return false;
  }
  
  private boolean a(Rect paramRect, boolean paramBoolean) {
    boolean bool;
    int i = a(paramRect);
    if (i != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      if (paramBoolean) {
        scrollBy(0, i);
      } else {
        a(0, i);
      }  
    return bool;
  }
  
  private boolean a(View paramView) {
    return a(paramView, 0, getHeight()) ^ true;
  }
  
  private boolean a(View paramView, int paramInt1, int paramInt2) {
    boolean bool;
    paramView.getDrawingRect(this.d);
    offsetDescendantRectToMyCoords(paramView, this.d);
    if (this.d.bottom + paramInt1 >= getScrollY() && this.d.top - paramInt1 <= getScrollY() + paramInt2) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private static boolean a(View paramView1, View paramView2) {
    boolean bool = true;
    if (paramView1 == paramView2)
      return true; 
    ViewParent viewParent = paramView1.getParent();
    if (!(viewParent instanceof ViewGroup) || !a((View)viewParent, paramView2))
      bool = false; 
    return bool;
  }
  
  private void b() {
    this.l = false;
    g();
    a(0);
    EdgeEffect edgeEffect = this.f;
    if (edgeEffect != null) {
      edgeEffect.onRelease();
      this.g.onRelease();
    } 
  }
  
  private void b(View paramView) {
    paramView.getDrawingRect(this.d);
    offsetDescendantRectToMyCoords(paramView, this.d);
    int i = a(this.d);
    if (i != 0)
      scrollBy(0, i); 
  }
  
  private boolean b(int paramInt1, int paramInt2, int paramInt3) {
    boolean bool1;
    NestedScrollView nestedScrollView;
    boolean bool2 = true;
    int k = getHeight();
    int i = getScrollY();
    k = i + k;
    if (paramInt1 == 33) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    View view2 = a(bool1, paramInt2, paramInt3);
    View view1 = view2;
    if (view2 == null)
      nestedScrollView = this; 
    if (paramInt2 >= i && paramInt3 <= k) {
      bool1 = false;
    } else {
      if (bool1) {
        paramInt2 -= i;
      } else {
        paramInt2 = paramInt3 - k;
      } 
      g(paramInt2);
      bool1 = bool2;
    } 
    if (nestedScrollView != findFocus())
      nestedScrollView.requestFocus(paramInt1); 
    return bool1;
  }
  
  private void c() {
    if (getOverScrollMode() != 2) {
      if (this.f == null) {
        Context context = getContext();
        this.f = new EdgeEffect(context);
        this.g = new EdgeEffect(context);
      } 
    } else {
      this.f = null;
      this.g = null;
    } 
  }
  
  private void d() {
    VelocityTracker velocityTracker = this.m;
    if (velocityTracker == null) {
      this.m = VelocityTracker.obtain();
    } else {
      velocityTracker.clear();
    } 
  }
  
  private boolean d(int paramInt1, int paramInt2) {
    int i = getChildCount();
    boolean bool = false;
    if (i > 0) {
      i = getScrollY();
      View view = getChildAt(0);
      if (paramInt2 >= view.getTop() - i && paramInt2 < view.getBottom() - i && paramInt1 >= view.getLeft() && paramInt1 < view.getRight())
        bool = true; 
      return bool;
    } 
    return false;
  }
  
  private void e() {
    this.e = new OverScroller(getContext());
    setFocusable(true);
    setDescendantFocusability(262144);
    setWillNotDraw(false);
    ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
    this.p = viewConfiguration.getScaledTouchSlop();
    this.q = viewConfiguration.getScaledMinimumFlingVelocity();
    this.r = viewConfiguration.getScaledMaximumFlingVelocity();
  }
  
  private void f() {
    if (this.m == null)
      this.m = VelocityTracker.obtain(); 
  }
  
  private void g() {
    VelocityTracker velocityTracker = this.m;
    if (velocityTracker != null) {
      velocityTracker.recycle();
      this.m = null;
    } 
  }
  
  private void g(int paramInt) {
    if (paramInt != 0)
      if (this.o) {
        a(0, paramInt);
      } else {
        scrollBy(0, paramInt);
      }  
  }
  
  private float getVerticalScrollFactorCompat() {
    if (this.A == 0.0F) {
      TypedValue typedValue = new TypedValue();
      Context context = getContext();
      if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
        this.A = typedValue.getDimension(context.getResources().getDisplayMetrics());
      } else {
        throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
      } 
    } 
    return this.A;
  }
  
  private void h(int paramInt) {
    boolean bool;
    int i = getScrollY();
    if ((i > 0 || paramInt > 0) && (i < getScrollRange() || paramInt < 0)) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!dispatchNestedPreFling(0.0F, paramInt)) {
      dispatchNestedFling(0.0F, paramInt, bool);
      c(paramInt);
    } 
  }
  
  protected int a(Rect paramRect) {
    if (getChildCount() == 0)
      return 0; 
    int i3 = getHeight();
    int i = getScrollY();
    int n = i + i3;
    int i1 = getVerticalFadingEdgeLength();
    int k = i;
    if (paramRect.top > 0)
      k = i + i1; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    i = n;
    if (paramRect.bottom < view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin)
      i = n - i1; 
    int i2 = i;
    i1 = 0;
    if (paramRect.bottom > i2 && paramRect.top > k) {
      if (paramRect.height() > i3) {
        i = 0 + paramRect.top - k;
      } else {
        i = 0 + paramRect.bottom - i2;
      } 
      i = Math.min(i, view.getBottom() + layoutParams.bottomMargin - n);
    } else {
      i = i1;
      if (paramRect.top < k) {
        i = i1;
        if (paramRect.bottom < i2) {
          if (paramRect.height() > i3) {
            i = 0 - i2 - paramRect.bottom;
          } else {
            i = 0 - k - paramRect.top;
          } 
          i = Math.max(i, -getScrollY());
        } 
      } 
    } 
    return i;
  }
  
  public void a(int paramInt) {
    this.z.c(paramInt);
  }
  
  public final void a(int paramInt1, int paramInt2) {
    if (getChildCount() == 0)
      return; 
    if (AnimationUtils.currentAnimationTimeMillis() - this.c > 250L) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int i2 = view.getHeight();
      int k = layoutParams.topMargin;
      int i3 = layoutParams.bottomMargin;
      int n = getHeight();
      int i = getPaddingTop();
      int i1 = getPaddingBottom();
      paramInt1 = getScrollY();
      paramInt2 = Math.max(0, Math.min(paramInt1 + paramInt2, Math.max(0, i2 + k + i3 - n - i - i1)));
      this.w = getScrollY();
      this.e.startScroll(getScrollX(), paramInt1, 0, paramInt2 - paramInt1);
      u.B((View)this);
    } else {
      if (!this.e.isFinished())
        this.e.abortAnimation(); 
      scrollBy(paramInt1, paramInt2);
    } 
    this.c = AnimationUtils.currentAnimationTimeMillis();
  }
  
  public void a(View paramView, int paramInt) {
    this.y.a(paramView, paramInt);
    a(paramInt);
  }
  
  public void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    paramInt1 = getScrollY();
    scrollBy(0, paramInt4);
    paramInt1 = getScrollY() - paramInt1;
    a(0, paramInt1, 0, paramInt4 - paramInt1, (int[])null, paramInt5);
  }
  
  public void a(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    a(paramInt1, paramInt2, paramArrayOfint, (int[])null, paramInt3);
  }
  
  public void a(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    this.y.a(paramView1, paramView2, paramInt1, paramInt2);
    c(2, paramInt2);
  }
  
  boolean a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean) {
    boolean bool1;
    boolean bool2;
    boolean bool3;
    int i = getOverScrollMode();
    if (computeHorizontalScrollRange() > computeHorizontalScrollExtent()) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (computeVerticalScrollRange() > computeVerticalScrollExtent()) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (i == 0 || (i == 1 && bool2)) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (i == 0 || (i == 1 && bool1)) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    paramInt3 += paramInt1;
    if (!bool2) {
      paramInt1 = 0;
    } else {
      paramInt1 = paramInt7;
    } 
    paramInt4 += paramInt2;
    if (!bool1) {
      paramInt2 = 0;
    } else {
      paramInt2 = paramInt8;
    } 
    paramInt7 = -paramInt1;
    paramInt1 += paramInt5;
    paramInt5 = -paramInt2;
    paramInt2 += paramInt6;
    if (paramInt3 > paramInt1) {
      paramBoolean = true;
    } else if (paramInt3 < paramInt7) {
      paramInt1 = paramInt7;
      paramBoolean = true;
    } else {
      paramBoolean = false;
      paramInt1 = paramInt3;
    } 
    if (paramInt4 > paramInt2) {
      bool3 = true;
    } else if (paramInt4 < paramInt5) {
      paramInt2 = paramInt5;
      bool3 = true;
    } else {
      paramInt2 = paramInt4;
      bool3 = false;
    } 
    if (bool3 && !e(1))
      this.e.springBack(paramInt1, paramInt2, 0, 0, 0, getScrollRange()); 
    onOverScrolled(paramInt1, paramInt2, paramBoolean, bool3);
    return (paramBoolean || bool3);
  }
  
  public boolean a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint, int paramInt5) {
    return this.z.a(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint, paramInt5);
  }
  
  public boolean a(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt3) {
    return this.z.a(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, paramInt3);
  }
  
  public boolean a(KeyEvent paramKeyEvent) {
    View view;
    this.d.setEmpty();
    boolean bool = a();
    char c1 = '';
    if (!bool) {
      boolean bool2 = isFocused();
      bool = false;
      if (bool2 && paramKeyEvent.getKeyCode() != 4) {
        View view1 = findFocus();
        view = view1;
        if (view1 == this)
          view = null; 
        view = FocusFinder.getInstance().findNextFocus((ViewGroup)this, view, 130);
        if (view != null && view != this && view.requestFocus(130))
          bool = true; 
        return bool;
      } 
      return false;
    } 
    boolean bool1 = false;
    bool = bool1;
    if (view.getAction() == 0) {
      int i = view.getKeyCode();
      if (i != 19) {
        if (i != 20) {
          if (i != 62) {
            bool = bool1;
          } else {
            if (view.isShiftPressed())
              c1 = '!'; 
            f(c1);
            bool = bool1;
          } 
        } else if (!view.isAltPressed()) {
          bool = b(130);
        } else {
          bool = d(130);
        } 
      } else if (!view.isAltPressed()) {
        bool = b(33);
      } else {
        bool = d(33);
      } 
    } 
    return bool;
  }
  
  public void addView(View paramView) {
    if (getChildCount() <= 0) {
      super.addView(paramView);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, int paramInt) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public final void b(int paramInt1, int paramInt2) {
    a(paramInt1 - getScrollX(), paramInt2 - getScrollY());
  }
  
  public boolean b(int paramInt) {
    View view2 = findFocus();
    View view1 = view2;
    if (view2 == this)
      view1 = null; 
    view2 = FocusFinder.getInstance().findNextFocus((ViewGroup)this, view1, paramInt);
    int i = getMaxScrollAmount();
    if (view2 != null && a(view2, i, getHeight())) {
      view2.getDrawingRect(this.d);
      offsetDescendantRectToMyCoords(view2, this.d);
      g(a(this.d));
      view2.requestFocus(paramInt);
    } else {
      int k;
      int n = i;
      if (paramInt == 33 && getScrollY() < n) {
        k = getScrollY();
      } else {
        k = n;
        if (paramInt == 130) {
          k = n;
          if (getChildCount() > 0) {
            View view = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
            k = Math.min(view.getBottom() + layoutParams.bottomMargin - getScrollY() + getHeight() - getPaddingBottom(), i);
          } 
        } 
      } 
      if (k == 0)
        return false; 
      if (paramInt != 130)
        k = -k; 
      g(k);
    } 
    if (view1 != null && view1.isFocused() && a(view1)) {
      paramInt = getDescendantFocusability();
      setDescendantFocusability(131072);
      requestFocus();
      setDescendantFocusability(paramInt);
    } 
    return true;
  }
  
  public boolean b(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    boolean bool;
    if ((paramInt1 & 0x2) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void c(int paramInt) {
    if (getChildCount() > 0) {
      c(2, 1);
      this.e.fling(getScrollX(), getScrollY(), 0, paramInt, 0, 0, -2147483648, 2147483647, 0, 0);
      this.w = getScrollY();
      u.B((View)this);
    } 
  }
  
  public boolean c(int paramInt1, int paramInt2) {
    return this.z.a(paramInt1, paramInt2);
  }
  
  public int computeHorizontalScrollExtent() {
    return super.computeHorizontalScrollExtent();
  }
  
  public int computeHorizontalScrollOffset() {
    return super.computeHorizontalScrollOffset();
  }
  
  public int computeHorizontalScrollRange() {
    return super.computeHorizontalScrollRange();
  }
  
  public void computeScroll() {
    if (this.e.computeScrollOffset()) {
      this.e.getCurrX();
      int k = this.e.getCurrY();
      int i = k - this.w;
      if (a(0, i, this.u, (int[])null, 1))
        i -= this.u[1]; 
      if (i != 0) {
        int i1 = getScrollRange();
        int n = getScrollY();
        a(0, i, getScrollX(), n, 0, i1, 0, 0, false);
        int i2 = getScrollY() - n;
        if (!a(0, i2, 0, i - i2, (int[])null, 1)) {
          i = getOverScrollMode();
          if (i == 0 || (i == 1 && i1 > 0)) {
            i = 1;
          } else {
            i = 0;
          } 
          if (i != 0) {
            c();
            if (k <= 0 && n > 0) {
              this.f.onAbsorb((int)this.e.getCurrVelocity());
            } else if (k >= i1 && n < i1) {
              this.g.onAbsorb((int)this.e.getCurrVelocity());
            } 
          } 
        } 
      } 
      this.w = k;
      u.B((View)this);
    } else {
      if (e(1))
        a(1); 
      this.w = 0;
    } 
  }
  
  public int computeVerticalScrollExtent() {
    return super.computeVerticalScrollExtent();
  }
  
  public int computeVerticalScrollOffset() {
    return Math.max(0, super.computeVerticalScrollOffset());
  }
  
  public int computeVerticalScrollRange() {
    int k = getChildCount();
    int i = getHeight() - getPaddingBottom() - getPaddingTop();
    if (k == 0)
      return i; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    k = view.getBottom() + layoutParams.bottomMargin;
    int n = getScrollY();
    int i1 = Math.max(0, k - i);
    if (n < 0) {
      i = k - n;
    } else {
      i = k;
      if (n > i1)
        i = k + n - i1; 
    } 
    return i;
  }
  
  public boolean d(int paramInt) {
    int i;
    if (paramInt == 130) {
      i = 1;
    } else {
      i = 0;
    } 
    int k = getHeight();
    Rect rect = this.d;
    rect.top = 0;
    rect.bottom = k;
    if (i) {
      i = getChildCount();
      if (i > 0) {
        View view = getChildAt(i - 1);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        this.d.bottom = view.getBottom() + layoutParams.bottomMargin + getPaddingBottom();
        Rect rect1 = this.d;
        rect1.top = rect1.bottom - k;
      } 
    } 
    rect = this.d;
    return b(paramInt, rect.top, rect.bottom);
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return (super.dispatchKeyEvent(paramKeyEvent) || a(paramKeyEvent));
  }
  
  public boolean dispatchNestedFling(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return this.z.a(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public boolean dispatchNestedPreFling(float paramFloat1, float paramFloat2) {
    return this.z.a(paramFloat1, paramFloat2);
  }
  
  public boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    return a(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, 0);
  }
  
  public boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    return a(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint, 0);
  }
  
  public void draw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial draw : (Landroid/graphics/Canvas;)V
    //   5: aload_0
    //   6: getfield f : Landroid/widget/EdgeEffect;
    //   9: ifnull -> 376
    //   12: aload_0
    //   13: invokevirtual getScrollY : ()I
    //   16: istore #8
    //   18: aload_0
    //   19: getfield f : Landroid/widget/EdgeEffect;
    //   22: invokevirtual isFinished : ()Z
    //   25: ifne -> 188
    //   28: aload_1
    //   29: invokevirtual save : ()I
    //   32: istore #9
    //   34: aload_0
    //   35: invokevirtual getWidth : ()I
    //   38: istore #4
    //   40: aload_0
    //   41: invokevirtual getHeight : ()I
    //   44: istore #7
    //   46: iconst_0
    //   47: istore_3
    //   48: iconst_0
    //   49: iload #8
    //   51: invokestatic min : (II)I
    //   54: istore #6
    //   56: getstatic android/os/Build$VERSION.SDK_INT : I
    //   59: bipush #21
    //   61: if_icmplt -> 74
    //   64: iload #4
    //   66: istore_2
    //   67: aload_0
    //   68: invokevirtual getClipToPadding : ()Z
    //   71: ifeq -> 94
    //   74: iload #4
    //   76: aload_0
    //   77: invokevirtual getPaddingLeft : ()I
    //   80: aload_0
    //   81: invokevirtual getPaddingRight : ()I
    //   84: iadd
    //   85: isub
    //   86: istore_2
    //   87: iconst_0
    //   88: aload_0
    //   89: invokevirtual getPaddingLeft : ()I
    //   92: iadd
    //   93: istore_3
    //   94: iload #7
    //   96: istore #5
    //   98: iload #6
    //   100: istore #4
    //   102: getstatic android/os/Build$VERSION.SDK_INT : I
    //   105: bipush #21
    //   107: if_icmplt -> 148
    //   110: iload #7
    //   112: istore #5
    //   114: iload #6
    //   116: istore #4
    //   118: aload_0
    //   119: invokevirtual getClipToPadding : ()Z
    //   122: ifeq -> 148
    //   125: iload #7
    //   127: aload_0
    //   128: invokevirtual getPaddingTop : ()I
    //   131: aload_0
    //   132: invokevirtual getPaddingBottom : ()I
    //   135: iadd
    //   136: isub
    //   137: istore #5
    //   139: iload #6
    //   141: aload_0
    //   142: invokevirtual getPaddingTop : ()I
    //   145: iadd
    //   146: istore #4
    //   148: aload_1
    //   149: iload_3
    //   150: i2f
    //   151: iload #4
    //   153: i2f
    //   154: invokevirtual translate : (FF)V
    //   157: aload_0
    //   158: getfield f : Landroid/widget/EdgeEffect;
    //   161: iload_2
    //   162: iload #5
    //   164: invokevirtual setSize : (II)V
    //   167: aload_0
    //   168: getfield f : Landroid/widget/EdgeEffect;
    //   171: aload_1
    //   172: invokevirtual draw : (Landroid/graphics/Canvas;)Z
    //   175: ifeq -> 182
    //   178: aload_0
    //   179: invokestatic B : (Landroid/view/View;)V
    //   182: aload_1
    //   183: iload #9
    //   185: invokevirtual restoreToCount : (I)V
    //   188: aload_0
    //   189: getfield g : Landroid/widget/EdgeEffect;
    //   192: invokevirtual isFinished : ()Z
    //   195: ifne -> 376
    //   198: aload_1
    //   199: invokevirtual save : ()I
    //   202: istore #9
    //   204: aload_0
    //   205: invokevirtual getWidth : ()I
    //   208: istore #4
    //   210: aload_0
    //   211: invokevirtual getHeight : ()I
    //   214: istore #6
    //   216: iconst_0
    //   217: istore_2
    //   218: aload_0
    //   219: invokevirtual getScrollRange : ()I
    //   222: iload #8
    //   224: invokestatic max : (II)I
    //   227: iload #6
    //   229: iadd
    //   230: istore #7
    //   232: getstatic android/os/Build$VERSION.SDK_INT : I
    //   235: bipush #21
    //   237: if_icmplt -> 250
    //   240: iload #4
    //   242: istore_3
    //   243: aload_0
    //   244: invokevirtual getClipToPadding : ()Z
    //   247: ifeq -> 270
    //   250: iload #4
    //   252: aload_0
    //   253: invokevirtual getPaddingLeft : ()I
    //   256: aload_0
    //   257: invokevirtual getPaddingRight : ()I
    //   260: iadd
    //   261: isub
    //   262: istore_3
    //   263: iconst_0
    //   264: aload_0
    //   265: invokevirtual getPaddingLeft : ()I
    //   268: iadd
    //   269: istore_2
    //   270: iload #6
    //   272: istore #5
    //   274: iload #7
    //   276: istore #4
    //   278: getstatic android/os/Build$VERSION.SDK_INT : I
    //   281: bipush #21
    //   283: if_icmplt -> 324
    //   286: iload #6
    //   288: istore #5
    //   290: iload #7
    //   292: istore #4
    //   294: aload_0
    //   295: invokevirtual getClipToPadding : ()Z
    //   298: ifeq -> 324
    //   301: iload #6
    //   303: aload_0
    //   304: invokevirtual getPaddingTop : ()I
    //   307: aload_0
    //   308: invokevirtual getPaddingBottom : ()I
    //   311: iadd
    //   312: isub
    //   313: istore #5
    //   315: iload #7
    //   317: aload_0
    //   318: invokevirtual getPaddingBottom : ()I
    //   321: isub
    //   322: istore #4
    //   324: aload_1
    //   325: iload_2
    //   326: iload_3
    //   327: isub
    //   328: i2f
    //   329: iload #4
    //   331: i2f
    //   332: invokevirtual translate : (FF)V
    //   335: aload_1
    //   336: ldc_w 180.0
    //   339: iload_3
    //   340: i2f
    //   341: fconst_0
    //   342: invokevirtual rotate : (FFF)V
    //   345: aload_0
    //   346: getfield g : Landroid/widget/EdgeEffect;
    //   349: iload_3
    //   350: iload #5
    //   352: invokevirtual setSize : (II)V
    //   355: aload_0
    //   356: getfield g : Landroid/widget/EdgeEffect;
    //   359: aload_1
    //   360: invokevirtual draw : (Landroid/graphics/Canvas;)Z
    //   363: ifeq -> 370
    //   366: aload_0
    //   367: invokestatic B : (Landroid/view/View;)V
    //   370: aload_1
    //   371: iload #9
    //   373: invokevirtual restoreToCount : (I)V
    //   376: return
  }
  
  public boolean e(int paramInt) {
    return this.z.a(paramInt);
  }
  
  public boolean f(int paramInt) {
    if (paramInt == 130) {
      i = 1;
    } else {
      i = 0;
    } 
    int k = getHeight();
    if (i) {
      this.d.top = getScrollY() + k;
      i = getChildCount();
      if (i > 0) {
        View view = getChildAt(i - 1);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        i = view.getBottom() + layoutParams.bottomMargin + getPaddingBottom();
        Rect rect1 = this.d;
        if (rect1.top + k > i)
          rect1.top = i - k; 
      } 
    } else {
      this.d.top = getScrollY() - k;
      Rect rect1 = this.d;
      if (rect1.top < 0)
        rect1.top = 0; 
    } 
    Rect rect = this.d;
    int i = rect.top;
    rect.bottom = i + k;
    return b(paramInt, i, rect.bottom);
  }
  
  protected float getBottomFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    int i = getVerticalFadingEdgeLength();
    int n = getHeight();
    int k = getPaddingBottom();
    k = view.getBottom() + layoutParams.bottomMargin - getScrollY() - n - k;
    return (k < i) ? (k / i) : 1.0F;
  }
  
  public int getMaxScrollAmount() {
    return (int)(getHeight() * 0.5F);
  }
  
  public int getNestedScrollAxes() {
    return this.y.a();
  }
  
  int getScrollRange() {
    int i = 0;
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      i = Math.max(0, view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin - getHeight() - getPaddingTop() - getPaddingBottom());
    } 
    return i;
  }
  
  protected float getTopFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    int k = getVerticalFadingEdgeLength();
    int i = getScrollY();
    return (i < k) ? (i / k) : 1.0F;
  }
  
  public boolean hasNestedScrollingParent() {
    return e(0);
  }
  
  public boolean isNestedScrollingEnabled() {
    return this.z.b();
  }
  
  protected void measureChild(View paramView, int paramInt1, int paramInt2) {
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    paramView.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
  }
  
  protected void measureChildWithMargins(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    paramView.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.j = false;
  }
  
  public boolean onGenericMotionEvent(MotionEvent paramMotionEvent) {
    if ((paramMotionEvent.getSource() & 0x2) != 0 && paramMotionEvent.getAction() == 8 && !this.l) {
      float f = paramMotionEvent.getAxisValue(9);
      if (f != 0.0F) {
        int i = (int)(getVerticalScrollFactorCompat() * f);
        int k = getScrollRange();
        int i1 = getScrollY();
        int n = i1 - i;
        if (n < 0) {
          i = 0;
        } else {
          i = n;
          if (n > k)
            i = k; 
        } 
        if (i != i1) {
          super.scrollTo(getScrollX(), i);
          return true;
        } 
      } 
    } 
    return false;
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    ViewParent viewParent;
    int i = paramMotionEvent.getAction();
    if (i == 2 && this.l)
      return true; 
    i &= 0xFF;
    if (i != 0) {
      if (i != 1)
        if (i != 2) {
          if (i != 3) {
            if (i == 6)
              a(paramMotionEvent); 
            return this.l;
          } 
        } else {
          i = this.s;
          if (i != -1) {
            StringBuilder stringBuilder;
            int k = paramMotionEvent.findPointerIndex(i);
            if (k == -1) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("Invalid pointerId=");
              stringBuilder.append(i);
              stringBuilder.append(" in onInterceptTouchEvent");
              Log.e("NestedScrollView", stringBuilder.toString());
            } else {
              i = (int)stringBuilder.getY(k);
              if (Math.abs(i - this.h) > this.p && (0x2 & getNestedScrollAxes()) == 0) {
                this.l = true;
                this.h = i;
                f();
                this.m.addMovement((MotionEvent)stringBuilder);
                this.v = 0;
                viewParent = getParent();
                if (viewParent != null)
                  viewParent.requestDisallowInterceptTouchEvent(true); 
              } 
            } 
          } 
          return this.l;
        }  
      this.l = false;
      this.s = -1;
      g();
      if (this.e.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()))
        u.B((View)this); 
      a(0);
    } else {
      i = (int)viewParent.getY();
      if (!d((int)viewParent.getX(), i)) {
        this.l = false;
        g();
      } else {
        this.h = i;
        this.s = viewParent.getPointerId(0);
        d();
        this.m.addMovement((MotionEvent)viewParent);
        this.e.computeScrollOffset();
        this.l = true ^ this.e.isFinished();
        c(2, 0);
      } 
    } 
    return this.l;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    this.i = false;
    View view = this.k;
    if (view != null && a(view, (View)this))
      b(this.k); 
    this.k = null;
    if (!this.j) {
      if (this.x != null) {
        scrollTo(getScrollX(), this.x.c);
        this.x = null;
      } 
      paramInt1 = 0;
      if (getChildCount() > 0) {
        view = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        paramInt1 = view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
      } 
      int i = getPaddingTop();
      int k = getPaddingBottom();
      paramInt3 = getScrollY();
      paramInt1 = a(paramInt3, paramInt4 - paramInt2 - i - k, paramInt1);
      if (paramInt1 != paramInt3)
        scrollTo(getScrollX(), paramInt1); 
    } 
    scrollTo(getScrollX(), getScrollY());
    this.j = true;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (!this.n)
      return; 
    if (View.MeasureSpec.getMode(paramInt2) == 0)
      return; 
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int i = view.getMeasuredHeight();
      paramInt2 = getMeasuredHeight() - getPaddingTop() - getPaddingBottom() - layoutParams.topMargin - layoutParams.bottomMargin;
      if (i < paramInt2)
        view.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824)); 
    } 
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    if (!paramBoolean) {
      h((int)paramFloat2);
      return true;
    } 
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return dispatchNestedPreFling(paramFloat1, paramFloat2);
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    a(paramView, paramInt1, paramInt2, paramArrayOfint, 0);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    a(paramView, paramInt1, paramInt2, paramInt3, paramInt4, 0);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    a(paramView1, paramView2, paramInt, 0);
  }
  
  protected void onOverScrolled(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    super.scrollTo(paramInt1, paramInt2);
  }
  
  protected boolean onRequestFocusInDescendants(int paramInt, Rect paramRect) {
    int i;
    View view;
    if (paramInt == 2) {
      i = 130;
    } else {
      i = paramInt;
      if (paramInt == 1)
        i = 33; 
    } 
    if (paramRect == null) {
      view = FocusFinder.getInstance().findNextFocus((ViewGroup)this, null, i);
    } else {
      view = FocusFinder.getInstance().findNextFocusFromRect((ViewGroup)this, paramRect, i);
    } 
    return (view == null) ? false : (a(view) ? false : view.requestFocus(i, paramRect));
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof c)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    c c1 = (c)paramParcelable;
    super.onRestoreInstanceState(c1.getSuperState());
    this.x = c1;
    requestLayout();
  }
  
  protected Parcelable onSaveInstanceState() {
    c c1 = new c(super.onSaveInstanceState());
    c1.c = getScrollY();
    return (Parcelable)c1;
  }
  
  protected void onScrollChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onScrollChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    b b1 = this.B;
    if (b1 != null)
      b1.a(this, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    View view = findFocus();
    if (view == null || this == view)
      return; 
    if (a(view, 0, paramInt4)) {
      view.getDrawingRect(this.d);
      offsetDescendantRectToMyCoords(view, this.d);
      g(a(this.d));
    } 
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return b(paramView1, paramView2, paramInt, 0);
  }
  
  public void onStopNestedScroll(View paramView) {
    a(paramView, 0);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    f();
    MotionEvent motionEvent = MotionEvent.obtain(paramMotionEvent);
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.v = 0; 
    motionEvent.offsetLocation(0.0F, this.v);
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i != 5) {
              if (i == 6) {
                a(paramMotionEvent);
                this.h = (int)paramMotionEvent.getY(paramMotionEvent.findPointerIndex(this.s));
              } 
            } else {
              i = paramMotionEvent.getActionIndex();
              this.h = (int)paramMotionEvent.getY(i);
              this.s = paramMotionEvent.getPointerId(i);
            } 
          } else {
            if (this.l && getChildCount() > 0 && this.e.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()))
              u.B((View)this); 
            this.s = -1;
            b();
          } 
        } else {
          StringBuilder stringBuilder;
          int k = paramMotionEvent.findPointerIndex(this.s);
          if (k == -1) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid pointerId=");
            stringBuilder.append(this.s);
            stringBuilder.append(" in onTouchEvent");
            Log.e("NestedScrollView", stringBuilder.toString());
          } else {
            int i1 = (int)stringBuilder.getY(k);
            i = this.h - i1;
            int n = i;
            if (a(0, i, this.u, this.t, 0)) {
              n = i - this.u[1];
              motionEvent.offsetLocation(0.0F, this.t[1]);
              this.v += this.t[1];
            } 
            i = n;
            if (!this.l) {
              i = n;
              if (Math.abs(n) > this.p) {
                ViewParent viewParent = getParent();
                if (viewParent != null)
                  viewParent.requestDisallowInterceptTouchEvent(true); 
                this.l = true;
                if (n > 0) {
                  i = n - this.p;
                } else {
                  i = n + this.p;
                } 
              } 
            } 
            if (this.l) {
              int[] arrayOfInt;
              this.h = i1 - this.t[1];
              int i2 = getScrollY();
              i1 = getScrollRange();
              n = getOverScrollMode();
              if (n == 0 || (n == 1 && i1 > 0)) {
                n = 1;
              } else {
                n = 0;
              } 
              if (a(0, i, 0, getScrollY(), 0, i1, 0, 0, true) && !e(0))
                this.m.clear(); 
              int i3 = getScrollY() - i2;
              if (a(0, i3, 0, i - i3, this.t, 0)) {
                i = this.h;
                arrayOfInt = this.t;
                this.h = i - arrayOfInt[1];
                motionEvent.offsetLocation(0.0F, arrayOfInt[1]);
                this.v += this.t[1];
              } else if (n != 0) {
                c();
                n = i2 + i;
                if (n < 0) {
                  g.a(this.f, i / getHeight(), arrayOfInt.getX(k) / getWidth());
                  if (!this.g.isFinished())
                    this.g.onRelease(); 
                } else if (n > i1) {
                  g.a(this.g, i / getHeight(), 1.0F - arrayOfInt.getX(k) / getWidth());
                  if (!this.f.isFinished())
                    this.f.onRelease(); 
                } 
                EdgeEffect edgeEffect = this.f;
                if (edgeEffect != null && (!edgeEffect.isFinished() || !this.g.isFinished()))
                  u.B((View)this); 
              } 
            } 
          } 
        } 
      } else {
        velocityTracker = this.m;
        velocityTracker.computeCurrentVelocity(1000, this.r);
        i = (int)velocityTracker.getYVelocity(this.s);
        if (Math.abs(i) > this.q) {
          h(-i);
        } else if (this.e.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
          u.B((View)this);
        } 
        this.s = -1;
        b();
      } 
    } else {
      if (getChildCount() == 0)
        return false; 
      int k = this.e.isFinished() ^ true;
      this.l = k;
      if (k != 0) {
        ViewParent viewParent = getParent();
        if (viewParent != null)
          viewParent.requestDisallowInterceptTouchEvent(true); 
      } 
      if (!this.e.isFinished())
        this.e.abortAnimation(); 
      this.h = (int)velocityTracker.getY();
      this.s = velocityTracker.getPointerId(0);
      c(2, 0);
    } 
    VelocityTracker velocityTracker = this.m;
    if (velocityTracker != null)
      velocityTracker.addMovement(motionEvent); 
    motionEvent.recycle();
    return true;
  }
  
  public void requestChildFocus(View paramView1, View paramView2) {
    if (!this.i) {
      b(paramView2);
    } else {
      this.k = paramView2;
    } 
    super.requestChildFocus(paramView1, paramView2);
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    paramRect.offset(paramView.getLeft() - paramView.getScrollX(), paramView.getTop() - paramView.getScrollY());
    return a(paramRect, paramBoolean);
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    if (paramBoolean)
      g(); 
    super.requestDisallowInterceptTouchEvent(paramBoolean);
  }
  
  public void requestLayout() {
    this.i = true;
    super.requestLayout();
  }
  
  public void scrollTo(int paramInt1, int paramInt2) {
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int i5 = getWidth();
      int i9 = getPaddingLeft();
      int i6 = getPaddingRight();
      int i8 = view.getWidth();
      int i4 = layoutParams.leftMargin;
      int i7 = layoutParams.rightMargin;
      int i2 = getHeight();
      int n = getPaddingTop();
      int i1 = getPaddingBottom();
      int i = view.getHeight();
      int i3 = layoutParams.topMargin;
      int k = layoutParams.bottomMargin;
      paramInt1 = a(paramInt1, i5 - i9 - i6, i8 + i4 + i7);
      paramInt2 = a(paramInt2, i2 - n - i1, i + i3 + k);
      if (paramInt1 != getScrollX() || paramInt2 != getScrollY())
        super.scrollTo(paramInt1, paramInt2); 
    } 
  }
  
  public void setFillViewport(boolean paramBoolean) {
    if (paramBoolean != this.n) {
      this.n = paramBoolean;
      requestLayout();
    } 
  }
  
  public void setNestedScrollingEnabled(boolean paramBoolean) {
    this.z.a(paramBoolean);
  }
  
  public void setOnScrollChangeListener(b paramb) {
    this.B = paramb;
  }
  
  public void setSmoothScrollingEnabled(boolean paramBoolean) {
    this.o = paramBoolean;
  }
  
  public boolean shouldDelayChildPressedState() {
    return true;
  }
  
  public boolean startNestedScroll(int paramInt) {
    return c(paramInt, 0);
  }
  
  public void stopNestedScroll() {
    a(0);
  }
  
  static class a extends android.support.v4.view.b {
    public void a(View param1View, android.support.v4.view.d0.c param1c) {
      super.a(param1View, param1c);
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      param1c.a(ScrollView.class.getName());
      if (nestedScrollView.isEnabled()) {
        int i = nestedScrollView.getScrollRange();
        if (i > 0) {
          param1c.k(true);
          if (nestedScrollView.getScrollY() > 0)
            param1c.a(8192); 
          if (nestedScrollView.getScrollY() < i)
            param1c.a(4096); 
        } 
      } 
    }
    
    public boolean a(View param1View, int param1Int, Bundle param1Bundle) {
      if (super.a(param1View, param1Int, param1Bundle))
        return true; 
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      if (!nestedScrollView.isEnabled())
        return false; 
      if (param1Int != 4096) {
        if (param1Int != 8192)
          return false; 
        int m = nestedScrollView.getHeight();
        param1Int = nestedScrollView.getPaddingBottom();
        int k = nestedScrollView.getPaddingTop();
        param1Int = Math.max(nestedScrollView.getScrollY() - m - param1Int - k, 0);
        if (param1Int != nestedScrollView.getScrollY()) {
          nestedScrollView.b(0, param1Int);
          return true;
        } 
        return false;
      } 
      param1Int = nestedScrollView.getHeight();
      int j = nestedScrollView.getPaddingBottom();
      int i = nestedScrollView.getPaddingTop();
      param1Int = Math.min(nestedScrollView.getScrollY() + param1Int - j - i, nestedScrollView.getScrollRange());
      if (param1Int != nestedScrollView.getScrollY()) {
        nestedScrollView.b(0, param1Int);
        return true;
      } 
      return false;
    }
    
    public void b(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      boolean bool;
      super.b(param1View, param1AccessibilityEvent);
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      param1AccessibilityEvent.setClassName(ScrollView.class.getName());
      if (nestedScrollView.getScrollRange() > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      param1AccessibilityEvent.setScrollable(bool);
      param1AccessibilityEvent.setScrollX(nestedScrollView.getScrollX());
      param1AccessibilityEvent.setScrollY(nestedScrollView.getScrollY());
      e.a((AccessibilityRecord)param1AccessibilityEvent, nestedScrollView.getScrollX());
      e.b((AccessibilityRecord)param1AccessibilityEvent, nestedScrollView.getScrollRange());
    }
  }
  
  public static interface b {
    void a(NestedScrollView param1NestedScrollView, int param1Int1, int param1Int2, int param1Int3, int param1Int4);
  }
  
  static class c extends View.BaseSavedState {
    public static final Parcelable.Creator<c> CREATOR = new a();
    
    public int c;
    
    c(Parcel param1Parcel) {
      super(param1Parcel);
      this.c = param1Parcel.readInt();
    }
    
    c(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("HorizontalScrollView.SavedState{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" scrollPosition=");
      stringBuilder.append(this.c);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.c);
    }
    
    static final class a implements Parcelable.Creator<c> {
      public NestedScrollView.c createFromParcel(Parcel param2Parcel) {
        return new NestedScrollView.c(param2Parcel);
      }
      
      public NestedScrollView.c[] newArray(int param2Int) {
        return new NestedScrollView.c[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.Creator<c> {
    public NestedScrollView.c createFromParcel(Parcel param1Parcel) {
      return new NestedScrollView.c(param1Parcel);
    }
    
    public NestedScrollView.c[] newArray(int param1Int) {
      return new NestedScrollView.c[param1Int];
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\widget\NestedScrollView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */