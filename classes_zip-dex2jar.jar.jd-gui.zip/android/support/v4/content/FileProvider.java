package android.support.v4.content;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ProviderInfo;
import android.content.res.XmlResourceParser;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;
import android.webkit.MimeTypeMap;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import org.xmlpull.v1.XmlPullParserException;

public class FileProvider extends ContentProvider {
  private static final String[] d = new String[] { "_display_name", "_size" };
  
  private static final File e = new File("/");
  
  private static HashMap<String, a> f = new HashMap<String, a>();
  
  private a c;
  
  private static int a(String paramString) {
    int i;
    if ("r".equals(paramString)) {
      i = 268435456;
    } else {
      if ("w".equals(paramString) || "wt".equals(paramString))
        return 738197504; 
      if ("wa".equals(paramString)) {
        i = 704643072;
      } else if ("rw".equals(paramString)) {
        i = 939524096;
      } else if ("rwt".equals(paramString)) {
        i = 1006632960;
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid mode: ");
        stringBuilder.append(paramString);
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
    } 
    return i;
  }
  
  public static Uri a(Context paramContext, String paramString, File paramFile) {
    return a(paramContext, paramString).a(paramFile);
  }
  
  private static a a(Context paramContext, String paramString) {
    HashMap<String, a> hashMap = f;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap<[ObjectType{java/lang/String}, InnerObjectType{ObjectType{android/support/v4/content/FileProvider}.Landroid/support/v4/content/FileProvider$a;}]>}, name=null} */
    try {
      a a2 = f.get(paramString);
      a a1 = a2;
      if (a2 == null) {
        try {
          a1 = b(paramContext, paramString);
          f.put(paramString, a1);
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap<[ObjectType{java/lang/String}, InnerObjectType{ObjectType{android/support/v4/content/FileProvider}.Landroid/support/v4/content/FileProvider$a;}]>}, name=null} */
          return a1;
        } catch (IOException iOException) {
          IllegalArgumentException illegalArgumentException = new IllegalArgumentException();
          this("Failed to parse android.support.FILE_PROVIDER_PATHS meta-data", iOException);
          throw illegalArgumentException;
        } catch (XmlPullParserException xmlPullParserException) {
          IllegalArgumentException illegalArgumentException = new IllegalArgumentException();
          this("Failed to parse android.support.FILE_PROVIDER_PATHS meta-data", (Throwable)xmlPullParserException);
          throw illegalArgumentException;
        } finally {}
      } else {
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap<[ObjectType{java/lang/String}, InnerObjectType{ObjectType{android/support/v4/content/FileProvider}.Landroid/support/v4/content/FileProvider$a;}]>}, name=null} */
        return a1;
      } 
    } finally {}
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap<[ObjectType{java/lang/String}, InnerObjectType{ObjectType{android/support/v4/content/FileProvider}.Landroid/support/v4/content/FileProvider$a;}]>}, name=null} */
    throw paramContext;
  }
  
  private static File a(File paramFile, String... paramVarArgs) {
    int i = paramVarArgs.length;
    byte b = 0;
    while (b < i) {
      String str = paramVarArgs[b];
      File file = paramFile;
      if (str != null)
        file = new File(paramFile, str); 
      b++;
      paramFile = file;
    } 
    return paramFile;
  }
  
  private static Object[] a(Object[] paramArrayOfObject, int paramInt) {
    Object[] arrayOfObject = new Object[paramInt];
    System.arraycopy(paramArrayOfObject, 0, arrayOfObject, 0, paramInt);
    return arrayOfObject;
  }
  
  private static String[] a(String[] paramArrayOfString, int paramInt) {
    String[] arrayOfString = new String[paramInt];
    System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, paramInt);
    return arrayOfString;
  }
  
  private static a b(Context paramContext, String paramString) {
    b b = new b(paramString);
    ProviderInfo providerInfo = paramContext.getPackageManager().resolveContentProvider(paramString, 128);
    XmlResourceParser xmlResourceParser = providerInfo.loadXmlMetaData(paramContext.getPackageManager(), "android.support.FILE_PROVIDER_PATHS");
    if (xmlResourceParser != null)
      while (true) {
        int i = xmlResourceParser.next();
        if (i != 1) {
          if (i == 2) {
            File file;
            String str3 = xmlResourceParser.getName();
            String str1 = xmlResourceParser.getAttributeValue(null, "name");
            String str2 = xmlResourceParser.getAttributeValue(null, "path");
            ProviderInfo providerInfo1 = null;
            File[] arrayOfFile = null;
            providerInfo = null;
            if ("root-path".equals(str3)) {
              file = e;
            } else if ("files-path".equals(str3)) {
              file = paramContext.getFilesDir();
            } else if ("cache-path".equals(str3)) {
              file = paramContext.getCacheDir();
            } else if ("external-path".equals(str3)) {
              file = Environment.getExternalStorageDirectory();
            } else if ("external-files-path".equals(str3)) {
              arrayOfFile = a.b(paramContext, (String)null);
              if (arrayOfFile.length > 0)
                file = arrayOfFile[0]; 
            } else if ("external-cache-path".equals(str3)) {
              arrayOfFile = a.a(paramContext);
              providerInfo = providerInfo1;
              if (arrayOfFile.length > 0)
                file = arrayOfFile[0]; 
            } else {
              providerInfo = providerInfo1;
              if (Build.VERSION.SDK_INT >= 21) {
                File[] arrayOfFile1 = arrayOfFile;
                if ("external-media-path".equals(str3)) {
                  File[] arrayOfFile2 = paramContext.getExternalMediaDirs();
                  arrayOfFile1 = arrayOfFile;
                  if (arrayOfFile2.length > 0)
                    file = arrayOfFile2[0]; 
                } 
              } 
            } 
            if (file != null)
              b.a(str1, a(file, new String[] { str2 })); 
          } 
          continue;
        } 
        return b;
      }  
    IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Missing android.support.FILE_PROVIDER_PATHS meta-data");
    throw illegalArgumentException;
  }
  
  public void attachInfo(Context paramContext, ProviderInfo paramProviderInfo) {
    super.attachInfo(paramContext, paramProviderInfo);
    if (!paramProviderInfo.exported) {
      if (paramProviderInfo.grantUriPermissions) {
        this.c = a(paramContext, paramProviderInfo.authority);
        return;
      } 
      throw new SecurityException("Provider must grant uri permissions");
    } 
    throw new SecurityException("Provider must not be exported");
  }
  
  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString) {
    return this.c.a(paramUri).delete();
  }
  
  public String getType(Uri paramUri) {
    File file = this.c.a(paramUri);
    int i = file.getName().lastIndexOf('.');
    if (i >= 0) {
      String str = file.getName().substring(i + 1);
      str = MimeTypeMap.getSingleton().getMimeTypeFromExtension(str);
      if (str != null)
        return str; 
    } 
    return "application/octet-stream";
  }
  
  public Uri insert(Uri paramUri, ContentValues paramContentValues) {
    throw new UnsupportedOperationException("No external inserts");
  }
  
  public boolean onCreate() {
    return true;
  }
  
  public ParcelFileDescriptor openFile(Uri paramUri, String paramString) {
    return ParcelFileDescriptor.open(this.c.a(paramUri), a(paramString));
  }
  
  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2) {
    File file = this.c.a(paramUri);
    String[] arrayOfString1 = paramArrayOfString1;
    if (paramArrayOfString1 == null)
      arrayOfString1 = d; 
    paramArrayOfString2 = new String[arrayOfString1.length];
    Object[] arrayOfObject2 = new Object[arrayOfString1.length];
    int i = 0;
    int j = arrayOfString1.length;
    byte b = 0;
    while (b < j) {
      int k;
      paramString2 = arrayOfString1[b];
      if ("_display_name".equals(paramString2)) {
        paramArrayOfString2[i] = "_display_name";
        arrayOfObject2[i] = file.getName();
        k = i + 1;
      } else {
        k = i;
        if ("_size".equals(paramString2)) {
          paramArrayOfString2[i] = "_size";
          arrayOfObject2[i] = Long.valueOf(file.length());
          k = i + 1;
        } 
      } 
      b++;
      i = k;
    } 
    String[] arrayOfString2 = a(paramArrayOfString2, i);
    Object[] arrayOfObject1 = a(arrayOfObject2, i);
    MatrixCursor matrixCursor = new MatrixCursor(arrayOfString2, 1);
    matrixCursor.addRow(arrayOfObject1);
    return (Cursor)matrixCursor;
  }
  
  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString) {
    throw new UnsupportedOperationException("No external updates");
  }
  
  static interface a {
    Uri a(File param1File);
    
    File a(Uri param1Uri);
  }
  
  static class b implements a {
    private final String a;
    
    private final HashMap<String, File> b = new HashMap<String, File>();
    
    b(String param1String) {
      this.a = param1String;
    }
    
    public Uri a(File param1File) {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual getCanonicalPath : ()Ljava/lang/String;
      //   4: astore #4
      //   6: aconst_null
      //   7: astore_1
      //   8: aload_0
      //   9: getfield b : Ljava/util/HashMap;
      //   12: invokevirtual entrySet : ()Ljava/util/Set;
      //   15: invokeinterface iterator : ()Ljava/util/Iterator;
      //   20: astore #5
      //   22: aload #5
      //   24: invokeinterface hasNext : ()Z
      //   29: ifeq -> 105
      //   32: aload #5
      //   34: invokeinterface next : ()Ljava/lang/Object;
      //   39: checkcast java/util/Map$Entry
      //   42: astore_3
      //   43: aload_3
      //   44: invokeinterface getValue : ()Ljava/lang/Object;
      //   49: checkcast java/io/File
      //   52: invokevirtual getPath : ()Ljava/lang/String;
      //   55: astore #6
      //   57: aload_1
      //   58: astore_2
      //   59: aload #4
      //   61: aload #6
      //   63: invokevirtual startsWith : (Ljava/lang/String;)Z
      //   66: ifeq -> 100
      //   69: aload_1
      //   70: ifnull -> 98
      //   73: aload_1
      //   74: astore_2
      //   75: aload #6
      //   77: invokevirtual length : ()I
      //   80: aload_1
      //   81: invokeinterface getValue : ()Ljava/lang/Object;
      //   86: checkcast java/io/File
      //   89: invokevirtual getPath : ()Ljava/lang/String;
      //   92: invokevirtual length : ()I
      //   95: if_icmple -> 100
      //   98: aload_3
      //   99: astore_2
      //   100: aload_2
      //   101: astore_1
      //   102: goto -> 22
      //   105: aload_1
      //   106: ifnull -> 231
      //   109: aload_1
      //   110: invokeinterface getValue : ()Ljava/lang/Object;
      //   115: checkcast java/io/File
      //   118: invokevirtual getPath : ()Ljava/lang/String;
      //   121: astore_2
      //   122: aload_2
      //   123: ldc '/'
      //   125: invokevirtual endsWith : (Ljava/lang/String;)Z
      //   128: ifeq -> 144
      //   131: aload #4
      //   133: aload_2
      //   134: invokevirtual length : ()I
      //   137: invokevirtual substring : (I)Ljava/lang/String;
      //   140: astore_2
      //   141: goto -> 156
      //   144: aload #4
      //   146: aload_2
      //   147: invokevirtual length : ()I
      //   150: iconst_1
      //   151: iadd
      //   152: invokevirtual substring : (I)Ljava/lang/String;
      //   155: astore_2
      //   156: new java/lang/StringBuilder
      //   159: dup
      //   160: invokespecial <init> : ()V
      //   163: astore_3
      //   164: aload_3
      //   165: aload_1
      //   166: invokeinterface getKey : ()Ljava/lang/Object;
      //   171: checkcast java/lang/String
      //   174: invokestatic encode : (Ljava/lang/String;)Ljava/lang/String;
      //   177: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   180: pop
      //   181: aload_3
      //   182: bipush #47
      //   184: invokevirtual append : (C)Ljava/lang/StringBuilder;
      //   187: pop
      //   188: aload_3
      //   189: aload_2
      //   190: ldc '/'
      //   192: invokestatic encode : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
      //   195: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   198: pop
      //   199: aload_3
      //   200: invokevirtual toString : ()Ljava/lang/String;
      //   203: astore_1
      //   204: new android/net/Uri$Builder
      //   207: dup
      //   208: invokespecial <init> : ()V
      //   211: ldc 'content'
      //   213: invokevirtual scheme : (Ljava/lang/String;)Landroid/net/Uri$Builder;
      //   216: aload_0
      //   217: getfield a : Ljava/lang/String;
      //   220: invokevirtual authority : (Ljava/lang/String;)Landroid/net/Uri$Builder;
      //   223: aload_1
      //   224: invokevirtual encodedPath : (Ljava/lang/String;)Landroid/net/Uri$Builder;
      //   227: invokevirtual build : ()Landroid/net/Uri;
      //   230: areturn
      //   231: new java/lang/StringBuilder
      //   234: dup
      //   235: invokespecial <init> : ()V
      //   238: astore_1
      //   239: aload_1
      //   240: ldc 'Failed to find configured root that contains '
      //   242: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   245: pop
      //   246: aload_1
      //   247: aload #4
      //   249: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   252: pop
      //   253: new java/lang/IllegalArgumentException
      //   256: dup
      //   257: aload_1
      //   258: invokevirtual toString : ()Ljava/lang/String;
      //   261: invokespecial <init> : (Ljava/lang/String;)V
      //   264: athrow
      //   265: astore_2
      //   266: new java/lang/StringBuilder
      //   269: dup
      //   270: invokespecial <init> : ()V
      //   273: astore_2
      //   274: aload_2
      //   275: ldc 'Failed to resolve canonical path for '
      //   277: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   280: pop
      //   281: aload_2
      //   282: aload_1
      //   283: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   286: pop
      //   287: new java/lang/IllegalArgumentException
      //   290: dup
      //   291: aload_2
      //   292: invokevirtual toString : ()Ljava/lang/String;
      //   295: invokespecial <init> : (Ljava/lang/String;)V
      //   298: astore_1
      //   299: goto -> 304
      //   302: aload_1
      //   303: athrow
      //   304: goto -> 302
      // Exception table:
      //   from	to	target	type
      //   0	6	265	java/io/IOException
    }
    
    public File a(Uri param1Uri) {
      File file1;
      String str2 = param1Uri.getEncodedPath();
      int i = str2.indexOf('/', 1);
      String str1 = Uri.decode(str2.substring(1, i));
      str2 = Uri.decode(str2.substring(i + 1));
      File file2 = this.b.get(str1);
      if (file2 != null) {
        file1 = new File(file2, str2);
        try {
          File file = file1.getCanonicalFile();
          if (file.getPath().startsWith(file2.getPath()))
            return file; 
          throw new SecurityException("Resolved path jumped beyond configured root");
        } catch (IOException iOException) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Failed to resolve canonical path for ");
          stringBuilder1.append(file1);
          throw new IllegalArgumentException(stringBuilder1.toString());
        } 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to find configured root for ");
      stringBuilder.append(file1);
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    void a(String param1String, File param1File) {
      if (!TextUtils.isEmpty(param1String))
        try {
          File file = param1File.getCanonicalFile();
          this.b.put(param1String, file);
          return;
        } catch (IOException iOException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to resolve canonical path for ");
          stringBuilder.append(param1File);
          throw new IllegalArgumentException(stringBuilder.toString(), iOException);
        }  
      throw new IllegalArgumentException("Name must not be empty");
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\content\FileProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */