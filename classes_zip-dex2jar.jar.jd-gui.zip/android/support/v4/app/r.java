package android.support.v4.app;

import android.graphics.Rect;
import android.os.Build;
import android.support.v4.view.u;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

class r {
  private static final int[] a = new int[] { 0, 3, 0, 1, 5, 4, 7, 6, 9, 8 };
  
  private static final t b;
  
  private static final t c = a();
  
  private static a.b.g.g.a<String, String> a(int paramInt1, ArrayList<c> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt2, int paramInt3) {
    a.b.g.g.a<String, String> a = new a.b.g.g.a();
    while (--paramInt3 >= paramInt2) {
      c c = paramArrayList.get(paramInt3);
      if (c.b(paramInt1)) {
        boolean bool = ((Boolean)paramArrayList1.get(paramInt3)).booleanValue();
        ArrayList<String> arrayList = c.q;
        if (arrayList != null) {
          ArrayList<String> arrayList1;
          int i = arrayList.size();
          if (bool) {
            arrayList = c.q;
            arrayList1 = c.r;
          } else {
            arrayList1 = c.q;
            arrayList = c.r;
          } 
          for (byte b = 0; b < i; b++) {
            String str1 = arrayList1.get(b);
            String str2 = arrayList.get(b);
            String str3 = (String)a.remove(str2);
            if (str3 != null) {
              a.put(str1, str3);
            } else {
              a.put(str1, str2);
            } 
          } 
        } 
      } 
      paramInt3--;
    } 
    return a;
  }
  
  static a.b.g.g.a<String, View> a(t paramt, a.b.g.g.a<String, String> parama, Object paramObject, e parame) {
    ArrayList<String> arrayList;
    f f = parame.a;
    View view = f.A();
    if (parama.isEmpty() || paramObject == null || view == null) {
      parama.clear();
      return null;
    } 
    a.b.g.g.a<String, View> a1 = new a.b.g.g.a();
    paramt.a((Map<String, View>)a1, view);
    c c = parame.c;
    if (parame.b) {
      paramObject = f.o();
      arrayList = c.q;
    } else {
      paramObject = f.m();
      arrayList = ((c)arrayList).r;
    } 
    if (arrayList != null) {
      a1.a(arrayList);
      a1.a(parama.values());
    } 
    if (paramObject != null) {
      paramObject.a(arrayList, (Map<String, View>)a1);
      for (int i = arrayList.size() - 1; i >= 0; i--) {
        String str = arrayList.get(i);
        paramObject = a1.get(str);
        if (paramObject == null) {
          paramObject = a(parama, str);
          if (paramObject != null)
            parama.remove(paramObject); 
        } else if (!str.equals(u.q((View)paramObject))) {
          str = a(parama, str);
          if (str != null)
            parama.put(str, u.q((View)paramObject)); 
        } 
      } 
    } else {
      a(parama, a1);
    } 
    return a1;
  }
  
  private static e a(e parame, SparseArray<e> paramSparseArray, int paramInt) {
    e e1 = parame;
    if (parame == null) {
      e1 = new e();
      paramSparseArray.put(paramInt, e1);
    } 
    return e1;
  }
  
  private static t a() {
    try {
      return Class.forName("a.b.f.e").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
    } catch (Exception exception) {
      return null;
    } 
  }
  
  private static t a(f paramf1, f paramf2) {
    ArrayList<Object> arrayList = new ArrayList();
    if (paramf1 != null) {
      Object object2 = paramf1.n();
      if (object2 != null)
        arrayList.add(object2); 
      object2 = paramf1.w();
      if (object2 != null)
        arrayList.add(object2); 
      Object object1 = paramf1.y();
      if (object1 != null)
        arrayList.add(object1); 
    } 
    if (paramf2 != null) {
      Object object = paramf2.l();
      if (object != null)
        arrayList.add(object); 
      object = paramf2.u();
      if (object != null)
        arrayList.add(object); 
      object = paramf2.x();
      if (object != null)
        arrayList.add(object); 
    } 
    if (arrayList.isEmpty())
      return null; 
    t t1 = b;
    if (t1 != null && a(t1, arrayList))
      return b; 
    t1 = c;
    if (t1 != null && a(t1, arrayList))
      return c; 
    if (b == null && c == null)
      return null; 
    throw new IllegalArgumentException("Invalid Transition types");
  }
  
  static View a(a.b.g.g.a<String, View> parama, e parame, Object<String> paramObject, boolean paramBoolean) {
    c c = parame.c;
    if (paramObject != null && parama != null) {
      paramObject = (Object<String>)c.q;
      if (paramObject != null && !paramObject.isEmpty()) {
        String str;
        if (paramBoolean) {
          str = c.q.get(0);
        } else {
          str = ((c)str).r.get(0);
        } 
        return (View)parama.get(str);
      } 
    } 
    return null;
  }
  
  private static Object a(t paramt, f paramf1, f paramf2, boolean paramBoolean) {
    Object object;
    if (paramf1 == null || paramf2 == null)
      return null; 
    if (paramBoolean) {
      object = paramf2.y();
    } else {
      object = object.x();
    } 
    return paramt.c(paramt.b(object));
  }
  
  private static Object a(t paramt, f paramf, boolean paramBoolean) {
    Object object;
    if (paramf == null)
      return null; 
    if (paramBoolean) {
      object = paramf.u();
    } else {
      object = object.l();
    } 
    return paramt.b(object);
  }
  
  private static Object a(t paramt, ViewGroup paramViewGroup, View paramView, a.b.g.g.a<String, String> parama, e parame, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2, Object paramObject1, Object paramObject2) {
    Object object;
    f f2 = parame.a;
    f f1 = parame.d;
    if (f2 == null || f1 == null)
      return null; 
    boolean bool = parame.b;
    if (parama.isEmpty()) {
      object = null;
    } else {
      object = a(paramt, f2, f1, bool);
    } 
    a.b.g.g.a<String, View> a1 = b(paramt, parama, object, parame);
    if (parama.isEmpty()) {
      object = null;
    } else {
      paramArrayList1.addAll(a1.values());
    } 
    if (paramObject1 == null && paramObject2 == null && object == null)
      return null; 
    a(f2, f1, bool, a1, true);
    if (object != null) {
      Rect rect = new Rect();
      paramt.b(object, paramView, paramArrayList1);
      a(paramt, object, paramObject2, a1, parame.e, parame.f);
      if (paramObject1 != null)
        paramt.a(paramObject1, rect); 
      paramObject2 = rect;
    } else {
      paramObject2 = null;
    } 
    a0.a((View)paramViewGroup, new d(paramt, parama, object, parame, paramArrayList2, paramView, f2, f1, bool, paramArrayList1, paramObject1, (Rect)paramObject2));
    return object;
  }
  
  private static Object a(t paramt, Object paramObject1, Object paramObject2, Object paramObject3, f paramf, boolean paramBoolean) {
    Object object;
    boolean bool2 = true;
    boolean bool1 = bool2;
    if (paramObject1 != null) {
      bool1 = bool2;
      if (paramObject2 != null) {
        bool1 = bool2;
        if (paramf != null) {
          if (paramBoolean) {
            paramBoolean = paramf.f();
          } else {
            paramBoolean = paramf.e();
          } 
          bool1 = paramBoolean;
        } 
      } 
    } 
    if (bool1) {
      object = paramt.b(paramObject2, paramObject1, paramObject3);
    } else {
      object = object.a(paramObject2, paramObject1, paramObject3);
    } 
    return object;
  }
  
  private static String a(a.b.g.g.a<String, String> parama, String paramString) {
    int i = parama.size();
    for (byte b = 0; b < i; b++) {
      if (paramString.equals(parama.d(b)))
        return (String)parama.b(b); 
    } 
    return null;
  }
  
  static ArrayList<View> a(t paramt, Object paramObject, f paramf, ArrayList<View> paramArrayList, View paramView) {
    ArrayList<View> arrayList = null;
    if (paramObject != null) {
      ArrayList<View> arrayList1 = new ArrayList();
      View view = paramf.A();
      if (view != null)
        paramt.a(arrayList1, view); 
      if (paramArrayList != null)
        arrayList1.removeAll(paramArrayList); 
      arrayList = arrayList1;
      if (!arrayList1.isEmpty()) {
        arrayList1.add(paramView);
        paramt.a(paramObject, arrayList1);
        arrayList = arrayList1;
      } 
    } 
    return arrayList;
  }
  
  private static void a(a.b.g.g.a<String, String> parama, a.b.g.g.a<String, View> parama1) {
    for (int i = parama.size() - 1; i >= 0; i--) {
      if (!parama1.containsKey(parama.d(i)))
        parama.c(i); 
    } 
  }
  
  private static void a(c paramc, c.a parama, SparseArray<e> paramSparseArray, boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: aload_1
    //   1: getfield b : Landroid/support/v4/app/f;
    //   4: astore #15
    //   6: aload #15
    //   8: ifnonnull -> 12
    //   11: return
    //   12: aload #15
    //   14: getfield A : I
    //   17: istore #10
    //   19: iload #10
    //   21: ifne -> 25
    //   24: return
    //   25: iload_3
    //   26: ifeq -> 42
    //   29: getstatic android/support/v4/app/r.a : [I
    //   32: aload_1
    //   33: getfield a : I
    //   36: iaload
    //   37: istore #5
    //   39: goto -> 48
    //   42: aload_1
    //   43: getfield a : I
    //   46: istore #5
    //   48: iconst_0
    //   49: istore #8
    //   51: iconst_0
    //   52: istore #6
    //   54: iconst_0
    //   55: istore #9
    //   57: iconst_0
    //   58: istore #7
    //   60: iconst_0
    //   61: istore #12
    //   63: iconst_0
    //   64: istore #13
    //   66: iload #5
    //   68: iconst_1
    //   69: if_icmpeq -> 371
    //   72: iload #5
    //   74: iconst_3
    //   75: if_icmpeq -> 275
    //   78: iload #5
    //   80: iconst_4
    //   81: if_icmpeq -> 185
    //   84: iload #5
    //   86: iconst_5
    //   87: if_icmpeq -> 119
    //   90: iload #5
    //   92: bipush #6
    //   94: if_icmpeq -> 275
    //   97: iload #5
    //   99: bipush #7
    //   101: if_icmpeq -> 371
    //   104: iconst_0
    //   105: istore #11
    //   107: iconst_0
    //   108: istore #6
    //   110: iconst_0
    //   111: istore #7
    //   113: iconst_0
    //   114: istore #5
    //   116: goto -> 422
    //   119: iload #4
    //   121: ifeq -> 166
    //   124: iload #13
    //   126: istore #11
    //   128: aload #15
    //   130: getfield Q : Z
    //   133: ifeq -> 163
    //   136: iload #13
    //   138: istore #11
    //   140: aload #15
    //   142: getfield C : Z
    //   145: ifne -> 163
    //   148: iload #13
    //   150: istore #11
    //   152: aload #15
    //   154: getfield m : Z
    //   157: ifeq -> 163
    //   160: iconst_1
    //   161: istore #11
    //   163: goto -> 173
    //   166: aload #15
    //   168: getfield C : Z
    //   171: istore #11
    //   173: iconst_0
    //   174: istore #6
    //   176: iconst_0
    //   177: istore #7
    //   179: iconst_1
    //   180: istore #5
    //   182: goto -> 422
    //   185: iload #4
    //   187: ifeq -> 232
    //   190: iload #8
    //   192: istore #5
    //   194: aload #15
    //   196: getfield Q : Z
    //   199: ifeq -> 229
    //   202: iload #8
    //   204: istore #5
    //   206: aload #15
    //   208: getfield m : Z
    //   211: ifeq -> 229
    //   214: iload #8
    //   216: istore #5
    //   218: aload #15
    //   220: getfield C : Z
    //   223: ifeq -> 229
    //   226: iconst_1
    //   227: istore #5
    //   229: goto -> 259
    //   232: iload #6
    //   234: istore #5
    //   236: aload #15
    //   238: getfield m : Z
    //   241: ifeq -> 259
    //   244: iload #6
    //   246: istore #5
    //   248: aload #15
    //   250: getfield C : Z
    //   253: ifne -> 259
    //   256: iconst_1
    //   257: istore #5
    //   259: iconst_0
    //   260: istore #11
    //   262: iconst_1
    //   263: istore #6
    //   265: iload #5
    //   267: istore #7
    //   269: iconst_0
    //   270: istore #5
    //   272: goto -> 422
    //   275: iload #4
    //   277: ifeq -> 328
    //   280: aload #15
    //   282: getfield m : Z
    //   285: ifne -> 321
    //   288: aload #15
    //   290: getfield K : Landroid/view/View;
    //   293: astore_1
    //   294: aload_1
    //   295: ifnull -> 321
    //   298: aload_1
    //   299: invokevirtual getVisibility : ()I
    //   302: ifne -> 321
    //   305: aload #15
    //   307: getfield R : F
    //   310: fconst_0
    //   311: fcmpl
    //   312: iflt -> 321
    //   315: iconst_1
    //   316: istore #5
    //   318: goto -> 325
    //   321: iload #9
    //   323: istore #5
    //   325: goto -> 355
    //   328: iload #7
    //   330: istore #5
    //   332: aload #15
    //   334: getfield m : Z
    //   337: ifeq -> 355
    //   340: iload #7
    //   342: istore #5
    //   344: aload #15
    //   346: getfield C : Z
    //   349: ifne -> 355
    //   352: iconst_1
    //   353: istore #5
    //   355: iconst_0
    //   356: istore #11
    //   358: iconst_1
    //   359: istore #6
    //   361: iload #5
    //   363: istore #7
    //   365: iconst_0
    //   366: istore #5
    //   368: goto -> 422
    //   371: iload #4
    //   373: ifeq -> 386
    //   376: aload #15
    //   378: getfield P : Z
    //   381: istore #11
    //   383: goto -> 413
    //   386: iload #12
    //   388: istore #11
    //   390: aload #15
    //   392: getfield m : Z
    //   395: ifne -> 413
    //   398: iload #12
    //   400: istore #11
    //   402: aload #15
    //   404: getfield C : Z
    //   407: ifne -> 413
    //   410: iconst_1
    //   411: istore #11
    //   413: iconst_0
    //   414: istore #6
    //   416: iconst_0
    //   417: istore #7
    //   419: iconst_1
    //   420: istore #5
    //   422: aload_2
    //   423: iload #10
    //   425: invokevirtual get : (I)Ljava/lang/Object;
    //   428: checkcast android/support/v4/app/r$e
    //   431: astore_1
    //   432: iload #11
    //   434: ifeq -> 464
    //   437: aload_1
    //   438: aload_2
    //   439: iload #10
    //   441: invokestatic a : (Landroid/support/v4/app/r$e;Landroid/util/SparseArray;I)Landroid/support/v4/app/r$e;
    //   444: astore_1
    //   445: aload_1
    //   446: aload #15
    //   448: putfield a : Landroid/support/v4/app/f;
    //   451: aload_1
    //   452: iload_3
    //   453: putfield b : Z
    //   456: aload_1
    //   457: aload_0
    //   458: putfield c : Landroid/support/v4/app/c;
    //   461: goto -> 464
    //   464: iload #4
    //   466: ifne -> 547
    //   469: iload #5
    //   471: ifeq -> 547
    //   474: aload_1
    //   475: ifnull -> 492
    //   478: aload_1
    //   479: getfield d : Landroid/support/v4/app/f;
    //   482: aload #15
    //   484: if_acmpne -> 492
    //   487: aload_1
    //   488: aconst_null
    //   489: putfield d : Landroid/support/v4/app/f;
    //   492: aload_0
    //   493: getfield a : Landroid/support/v4/app/l;
    //   496: astore #14
    //   498: aload #15
    //   500: getfield c : I
    //   503: iconst_1
    //   504: if_icmpge -> 544
    //   507: aload #14
    //   509: getfield n : I
    //   512: iconst_1
    //   513: if_icmplt -> 544
    //   516: aload_0
    //   517: getfield s : Z
    //   520: ifne -> 544
    //   523: aload #14
    //   525: aload #15
    //   527: invokevirtual g : (Landroid/support/v4/app/f;)V
    //   530: aload #14
    //   532: aload #15
    //   534: iconst_1
    //   535: iconst_0
    //   536: iconst_0
    //   537: iconst_0
    //   538: invokevirtual a : (Landroid/support/v4/app/f;IIIZ)V
    //   541: goto -> 547
    //   544: goto -> 547
    //   547: iload #7
    //   549: ifeq -> 599
    //   552: aload_1
    //   553: astore #14
    //   555: aload #14
    //   557: ifnull -> 571
    //   560: aload #14
    //   562: astore_1
    //   563: aload #14
    //   565: getfield d : Landroid/support/v4/app/f;
    //   568: ifnonnull -> 599
    //   571: aload #14
    //   573: aload_2
    //   574: iload #10
    //   576: invokestatic a : (Landroid/support/v4/app/r$e;Landroid/util/SparseArray;I)Landroid/support/v4/app/r$e;
    //   579: astore_1
    //   580: aload_1
    //   581: aload #15
    //   583: putfield d : Landroid/support/v4/app/f;
    //   586: aload_1
    //   587: iload_3
    //   588: putfield e : Z
    //   591: aload_1
    //   592: aload_0
    //   593: putfield f : Landroid/support/v4/app/c;
    //   596: goto -> 599
    //   599: iload #4
    //   601: ifne -> 627
    //   604: iload #6
    //   606: ifeq -> 627
    //   609: aload_1
    //   610: ifnull -> 627
    //   613: aload_1
    //   614: getfield a : Landroid/support/v4/app/f;
    //   617: aload #15
    //   619: if_acmpne -> 627
    //   622: aload_1
    //   623: aconst_null
    //   624: putfield a : Landroid/support/v4/app/f;
    //   627: return
  }
  
  public static void a(c paramc, SparseArray<e> paramSparseArray, boolean paramBoolean) {
    int i = paramc.b.size();
    for (byte b = 0; b < i; b++)
      a(paramc, paramc.b.get(b), paramSparseArray, false, paramBoolean); 
  }
  
  static void a(f paramf1, f paramf2, boolean paramBoolean1, a.b.g.g.a<String, View> parama, boolean paramBoolean2) {
    c0 c0;
    if (paramBoolean1) {
      c0 = paramf2.m();
    } else {
      c0 = c0.m();
    } 
    if (c0 != null) {
      int i;
      ArrayList<Object> arrayList1 = new ArrayList();
      ArrayList<Object> arrayList2 = new ArrayList();
      if (parama == null) {
        i = 0;
      } else {
        i = parama.size();
      } 
      for (byte b = 0; b < i; b++) {
        arrayList2.add(parama.b(b));
        arrayList1.add(parama.d(b));
      } 
      if (paramBoolean2) {
        c0.b(arrayList2, arrayList1, null);
      } else {
        c0.a(arrayList2, arrayList1, null);
      } 
    } 
  }
  
  private static void a(l paraml, int paramInt, e parame, View paramView, a.b.g.g.a<String, String> parama) {
    if (paraml.p.a()) {
      ViewGroup viewGroup = (ViewGroup)paraml.p.a(paramInt);
    } else {
      paraml = null;
    } 
    if (paraml == null)
      return; 
    f f1 = parame.a;
    f f2 = parame.d;
    t t1 = a(f2, f1);
    if (t1 == null)
      return; 
    boolean bool1 = parame.b;
    boolean bool2 = parame.e;
    Object object2 = a(t1, f1, bool1);
    Object object1 = b(t1, f2, bool2);
    ArrayList<View> arrayList3 = new ArrayList();
    ArrayList<View> arrayList1 = new ArrayList();
    Object object3 = a(t1, (ViewGroup)paraml, paramView, parama, parame, arrayList3, arrayList1, object2, object1);
    if (object2 == null && object3 == null && object1 == null)
      return; 
    ArrayList<View> arrayList2 = a(t1, object1, f2, arrayList3, paramView);
    if (arrayList2 == null || arrayList2.isEmpty())
      object1 = null; 
    t1.a(object2, paramView);
    Object object4 = a(t1, object2, object1, object3, f1, parame.b);
    if (object4 != null) {
      ArrayList<View> arrayList = new ArrayList();
      t1.a(object4, object2, arrayList, object1, arrayList2, object3, arrayList1);
      a(t1, (ViewGroup)paraml, f1, paramView, arrayList1, object2, arrayList, object1, arrayList2);
      t1.a((View)paraml, arrayList1, (Map<String, String>)parama);
      t1.a((ViewGroup)paraml, object4);
      t1.a((ViewGroup)paraml, arrayList1, (Map<String, String>)parama);
    } 
  }
  
  static void a(l paraml, ArrayList<c> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, boolean paramBoolean) {
    if (paraml.n < 1)
      return; 
    SparseArray<e> sparseArray = new SparseArray();
    int i;
    for (i = paramInt1; i < paramInt2; i++) {
      c c = paramArrayList.get(i);
      if (((Boolean)paramArrayList1.get(i)).booleanValue()) {
        b(c, sparseArray, paramBoolean);
      } else {
        a(c, sparseArray, paramBoolean);
      } 
    } 
    if (sparseArray.size() != 0) {
      View view = new View(paraml.o.c());
      int j = sparseArray.size();
      for (i = 0; i < j; i++) {
        int k = sparseArray.keyAt(i);
        a.b.g.g.a<String, String> a = a(k, paramArrayList, paramArrayList1, paramInt1, paramInt2);
        e e = (e)sparseArray.valueAt(i);
        if (paramBoolean) {
          b(paraml, k, e, view, a);
        } else {
          a(paraml, k, e, view, a);
        } 
      } 
    } 
  }
  
  private static void a(t paramt, ViewGroup paramViewGroup, f paramf, View paramView, ArrayList<View> paramArrayList1, Object paramObject1, ArrayList<View> paramArrayList2, Object paramObject2, ArrayList<View> paramArrayList3) {
    a0.a((View)paramViewGroup, new b(paramObject1, paramt, paramView, paramf, paramArrayList1, paramArrayList2, paramArrayList3, paramObject2));
  }
  
  private static void a(t paramt, Object paramObject, f paramf, ArrayList<View> paramArrayList) {
    if (paramf != null && paramObject != null && paramf.m && paramf.C && paramf.Q) {
      paramf.f(true);
      paramt.a(paramObject, paramf.A(), paramArrayList);
      a0.a((View)paramf.J, new a(paramArrayList));
    } 
  }
  
  private static void a(t paramt, Object paramObject1, Object paramObject2, a.b.g.g.a<String, View> parama, boolean paramBoolean, c paramc) {
    ArrayList<String> arrayList = paramc.q;
    if (arrayList != null && !arrayList.isEmpty()) {
      String str;
      if (paramBoolean) {
        str = paramc.r.get(0);
      } else {
        str = ((c)str).q.get(0);
      } 
      View view = (View)parama.get(str);
      paramt.c(paramObject1, view);
      if (paramObject2 != null)
        paramt.c(paramObject2, view); 
    } 
  }
  
  static void a(ArrayList<View> paramArrayList, int paramInt) {
    if (paramArrayList == null)
      return; 
    for (int i = paramArrayList.size() - 1; i >= 0; i--)
      ((View)paramArrayList.get(i)).setVisibility(paramInt); 
  }
  
  private static void a(ArrayList<View> paramArrayList, a.b.g.g.a<String, View> parama, Collection<String> paramCollection) {
    for (int i = parama.size() - 1; i >= 0; i--) {
      View view = (View)parama.d(i);
      if (paramCollection.contains(u.q(view)))
        paramArrayList.add(view); 
    } 
  }
  
  private static boolean a(t paramt, List<Object> paramList) {
    byte b = 0;
    int i = paramList.size();
    while (b < i) {
      if (!paramt.a(paramList.get(b)))
        return false; 
      b++;
    } 
    return true;
  }
  
  private static a.b.g.g.a<String, View> b(t paramt, a.b.g.g.a<String, String> parama, Object paramObject, e parame) {
    ArrayList<String> arrayList;
    if (parama.isEmpty() || paramObject == null) {
      parama.clear();
      return null;
    } 
    paramObject = parame.d;
    a.b.g.g.a<String, View> a1 = new a.b.g.g.a();
    paramt.a((Map<String, View>)a1, paramObject.A());
    c c = parame.f;
    if (parame.e) {
      paramObject = paramObject.m();
      arrayList = c.r;
    } else {
      paramObject = paramObject.o();
      arrayList = ((c)arrayList).q;
    } 
    a1.a(arrayList);
    if (paramObject != null) {
      paramObject.a(arrayList, (Map<String, View>)a1);
      for (int i = arrayList.size() - 1; i >= 0; i--) {
        String str = arrayList.get(i);
        paramObject = a1.get(str);
        if (paramObject == null) {
          parama.remove(str);
        } else if (!str.equals(u.q((View)paramObject))) {
          str = (String)parama.remove(str);
          parama.put(u.q((View)paramObject), str);
        } 
      } 
    } else {
      parama.a(a1.keySet());
    } 
    return a1;
  }
  
  private static Object b(t paramt, f paramf, boolean paramBoolean) {
    Object object;
    if (paramf == null)
      return null; 
    if (paramBoolean) {
      object = paramf.w();
    } else {
      object = object.n();
    } 
    return paramt.b(object);
  }
  
  private static Object b(t paramt, ViewGroup paramViewGroup, View paramView, a.b.g.g.a<String, String> parama, e parame, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2, Object paramObject1, Object paramObject2) {
    Object object1;
    Object object2;
    f f2 = parame.a;
    f f1 = parame.d;
    if (f2 != null)
      f2.A().setVisibility(0); 
    if (f2 == null || f1 == null)
      return null; 
    boolean bool = parame.b;
    if (parama.isEmpty()) {
      object2 = null;
    } else {
      object2 = a(paramt, f2, f1, bool);
    } 
    a.b.g.g.a<String, View> a2 = b(paramt, parama, object2, parame);
    a.b.g.g.a<String, View> a1 = a(paramt, parama, object2, parame);
    if (parama.isEmpty()) {
      if (a2 != null)
        a2.clear(); 
      if (a1 != null)
        a1.clear(); 
      parama = null;
    } else {
      a(paramArrayList1, a2, parama.keySet());
      a(paramArrayList2, a1, parama.values());
      object1 = object2;
    } 
    if (paramObject1 == null && paramObject2 == null && object1 == null)
      return null; 
    a(f2, f1, bool, a2, true);
    if (object1 != null) {
      paramArrayList2.add(paramView);
      paramt.b(object1, paramView, paramArrayList1);
      a(paramt, object1, paramObject2, a2, parame.e, parame.f);
      Rect rect = new Rect();
      View view = a(a1, parame, paramObject1, bool);
      if (view != null)
        paramt.a(paramObject1, rect); 
    } else {
      paramView = null;
      parame = null;
    } 
    a0.a((View)paramViewGroup, new c(f2, f1, bool, a1, (View)parame, paramt, (Rect)paramView));
    return object1;
  }
  
  public static void b(c paramc, SparseArray<e> paramSparseArray, boolean paramBoolean) {
    if (!paramc.a.p.a())
      return; 
    for (int i = paramc.b.size() - 1; i >= 0; i--)
      a(paramc, paramc.b.get(i), paramSparseArray, true, paramBoolean); 
  }
  
  private static void b(l paraml, int paramInt, e parame, View paramView, a.b.g.g.a<String, String> parama) {
    if (paraml.p.a()) {
      ViewGroup viewGroup = (ViewGroup)paraml.p.a(paramInt);
    } else {
      paraml = null;
    } 
    if (paraml == null)
      return; 
    f f2 = parame.a;
    f f1 = parame.d;
    t t1 = a(f1, f2);
    if (t1 == null)
      return; 
    boolean bool2 = parame.b;
    boolean bool1 = parame.e;
    ArrayList<View> arrayList3 = new ArrayList();
    ArrayList<View> arrayList4 = new ArrayList();
    Object object2 = a(t1, f2, bool2);
    Object object1 = b(t1, f1, bool1);
    Object object3 = b(t1, (ViewGroup)paraml, paramView, parama, parame, arrayList4, arrayList3, object2, object1);
    if (object2 == null && object3 == null && object1 == null)
      return; 
    ArrayList<View> arrayList1 = a(t1, object1, f1, arrayList4, paramView);
    ArrayList<View> arrayList2 = a(t1, object2, f2, arrayList3, paramView);
    a(arrayList2, 4);
    Object object4 = a(t1, object2, object1, object3, f2, bool2);
    if (object4 != null) {
      a(t1, object1, f1, arrayList1);
      ArrayList<String> arrayList = t1.a(arrayList3);
      t1.a(object4, object2, arrayList2, object1, arrayList1, object3, arrayList3);
      t1.a((ViewGroup)paraml, object4);
      t1.a((View)paraml, arrayList4, arrayList3, arrayList, (Map<String, String>)parama);
      a(arrayList2, 0);
      t1.b(object3, arrayList4, arrayList3);
    } 
  }
  
  static {
    t t1;
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 21) {
      t1 = new s();
    } else {
      t1 = null;
    } 
    b = t1;
  }
  
  static final class a implements Runnable {
    final ArrayList c;
    
    a(ArrayList param1ArrayList) {}
    
    public void run() {
      r.a(this.c, 4);
    }
  }
  
  static final class b implements Runnable {
    final Object c;
    
    final t d;
    
    final View e;
    
    final f f;
    
    final ArrayList g;
    
    final ArrayList h;
    
    final ArrayList i;
    
    final Object j;
    
    b(Object param1Object1, t param1t, View param1View, f param1f, ArrayList param1ArrayList1, ArrayList param1ArrayList2, ArrayList param1ArrayList3, Object param1Object2) {}
    
    public void run() {
      Object<View> object = (Object<View>)this.c;
      if (object != null) {
        this.d.b(object, this.e);
        object = (Object<View>)r.a(this.d, this.c, this.f, this.g, this.e);
        this.h.addAll((Collection<? extends View>)object);
      } 
      if (this.i != null) {
        if (this.j != null) {
          object = (Object<View>)new ArrayList();
          object.add(this.e);
          this.d.a(this.j, this.i, (ArrayList<View>)object);
        } 
        this.i.clear();
        this.i.add(this.e);
      } 
    }
  }
  
  static final class c implements Runnable {
    final f c;
    
    final f d;
    
    final boolean e;
    
    final a.b.g.g.a f;
    
    final View g;
    
    final t h;
    
    final Rect i;
    
    c(f param1f1, f param1f2, boolean param1Boolean, a.b.g.g.a param1a, View param1View, t param1t, Rect param1Rect) {}
    
    public void run() {
      r.a(this.c, this.d, this.e, this.f, false);
      View view = this.g;
      if (view != null)
        this.h.a(view, this.i); 
    }
  }
  
  static final class d implements Runnable {
    final t c;
    
    final a.b.g.g.a d;
    
    final Object e;
    
    final r.e f;
    
    final ArrayList g;
    
    final View h;
    
    final f i;
    
    final f j;
    
    final boolean k;
    
    final ArrayList l;
    
    final Object m;
    
    final Rect n;
    
    d(t param1t, a.b.g.g.a param1a, Object param1Object1, r.e param1e, ArrayList param1ArrayList1, View param1View, f param1f1, f param1f2, boolean param1Boolean, ArrayList param1ArrayList2, Object param1Object2, Rect param1Rect) {}
    
    public void run() {
      a.b.g.g.a<String, View> a1 = r.a(this.c, this.d, this.e, this.f);
      if (a1 != null) {
        this.g.addAll(a1.values());
        this.g.add(this.h);
      } 
      r.a(this.i, this.j, this.k, a1, false);
      Object object = this.e;
      if (object != null) {
        this.c.b(object, this.l, this.g);
        object = r.a(a1, this.f, this.m, this.k);
        if (object != null)
          this.c.a((View)object, this.n); 
      } 
    }
  }
  
  static class e {
    public f a;
    
    public boolean b;
    
    public c c;
    
    public f d;
    
    public boolean e;
    
    public c f;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */