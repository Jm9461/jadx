package android.support.v4.app;

import a.b.g.g.e;
import android.util.Log;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

final class c extends q implements k.a, l.l {
  final l a;
  
  ArrayList<a> b = new ArrayList<a>();
  
  int c;
  
  int d;
  
  int e;
  
  int f;
  
  int g;
  
  int h;
  
  boolean i;
  
  String j;
  
  boolean k;
  
  int l = -1;
  
  int m;
  
  CharSequence n;
  
  int o;
  
  CharSequence p;
  
  ArrayList<String> q;
  
  ArrayList<String> r;
  
  boolean s = false;
  
  ArrayList<Runnable> t;
  
  public c(l paraml) {
    this.a = paraml;
  }
  
  private void a(int paramInt1, f paramf, String paramString, int paramInt2) {
    StringBuilder stringBuilder2;
    Class<?> clazz = paramf.getClass();
    int i = clazz.getModifiers();
    if (!clazz.isAnonymousClass() && Modifier.isPublic(i) && (!clazz.isMemberClass() || Modifier.isStatic(i))) {
      paramf.t = this.a;
      if (paramString != null) {
        String str = paramf.B;
        if (str == null || paramString.equals(str)) {
          paramf.B = paramString;
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Can't change tag of fragment ");
          stringBuilder2.append(paramf);
          stringBuilder2.append(": was ");
          stringBuilder2.append(paramf.B);
          stringBuilder2.append(" now ");
          stringBuilder2.append(paramString);
          throw new IllegalStateException(stringBuilder2.toString());
        } 
      } 
      if (paramInt1 != 0) {
        StringBuilder stringBuilder;
        if (paramInt1 != -1) {
          i = paramf.z;
          if (i == 0 || i == paramInt1) {
            paramf.z = paramInt1;
            paramf.A = paramInt1;
          } else {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Can't change container ID of fragment ");
            stringBuilder.append(paramf);
            stringBuilder.append(": was ");
            stringBuilder.append(paramf.z);
            stringBuilder.append(" now ");
            stringBuilder.append(paramInt1);
            throw new IllegalStateException(stringBuilder.toString());
          } 
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Can't add fragment ");
          stringBuilder2.append(paramf);
          stringBuilder2.append(" with tag ");
          stringBuilder2.append((String)stringBuilder);
          stringBuilder2.append(" to container view with no id");
          throw new IllegalArgumentException(stringBuilder2.toString());
        } 
      } 
      a(new a(paramInt2, paramf));
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Fragment ");
    stringBuilder1.append(stringBuilder2.getCanonicalName());
    stringBuilder1.append(" must be a public static class to be  properly recreated from");
    stringBuilder1.append(" instance state.");
    throw new IllegalStateException(stringBuilder1.toString());
  }
  
  private static boolean b(a parama) {
    boolean bool;
    f f = parama.b;
    if (f != null && f.m && f.K != null && !f.D && !f.C && f.H()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int a() {
    return a(false);
  }
  
  int a(boolean paramBoolean) {
    if (!this.k) {
      if (l.G) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Commit: ");
        stringBuilder.append(this);
        Log.v("FragmentManager", stringBuilder.toString());
        PrintWriter printWriter = new PrintWriter((Writer)new e("FragmentManager"));
        a("  ", (FileDescriptor)null, printWriter, (String[])null);
        printWriter.close();
      } 
      this.k = true;
      if (this.i) {
        this.l = this.a.b(this);
      } else {
        this.l = -1;
      } 
      this.a.a(this, paramBoolean);
      return this.l;
    } 
    throw new IllegalStateException("commit already called");
  }
  
  f a(ArrayList<f> paramArrayList, f paramf) {
    int i = 0;
    f f1;
    for (f1 = paramf; i < this.b.size(); f1 = paramf) {
      f f2;
      a a1 = this.b.get(i);
      int j = a1.a;
      if (j != 1)
        if (j != 2) {
          if (j != 3 && j != 6) {
            if (j != 7) {
              if (j != 8) {
                j = i;
                paramf = f1;
              } else {
                this.b.add(i, new a(9, f1));
                j = i + 1;
                paramf = a1.b;
              } 
              continue;
            } 
          } else {
            paramArrayList.remove(a1.b);
            f2 = a1.b;
            j = i;
            paramf = f1;
            if (f2 == f1) {
              this.b.add(i, new a(9, f2));
              j = i + 1;
              paramf = null;
            } 
            continue;
          } 
        } else {
          f f3 = ((a)f2).b;
          int k = f3.A;
          boolean bool = false;
          j = paramArrayList.size() - 1;
          for (paramf = f1; j >= 0; paramf = f1) {
            f f4 = paramArrayList.get(j);
            int m = i;
            boolean bool1 = bool;
            f1 = paramf;
            if (f4.A == k)
              if (f4 == f3) {
                bool1 = true;
                m = i;
                f1 = paramf;
              } else {
                m = i;
                f1 = paramf;
                if (f4 == paramf) {
                  this.b.add(i, new a(9, f4));
                  m = i + 1;
                  f1 = null;
                } 
                a a2 = new a(3, f4);
                a2.c = ((a)f2).c;
                a2.e = ((a)f2).e;
                a2.d = ((a)f2).d;
                a2.f = ((a)f2).f;
                this.b.add(m, a2);
                paramArrayList.remove(f4);
                m++;
                bool1 = bool;
              }  
            j--;
            i = m;
            bool = bool1;
          } 
          if (bool) {
            this.b.remove(i);
            i--;
          } else {
            ((a)f2).a = 1;
            paramArrayList.add(f3);
          } 
          j = i;
          continue;
        }  
      paramArrayList.add(((a)f2).b);
      paramf = f1;
      j = i;
      continue;
      i = SYNTHETIC_LOCAL_VARIABLE_4 + 1;
    } 
    return f1;
  }
  
  public q a(int paramInt, f paramf) {
    a(paramInt, paramf, (String)null, 1);
    return this;
  }
  
  public q a(int paramInt, f paramf, String paramString) {
    if (paramInt != 0) {
      a(paramInt, paramf, paramString, 2);
      return this;
    } 
    throw new IllegalArgumentException("Must use non-zero containerViewId");
  }
  
  public q a(f paramf) {
    a(new a(3, paramf));
    return this;
  }
  
  public q a(f paramf, String paramString) {
    a(0, paramf, paramString, 1);
    return this;
  }
  
  void a(int paramInt) {
    if (!this.i)
      return; 
    if (l.G) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Bump nesting in ");
      stringBuilder.append(this);
      stringBuilder.append(" by ");
      stringBuilder.append(paramInt);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    int i = this.b.size();
    for (byte b = 0; b < i; b++) {
      a a1 = this.b.get(b);
      f f = a1.b;
      if (f != null) {
        f.s += paramInt;
        if (l.G) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Bump nesting of ");
          stringBuilder.append(a1.b);
          stringBuilder.append(" to ");
          stringBuilder.append(a1.b.s);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
      } 
    } 
  }
  
  void a(a parama) {
    this.b.add(parama);
    parama.c = this.c;
    parama.d = this.d;
    parama.e = this.e;
    parama.f = this.f;
  }
  
  void a(f.f paramf) {
    for (byte b = 0; b < this.b.size(); b++) {
      a a1 = this.b.get(b);
      if (b(a1))
        a1.b.a(paramf); 
    } 
  }
  
  public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    a(paramString, paramPrintWriter, true);
  }
  
  public void a(String paramString, PrintWriter paramPrintWriter, boolean paramBoolean) {
    if (paramBoolean) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mName=");
      paramPrintWriter.print(this.j);
      paramPrintWriter.print(" mIndex=");
      paramPrintWriter.print(this.l);
      paramPrintWriter.print(" mCommitted=");
      paramPrintWriter.println(this.k);
      if (this.g != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mTransition=#");
        paramPrintWriter.print(Integer.toHexString(this.g));
        paramPrintWriter.print(" mTransitionStyle=#");
        paramPrintWriter.println(Integer.toHexString(this.h));
      } 
      if (this.c != 0 || this.d != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.c));
        paramPrintWriter.print(" mExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.d));
      } 
      if (this.e != 0 || this.f != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mPopEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.e));
        paramPrintWriter.print(" mPopExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.f));
      } 
      if (this.m != 0 || this.n != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.m));
        paramPrintWriter.print(" mBreadCrumbTitleText=");
        paramPrintWriter.println(this.n);
      } 
      if (this.o != 0 || this.p != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbShortTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.o));
        paramPrintWriter.print(" mBreadCrumbShortTitleText=");
        paramPrintWriter.println(this.p);
      } 
    } 
    if (!this.b.isEmpty()) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Operations:");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramString);
      stringBuilder.append("    ");
      stringBuilder.toString();
      int i = this.b.size();
      for (byte b = 0; b < i; b++) {
        String str;
        a a1 = this.b.get(b);
        switch (a1.a) {
          default:
            stringBuilder = new StringBuilder();
            stringBuilder.append("cmd=");
            stringBuilder.append(a1.a);
            str = stringBuilder.toString();
            break;
          case 9:
            str = "UNSET_PRIMARY_NAV";
            break;
          case 8:
            str = "SET_PRIMARY_NAV";
            break;
          case 7:
            str = "ATTACH";
            break;
          case 6:
            str = "DETACH";
            break;
          case 5:
            str = "SHOW";
            break;
          case 4:
            str = "HIDE";
            break;
          case 3:
            str = "REMOVE";
            break;
          case 2:
            str = "REPLACE";
            break;
          case 1:
            str = "ADD";
            break;
          case 0:
            str = "NULL";
            break;
        } 
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  Op #");
        paramPrintWriter.print(b);
        paramPrintWriter.print(": ");
        paramPrintWriter.print(str);
        paramPrintWriter.print(" ");
        paramPrintWriter.println(a1.b);
        if (paramBoolean) {
          if (a1.c != 0 || a1.d != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("enterAnim=#");
            paramPrintWriter.print(Integer.toHexString(a1.c));
            paramPrintWriter.print(" exitAnim=#");
            paramPrintWriter.println(Integer.toHexString(a1.d));
          } 
          if (a1.e != 0 || a1.f != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("popEnterAnim=#");
            paramPrintWriter.print(Integer.toHexString(a1.e));
            paramPrintWriter.print(" popExitAnim=#");
            paramPrintWriter.println(Integer.toHexString(a1.f));
          } 
        } 
      } 
    } 
  }
  
  boolean a(ArrayList<c> paramArrayList, int paramInt1, int paramInt2) {
    if (paramInt2 == paramInt1)
      return false; 
    int i = this.b.size();
    byte b1 = -1;
    byte b = 0;
    while (b < i) {
      byte b2;
      f f = ((a)this.b.get(b)).b;
      if (f != null) {
        b2 = f.A;
      } else {
        b2 = 0;
      } 
      byte b3 = b1;
      if (b2) {
        b3 = b1;
        if (b2 != b1) {
          b1 = b2;
          int j = paramInt1;
          while (true) {
            b3 = b1;
            if (j < paramInt2) {
              c c1 = paramArrayList.get(j);
              int k = c1.b.size();
              for (b3 = 0; b3 < k; b3++) {
                byte b4;
                f = ((a)c1.b.get(b3)).b;
                if (f != null) {
                  b4 = f.A;
                } else {
                  b4 = 0;
                } 
                if (b4 == b2)
                  return true; 
              } 
              j++;
              continue;
            } 
            break;
          } 
        } 
      } 
      b++;
      b1 = b3;
    } 
    return false;
  }
  
  public boolean a(ArrayList<c> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (l.G) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Run: ");
      stringBuilder.append(this);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    paramArrayList.add(this);
    paramArrayList1.add(Boolean.valueOf(false));
    if (this.i)
      this.a.a(this); 
    return true;
  }
  
  public int b() {
    return a(true);
  }
  
  f b(ArrayList<f> paramArrayList, f paramf) {
    byte b = 0;
    while (b < this.b.size()) {
      a a1 = this.b.get(b);
      int i = a1.a;
      if (i != 1)
        if (i != 3) {
          switch (i) {
            case 9:
              paramf = a1.b;
              break;
            case 8:
              paramf = null;
              break;
            case 6:
              paramArrayList.add(a1.b);
              break;
            case 7:
              paramArrayList.remove(a1.b);
              break;
          } 
          b++;
        }  
    } 
    return paramf;
  }
  
  public q b(int paramInt, f paramf) {
    a(paramInt, paramf, (String)null);
    return this;
  }
  
  void b(boolean paramBoolean) {
    for (int i = this.b.size() - 1; i >= 0; i--) {
      StringBuilder stringBuilder;
      a a1 = this.b.get(i);
      f f = a1.b;
      if (f != null)
        f.a(l.e(this.g), this.h); 
      switch (a1.a) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown cmd: ");
          stringBuilder.append(a1.a);
          throw new IllegalArgumentException(stringBuilder.toString());
        case 9:
          this.a.o((f)stringBuilder);
          break;
        case 8:
          this.a.o(null);
          break;
        case 7:
          stringBuilder.c(a1.f);
          this.a.d((f)stringBuilder);
          break;
        case 6:
          stringBuilder.c(a1.e);
          this.a.b((f)stringBuilder);
          break;
        case 5:
          stringBuilder.c(a1.f);
          this.a.f((f)stringBuilder);
          break;
        case 4:
          stringBuilder.c(a1.e);
          this.a.p((f)stringBuilder);
          break;
        case 3:
          stringBuilder.c(a1.e);
          this.a.a((f)stringBuilder, false);
          break;
        case 1:
          stringBuilder.c(a1.f);
          this.a.l((f)stringBuilder);
          break;
      } 
      if (!this.s && a1.a != 3 && stringBuilder != null)
        this.a.i((f)stringBuilder); 
    } 
    if (!this.s && paramBoolean) {
      l l1 = this.a;
      l1.a(l1.n, true);
    } 
  }
  
  boolean b(int paramInt) {
    int i = this.b.size();
    byte b = 0;
    while (true) {
      int j = 0;
      if (b < i) {
        f f = ((a)this.b.get(b)).b;
        if (f != null)
          j = f.A; 
        if (j != 0 && j == paramInt)
          return true; 
        b++;
        continue;
      } 
      return false;
    } 
  }
  
  public void c() {
    d();
    this.a.b(this, true);
  }
  
  public q d() {
    if (!this.i)
      return this; 
    throw new IllegalStateException("This transaction is already being added to the back stack");
  }
  
  void e() {
    int i = this.b.size();
    for (byte b = 0; b < i; b++) {
      StringBuilder stringBuilder;
      a a1 = this.b.get(b);
      f f = a1.b;
      if (f != null)
        f.a(this.g, this.h); 
      switch (a1.a) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown cmd: ");
          stringBuilder.append(a1.a);
          throw new IllegalArgumentException(stringBuilder.toString());
        case 9:
          this.a.o(null);
          break;
        case 8:
          this.a.o((f)stringBuilder);
          break;
        case 7:
          stringBuilder.c(a1.c);
          this.a.b((f)stringBuilder);
          break;
        case 6:
          stringBuilder.c(a1.d);
          this.a.d((f)stringBuilder);
          break;
        case 5:
          stringBuilder.c(a1.c);
          this.a.p((f)stringBuilder);
          break;
        case 4:
          stringBuilder.c(a1.d);
          this.a.f((f)stringBuilder);
          break;
        case 3:
          stringBuilder.c(a1.d);
          this.a.l((f)stringBuilder);
          break;
        case 1:
          stringBuilder.c(a1.c);
          this.a.a((f)stringBuilder, false);
          break;
      } 
      if (!this.s && a1.a != 1 && stringBuilder != null)
        this.a.i((f)stringBuilder); 
    } 
    if (!this.s) {
      l l1 = this.a;
      l1.a(l1.n, true);
    } 
  }
  
  public String f() {
    return this.j;
  }
  
  boolean g() {
    for (byte b = 0; b < this.b.size(); b++) {
      if (b(this.b.get(b)))
        return true; 
    } 
    return false;
  }
  
  public void h() {
    ArrayList<Runnable> arrayList = this.t;
    if (arrayList != null) {
      byte b = 0;
      int i = arrayList.size();
      while (b < i) {
        ((Runnable)this.t.get(b)).run();
        b++;
      } 
      this.t = null;
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("BackStackEntry{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    if (this.l >= 0) {
      stringBuilder.append(" #");
      stringBuilder.append(this.l);
    } 
    if (this.j != null) {
      stringBuilder.append(" ");
      stringBuilder.append(this.j);
    } 
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  static final class a {
    int a;
    
    f b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    a() {}
    
    a(int param1Int, f param1f) {
      this.a = param1Int;
      this.b = param1f;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */