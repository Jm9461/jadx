package android.support.v4.app;

import android.arch.lifecycle.e;
import android.arch.lifecycle.q;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class u {
  public static <T extends e & q> u a(T paramT) {
    return new LoaderManagerImpl((e)paramT, ((q)paramT).b());
  }
  
  public abstract void a();
  
  @Deprecated
  public abstract void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\ap\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */