package android.support.v4.app;

import a.b.g.g.n;
import android.app.Activity;
import android.arch.lifecycle.c;
import android.arch.lifecycle.e;
import android.arch.lifecycle.f;
import android.arch.lifecycle.m;
import android.os.Bundle;
import android.support.v4.view.e;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;

public class e0 extends Activity implements e, e.a {
  private f c;
  
  public e0() {
    new n();
    this.c = new f(this);
  }
  
  public c a() {
    return (c)this.c;
  }
  
  public boolean a(KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && e.a(view, paramKeyEvent)) ? true : e.a(this, view, (Window.Callback)this, paramKeyEvent);
  }
  
  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && e.a(view, paramKeyEvent)) ? true : super.dispatchKeyShortcutEvent(paramKeyEvent);
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    m.a(this);
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    this.c.a(c.b.e);
    super.onSaveInstanceState(paramBundle);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */