package android.support.v4.app;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.q;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

public abstract class p extends q {
  private final k c;
  
  private q d = null;
  
  private ArrayList<f.g> e = new ArrayList<f.g>();
  
  private ArrayList<f> f = new ArrayList<f>();
  
  private f g = null;
  
  public p(k paramk) {
    this.c = paramk;
  }
  
  public Object a(ViewGroup paramViewGroup, int paramInt) {
    if (this.f.size() > paramInt) {
      f f2 = this.f.get(paramInt);
      if (f2 != null)
        return f2; 
    } 
    if (this.d == null)
      this.d = this.c.a(); 
    f f1 = c(paramInt);
    if (this.e.size() > paramInt) {
      f.g g = this.e.get(paramInt);
      if (g != null)
        f1.a(g); 
    } 
    while (this.f.size() <= paramInt)
      this.f.add(null); 
    f1.g(false);
    f1.h(false);
    this.f.set(paramInt, f1);
    this.d.a(paramViewGroup.getId(), f1);
    return f1;
  }
  
  public void a(Parcelable paramParcelable, ClassLoader paramClassLoader) {
    if (paramParcelable != null) {
      Bundle bundle = (Bundle)paramParcelable;
      bundle.setClassLoader(paramClassLoader);
      Parcelable[] arrayOfParcelable = bundle.getParcelableArray("states");
      this.e.clear();
      this.f.clear();
      if (arrayOfParcelable != null)
        for (byte b = 0; b < arrayOfParcelable.length; b++)
          this.e.add((f.g)arrayOfParcelable[b]);  
      for (String str : bundle.keySet()) {
        if (str.startsWith("f")) {
          int i = Integer.parseInt(str.substring(1));
          f f1 = this.c.a(bundle, str);
          if (f1 != null) {
            while (this.f.size() <= i)
              this.f.add(null); 
            f1.g(false);
            this.f.set(i, f1);
            continue;
          } 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Bad fragment at key ");
          stringBuilder.append(str);
          Log.w("FragmentStatePagerAdapt", stringBuilder.toString());
        } 
      } 
    } 
  }
  
  public void a(ViewGroup paramViewGroup) {
    q q1 = this.d;
    if (q1 != null) {
      q1.c();
      this.d = null;
    } 
  }
  
  public void a(ViewGroup paramViewGroup, int paramInt, Object<f.g> paramObject) {
    f f1 = (f)paramObject;
    if (this.d == null)
      this.d = this.c.a(); 
    while (this.e.size() <= paramInt)
      this.e.add(null); 
    paramObject = (Object<f.g>)this.e;
    if (f1.D()) {
      f.g g = this.c.a(f1);
    } else {
      paramViewGroup = null;
    } 
    paramObject.set(paramInt, paramViewGroup);
    this.f.set(paramInt, null);
    this.d.a(f1);
  }
  
  public boolean a(View paramView, Object paramObject) {
    boolean bool;
    if (((f)paramObject).A() == paramView) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void b(ViewGroup paramViewGroup) {
    if (paramViewGroup.getId() != -1)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ViewPager with adapter ");
    stringBuilder.append(this);
    stringBuilder.append(" requires a view id");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void b(ViewGroup paramViewGroup, int paramInt, Object paramObject) {
    f f1 = (f)paramObject;
    paramObject = this.g;
    if (f1 != paramObject) {
      if (paramObject != null) {
        paramObject.g(false);
        this.g.h(false);
      } 
      f1.g(true);
      f1.h(true);
      this.g = f1;
    } 
  }
  
  public Parcelable c() {
    Bundle bundle = null;
    if (this.e.size() > 0) {
      bundle = new Bundle();
      f.g[] arrayOfG = new f.g[this.e.size()];
      this.e.toArray(arrayOfG);
      bundle.putParcelableArray("states", (Parcelable[])arrayOfG);
    } 
    byte b = 0;
    while (b < this.f.size()) {
      f f1 = this.f.get(b);
      Bundle bundle1 = bundle;
      if (f1 != null) {
        bundle1 = bundle;
        if (f1.D()) {
          bundle1 = bundle;
          if (bundle == null)
            bundle1 = new Bundle(); 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("f");
          stringBuilder.append(b);
          String str = stringBuilder.toString();
          this.c.a(bundle1, str, f1);
        } 
      } 
      b++;
      bundle = bundle1;
    } 
    return (Parcelable)bundle;
  }
  
  public abstract f c(int paramInt);
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */