package android.support.v4.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

public abstract class h {
  public f a(Context paramContext, String paramString, Bundle paramBundle) {
    return f.a(paramContext, paramString, paramBundle);
  }
  
  public abstract View a(int paramInt);
  
  public abstract boolean a();
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */