package android.support.v4.app;

import a.b.g.g.n;
import android.animation.Animator;
import android.app.Activity;
import android.arch.lifecycle.e;
import android.arch.lifecycle.j;
import android.arch.lifecycle.p;
import android.arch.lifecycle.q;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;

public class f implements ComponentCallbacks, View.OnCreateContextMenuListener, e, q {
  private static final n<String, Class<?>> Y = new n();
  
  static final Object Z = new Object();
  
  int A;
  
  String B;
  
  boolean C;
  
  boolean D;
  
  boolean E;
  
  boolean F;
  
  boolean G;
  
  boolean H = true;
  
  boolean I;
  
  ViewGroup J;
  
  View K;
  
  View L;
  
  boolean M;
  
  boolean N = true;
  
  d O;
  
  boolean P;
  
  boolean Q;
  
  float R;
  
  LayoutInflater S;
  
  boolean T;
  
  android.arch.lifecycle.f U = new android.arch.lifecycle.f(this);
  
  android.arch.lifecycle.f V;
  
  e W;
  
  j<e> X = new j();
  
  int c = 0;
  
  Bundle d;
  
  SparseArray<Parcelable> e;
  
  Boolean f;
  
  int g = -1;
  
  String h;
  
  Bundle i;
  
  f j;
  
  int k = -1;
  
  int l;
  
  boolean m;
  
  boolean n;
  
  boolean o;
  
  boolean p;
  
  boolean q;
  
  boolean r;
  
  int s;
  
  l t;
  
  j u;
  
  l v;
  
  m w;
  
  p x;
  
  f y;
  
  int z;
  
  public static f a(Context paramContext, String paramString, Bundle paramBundle) {
    try {
      Class<?> clazz2 = (Class)Y.get(paramString);
      Class<?> clazz1 = clazz2;
      if (clazz2 == null) {
        clazz1 = paramContext.getClassLoader().loadClass(paramString);
        Y.put(paramString, clazz1);
      } 
      f f1 = clazz1.getConstructor(new Class[0]).newInstance(new Object[0]);
      if (paramBundle != null) {
        paramBundle.setClassLoader(f1.getClass().getClassLoader());
        f1.m(paramBundle);
      } 
      return f1;
    } catch (ClassNotFoundException classNotFoundException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class name exists, is public, and has an");
      stringBuilder.append(" empty constructor that is public");
      throw new e(stringBuilder.toString(), classNotFoundException);
    } catch (InstantiationException instantiationException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class name exists, is public, and has an");
      stringBuilder.append(" empty constructor that is public");
      throw new e(stringBuilder.toString(), instantiationException);
    } catch (IllegalAccessException illegalAccessException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class name exists, is public, and has an");
      stringBuilder.append(" empty constructor that is public");
      throw new e(stringBuilder.toString(), illegalAccessException);
    } catch (NoSuchMethodException noSuchMethodException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": could not find Fragment constructor");
      throw new e(stringBuilder.toString(), noSuchMethodException);
    } catch (InvocationTargetException invocationTargetException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": calling Fragment constructor caused an exception");
      throw new e(stringBuilder.toString(), invocationTargetException);
    } 
  }
  
  static boolean a(Context paramContext, String paramString) {
    try {
      Class<?> clazz2 = (Class)Y.get(paramString);
      Class<?> clazz1 = clazz2;
      if (clazz2 == null) {
        clazz1 = paramContext.getClassLoader().loadClass(paramString);
        Y.put(paramString, clazz1);
      } 
      return f.class.isAssignableFrom(clazz1);
    } catch (ClassNotFoundException classNotFoundException) {
      return false;
    } 
  }
  
  private d d0() {
    if (this.O == null)
      this.O = new d(); 
    return this.O;
  }
  
  public View A() {
    return this.K;
  }
  
  void B() {
    this.g = -1;
    this.h = null;
    this.m = false;
    this.n = false;
    this.o = false;
    this.p = false;
    this.q = false;
    this.s = 0;
    this.t = null;
    this.v = null;
    this.u = null;
    this.z = 0;
    this.A = 0;
    this.B = null;
    this.C = false;
    this.D = false;
    this.F = false;
  }
  
  void C() {
    if (this.u != null) {
      this.v = new l();
      this.v.a(this.u, new b(this), this);
      return;
    } 
    throw new IllegalStateException("Fragment has not been attached yet.");
  }
  
  public final boolean D() {
    boolean bool;
    if (this.u != null && this.m) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final boolean E() {
    return this.C;
  }
  
  boolean F() {
    d d1 = this.O;
    return (d1 == null) ? false : d1.s;
  }
  
  final boolean G() {
    boolean bool;
    if (this.s > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  boolean H() {
    d d1 = this.O;
    return (d1 == null) ? false : d1.q;
  }
  
  public final boolean I() {
    l l1 = this.t;
    return (l1 == null) ? false : l1.c();
  }
  
  void J() {
    l l1 = this.v;
    if (l1 != null)
      l1.r(); 
  }
  
  public void K() {
    boolean bool = true;
    this.I = true;
    g g = d();
    if (g == null || !g.isChangingConfigurations())
      bool = false; 
    p p1 = this.x;
    if (p1 != null && !bool)
      p1.a(); 
  }
  
  public void L() {}
  
  public void M() {
    this.I = true;
  }
  
  public void N() {
    this.I = true;
  }
  
  public void O() {
    this.I = true;
  }
  
  public void P() {
    this.I = true;
  }
  
  public void Q() {
    this.I = true;
  }
  
  public void R() {
    this.I = true;
  }
  
  k S() {
    return this.v;
  }
  
  void T() {
    this.U.a(android.arch.lifecycle.c.a.ON_DESTROY);
    l l1 = this.v;
    if (l1 != null)
      l1.g(); 
    this.c = 0;
    this.I = false;
    this.T = false;
    K();
    if (this.I) {
      this.v = null;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDestroy()");
    throw new d0(stringBuilder.toString());
  }
  
  void U() {
    if (this.K != null)
      this.V.a(android.arch.lifecycle.c.a.ON_DESTROY); 
    l l1 = this.v;
    if (l1 != null)
      l1.h(); 
    this.c = 1;
    this.I = false;
    M();
    if (this.I) {
      u.<f>a(this).a();
      this.r = false;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDestroyView()");
    throw new d0(stringBuilder.toString());
  }
  
  void V() {
    this.I = false;
    N();
    this.S = null;
    if (this.I) {
      l l1 = this.v;
      if (l1 != null)
        if (this.F) {
          l1.g();
          this.v = null;
        } else {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Child FragmentManager of ");
          stringBuilder1.append(this);
          stringBuilder1.append(" was not ");
          stringBuilder1.append(" destroyed and this fragment is not retaining instance");
          throw new IllegalStateException(stringBuilder1.toString());
        }  
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDetach()");
    throw new d0(stringBuilder.toString());
  }
  
  void W() {
    onLowMemory();
    l l1 = this.v;
    if (l1 != null)
      l1.i(); 
  }
  
  void X() {
    if (this.K != null)
      this.V.a(android.arch.lifecycle.c.a.ON_PAUSE); 
    this.U.a(android.arch.lifecycle.c.a.ON_PAUSE);
    l l1 = this.v;
    if (l1 != null)
      l1.j(); 
    this.c = 3;
    this.I = false;
    O();
    if (this.I)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onPause()");
    throw new d0(stringBuilder.toString());
  }
  
  void Y() {
    l l1 = this.v;
    if (l1 != null) {
      l1.r();
      this.v.o();
    } 
    this.c = 4;
    this.I = false;
    P();
    if (this.I) {
      l1 = this.v;
      if (l1 != null) {
        l1.k();
        this.v.o();
      } 
      this.U.a(android.arch.lifecycle.c.a.ON_RESUME);
      if (this.K != null)
        this.V.a(android.arch.lifecycle.c.a.ON_RESUME); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onResume()");
    throw new d0(stringBuilder.toString());
  }
  
  void Z() {
    l l1 = this.v;
    if (l1 != null) {
      l1.r();
      this.v.o();
    } 
    this.c = 3;
    this.I = false;
    Q();
    if (this.I) {
      l1 = this.v;
      if (l1 != null)
        l1.l(); 
      this.U.a(android.arch.lifecycle.c.a.ON_START);
      if (this.K != null)
        this.V.a(android.arch.lifecycle.c.a.ON_START); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onStart()");
    throw new d0(stringBuilder.toString());
  }
  
  public android.arch.lifecycle.c a() {
    return (android.arch.lifecycle.c)this.U;
  }
  
  f a(String paramString) {
    if (paramString.equals(this.h))
      return this; 
    l l1 = this.v;
    return (l1 != null) ? l1.b(paramString) : null;
  }
  
  @Deprecated
  public LayoutInflater a(Bundle paramBundle) {
    j j1 = this.u;
    if (j1 != null) {
      LayoutInflater layoutInflater = j1.f();
      j();
      l l1 = this.v;
      l1.p();
      android.support.v4.view.f.b(layoutInflater, l1);
      return layoutInflater;
    } 
    throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
  }
  
  public View a(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    return null;
  }
  
  public Animation a(int paramInt1, boolean paramBoolean, int paramInt2) {
    return null;
  }
  
  void a(int paramInt1, int paramInt2) {
    if (this.O == null && paramInt1 == 0 && paramInt2 == 0)
      return; 
    d0();
    d d1 = this.O;
    d1.e = paramInt1;
    d1.f = paramInt2;
  }
  
  public void a(int paramInt1, int paramInt2, Intent paramIntent) {}
  
  final void a(int paramInt, f paramf) {
    this.g = paramInt;
    if (paramf != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramf.h);
      stringBuilder.append(":");
      stringBuilder.append(this.g);
      this.h = stringBuilder.toString();
    } else {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("android:fragment:");
      stringBuilder.append(this.g);
      this.h = stringBuilder.toString();
    } 
  }
  
  public void a(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {}
  
  void a(Animator paramAnimator) {
    (d0()).b = paramAnimator;
  }
  
  @Deprecated
  public void a(Activity paramActivity) {
    this.I = true;
  }
  
  @Deprecated
  public void a(Activity paramActivity, AttributeSet paramAttributeSet, Bundle paramBundle) {
    this.I = true;
  }
  
  public void a(Context paramContext) {
    Activity activity;
    this.I = true;
    j j1 = this.u;
    if (j1 == null) {
      j1 = null;
    } else {
      activity = j1.b();
    } 
    if (activity != null) {
      this.I = false;
      a(activity);
    } 
  }
  
  public void a(Context paramContext, AttributeSet paramAttributeSet, Bundle paramBundle) {
    Activity activity;
    this.I = true;
    j j1 = this.u;
    if (j1 == null) {
      j1 = null;
    } else {
      activity = j1.b();
    } 
    if (activity != null) {
      this.I = false;
      a(activity, paramAttributeSet, paramBundle);
    } 
  }
  
  public void a(Intent paramIntent) {
    a(paramIntent, (Bundle)null);
  }
  
  public void a(Intent paramIntent, int paramInt) {
    a(paramIntent, paramInt, (Bundle)null);
  }
  
  public void a(Intent paramIntent, int paramInt, Bundle paramBundle) {
    j j1 = this.u;
    if (j1 != null) {
      j1.a(this, paramIntent, paramInt, paramBundle);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to Activity");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void a(Intent paramIntent, Bundle paramBundle) {
    j j1 = this.u;
    if (j1 != null) {
      j1.a(this, paramIntent, -1, paramBundle);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to Activity");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  void a(Configuration paramConfiguration) {
    onConfigurationChanged(paramConfiguration);
    l l1 = this.v;
    if (l1 != null)
      l1.a(paramConfiguration); 
  }
  
  void a(f paramf) {
    d0();
    f f1 = this.O.r;
    if (paramf == f1)
      return; 
    if (paramf == null || f1 == null) {
      d d1 = this.O;
      if (d1.q)
        d1.r = paramf; 
      if (paramf != null)
        paramf.b(); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Trying to set a replacement startPostponedEnterTransition on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void a(g paramg) {
    if (this.g < 0) {
      if (paramg != null) {
        Bundle bundle = paramg.c;
        if (bundle != null) {
          this.d = bundle;
          return;
        } 
      } 
      paramg = null;
    } else {
      throw new IllegalStateException("Fragment already active");
    } 
    this.d = (Bundle)paramg;
  }
  
  public void a(f paramf) {}
  
  public void a(Menu paramMenu) {}
  
  public void a(Menu paramMenu, MenuInflater paramMenuInflater) {}
  
  void a(View paramView) {
    (d0()).a = paramView;
  }
  
  public void a(View paramView, Bundle paramBundle) {}
  
  public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mFragmentId=#");
    paramPrintWriter.print(Integer.toHexString(this.z));
    paramPrintWriter.print(" mContainerId=#");
    paramPrintWriter.print(Integer.toHexString(this.A));
    paramPrintWriter.print(" mTag=");
    paramPrintWriter.println(this.B);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mState=");
    paramPrintWriter.print(this.c);
    paramPrintWriter.print(" mIndex=");
    paramPrintWriter.print(this.g);
    paramPrintWriter.print(" mWho=");
    paramPrintWriter.print(this.h);
    paramPrintWriter.print(" mBackStackNesting=");
    paramPrintWriter.println(this.s);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mAdded=");
    paramPrintWriter.print(this.m);
    paramPrintWriter.print(" mRemoving=");
    paramPrintWriter.print(this.n);
    paramPrintWriter.print(" mFromLayout=");
    paramPrintWriter.print(this.o);
    paramPrintWriter.print(" mInLayout=");
    paramPrintWriter.println(this.p);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mHidden=");
    paramPrintWriter.print(this.C);
    paramPrintWriter.print(" mDetached=");
    paramPrintWriter.print(this.D);
    paramPrintWriter.print(" mMenuVisible=");
    paramPrintWriter.print(this.H);
    paramPrintWriter.print(" mHasMenu=");
    paramPrintWriter.println(this.G);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mRetainInstance=");
    paramPrintWriter.print(this.E);
    paramPrintWriter.print(" mRetaining=");
    paramPrintWriter.print(this.F);
    paramPrintWriter.print(" mUserVisibleHint=");
    paramPrintWriter.println(this.N);
    if (this.t != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mFragmentManager=");
      paramPrintWriter.println(this.t);
    } 
    if (this.u != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mHost=");
      paramPrintWriter.println(this.u);
    } 
    if (this.y != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mParentFragment=");
      paramPrintWriter.println(this.y);
    } 
    if (this.i != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mArguments=");
      paramPrintWriter.println(this.i);
    } 
    if (this.d != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedFragmentState=");
      paramPrintWriter.println(this.d);
    } 
    if (this.e != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedViewState=");
      paramPrintWriter.println(this.e);
    } 
    if (this.j != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mTarget=");
      paramPrintWriter.print(this.j);
      paramPrintWriter.print(" mTargetRequestCode=");
      paramPrintWriter.println(this.l);
    } 
    if (q() != 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mNextAnim=");
      paramPrintWriter.println(q());
    } 
    if (this.J != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mContainer=");
      paramPrintWriter.println(this.J);
    } 
    if (this.K != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mView=");
      paramPrintWriter.println(this.K);
    } 
    if (this.L != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mInnerView=");
      paramPrintWriter.println(this.K);
    } 
    if (g() != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mAnimatingAway=");
      paramPrintWriter.println(g());
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mStateAfterAnimating=");
      paramPrintWriter.println(z());
    } 
    if (k() != null)
      u.<f>a(this).a(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString); 
    if (this.v != null) {
      paramPrintWriter.print(paramString);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Child ");
      stringBuilder.append(this.v);
      stringBuilder.append(":");
      paramPrintWriter.println(stringBuilder.toString());
      l l1 = this.v;
      stringBuilder = new StringBuilder();
      stringBuilder.append(paramString);
      stringBuilder.append("  ");
      l1.a(stringBuilder.toString(), paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    } 
  }
  
  public void a(boolean paramBoolean) {}
  
  public boolean a(MenuItem paramMenuItem) {
    return false;
  }
  
  void a0() {
    if (this.K != null)
      this.V.a(android.arch.lifecycle.c.a.ON_STOP); 
    this.U.a(android.arch.lifecycle.c.a.ON_STOP);
    l l1 = this.v;
    if (l1 != null)
      l1.m(); 
    this.c = 2;
    this.I = false;
    R();
    if (this.I)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onStop()");
    throw new d0(stringBuilder.toString());
  }
  
  public Animator b(int paramInt1, boolean paramBoolean, int paramInt2) {
    return null;
  }
  
  public p b() {
    if (k() != null) {
      if (this.x == null)
        this.x = new p(); 
      return this.x;
    } 
    throw new IllegalStateException("Can't access ViewModels from detached fragment");
  }
  
  public void b(Bundle paramBundle) {
    this.I = true;
  }
  
  void b(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    l l1 = this.v;
    if (l1 != null)
      l1.r(); 
    this.r = true;
    this.W = new c(this);
    this.V = null;
    this.K = a(paramLayoutInflater, paramViewGroup, paramBundle);
    if (this.K != null) {
      this.W.a();
      this.X.a(this.W);
    } else {
      if (this.V == null) {
        this.W = null;
        return;
      } 
      throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
    } 
  }
  
  public void b(Menu paramMenu) {}
  
  public void b(boolean paramBoolean) {}
  
  boolean b(Menu paramMenu, MenuInflater paramMenuInflater) {
    boolean bool1 = false;
    boolean bool2 = false;
    if (!this.C) {
      boolean bool = bool2;
      if (this.G) {
        bool = bool2;
        if (this.H) {
          bool = true;
          a(paramMenu, paramMenuInflater);
        } 
      } 
      l l1 = this.v;
      bool1 = bool;
      if (l1 != null)
        bool1 = bool | l1.a(paramMenu, paramMenuInflater); 
    } 
    return bool1;
  }
  
  public boolean b(MenuItem paramMenuItem) {
    return false;
  }
  
  public final Context b0() {
    Context context = k();
    if (context != null)
      return context; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to a context.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  void c() {
    f f1;
    d d1 = this.O;
    if (d1 == null) {
      f1 = null;
    } else {
      d1.q = false;
      f1 = d1.r;
      d1.r = null;
    } 
    if (f1 != null)
      f1.a(); 
  }
  
  void c(int paramInt) {
    if (this.O == null && paramInt == 0)
      return; 
    (d0()).d = paramInt;
  }
  
  public void c(Bundle paramBundle) {
    this.I = true;
    k(paramBundle);
    l l1 = this.v;
    if (l1 != null && !l1.c(1))
      this.v.f(); 
  }
  
  void c(Menu paramMenu) {
    if (!this.C) {
      if (this.G && this.H)
        a(paramMenu); 
      l l1 = this.v;
      if (l1 != null)
        l1.a(paramMenu); 
    } 
  }
  
  public void c(boolean paramBoolean) {}
  
  boolean c(MenuItem paramMenuItem) {
    if (!this.C) {
      if (a(paramMenuItem))
        return true; 
      l l1 = this.v;
      if (l1 != null && l1.a(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void c0() {
    l l1 = this.t;
    if (l1 == null || l1.o == null) {
      (d0()).q = false;
      return;
    } 
    if (Looper.myLooper() != this.t.o.e().getLooper()) {
      this.t.o.e().postAtFrontOfQueue(new a(this));
    } else {
      c();
    } 
  }
  
  public final g d() {
    g g;
    j j1 = this.u;
    if (j1 == null) {
      j1 = null;
    } else {
      g = (g)j1.b();
    } 
    return g;
  }
  
  public LayoutInflater d(Bundle paramBundle) {
    return a(paramBundle);
  }
  
  void d(int paramInt) {
    (d0()).c = paramInt;
  }
  
  void d(boolean paramBoolean) {
    b(paramBoolean);
    l l1 = this.v;
    if (l1 != null)
      l1.a(paramBoolean); 
  }
  
  boolean d(Menu paramMenu) {
    boolean bool1 = false;
    boolean bool2 = false;
    if (!this.C) {
      boolean bool = bool2;
      if (this.G) {
        bool = bool2;
        if (this.H) {
          bool = true;
          b(paramMenu);
        } 
      } 
      l l1 = this.v;
      bool1 = bool;
      if (l1 != null)
        bool1 = bool | l1.b(paramMenu); 
    } 
    return bool1;
  }
  
  boolean d(MenuItem paramMenuItem) {
    if (!this.C) {
      if (this.G && this.H && b(paramMenuItem))
        return true; 
      l l1 = this.v;
      if (l1 != null && l1.b(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void e(Bundle paramBundle) {}
  
  void e(boolean paramBoolean) {
    c(paramBoolean);
    l l1 = this.v;
    if (l1 != null)
      l1.b(paramBoolean); 
  }
  
  public boolean e() {
    d d1 = this.O;
    if (d1 != null) {
      Boolean bool = d1.n;
      return (bool == null) ? true : bool.booleanValue();
    } 
    return true;
  }
  
  public final boolean equals(Object paramObject) {
    return super.equals(paramObject);
  }
  
  public void f(Bundle paramBundle) {
    this.I = true;
  }
  
  void f(boolean paramBoolean) {
    (d0()).s = paramBoolean;
  }
  
  public boolean f() {
    d d1 = this.O;
    if (d1 != null) {
      Boolean bool = d1.m;
      return (bool == null) ? true : bool.booleanValue();
    } 
    return true;
  }
  
  View g() {
    d d1 = this.O;
    return (d1 == null) ? null : d1.a;
  }
  
  void g(Bundle paramBundle) {
    l l1 = this.v;
    if (l1 != null)
      l1.r(); 
    this.c = 2;
    this.I = false;
    b(paramBundle);
    if (this.I) {
      l l2 = this.v;
      if (l2 != null)
        l2.e(); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onActivityCreated()");
    throw new d0(stringBuilder.toString());
  }
  
  public void g(boolean paramBoolean) {
    if (this.H != paramBoolean) {
      this.H = paramBoolean;
      if (this.G && D() && !E())
        this.u.i(); 
    } 
  }
  
  Animator h() {
    d d1 = this.O;
    return (d1 == null) ? null : d1.b;
  }
  
  void h(Bundle paramBundle) {
    l l1 = this.v;
    if (l1 != null)
      l1.r(); 
    this.c = 1;
    this.I = false;
    c(paramBundle);
    this.T = true;
    if (this.I) {
      this.U.a(android.arch.lifecycle.c.a.ON_CREATE);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onCreate()");
    throw new d0(stringBuilder.toString());
  }
  
  public void h(boolean paramBoolean) {
    boolean bool;
    if (!this.N && paramBoolean && this.c < 3 && this.t != null && D() && this.T)
      this.t.k(this); 
    this.N = paramBoolean;
    if (this.c < 3 && !paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    this.M = bool;
    if (this.d != null)
      this.f = Boolean.valueOf(paramBoolean); 
  }
  
  public final int hashCode() {
    return super.hashCode();
  }
  
  public final Bundle i() {
    return this.i;
  }
  
  LayoutInflater i(Bundle paramBundle) {
    this.S = d(paramBundle);
    return this.S;
  }
  
  public final k j() {
    if (this.v == null) {
      C();
      int i = this.c;
      if (i >= 4) {
        this.v.k();
      } else if (i >= 3) {
        this.v.l();
      } else if (i >= 2) {
        this.v.e();
      } else if (i >= 1) {
        this.v.f();
      } 
    } 
    return this.v;
  }
  
  void j(Bundle paramBundle) {
    e(paramBundle);
    l l1 = this.v;
    if (l1 != null) {
      Parcelable parcelable = l1.u();
      if (parcelable != null)
        paramBundle.putParcelable("android:support:fragments", parcelable); 
    } 
  }
  
  public Context k() {
    Context context;
    j j1 = this.u;
    if (j1 == null) {
      j1 = null;
    } else {
      context = j1.c();
    } 
    return context;
  }
  
  void k(Bundle paramBundle) {
    if (paramBundle != null) {
      Parcelable parcelable = paramBundle.getParcelable("android:support:fragments");
      if (parcelable != null) {
        if (this.v == null)
          C(); 
        this.v.a(parcelable, this.w);
        this.w = null;
        this.v.f();
      } 
    } 
  }
  
  public Object l() {
    d d1 = this.O;
    return (d1 == null) ? null : d1.g;
  }
  
  final void l(Bundle paramBundle) {
    SparseArray<Parcelable> sparseArray = this.e;
    if (sparseArray != null) {
      this.L.restoreHierarchyState(sparseArray);
      this.e = null;
    } 
    this.I = false;
    f(paramBundle);
    if (this.I) {
      if (this.K != null)
        this.V.a(android.arch.lifecycle.c.a.ON_CREATE); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onViewStateRestored()");
    throw new d0(stringBuilder.toString());
  }
  
  c0 m() {
    d d1 = this.O;
    return (d1 == null) ? null : d1.o;
  }
  
  public void m(Bundle paramBundle) {
    if (this.g < 0 || !I()) {
      this.i = paramBundle;
      return;
    } 
    throw new IllegalStateException("Fragment already active and state has been saved");
  }
  
  public Object n() {
    d d1 = this.O;
    return (d1 == null) ? null : d1.i;
  }
  
  c0 o() {
    d d1 = this.O;
    return (d1 == null) ? null : d1.p;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    this.I = true;
  }
  
  public void onCreateContextMenu(ContextMenu paramContextMenu, View paramView, ContextMenu.ContextMenuInfo paramContextMenuInfo) {
    d().onCreateContextMenu(paramContextMenu, paramView, paramContextMenuInfo);
  }
  
  public void onLowMemory() {
    this.I = true;
  }
  
  public final k p() {
    return this.t;
  }
  
  int q() {
    d d1 = this.O;
    return (d1 == null) ? 0 : d1.d;
  }
  
  int r() {
    d d1 = this.O;
    return (d1 == null) ? 0 : d1.e;
  }
  
  int s() {
    d d1 = this.O;
    return (d1 == null) ? 0 : d1.f;
  }
  
  public final f t() {
    return this.y;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    a.b.g.g.d.a(this, stringBuilder);
    if (this.g >= 0) {
      stringBuilder.append(" #");
      stringBuilder.append(this.g);
    } 
    if (this.z != 0) {
      stringBuilder.append(" id=0x");
      stringBuilder.append(Integer.toHexString(this.z));
    } 
    if (this.B != null) {
      stringBuilder.append(" ");
      stringBuilder.append(this.B);
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public Object u() {
    d d1 = this.O;
    if (d1 == null)
      return null; 
    Object object2 = d1.j;
    Object object1 = object2;
    if (object2 == Z)
      object1 = n(); 
    return object1;
  }
  
  public final Resources v() {
    return b0().getResources();
  }
  
  public Object w() {
    d d1 = this.O;
    if (d1 == null)
      return null; 
    Object object2 = d1.h;
    Object object1 = object2;
    if (object2 == Z)
      object1 = l(); 
    return object1;
  }
  
  public Object x() {
    d d1 = this.O;
    return (d1 == null) ? null : d1.k;
  }
  
  public Object y() {
    d d1 = this.O;
    if (d1 == null)
      return null; 
    Object object = d1.l;
    if (object == Z)
      object = x(); 
    return object;
  }
  
  int z() {
    d d1 = this.O;
    return (d1 == null) ? 0 : d1.c;
  }
  
  class a implements Runnable {
    final f c;
    
    a(f this$0) {}
    
    public void run() {
      this.c.c();
    }
  }
  
  class b extends h {
    final f a;
    
    b(f this$0) {}
    
    public f a(Context param1Context, String param1String, Bundle param1Bundle) {
      return this.a.u.a(param1Context, param1String, param1Bundle);
    }
    
    public View a(int param1Int) {
      View view = this.a.K;
      if (view != null)
        return view.findViewById(param1Int); 
      throw new IllegalStateException("Fragment does not have a view");
    }
    
    public boolean a() {
      boolean bool;
      if (this.a.K != null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
  }
  
  class c implements e {
    final f c;
    
    c(f this$0) {}
    
    public android.arch.lifecycle.c a() {
      f f1 = this.c;
      if (f1.V == null)
        f1.V = new android.arch.lifecycle.f(f1.W); 
      return (android.arch.lifecycle.c)this.c.V;
    }
  }
  
  static class d {
    View a;
    
    Animator b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    Object g = null;
    
    Object h;
    
    Object i;
    
    Object j;
    
    Object k;
    
    Object l;
    
    Boolean m;
    
    Boolean n;
    
    c0 o;
    
    c0 p;
    
    boolean q;
    
    f.f r;
    
    boolean s;
    
    d() {
      Object object = f.Z;
      this.h = object;
      this.i = null;
      this.j = object;
      this.k = null;
      this.l = object;
      this.o = null;
      this.p = null;
    }
  }
  
  public static class e extends RuntimeException {
    public e(String param1String, Exception param1Exception) {
      super(param1String, param1Exception);
    }
  }
  
  static interface f {
    void a();
    
    void b();
  }
  
  public static class g implements Parcelable {
    public static final Parcelable.Creator<g> CREATOR = (Parcelable.Creator<g>)new a();
    
    final Bundle c;
    
    g(Bundle param1Bundle) {
      this.c = param1Bundle;
    }
    
    g(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      this.c = param1Parcel.readBundle();
      if (param1ClassLoader != null) {
        Bundle bundle = this.c;
        if (bundle != null)
          bundle.setClassLoader(param1ClassLoader); 
      } 
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeBundle(this.c);
    }
    
    static final class a implements Parcelable.ClassLoaderCreator<g> {
      public f.g createFromParcel(Parcel param2Parcel) {
        return new f.g(param2Parcel, null);
      }
      
      public f.g createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new f.g(param2Parcel, param2ClassLoader);
      }
      
      public f.g[] newArray(int param2Int) {
        return new f.g[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.ClassLoaderCreator<g> {
    public f.g createFromParcel(Parcel param1Parcel) {
      return new f.g(param1Parcel, null);
    }
    
    public f.g createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new f.g(param1Parcel, param1ClassLoader);
    }
    
    public f.g[] newArray(int param1Int) {
      return new f.g[param1Int];
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */