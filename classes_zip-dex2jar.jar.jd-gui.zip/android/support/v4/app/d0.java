package android.support.v4.app;

import android.util.AndroidRuntimeException;

final class d0 extends AndroidRuntimeException {
  public d0(String paramString) {
    super(paramString);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */