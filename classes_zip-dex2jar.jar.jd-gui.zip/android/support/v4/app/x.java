package android.support.v4.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.widget.RemoteViews;
import java.util.ArrayList;

public class x {
  public static Bundle a(Notification paramNotification) {
    int i = Build.VERSION.SDK_INT;
    return (i >= 19) ? paramNotification.extras : ((i >= 16) ? z.a(paramNotification) : null);
  }
  
  public static class a {
    final Bundle a;
    
    private final b0[] b;
    
    private final b0[] c;
    
    private boolean d;
    
    boolean e;
    
    private final int f;
    
    public int g;
    
    public CharSequence h;
    
    public PendingIntent i;
    
    public PendingIntent a() {
      return this.i;
    }
    
    public boolean b() {
      return this.d;
    }
    
    public b0[] c() {
      return this.c;
    }
    
    public Bundle d() {
      return this.a;
    }
    
    public int e() {
      return this.g;
    }
    
    public b0[] f() {
      return this.b;
    }
    
    public int g() {
      return this.f;
    }
    
    public boolean h() {
      return this.e;
    }
    
    public CharSequence i() {
      return this.h;
    }
  }
  
  public static class b extends d {
    private CharSequence e;
    
    public b a(CharSequence param1CharSequence) {
      this.e = x.c.c(param1CharSequence);
      return this;
    }
    
    public void a(w param1w) {
      if (Build.VERSION.SDK_INT >= 16) {
        Notification.BigTextStyle bigTextStyle = (new Notification.BigTextStyle(param1w.a())).setBigContentTitle(this.b).bigText(this.e);
        if (this.d)
          bigTextStyle.setSummaryText(this.c); 
      } 
    }
  }
  
  public static class c {
    String A;
    
    Bundle B;
    
    int C = 0;
    
    int D = 0;
    
    Notification E;
    
    RemoteViews F;
    
    RemoteViews G;
    
    RemoteViews H;
    
    String I;
    
    int J = 0;
    
    String K;
    
    long L;
    
    int M = 0;
    
    Notification N = new Notification();
    
    @Deprecated
    public ArrayList<String> O;
    
    public Context a;
    
    public ArrayList<x.a> b = new ArrayList<x.a>();
    
    ArrayList<x.a> c = new ArrayList<x.a>();
    
    CharSequence d;
    
    CharSequence e;
    
    PendingIntent f;
    
    PendingIntent g;
    
    RemoteViews h;
    
    Bitmap i;
    
    CharSequence j;
    
    int k;
    
    int l;
    
    boolean m = true;
    
    boolean n;
    
    x.d o;
    
    CharSequence p;
    
    CharSequence[] q;
    
    int r;
    
    int s;
    
    boolean t;
    
    String u;
    
    boolean v;
    
    String w;
    
    boolean x = false;
    
    boolean y;
    
    boolean z;
    
    public c(Context param1Context, String param1String) {
      this.a = param1Context;
      this.I = param1String;
      this.N.when = System.currentTimeMillis();
      this.N.audioStreamType = -1;
      this.l = 0;
      this.O = new ArrayList<String>();
    }
    
    private Bitmap b(Bitmap param1Bitmap) {
      if (param1Bitmap == null || Build.VERSION.SDK_INT >= 27)
        return param1Bitmap; 
      Resources resources = this.a.getResources();
      int j = resources.getDimensionPixelSize(a.b.a.b.compat_notification_large_icon_max_width);
      int i = resources.getDimensionPixelSize(a.b.a.b.compat_notification_large_icon_max_height);
      if (param1Bitmap.getWidth() <= j && param1Bitmap.getHeight() <= i)
        return param1Bitmap; 
      double d1 = j;
      double d2 = Math.max(1, param1Bitmap.getWidth());
      Double.isNaN(d1);
      Double.isNaN(d2);
      d2 = d1 / d2;
      double d3 = i;
      d1 = Math.max(1, param1Bitmap.getHeight());
      Double.isNaN(d3);
      Double.isNaN(d1);
      d1 = Math.min(d2, d3 / d1);
      d2 = param1Bitmap.getWidth();
      Double.isNaN(d2);
      i = (int)Math.ceil(d2 * d1);
      d2 = param1Bitmap.getHeight();
      Double.isNaN(d2);
      return Bitmap.createScaledBitmap(param1Bitmap, i, (int)Math.ceil(d2 * d1), true);
    }
    
    protected static CharSequence c(CharSequence param1CharSequence) {
      if (param1CharSequence == null)
        return param1CharSequence; 
      CharSequence charSequence = param1CharSequence;
      if (param1CharSequence.length() > 5120)
        charSequence = param1CharSequence.subSequence(0, 5120); 
      return charSequence;
    }
    
    public Notification a() {
      return (new y(this)).b();
    }
    
    public c a(int param1Int) {
      Notification notification = this.N;
      notification.defaults = param1Int;
      if ((param1Int & 0x4) != 0)
        notification.flags |= 0x1; 
      return this;
    }
    
    public c a(long param1Long) {
      this.N.when = param1Long;
      return this;
    }
    
    public c a(PendingIntent param1PendingIntent) {
      this.f = param1PendingIntent;
      return this;
    }
    
    public c a(Bitmap param1Bitmap) {
      this.i = b(param1Bitmap);
      return this;
    }
    
    public c a(x.d param1d) {
      if (this.o != param1d) {
        this.o = param1d;
        param1d = this.o;
        if (param1d != null)
          param1d.a(this); 
      } 
      return this;
    }
    
    public c a(CharSequence param1CharSequence) {
      this.e = c(param1CharSequence);
      return this;
    }
    
    public Bundle b() {
      if (this.B == null)
        this.B = new Bundle(); 
      return this.B;
    }
    
    public c b(int param1Int) {
      this.l = param1Int;
      return this;
    }
    
    public c b(CharSequence param1CharSequence) {
      this.d = c(param1CharSequence);
      return this;
    }
    
    public c c(int param1Int) {
      this.N.icon = param1Int;
      return this;
    }
  }
  
  public static abstract class d {
    protected x.c a;
    
    CharSequence b;
    
    CharSequence c;
    
    boolean d = false;
    
    public void a(Bundle param1Bundle) {}
    
    public abstract void a(w param1w);
    
    public void a(x.c param1c) {
      if (this.a != param1c) {
        this.a = param1c;
        param1c = this.a;
        if (param1c != null)
          param1c.a(this); 
      } 
    }
    
    public RemoteViews b(w param1w) {
      return null;
    }
    
    public RemoteViews c(w param1w) {
      return null;
    }
    
    public RemoteViews d(w param1w) {
      return null;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */