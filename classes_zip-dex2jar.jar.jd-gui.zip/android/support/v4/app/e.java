package android.support.v4.app;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

public class e extends f implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
  int a0 = 0;
  
  int b0 = 0;
  
  boolean c0 = true;
  
  boolean d0 = true;
  
  int e0 = -1;
  
  Dialog f0;
  
  boolean g0;
  
  boolean h0;
  
  boolean i0;
  
  public void M() {
    super.M();
    Dialog dialog = this.f0;
    if (dialog != null) {
      this.g0 = true;
      dialog.dismiss();
      this.f0 = null;
    } 
  }
  
  public void N() {
    super.N();
    if (!this.i0 && !this.h0)
      this.h0 = true; 
  }
  
  public void Q() {
    super.Q();
    Dialog dialog = this.f0;
    if (dialog != null) {
      this.g0 = false;
      dialog.show();
    } 
  }
  
  public void R() {
    super.R();
    Dialog dialog = this.f0;
    if (dialog != null)
      dialog.hide(); 
  }
  
  public void a(Dialog paramDialog, int paramInt) {
    if (paramInt != 1 && paramInt != 2) {
      if (paramInt != 3)
        return; 
      paramDialog.getWindow().addFlags(24);
    } 
    paramDialog.requestWindowFeature(1);
  }
  
  public void a(Context paramContext) {
    super.a(paramContext);
    if (!this.i0)
      this.h0 = false; 
  }
  
  public void a(k paramk, String paramString) {
    this.h0 = false;
    this.i0 = true;
    q q = paramk.a();
    q.a(this, paramString);
    q.a();
  }
  
  public void b(Bundle paramBundle) {
    super.b(paramBundle);
    if (!this.d0)
      return; 
    View view = A();
    if (view != null)
      if (view.getParent() == null) {
        this.f0.setContentView(view);
      } else {
        throw new IllegalStateException("DialogFragment can not be attached to a container view");
      }  
    g g = d();
    if (g != null)
      this.f0.setOwnerActivity(g); 
    this.f0.setCancelable(this.c0);
    this.f0.setOnCancelListener(this);
    this.f0.setOnDismissListener(this);
    if (paramBundle != null) {
      paramBundle = paramBundle.getBundle("android:savedDialogState");
      if (paramBundle != null)
        this.f0.onRestoreInstanceState(paramBundle); 
    } 
  }
  
  public void c(Bundle paramBundle) {
    boolean bool;
    super.c(paramBundle);
    if (this.A == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.d0 = bool;
    if (paramBundle != null) {
      this.a0 = paramBundle.getInt("android:style", 0);
      this.b0 = paramBundle.getInt("android:theme", 0);
      this.c0 = paramBundle.getBoolean("android:cancelable", true);
      this.d0 = paramBundle.getBoolean("android:showsDialog", this.d0);
      this.e0 = paramBundle.getInt("android:backStackId", -1);
    } 
  }
  
  public LayoutInflater d(Bundle paramBundle) {
    if (!this.d0)
      return super.d(paramBundle); 
    this.f0 = n(paramBundle);
    Dialog dialog = this.f0;
    if (dialog != null) {
      a(dialog, this.a0);
      return (LayoutInflater)this.f0.getContext().getSystemService("layout_inflater");
    } 
    return (LayoutInflater)this.u.c().getSystemService("layout_inflater");
  }
  
  public void d0() {
    i(false);
  }
  
  public void e(Bundle paramBundle) {
    super.e(paramBundle);
    Dialog dialog = this.f0;
    if (dialog != null) {
      Bundle bundle = dialog.onSaveInstanceState();
      if (bundle != null)
        paramBundle.putBundle("android:savedDialogState", bundle); 
    } 
    int i = this.a0;
    if (i != 0)
      paramBundle.putInt("android:style", i); 
    i = this.b0;
    if (i != 0)
      paramBundle.putInt("android:theme", i); 
    boolean bool = this.c0;
    if (!bool)
      paramBundle.putBoolean("android:cancelable", bool); 
    bool = this.d0;
    if (!bool)
      paramBundle.putBoolean("android:showsDialog", bool); 
    i = this.e0;
    if (i != -1)
      paramBundle.putInt("android:backStackId", i); 
  }
  
  public Dialog e0() {
    return this.f0;
  }
  
  public int f0() {
    return this.b0;
  }
  
  void i(boolean paramBoolean) {
    if (this.h0)
      return; 
    this.h0 = true;
    this.i0 = false;
    Dialog dialog = this.f0;
    if (dialog != null)
      dialog.dismiss(); 
    this.g0 = true;
    if (this.e0 >= 0) {
      p().a(this.e0, 1);
      this.e0 = -1;
    } else {
      q q = p().a();
      q.a(this);
      if (paramBoolean) {
        q.b();
      } else {
        q.a();
      } 
    } 
  }
  
  public Dialog n(Bundle paramBundle) {
    return new Dialog((Context)d(), f0());
  }
  
  public void onCancel(DialogInterface paramDialogInterface) {}
  
  public void onDismiss(DialogInterface paramDialogInterface) {
    if (!this.g0)
      i(true); 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */