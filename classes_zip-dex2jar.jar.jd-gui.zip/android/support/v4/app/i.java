package android.support.v4.app;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

public class i {
  private final j<?> a;
  
  private i(j<?> paramj) {
    this.a = paramj;
  }
  
  public static i a(j<?> paramj) {
    return new i(paramj);
  }
  
  public f a(String paramString) {
    return this.a.d.b(paramString);
  }
  
  public View a(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return this.a.d.onCreateView(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public void a() {
    this.a.d.e();
  }
  
  public void a(Configuration paramConfiguration) {
    this.a.d.a(paramConfiguration);
  }
  
  public void a(Parcelable paramParcelable, m paramm) {
    this.a.d.a(paramParcelable, paramm);
  }
  
  public void a(f paramf) {
    j<?> j1 = this.a;
    j1.d.a(j1, j1, paramf);
  }
  
  public void a(Menu paramMenu) {
    this.a.d.a(paramMenu);
  }
  
  public void a(boolean paramBoolean) {
    this.a.d.a(paramBoolean);
  }
  
  public boolean a(Menu paramMenu, MenuInflater paramMenuInflater) {
    return this.a.d.a(paramMenu, paramMenuInflater);
  }
  
  public boolean a(MenuItem paramMenuItem) {
    return this.a.d.a(paramMenuItem);
  }
  
  public void b() {
    this.a.d.f();
  }
  
  public void b(boolean paramBoolean) {
    this.a.d.b(paramBoolean);
  }
  
  public boolean b(Menu paramMenu) {
    return this.a.d.b(paramMenu);
  }
  
  public boolean b(MenuItem paramMenuItem) {
    return this.a.d.b(paramMenuItem);
  }
  
  public void c() {
    this.a.d.g();
  }
  
  public void d() {
    this.a.d.i();
  }
  
  public void e() {
    this.a.d.j();
  }
  
  public void f() {
    this.a.d.k();
  }
  
  public void g() {
    this.a.d.l();
  }
  
  public void h() {
    this.a.d.m();
  }
  
  public boolean i() {
    return this.a.d.o();
  }
  
  public k j() {
    return this.a.d();
  }
  
  public void k() {
    this.a.d.r();
  }
  
  public m l() {
    return this.a.d.t();
  }
  
  public Parcelable m() {
    return this.a.d.u();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */