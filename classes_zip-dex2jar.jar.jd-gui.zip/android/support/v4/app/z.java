package android.support.v4.app;

import android.app.Notification;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.util.SparseArray;
import java.lang.reflect.Field;
import java.util.List;

class z {
  private static final Object a = new Object();
  
  private static Field b;
  
  private static boolean c;
  
  static {
    new Object();
  }
  
  public static Bundle a(Notification.Builder paramBuilder, x.a parama) {
    paramBuilder.addAction(parama.e(), parama.i(), parama.a());
    Bundle bundle = new Bundle(parama.d());
    if (parama.f() != null)
      bundle.putParcelableArray("android.support.remoteInputs", (Parcelable[])a(parama.f())); 
    if (parama.c() != null)
      bundle.putParcelableArray("android.support.dataRemoteInputs", (Parcelable[])a(parama.c())); 
    bundle.putBoolean("android.support.allowGeneratedReplies", parama.b());
    return bundle;
  }
  
  public static Bundle a(Notification paramNotification) {
    synchronized (a) {
      if (c)
        return null; 
      try {
        if (b == null) {
          Field field = Notification.class.getDeclaredField("extras");
          if (!Bundle.class.isAssignableFrom(field.getType())) {
            Log.e("NotificationCompat", "Notification.extras field is not of type Bundle");
            c = true;
            return null;
          } 
          field.setAccessible(true);
          b = field;
        } 
        Bundle bundle2 = (Bundle)b.get(paramNotification);
        Bundle bundle1 = bundle2;
        if (bundle2 == null) {
          bundle1 = new Bundle();
          this();
          b.set(paramNotification, bundle1);
        } 
        return bundle1;
      } catch (IllegalAccessException illegalAccessException) {
        Log.e("NotificationCompat", "Unable to access notification extras", illegalAccessException);
      } catch (NoSuchFieldException noSuchFieldException) {
        Log.e("NotificationCompat", "Unable to access notification extras", noSuchFieldException);
      } 
      c = true;
      return null;
    } 
  }
  
  private static Bundle a(b0 paramb0) {
    new Bundle();
    paramb0.a();
    throw null;
  }
  
  static Bundle a(x.a parama) {
    Bundle bundle1;
    Bundle bundle2 = new Bundle();
    bundle2.putInt("icon", parama.e());
    bundle2.putCharSequence("title", parama.i());
    bundle2.putParcelable("actionIntent", (Parcelable)parama.a());
    if (parama.d() != null) {
      bundle1 = new Bundle(parama.d());
    } else {
      bundle1 = new Bundle();
    } 
    bundle1.putBoolean("android.support.allowGeneratedReplies", parama.b());
    bundle2.putBundle("extras", bundle1);
    bundle2.putParcelableArray("remoteInputs", (Parcelable[])a(parama.f()));
    bundle2.putBoolean("showsUserInterface", parama.h());
    bundle2.putInt("semanticAction", parama.g());
    return bundle2;
  }
  
  public static SparseArray<Bundle> a(List<Bundle> paramList) {
    SparseArray<Bundle> sparseArray = null;
    byte b = 0;
    int i = paramList.size();
    while (b < i) {
      Bundle bundle = paramList.get(b);
      SparseArray<Bundle> sparseArray1 = sparseArray;
      if (bundle != null) {
        sparseArray1 = sparseArray;
        if (sparseArray == null)
          sparseArray1 = new SparseArray(); 
        sparseArray1.put(b, bundle);
      } 
      b++;
      sparseArray = sparseArray1;
    } 
    return sparseArray;
  }
  
  private static Bundle[] a(b0[] paramArrayOfb0) {
    if (paramArrayOfb0 == null)
      return null; 
    Bundle[] arrayOfBundle = new Bundle[paramArrayOfb0.length];
    if (paramArrayOfb0.length >= 0)
      return arrayOfBundle; 
    a(paramArrayOfb0[0]);
    throw null;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */