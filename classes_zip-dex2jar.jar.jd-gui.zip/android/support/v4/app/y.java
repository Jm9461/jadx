package android.support.v4.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.SparseArray;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class y implements w {
  private final Notification.Builder a;
  
  private final x.c b;
  
  private RemoteViews c;
  
  private RemoteViews d;
  
  private final List<Bundle> e;
  
  private final Bundle f;
  
  private int g;
  
  private RemoteViews h;
  
  y(x.c paramc) {
    boolean bool;
    this.e = new ArrayList<Bundle>();
    this.f = new Bundle();
    this.b = paramc;
    if (Build.VERSION.SDK_INT >= 26) {
      this.a = new Notification.Builder(paramc.a, paramc.I);
    } else {
      this.a = new Notification.Builder(paramc.a);
    } 
    Notification notification = paramc.N;
    Notification.Builder builder = this.a.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, paramc.h).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS);
    if ((notification.flags & 0x2) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOngoing(bool);
    if ((notification.flags & 0x8) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOnlyAlertOnce(bool);
    if ((notification.flags & 0x10) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setAutoCancel(bool).setDefaults(notification.defaults).setContentTitle(paramc.d).setContentText(paramc.e).setContentInfo(paramc.j).setContentIntent(paramc.f).setDeleteIntent(notification.deleteIntent);
    PendingIntent pendingIntent = paramc.g;
    if ((notification.flags & 0x80) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder.setFullScreenIntent(pendingIntent, bool).setLargeIcon(paramc.i).setNumber(paramc.k).setProgress(paramc.r, paramc.s, paramc.t);
    if (Build.VERSION.SDK_INT < 21)
      this.a.setSound(notification.sound, notification.audioStreamType); 
    if (Build.VERSION.SDK_INT >= 16) {
      this.a.setSubText(paramc.p).setUsesChronometer(paramc.n).setPriority(paramc.l);
      Iterator<x.a> iterator = paramc.b.iterator();
      while (iterator.hasNext())
        a(iterator.next()); 
      Bundle bundle = paramc.B;
      if (bundle != null)
        this.f.putAll(bundle); 
      if (Build.VERSION.SDK_INT < 20) {
        if (paramc.x)
          this.f.putBoolean("android.support.localOnly", true); 
        String str = paramc.u;
        if (str != null) {
          this.f.putString("android.support.groupKey", str);
          if (paramc.v) {
            this.f.putBoolean("android.support.isGroupSummary", true);
          } else {
            this.f.putBoolean("android.support.useSideChannel", true);
          } 
        } 
        str = paramc.w;
        if (str != null)
          this.f.putString("android.support.sortKey", str); 
      } 
      this.c = paramc.F;
      this.d = paramc.G;
    } 
    if (Build.VERSION.SDK_INT >= 19) {
      this.a.setShowWhen(paramc.m);
      if (Build.VERSION.SDK_INT < 21) {
        ArrayList<String> arrayList = paramc.O;
        if (arrayList != null && !arrayList.isEmpty()) {
          Bundle bundle = this.f;
          arrayList = paramc.O;
          bundle.putStringArray("android.people", arrayList.<String>toArray(new String[arrayList.size()]));
        } 
      } 
    } 
    if (Build.VERSION.SDK_INT >= 20) {
      this.a.setLocalOnly(paramc.x).setGroup(paramc.u).setGroupSummary(paramc.v).setSortKey(paramc.w);
      this.g = paramc.M;
    } 
    if (Build.VERSION.SDK_INT >= 21) {
      this.a.setCategory(paramc.A).setColor(paramc.C).setVisibility(paramc.D).setPublicVersion(paramc.E).setSound(notification.sound, notification.audioAttributes);
      for (String str : paramc.O)
        this.a.addPerson(str); 
      this.h = paramc.H;
      if (paramc.c.size() > 0) {
        Bundle bundle2 = paramc.b().getBundle("android.car.EXTENSIONS");
        Bundle bundle1 = bundle2;
        if (bundle2 == null)
          bundle1 = new Bundle(); 
        bundle2 = new Bundle();
        for (byte b = 0; b < paramc.c.size(); b++)
          bundle2.putBundle(Integer.toString(b), z.a(paramc.c.get(b))); 
        bundle1.putBundle("invisible_actions", bundle2);
        paramc.b().putBundle("android.car.EXTENSIONS", bundle1);
        this.f.putBundle("android.car.EXTENSIONS", bundle1);
      } 
    } 
    if (Build.VERSION.SDK_INT >= 24) {
      this.a.setExtras(paramc.B).setRemoteInputHistory(paramc.q);
      RemoteViews remoteViews = paramc.F;
      if (remoteViews != null)
        this.a.setCustomContentView(remoteViews); 
      remoteViews = paramc.G;
      if (remoteViews != null)
        this.a.setCustomBigContentView(remoteViews); 
      remoteViews = paramc.H;
      if (remoteViews != null)
        this.a.setCustomHeadsUpContentView(remoteViews); 
    } 
    if (Build.VERSION.SDK_INT >= 26) {
      this.a.setBadgeIconType(paramc.J).setShortcutId(paramc.K).setTimeoutAfter(paramc.L).setGroupAlertBehavior(paramc.M);
      if (paramc.z)
        this.a.setColorized(paramc.y); 
      if (!TextUtils.isEmpty(paramc.I))
        this.a.setSound(null).setDefaults(0).setLights(0, 0, 0).setVibrate(null); 
    } 
  }
  
  private void a(Notification paramNotification) {
    paramNotification.sound = null;
    paramNotification.vibrate = null;
    paramNotification.defaults &= 0xFFFFFFFE;
    paramNotification.defaults &= 0xFFFFFFFD;
  }
  
  private void a(x.a parama) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 20) {
      Bundle bundle;
      Notification.Action.Builder builder = new Notification.Action.Builder(parama.e(), parama.i(), parama.a());
      if (parama.f() != null) {
        RemoteInput[] arrayOfRemoteInput = b0.a(parama.f());
        int j = arrayOfRemoteInput.length;
        for (i = 0; i < j; i++)
          builder.addRemoteInput(arrayOfRemoteInput[i]); 
      } 
      if (parama.d() != null) {
        bundle = new Bundle(parama.d());
      } else {
        bundle = new Bundle();
      } 
      bundle.putBoolean("android.support.allowGeneratedReplies", parama.b());
      if (Build.VERSION.SDK_INT >= 24)
        builder.setAllowGeneratedReplies(parama.b()); 
      bundle.putInt("android.support.action.semanticAction", parama.g());
      if (Build.VERSION.SDK_INT >= 28)
        builder.setSemanticAction(parama.g()); 
      bundle.putBoolean("android.support.action.showsUserInterface", parama.h());
      builder.addExtras(bundle);
      this.a.addAction(builder.build());
    } else if (i >= 16) {
      this.e.add(z.a(this.a, parama));
    } 
  }
  
  public Notification.Builder a() {
    return this.a;
  }
  
  public Notification b() {
    RemoteViews remoteViews;
    x.d d = this.b.o;
    if (d != null)
      d.a(this); 
    if (d != null) {
      remoteViews = d.c(this);
    } else {
      remoteViews = null;
    } 
    Notification notification = c();
    if (remoteViews != null) {
      notification.contentView = remoteViews;
    } else {
      remoteViews = this.b.F;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
    } 
    if (Build.VERSION.SDK_INT >= 16 && d != null) {
      remoteViews = d.b(this);
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
    } 
    if (Build.VERSION.SDK_INT >= 21 && d != null) {
      remoteViews = this.b.o.d(this);
      if (remoteViews != null)
        notification.headsUpContentView = remoteViews; 
    } 
    if (Build.VERSION.SDK_INT >= 16 && d != null) {
      Bundle bundle = x.a(notification);
      if (bundle != null)
        d.a(bundle); 
    } 
    return notification;
  }
  
  protected Notification c() {
    int i = Build.VERSION.SDK_INT;
    if (i >= 26)
      return this.a.build(); 
    if (i >= 24) {
      Notification notification = this.a.build();
      if (this.g != 0) {
        if (notification.getGroup() != null && (notification.flags & 0x200) != 0 && this.g == 2)
          a(notification); 
        if (notification.getGroup() != null && (notification.flags & 0x200) == 0 && this.g == 1)
          a(notification); 
      } 
      return notification;
    } 
    if (i >= 21) {
      this.a.setExtras(this.f);
      Notification notification = this.a.build();
      RemoteViews remoteViews = this.c;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
      remoteViews = this.d;
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
      remoteViews = this.h;
      if (remoteViews != null)
        notification.headsUpContentView = remoteViews; 
      if (this.g != 0) {
        if (notification.getGroup() != null && (notification.flags & 0x200) != 0 && this.g == 2)
          a(notification); 
        if (notification.getGroup() != null && (notification.flags & 0x200) == 0 && this.g == 1)
          a(notification); 
      } 
      return notification;
    } 
    if (i >= 20) {
      this.a.setExtras(this.f);
      Notification notification = this.a.build();
      RemoteViews remoteViews = this.c;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
      remoteViews = this.d;
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
      if (this.g != 0) {
        if (notification.getGroup() != null && (notification.flags & 0x200) != 0 && this.g == 2)
          a(notification); 
        if (notification.getGroup() != null && (notification.flags & 0x200) == 0 && this.g == 1)
          a(notification); 
      } 
      return notification;
    } 
    if (i >= 19) {
      SparseArray<Bundle> sparseArray = z.a(this.e);
      if (sparseArray != null)
        this.f.putSparseParcelableArray("android.support.actionExtras", sparseArray); 
      this.a.setExtras(this.f);
      Notification notification = this.a.build();
      RemoteViews remoteViews = this.c;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
      remoteViews = this.d;
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
      return notification;
    } 
    if (i >= 16) {
      Notification notification = this.a.build();
      Bundle bundle1 = x.a(notification);
      Bundle bundle2 = new Bundle(this.f);
      for (String str : this.f.keySet()) {
        if (bundle1.containsKey(str))
          bundle2.remove(str); 
      } 
      bundle1.putAll(bundle2);
      SparseArray<Bundle> sparseArray = z.a(this.e);
      if (sparseArray != null)
        x.a(notification).putSparseParcelableArray("android.support.actionExtras", sparseArray); 
      RemoteViews remoteViews = this.c;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
      remoteViews = this.d;
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
      return notification;
    } 
    return this.a.getNotification();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */