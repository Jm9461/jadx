package android.support.design.widget;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

public class f extends Drawable {
  final Paint a = new Paint(1);
  
  final Rect b = new Rect();
  
  final RectF c = new RectF();
  
  final b d = new b(null);
  
  float e;
  
  private int f;
  
  private int g;
  
  private int h;
  
  private int i;
  
  private ColorStateList j;
  
  private int k;
  
  private boolean l = true;
  
  private float m;
  
  public f() {
    this.a.setStyle(Paint.Style.STROKE);
  }
  
  private Shader a() {
    Rect rect = this.b;
    copyBounds(rect);
    float f3 = this.e / rect.height();
    int n = a.b.g.a.a.b(this.f, this.k);
    int k = a.b.g.a.a.b(this.g, this.k);
    int i = a.b.g.a.a.b(a.b.g.a.a.c(this.g, 0), this.k);
    int m = a.b.g.a.a.b(a.b.g.a.a.c(this.i, 0), this.k);
    int i1 = a.b.g.a.a.b(this.i, this.k);
    int j = a.b.g.a.a.b(this.h, this.k);
    float f1 = rect.top;
    float f2 = rect.bottom;
    Shader.TileMode tileMode = Shader.TileMode.CLAMP;
    return (Shader)new LinearGradient(0.0F, f1, 0.0F, f2, new int[] { n, k, i, m, i1, j }, new float[] { 0.0F, f3, 0.5F, 0.5F, 1.0F - f3, 1.0F }, tileMode);
  }
  
  public void a(float paramFloat) {
    if (this.e != paramFloat) {
      this.e = paramFloat;
      this.a.setStrokeWidth(1.3333F * paramFloat);
      this.l = true;
      invalidateSelf();
    } 
  }
  
  public void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.f = paramInt1;
    this.g = paramInt2;
    this.h = paramInt3;
    this.i = paramInt4;
  }
  
  public void a(ColorStateList paramColorStateList) {
    if (paramColorStateList != null)
      this.k = paramColorStateList.getColorForState(getState(), this.k); 
    this.j = paramColorStateList;
    this.l = true;
    invalidateSelf();
  }
  
  public final void b(float paramFloat) {
    if (paramFloat != this.m) {
      this.m = paramFloat;
      invalidateSelf();
    } 
  }
  
  public void draw(Canvas paramCanvas) {
    if (this.l) {
      this.a.setShader(a());
      this.l = false;
    } 
    float f1 = this.a.getStrokeWidth() / 2.0F;
    RectF rectF = this.c;
    copyBounds(this.b);
    rectF.set(this.b);
    rectF.left += f1;
    rectF.top += f1;
    rectF.right -= f1;
    rectF.bottom -= f1;
    paramCanvas.save();
    paramCanvas.rotate(this.m, rectF.centerX(), rectF.centerY());
    paramCanvas.drawOval(rectF, this.a);
    paramCanvas.restore();
  }
  
  public Drawable.ConstantState getConstantState() {
    return this.d;
  }
  
  public int getOpacity() {
    byte b1;
    if (this.e > 0.0F) {
      b1 = -3;
    } else {
      b1 = -2;
    } 
    return b1;
  }
  
  public boolean getPadding(Rect paramRect) {
    int i = Math.round(this.e);
    paramRect.set(i, i, i, i);
    return true;
  }
  
  public boolean isStateful() {
    boolean bool;
    ColorStateList colorStateList = this.j;
    if ((colorStateList != null && colorStateList.isStateful()) || super.isStateful()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  protected void onBoundsChange(Rect paramRect) {
    this.l = true;
  }
  
  protected boolean onStateChange(int[] paramArrayOfint) {
    ColorStateList colorStateList = this.j;
    if (colorStateList != null) {
      int i = colorStateList.getColorForState(paramArrayOfint, this.k);
      if (i != this.k) {
        this.l = true;
        this.k = i;
      } 
    } 
    if (this.l)
      invalidateSelf(); 
    return this.l;
  }
  
  public void setAlpha(int paramInt) {
    this.a.setAlpha(paramInt);
    invalidateSelf();
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    this.a.setColorFilter(paramColorFilter);
    invalidateSelf();
  }
  
  private class b extends Drawable.ConstantState {
    final f a;
    
    private b(f this$0) {}
    
    public int getChangingConfigurations() {
      return 0;
    }
    
    public Drawable newDrawable() {
      return this.a;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */