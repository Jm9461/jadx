package android.support.design.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

class x<V extends View> extends CoordinatorLayout.c<V> {
  private y a;
  
  private int b = 0;
  
  private int c = 0;
  
  public x() {}
  
  public x(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  public boolean a(int paramInt) {
    y y1 = this.a;
    if (y1 != null)
      return y1.b(paramInt); 
    this.b = paramInt;
    return false;
  }
  
  public boolean a(CoordinatorLayout paramCoordinatorLayout, V paramV, int paramInt) {
    b(paramCoordinatorLayout, paramV, paramInt);
    if (this.a == null)
      this.a = new y((View)paramV); 
    this.a.b();
    paramInt = this.b;
    if (paramInt != 0) {
      this.a.b(paramInt);
      this.b = 0;
    } 
    paramInt = this.c;
    if (paramInt != 0) {
      this.a.a(paramInt);
      this.c = 0;
    } 
    return true;
  }
  
  public int b() {
    boolean bool;
    y y1 = this.a;
    if (y1 != null) {
      bool = y1.a();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  protected void b(CoordinatorLayout paramCoordinatorLayout, V paramV, int paramInt) {
    paramCoordinatorLayout.c((View)paramV, paramInt);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */