package android.support.design.widget;

import a.b.g.g.j;
import a.b.g.g.l;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.support.v4.view.c0;
import android.support.v4.view.m;
import android.support.v4.view.o;
import android.support.v4.view.p;
import android.support.v4.view.u;
import android.support.v4.widget.t;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CoordinatorLayout extends ViewGroup implements m {
  static final String v;
  
  static final Class<?>[] w = new Class[] { Context.class, AttributeSet.class };
  
  static final ThreadLocal<Map<String, Constructor<c>>> x = new ThreadLocal<Map<String, Constructor<c>>>();
  
  static final Comparator<View> y;
  
  private static final j<Rect> z = (j<Rect>)new l(12);
  
  private final List<View> c;
  
  private final android.support.v4.widget.f<View> d;
  
  private final List<View> e;
  
  private final List<View> f;
  
  private final int[] g;
  
  private Paint h;
  
  private boolean i;
  
  private boolean j;
  
  private int[] k;
  
  private View l;
  
  private View m;
  
  private g n;
  
  private boolean o;
  
  private c0 p;
  
  private boolean q;
  
  private Drawable r;
  
  ViewGroup.OnHierarchyChangeListener s;
  
  private p t;
  
  private final o u;
  
  public CoordinatorLayout(Context paramContext) {
    this(paramContext, null);
  }
  
  public CoordinatorLayout(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.b.b.a.coordinatorLayoutStyle);
  }
  
  public CoordinatorLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TypedArray typedArray;
    this.c = new ArrayList<View>();
    this.d = new android.support.v4.widget.f();
    this.e = new ArrayList<View>();
    this.f = new ArrayList<View>();
    this.g = new int[2];
    this.u = new o(this);
    if (paramInt == 0) {
      typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, a.b.b.c.CoordinatorLayout, 0, a.b.b.b.Widget_Support_CoordinatorLayout);
    } else {
      typedArray = paramContext.obtainStyledAttributes((AttributeSet)typedArray, a.b.b.c.CoordinatorLayout, paramInt, 0);
    } 
    paramInt = typedArray.getResourceId(a.b.b.c.CoordinatorLayout_keylines, 0);
    if (paramInt != 0) {
      Resources resources = paramContext.getResources();
      this.k = resources.getIntArray(paramInt);
      float f1 = (resources.getDisplayMetrics()).density;
      int i = this.k.length;
      for (paramInt = 0; paramInt < i; paramInt++) {
        int[] arrayOfInt = this.k;
        arrayOfInt[paramInt] = (int)(arrayOfInt[paramInt] * f1);
      } 
    } 
    this.r = typedArray.getDrawable(a.b.b.c.CoordinatorLayout_statusBarBackground);
    typedArray.recycle();
    f();
    super.setOnHierarchyChangeListener(new e(this));
  }
  
  private static int a(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt1 < paramInt2) ? paramInt2 : ((paramInt1 > paramInt3) ? paramInt3 : paramInt1);
  }
  
  static c a(Context paramContext, AttributeSet paramAttributeSet, String paramString) {
    if (TextUtils.isEmpty(paramString))
      return null; 
    if (paramString.startsWith(".")) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramContext.getPackageName());
      stringBuilder.append(paramString);
      paramString = stringBuilder.toString();
    } else if (paramString.indexOf('.') < 0 && !TextUtils.isEmpty(v)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(v);
      stringBuilder.append('.');
      stringBuilder.append(paramString);
      paramString = stringBuilder.toString();
    } 
    try {
      Map<Object, Object> map2 = (Map)x.get();
      Map<Object, Object> map1 = map2;
      if (map2 == null) {
        map1 = new HashMap<Object, Object>();
        super();
        x.set(map1);
      } 
      Constructor<?> constructor2 = (Constructor)map1.get(paramString);
      Constructor<?> constructor1 = constructor2;
      if (constructor2 == null) {
        constructor1 = paramContext.getClassLoader().loadClass(paramString).getConstructor(w);
        constructor1.setAccessible(true);
        map1.put(paramString, constructor1);
      } 
      return (c)constructor1.newInstance(new Object[] { paramContext, paramAttributeSet });
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not inflate Behavior subclass ");
      stringBuilder.append(paramString);
      throw new RuntimeException(stringBuilder.toString(), exception);
    } 
  }
  
  private static void a(Rect paramRect) {
    paramRect.setEmpty();
    z.a(paramRect);
  }
  
  private void a(f paramf, Rect paramRect, int paramInt1, int paramInt2) {
    int i = getWidth();
    int k = getHeight();
    i = Math.max(getPaddingLeft() + paramf.leftMargin, Math.min(paramRect.left, i - getPaddingRight() - paramInt1 - paramf.rightMargin));
    k = Math.max(getPaddingTop() + paramf.topMargin, Math.min(paramRect.top, k - getPaddingBottom() - paramInt2 - paramf.bottomMargin));
    paramRect.set(i, k, i + paramInt1, k + paramInt2);
  }
  
  private void a(View paramView, int paramInt1, Rect paramRect1, Rect paramRect2, f paramf, int paramInt2, int paramInt3) {
    int i = android.support.v4.view.d.a(c(paramf.c), paramInt1);
    paramInt1 = android.support.v4.view.d.a(d(paramf.d), paramInt1);
    int n = i & 0x7;
    int k = i & 0x70;
    int i1 = paramInt1 & 0x7;
    i = paramInt1 & 0x70;
    if (i1 != 1) {
      if (i1 != 5) {
        paramInt1 = paramRect1.left;
      } else {
        paramInt1 = paramRect1.right;
      } 
    } else {
      paramInt1 = paramRect1.left + paramRect1.width() / 2;
    } 
    if (i != 16) {
      if (i != 80) {
        i = paramRect1.top;
      } else {
        i = paramRect1.bottom;
      } 
    } else {
      i = paramRect1.top + paramRect1.height() / 2;
    } 
    if (n != 1) {
      if (n != 5)
        paramInt1 -= paramInt2; 
    } else {
      paramInt1 -= paramInt2 / 2;
    } 
    if (k != 16) {
      if (k != 80)
        i -= paramInt3; 
    } else {
      i -= paramInt3 / 2;
    } 
    paramRect2.set(paramInt1, i, paramInt1 + paramInt2, i + paramInt3);
  }
  
  private void a(View paramView, Rect paramRect, int paramInt) {
    StringBuilder stringBuilder;
    if (!u.y(paramView))
      return; 
    if (paramView.getWidth() <= 0 || paramView.getHeight() <= 0)
      return; 
    f f1 = (f)paramView.getLayoutParams();
    c<View> c = f1.d();
    Rect rect2 = d();
    Rect rect1 = d();
    rect1.set(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
    if (c != null && c.a(this, paramView, rect2)) {
      if (!rect1.contains(rect2)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Rect should be within the child's bounds. Rect:");
        stringBuilder.append(rect2.toShortString());
        stringBuilder.append(" | Bounds:");
        stringBuilder.append(rect1.toShortString());
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
    } else {
      rect2.set(rect1);
    } 
    a(rect1);
    if (rect2.isEmpty()) {
      a(rect2);
      return;
    } 
    int k = android.support.v4.view.d.a(f1.h, paramInt);
    int i = 0;
    paramInt = i;
    if ((k & 0x30) == 48) {
      int n = rect2.top - f1.topMargin - f1.j;
      int i1 = paramRect.top;
      paramInt = i;
      if (n < i1) {
        f((View)stringBuilder, i1 - n);
        paramInt = 1;
      } 
    } 
    i = paramInt;
    if ((k & 0x50) == 80) {
      int i1 = getHeight() - rect2.bottom - f1.bottomMargin + f1.j;
      int n = paramRect.bottom;
      i = paramInt;
      if (i1 < n) {
        f((View)stringBuilder, i1 - n);
        i = 1;
      } 
    } 
    if (i == 0)
      f((View)stringBuilder, 0); 
    i = 0;
    paramInt = i;
    if ((k & 0x3) == 3) {
      int n = rect2.left - f1.leftMargin - f1.i;
      int i1 = paramRect.left;
      paramInt = i;
      if (n < i1) {
        e((View)stringBuilder, i1 - n);
        paramInt = 1;
      } 
    } 
    i = paramInt;
    if ((k & 0x5) == 5) {
      int n = getWidth() - rect2.right - f1.rightMargin + f1.i;
      k = paramRect.right;
      i = paramInt;
      if (n < k) {
        e((View)stringBuilder, n - k);
        i = 1;
      } 
    } 
    if (i == 0)
      e((View)stringBuilder, 0); 
    a(rect2);
  }
  
  private void a(View paramView1, View paramView2, int paramInt) {
    Rect rect1 = d();
    Rect rect2 = d();
    try {
      a(paramView2, rect1);
      a(paramView1, paramInt, rect1, rect2);
      paramView1.layout(rect2.left, rect2.top, rect2.right, rect2.bottom);
      return;
    } finally {
      a(rect1);
      a(rect2);
    } 
  }
  
  private void a(List<View> paramList) {
    paramList.clear();
    boolean bool = isChildrenDrawingOrderEnabled();
    int k = getChildCount();
    for (int i = k - 1; i >= 0; i--) {
      int n;
      if (bool) {
        n = getChildDrawingOrder(k, i);
      } else {
        n = i;
      } 
      paramList.add(getChildAt(n));
    } 
    Comparator<View> comparator = y;
    if (comparator != null)
      Collections.sort(paramList, comparator); 
  }
  
  private void a(boolean paramBoolean) {
    int i = getChildCount();
    byte b;
    for (b = 0; b < i; b++) {
      View view = getChildAt(b);
      c<View> c = ((f)view.getLayoutParams()).d();
      if (c != null) {
        long l = SystemClock.uptimeMillis();
        MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
        if (paramBoolean) {
          c.a(this, view, motionEvent);
        } else {
          c.b(this, view, motionEvent);
        } 
        motionEvent.recycle();
      } 
    } 
    for (b = 0; b < i; b++)
      ((f)getChildAt(b).getLayoutParams()).h(); 
    this.l = null;
    this.i = false;
  }
  
  private boolean a(MotionEvent paramMotionEvent, int paramInt) {
    boolean bool2;
    boolean bool1 = false;
    boolean bool = false;
    f f1 = null;
    int k = paramMotionEvent.getActionMasked();
    List<View> list = this.e;
    a(list);
    int i = list.size();
    byte b = 0;
    while (true) {
      bool2 = bool1;
      if (b < i) {
        boolean bool4;
        MotionEvent motionEvent;
        f f2;
        View view = list.get(b);
        f f3 = (f)view.getLayoutParams();
        c<View> c = f3.d();
        boolean bool3 = true;
        if ((bool1 || bool) && k != 0) {
          bool4 = bool1;
          bool3 = bool;
          f3 = f1;
          if (c != null) {
            f3 = f1;
            if (f1 == null) {
              long l = SystemClock.uptimeMillis();
              motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
            } 
            if (paramInt != 0) {
              if (paramInt == 1)
                c.b(this, view, motionEvent); 
            } else {
              c.a(this, view, motionEvent);
            } 
            bool4 = bool1;
            bool3 = bool;
          } 
        } else {
          bool2 = bool1;
          if (!bool1) {
            bool2 = bool1;
            if (c != null) {
              if (paramInt != 0) {
                if (paramInt == 1)
                  bool1 = c.b(this, view, paramMotionEvent); 
              } else {
                bool1 = c.a(this, view, paramMotionEvent);
              } 
              bool2 = bool1;
              if (bool1) {
                this.l = view;
                bool2 = bool1;
              } 
            } 
          } 
          bool4 = motionEvent.b();
          bool1 = motionEvent.b(this, view);
          if (!bool1 || bool4)
            bool3 = false; 
          bool = bool3;
          bool4 = bool2;
          bool3 = bool;
          f2 = f1;
          if (bool1) {
            bool4 = bool2;
            bool3 = bool;
            f2 = f1;
            if (!bool)
              break; 
          } 
        } 
        b++;
        bool1 = bool4;
        bool = bool3;
        f1 = f2;
        continue;
      } 
      break;
    } 
    list.clear();
    return bool2;
  }
  
  private int b(int paramInt) {
    StringBuilder stringBuilder;
    int[] arrayOfInt = this.k;
    if (arrayOfInt == null) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("No keylines defined for ");
      stringBuilder.append(this);
      stringBuilder.append(" - attempted index lookup ");
      stringBuilder.append(paramInt);
      Log.e("CoordinatorLayout", stringBuilder.toString());
      return 0;
    } 
    if (paramInt < 0 || paramInt >= stringBuilder.length) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("Keyline index ");
      stringBuilder.append(paramInt);
      stringBuilder.append(" out of range for ");
      stringBuilder.append(this);
      Log.e("CoordinatorLayout", stringBuilder.toString());
      return 0;
    } 
    return stringBuilder[paramInt];
  }
  
  private c0 b(c0 paramc0) {
    c0 c01;
    if (paramc0.g())
      return paramc0; 
    byte b = 0;
    int i = getChildCount();
    while (true) {
      c01 = paramc0;
      if (b < i) {
        View view = getChildAt(b);
        c01 = paramc0;
        if (u.h(view)) {
          c<View> c = ((f)view.getLayoutParams()).d();
          c01 = paramc0;
          if (c != null) {
            paramc0 = c.a(this, view, paramc0);
            c01 = paramc0;
            if (paramc0.g()) {
              c01 = paramc0;
              break;
            } 
          } 
        } 
        b++;
        paramc0 = c01;
        continue;
      } 
      break;
    } 
    return c01;
  }
  
  private void b(View paramView, int paramInt1, int paramInt2) {
    f f1 = (f)paramView.getLayoutParams();
    int i = android.support.v4.view.d.a(e(f1.c), paramInt2);
    int i3 = i & 0x7;
    int i2 = i & 0x70;
    int i1 = getWidth();
    int n = getHeight();
    i = paramView.getMeasuredWidth();
    int k = paramView.getMeasuredHeight();
    if (paramInt2 == 1)
      paramInt1 = i1 - paramInt1; 
    paramInt1 = b(paramInt1) - i;
    paramInt2 = 0;
    if (i3 != 1) {
      if (i3 == 5)
        paramInt1 += i; 
    } else {
      paramInt1 += i / 2;
    } 
    if (i2 != 16) {
      if (i2 == 80)
        paramInt2 = 0 + k; 
    } else {
      paramInt2 = 0 + k / 2;
    } 
    paramInt1 = Math.max(getPaddingLeft() + f1.leftMargin, Math.min(paramInt1, i1 - getPaddingRight() - i - f1.rightMargin));
    paramInt2 = Math.max(getPaddingTop() + f1.topMargin, Math.min(paramInt2, n - getPaddingBottom() - k - f1.bottomMargin));
    paramView.layout(paramInt1, paramInt2, paramInt1 + i, paramInt2 + k);
  }
  
  private static int c(int paramInt) {
    if (paramInt == 0)
      paramInt = 17; 
    return paramInt;
  }
  
  private static int d(int paramInt) {
    int i = paramInt;
    if ((paramInt & 0x7) == 0)
      i = paramInt | 0x800003; 
    paramInt = i;
    if ((i & 0x70) == 0)
      paramInt = i | 0x30; 
    return paramInt;
  }
  
  private static Rect d() {
    Rect rect2 = (Rect)z.a();
    Rect rect1 = rect2;
    if (rect2 == null)
      rect1 = new Rect(); 
    return rect1;
  }
  
  private void d(View paramView, int paramInt) {
    f f1 = (f)paramView.getLayoutParams();
    Rect rect1 = d();
    rect1.set(getPaddingLeft() + f1.leftMargin, getPaddingTop() + f1.topMargin, getWidth() - getPaddingRight() - f1.rightMargin, getHeight() - getPaddingBottom() - f1.bottomMargin);
    if (this.p != null && u.h((View)this) && !u.h(paramView)) {
      rect1.left += this.p.c();
      rect1.top += this.p.e();
      rect1.right -= this.p.d();
      rect1.bottom -= this.p.b();
    } 
    Rect rect2 = d();
    android.support.v4.view.d.a(d(f1.c), paramView.getMeasuredWidth(), paramView.getMeasuredHeight(), rect1, rect2, paramInt);
    paramView.layout(rect2.left, rect2.top, rect2.right, rect2.bottom);
    a(rect1);
    a(rect2);
  }
  
  private static int e(int paramInt) {
    if (paramInt == 0)
      paramInt = 8388661; 
    return paramInt;
  }
  
  private void e() {
    this.c.clear();
    this.d.a();
    byte b = 0;
    int i = getChildCount();
    while (b < i) {
      View view = getChildAt(b);
      f f1 = d(view);
      f1.a(this, view);
      this.d.a(view);
      for (byte b1 = 0; b1 < i; b1++) {
        if (b1 != b) {
          View view1 = getChildAt(b1);
          if (f1.a(this, view, view1)) {
            if (!this.d.b(view1))
              this.d.a(view1); 
            this.d.a(view1, view);
          } 
        } 
      } 
      b++;
    } 
    this.c.addAll(this.d.b());
    Collections.reverse(this.c);
  }
  
  private void e(View paramView, int paramInt) {
    f f1 = (f)paramView.getLayoutParams();
    int i = f1.i;
    if (i != paramInt) {
      u.c(paramView, paramInt - i);
      f1.i = paramInt;
    } 
  }
  
  private boolean e(View paramView) {
    return this.d.e(paramView);
  }
  
  private void f() {
    if (Build.VERSION.SDK_INT < 21)
      return; 
    if (u.h((View)this)) {
      if (this.t == null)
        this.t = new a(this); 
      u.a((View)this, this.t);
      setSystemUiVisibility(1280);
    } else {
      u.a((View)this, null);
    } 
  }
  
  private void f(View paramView, int paramInt) {
    f f1 = (f)paramView.getLayoutParams();
    int i = f1.j;
    if (i != paramInt) {
      u.d(paramView, paramInt - i);
      f1.j = paramInt;
    } 
  }
  
  final c0 a(c0 paramc0) {
    c0 c01 = paramc0;
    if (!a.b.g.g.i.a(this.p, paramc0)) {
      boolean bool1;
      this.p = paramc0;
      boolean bool2 = true;
      if (paramc0 != null && paramc0.e() > 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.q = bool1;
      if (!this.q && getBackground() == null) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      setWillNotDraw(bool1);
      c01 = b(paramc0);
      requestLayout();
    } 
    return c01;
  }
  
  void a() {
    if (this.j) {
      if (this.n == null)
        this.n = new g(this); 
      getViewTreeObserver().addOnPreDrawListener(this.n);
    } 
    this.o = true;
  }
  
  final void a(int paramInt) {
    int i = u.k((View)this);
    int k = this.c.size();
    Rect rect2 = d();
    Rect rect3 = d();
    Rect rect1 = d();
    for (byte b = 0; b < k; b++) {
      View view = this.c.get(b);
      f f1 = (f)view.getLayoutParams();
      if (paramInt == 0 && view.getVisibility() == 8)
        continue; 
      int n;
      for (n = 0; n < b; n++) {
        View view1 = this.c.get(n);
        if (f1.l == view1)
          b(view, i); 
      } 
      a(view, true, rect3);
      if (f1.g != 0 && !rect3.isEmpty()) {
        int i1 = android.support.v4.view.d.a(f1.g, i);
        n = i1 & 0x70;
        if (n != 48) {
          if (n == 80)
            rect2.bottom = Math.max(rect2.bottom, getHeight() - rect3.top); 
        } else {
          rect2.top = Math.max(rect2.top, rect3.bottom);
        } 
        n = i1 & 0x7;
        if (n != 3) {
          if (n == 5)
            rect2.right = Math.max(rect2.right, getWidth() - rect3.left); 
        } else {
          rect2.left = Math.max(rect2.left, rect3.right);
        } 
      } 
      if (f1.h != 0 && view.getVisibility() == 0)
        a(view, rect2, i); 
      if (paramInt != 2) {
        b(view, rect1);
        if (rect1.equals(rect3))
          continue; 
        c(view, rect3);
      } 
      for (n = b + 1; n < k; n++) {
        View view1 = this.c.get(n);
        f f2 = (f)view1.getLayoutParams();
        c<View> c = f2.d();
        if (c != null && c.a(this, view1, view))
          if (paramInt == 0 && f2.e()) {
            f2.g();
          } else {
            boolean bool;
            if (paramInt != 2) {
              bool = c.b(this, view1, view);
            } else {
              c.c(this, view1, view);
              bool = true;
            } 
            if (paramInt == 1)
              f2.a(bool); 
          }  
      } 
      continue;
    } 
    a(rect2);
    a(rect3);
    a(rect1);
  }
  
  public void a(View paramView) {
    List<View> list = this.d.c(paramView);
    if (list != null && !list.isEmpty())
      for (byte b = 0; b < list.size(); b++) {
        View view = list.get(b);
        c<View> c = ((f)view.getLayoutParams()).d();
        if (c != null)
          c.b(this, view, paramView); 
      }  
  }
  
  public void a(View paramView, int paramInt) {
    this.u.a(paramView, paramInt);
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      f f1 = (f)view.getLayoutParams();
      if (f1.a(paramInt)) {
        c<View> c = f1.d();
        if (c != null)
          c.a(this, view, paramView, paramInt); 
        f1.b(paramInt);
        f1.g();
      } 
    } 
    this.m = null;
  }
  
  public void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    measureChildWithMargins(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    int i = getChildCount();
    boolean bool = false;
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      if (view.getVisibility() != 8) {
        f f1 = (f)view.getLayoutParams();
        if (f1.a(paramInt5)) {
          c<View> c = f1.d();
          if (c != null) {
            c.a(this, view, paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
            bool = true;
          } 
        } 
      } 
    } 
    if (bool)
      a(1); 
  }
  
  public void a(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    int i1 = getChildCount();
    int n = 0;
    int k = 0;
    int i = 0;
    for (byte b = 0; b < i1; b++) {
      View view = getChildAt(b);
      if (view.getVisibility() != 8) {
        f f1 = (f)view.getLayoutParams();
        if (f1.a(paramInt3)) {
          c<View> c = f1.d();
          if (c != null) {
            int[] arrayOfInt2 = this.g;
            arrayOfInt2[1] = 0;
            arrayOfInt2[0] = 0;
            c.a(this, view, paramView, paramInt1, paramInt2, arrayOfInt2, paramInt3);
            int[] arrayOfInt1 = this.g;
            if (paramInt1 > 0) {
              i = Math.max(n, arrayOfInt1[0]);
            } else {
              i = Math.min(n, arrayOfInt1[0]);
            } 
            arrayOfInt1 = this.g;
            if (paramInt2 > 0) {
              k = Math.max(k, arrayOfInt1[1]);
            } else {
              k = Math.min(k, arrayOfInt1[1]);
            } 
            boolean bool = true;
            n = i;
            i = bool;
          } 
        } 
      } 
    } 
    paramArrayOfint[0] = n;
    paramArrayOfint[1] = k;
    if (i != 0)
      a(1); 
  }
  
  void a(View paramView, int paramInt, Rect paramRect1, Rect paramRect2) {
    f f1 = (f)paramView.getLayoutParams();
    int i = paramView.getMeasuredWidth();
    int k = paramView.getMeasuredHeight();
    a(paramView, paramInt, paramRect1, paramRect2, f1, i, k);
    a(f1, paramRect2, i, k);
  }
  
  void a(View paramView, Rect paramRect) {
    t.a(this, paramView, paramRect);
  }
  
  public void a(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    this.u.a(paramView1, paramView2, paramInt1, paramInt2);
    this.m = paramView2;
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      f f1 = (f)view.getLayoutParams();
      if (f1.a(paramInt2)) {
        c<View> c = f1.d();
        if (c != null)
          c.a(this, view, paramView1, paramView2, paramInt1, paramInt2); 
      } 
    } 
  }
  
  void a(View paramView, boolean paramBoolean, Rect paramRect) {
    if (paramView.isLayoutRequested() || paramView.getVisibility() == 8) {
      paramRect.setEmpty();
      return;
    } 
    if (paramBoolean) {
      a(paramView, paramRect);
    } else {
      paramRect.set(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
    } 
  }
  
  public boolean a(View paramView, int paramInt1, int paramInt2) {
    Rect rect = d();
    a(paramView, rect);
    try {
      return rect.contains(paramInt1, paramInt2);
    } finally {
      a(rect);
    } 
  }
  
  public List<View> b(View paramView) {
    List<? extends View> list = this.d.d(paramView);
    this.f.clear();
    if (list != null)
      this.f.addAll(list); 
    return this.f;
  }
  
  void b() {
    boolean bool1;
    boolean bool2 = false;
    int i = getChildCount();
    byte b = 0;
    while (true) {
      bool1 = bool2;
      if (b < i) {
        if (e(getChildAt(b))) {
          bool1 = true;
          break;
        } 
        b++;
        continue;
      } 
      break;
    } 
    if (bool1 != this.o)
      if (bool1) {
        a();
      } else {
        c();
      }  
  }
  
  void b(View paramView, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   4: checkcast android/support/design/widget/CoordinatorLayout$f
    //   7: astore #7
    //   9: aload #7
    //   11: getfield k : Landroid/view/View;
    //   14: ifnull -> 212
    //   17: invokestatic d : ()Landroid/graphics/Rect;
    //   20: astore #6
    //   22: invokestatic d : ()Landroid/graphics/Rect;
    //   25: astore #9
    //   27: invokestatic d : ()Landroid/graphics/Rect;
    //   30: astore #10
    //   32: aload_0
    //   33: aload #7
    //   35: getfield k : Landroid/view/View;
    //   38: aload #6
    //   40: invokevirtual a : (Landroid/view/View;Landroid/graphics/Rect;)V
    //   43: iconst_0
    //   44: istore_3
    //   45: aload_0
    //   46: aload_1
    //   47: iconst_0
    //   48: aload #9
    //   50: invokevirtual a : (Landroid/view/View;ZLandroid/graphics/Rect;)V
    //   53: aload_1
    //   54: invokevirtual getMeasuredWidth : ()I
    //   57: istore #5
    //   59: aload_1
    //   60: invokevirtual getMeasuredHeight : ()I
    //   63: istore #4
    //   65: aload_0
    //   66: aload_1
    //   67: iload_2
    //   68: aload #6
    //   70: aload #10
    //   72: aload #7
    //   74: iload #5
    //   76: iload #4
    //   78: invokespecial a : (Landroid/view/View;ILandroid/graphics/Rect;Landroid/graphics/Rect;Landroid/support/design/widget/CoordinatorLayout$f;II)V
    //   81: aload #10
    //   83: getfield left : I
    //   86: aload #9
    //   88: getfield left : I
    //   91: if_icmpne -> 109
    //   94: iload_3
    //   95: istore_2
    //   96: aload #10
    //   98: getfield top : I
    //   101: aload #9
    //   103: getfield top : I
    //   106: if_icmpeq -> 111
    //   109: iconst_1
    //   110: istore_2
    //   111: aload_0
    //   112: aload #7
    //   114: aload #10
    //   116: iload #5
    //   118: iload #4
    //   120: invokespecial a : (Landroid/support/design/widget/CoordinatorLayout$f;Landroid/graphics/Rect;II)V
    //   123: aload #10
    //   125: getfield left : I
    //   128: aload #9
    //   130: getfield left : I
    //   133: isub
    //   134: istore_3
    //   135: aload #10
    //   137: getfield top : I
    //   140: aload #9
    //   142: getfield top : I
    //   145: isub
    //   146: istore #4
    //   148: iload_3
    //   149: ifeq -> 157
    //   152: aload_1
    //   153: iload_3
    //   154: invokestatic c : (Landroid/view/View;I)V
    //   157: iload #4
    //   159: ifeq -> 168
    //   162: aload_1
    //   163: iload #4
    //   165: invokestatic d : (Landroid/view/View;I)V
    //   168: iload_2
    //   169: ifeq -> 197
    //   172: aload #7
    //   174: invokevirtual d : ()Landroid/support/design/widget/CoordinatorLayout$c;
    //   177: astore #8
    //   179: aload #8
    //   181: ifnull -> 197
    //   184: aload #8
    //   186: aload_0
    //   187: aload_1
    //   188: aload #7
    //   190: getfield k : Landroid/view/View;
    //   193: invokevirtual b : (Landroid/support/design/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z
    //   196: pop
    //   197: aload #6
    //   199: invokestatic a : (Landroid/graphics/Rect;)V
    //   202: aload #9
    //   204: invokestatic a : (Landroid/graphics/Rect;)V
    //   207: aload #10
    //   209: invokestatic a : (Landroid/graphics/Rect;)V
    //   212: return
  }
  
  void b(View paramView, Rect paramRect) {
    paramRect.set(((f)paramView.getLayoutParams()).f());
  }
  
  public boolean b(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    int i = getChildCount();
    boolean bool = false;
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      if (view.getVisibility() != 8) {
        f f1 = (f)view.getLayoutParams();
        c<View> c = f1.d();
        if (c != null) {
          boolean bool1 = c.b(this, view, paramView1, paramView2, paramInt1, paramInt2);
          f1.a(paramInt2, bool1);
          bool |= bool1;
        } else {
          f1.a(paramInt2, false);
        } 
      } 
    } 
    return bool;
  }
  
  public List<View> c(View paramView) {
    List<? extends View> list = this.d.c(paramView);
    this.f.clear();
    if (list != null)
      this.f.addAll(list); 
    return this.f;
  }
  
  void c() {
    if (this.j && this.n != null)
      getViewTreeObserver().removeOnPreDrawListener(this.n); 
    this.o = false;
  }
  
  public void c(View paramView, int paramInt) {
    f f1 = (f)paramView.getLayoutParams();
    if (!f1.a()) {
      View view = f1.k;
      if (view != null) {
        a(paramView, view, paramInt);
      } else {
        int i = f1.e;
        if (i >= 0) {
          b(paramView, i, paramInt);
        } else {
          d(paramView, paramInt);
        } 
      } 
      return;
    } 
    throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
  }
  
  void c(View paramView, Rect paramRect) {
    ((f)paramView.getLayoutParams()).a(paramRect);
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    boolean bool;
    if (paramLayoutParams instanceof f && super.checkLayoutParams(paramLayoutParams)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  f d(View paramView) {
    f f1 = (f)paramView.getLayoutParams();
    if (!f1.b) {
      c c;
      if (paramView instanceof b) {
        c = ((b)paramView).getBehavior();
        if (c == null)
          Log.e("CoordinatorLayout", "Attached behavior class is null"); 
        f1.a(c);
        f1.b = true;
      } else {
        d d;
        Class<?> clazz = c.getClass();
        c = null;
        while (true) {
          c c1 = c;
          if (clazz != null) {
            d d2 = clazz.<d>getAnnotation(d.class);
            d d1 = d2;
            d = d1;
            if (d2 == null) {
              clazz = clazz.getSuperclass();
              continue;
            } 
          } 
          break;
        } 
        if (d != null)
          try {
            f1.a(d.value().getDeclaredConstructor(new Class[0]).newInstance(new Object[0]));
          } catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Default behavior class ");
            stringBuilder.append(d.value().getName());
            stringBuilder.append(" could not be instantiated. Did you forget");
            stringBuilder.append(" a default constructor?");
            Log.e("CoordinatorLayout", stringBuilder.toString(), exception);
          }  
        f1.b = true;
      } 
    } 
    return f1;
  }
  
  protected boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    f f1 = (f)paramView.getLayoutParams();
    c<View> c = f1.a;
    if (c != null) {
      float f2 = c.c(this, paramView);
      if (f2 > 0.0F) {
        if (this.h == null)
          this.h = new Paint(); 
        this.h.setColor(f1.a.b(this, paramView));
        this.h.setAlpha(a(Math.round(255.0F * f2), 0, 255));
        int i = paramCanvas.save();
        if (paramView.isOpaque())
          paramCanvas.clipRect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom(), Region.Op.DIFFERENCE); 
        paramCanvas.drawRect(getPaddingLeft(), getPaddingTop(), (getWidth() - getPaddingRight()), (getHeight() - getPaddingBottom()), this.h);
        paramCanvas.restoreToCount(i);
      } 
    } 
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    int[] arrayOfInt = getDrawableState();
    byte b = 0;
    Drawable drawable = this.r;
    int i = b;
    if (drawable != null) {
      i = b;
      if (drawable.isStateful())
        i = false | drawable.setState(arrayOfInt); 
    } 
    if (i != 0)
      invalidate(); 
  }
  
  protected f generateDefaultLayoutParams() {
    return new f(-2, -2);
  }
  
  public f generateLayoutParams(AttributeSet paramAttributeSet) {
    return new f(getContext(), paramAttributeSet);
  }
  
  protected f generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof f) ? new f((f)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new f((ViewGroup.MarginLayoutParams)paramLayoutParams) : new f(paramLayoutParams));
  }
  
  final List<View> getDependencySortedChildren() {
    e();
    return Collections.unmodifiableList(this.c);
  }
  
  public final c0 getLastWindowInsets() {
    return this.p;
  }
  
  public int getNestedScrollAxes() {
    return this.u.a();
  }
  
  public Drawable getStatusBarBackground() {
    return this.r;
  }
  
  protected int getSuggestedMinimumHeight() {
    return Math.max(super.getSuggestedMinimumHeight(), getPaddingTop() + getPaddingBottom());
  }
  
  protected int getSuggestedMinimumWidth() {
    return Math.max(super.getSuggestedMinimumWidth(), getPaddingLeft() + getPaddingRight());
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    a(false);
    if (this.o) {
      if (this.n == null)
        this.n = new g(this); 
      getViewTreeObserver().addOnPreDrawListener(this.n);
    } 
    if (this.p == null && u.h((View)this))
      u.C((View)this); 
    this.j = true;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    a(false);
    if (this.o && this.n != null)
      getViewTreeObserver().removeOnPreDrawListener(this.n); 
    View view = this.m;
    if (view != null)
      onStopNestedScroll(view); 
    this.j = false;
  }
  
  public void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.q && this.r != null) {
      boolean bool;
      c0 c01 = this.p;
      if (c01 != null) {
        bool = c01.e();
      } else {
        bool = false;
      } 
      if (bool) {
        this.r.setBounds(0, 0, getWidth(), bool);
        this.r.draw(paramCanvas);
      } 
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      a(true); 
    boolean bool = a(paramMotionEvent, 0);
    if (i == 1 || i == 3)
      a(true); 
    return bool;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt2 = u.k((View)this);
    paramInt3 = this.c.size();
    for (paramInt1 = 0; paramInt1 < paramInt3; paramInt1++) {
      View view = this.c.get(paramInt1);
      if (view.getVisibility() != 8) {
        c<View> c = ((f)view.getLayoutParams()).d();
        if (c == null || !c.a(this, view, paramInt2))
          c(view, paramInt2); 
      } 
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    boolean bool1;
    e();
    b();
    int i4 = getPaddingLeft();
    int i7 = getPaddingTop();
    int i6 = getPaddingRight();
    int i5 = getPaddingBottom();
    int i3 = u.k((View)this);
    boolean bool2 = true;
    if (i3 == 1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    int i10 = View.MeasureSpec.getMode(paramInt1);
    int i9 = View.MeasureSpec.getSize(paramInt1);
    int i = View.MeasureSpec.getMode(paramInt2);
    int i8 = View.MeasureSpec.getSize(paramInt2);
    int i1 = getSuggestedMinimumWidth();
    int i2 = getSuggestedMinimumHeight();
    if (this.p == null || !u.h((View)this))
      bool2 = false; 
    int k = this.c.size();
    byte b = 0;
    int n = 0;
    while (b < k) {
      View view = this.c.get(b);
      if (view.getVisibility() != 8) {
        int i13;
        f f1 = (f)view.getLayoutParams();
        int i11 = 0;
        int i12 = f1.e;
        if (i12 >= 0 && i10 != 0) {
          i13 = b(i12);
          i12 = android.support.v4.view.d.a(e(f1.c), i3) & 0x7;
          if ((i12 == 3 && !bool1) || (i12 == 5 && bool1)) {
            i11 = Math.max(0, i9 - i6 - i13);
          } else if ((i12 == 5 && !bool1) || (i12 == 3 && bool1)) {
            i11 = Math.max(0, i13 - i4);
          } 
        } 
        if (bool2 && !u.h(view)) {
          int i15 = this.p.c();
          i12 = this.p.d();
          i13 = this.p.e();
          int i14 = this.p.b();
          i12 = View.MeasureSpec.makeMeasureSpec(i9 - i15 + i12, i10);
          i13 = View.MeasureSpec.makeMeasureSpec(i8 - i13 + i14, i);
        } else {
          i12 = paramInt1;
          i13 = paramInt2;
        } 
        c<View> c = f1.d();
        if (c == null || !c.a(this, view, i12, i11, i13, 0))
          a(view, i12, i11, i13, 0); 
        i1 = Math.max(i1, i4 + i6 + view.getMeasuredWidth() + f1.leftMargin + f1.rightMargin);
        i2 = Math.max(i2, i7 + i5 + view.getMeasuredHeight() + f1.topMargin + f1.bottomMargin);
        n = View.combineMeasuredStates(n, view.getMeasuredState());
      } 
      b++;
    } 
    setMeasuredDimension(View.resolveSizeAndState(i1, paramInt1, 0xFF000000 & n), View.resolveSizeAndState(i2, paramInt2, n << 16));
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    int i = getChildCount();
    boolean bool = false;
    byte b = 0;
    while (b < i) {
      boolean bool1;
      View view = getChildAt(b);
      if (view.getVisibility() == 8) {
        bool1 = bool;
      } else {
        f f1 = (f)view.getLayoutParams();
        if (!f1.a(0)) {
          bool1 = bool;
        } else {
          c<View> c = f1.d();
          bool1 = bool;
          if (c != null)
            bool1 = c.a(this, view, paramView, paramFloat1, paramFloat2, paramBoolean) | bool; 
        } 
      } 
      b++;
      bool = bool1;
    } 
    if (bool)
      a(1); 
    return bool;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    boolean bool = false;
    int i = getChildCount();
    byte b = 0;
    while (b < i) {
      boolean bool1;
      View view = getChildAt(b);
      if (view.getVisibility() == 8) {
        bool1 = bool;
      } else {
        f f1 = (f)view.getLayoutParams();
        if (!f1.a(0)) {
          bool1 = bool;
        } else {
          c<View> c = f1.d();
          bool1 = bool;
          if (c != null)
            bool1 = bool | c.a(this, view, paramView, paramFloat1, paramFloat2); 
        } 
      } 
      b++;
      bool = bool1;
    } 
    return bool;
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    a(paramView, paramInt1, paramInt2, paramArrayOfint, 0);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    a(paramView, paramInt1, paramInt2, paramInt3, paramInt4, 0);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    a(paramView1, paramView2, paramInt, 0);
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof h)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    h h = (h)paramParcelable;
    super.onRestoreInstanceState(h.a());
    SparseArray<Parcelable> sparseArray = h.e;
    byte b = 0;
    int i = getChildCount();
    while (b < i) {
      View view = getChildAt(b);
      int k = view.getId();
      c<View> c = d(view).d();
      if (k != -1 && c != null) {
        Parcelable parcelable = (Parcelable)sparseArray.get(k);
        if (parcelable != null)
          c.a(this, view, parcelable); 
      } 
      b++;
    } 
  }
  
  protected Parcelable onSaveInstanceState() {
    h h = new h(super.onSaveInstanceState());
    SparseArray<Parcelable> sparseArray = new SparseArray();
    byte b = 0;
    int i = getChildCount();
    while (b < i) {
      View view = getChildAt(b);
      int k = view.getId();
      c<View> c = ((f)view.getLayoutParams()).d();
      if (k != -1 && c != null) {
        Parcelable parcelable = c.d(this, view);
        if (parcelable != null)
          sparseArray.append(k, parcelable); 
      } 
      b++;
    } 
    h.e = sparseArray;
    return (Parcelable)h;
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return b(paramView1, paramView2, paramInt, 0);
  }
  
  public void onStopNestedScroll(View paramView) {
    a(paramView, 0);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #6
    //   3: iconst_0
    //   4: istore #4
    //   6: aconst_null
    //   7: astore #11
    //   9: aconst_null
    //   10: astore #10
    //   12: aload_1
    //   13: invokevirtual getActionMasked : ()I
    //   16: istore_2
    //   17: aload_0
    //   18: getfield l : Landroid/view/View;
    //   21: ifnonnull -> 48
    //   24: aload_0
    //   25: aload_1
    //   26: iconst_1
    //   27: invokespecial a : (Landroid/view/MotionEvent;I)Z
    //   30: istore #7
    //   32: iload #7
    //   34: istore #4
    //   36: iload #6
    //   38: istore_3
    //   39: iload #4
    //   41: istore #5
    //   43: iload #7
    //   45: ifeq -> 91
    //   48: aload_0
    //   49: getfield l : Landroid/view/View;
    //   52: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   55: checkcast android/support/design/widget/CoordinatorLayout$f
    //   58: invokevirtual d : ()Landroid/support/design/widget/CoordinatorLayout$c;
    //   61: astore #12
    //   63: iload #6
    //   65: istore_3
    //   66: iload #4
    //   68: istore #5
    //   70: aload #12
    //   72: ifnull -> 91
    //   75: aload #12
    //   77: aload_0
    //   78: aload_0
    //   79: getfield l : Landroid/view/View;
    //   82: aload_1
    //   83: invokevirtual b : (Landroid/support/design/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z
    //   86: istore_3
    //   87: iload #4
    //   89: istore #5
    //   91: aload_0
    //   92: getfield l : Landroid/view/View;
    //   95: ifnonnull -> 113
    //   98: iload_3
    //   99: aload_0
    //   100: aload_1
    //   101: invokespecial onTouchEvent : (Landroid/view/MotionEvent;)Z
    //   104: ior
    //   105: istore #4
    //   107: aload #11
    //   109: astore_1
    //   110: goto -> 157
    //   113: iload_3
    //   114: istore #4
    //   116: aload #11
    //   118: astore_1
    //   119: iload #5
    //   121: ifeq -> 157
    //   124: aload #10
    //   126: astore_1
    //   127: iconst_0
    //   128: ifne -> 148
    //   131: invokestatic uptimeMillis : ()J
    //   134: lstore #8
    //   136: lload #8
    //   138: lload #8
    //   140: iconst_3
    //   141: fconst_0
    //   142: fconst_0
    //   143: iconst_0
    //   144: invokestatic obtain : (JJIFFI)Landroid/view/MotionEvent;
    //   147: astore_1
    //   148: aload_0
    //   149: aload_1
    //   150: invokespecial onTouchEvent : (Landroid/view/MotionEvent;)Z
    //   153: pop
    //   154: iload_3
    //   155: istore #4
    //   157: aload_1
    //   158: ifnull -> 165
    //   161: aload_1
    //   162: invokevirtual recycle : ()V
    //   165: iload_2
    //   166: iconst_1
    //   167: if_icmpeq -> 175
    //   170: iload_2
    //   171: iconst_3
    //   172: if_icmpne -> 180
    //   175: aload_0
    //   176: iconst_0
    //   177: invokespecial a : (Z)V
    //   180: iload #4
    //   182: ireturn
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    c<View> c = ((f)paramView.getLayoutParams()).d();
    return (c != null && c.a(this, paramView, paramRect, paramBoolean)) ? true : super.requestChildRectangleOnScreen(paramView, paramRect, paramBoolean);
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    super.requestDisallowInterceptTouchEvent(paramBoolean);
    if (paramBoolean && !this.i) {
      a(false);
      this.i = true;
    } 
  }
  
  public void setFitsSystemWindows(boolean paramBoolean) {
    super.setFitsSystemWindows(paramBoolean);
    f();
  }
  
  public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener paramOnHierarchyChangeListener) {
    this.s = paramOnHierarchyChangeListener;
  }
  
  public void setStatusBarBackground(Drawable paramDrawable) {
    Drawable drawable = this.r;
    if (drawable != paramDrawable) {
      Drawable drawable1 = null;
      if (drawable != null)
        drawable.setCallback(null); 
      if (paramDrawable != null)
        drawable1 = paramDrawable.mutate(); 
      this.r = drawable1;
      paramDrawable = this.r;
      if (paramDrawable != null) {
        boolean bool;
        if (paramDrawable.isStateful())
          this.r.setState(getDrawableState()); 
        android.support.v4.graphics.drawable.a.a(this.r, u.k((View)this));
        paramDrawable = this.r;
        if (getVisibility() == 0) {
          bool = true;
        } else {
          bool = false;
        } 
        paramDrawable.setVisible(bool, false);
        this.r.setCallback((Drawable.Callback)this);
      } 
      u.B((View)this);
    } 
  }
  
  public void setStatusBarBackgroundColor(int paramInt) {
    setStatusBarBackground((Drawable)new ColorDrawable(paramInt));
  }
  
  public void setStatusBarBackgroundResource(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = android.support.v4.content.a.c(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setStatusBarBackground(drawable);
  }
  
  public void setVisibility(int paramInt) {
    boolean bool;
    super.setVisibility(paramInt);
    if (paramInt == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    Drawable drawable = this.r;
    if (drawable != null && drawable.isVisible() != bool)
      this.r.setVisible(bool, false); 
  }
  
  protected boolean verifyDrawable(Drawable paramDrawable) {
    return (super.verifyDrawable(paramDrawable) || paramDrawable == this.r);
  }
  
  static {
    Package package_ = CoordinatorLayout.class.getPackage();
    if (package_ != null) {
      String str = package_.getName();
    } else {
      package_ = null;
    } 
    v = (String)package_;
    if (Build.VERSION.SDK_INT >= 21) {
      y = new i();
    } else {
      y = null;
    } 
  }
  
  class a implements p {
    final CoordinatorLayout a;
    
    a(CoordinatorLayout this$0) {}
    
    public c0 a(View param1View, c0 param1c0) {
      return this.a.a(param1c0);
    }
  }
  
  public static interface b {
    CoordinatorLayout.c getBehavior();
  }
  
  public static abstract class c<V extends View> {
    public c() {}
    
    public c(Context param1Context, AttributeSet param1AttributeSet) {}
    
    public c0 a(CoordinatorLayout param1CoordinatorLayout, V param1V, c0 param1c0) {
      return param1c0;
    }
    
    public void a() {}
    
    public void a(CoordinatorLayout.f param1f) {}
    
    public void a(CoordinatorLayout param1CoordinatorLayout, V param1V, Parcelable param1Parcelable) {}
    
    public void a(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int) {
      if (param1Int == 0)
        d(param1CoordinatorLayout, param1V, param1View); 
    }
    
    @Deprecated
    public void a(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {}
    
    public void a(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5) {
      if (param1Int5 == 0)
        a(param1CoordinatorLayout, param1V, param1View, param1Int1, param1Int2, param1Int3, param1Int4); 
    }
    
    @Deprecated
    public void a(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int1, int param1Int2, int[] param1ArrayOfint) {}
    
    public void a(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, int param1Int1, int param1Int2, int[] param1ArrayOfint, int param1Int3) {
      if (param1Int3 == 0)
        a(param1CoordinatorLayout, param1V, param1View, param1Int1, param1Int2, param1ArrayOfint); 
    }
    
    @Deprecated
    public void a(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View1, View param1View2, int param1Int) {}
    
    public void a(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View1, View param1View2, int param1Int1, int param1Int2) {
      if (param1Int2 == 0)
        a(param1CoordinatorLayout, param1V, param1View1, param1View2, param1Int1); 
    }
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, V param1V) {
      boolean bool;
      if (c(param1CoordinatorLayout, param1V) > 0.0F) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, V param1V, int param1Int) {
      return false;
    }
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, V param1V, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      return false;
    }
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, V param1V, Rect param1Rect) {
      return false;
    }
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, V param1V, Rect param1Rect, boolean param1Boolean) {
      return false;
    }
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, V param1V, MotionEvent param1MotionEvent) {
      return false;
    }
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {
      return false;
    }
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, float param1Float1, float param1Float2) {
      return false;
    }
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View, float param1Float1, float param1Float2, boolean param1Boolean) {
      return false;
    }
    
    public int b(CoordinatorLayout param1CoordinatorLayout, V param1V) {
      return -16777216;
    }
    
    public boolean b(CoordinatorLayout param1CoordinatorLayout, V param1V, MotionEvent param1MotionEvent) {
      return false;
    }
    
    public boolean b(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {
      return false;
    }
    
    @Deprecated
    public boolean b(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View1, View param1View2, int param1Int) {
      return false;
    }
    
    public boolean b(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View1, View param1View2, int param1Int1, int param1Int2) {
      return (param1Int2 == 0) ? b(param1CoordinatorLayout, param1V, param1View1, param1View2, param1Int1) : false;
    }
    
    public float c(CoordinatorLayout param1CoordinatorLayout, V param1V) {
      return 0.0F;
    }
    
    public void c(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {}
    
    public Parcelable d(CoordinatorLayout param1CoordinatorLayout, V param1V) {
      return (Parcelable)View.BaseSavedState.EMPTY_STATE;
    }
    
    @Deprecated
    public void d(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {}
  }
  
  @Deprecated
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface d {
    Class<? extends CoordinatorLayout.c> value();
  }
  
  private class e implements ViewGroup.OnHierarchyChangeListener {
    final CoordinatorLayout c;
    
    e(CoordinatorLayout this$0) {}
    
    public void onChildViewAdded(View param1View1, View param1View2) {
      ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.c.s;
      if (onHierarchyChangeListener != null)
        onHierarchyChangeListener.onChildViewAdded(param1View1, param1View2); 
    }
    
    public void onChildViewRemoved(View param1View1, View param1View2) {
      this.c.a(2);
      ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.c.s;
      if (onHierarchyChangeListener != null)
        onHierarchyChangeListener.onChildViewRemoved(param1View1, param1View2); 
    }
  }
  
  public static class f extends ViewGroup.MarginLayoutParams {
    CoordinatorLayout.c a;
    
    boolean b = false;
    
    public int c = 0;
    
    public int d = 0;
    
    public int e = -1;
    
    int f = -1;
    
    public int g = 0;
    
    public int h = 0;
    
    int i;
    
    int j;
    
    View k;
    
    View l;
    
    private boolean m;
    
    private boolean n;
    
    private boolean o;
    
    private boolean p;
    
    final Rect q = new Rect();
    
    public f(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    f(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, a.b.b.c.CoordinatorLayout_Layout);
      this.c = typedArray.getInteger(a.b.b.c.CoordinatorLayout_Layout_android_layout_gravity, 0);
      this.f = typedArray.getResourceId(a.b.b.c.CoordinatorLayout_Layout_layout_anchor, -1);
      this.d = typedArray.getInteger(a.b.b.c.CoordinatorLayout_Layout_layout_anchorGravity, 0);
      this.e = typedArray.getInteger(a.b.b.c.CoordinatorLayout_Layout_layout_keyline, -1);
      this.g = typedArray.getInt(a.b.b.c.CoordinatorLayout_Layout_layout_insetEdge, 0);
      this.h = typedArray.getInt(a.b.b.c.CoordinatorLayout_Layout_layout_dodgeInsetEdges, 0);
      this.b = typedArray.hasValue(a.b.b.c.CoordinatorLayout_Layout_layout_behavior);
      if (this.b)
        this.a = CoordinatorLayout.a(param1Context, param1AttributeSet, typedArray.getString(a.b.b.c.CoordinatorLayout_Layout_layout_behavior)); 
      typedArray.recycle();
      CoordinatorLayout.c c1 = this.a;
      if (c1 != null)
        c1.a(this); 
    }
    
    public f(f param1f) {
      super(param1f);
    }
    
    public f(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public f(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    private void a(View param1View, CoordinatorLayout param1CoordinatorLayout) {
      this.k = param1CoordinatorLayout.findViewById(this.f);
      View view = this.k;
      if (view != null) {
        if (view == param1CoordinatorLayout) {
          if (param1CoordinatorLayout.isInEditMode()) {
            this.l = null;
            this.k = null;
            return;
          } 
          throw new IllegalStateException("View can not be anchored to the the parent CoordinatorLayout");
        } 
        View view1 = this.k;
        for (ViewParent viewParent = view.getParent(); viewParent != param1CoordinatorLayout && viewParent != null; viewParent = viewParent.getParent()) {
          if (viewParent == param1View) {
            if (param1CoordinatorLayout.isInEditMode()) {
              this.l = null;
              this.k = null;
              return;
            } 
            throw new IllegalStateException("Anchor must not be a descendant of the anchored view");
          } 
          if (viewParent instanceof View)
            view1 = (View)viewParent; 
        } 
        this.l = view1;
        return;
      } 
      if (param1CoordinatorLayout.isInEditMode()) {
        this.l = null;
        this.k = null;
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not find CoordinatorLayout descendant view with id ");
      stringBuilder.append(param1CoordinatorLayout.getResources().getResourceName(this.f));
      stringBuilder.append(" to anchor view ");
      stringBuilder.append(param1View);
      IllegalStateException illegalStateException = new IllegalStateException(stringBuilder.toString());
      throw illegalStateException;
    }
    
    private boolean a(View param1View, int param1Int) {
      boolean bool;
      int i = android.support.v4.view.d.a(((f)param1View.getLayoutParams()).g, param1Int);
      if (i != 0 && (android.support.v4.view.d.a(this.h, param1Int) & i) == i) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    private boolean b(View param1View, CoordinatorLayout param1CoordinatorLayout) {
      if (this.k.getId() != this.f)
        return false; 
      View view = this.k;
      for (ViewParent viewParent = this.k.getParent(); viewParent != param1CoordinatorLayout; viewParent = viewParent.getParent()) {
        if (viewParent == null || viewParent == param1View) {
          this.l = null;
          this.k = null;
          return false;
        } 
        if (viewParent instanceof View)
          view = (View)viewParent; 
      } 
      this.l = view;
      return true;
    }
    
    View a(CoordinatorLayout param1CoordinatorLayout, View param1View) {
      if (this.f == -1) {
        this.l = null;
        this.k = null;
        return null;
      } 
      if (this.k == null || !b(param1View, param1CoordinatorLayout))
        a(param1View, param1CoordinatorLayout); 
      return this.k;
    }
    
    void a(int param1Int, boolean param1Boolean) {
      if (param1Int != 0) {
        if (param1Int == 1)
          this.o = param1Boolean; 
      } else {
        this.n = param1Boolean;
      } 
    }
    
    void a(Rect param1Rect) {
      this.q.set(param1Rect);
    }
    
    public void a(CoordinatorLayout.c param1c) {
      CoordinatorLayout.c c1 = this.a;
      if (c1 != param1c) {
        if (c1 != null)
          c1.a(); 
        this.a = param1c;
        this.b = true;
        if (param1c != null)
          param1c.a(this); 
      } 
    }
    
    void a(boolean param1Boolean) {
      this.p = param1Boolean;
    }
    
    boolean a() {
      boolean bool;
      if (this.k == null && this.f != -1) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    boolean a(int param1Int) {
      return (param1Int != 0) ? ((param1Int != 1) ? false : this.o) : this.n;
    }
    
    boolean a(CoordinatorLayout param1CoordinatorLayout, View param1View1, View param1View2) {
      if (param1View2 != this.l && !a(param1View2, u.k((View)param1CoordinatorLayout))) {
        CoordinatorLayout.c<View> c1 = this.a;
        return (c1 != null && c1.a(param1CoordinatorLayout, param1View1, param1View2));
      } 
      return true;
    }
    
    void b(int param1Int) {
      a(param1Int, false);
    }
    
    boolean b() {
      if (this.a == null)
        this.m = false; 
      return this.m;
    }
    
    boolean b(CoordinatorLayout param1CoordinatorLayout, View param1View) {
      boolean bool2 = this.m;
      if (bool2)
        return true; 
      CoordinatorLayout.c<View> c1 = this.a;
      if (c1 != null) {
        bool1 = c1.a(param1CoordinatorLayout, param1View);
      } else {
        bool1 = false;
      } 
      boolean bool1 = bool2 | bool1;
      this.m = bool1;
      return bool1;
    }
    
    public int c() {
      return this.f;
    }
    
    public CoordinatorLayout.c d() {
      return this.a;
    }
    
    boolean e() {
      return this.p;
    }
    
    Rect f() {
      return this.q;
    }
    
    void g() {
      this.p = false;
    }
    
    void h() {
      this.m = false;
    }
  }
  
  class g implements ViewTreeObserver.OnPreDrawListener {
    final CoordinatorLayout c;
    
    g(CoordinatorLayout this$0) {}
    
    public boolean onPreDraw() {
      this.c.a(0);
      return true;
    }
  }
  
  protected static class h extends android.support.v4.view.a {
    public static final Parcelable.Creator<h> CREATOR = (Parcelable.Creator<h>)new a();
    
    SparseArray<Parcelable> e;
    
    public h(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      int i = param1Parcel.readInt();
      int[] arrayOfInt = new int[i];
      param1Parcel.readIntArray(arrayOfInt);
      Parcelable[] arrayOfParcelable = param1Parcel.readParcelableArray(param1ClassLoader);
      this.e = new SparseArray(i);
      for (byte b = 0; b < i; b++)
        this.e.append(arrayOfInt[b], arrayOfParcelable[b]); 
    }
    
    public h(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      byte b1;
      super.writeToParcel(param1Parcel, param1Int);
      SparseArray<Parcelable> sparseArray = this.e;
      if (sparseArray != null) {
        b1 = sparseArray.size();
      } else {
        b1 = 0;
      } 
      param1Parcel.writeInt(b1);
      int[] arrayOfInt = new int[b1];
      Parcelable[] arrayOfParcelable = new Parcelable[b1];
      for (byte b2 = 0; b2 < b1; b2++) {
        arrayOfInt[b2] = this.e.keyAt(b2);
        arrayOfParcelable[b2] = (Parcelable)this.e.valueAt(b2);
      } 
      param1Parcel.writeIntArray(arrayOfInt);
      param1Parcel.writeParcelableArray(arrayOfParcelable, param1Int);
    }
    
    static final class a implements Parcelable.ClassLoaderCreator<h> {
      public CoordinatorLayout.h createFromParcel(Parcel param2Parcel) {
        return new CoordinatorLayout.h(param2Parcel, null);
      }
      
      public CoordinatorLayout.h createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new CoordinatorLayout.h(param2Parcel, param2ClassLoader);
      }
      
      public CoordinatorLayout.h[] newArray(int param2Int) {
        return new CoordinatorLayout.h[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.ClassLoaderCreator<h> {
    public CoordinatorLayout.h createFromParcel(Parcel param1Parcel) {
      return new CoordinatorLayout.h(param1Parcel, null);
    }
    
    public CoordinatorLayout.h createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new CoordinatorLayout.h(param1Parcel, param1ClassLoader);
    }
    
    public CoordinatorLayout.h[] newArray(int param1Int) {
      return new CoordinatorLayout.h[param1Int];
    }
  }
  
  static class i implements Comparator<View> {
    public int a(View param1View1, View param1View2) {
      float f1 = u.s(param1View1);
      float f2 = u.s(param1View2);
      return (f1 > f2) ? -1 : ((f1 < f2) ? 1 : 0);
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\CoordinatorLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */