package android.support.design.widget;

import android.view.MotionEvent;
import android.view.View;

public class a {
  private t.b a;
  
  public a(SwipeDismissBehavior<?> paramSwipeDismissBehavior) {
    paramSwipeDismissBehavior.b(0.1F);
    paramSwipeDismissBehavior.a(0.6F);
    paramSwipeDismissBehavior.a(0);
  }
  
  public void a(CoordinatorLayout paramCoordinatorLayout, View paramView, MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i != 0) {
      if (i == 1 || i == 3)
        t.a().b(this.a); 
    } else if (paramCoordinatorLayout.a(paramView, (int)paramMotionEvent.getX(), (int)paramMotionEvent.getY())) {
      t.a().a(this.a);
    } 
  }
  
  public boolean a(View paramView) {
    return paramView instanceof d;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */