package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.util.StateSet;
import java.util.ArrayList;

public final class u {
  private final ArrayList<b> a = new ArrayList<b>();
  
  private b b = null;
  
  ValueAnimator c = null;
  
  private final Animator.AnimatorListener d = (Animator.AnimatorListener)new a(this);
  
  private void a(b paramb) {
    this.c = paramb.b;
    this.c.start();
  }
  
  private void b() {
    ValueAnimator valueAnimator = this.c;
    if (valueAnimator != null) {
      valueAnimator.cancel();
      this.c = null;
    } 
  }
  
  public void a() {
    ValueAnimator valueAnimator = this.c;
    if (valueAnimator != null) {
      valueAnimator.end();
      this.c = null;
    } 
  }
  
  public void a(int[] paramArrayOfint) {
    b b3;
    b b4 = null;
    int i = this.a.size();
    byte b2 = 0;
    while (true) {
      b3 = b4;
      if (b2 < i) {
        b3 = this.a.get(b2);
        if (StateSet.stateSetMatches(b3.a, paramArrayOfint))
          break; 
        b2++;
        continue;
      } 
      break;
    } 
    b b1 = this.b;
    if (b3 == b1)
      return; 
    if (b1 != null)
      b(); 
    this.b = b3;
    if (b3 != null)
      a(b3); 
  }
  
  public void a(int[] paramArrayOfint, ValueAnimator paramValueAnimator) {
    b b1 = new b(paramArrayOfint, paramValueAnimator);
    paramValueAnimator.addListener(this.d);
    this.a.add(b1);
  }
  
  class a extends AnimatorListenerAdapter {
    final u a;
    
    a(u this$0) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      u u1 = this.a;
      if (u1.c == param1Animator)
        u1.c = null; 
    }
  }
  
  static class b {
    final int[] a;
    
    final ValueAnimator b;
    
    b(int[] param1ArrayOfint, ValueAnimator param1ValueAnimator) {
      this.a = param1ArrayOfint;
      this.b = param1ValueAnimator;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widge\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */