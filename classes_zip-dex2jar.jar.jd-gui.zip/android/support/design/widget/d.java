package android.support.design.widget;

import a.b.c.k;
import android.content.Context;
import android.content.res.TypedArray;
import android.support.v4.view.d0.b;
import android.support.v4.view.u;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.FrameLayout;

public class d extends FrameLayout {
  private final AccessibilityManager c;
  
  private final b.a d;
  
  private c e;
  
  private b f;
  
  protected d(Context paramContext) {
    this(paramContext, null);
  }
  
  protected d(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, k.SnackbarLayout);
    if (typedArray.hasValue(k.SnackbarLayout_elevation))
      u.a((View)this, typedArray.getDimensionPixelSize(k.SnackbarLayout_elevation, 0)); 
    typedArray.recycle();
    this.c = (AccessibilityManager)paramContext.getSystemService("accessibility");
    this.d = new a(this);
    b.a(this.c, this.d);
    setClickableOrFocusableBasedOnAccessibility(this.c.isTouchExplorationEnabled());
  }
  
  private void setClickableOrFocusableBasedOnAccessibility(boolean paramBoolean) {
    setClickable(paramBoolean ^ true);
    setFocusable(paramBoolean);
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    b b1 = this.f;
    if (b1 != null)
      b1.onViewAttachedToWindow((View)this); 
    u.C((View)this);
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    b b1 = this.f;
    if (b1 != null)
      b1.onViewDetachedFromWindow((View)this); 
    b.b(this.c, this.d);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    c c1 = this.e;
    if (c1 != null)
      c1.a((View)this, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  void setOnAttachStateChangeListener(b paramb) {
    this.f = paramb;
  }
  
  void setOnLayoutChangeListener(c paramc) {
    this.e = paramc;
  }
  
  class a implements b.a {
    final d a;
    
    a(d this$0) {}
    
    public void onTouchExplorationStateChanged(boolean param1Boolean) {
      d.a(this.a, param1Boolean);
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */