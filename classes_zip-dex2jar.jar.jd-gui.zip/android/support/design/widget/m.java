package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.StateListAnimator;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.view.View;
import java.util.ArrayList;

class m extends l {
  private InsetDrawable I;
  
  m(a0 parama0, s params) {
    super(parama0, params);
  }
  
  private Animator a(float paramFloat1, float paramFloat2) {
    AnimatorSet animatorSet = new AnimatorSet();
    animatorSet.play((Animator)ObjectAnimator.ofFloat(this.u, "elevation", new float[] { paramFloat1 }).setDuration(0L)).with((Animator)ObjectAnimator.ofFloat(this.u, View.TRANSLATION_Z, new float[] { paramFloat2 }).setDuration(100L));
    animatorSet.setInterpolator(l.B);
    return (Animator)animatorSet;
  }
  
  void a(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (Build.VERSION.SDK_INT == 21) {
      this.u.refreshDrawableState();
    } else {
      StateListAnimator stateListAnimator = new StateListAnimator();
      stateListAnimator.addState(l.C, a(paramFloat1, paramFloat3));
      stateListAnimator.addState(l.D, a(paramFloat1, paramFloat2));
      stateListAnimator.addState(l.E, a(paramFloat1, paramFloat2));
      stateListAnimator.addState(l.F, a(paramFloat1, paramFloat2));
      AnimatorSet animatorSet = new AnimatorSet();
      ArrayList<ObjectAnimator> arrayList = new ArrayList();
      arrayList.add(ObjectAnimator.ofFloat(this.u, "elevation", new float[] { paramFloat1 }).setDuration(0L));
      int i = Build.VERSION.SDK_INT;
      if (i >= 22 && i <= 24) {
        a0 a0 = this.u;
        arrayList.add(ObjectAnimator.ofFloat(a0, View.TRANSLATION_Z, new float[] { a0.getTranslationZ() }).setDuration(100L));
      } 
      arrayList.add(ObjectAnimator.ofFloat(this.u, View.TRANSLATION_Z, new float[] { 0.0F }).setDuration(100L));
      animatorSet.playSequentially(arrayList.<Animator>toArray(new Animator[0]));
      animatorSet.setInterpolator(l.B);
      stateListAnimator.addState(l.G, (Animator)animatorSet);
      stateListAnimator.addState(l.H, a(0.0F, 0.0F));
      this.u.setStateListAnimator(stateListAnimator);
    } 
    if (this.v.b())
      s(); 
  }
  
  void a(ColorStateList paramColorStateList1, PorterDuff.Mode paramMode, ColorStateList paramColorStateList2, int paramInt) {
    this.j = android.support.v4.graphics.drawable.a.h((Drawable)a());
    android.support.v4.graphics.drawable.a.a(this.j, paramColorStateList1);
    if (paramMode != null)
      android.support.v4.graphics.drawable.a.a(this.j, paramMode); 
    if (paramInt > 0) {
      this.l = a(paramInt, paramColorStateList1);
      LayerDrawable layerDrawable = new LayerDrawable(new Drawable[] { this.l, this.j });
    } else {
      this.l = null;
      drawable = this.j;
    } 
    this.k = (Drawable)new RippleDrawable(a.b.c.q.a.a(paramColorStateList2), drawable, null);
    Drawable drawable = this.k;
    this.m = drawable;
    this.v.a(drawable);
  }
  
  void a(Rect paramRect) {
    if (this.v.b()) {
      float f2 = this.v.a();
      float f1 = c() + this.p;
      int j = (int)Math.ceil(r.a(f1, f2, false));
      int i = (int)Math.ceil(r.b(f1, f2, false));
      paramRect.set(j, i, j, i);
    } else {
      paramRect.set(0, 0, 0, 0);
    } 
  }
  
  void a(int[] paramArrayOfint) {
    if (Build.VERSION.SDK_INT == 21)
      if (this.u.isEnabled()) {
        this.u.setElevation(this.n);
        if (this.u.isPressed()) {
          this.u.setTranslationZ(this.p);
        } else {
          if (this.u.isFocused() || this.u.isHovered()) {
            this.u.setTranslationZ(this.o);
            return;
          } 
          this.u.setTranslationZ(0.0F);
        } 
      } else {
        this.u.setElevation(0.0F);
        this.u.setTranslationZ(0.0F);
      }  
  }
  
  void b(ColorStateList paramColorStateList) {
    Drawable drawable = this.k;
    if (drawable instanceof RippleDrawable) {
      ((RippleDrawable)drawable).setColor(a.b.c.q.a.a(paramColorStateList));
    } else {
      super.b(paramColorStateList);
    } 
  }
  
  void b(Rect paramRect) {
    if (this.v.b()) {
      this.I = new InsetDrawable(this.k, paramRect.left, paramRect.top, paramRect.right, paramRect.bottom);
      this.v.a((Drawable)this.I);
    } else {
      this.v.a(this.k);
    } 
  }
  
  public float c() {
    return this.u.getElevation();
  }
  
  void j() {}
  
  f k() {
    return new g();
  }
  
  GradientDrawable l() {
    return new a();
  }
  
  void n() {
    s();
  }
  
  boolean q() {
    return false;
  }
  
  static class a extends GradientDrawable {
    public boolean isStateful() {
      return true;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */