package android.support.design.widget;

import android.graphics.Outline;

public class g extends f {
  public void getOutline(Outline paramOutline) {
    copyBounds(this.b);
    paramOutline.setOval(this.b);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */