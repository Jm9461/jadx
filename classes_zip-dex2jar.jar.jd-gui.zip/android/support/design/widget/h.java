package android.support.design.widget;

import a.b.c.l.a;
import a.b.g.c.a;
import a.b.g.f.c;
import a.b.g.f.d;
import a.b.h.a.j;
import android.animation.TimeInterpolator;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Build;
import android.support.v4.view.d;
import android.support.v4.view.u;
import android.support.v7.widget.j1;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.View;

public final class h {
  private static final boolean T;
  
  private static final Paint U = null;
  
  private Paint A;
  
  private float B;
  
  private float C;
  
  private float D;
  
  private float E;
  
  private int[] F;
  
  private boolean G;
  
  private final TextPaint H;
  
  private final TextPaint I;
  
  private TimeInterpolator J;
  
  private TimeInterpolator K;
  
  private float L;
  
  private float M;
  
  private float N;
  
  private int O;
  
  private float P;
  
  private float Q;
  
  private float R;
  
  private int S;
  
  private final View a;
  
  private boolean b;
  
  private float c;
  
  private final Rect d;
  
  private final Rect e;
  
  private final RectF f;
  
  private int g = 16;
  
  private int h = 16;
  
  private float i = 15.0F;
  
  private float j = 15.0F;
  
  private ColorStateList k;
  
  private ColorStateList l;
  
  private float m;
  
  private float n;
  
  private float o;
  
  private float p;
  
  private float q;
  
  private float r;
  
  private Typeface s;
  
  private Typeface t;
  
  private Typeface u;
  
  private CharSequence v;
  
  private CharSequence w;
  
  private boolean x;
  
  private boolean y;
  
  private Bitmap z;
  
  static {
    Paint paint = U;
    if (paint != null) {
      paint.setAntiAlias(true);
      U.setColor(-65281);
    } 
  }
  
  public h(View paramView) {
    this.a = paramView;
    this.H = new TextPaint(129);
    this.I = new TextPaint((Paint)this.H);
    this.e = new Rect();
    this.d = new Rect();
    this.f = new RectF();
  }
  
  private static float a(float paramFloat1, float paramFloat2, float paramFloat3, TimeInterpolator paramTimeInterpolator) {
    float f = paramFloat3;
    if (paramTimeInterpolator != null)
      f = paramTimeInterpolator.getInterpolation(paramFloat3); 
    return a.a(paramFloat1, paramFloat2, f);
  }
  
  private static int a(int paramInt1, int paramInt2, float paramFloat) {
    float f7 = 1.0F - paramFloat;
    float f6 = Color.alpha(paramInt1);
    float f8 = Color.alpha(paramInt2);
    float f3 = Color.red(paramInt1);
    float f4 = Color.red(paramInt2);
    float f5 = Color.green(paramInt1);
    float f1 = Color.green(paramInt2);
    float f2 = Color.blue(paramInt1);
    float f9 = Color.blue(paramInt2);
    return Color.argb((int)(f6 * f7 + f8 * paramFloat), (int)(f3 * f7 + f4 * paramFloat), (int)(f5 * f7 + f1 * paramFloat), (int)(f2 * f7 + f9 * paramFloat));
  }
  
  private void a(TextPaint paramTextPaint) {
    paramTextPaint.setTextSize(this.j);
    paramTextPaint.setTypeface(this.s);
  }
  
  private static boolean a(float paramFloat1, float paramFloat2) {
    boolean bool;
    if (Math.abs(paramFloat1 - paramFloat2) < 0.001F) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private static boolean a(Rect paramRect, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    boolean bool;
    if (paramRect.left == paramInt1 && paramRect.top == paramInt2 && paramRect.right == paramInt3 && paramRect.bottom == paramInt4) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private boolean b(CharSequence paramCharSequence) {
    c c;
    int i = u.k(this.a);
    boolean bool = true;
    if (i != 1)
      bool = false; 
    if (bool) {
      c = d.b;
    } else {
      c = d.a;
    } 
    return c.a(paramCharSequence, 0, paramCharSequence.length());
  }
  
  private void c(float paramFloat) {
    e(paramFloat);
    this.q = a(this.o, this.p, paramFloat, this.J);
    this.r = a(this.m, this.n, paramFloat, this.J);
    f(a(this.i, this.j, paramFloat, this.K));
    if (this.l != this.k) {
      this.H.setColor(a(m(), d(), paramFloat));
    } else {
      this.H.setColor(d());
    } 
    this.H.setShadowLayer(a(this.P, this.L, paramFloat, (TimeInterpolator)null), a(this.Q, this.M, paramFloat, (TimeInterpolator)null), a(this.R, this.N, paramFloat, (TimeInterpolator)null), a(this.S, this.O, paramFloat));
    u.B(this.a);
  }
  
  private Typeface d(int paramInt) {
    TypedArray typedArray = this.a.getContext().obtainStyledAttributes(paramInt, new int[] { 16843692 });
    try {
      String str = typedArray.getString(0);
      if (str != null)
        return Typeface.create(str, 0); 
      return null;
    } finally {
      typedArray.recycle();
    } 
  }
  
  private void d(float paramFloat) {
    float f1;
    if (this.v == null)
      return; 
    float f2 = this.e.width();
    float f3 = this.d.width();
    boolean bool1 = false;
    boolean bool2 = false;
    if (a(paramFloat, this.j)) {
      f1 = this.j;
      this.D = 1.0F;
      Typeface typeface1 = this.u;
      Typeface typeface2 = this.s;
      bool1 = bool2;
      if (typeface1 != typeface2) {
        this.u = typeface2;
        bool1 = true;
      } 
      paramFloat = f2;
    } else {
      f1 = this.i;
      Typeface typeface2 = this.u;
      Typeface typeface1 = this.t;
      if (typeface2 != typeface1) {
        this.u = typeface1;
        bool1 = true;
      } 
      if (a(paramFloat, this.i)) {
        this.D = 1.0F;
      } else {
        this.D = paramFloat / this.i;
      } 
      paramFloat = this.j / this.i;
      if (f3 * paramFloat > f2) {
        paramFloat = Math.min(f2 / paramFloat, f3);
      } else {
        paramFloat = f3;
      } 
    } 
    boolean bool3 = true;
    bool2 = bool1;
    if (paramFloat > 0.0F) {
      if (this.E != f1 || this.G || bool1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.E = f1;
      this.G = false;
      bool2 = bool1;
    } 
    if (this.w == null || bool2) {
      this.H.setTextSize(this.E);
      this.H.setTypeface(this.u);
      TextPaint textPaint = this.H;
      if (this.D == 1.0F)
        bool3 = false; 
      textPaint.setLinearText(bool3);
      CharSequence charSequence = TextUtils.ellipsize(this.v, this.H, paramFloat, TextUtils.TruncateAt.END);
      if (!TextUtils.equals(charSequence, this.w)) {
        this.w = charSequence;
        this.x = b(this.w);
      } 
    } 
  }
  
  private void e(float paramFloat) {
    this.f.left = a(this.d.left, this.e.left, paramFloat, this.J);
    this.f.top = a(this.m, this.n, paramFloat, this.J);
    this.f.right = a(this.d.right, this.e.right, paramFloat, this.J);
    this.f.bottom = a(this.d.bottom, this.e.bottom, paramFloat, this.J);
  }
  
  private void f(float paramFloat) {
    boolean bool;
    d(paramFloat);
    if (T && this.D != 1.0F) {
      bool = true;
    } else {
      bool = false;
    } 
    this.y = bool;
    if (this.y)
      l(); 
    u.B(this.a);
  }
  
  private void i() {
    float f3 = this.E;
    d(this.j);
    CharSequence charSequence = this.w;
    float f2 = 0.0F;
    if (charSequence != null) {
      f1 = this.H.measureText(charSequence, 0, charSequence.length());
    } else {
      f1 = 0.0F;
    } 
    int j = d.a(this.h, this.x);
    int i = j & 0x70;
    if (i != 48) {
      if (i != 80) {
        float f5 = (this.H.descent() - this.H.ascent()) / 2.0F;
        float f4 = this.H.descent();
        this.n = this.e.centerY() + f5 - f4;
      } else {
        this.n = this.e.bottom;
      } 
    } else {
      this.n = this.e.top - this.H.ascent();
    } 
    i = j & 0x800007;
    if (i != 1) {
      if (i != 5) {
        this.p = this.e.left;
      } else {
        this.p = this.e.right - f1;
      } 
    } else {
      this.p = this.e.centerX() - f1 / 2.0F;
    } 
    d(this.i);
    charSequence = this.w;
    float f1 = f2;
    if (charSequence != null)
      f1 = this.H.measureText(charSequence, 0, charSequence.length()); 
    j = d.a(this.g, this.x);
    i = j & 0x70;
    if (i != 48) {
      if (i != 80) {
        float f = (this.H.descent() - this.H.ascent()) / 2.0F;
        f2 = this.H.descent();
        this.m = this.d.centerY() + f - f2;
      } else {
        this.m = this.d.bottom;
      } 
    } else {
      this.m = this.d.top - this.H.ascent();
    } 
    i = j & 0x800007;
    if (i != 1) {
      if (i != 5) {
        this.o = this.d.left;
      } else {
        this.o = this.d.right - f1;
      } 
    } else {
      this.o = this.d.centerX() - f1 / 2.0F;
    } 
    k();
    f(f3);
  }
  
  private void j() {
    c(this.c);
  }
  
  private void k() {
    Bitmap bitmap = this.z;
    if (bitmap != null) {
      bitmap.recycle();
      this.z = null;
    } 
  }
  
  private void l() {
    if (this.z != null || this.d.isEmpty() || TextUtils.isEmpty(this.w))
      return; 
    c(0.0F);
    this.B = this.H.ascent();
    this.C = this.H.descent();
    TextPaint textPaint = this.H;
    CharSequence charSequence2 = this.w;
    int i = Math.round(textPaint.measureText(charSequence2, 0, charSequence2.length()));
    int j = Math.round(this.C - this.B);
    if (i <= 0 || j <= 0)
      return; 
    this.z = Bitmap.createBitmap(i, j, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(this.z);
    CharSequence charSequence1 = this.w;
    canvas.drawText(charSequence1, 0, charSequence1.length(), 0.0F, j - this.H.descent(), (Paint)this.H);
    if (this.A == null)
      this.A = new Paint(3); 
  }
  
  private int m() {
    int[] arrayOfInt = this.F;
    return (arrayOfInt != null) ? this.k.getColorForState(arrayOfInt, 0) : this.k.getDefaultColor();
  }
  
  public float a() {
    if (this.v == null)
      return 0.0F; 
    a(this.I);
    TextPaint textPaint = this.I;
    CharSequence charSequence = this.v;
    return textPaint.measureText(charSequence, 0, charSequence.length());
  }
  
  public void a(float paramFloat) {
    if (this.i != paramFloat) {
      this.i = paramFloat;
      h();
    } 
  }
  
  public void a(int paramInt) {
    j1 j1 = j1.a(this.a.getContext(), paramInt, j.TextAppearance);
    if (j1.g(j.TextAppearance_android_textColor))
      this.l = j1.a(j.TextAppearance_android_textColor); 
    if (j1.g(j.TextAppearance_android_textSize))
      this.j = j1.c(j.TextAppearance_android_textSize, (int)this.j); 
    this.O = j1.d(j.TextAppearance_android_shadowColor, 0);
    this.M = j1.b(j.TextAppearance_android_shadowDx, 0.0F);
    this.N = j1.b(j.TextAppearance_android_shadowDy, 0.0F);
    this.L = j1.b(j.TextAppearance_android_shadowRadius, 0.0F);
    j1.a();
    if (Build.VERSION.SDK_INT >= 16)
      this.s = d(paramInt); 
    h();
  }
  
  public void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!a(this.e, paramInt1, paramInt2, paramInt3, paramInt4)) {
      this.e.set(paramInt1, paramInt2, paramInt3, paramInt4);
      this.G = true;
      g();
    } 
  }
  
  public void a(TimeInterpolator paramTimeInterpolator) {
    this.J = paramTimeInterpolator;
    h();
  }
  
  public void a(ColorStateList paramColorStateList) {
    if (this.l != paramColorStateList) {
      this.l = paramColorStateList;
      h();
    } 
  }
  
  public void a(Canvas paramCanvas) {
    int i = paramCanvas.save();
    if (this.w != null && this.b) {
      float f1;
      boolean bool;
      float f3 = this.q;
      float f2 = this.r;
      if (this.y && this.z != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        float f4 = this.B;
        f1 = this.D;
        float f5 = this.C;
        f1 = f4 * f1;
      } else {
        float f5 = this.H.ascent();
        f1 = this.D;
        this.H.descent();
        float f4 = this.D;
        f1 = f5 * f1;
      } 
      if (bool) {
        f1 = f2 + f1;
      } else {
        f1 = f2;
      } 
      f2 = this.D;
      if (f2 != 1.0F)
        paramCanvas.scale(f2, f2, f3, f1); 
      if (bool) {
        paramCanvas.drawBitmap(this.z, f3, f1, this.A);
      } else {
        CharSequence charSequence = this.w;
        paramCanvas.drawText(charSequence, 0, charSequence.length(), f3, f1, (Paint)this.H);
      } 
    } 
    paramCanvas.restoreToCount(i);
  }
  
  public void a(RectF paramRectF) {
    float f;
    boolean bool = b(this.v);
    Rect rect = this.e;
    if (!bool) {
      f = rect.left;
    } else {
      f = rect.right - a();
    } 
    paramRectF.left = f;
    rect = this.e;
    paramRectF.top = rect.top;
    if (!bool) {
      f = paramRectF.left + a();
    } else {
      f = rect.right;
    } 
    paramRectF.right = f;
    paramRectF.bottom = this.e.top + c();
  }
  
  public void a(Typeface paramTypeface) {
    this.t = paramTypeface;
    this.s = paramTypeface;
    h();
  }
  
  public void a(CharSequence paramCharSequence) {
    if (paramCharSequence == null || !paramCharSequence.equals(this.v)) {
      this.v = paramCharSequence;
      this.w = null;
      k();
      h();
    } 
  }
  
  public final boolean a(int[] paramArrayOfint) {
    this.F = paramArrayOfint;
    if (f()) {
      h();
      return true;
    } 
    return false;
  }
  
  public ColorStateList b() {
    return this.l;
  }
  
  public void b(float paramFloat) {
    paramFloat = a.a(paramFloat, 0.0F, 1.0F);
    if (paramFloat != this.c) {
      this.c = paramFloat;
      j();
    } 
  }
  
  public void b(int paramInt) {
    if (this.h != paramInt) {
      this.h = paramInt;
      h();
    } 
  }
  
  public void b(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!a(this.d, paramInt1, paramInt2, paramInt3, paramInt4)) {
      this.d.set(paramInt1, paramInt2, paramInt3, paramInt4);
      this.G = true;
      g();
    } 
  }
  
  public void b(TimeInterpolator paramTimeInterpolator) {
    this.K = paramTimeInterpolator;
    h();
  }
  
  public void b(ColorStateList paramColorStateList) {
    if (this.k != paramColorStateList) {
      this.k = paramColorStateList;
      h();
    } 
  }
  
  public float c() {
    a(this.I);
    return -this.I.ascent();
  }
  
  public void c(int paramInt) {
    if (this.g != paramInt) {
      this.g = paramInt;
      h();
    } 
  }
  
  public int d() {
    int[] arrayOfInt = this.F;
    return (arrayOfInt != null) ? this.l.getColorForState(arrayOfInt, 0) : this.l.getDefaultColor();
  }
  
  public float e() {
    return this.c;
  }
  
  public final boolean f() {
    ColorStateList colorStateList = this.l;
    if (colorStateList == null || !colorStateList.isStateful()) {
      colorStateList = this.k;
      return (colorStateList != null && colorStateList.isStateful());
    } 
    return true;
  }
  
  void g() {
    boolean bool;
    if (this.e.width() > 0 && this.e.height() > 0 && this.d.width() > 0 && this.d.height() > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.b = bool;
  }
  
  public void h() {
    if (this.a.getHeight() > 0 && this.a.getWidth() > 0) {
      i();
      j();
    } 
  }
  
  static {
    boolean bool;
    if (Build.VERSION.SDK_INT < 18) {
      bool = true;
    } else {
      bool = false;
    } 
    T = bool;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */