package android.support.design.widget;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Xfermode;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.View;

class i extends GradientDrawable {
  private final Paint a = new Paint(1);
  
  private final RectF b;
  
  private int c;
  
  i() {
    c();
    this.b = new RectF();
  }
  
  private void a(Canvas paramCanvas) {
    if (!a(getCallback()))
      paramCanvas.restoreToCount(this.c); 
  }
  
  private boolean a(Drawable.Callback paramCallback) {
    return paramCallback instanceof View;
  }
  
  private void b(Canvas paramCanvas) {
    Drawable.Callback callback = getCallback();
    if (a(callback)) {
      ((View)callback).setLayerType(2, null);
    } else {
      c(paramCanvas);
    } 
  }
  
  private void c() {
    this.a.setStyle(Paint.Style.FILL_AND_STROKE);
    this.a.setColor(-1);
    this.a.setXfermode((Xfermode)new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
  }
  
  private void c(Canvas paramCanvas) {
    if (Build.VERSION.SDK_INT >= 21) {
      this.c = paramCanvas.saveLayer(0.0F, 0.0F, paramCanvas.getWidth(), paramCanvas.getHeight(), null);
    } else {
      this.c = paramCanvas.saveLayer(0.0F, 0.0F, paramCanvas.getWidth(), paramCanvas.getHeight(), null, 31);
    } 
  }
  
  void a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    RectF rectF = this.b;
    if (paramFloat1 != rectF.left || paramFloat2 != rectF.top || paramFloat3 != rectF.right || paramFloat4 != rectF.bottom) {
      this.b.set(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
      invalidateSelf();
    } 
  }
  
  void a(RectF paramRectF) {
    a(paramRectF.left, paramRectF.top, paramRectF.right, paramRectF.bottom);
  }
  
  boolean a() {
    return this.b.isEmpty() ^ true;
  }
  
  void b() {
    a(0.0F, 0.0F, 0.0F, 0.0F);
  }
  
  public void draw(Canvas paramCanvas) {
    b(paramCanvas);
    super.draw(paramCanvas);
    paramCanvas.drawRect(this.b, this.a);
    a(paramCanvas);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */