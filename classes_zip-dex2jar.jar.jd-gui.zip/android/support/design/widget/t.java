package android.support.design.widget;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.lang.ref.WeakReference;

class t {
  private static t e;
  
  private final Object a = new Object();
  
  private final Handler b = new Handler(Looper.getMainLooper(), new a(this));
  
  private c c;
  
  private c d;
  
  static t a() {
    if (e == null)
      e = new t(); 
    return e;
  }
  
  private boolean a(c paramc, int paramInt) {
    b b = paramc.a.get();
    if (b != null) {
      this.b.removeCallbacksAndMessages(paramc);
      b.a(paramInt);
      return true;
    } 
    return false;
  }
  
  private void b(c paramc) {
    int j = paramc.b;
    if (j == -2)
      return; 
    int i = 2750;
    if (j > 0) {
      i = paramc.b;
    } else if (j == -1) {
      i = 1500;
    } 
    this.b.removeCallbacksAndMessages(paramc);
    Handler handler = this.b;
    handler.sendMessageDelayed(Message.obtain(handler, 0, paramc), i);
  }
  
  private boolean c(b paramb) {
    boolean bool;
    c c1 = this.c;
    if (c1 != null && c1.a(paramb)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void a(b paramb) {
    synchronized (this.a) {
      if (c(paramb) && !this.c.c) {
        this.c.c = true;
        this.b.removeCallbacksAndMessages(this.c);
      } 
      return;
    } 
  }
  
  void a(c paramc) {
    synchronized (this.a) {
      if (this.c == paramc || this.d == paramc)
        a(paramc, 2); 
      return;
    } 
  }
  
  public void b(b paramb) {
    synchronized (this.a) {
      if (c(paramb) && this.c.c) {
        this.c.c = false;
        b(this.c);
      } 
      return;
    } 
  }
  
  class a implements Handler.Callback {
    final t a;
    
    a(t this$0) {}
    
    public boolean handleMessage(Message param1Message) {
      if (param1Message.what != 0)
        return false; 
      this.a.a((t.c)param1Message.obj);
      return true;
    }
  }
  
  static interface b {
    void a(int param1Int);
  }
  
  private static class c {
    final WeakReference<t.b> a;
    
    int b;
    
    boolean c;
    
    boolean a(t.b param1b) {
      boolean bool;
      if (param1b != null && this.a.get() == param1b) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */