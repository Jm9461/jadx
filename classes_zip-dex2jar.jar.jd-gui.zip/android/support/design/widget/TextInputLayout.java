package android.support.design.widget;

import a.b.c.f;
import a.b.c.h;
import a.b.c.i;
import a.b.c.j;
import a.b.c.k;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.design.internal.g;
import android.support.design.internal.h;
import android.support.v4.view.u;
import android.support.v4.widget.p;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.h0;
import android.support.v7.widget.j;
import android.support.v7.widget.j1;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStructure;
import android.view.accessibility.AccessibilityEvent;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class TextInputLayout extends LinearLayout {
  private final int A;
  
  private int B;
  
  private int C;
  
  private Drawable D;
  
  private final Rect E = new Rect();
  
  private final RectF F = new RectF();
  
  private Typeface G;
  
  private boolean H;
  
  private Drawable I;
  
  private CharSequence J;
  
  private CheckableImageButton K;
  
  private boolean L;
  
  private Drawable M;
  
  private Drawable N;
  
  private ColorStateList O;
  
  private boolean P;
  
  private PorterDuff.Mode Q;
  
  private boolean R;
  
  private ColorStateList S;
  
  private ColorStateList T;
  
  private final int U;
  
  private final int V;
  
  private int W;
  
  private final int a0;
  
  private boolean b0;
  
  private final FrameLayout c;
  
  final h c0 = new h((View)this);
  
  EditText d;
  
  private boolean d0;
  
  private CharSequence e;
  
  private ValueAnimator e0;
  
  private final p f = new p(this);
  
  private boolean f0;
  
  boolean g;
  
  private boolean g0;
  
  private int h;
  
  private boolean h0;
  
  private boolean i;
  
  private TextView j;
  
  private final int k;
  
  private final int l;
  
  private boolean m;
  
  private CharSequence n;
  
  private boolean o;
  
  private GradientDrawable p;
  
  private final int q;
  
  private final int r;
  
  private int s;
  
  private final int t;
  
  private float u;
  
  private float v;
  
  private float w;
  
  private float x;
  
  private int y;
  
  private final int z;
  
  public TextInputLayout(Context paramContext) {
    this(paramContext, null);
  }
  
  public TextInputLayout(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.b.c.b.textInputStyle);
  }
  
  public TextInputLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    setOrientation(1);
    setWillNotDraw(false);
    setAddStatesFromChildren(true);
    this.c = new FrameLayout(paramContext);
    this.c.setAddStatesFromChildren(true);
    addView((View)this.c);
    this.c0.b(a.b.c.l.a.a);
    this.c0.a(a.b.c.l.a.a);
    this.c0.b(8388659);
    j1 j1 = g.d(paramContext, paramAttributeSet, k.TextInputLayout, paramInt, j.Widget_Design_TextInputLayout, new int[0]);
    this.m = j1.a(k.TextInputLayout_hintEnabled, true);
    setHint(j1.e(k.TextInputLayout_android_hint));
    this.d0 = j1.a(k.TextInputLayout_hintAnimationEnabled, true);
    this.q = paramContext.getResources().getDimensionPixelOffset(a.b.c.d.mtrl_textinput_box_bottom_offset);
    this.r = paramContext.getResources().getDimensionPixelOffset(a.b.c.d.mtrl_textinput_box_label_cutout_padding);
    this.t = j1.b(k.TextInputLayout_boxCollapsedPaddingTop, 0);
    this.u = j1.a(k.TextInputLayout_boxCornerRadiusTopStart, 0.0F);
    this.v = j1.a(k.TextInputLayout_boxCornerRadiusTopEnd, 0.0F);
    this.w = j1.a(k.TextInputLayout_boxCornerRadiusBottomEnd, 0.0F);
    this.x = j1.a(k.TextInputLayout_boxCornerRadiusBottomStart, 0.0F);
    this.C = j1.a(k.TextInputLayout_boxBackgroundColor, 0);
    this.W = j1.a(k.TextInputLayout_boxStrokeColor, 0);
    this.z = paramContext.getResources().getDimensionPixelSize(a.b.c.d.mtrl_textinput_box_stroke_width_default);
    this.A = paramContext.getResources().getDimensionPixelSize(a.b.c.d.mtrl_textinput_box_stroke_width_focused);
    this.y = this.z;
    setBoxBackgroundMode(j1.d(k.TextInputLayout_boxBackgroundMode, 0));
    if (j1.g(k.TextInputLayout_android_textColorHint)) {
      ColorStateList colorStateList = j1.a(k.TextInputLayout_android_textColorHint);
      this.T = colorStateList;
      this.S = colorStateList;
    } 
    this.U = android.support.v4.content.a.a(paramContext, a.b.c.c.mtrl_textinput_default_box_stroke_color);
    this.a0 = android.support.v4.content.a.a(paramContext, a.b.c.c.mtrl_textinput_disabled_color);
    this.V = android.support.v4.content.a.a(paramContext, a.b.c.c.mtrl_textinput_hovered_box_stroke_color);
    if (j1.g(k.TextInputLayout_hintTextAppearance, -1) != -1)
      setHintTextAppearance(j1.g(k.TextInputLayout_hintTextAppearance, 0)); 
    int i = j1.g(k.TextInputLayout_errorTextAppearance, 0);
    boolean bool3 = j1.a(k.TextInputLayout_errorEnabled, false);
    paramInt = j1.g(k.TextInputLayout_helperTextTextAppearance, 0);
    boolean bool1 = j1.a(k.TextInputLayout_helperTextEnabled, false);
    CharSequence charSequence = j1.e(k.TextInputLayout_helperText);
    boolean bool2 = j1.a(k.TextInputLayout_counterEnabled, false);
    setCounterMaxLength(j1.d(k.TextInputLayout_counterMaxLength, -1));
    this.l = j1.g(k.TextInputLayout_counterTextAppearance, 0);
    this.k = j1.g(k.TextInputLayout_counterOverflowTextAppearance, 0);
    this.H = j1.a(k.TextInputLayout_passwordToggleEnabled, false);
    this.I = j1.b(k.TextInputLayout_passwordToggleDrawable);
    this.J = j1.e(k.TextInputLayout_passwordToggleContentDescription);
    if (j1.g(k.TextInputLayout_passwordToggleTint)) {
      this.P = true;
      this.O = j1.a(k.TextInputLayout_passwordToggleTint);
    } 
    if (j1.g(k.TextInputLayout_passwordToggleTintMode)) {
      this.R = true;
      this.Q = h.a(j1.d(k.TextInputLayout_passwordToggleTintMode, -1), null);
    } 
    j1.a();
    setHelperTextEnabled(bool1);
    setHelperText(charSequence);
    setHelperTextTextAppearance(paramInt);
    setErrorEnabled(bool3);
    setErrorTextAppearance(i);
    setCounterEnabled(bool2);
    f();
    u.f((View)this, 2);
  }
  
  private void a(RectF paramRectF) {
    float f = paramRectF.left;
    int i = this.r;
    paramRectF.left = f - i;
    paramRectF.top -= i;
    paramRectF.right += i;
    paramRectF.bottom += i;
  }
  
  private static void a(ViewGroup paramViewGroup, boolean paramBoolean) {
    byte b = 0;
    int i = paramViewGroup.getChildCount();
    while (b < i) {
      View view = paramViewGroup.getChildAt(b);
      view.setEnabled(paramBoolean);
      if (view instanceof ViewGroup)
        a((ViewGroup)view, paramBoolean); 
      b++;
    } 
  }
  
  private void a(boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual isEnabled : ()Z
    //   4: istore #5
    //   6: aload_0
    //   7: getfield d : Landroid/widget/EditText;
    //   10: astore #7
    //   12: iconst_1
    //   13: istore #4
    //   15: aload #7
    //   17: ifnull -> 36
    //   20: aload #7
    //   22: invokevirtual getText : ()Landroid/text/Editable;
    //   25: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   28: ifne -> 36
    //   31: iconst_1
    //   32: istore_3
    //   33: goto -> 38
    //   36: iconst_0
    //   37: istore_3
    //   38: aload_0
    //   39: getfield d : Landroid/widget/EditText;
    //   42: astore #7
    //   44: aload #7
    //   46: ifnull -> 60
    //   49: aload #7
    //   51: invokevirtual hasFocus : ()Z
    //   54: ifeq -> 60
    //   57: goto -> 63
    //   60: iconst_0
    //   61: istore #4
    //   63: aload_0
    //   64: getfield f : Landroid/support/design/widget/p;
    //   67: invokevirtual c : ()Z
    //   70: istore #6
    //   72: aload_0
    //   73: getfield S : Landroid/content/res/ColorStateList;
    //   76: astore #7
    //   78: aload #7
    //   80: ifnull -> 103
    //   83: aload_0
    //   84: getfield c0 : Landroid/support/design/widget/h;
    //   87: aload #7
    //   89: invokevirtual a : (Landroid/content/res/ColorStateList;)V
    //   92: aload_0
    //   93: getfield c0 : Landroid/support/design/widget/h;
    //   96: aload_0
    //   97: getfield S : Landroid/content/res/ColorStateList;
    //   100: invokevirtual b : (Landroid/content/res/ColorStateList;)V
    //   103: iload #5
    //   105: ifne -> 139
    //   108: aload_0
    //   109: getfield c0 : Landroid/support/design/widget/h;
    //   112: aload_0
    //   113: getfield a0 : I
    //   116: invokestatic valueOf : (I)Landroid/content/res/ColorStateList;
    //   119: invokevirtual a : (Landroid/content/res/ColorStateList;)V
    //   122: aload_0
    //   123: getfield c0 : Landroid/support/design/widget/h;
    //   126: aload_0
    //   127: getfield a0 : I
    //   130: invokestatic valueOf : (I)Landroid/content/res/ColorStateList;
    //   133: invokevirtual b : (Landroid/content/res/ColorStateList;)V
    //   136: goto -> 219
    //   139: iload #6
    //   141: ifeq -> 161
    //   144: aload_0
    //   145: getfield c0 : Landroid/support/design/widget/h;
    //   148: aload_0
    //   149: getfield f : Landroid/support/design/widget/p;
    //   152: invokevirtual f : ()Landroid/content/res/ColorStateList;
    //   155: invokevirtual a : (Landroid/content/res/ColorStateList;)V
    //   158: goto -> 219
    //   161: aload_0
    //   162: getfield i : Z
    //   165: ifeq -> 194
    //   168: aload_0
    //   169: getfield j : Landroid/widget/TextView;
    //   172: astore #7
    //   174: aload #7
    //   176: ifnull -> 194
    //   179: aload_0
    //   180: getfield c0 : Landroid/support/design/widget/h;
    //   183: aload #7
    //   185: invokevirtual getTextColors : ()Landroid/content/res/ColorStateList;
    //   188: invokevirtual a : (Landroid/content/res/ColorStateList;)V
    //   191: goto -> 219
    //   194: iload #4
    //   196: ifeq -> 219
    //   199: aload_0
    //   200: getfield T : Landroid/content/res/ColorStateList;
    //   203: astore #7
    //   205: aload #7
    //   207: ifnull -> 219
    //   210: aload_0
    //   211: getfield c0 : Landroid/support/design/widget/h;
    //   214: aload #7
    //   216: invokevirtual a : (Landroid/content/res/ColorStateList;)V
    //   219: iload_3
    //   220: ifne -> 262
    //   223: aload_0
    //   224: invokevirtual isEnabled : ()Z
    //   227: ifeq -> 243
    //   230: iload #4
    //   232: ifne -> 262
    //   235: iload #6
    //   237: ifeq -> 243
    //   240: goto -> 262
    //   243: iload_2
    //   244: ifne -> 254
    //   247: aload_0
    //   248: getfield b0 : Z
    //   251: ifne -> 278
    //   254: aload_0
    //   255: iload_1
    //   256: invokespecial d : (Z)V
    //   259: goto -> 278
    //   262: iload_2
    //   263: ifne -> 273
    //   266: aload_0
    //   267: getfield b0 : Z
    //   270: ifeq -> 278
    //   273: aload_0
    //   274: iload_1
    //   275: invokespecial c : (Z)V
    //   278: return
  }
  
  private void c(boolean paramBoolean) {
    ValueAnimator valueAnimator = this.e0;
    if (valueAnimator != null && valueAnimator.isRunning())
      this.e0.cancel(); 
    if (paramBoolean && this.d0) {
      a(1.0F);
    } else {
      this.c0.b(1.0F);
    } 
    this.b0 = false;
    if (l())
      p(); 
  }
  
  private void d(boolean paramBoolean) {
    ValueAnimator valueAnimator = this.e0;
    if (valueAnimator != null && valueAnimator.isRunning())
      this.e0.cancel(); 
    if (paramBoolean && this.d0) {
      a(0.0F);
    } else {
      this.c0.b(0.0F);
    } 
    if (l() && ((i)this.p).a())
      k(); 
    this.b0 = true;
  }
  
  private void e() {
    if (this.p == null)
      return; 
    q();
    EditText editText1 = this.d;
    if (editText1 != null && this.s == 2) {
      if (editText1.getBackground() != null)
        this.D = this.d.getBackground(); 
      u.a((View)this.d, null);
    } 
    EditText editText2 = this.d;
    if (editText2 != null && this.s == 1) {
      Drawable drawable = this.D;
      if (drawable != null)
        u.a((View)editText2, drawable); 
    } 
    int i = this.y;
    if (i > -1) {
      int j = this.B;
      if (j != 0)
        this.p.setStroke(i, j); 
    } 
    this.p.setCornerRadii(getCornerRadiiAsArray());
    this.p.setColor(this.C);
    invalidate();
  }
  
  private void f() {
    if (this.I != null && (this.P || this.R)) {
      this.I = android.support.v4.graphics.drawable.a.h(this.I).mutate();
      if (this.P)
        android.support.v4.graphics.drawable.a.a(this.I, this.O); 
      if (this.R)
        android.support.v4.graphics.drawable.a.a(this.I, this.Q); 
      CheckableImageButton checkableImageButton = this.K;
      if (checkableImageButton != null) {
        Drawable drawable1 = checkableImageButton.getDrawable();
        Drawable drawable2 = this.I;
        if (drawable1 != drawable2)
          this.K.setImageDrawable(drawable2); 
      } 
    } 
  }
  
  private void g() {
    int i = this.s;
    if (i == 0) {
      this.p = null;
    } else if (i == 2 && this.m && !(this.p instanceof i)) {
      this.p = new i();
    } else if (!(this.p instanceof GradientDrawable)) {
      this.p = new GradientDrawable();
    } 
  }
  
  private Drawable getBoxBackground() {
    int i = this.s;
    if (i == 1 || i == 2)
      return (Drawable)this.p; 
    throw new IllegalStateException();
  }
  
  private float[] getCornerRadiiAsArray() {
    if (!h.a((View)this)) {
      float f8 = this.u;
      float f5 = this.v;
      float f7 = this.w;
      float f6 = this.x;
      return new float[] { f8, f8, f5, f5, f7, f7, f6, f6 };
    } 
    float f3 = this.v;
    float f2 = this.u;
    float f4 = this.x;
    float f1 = this.w;
    return new float[] { f3, f3, f2, f2, f4, f4, f1, f1 };
  }
  
  private int h() {
    EditText editText = this.d;
    if (editText == null)
      return 0; 
    int i = this.s;
    return (i != 1) ? ((i != 2) ? 0 : (editText.getTop() + j())) : editText.getTop();
  }
  
  private int i() {
    int i = this.s;
    return (i != 1) ? ((i != 2) ? getPaddingTop() : ((getBoxBackground().getBounds()).top - j())) : ((getBoxBackground().getBounds()).top + this.t);
  }
  
  private int j() {
    if (!this.m)
      return 0; 
    int i = this.s;
    return (i != 0 && i != 1) ? ((i != 2) ? 0 : (int)(this.c0.c() / 2.0F)) : (int)this.c0.c();
  }
  
  private void k() {
    if (l())
      ((i)this.p).b(); 
  }
  
  private boolean l() {
    boolean bool;
    if (this.m && !TextUtils.isEmpty(this.n) && this.p instanceof i) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private void m() {
    int i = Build.VERSION.SDK_INT;
    if (i != 21 && i != 22)
      return; 
    Drawable drawable = this.d.getBackground();
    if (drawable == null)
      return; 
    if (!this.f0) {
      Drawable drawable1 = drawable.getConstantState().newDrawable();
      if (drawable instanceof DrawableContainer)
        this.f0 = k.a((DrawableContainer)drawable, drawable1.getConstantState()); 
      if (!this.f0) {
        u.a((View)this.d, drawable1);
        this.f0 = true;
        o();
      } 
    } 
  }
  
  private boolean n() {
    boolean bool;
    EditText editText = this.d;
    if (editText != null && editText.getTransformationMethod() instanceof PasswordTransformationMethod) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private void o() {
    g();
    if (this.s != 0)
      t(); 
    v();
  }
  
  private void p() {
    if (!l())
      return; 
    RectF rectF = this.F;
    this.c0.a(rectF);
    a(rectF);
    ((i)this.p).a(rectF);
  }
  
  private void q() {
    int i = this.s;
    if (i != 1) {
      if (i == 2 && this.W == 0)
        this.W = this.T.getColorForState(getDrawableState(), this.T.getDefaultColor()); 
    } else {
      this.y = 0;
    } 
  }
  
  private boolean r() {
    boolean bool;
    if (this.H && (n() || this.L)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private void s() {
    EditText editText = this.d;
    if (editText == null)
      return; 
    Drawable drawable2 = editText.getBackground();
    if (drawable2 == null)
      return; 
    Drawable drawable1 = drawable2;
    if (h0.a(drawable2))
      drawable1 = drawable2.mutate(); 
    Rect rect = new Rect();
    j.a((ViewGroup)this, (View)this.d, rect);
    rect = drawable1.getBounds();
    if (rect.left != rect.right) {
      Rect rect1 = new Rect();
      drawable1.getPadding(rect1);
      int i = rect.left;
      int m = rect1.left;
      int j = rect.right;
      int k = rect1.right;
      drawable1.setBounds(i - m, rect.top, j + k * 2, this.d.getBottom());
    } 
  }
  
  private void setEditText(EditText paramEditText) {
    if (this.d == null) {
      if (!(paramEditText instanceof w))
        Log.i("TextInputLayout", "EditText added is not a TextInputEditText. Please switch to using that class instead."); 
      this.d = paramEditText;
      o();
      setTextInputAccessibilityDelegate(new d(this));
      if (!n())
        this.c0.a(this.d.getTypeface()); 
      this.c0.a(this.d.getTextSize());
      int i = this.d.getGravity();
      this.c0.b(i & 0xFFFFFF8F | 0x30);
      this.c0.c(i);
      this.d.addTextChangedListener(new a(this));
      if (this.S == null)
        this.S = this.d.getHintTextColors(); 
      if (this.m) {
        if (TextUtils.isEmpty(this.n)) {
          this.e = this.d.getHint();
          setHint(this.e);
          this.d.setHint(null);
        } 
        this.o = true;
      } 
      if (this.j != null)
        a(this.d.getText().length()); 
      this.f.a();
      u();
      a(false, true);
      return;
    } 
    throw new IllegalArgumentException("We already have an EditText, can only have one");
  }
  
  private void setHintInternal(CharSequence paramCharSequence) {
    if (!TextUtils.equals(paramCharSequence, this.n)) {
      this.n = paramCharSequence;
      this.c0.a(paramCharSequence);
      if (!this.b0)
        p(); 
    } 
  }
  
  private void t() {
    LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)this.c.getLayoutParams();
    int i = j();
    if (i != layoutParams.topMargin) {
      layoutParams.topMargin = i;
      this.c.requestLayout();
    } 
  }
  
  private void u() {
    if (this.d == null)
      return; 
    if (r()) {
      if (this.K == null) {
        this.K = (CheckableImageButton)LayoutInflater.from(getContext()).inflate(h.design_text_input_password_icon, (ViewGroup)this.c, false);
        this.K.setImageDrawable(this.I);
        this.K.setContentDescription(this.J);
        this.c.addView((View)this.K);
        this.K.setOnClickListener(new b(this));
      } 
      EditText editText = this.d;
      if (editText != null && u.l((View)editText) <= 0)
        this.d.setMinimumHeight(u.l((View)this.K)); 
      this.K.setVisibility(0);
      this.K.setChecked(this.L);
      if (this.M == null)
        this.M = (Drawable)new ColorDrawable(); 
      this.M.setBounds(0, 0, this.K.getMeasuredWidth(), 1);
      Drawable[] arrayOfDrawable = p.a((TextView)this.d);
      if (arrayOfDrawable[2] != this.M)
        this.N = arrayOfDrawable[2]; 
      p.a((TextView)this.d, arrayOfDrawable[0], arrayOfDrawable[1], this.M, arrayOfDrawable[3]);
      this.K.setPadding(this.d.getPaddingLeft(), this.d.getPaddingTop(), this.d.getPaddingRight(), this.d.getPaddingBottom());
    } else {
      CheckableImageButton checkableImageButton = this.K;
      if (checkableImageButton != null && checkableImageButton.getVisibility() == 0)
        this.K.setVisibility(8); 
      if (this.M != null) {
        Drawable[] arrayOfDrawable = p.a((TextView)this.d);
        if (arrayOfDrawable[2] == this.M) {
          p.a((TextView)this.d, arrayOfDrawable[0], arrayOfDrawable[1], this.N, arrayOfDrawable[3]);
          this.M = null;
        } 
      } 
    } 
  }
  
  private void v() {
    if (this.s == 0 || this.p == null || this.d == null || getRight() == 0)
      return; 
    int i3 = this.d.getLeft();
    int i2 = h();
    int i1 = this.d.getRight();
    int n = this.d.getBottom() + this.q;
    int m = i3;
    int k = i2;
    int j = i1;
    int i = n;
    if (this.s == 2) {
      i = this.A;
      m = i3 + i / 2;
      k = i2 - i / 2;
      j = i1 - i / 2;
      i = n + i / 2;
    } 
    this.p.setBounds(m, k, j, i);
    e();
    s();
  }
  
  void a(float paramFloat) {
    if (this.c0.e() == paramFloat)
      return; 
    if (this.e0 == null) {
      this.e0 = new ValueAnimator();
      this.e0.setInterpolator(a.b.c.l.a.b);
      this.e0.setDuration(167L);
      this.e0.addUpdateListener(new c(this));
    } 
    this.e0.setFloatValues(new float[] { this.c0.e(), paramFloat });
    this.e0.start();
  }
  
  void a(int paramInt) {
    boolean bool = this.i;
    if (this.h == -1) {
      this.j.setText(String.valueOf(paramInt));
      this.j.setContentDescription(null);
      this.i = false;
    } else {
      if (u.b((View)this.j) == 1)
        u.e((View)this.j, 0); 
      if (paramInt > this.h) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.i = bool1;
      boolean bool1 = this.i;
      if (bool != bool1) {
        int i;
        TextView textView = this.j;
        if (bool1) {
          i = this.k;
        } else {
          i = this.l;
        } 
        a(textView, i);
        if (this.i)
          u.e((View)this.j, 1); 
      } 
      this.j.setText(getContext().getString(i.character_counter_pattern, new Object[] { Integer.valueOf(paramInt), Integer.valueOf(this.h) }));
      this.j.setContentDescription(getContext().getString(i.character_counter_content_description, new Object[] { Integer.valueOf(paramInt), Integer.valueOf(this.h) }));
    } 
    if (this.d != null && bool != this.i) {
      b(false);
      d();
      c();
    } 
  }
  
  void a(TextView paramTextView, int paramInt) {
    boolean bool = false;
    try {
      p.d(paramTextView, paramInt);
      paramInt = bool;
      if (Build.VERSION.SDK_INT >= 23) {
        int i = paramTextView.getTextColors().getDefaultColor();
        paramInt = bool;
        if (i == -65281)
          paramInt = 1; 
      } 
    } catch (Exception exception) {
      paramInt = 1;
    } 
    if (paramInt != 0) {
      p.d(paramTextView, j.TextAppearance_AppCompat_Caption);
      paramTextView.setTextColor(android.support.v4.content.a.a(getContext(), a.b.c.c.design_error));
    } 
  }
  
  public void a(boolean paramBoolean) {
    if (this.H) {
      int i = this.d.getSelectionEnd();
      if (n()) {
        this.d.setTransformationMethod(null);
        this.L = true;
      } else {
        this.d.setTransformationMethod((TransformationMethod)PasswordTransformationMethod.getInstance());
        this.L = false;
      } 
      this.K.setChecked(this.L);
      if (paramBoolean)
        this.K.jumpDrawablesToCurrentState(); 
      this.d.setSelection(i);
    } 
  }
  
  public boolean a() {
    return this.f.l();
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    if (paramView instanceof EditText) {
      FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(paramLayoutParams);
      layoutParams.gravity = layoutParams.gravity & 0xFFFFFF8F | 0x10;
      this.c.addView(paramView, (ViewGroup.LayoutParams)layoutParams);
      this.c.setLayoutParams(paramLayoutParams);
      t();
      setEditText((EditText)paramView);
    } else {
      super.addView(paramView, paramInt, paramLayoutParams);
    } 
  }
  
  void b(boolean paramBoolean) {
    a(paramBoolean, false);
  }
  
  boolean b() {
    return this.o;
  }
  
  void c() {
    EditText editText = this.d;
    if (editText == null)
      return; 
    Drawable drawable2 = editText.getBackground();
    if (drawable2 == null)
      return; 
    m();
    Drawable drawable1 = drawable2;
    if (h0.a(drawable2))
      drawable1 = drawable2.mutate(); 
    if (this.f.c()) {
      drawable1.setColorFilter((ColorFilter)j.a(this.f.e(), PorterDuff.Mode.SRC_IN));
    } else {
      if (this.i) {
        TextView textView = this.j;
        if (textView != null) {
          drawable1.setColorFilter((ColorFilter)j.a(textView.getCurrentTextColor(), PorterDuff.Mode.SRC_IN));
          return;
        } 
      } 
      android.support.v4.graphics.drawable.a.b(drawable1);
      this.d.refreshDrawableState();
    } 
  }
  
  void d() {
    // Byte code:
    //   0: aload_0
    //   1: getfield p : Landroid/graphics/drawable/GradientDrawable;
    //   4: ifnull -> 217
    //   7: aload_0
    //   8: getfield s : I
    //   11: ifne -> 17
    //   14: goto -> 217
    //   17: aload_0
    //   18: getfield d : Landroid/widget/EditText;
    //   21: astore_3
    //   22: iconst_1
    //   23: istore_2
    //   24: aload_3
    //   25: ifnull -> 40
    //   28: aload_3
    //   29: invokevirtual hasFocus : ()Z
    //   32: ifeq -> 40
    //   35: iconst_1
    //   36: istore_1
    //   37: goto -> 42
    //   40: iconst_0
    //   41: istore_1
    //   42: aload_0
    //   43: getfield d : Landroid/widget/EditText;
    //   46: astore_3
    //   47: aload_3
    //   48: ifnull -> 61
    //   51: aload_3
    //   52: invokevirtual isHovered : ()Z
    //   55: ifeq -> 61
    //   58: goto -> 63
    //   61: iconst_0
    //   62: istore_2
    //   63: aload_0
    //   64: getfield s : I
    //   67: iconst_2
    //   68: if_icmpne -> 216
    //   71: aload_0
    //   72: invokevirtual isEnabled : ()Z
    //   75: ifne -> 89
    //   78: aload_0
    //   79: aload_0
    //   80: getfield a0 : I
    //   83: putfield B : I
    //   86: goto -> 178
    //   89: aload_0
    //   90: getfield f : Landroid/support/design/widget/p;
    //   93: invokevirtual c : ()Z
    //   96: ifeq -> 113
    //   99: aload_0
    //   100: aload_0
    //   101: getfield f : Landroid/support/design/widget/p;
    //   104: invokevirtual e : ()I
    //   107: putfield B : I
    //   110: goto -> 178
    //   113: aload_0
    //   114: getfield i : Z
    //   117: ifeq -> 140
    //   120: aload_0
    //   121: getfield j : Landroid/widget/TextView;
    //   124: astore_3
    //   125: aload_3
    //   126: ifnull -> 140
    //   129: aload_0
    //   130: aload_3
    //   131: invokevirtual getCurrentTextColor : ()I
    //   134: putfield B : I
    //   137: goto -> 178
    //   140: iload_1
    //   141: ifeq -> 155
    //   144: aload_0
    //   145: aload_0
    //   146: getfield W : I
    //   149: putfield B : I
    //   152: goto -> 178
    //   155: iload_2
    //   156: ifeq -> 170
    //   159: aload_0
    //   160: aload_0
    //   161: getfield V : I
    //   164: putfield B : I
    //   167: goto -> 178
    //   170: aload_0
    //   171: aload_0
    //   172: getfield U : I
    //   175: putfield B : I
    //   178: iload_2
    //   179: ifne -> 186
    //   182: iload_1
    //   183: ifeq -> 204
    //   186: aload_0
    //   187: invokevirtual isEnabled : ()Z
    //   190: ifeq -> 204
    //   193: aload_0
    //   194: aload_0
    //   195: getfield A : I
    //   198: putfield y : I
    //   201: goto -> 212
    //   204: aload_0
    //   205: aload_0
    //   206: getfield z : I
    //   209: putfield y : I
    //   212: aload_0
    //   213: invokespecial e : ()V
    //   216: return
    //   217: return
  }
  
  public void dispatchProvideAutofillStructure(ViewStructure paramViewStructure, int paramInt) {
    if (this.e != null) {
      EditText editText = this.d;
      if (editText != null) {
        boolean bool = this.o;
        this.o = false;
        CharSequence charSequence = editText.getHint();
        this.d.setHint(this.e);
        try {
          super.dispatchProvideAutofillStructure(paramViewStructure, paramInt);
          return;
        } finally {
          this.d.setHint(charSequence);
          this.o = bool;
        } 
      } 
    } 
    super.dispatchProvideAutofillStructure(paramViewStructure, paramInt);
  }
  
  protected void dispatchRestoreInstanceState(SparseArray<Parcelable> paramSparseArray) {
    this.h0 = true;
    super.dispatchRestoreInstanceState(paramSparseArray);
    this.h0 = false;
  }
  
  public void draw(Canvas paramCanvas) {
    GradientDrawable gradientDrawable = this.p;
    if (gradientDrawable != null)
      gradientDrawable.draw(paramCanvas); 
    super.draw(paramCanvas);
    if (this.m)
      this.c0.a(paramCanvas); 
  }
  
  protected void drawableStateChanged() {
    if (this.g0)
      return; 
    boolean bool = true;
    this.g0 = true;
    super.drawableStateChanged();
    int[] arrayOfInt = getDrawableState();
    int i = 0;
    if (!u.y((View)this) || !isEnabled())
      bool = false; 
    b(bool);
    c();
    v();
    d();
    h h1 = this.c0;
    if (h1 != null)
      i = false | h1.a(arrayOfInt); 
    if (i != 0)
      invalidate(); 
    this.g0 = false;
  }
  
  public int getBoxBackgroundColor() {
    return this.C;
  }
  
  public float getBoxCornerRadiusBottomEnd() {
    return this.w;
  }
  
  public float getBoxCornerRadiusBottomStart() {
    return this.x;
  }
  
  public float getBoxCornerRadiusTopEnd() {
    return this.v;
  }
  
  public float getBoxCornerRadiusTopStart() {
    return this.u;
  }
  
  public int getBoxStrokeColor() {
    return this.W;
  }
  
  public int getCounterMaxLength() {
    return this.h;
  }
  
  CharSequence getCounterOverflowDescription() {
    if (this.g && this.i) {
      TextView textView = this.j;
      if (textView != null)
        return textView.getContentDescription(); 
    } 
    return null;
  }
  
  public ColorStateList getDefaultHintTextColor() {
    return this.S;
  }
  
  public EditText getEditText() {
    return this.d;
  }
  
  public CharSequence getError() {
    CharSequence charSequence;
    if (this.f.k()) {
      charSequence = this.f.d();
    } else {
      charSequence = null;
    } 
    return charSequence;
  }
  
  public int getErrorCurrentTextColors() {
    return this.f.e();
  }
  
  final int getErrorTextCurrentColor() {
    return this.f.e();
  }
  
  public CharSequence getHelperText() {
    CharSequence charSequence;
    if (this.f.l()) {
      charSequence = this.f.g();
    } else {
      charSequence = null;
    } 
    return charSequence;
  }
  
  public int getHelperTextCurrentTextColor() {
    return this.f.h();
  }
  
  public CharSequence getHint() {
    CharSequence charSequence;
    if (this.m) {
      charSequence = this.n;
    } else {
      charSequence = null;
    } 
    return charSequence;
  }
  
  final float getHintCollapsedTextHeight() {
    return this.c0.c();
  }
  
  final int getHintCurrentCollapsedTextColor() {
    return this.c0.d();
  }
  
  public CharSequence getPasswordVisibilityToggleContentDescription() {
    return this.J;
  }
  
  public Drawable getPasswordVisibilityToggleDrawable() {
    return this.I;
  }
  
  public Typeface getTypeface() {
    return this.G;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    if (this.p != null)
      v(); 
    if (this.m) {
      EditText editText = this.d;
      if (editText != null) {
        Rect rect = this.E;
        j.a((ViewGroup)this, (View)editText, rect);
        int i = rect.left + this.d.getCompoundPaddingLeft();
        paramInt3 = rect.right - this.d.getCompoundPaddingRight();
        paramInt1 = i();
        this.c0.b(i, rect.top + this.d.getCompoundPaddingTop(), paramInt3, rect.bottom - this.d.getCompoundPaddingBottom());
        this.c0.a(i, paramInt1, paramInt3, paramInt4 - paramInt2 - getPaddingBottom());
        this.c0.h();
        if (l() && !this.b0)
          p(); 
      } 
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    u();
    super.onMeasure(paramInt1, paramInt2);
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof e)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    e e = (e)paramParcelable;
    super.onRestoreInstanceState(e.a());
    setError(e.e);
    if (e.f)
      a(true); 
    requestLayout();
  }
  
  public Parcelable onSaveInstanceState() {
    e e = new e(super.onSaveInstanceState());
    if (this.f.c())
      e.e = getError(); 
    e.f = this.L;
    return (Parcelable)e;
  }
  
  public void setBoxBackgroundColor(int paramInt) {
    if (this.C != paramInt) {
      this.C = paramInt;
      e();
    } 
  }
  
  public void setBoxBackgroundColorResource(int paramInt) {
    setBoxBackgroundColor(android.support.v4.content.a.a(getContext(), paramInt));
  }
  
  public void setBoxBackgroundMode(int paramInt) {
    if (paramInt == this.s)
      return; 
    this.s = paramInt;
    o();
  }
  
  public void setBoxStrokeColor(int paramInt) {
    if (this.W != paramInt) {
      this.W = paramInt;
      d();
    } 
  }
  
  public void setCounterEnabled(boolean paramBoolean) {
    if (this.g != paramBoolean) {
      if (paramBoolean) {
        this.j = (TextView)new AppCompatTextView(getContext());
        this.j.setId(f.textinput_counter);
        Typeface typeface = this.G;
        if (typeface != null)
          this.j.setTypeface(typeface); 
        this.j.setMaxLines(1);
        a(this.j, this.l);
        this.f.a(this.j, 2);
        EditText editText = this.d;
        if (editText == null) {
          a(0);
        } else {
          a(editText.getText().length());
        } 
      } else {
        this.f.b(this.j, 2);
        this.j = null;
      } 
      this.g = paramBoolean;
    } 
  }
  
  public void setCounterMaxLength(int paramInt) {
    if (this.h != paramInt) {
      if (paramInt > 0) {
        this.h = paramInt;
      } else {
        this.h = -1;
      } 
      if (this.g) {
        EditText editText = this.d;
        if (editText == null) {
          paramInt = 0;
        } else {
          paramInt = editText.getText().length();
        } 
        a(paramInt);
      } 
    } 
  }
  
  public void setDefaultHintTextColor(ColorStateList paramColorStateList) {
    this.S = paramColorStateList;
    this.T = paramColorStateList;
    if (this.d != null)
      b(false); 
  }
  
  public void setEnabled(boolean paramBoolean) {
    a((ViewGroup)this, paramBoolean);
    super.setEnabled(paramBoolean);
  }
  
  public void setError(CharSequence paramCharSequence) {
    if (!this.f.k()) {
      if (TextUtils.isEmpty(paramCharSequence))
        return; 
      setErrorEnabled(true);
    } 
    if (!TextUtils.isEmpty(paramCharSequence)) {
      this.f.a(paramCharSequence);
    } else {
      this.f.i();
    } 
  }
  
  public void setErrorEnabled(boolean paramBoolean) {
    this.f.a(paramBoolean);
  }
  
  public void setErrorTextAppearance(int paramInt) {
    this.f.b(paramInt);
  }
  
  public void setErrorTextColor(ColorStateList paramColorStateList) {
    this.f.a(paramColorStateList);
  }
  
  public void setHelperText(CharSequence paramCharSequence) {
    if (TextUtils.isEmpty(paramCharSequence)) {
      if (a())
        setHelperTextEnabled(false); 
    } else {
      if (!a())
        setHelperTextEnabled(true); 
      this.f.b(paramCharSequence);
    } 
  }
  
  public void setHelperTextColor(ColorStateList paramColorStateList) {
    this.f.b(paramColorStateList);
  }
  
  public void setHelperTextEnabled(boolean paramBoolean) {
    this.f.b(paramBoolean);
  }
  
  public void setHelperTextTextAppearance(int paramInt) {
    this.f.c(paramInt);
  }
  
  public void setHint(CharSequence paramCharSequence) {
    if (this.m) {
      setHintInternal(paramCharSequence);
      sendAccessibilityEvent(2048);
    } 
  }
  
  public void setHintAnimationEnabled(boolean paramBoolean) {
    this.d0 = paramBoolean;
  }
  
  public void setHintEnabled(boolean paramBoolean) {
    if (paramBoolean != this.m) {
      this.m = paramBoolean;
      if (!this.m) {
        this.o = false;
        if (!TextUtils.isEmpty(this.n) && TextUtils.isEmpty(this.d.getHint()))
          this.d.setHint(this.n); 
        setHintInternal(null);
      } else {
        CharSequence charSequence = this.d.getHint();
        if (!TextUtils.isEmpty(charSequence)) {
          if (TextUtils.isEmpty(this.n))
            setHint(charSequence); 
          this.d.setHint(null);
        } 
        this.o = true;
      } 
      if (this.d != null)
        t(); 
    } 
  }
  
  public void setHintTextAppearance(int paramInt) {
    this.c0.a(paramInt);
    this.T = this.c0.b();
    if (this.d != null) {
      b(false);
      t();
    } 
  }
  
  public void setPasswordVisibilityToggleContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getResources().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setPasswordVisibilityToggleContentDescription(charSequence);
  }
  
  public void setPasswordVisibilityToggleContentDescription(CharSequence paramCharSequence) {
    this.J = paramCharSequence;
    CheckableImageButton checkableImageButton = this.K;
    if (checkableImageButton != null)
      checkableImageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setPasswordVisibilityToggleDrawable(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = a.b.h.c.a.a.c(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setPasswordVisibilityToggleDrawable(drawable);
  }
  
  public void setPasswordVisibilityToggleDrawable(Drawable paramDrawable) {
    this.I = paramDrawable;
    CheckableImageButton checkableImageButton = this.K;
    if (checkableImageButton != null)
      checkableImageButton.setImageDrawable(paramDrawable); 
  }
  
  public void setPasswordVisibilityToggleEnabled(boolean paramBoolean) {
    if (this.H != paramBoolean) {
      this.H = paramBoolean;
      if (!paramBoolean && this.L) {
        EditText editText = this.d;
        if (editText != null)
          editText.setTransformationMethod((TransformationMethod)PasswordTransformationMethod.getInstance()); 
      } 
      this.L = false;
      u();
    } 
  }
  
  public void setPasswordVisibilityToggleTintList(ColorStateList paramColorStateList) {
    this.O = paramColorStateList;
    this.P = true;
    f();
  }
  
  public void setPasswordVisibilityToggleTintMode(PorterDuff.Mode paramMode) {
    this.Q = paramMode;
    this.R = true;
    f();
  }
  
  public void setTextInputAccessibilityDelegate(d paramd) {
    EditText editText = this.d;
    if (editText != null)
      u.a((View)editText, paramd); 
  }
  
  public void setTypeface(Typeface paramTypeface) {
    if (paramTypeface != this.G) {
      this.G = paramTypeface;
      this.c0.a(paramTypeface);
      this.f.a(paramTypeface);
      TextView textView = this.j;
      if (textView != null)
        textView.setTypeface(paramTypeface); 
    } 
  }
  
  class a implements TextWatcher {
    final TextInputLayout c;
    
    a(TextInputLayout this$0) {}
    
    public void afterTextChanged(Editable param1Editable) {
      TextInputLayout textInputLayout = this.c;
      textInputLayout.b(TextInputLayout.a(textInputLayout) ^ true);
      textInputLayout = this.c;
      if (textInputLayout.g)
        textInputLayout.a(param1Editable.length()); 
    }
    
    public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
  }
  
  class b implements View.OnClickListener {
    final TextInputLayout c;
    
    b(TextInputLayout this$0) {}
    
    public void onClick(View param1View) {
      this.c.a(false);
    }
  }
  
  class c implements ValueAnimator.AnimatorUpdateListener {
    final TextInputLayout a;
    
    c(TextInputLayout this$0) {}
    
    public void onAnimationUpdate(ValueAnimator param1ValueAnimator) {
      this.a.c0.b(((Float)param1ValueAnimator.getAnimatedValue()).floatValue());
    }
  }
  
  public static class d extends android.support.v4.view.b {
    private final TextInputLayout c;
    
    public d(TextInputLayout param1TextInputLayout) {
      this.c = param1TextInputLayout;
    }
    
    public void a(View param1View, android.support.v4.view.d0.c param1c) {
      boolean bool1;
      super.a(param1View, param1c);
      EditText editText = this.c.getEditText();
      if (editText != null) {
        Editable editable = editText.getText();
      } else {
        editText = null;
      } 
      CharSequence charSequence3 = this.c.getHint();
      CharSequence charSequence1 = this.c.getError();
      CharSequence charSequence2 = this.c.getCounterOverflowDescription();
      int k = TextUtils.isEmpty((CharSequence)editText) ^ true;
      int i = TextUtils.isEmpty(charSequence3) ^ true;
      int j = TextUtils.isEmpty(charSequence1) ^ true;
      boolean bool2 = false;
      if (j != 0 || !TextUtils.isEmpty(charSequence2)) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (k != 0) {
        param1c.f((CharSequence)editText);
      } else if (i != 0) {
        param1c.f(charSequence3);
      } 
      if (i != 0) {
        param1c.d(charSequence3);
        boolean bool = bool2;
        if (k == 0) {
          bool = bool2;
          if (i != 0)
            bool = true; 
        } 
        param1c.m(bool);
      } 
      if (bool1) {
        CharSequence charSequence;
        if (j != 0) {
          charSequence = charSequence1;
        } else {
          charSequence = charSequence2;
        } 
        param1c.c(charSequence);
        param1c.e(true);
      } 
    }
    
    public void c(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      CharSequence charSequence;
      super.c(param1View, param1AccessibilityEvent);
      EditText editText = this.c.getEditText();
      if (editText != null) {
        Editable editable = editText.getText();
      } else {
        editText = null;
      } 
      if (TextUtils.isEmpty((CharSequence)editText))
        charSequence = this.c.getHint(); 
      if (!TextUtils.isEmpty(charSequence))
        param1AccessibilityEvent.getText().add(charSequence); 
    }
  }
  
  static class e extends android.support.v4.view.a {
    public static final Parcelable.Creator<e> CREATOR = (Parcelable.Creator<e>)new a();
    
    CharSequence e;
    
    boolean f;
    
    e(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      this.e = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(param1Parcel);
      int i = param1Parcel.readInt();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      this.f = bool;
    }
    
    e(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("TextInputLayout.SavedState{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" error=");
      stringBuilder.append(this.e);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      TextUtils.writeToParcel(this.e, param1Parcel, param1Int);
      param1Parcel.writeInt(this.f);
    }
    
    static final class a implements Parcelable.ClassLoaderCreator<e> {
      public TextInputLayout.e createFromParcel(Parcel param2Parcel) {
        return new TextInputLayout.e(param2Parcel, null);
      }
      
      public TextInputLayout.e createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new TextInputLayout.e(param2Parcel, param2ClassLoader);
      }
      
      public TextInputLayout.e[] newArray(int param2Int) {
        return new TextInputLayout.e[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.ClassLoaderCreator<e> {
    public TextInputLayout.e createFromParcel(Parcel param1Parcel) {
      return new TextInputLayout.e(param1Parcel, null);
    }
    
    public TextInputLayout.e createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new TextInputLayout.e(param1Parcel, param1ClassLoader);
    }
    
    public TextInputLayout.e[] newArray(int param1Int) {
      return new TextInputLayout.e[param1Int];
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\TextInputLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */