package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Matrix;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.support.v4.view.u;
import android.util.Property;
import android.view.View;
import android.view.ViewTreeObserver;
import java.util.ArrayList;
import java.util.Iterator;

class l {
  static final TimeInterpolator B = a.b.c.l.a.c;
  
  static final int[] C = new int[] { 16842919, 16842910 };
  
  static final int[] D = new int[] { 16843623, 16842908, 16842910 };
  
  static final int[] E = new int[] { 16842908, 16842910 };
  
  static final int[] F = new int[] { 16843623, 16842910 };
  
  static final int[] G = new int[] { 16842910 };
  
  static final int[] H = new int[0];
  
  private ViewTreeObserver.OnPreDrawListener A;
  
  int a = 0;
  
  Animator b;
  
  a.b.c.l.h c;
  
  a.b.c.l.h d;
  
  private a.b.c.l.h e;
  
  private a.b.c.l.h f;
  
  private final u g;
  
  r h;
  
  private float i;
  
  Drawable j;
  
  Drawable k;
  
  f l;
  
  Drawable m;
  
  float n;
  
  float o;
  
  float p;
  
  int q;
  
  float r = 1.0F;
  
  private ArrayList<Animator.AnimatorListener> s;
  
  private ArrayList<Animator.AnimatorListener> t;
  
  final a0 u;
  
  final s v;
  
  private final Rect w = new Rect();
  
  private final RectF x = new RectF();
  
  private final RectF y = new RectF();
  
  private final Matrix z = new Matrix();
  
  l(a0 parama0, s params) {
    this.u = parama0;
    this.v = params;
    this.g = new u();
    this.g.a(C, a(new f(this)));
    this.g.a(D, a(new e(this)));
    this.g.a(E, a(new e(this)));
    this.g.a(F, a(new e(this)));
    this.g.a(G, a(new h(this)));
    this.g.a(H, a(new d(this)));
    this.i = this.u.getRotation();
  }
  
  private AnimatorSet a(a.b.c.l.h paramh, float paramFloat1, float paramFloat2, float paramFloat3) {
    ArrayList<ObjectAnimator> arrayList = new ArrayList();
    ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(this.u, View.ALPHA, new float[] { paramFloat1 });
    paramh.a("opacity").a((Animator)objectAnimator);
    arrayList.add(objectAnimator);
    objectAnimator = ObjectAnimator.ofFloat(this.u, View.SCALE_X, new float[] { paramFloat2 });
    paramh.a("scale").a((Animator)objectAnimator);
    arrayList.add(objectAnimator);
    objectAnimator = ObjectAnimator.ofFloat(this.u, View.SCALE_Y, new float[] { paramFloat2 });
    paramh.a("scale").a((Animator)objectAnimator);
    arrayList.add(objectAnimator);
    a(paramFloat3, this.z);
    objectAnimator = ObjectAnimator.ofObject(this.u, (Property)new a.b.c.l.f(), (TypeEvaluator)new a.b.c.l.g(), (Object[])new Matrix[] { new Matrix(this.z) });
    paramh.a("iconScale").a((Animator)objectAnimator);
    arrayList.add(objectAnimator);
    AnimatorSet animatorSet = new AnimatorSet();
    a.b.c.l.b.a(animatorSet, arrayList);
    return animatorSet;
  }
  
  private ValueAnimator a(i parami) {
    ValueAnimator valueAnimator = new ValueAnimator();
    valueAnimator.setInterpolator(B);
    valueAnimator.setDuration(100L);
    valueAnimator.addListener((Animator.AnimatorListener)parami);
    valueAnimator.addUpdateListener(parami);
    valueAnimator.setFloatValues(new float[] { 0.0F, 1.0F });
    return valueAnimator;
  }
  
  private void a(float paramFloat, Matrix paramMatrix) {
    paramMatrix.reset();
    Drawable drawable = this.u.getDrawable();
    if (drawable != null && this.q != 0) {
      RectF rectF1 = this.x;
      RectF rectF2 = this.y;
      rectF1.set(0.0F, 0.0F, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
      int i = this.q;
      rectF2.set(0.0F, 0.0F, i, i);
      paramMatrix.setRectToRect(rectF1, rectF2, Matrix.ScaleToFit.CENTER);
      i = this.q;
      paramMatrix.postScale(paramFloat, paramFloat, i / 2.0F, i / 2.0F);
    } 
  }
  
  private void t() {
    if (this.A == null)
      this.A = new c(this); 
  }
  
  private a.b.c.l.h u() {
    if (this.f == null)
      this.f = a.b.c.l.h.a(this.u.getContext(), a.b.c.a.design_fab_hide_motion_spec); 
    return this.f;
  }
  
  private a.b.c.l.h v() {
    if (this.e == null)
      this.e = a.b.c.l.h.a(this.u.getContext(), a.b.c.a.design_fab_show_motion_spec); 
    return this.e;
  }
  
  private boolean w() {
    boolean bool;
    if (u.y((View)this.u) && !this.u.isInEditMode()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private void x() {
    if (Build.VERSION.SDK_INT == 19)
      if (this.i % 90.0F != 0.0F) {
        if (this.u.getLayerType() != 1)
          this.u.setLayerType(1, null); 
      } else if (this.u.getLayerType() != 0) {
        this.u.setLayerType(0, null);
      }  
    r r1 = this.h;
    if (r1 != null)
      r1.a(-this.i); 
    f f1 = this.l;
    if (f1 != null)
      f1.b(-this.i); 
  }
  
  GradientDrawable a() {
    GradientDrawable gradientDrawable = l();
    gradientDrawable.setShape(1);
    gradientDrawable.setColor(-1);
    return gradientDrawable;
  }
  
  f a(int paramInt, ColorStateList paramColorStateList) {
    Context context = this.u.getContext();
    f f1 = k();
    f1.a(android.support.v4.content.a.a(context, a.b.c.c.design_fab_stroke_top_outer_color), android.support.v4.content.a.a(context, a.b.c.c.design_fab_stroke_top_inner_color), android.support.v4.content.a.a(context, a.b.c.c.design_fab_stroke_end_inner_color), android.support.v4.content.a.a(context, a.b.c.c.design_fab_stroke_end_outer_color));
    f1.a(paramInt);
    f1.a(paramColorStateList);
    return f1;
  }
  
  final void a(float paramFloat) {
    if (this.n != paramFloat) {
      this.n = paramFloat;
      a(this.n, this.o, this.p);
    } 
  }
  
  void a(float paramFloat1, float paramFloat2, float paramFloat3) {
    r r1 = this.h;
    if (r1 != null) {
      r1.a(paramFloat1, this.p + paramFloat1);
      s();
    } 
  }
  
  final void a(int paramInt) {
    if (this.q != paramInt) {
      this.q = paramInt;
      r();
    } 
  }
  
  final void a(a.b.c.l.h paramh) {
    this.d = paramh;
  }
  
  public void a(Animator.AnimatorListener paramAnimatorListener) {
    if (this.t == null)
      this.t = new ArrayList<Animator.AnimatorListener>(); 
    this.t.add(paramAnimatorListener);
  }
  
  void a(ColorStateList paramColorStateList) {
    Drawable drawable = this.j;
    if (drawable != null)
      android.support.v4.graphics.drawable.a.a(drawable, paramColorStateList); 
    drawable = this.l;
    if (drawable != null)
      drawable.a(paramColorStateList); 
  }
  
  void a(ColorStateList paramColorStateList1, PorterDuff.Mode paramMode, ColorStateList paramColorStateList2, int paramInt) {
    Drawable[] arrayOfDrawable;
    this.j = android.support.v4.graphics.drawable.a.h((Drawable)a());
    android.support.v4.graphics.drawable.a.a(this.j, paramColorStateList1);
    if (paramMode != null)
      android.support.v4.graphics.drawable.a.a(this.j, paramMode); 
    this.k = android.support.v4.graphics.drawable.a.h((Drawable)a());
    android.support.v4.graphics.drawable.a.a(this.k, a.b.c.q.a.a(paramColorStateList2));
    if (paramInt > 0) {
      this.l = a(paramInt, paramColorStateList1);
      arrayOfDrawable = new Drawable[] { this.l, this.j, this.k };
    } else {
      this.l = null;
      arrayOfDrawable = new Drawable[] { this.j, this.k };
    } 
    this.m = (Drawable)new LayerDrawable(arrayOfDrawable);
    Context context = this.u.getContext();
    Drawable drawable = this.m;
    float f2 = this.v.a();
    float f1 = this.n;
    this.h = new r(context, drawable, f2, f1, f1 + this.p);
    this.h.a(false);
    this.v.a((Drawable)this.h);
  }
  
  void a(PorterDuff.Mode paramMode) {
    Drawable drawable = this.j;
    if (drawable != null)
      android.support.v4.graphics.drawable.a.a(drawable, paramMode); 
  }
  
  void a(Rect paramRect) {
    this.h.getPadding(paramRect);
  }
  
  void a(g paramg, boolean paramBoolean) {
    Iterator<Animator.AnimatorListener> iterator;
    if (h())
      return; 
    Animator animator = this.b;
    if (animator != null)
      animator.cancel(); 
    if (w()) {
      a.b.c.l.h h1 = this.d;
      if (h1 == null)
        h1 = u(); 
      AnimatorSet animatorSet = a(h1, 0.0F, 0.0F, 0.0F);
      animatorSet.addListener((Animator.AnimatorListener)new a(this, paramBoolean, paramg));
      ArrayList<Animator.AnimatorListener> arrayList = this.t;
      if (arrayList != null) {
        iterator = arrayList.iterator();
        while (iterator.hasNext())
          animatorSet.addListener(iterator.next()); 
      } 
      animatorSet.start();
    } else {
      byte b;
      a0 a01 = this.u;
      if (paramBoolean) {
        b = 8;
      } else {
        b = 4;
      } 
      a01.a(b, paramBoolean);
      if (iterator != null)
        iterator.b(); 
    } 
  }
  
  void a(int[] paramArrayOfint) {
    this.g.a(paramArrayOfint);
  }
  
  final Drawable b() {
    return this.m;
  }
  
  final void b(float paramFloat) {
    if (this.o != paramFloat) {
      this.o = paramFloat;
      a(this.n, this.o, this.p);
    } 
  }
  
  final void b(a.b.c.l.h paramh) {
    this.c = paramh;
  }
  
  void b(Animator.AnimatorListener paramAnimatorListener) {
    if (this.s == null)
      this.s = new ArrayList<Animator.AnimatorListener>(); 
    this.s.add(paramAnimatorListener);
  }
  
  void b(ColorStateList paramColorStateList) {
    Drawable drawable = this.k;
    if (drawable != null)
      android.support.v4.graphics.drawable.a.a(drawable, a.b.c.q.a.a(paramColorStateList)); 
  }
  
  void b(Rect paramRect) {}
  
  void b(g paramg, boolean paramBoolean) {
    Iterator<Animator.AnimatorListener> iterator;
    if (i())
      return; 
    Animator animator = this.b;
    if (animator != null)
      animator.cancel(); 
    if (w()) {
      if (this.u.getVisibility() != 0) {
        this.u.setAlpha(0.0F);
        this.u.setScaleY(0.0F);
        this.u.setScaleX(0.0F);
        c(0.0F);
      } 
      a.b.c.l.h h1 = this.c;
      if (h1 == null)
        h1 = v(); 
      AnimatorSet animatorSet = a(h1, 1.0F, 1.0F, 1.0F);
      animatorSet.addListener((Animator.AnimatorListener)new b(this, paramBoolean, paramg));
      ArrayList<Animator.AnimatorListener> arrayList = this.s;
      if (arrayList != null) {
        iterator = arrayList.iterator();
        while (iterator.hasNext())
          animatorSet.addListener(iterator.next()); 
      } 
      animatorSet.start();
    } else {
      this.u.a(0, paramBoolean);
      this.u.setAlpha(1.0F);
      this.u.setScaleY(1.0F);
      this.u.setScaleX(1.0F);
      c(1.0F);
      if (iterator != null)
        iterator.a(); 
    } 
  }
  
  float c() {
    return this.n;
  }
  
  final void c(float paramFloat) {
    this.r = paramFloat;
    Matrix matrix = this.z;
    a(paramFloat, matrix);
    this.u.setImageMatrix(matrix);
  }
  
  public void c(Animator.AnimatorListener paramAnimatorListener) {
    ArrayList<Animator.AnimatorListener> arrayList = this.t;
    if (arrayList == null)
      return; 
    arrayList.remove(paramAnimatorListener);
  }
  
  final a.b.c.l.h d() {
    return this.d;
  }
  
  final void d(float paramFloat) {
    if (this.p != paramFloat) {
      this.p = paramFloat;
      a(this.n, this.o, this.p);
    } 
  }
  
  void d(Animator.AnimatorListener paramAnimatorListener) {
    ArrayList<Animator.AnimatorListener> arrayList = this.s;
    if (arrayList == null)
      return; 
    arrayList.remove(paramAnimatorListener);
  }
  
  float e() {
    return this.o;
  }
  
  float f() {
    return this.p;
  }
  
  final a.b.c.l.h g() {
    return this.c;
  }
  
  boolean h() {
    int i = this.u.getVisibility();
    boolean bool1 = false;
    boolean bool2 = false;
    if (i == 0) {
      bool1 = bool2;
      if (this.a == 1)
        bool1 = true; 
      return bool1;
    } 
    if (this.a != 2)
      bool1 = true; 
    return bool1;
  }
  
  boolean i() {
    int i = this.u.getVisibility();
    boolean bool2 = false;
    boolean bool1 = false;
    if (i != 0) {
      if (this.a == 2)
        bool1 = true; 
      return bool1;
    } 
    bool1 = bool2;
    if (this.a != 1)
      bool1 = true; 
    return bool1;
  }
  
  void j() {
    this.g.a();
  }
  
  f k() {
    return new f();
  }
  
  GradientDrawable l() {
    return new GradientDrawable();
  }
  
  void m() {
    if (q()) {
      t();
      this.u.getViewTreeObserver().addOnPreDrawListener(this.A);
    } 
  }
  
  void n() {}
  
  void o() {
    if (this.A != null) {
      this.u.getViewTreeObserver().removeOnPreDrawListener(this.A);
      this.A = null;
    } 
  }
  
  void p() {
    float f1 = this.u.getRotation();
    if (this.i != f1) {
      this.i = f1;
      x();
    } 
  }
  
  boolean q() {
    return true;
  }
  
  final void r() {
    c(this.r);
  }
  
  final void s() {
    Rect rect = this.w;
    a(rect);
    b(rect);
    this.v.a(rect.left, rect.top, rect.right, rect.bottom);
  }
  
  class a extends AnimatorListenerAdapter {
    private boolean a;
    
    final boolean b;
    
    final l.g c;
    
    final l d;
    
    a(l this$0, boolean param1Boolean, l.g param1g) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      this.a = true;
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      l l1 = this.d;
      l1.a = 0;
      l1.b = null;
      if (!this.a) {
        byte b;
        a0 a0 = l1.u;
        if (this.b) {
          b = 8;
        } else {
          b = 4;
        } 
        a0.a(b, this.b);
        l.g g1 = this.c;
        if (g1 != null)
          g1.b(); 
      } 
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.d.u.a(0, this.b);
      l l1 = this.d;
      l1.a = 1;
      l1.b = param1Animator;
      this.a = false;
    }
  }
  
  class b extends AnimatorListenerAdapter {
    final boolean a;
    
    final l.g b;
    
    final l c;
    
    b(l this$0, boolean param1Boolean, l.g param1g) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      l l1 = this.c;
      l1.a = 0;
      l1.b = null;
      l.g g1 = this.b;
      if (g1 != null)
        g1.a(); 
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.c.u.a(0, this.a);
      l l1 = this.c;
      l1.a = 2;
      l1.b = param1Animator;
    }
  }
  
  class c implements ViewTreeObserver.OnPreDrawListener {
    final l c;
    
    c(l this$0) {}
    
    public boolean onPreDraw() {
      this.c.p();
      return true;
    }
  }
  
  private class d extends i {
    d(l this$0) {
      super(this$0, null);
    }
    
    protected float a() {
      return 0.0F;
    }
  }
  
  private class e extends i {
    final l e;
    
    e(l this$0) {
      super(this$0, null);
    }
    
    protected float a() {
      l l1 = this.e;
      return l1.n + l1.o;
    }
  }
  
  private class f extends i {
    final l e;
    
    f(l this$0) {
      super(this$0, null);
    }
    
    protected float a() {
      l l1 = this.e;
      return l1.n + l1.p;
    }
  }
  
  static interface g {
    void a();
    
    void b();
  }
  
  private class h extends i {
    final l e;
    
    h(l this$0) {
      super(this$0, null);
    }
    
    protected float a() {
      return this.e.n;
    }
  }
  
  private abstract class i extends AnimatorListenerAdapter implements ValueAnimator.AnimatorUpdateListener {
    private boolean a;
    
    private float b;
    
    private float c;
    
    final l d;
    
    private i(l this$0) {}
    
    protected abstract float a();
    
    public void onAnimationEnd(Animator param1Animator) {
      this.d.h.b(this.c);
      this.a = false;
    }
    
    public void onAnimationUpdate(ValueAnimator param1ValueAnimator) {
      if (!this.a) {
        this.b = this.d.h.b();
        this.c = a();
        this.a = true;
      } 
      r r = this.d.h;
      float f = this.b;
      r.b(f + (this.c - f) * param1ValueAnimator.getAnimatedFraction());
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */