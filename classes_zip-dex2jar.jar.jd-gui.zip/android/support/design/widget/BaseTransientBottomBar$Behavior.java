package android.support.design.widget;

import android.view.MotionEvent;
import android.view.View;

public class BaseTransientBottomBar$Behavior extends SwipeDismissBehavior<View> {
  private final a k = new a(this);
  
  public boolean a(CoordinatorLayout paramCoordinatorLayout, View paramView, MotionEvent paramMotionEvent) {
    this.k.a(paramCoordinatorLayout, paramView, paramMotionEvent);
    return super.a(paramCoordinatorLayout, paramView, paramMotionEvent);
  }
  
  public boolean a(View paramView) {
    return this.k.a(paramView);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\BaseTransientBottomBar$Behavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */