package android.support.design.widget;

import a.b.c.f;
import a.b.c.h;
import a.b.c.j;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.view.u;
import android.support.v7.app.i;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;

public class e extends i {
  private BottomSheetBehavior<FrameLayout> e;
  
  boolean f = true;
  
  private boolean g = true;
  
  private boolean h;
  
  private BottomSheetBehavior.c i = new d(this);
  
  public e(Context paramContext) {
    this(paramContext, 0);
  }
  
  public e(Context paramContext, int paramInt) {
    super(paramContext, a(paramContext, paramInt));
    a(1);
  }
  
  private static int a(Context paramContext, int paramInt) {
    int j = paramInt;
    if (paramInt == 0) {
      TypedValue typedValue = new TypedValue();
      if (paramContext.getTheme().resolveAttribute(a.b.c.b.bottomSheetDialogTheme, typedValue, true)) {
        j = typedValue.resourceId;
      } else {
        j = j.Theme_Design_Light_BottomSheetDialog;
      } 
    } 
    return j;
  }
  
  private View a(int paramInt, View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    FrameLayout frameLayout2 = (FrameLayout)View.inflate(getContext(), h.design_bottom_sheet_dialog, null);
    CoordinatorLayout coordinatorLayout = (CoordinatorLayout)frameLayout2.findViewById(f.coordinator);
    View view = paramView;
    if (paramInt != 0) {
      view = paramView;
      if (paramView == null)
        view = getLayoutInflater().inflate(paramInt, coordinatorLayout, false); 
    } 
    FrameLayout frameLayout1 = (FrameLayout)coordinatorLayout.findViewById(f.design_bottom_sheet);
    this.e = BottomSheetBehavior.b(frameLayout1);
    this.e.a(this.i);
    this.e.b(this.f);
    if (paramLayoutParams == null) {
      frameLayout1.addView(view);
    } else {
      frameLayout1.addView(view, paramLayoutParams);
    } 
    coordinatorLayout.findViewById(f.touch_outside).setOnClickListener(new a(this));
    u.a((View)frameLayout1, new b(this));
    frameLayout1.setOnTouchListener(new c(this));
    return (View)frameLayout2;
  }
  
  boolean b() {
    if (!this.h) {
      TypedArray typedArray = getContext().obtainStyledAttributes(new int[] { 16843611 });
      this.g = typedArray.getBoolean(0, true);
      typedArray.recycle();
      this.h = true;
    } 
    return this.g;
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    Window window = getWindow();
    if (window != null) {
      if (Build.VERSION.SDK_INT >= 21) {
        window.clearFlags(67108864);
        window.addFlags(-2147483648);
      } 
      window.setLayout(-1, -1);
    } 
  }
  
  protected void onStart() {
    super.onStart();
    BottomSheetBehavior<FrameLayout> bottomSheetBehavior = this.e;
    if (bottomSheetBehavior != null && bottomSheetBehavior.b() == 5)
      this.e.c(4); 
  }
  
  public void setCancelable(boolean paramBoolean) {
    super.setCancelable(paramBoolean);
    if (this.f != paramBoolean) {
      this.f = paramBoolean;
      BottomSheetBehavior<FrameLayout> bottomSheetBehavior = this.e;
      if (bottomSheetBehavior != null)
        bottomSheetBehavior.b(paramBoolean); 
    } 
  }
  
  public void setCanceledOnTouchOutside(boolean paramBoolean) {
    super.setCanceledOnTouchOutside(paramBoolean);
    if (paramBoolean && !this.f)
      this.f = true; 
    this.g = paramBoolean;
    this.h = true;
  }
  
  public void setContentView(int paramInt) {
    super.setContentView(a(paramInt, null, null));
  }
  
  public void setContentView(View paramView) {
    super.setContentView(a(0, paramView, null));
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    super.setContentView(a(0, paramView, paramLayoutParams));
  }
  
  class a implements View.OnClickListener {
    final e c;
    
    a(e this$0) {}
    
    public void onClick(View param1View) {
      e e1 = this.c;
      if (e1.f && e1.isShowing() && this.c.b())
        this.c.cancel(); 
    }
  }
  
  class b extends android.support.v4.view.b {
    final e c;
    
    b(e this$0) {}
    
    public void a(View param1View, android.support.v4.view.d0.c param1c) {
      super.a(param1View, param1c);
      if (this.c.f) {
        param1c.a(1048576);
        param1c.f(true);
      } else {
        param1c.f(false);
      } 
    }
    
    public boolean a(View param1View, int param1Int, Bundle param1Bundle) {
      if (param1Int == 1048576) {
        e e1 = this.c;
        if (e1.f) {
          e1.cancel();
          return true;
        } 
      } 
      return super.a(param1View, param1Int, param1Bundle);
    }
  }
  
  class c implements View.OnTouchListener {
    c(e this$0) {}
    
    public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
      return true;
    }
  }
  
  class d extends BottomSheetBehavior.c {
    final e a;
    
    d(e this$0) {}
    
    public void a(View param1View, float param1Float) {}
    
    public void a(View param1View, int param1Int) {
      if (param1Int == 5)
        this.a.cancel(); 
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */