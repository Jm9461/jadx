package android.support.design.widget;

import android.content.Context;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.view.u;
import android.support.v4.widget.s;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

public class BottomSheetBehavior<V extends View> extends CoordinatorLayout.c<V> {
  private boolean a = true;
  
  private float b;
  
  private int c;
  
  private boolean d;
  
  private int e;
  
  private int f;
  
  int g;
  
  int h;
  
  int i;
  
  boolean j;
  
  private boolean k;
  
  int l = 4;
  
  s m;
  
  private boolean n;
  
  private int o;
  
  private boolean p;
  
  int q;
  
  WeakReference<V> r;
  
  WeakReference<View> s;
  
  private c t;
  
  private VelocityTracker u;
  
  int v;
  
  private int w;
  
  boolean x;
  
  private Map<View, Integer> y;
  
  private final s.c z = new b(this);
  
  public BottomSheetBehavior() {}
  
  public BottomSheetBehavior(Context paramContext, AttributeSet paramAttributeSet) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   6: aload_0
    //   7: iconst_1
    //   8: putfield a : Z
    //   11: aload_0
    //   12: iconst_4
    //   13: putfield l : I
    //   16: aload_0
    //   17: new android/support/design/widget/BottomSheetBehavior$b
    //   20: dup
    //   21: aload_0
    //   22: invokespecial <init> : (Landroid/support/design/widget/BottomSheetBehavior;)V
    //   25: putfield z : Landroid/support/v4/widget/s$c;
    //   28: aload_1
    //   29: aload_2
    //   30: getstatic a/b/c/k.BottomSheetBehavior_Layout : [I
    //   33: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   36: astore #4
    //   38: aload #4
    //   40: getstatic a/b/c/k.BottomSheetBehavior_Layout_behavior_peekHeight : I
    //   43: invokevirtual peekValue : (I)Landroid/util/TypedValue;
    //   46: astore_2
    //   47: aload_2
    //   48: ifnull -> 69
    //   51: aload_2
    //   52: getfield data : I
    //   55: istore_3
    //   56: iload_3
    //   57: iconst_m1
    //   58: if_icmpne -> 69
    //   61: aload_0
    //   62: iload_3
    //   63: invokevirtual b : (I)V
    //   66: goto -> 82
    //   69: aload_0
    //   70: aload #4
    //   72: getstatic a/b/c/k.BottomSheetBehavior_Layout_behavior_peekHeight : I
    //   75: iconst_m1
    //   76: invokevirtual getDimensionPixelSize : (II)I
    //   79: invokevirtual b : (I)V
    //   82: aload_0
    //   83: aload #4
    //   85: getstatic a/b/c/k.BottomSheetBehavior_Layout_behavior_hideable : I
    //   88: iconst_0
    //   89: invokevirtual getBoolean : (IZ)Z
    //   92: invokevirtual b : (Z)V
    //   95: aload_0
    //   96: aload #4
    //   98: getstatic a/b/c/k.BottomSheetBehavior_Layout_behavior_fitToContents : I
    //   101: iconst_1
    //   102: invokevirtual getBoolean : (IZ)Z
    //   105: invokevirtual a : (Z)V
    //   108: aload_0
    //   109: aload #4
    //   111: getstatic a/b/c/k.BottomSheetBehavior_Layout_behavior_skipCollapsed : I
    //   114: iconst_0
    //   115: invokevirtual getBoolean : (IZ)Z
    //   118: invokevirtual c : (Z)V
    //   121: aload #4
    //   123: invokevirtual recycle : ()V
    //   126: aload_0
    //   127: aload_1
    //   128: invokestatic get : (Landroid/content/Context;)Landroid/view/ViewConfiguration;
    //   131: invokevirtual getScaledMaximumFlingVelocity : ()I
    //   134: i2f
    //   135: putfield b : F
    //   138: return
  }
  
  public static <V extends View> BottomSheetBehavior<V> b(V paramV) {
    ViewGroup.LayoutParams layoutParams = paramV.getLayoutParams();
    if (layoutParams instanceof CoordinatorLayout.f) {
      CoordinatorLayout.c c1 = ((CoordinatorLayout.f)layoutParams).d();
      if (c1 instanceof BottomSheetBehavior)
        return (BottomSheetBehavior<V>)c1; 
      throw new IllegalArgumentException("The view is not associated with BottomSheetBehavior");
    } 
    throw new IllegalArgumentException("The view is not a child of CoordinatorLayout");
  }
  
  private void c() {
    if (this.a) {
      this.i = Math.max(this.q - this.f, this.g);
    } else {
      this.i = this.q - this.f;
    } 
  }
  
  private int d() {
    boolean bool;
    if (this.a) {
      bool = this.g;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private void d(boolean paramBoolean) {
    WeakReference<V> weakReference = this.r;
    if (weakReference == null)
      return; 
    ViewParent viewParent = ((View)weakReference.get()).getParent();
    if (!(viewParent instanceof CoordinatorLayout))
      return; 
    CoordinatorLayout coordinatorLayout = (CoordinatorLayout)viewParent;
    int i = coordinatorLayout.getChildCount();
    if (Build.VERSION.SDK_INT >= 16 && paramBoolean)
      if (this.y == null) {
        this.y = new HashMap<View, Integer>(i);
      } else {
        return;
      }  
    for (byte b = 0; b < i; b++) {
      View view = coordinatorLayout.getChildAt(b);
      if (view != this.r.get())
        if (!paramBoolean) {
          Map<View, Integer> map = this.y;
          if (map != null && map.containsKey(view))
            u.f(view, ((Integer)this.y.get(view)).intValue()); 
        } else {
          if (Build.VERSION.SDK_INT >= 16)
            this.y.put(view, Integer.valueOf(view.getImportantForAccessibility())); 
          u.f(view, 4);
        }  
    } 
    if (!paramBoolean)
      this.y = null; 
  }
  
  private float e() {
    VelocityTracker velocityTracker = this.u;
    if (velocityTracker == null)
      return 0.0F; 
    velocityTracker.computeCurrentVelocity(1000, this.b);
    return this.u.getYVelocity(this.v);
  }
  
  private void f() {
    this.v = -1;
    VelocityTracker velocityTracker = this.u;
    if (velocityTracker != null) {
      velocityTracker.recycle();
      this.u = null;
    } 
  }
  
  View a(View paramView) {
    if (u.z(paramView))
      return paramView; 
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      byte b = 0;
      int i = viewGroup.getChildCount();
      while (b < i) {
        paramView = a(viewGroup.getChildAt(b));
        if (paramView != null)
          return paramView; 
        b++;
      } 
    } 
    return null;
  }
  
  void a(int paramInt) {
    View view = (View)this.r.get();
    if (view != null) {
      c c1 = this.t;
      if (c1 != null) {
        int i = this.i;
        if (paramInt > i) {
          c1.a(view, (i - paramInt) / (this.q - i));
        } else {
          c1.a(view, (i - paramInt) / (i - d()));
        } 
      } 
    } 
  }
  
  public void a(c paramc) {
    this.t = paramc;
  }
  
  public void a(CoordinatorLayout paramCoordinatorLayout, V paramV, Parcelable paramParcelable) {
    d d = (d)paramParcelable;
    super.a(paramCoordinatorLayout, paramV, d.a());
    int i = d.e;
    if (i == 1 || i == 2) {
      this.l = 4;
      return;
    } 
    this.l = i;
  }
  
  public void a(CoordinatorLayout paramCoordinatorLayout, V paramV, View paramView, int paramInt) {
    byte b;
    if (paramV.getTop() == d()) {
      d(3);
      return;
    } 
    if (paramView != this.s.get() || !this.p)
      return; 
    if (this.o > 0) {
      paramInt = d();
      b = 3;
    } else if (this.j && a((View)paramV, e())) {
      paramInt = this.q;
      b = 5;
    } else if (this.o == 0) {
      b = paramV.getTop();
      if (this.a) {
        if (Math.abs(b - this.g) < Math.abs(b - this.i)) {
          paramInt = this.g;
          b = 3;
        } else {
          paramInt = this.i;
          b = 4;
        } 
      } else {
        paramInt = this.h;
        if (b < paramInt) {
          if (b < Math.abs(b - this.i)) {
            paramInt = 0;
            b = 3;
          } else {
            paramInt = this.h;
            b = 6;
          } 
        } else if (Math.abs(b - paramInt) < Math.abs(b - this.i)) {
          paramInt = this.h;
          b = 6;
        } else {
          paramInt = this.i;
          b = 4;
        } 
      } 
    } else {
      paramInt = this.i;
      b = 4;
    } 
    if (this.m.b((View)paramV, paramV.getLeft(), paramInt)) {
      d(2);
      u.a((View)paramV, new e(this, (View)paramV, b));
    } else {
      d(b);
    } 
    this.p = false;
  }
  
  public void a(CoordinatorLayout paramCoordinatorLayout, V paramV, View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    if (paramInt3 == 1)
      return; 
    if (paramView != (View)this.s.get())
      return; 
    paramInt1 = paramV.getTop();
    paramInt3 = paramInt1 - paramInt2;
    if (paramInt2 > 0) {
      if (paramInt3 < d()) {
        paramArrayOfint[1] = paramInt1 - d();
        u.d((View)paramV, -paramArrayOfint[1]);
        d(3);
      } else {
        paramArrayOfint[1] = paramInt2;
        u.d((View)paramV, -paramInt2);
        d(1);
      } 
    } else if (paramInt2 < 0 && !paramView.canScrollVertically(-1)) {
      int i = this.i;
      if (paramInt3 <= i || this.j) {
        paramArrayOfint[1] = paramInt2;
        u.d((View)paramV, -paramInt2);
        d(1);
      } else {
        paramArrayOfint[1] = paramInt1 - i;
        u.d((View)paramV, -paramArrayOfint[1]);
        d(4);
      } 
    } 
    a(paramV.getTop());
    this.o = paramInt2;
    this.p = true;
  }
  
  void a(View paramView, int paramInt) {
    StringBuilder stringBuilder;
    int i;
    int j;
    if (paramInt == 4) {
      i = this.i;
      j = paramInt;
    } else if (paramInt == 6) {
      int k = this.h;
      i = k;
      j = paramInt;
      if (this.a) {
        i = k;
        j = paramInt;
        if (k <= this.g) {
          j = 3;
          i = this.g;
        } 
      } 
    } else if (paramInt == 3) {
      i = d();
      j = paramInt;
    } else if (this.j && paramInt == 5) {
      i = this.q;
      j = paramInt;
    } else {
      stringBuilder = new StringBuilder();
      stringBuilder.append("Illegal state argument: ");
      stringBuilder.append(paramInt);
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    if (this.m.b((View)stringBuilder, stringBuilder.getLeft(), i)) {
      d(2);
      u.a((View)stringBuilder, new e(this, (View)stringBuilder, j));
    } else {
      d(j);
    } 
  }
  
  public void a(boolean paramBoolean) {
    int i;
    if (this.a == paramBoolean)
      return; 
    this.a = paramBoolean;
    if (this.r != null)
      c(); 
    if (this.a && this.l == 6) {
      i = 3;
    } else {
      i = this.l;
    } 
    d(i);
  }
  
  public boolean a(CoordinatorLayout paramCoordinatorLayout, V paramV, int paramInt) {
    if (u.h((View)paramCoordinatorLayout) && !u.h((View)paramV))
      paramV.setFitsSystemWindows(true); 
    int i = paramV.getTop();
    paramCoordinatorLayout.c((View)paramV, paramInt);
    this.q = paramCoordinatorLayout.getHeight();
    if (this.d) {
      if (this.e == 0)
        this.e = paramCoordinatorLayout.getResources().getDimensionPixelSize(a.b.c.d.design_bottom_sheet_peek_height_min); 
      this.f = Math.max(this.e, this.q - paramCoordinatorLayout.getWidth() * 9 / 16);
    } else {
      this.f = this.c;
    } 
    this.g = Math.max(0, this.q - paramV.getHeight());
    this.h = this.q / 2;
    c();
    paramInt = this.l;
    if (paramInt == 3) {
      u.d((View)paramV, d());
    } else if (paramInt == 6) {
      u.d((View)paramV, this.h);
    } else if (this.j && paramInt == 5) {
      u.d((View)paramV, this.q);
    } else {
      paramInt = this.l;
      if (paramInt == 4) {
        u.d((View)paramV, this.i);
      } else if (paramInt == 1 || paramInt == 2) {
        u.d((View)paramV, i - paramV.getTop());
      } 
    } 
    if (this.m == null)
      this.m = s.a(paramCoordinatorLayout, this.z); 
    this.r = new WeakReference<V>(paramV);
    this.s = new WeakReference<View>(a((View)paramV));
    return true;
  }
  
  public boolean a(CoordinatorLayout paramCoordinatorLayout, V paramV, MotionEvent paramMotionEvent) {
    View view;
    boolean bool = paramV.isShown();
    boolean bool1 = false;
    if (!bool) {
      this.n = true;
      return false;
    } 
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      f(); 
    if (this.u == null)
      this.u = VelocityTracker.obtain(); 
    this.u.addMovement(paramMotionEvent);
    V v = null;
    if (i != 0) {
      if (i == 1 || i == 3) {
        this.x = false;
        this.v = -1;
        if (this.n) {
          this.n = false;
          return false;
        } 
      } 
    } else {
      int j = (int)paramMotionEvent.getX();
      this.w = (int)paramMotionEvent.getY();
      WeakReference<View> weakReference1 = this.s;
      if (weakReference1 != null) {
        View view1 = weakReference1.get();
      } else {
        weakReference1 = null;
      } 
      if (weakReference1 != null && paramCoordinatorLayout.a((View)weakReference1, j, this.w)) {
        this.v = paramMotionEvent.getPointerId(paramMotionEvent.getActionIndex());
        this.x = true;
      } 
      if (this.v == -1 && !paramCoordinatorLayout.a((View)paramV, j, this.w)) {
        bool = true;
      } else {
        bool = false;
      } 
      this.n = bool;
    } 
    if (!this.n) {
      s s1 = this.m;
      if (s1 != null && s1.b(paramMotionEvent))
        return true; 
    } 
    WeakReference<View> weakReference = this.s;
    paramV = v;
    if (weakReference != null)
      view = weakReference.get(); 
    if (i == 2 && view != null && !this.n && this.l != 1 && !paramCoordinatorLayout.a(view, (int)paramMotionEvent.getX(), (int)paramMotionEvent.getY()) && this.m != null && Math.abs(this.w - paramMotionEvent.getY()) > this.m.d()) {
      bool = true;
    } else {
      bool = bool1;
    } 
    return bool;
  }
  
  public boolean a(CoordinatorLayout paramCoordinatorLayout, V paramV, View paramView, float paramFloat1, float paramFloat2) {
    boolean bool;
    if (paramView == this.s.get() && (this.l != 3 || super.a(paramCoordinatorLayout, paramV, paramView, paramFloat1, paramFloat2))) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  boolean a(View paramView, float paramFloat) {
    boolean bool1 = this.k;
    boolean bool = true;
    if (bool1)
      return true; 
    if (paramView.getTop() < this.i)
      return false; 
    if (Math.abs(paramView.getTop() + 0.1F * paramFloat - this.i) / this.c <= 0.5F)
      bool = false; 
    return bool;
  }
  
  public final int b() {
    return this.l;
  }
  
  public final void b(int paramInt) {
    boolean bool = false;
    if (paramInt == -1) {
      if (!this.d) {
        this.d = true;
        bool = true;
      } 
    } else if (this.d || this.c != paramInt) {
      this.d = false;
      this.c = Math.max(0, paramInt);
      this.i = this.q - paramInt;
      bool = true;
    } 
    if (bool && this.l == 4) {
      WeakReference<V> weakReference = this.r;
      if (weakReference != null) {
        View view = (View)weakReference.get();
        if (view != null)
          view.requestLayout(); 
      } 
    } 
  }
  
  public void b(boolean paramBoolean) {
    this.j = paramBoolean;
  }
  
  public boolean b(CoordinatorLayout paramCoordinatorLayout, V paramV, MotionEvent paramMotionEvent) {
    if (!paramV.isShown())
      return false; 
    int i = paramMotionEvent.getActionMasked();
    if (this.l == 1 && i == 0)
      return true; 
    s s1 = this.m;
    if (s1 != null)
      s1.a(paramMotionEvent); 
    if (i == 0)
      f(); 
    if (this.u == null)
      this.u = VelocityTracker.obtain(); 
    this.u.addMovement(paramMotionEvent);
    if (i == 2 && !this.n && Math.abs(this.w - paramMotionEvent.getY()) > this.m.d())
      this.m.a((View)paramV, paramMotionEvent.getPointerId(paramMotionEvent.getActionIndex())); 
    return this.n ^ true;
  }
  
  public boolean b(CoordinatorLayout paramCoordinatorLayout, V paramV, View paramView1, View paramView2, int paramInt1, int paramInt2) {
    boolean bool = false;
    this.o = 0;
    this.p = false;
    if ((paramInt1 & 0x2) != 0)
      bool = true; 
    return bool;
  }
  
  public final void c(int paramInt) {
    if (paramInt == this.l)
      return; 
    WeakReference<V> weakReference = this.r;
    if (weakReference == null) {
      if (paramInt == 4 || paramInt == 3 || paramInt == 6 || (this.j && paramInt == 5))
        this.l = paramInt; 
      return;
    } 
    View view = (View)weakReference.get();
    if (view == null)
      return; 
    ViewParent viewParent = view.getParent();
    if (viewParent != null && viewParent.isLayoutRequested() && u.x(view)) {
      view.post(new a(this, view, paramInt));
    } else {
      a(view, paramInt);
    } 
  }
  
  public void c(boolean paramBoolean) {
    this.k = paramBoolean;
  }
  
  public Parcelable d(CoordinatorLayout paramCoordinatorLayout, V paramV) {
    return (Parcelable)new d(super.d(paramCoordinatorLayout, paramV), this.l);
  }
  
  void d(int paramInt) {
    if (this.l == paramInt)
      return; 
    this.l = paramInt;
    if (paramInt == 6 || paramInt == 3) {
      d(true);
    } else if (paramInt == 5 || paramInt == 4) {
      d(false);
    } 
    View view = (View)this.r.get();
    if (view != null) {
      c c1 = this.t;
      if (c1 != null)
        c1.a(view, paramInt); 
    } 
  }
  
  class a implements Runnable {
    final View c;
    
    final int d;
    
    final BottomSheetBehavior e;
    
    a(BottomSheetBehavior this$0, View param1View, int param1Int) {}
    
    public void run() {
      this.e.a(this.c, this.d);
    }
  }
  
  class b extends s.c {
    final BottomSheetBehavior a;
    
    b(BottomSheetBehavior this$0) {}
    
    public int a(View param1View, int param1Int1, int param1Int2) {
      return param1View.getLeft();
    }
    
    public void a(View param1View, float param1Float1, float param1Float2) {
      int i;
      byte b1;
      if (param1Float2 < 0.0F) {
        if (BottomSheetBehavior.a(this.a)) {
          i = this.a.g;
          b1 = 3;
        } else {
          i = param1View.getTop();
          BottomSheetBehavior bottomSheetBehavior = this.a;
          if (i > bottomSheetBehavior.h) {
            i = bottomSheetBehavior.h;
            b1 = 6;
          } else {
            b1 = 3;
            i = 0;
          } 
        } 
      } else {
        BottomSheetBehavior bottomSheetBehavior = this.a;
        if (bottomSheetBehavior.j && bottomSheetBehavior.a(param1View, param1Float2) && (param1View.getTop() > this.a.i || Math.abs(param1Float1) < Math.abs(param1Float2))) {
          i = this.a.q;
          b1 = 5;
        } else if (param1Float2 == 0.0F || Math.abs(param1Float1) > Math.abs(param1Float2)) {
          i = param1View.getTop();
          if (BottomSheetBehavior.a(this.a)) {
            if (Math.abs(i - this.a.g) < Math.abs(i - this.a.i)) {
              i = this.a.g;
              b1 = 3;
            } else {
              i = this.a.i;
              b1 = 4;
            } 
          } else {
            bottomSheetBehavior = this.a;
            b1 = bottomSheetBehavior.h;
            if (i < b1) {
              if (i < Math.abs(i - bottomSheetBehavior.i)) {
                i = 0;
                b1 = 3;
              } else {
                i = this.a.h;
                b1 = 6;
              } 
            } else if (Math.abs(i - b1) < Math.abs(i - this.a.i)) {
              i = this.a.h;
              b1 = 6;
            } else {
              i = this.a.i;
              b1 = 4;
            } 
          } 
        } else {
          i = this.a.i;
          b1 = 4;
        } 
      } 
      if (this.a.m.d(param1View.getLeft(), i)) {
        this.a.d(2);
        u.a(param1View, new BottomSheetBehavior.e(this.a, param1View, b1));
      } else {
        this.a.d(b1);
      } 
    }
    
    public void a(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.a.a(param1Int2);
    }
    
    public int b(View param1View) {
      BottomSheetBehavior bottomSheetBehavior = this.a;
      return bottomSheetBehavior.j ? bottomSheetBehavior.q : bottomSheetBehavior.i;
    }
    
    public int b(View param1View, int param1Int1, int param1Int2) {
      int i = BottomSheetBehavior.b(this.a);
      BottomSheetBehavior bottomSheetBehavior = this.a;
      if (bottomSheetBehavior.j) {
        param1Int2 = bottomSheetBehavior.q;
      } else {
        param1Int2 = bottomSheetBehavior.i;
      } 
      return a.b.g.c.a.a(param1Int1, i, param1Int2);
    }
    
    public boolean b(View param1View, int param1Int) {
      BottomSheetBehavior bottomSheetBehavior = this.a;
      int i = bottomSheetBehavior.l;
      boolean bool = true;
      if (i == 1)
        return false; 
      if (bottomSheetBehavior.x)
        return false; 
      if (i == 3 && bottomSheetBehavior.v == param1Int) {
        View view = bottomSheetBehavior.s.get();
        if (view != null && view.canScrollVertically(-1))
          return false; 
      } 
      WeakReference<View> weakReference = this.a.r;
      if (weakReference == null || weakReference.get() != param1View)
        bool = false; 
      return bool;
    }
    
    public void c(int param1Int) {
      if (param1Int == 1)
        this.a.d(1); 
    }
  }
  
  public static abstract class c {
    public abstract void a(View param1View, float param1Float);
    
    public abstract void a(View param1View, int param1Int);
  }
  
  protected static class d extends android.support.v4.view.a {
    public static final Parcelable.Creator<d> CREATOR = (Parcelable.Creator<d>)new a();
    
    final int e;
    
    public d(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      this.e = param1Parcel.readInt();
    }
    
    public d(Parcelable param1Parcelable, int param1Int) {
      super(param1Parcelable);
      this.e = param1Int;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.e);
    }
    
    static final class a implements Parcelable.ClassLoaderCreator<d> {
      public BottomSheetBehavior.d createFromParcel(Parcel param2Parcel) {
        return new BottomSheetBehavior.d(param2Parcel, null);
      }
      
      public BottomSheetBehavior.d createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new BottomSheetBehavior.d(param2Parcel, param2ClassLoader);
      }
      
      public BottomSheetBehavior.d[] newArray(int param2Int) {
        return new BottomSheetBehavior.d[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.ClassLoaderCreator<d> {
    public BottomSheetBehavior.d createFromParcel(Parcel param1Parcel) {
      return new BottomSheetBehavior.d(param1Parcel, null);
    }
    
    public BottomSheetBehavior.d createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new BottomSheetBehavior.d(param1Parcel, param1ClassLoader);
    }
    
    public BottomSheetBehavior.d[] newArray(int param1Int) {
      return new BottomSheetBehavior.d[param1Int];
    }
  }
  
  private class e implements Runnable {
    private final View c;
    
    private final int d;
    
    final BottomSheetBehavior e;
    
    e(BottomSheetBehavior this$0, View param1View, int param1Int) {
      this.c = param1View;
      this.d = param1Int;
    }
    
    public void run() {
      s s = this.e.m;
      if (s != null && s.a(true)) {
        u.a(this.c, this);
      } else {
        this.e.d(this.d);
      } 
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\BottomSheetBehavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */