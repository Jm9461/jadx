package android.support.design.widget;

import a.b.g.c.a;
import android.content.Context;
import android.graphics.Rect;
import android.support.v4.view.c0;
import android.support.v4.view.d;
import android.support.v4.view.u;
import android.util.AttributeSet;
import android.view.View;
import java.util.List;

abstract class o extends x<View> {
  final Rect d = new Rect();
  
  final Rect e = new Rect();
  
  private int f = 0;
  
  private int g;
  
  public o() {}
  
  public o(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  private static int c(int paramInt) {
    if (paramInt == 0)
      paramInt = 8388659; 
    return paramInt;
  }
  
  final int a(View paramView) {
    int j = this.g;
    int i = 0;
    if (j != 0) {
      float f = b(paramView);
      i = this.g;
      i = a.a((int)(f * i), 0, i);
    } 
    return i;
  }
  
  abstract View a(List<View> paramList);
  
  public boolean a(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = (paramView.getLayoutParams()).height;
    if (i == -1 || i == -2) {
      View view = a(paramCoordinatorLayout.b(paramView));
      if (view != null) {
        if (u.h(view) && !u.h(paramView)) {
          u.a(paramView, true);
          if (u.h(paramView)) {
            paramView.requestLayout();
            return true;
          } 
        } 
        paramInt3 = View.MeasureSpec.getSize(paramInt3);
        if (paramInt3 == 0)
          paramInt3 = paramCoordinatorLayout.getHeight(); 
        int k = view.getMeasuredHeight();
        int j = c(view);
        if (i == -1) {
          i = 1073741824;
        } else {
          i = Integer.MIN_VALUE;
        } 
        paramCoordinatorLayout.a(paramView, paramInt1, paramInt2, View.MeasureSpec.makeMeasureSpec(paramInt3 - k + j, i), paramInt4);
        return true;
      } 
    } 
    return false;
  }
  
  abstract float b(View paramView);
  
  public final void b(int paramInt) {
    this.g = paramInt;
  }
  
  protected void b(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt) {
    Rect rect;
    View view = a(paramCoordinatorLayout.b(paramView));
    if (view != null) {
      CoordinatorLayout.f f = (CoordinatorLayout.f)paramView.getLayoutParams();
      Rect rect1 = this.d;
      rect1.set(paramCoordinatorLayout.getPaddingLeft() + f.leftMargin, view.getBottom() + f.topMargin, paramCoordinatorLayout.getWidth() - paramCoordinatorLayout.getPaddingRight() - f.rightMargin, paramCoordinatorLayout.getHeight() + view.getBottom() - paramCoordinatorLayout.getPaddingBottom() - f.bottomMargin);
      c0 c0 = paramCoordinatorLayout.getLastWindowInsets();
      if (c0 != null && u.h((View)paramCoordinatorLayout) && !u.h(paramView)) {
        rect1.left += c0.c();
        rect1.right -= c0.d();
      } 
      rect = this.e;
      d.a(c(f.c), paramView.getMeasuredWidth(), paramView.getMeasuredHeight(), rect1, rect, paramInt);
      paramInt = a(view);
      paramView.layout(rect.left, rect.top - paramInt, rect.right, rect.bottom - paramInt);
      this.f = rect.top - view.getBottom();
    } else {
      super.b((CoordinatorLayout)rect, paramView, paramInt);
      this.f = 0;
    } 
  }
  
  public final int c() {
    return this.g;
  }
  
  int c(View paramView) {
    return paramView.getMeasuredHeight();
  }
  
  final int d() {
    return this.f;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */