package android.support.design.internal;

import android.content.Context;
import android.support.v7.view.menu.h;
import android.support.v7.view.menu.k;
import android.support.v7.view.menu.v;

public class d extends v {
  public d(Context paramContext, b paramb, k paramk) {
    super(paramContext, paramb, paramk);
  }
  
  public void b(boolean paramBoolean) {
    super.b(paramBoolean);
    ((h)t()).b(paramBoolean);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\internal\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */