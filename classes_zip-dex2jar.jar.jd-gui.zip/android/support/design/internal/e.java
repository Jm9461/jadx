package android.support.design.internal;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.SparseArray;

public class e extends SparseArray<Parcelable> implements Parcelable {
  public static final Parcelable.Creator<e> CREATOR = (Parcelable.Creator<e>)new a();
  
  public e() {}
  
  public e(Parcel paramParcel, ClassLoader paramClassLoader) {
    int i = paramParcel.readInt();
    int[] arrayOfInt = new int[i];
    paramParcel.readIntArray(arrayOfInt);
    Parcelable[] arrayOfParcelable = paramParcel.readParcelableArray(paramClassLoader);
    for (byte b = 0; b < i; b++)
      put(arrayOfInt[b], arrayOfParcelable[b]); 
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = size();
    int[] arrayOfInt = new int[i];
    Parcelable[] arrayOfParcelable = new Parcelable[i];
    for (byte b = 0; b < i; b++) {
      arrayOfInt[b] = keyAt(b);
      arrayOfParcelable[b] = (Parcelable)valueAt(b);
    } 
    paramParcel.writeInt(i);
    paramParcel.writeIntArray(arrayOfInt);
    paramParcel.writeParcelableArray(arrayOfParcelable, paramInt);
  }
  
  static final class a implements Parcelable.ClassLoaderCreator<e> {
    public e createFromParcel(Parcel param1Parcel) {
      return new e(param1Parcel, null);
    }
    
    public e createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new e(param1Parcel, param1ClassLoader);
    }
    
    public e[] newArray(int param1Int) {
      return new e[param1Int];
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\internal\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */