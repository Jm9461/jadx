package android.support.design.internal;

import a.b.c.d;
import a.b.c.e;
import a.b.c.f;
import a.b.c.h;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.support.v4.content.e.f;
import android.support.v4.view.b;
import android.support.v4.view.d0.c;
import android.support.v4.view.u;
import android.support.v4.widget.p;
import android.support.v7.view.menu.k;
import android.support.v7.view.menu.q;
import android.support.v7.widget.l1;
import android.support.v7.widget.o0;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.CheckedTextView;
import android.widget.FrameLayout;
import android.widget.TextView;

public class NavigationMenuItemView extends a implements q.a {
  private static final int[] H = new int[] { 16842912 };
  
  private final CheckedTextView A;
  
  private FrameLayout B;
  
  private k C;
  
  private ColorStateList D;
  
  private boolean E;
  
  private Drawable F;
  
  private final b G = new a(this);
  
  private final int x;
  
  private boolean y;
  
  boolean z;
  
  public NavigationMenuItemView(Context paramContext) {
    this(paramContext, null);
  }
  
  public NavigationMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public NavigationMenuItemView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    setOrientation(0);
    LayoutInflater.from(paramContext).inflate(h.design_navigation_menu_item, (ViewGroup)this, true);
    this.x = paramContext.getResources().getDimensionPixelSize(d.design_navigation_icon_size);
    this.A = (CheckedTextView)findViewById(f.design_menu_item_text);
    this.A.setDuplicateParentStateEnabled(true);
    u.a((View)this.A, this.G);
  }
  
  private void e() {
    if (g()) {
      this.A.setVisibility(8);
      FrameLayout frameLayout = this.B;
      if (frameLayout != null) {
        o0.a a1 = (o0.a)frameLayout.getLayoutParams();
        ((ViewGroup.MarginLayoutParams)a1).width = -1;
        this.B.setLayoutParams((ViewGroup.LayoutParams)a1);
      } 
    } else {
      this.A.setVisibility(0);
      FrameLayout frameLayout = this.B;
      if (frameLayout != null) {
        o0.a a1 = (o0.a)frameLayout.getLayoutParams();
        ((ViewGroup.MarginLayoutParams)a1).width = -2;
        this.B.setLayoutParams((ViewGroup.LayoutParams)a1);
      } 
    } 
  }
  
  private StateListDrawable f() {
    TypedValue typedValue = new TypedValue();
    if (getContext().getTheme().resolveAttribute(a.b.h.a.a.colorControlHighlight, typedValue, true)) {
      StateListDrawable stateListDrawable = new StateListDrawable();
      stateListDrawable.addState(H, (Drawable)new ColorDrawable(typedValue.data));
      stateListDrawable.addState(ViewGroup.EMPTY_STATE_SET, (Drawable)new ColorDrawable(0));
      return stateListDrawable;
    } 
    return null;
  }
  
  private boolean g() {
    boolean bool;
    if (this.C.getTitle() == null && this.C.getIcon() == null && this.C.getActionView() != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private void setActionView(View paramView) {
    if (paramView != null) {
      if (this.B == null)
        this.B = (FrameLayout)((ViewStub)findViewById(f.design_menu_item_action_area_stub)).inflate(); 
      this.B.removeAllViews();
      this.B.addView(paramView);
    } 
  }
  
  public void a(k paramk, int paramInt) {
    this.C = paramk;
    if (paramk.isVisible()) {
      paramInt = 0;
    } else {
      paramInt = 8;
    } 
    setVisibility(paramInt);
    if (getBackground() == null)
      u.a((View)this, (Drawable)f()); 
    setCheckable(paramk.isCheckable());
    setChecked(paramk.isChecked());
    setEnabled(paramk.isEnabled());
    setTitle(paramk.getTitle());
    setIcon(paramk.getIcon());
    setActionView(paramk.getActionView());
    setContentDescription(paramk.getContentDescription());
    l1.a((View)this, paramk.getTooltipText());
    e();
  }
  
  public boolean a() {
    return false;
  }
  
  public void d() {
    FrameLayout frameLayout = this.B;
    if (frameLayout != null)
      frameLayout.removeAllViews(); 
    this.A.setCompoundDrawables(null, null, null, null);
  }
  
  public k getItemData() {
    return this.C;
  }
  
  protected int[] onCreateDrawableState(int paramInt) {
    int[] arrayOfInt = super.onCreateDrawableState(paramInt + 1);
    k k1 = this.C;
    if (k1 != null && k1.isCheckable() && this.C.isChecked())
      ViewGroup.mergeDrawableStates(arrayOfInt, H); 
    return arrayOfInt;
  }
  
  public void setCheckable(boolean paramBoolean) {
    refreshDrawableState();
    if (this.z != paramBoolean) {
      this.z = paramBoolean;
      this.G.a((View)this.A, 2048);
    } 
  }
  
  public void setChecked(boolean paramBoolean) {
    refreshDrawableState();
    this.A.setChecked(paramBoolean);
  }
  
  public void setHorizontalPadding(int paramInt) {
    setPadding(paramInt, 0, paramInt, 0);
  }
  
  public void setIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      Drawable drawable = paramDrawable;
      if (this.E) {
        Drawable.ConstantState constantState = paramDrawable.getConstantState();
        if (constantState != null)
          paramDrawable = constantState.newDrawable(); 
        drawable = android.support.v4.graphics.drawable.a.h(paramDrawable).mutate();
        android.support.v4.graphics.drawable.a.a(drawable, this.D);
      } 
      int i = this.x;
      drawable.setBounds(0, 0, i, i);
      paramDrawable = drawable;
    } else if (this.y) {
      if (this.F == null) {
        this.F = f.a(getResources(), e.navigation_empty_icon, getContext().getTheme());
        paramDrawable = this.F;
        if (paramDrawable != null) {
          int i = this.x;
          paramDrawable.setBounds(0, 0, i, i);
        } 
      } 
      paramDrawable = this.F;
    } 
    p.a((TextView)this.A, paramDrawable, null, null, null);
  }
  
  public void setIconPadding(int paramInt) {
    this.A.setCompoundDrawablePadding(paramInt);
  }
  
  void setIconTintList(ColorStateList paramColorStateList) {
    boolean bool;
    this.D = paramColorStateList;
    if (this.D != null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.E = bool;
    k k1 = this.C;
    if (k1 != null)
      setIcon(k1.getIcon()); 
  }
  
  public void setNeedsEmptyIcon(boolean paramBoolean) {
    this.y = paramBoolean;
  }
  
  public void setTextAppearance(int paramInt) {
    p.d((TextView)this.A, paramInt);
  }
  
  public void setTextColor(ColorStateList paramColorStateList) {
    this.A.setTextColor(paramColorStateList);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.A.setText(paramCharSequence);
  }
  
  class a extends b {
    final NavigationMenuItemView c;
    
    a(NavigationMenuItemView this$0) {}
    
    public void a(View param1View, c param1c) {
      super.a(param1View, param1c);
      param1c.b(this.c.z);
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\internal\NavigationMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */