package android.support.design.internal;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.c0;
import android.support.v4.view.u;
import android.support.v7.view.menu.p;
import android.support.v7.view.menu.q;
import android.support.v7.view.menu.v;
import android.support.v7.widget.RecyclerView;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;

public class c implements p {
  private NavigationMenuView c;
  
  LinearLayout d;
  
  private p.a e;
  
  android.support.v7.view.menu.h f;
  
  private int g;
  
  c h;
  
  LayoutInflater i;
  
  int j;
  
  boolean k;
  
  ColorStateList l;
  
  ColorStateList m;
  
  Drawable n;
  
  int o;
  
  int p;
  
  private int q;
  
  int r;
  
  final View.OnClickListener s = new a(this);
  
  public int a() {
    return this.g;
  }
  
  public q a(ViewGroup paramViewGroup) {
    if (this.c == null) {
      this.c = (NavigationMenuView)this.i.inflate(a.b.c.h.design_navigation_menu, paramViewGroup, false);
      if (this.h == null)
        this.h = new c(this); 
      this.d = (LinearLayout)this.i.inflate(a.b.c.h.design_navigation_item_header, (ViewGroup)this.c, false);
      this.c.setAdapter(this.h);
    } 
    return this.c;
  }
  
  public View a(int paramInt) {
    View view = this.i.inflate(paramInt, (ViewGroup)this.d, false);
    a(view);
    return view;
  }
  
  public void a(Context paramContext, android.support.v7.view.menu.h paramh) {
    this.i = LayoutInflater.from(paramContext);
    this.f = paramh;
    this.r = paramContext.getResources().getDimensionPixelOffset(a.b.c.d.design_navigation_separator_vertical_padding);
  }
  
  public void a(ColorStateList paramColorStateList) {
    this.m = paramColorStateList;
    a(false);
  }
  
  public void a(Drawable paramDrawable) {
    this.n = paramDrawable;
    a(false);
  }
  
  public void a(Parcelable paramParcelable) {
    if (paramParcelable instanceof Bundle) {
      Bundle bundle1 = (Bundle)paramParcelable;
      SparseArray sparseArray2 = bundle1.getSparseParcelableArray("android:menu:list");
      if (sparseArray2 != null)
        this.c.restoreHierarchyState(sparseArray2); 
      Bundle bundle2 = bundle1.getBundle("android:menu:adapter");
      if (bundle2 != null)
        this.h.a(bundle2); 
      SparseArray sparseArray1 = bundle1.getSparseParcelableArray("android:menu:header");
      if (sparseArray1 != null)
        this.d.restoreHierarchyState(sparseArray1); 
    } 
  }
  
  public void a(c0 paramc0) {
    int i = paramc0.e();
    if (this.q != i) {
      this.q = i;
      if (this.d.getChildCount() == 0) {
        NavigationMenuView navigationMenuView = this.c;
        navigationMenuView.setPadding(0, this.q, 0, navigationMenuView.getPaddingBottom());
      } 
    } 
    u.a((View)this.d, paramc0);
  }
  
  public void a(android.support.v7.view.menu.h paramh, boolean paramBoolean) {
    p.a a1 = this.e;
    if (a1 != null)
      a1.a(paramh, paramBoolean); 
  }
  
  public void a(android.support.v7.view.menu.k paramk) {
    this.h.a(paramk);
  }
  
  public void a(View paramView) {
    this.d.addView(paramView);
    NavigationMenuView navigationMenuView = this.c;
    navigationMenuView.setPadding(0, 0, 0, navigationMenuView.getPaddingBottom());
  }
  
  public void a(boolean paramBoolean) {
    c c1 = this.h;
    if (c1 != null)
      c1.g(); 
  }
  
  public boolean a(android.support.v7.view.menu.h paramh, android.support.v7.view.menu.k paramk) {
    return false;
  }
  
  public boolean a(v paramv) {
    return false;
  }
  
  public void b(int paramInt) {
    this.g = paramInt;
  }
  
  public void b(ColorStateList paramColorStateList) {
    this.l = paramColorStateList;
    a(false);
  }
  
  public void b(boolean paramBoolean) {
    c c1 = this.h;
    if (c1 != null)
      c1.b(paramBoolean); 
  }
  
  public boolean b() {
    return false;
  }
  
  public boolean b(android.support.v7.view.menu.h paramh, android.support.v7.view.menu.k paramk) {
    return false;
  }
  
  public Parcelable c() {
    Bundle bundle = new Bundle();
    if (this.c != null) {
      SparseArray sparseArray = new SparseArray();
      this.c.saveHierarchyState(sparseArray);
      bundle.putSparseParcelableArray("android:menu:list", sparseArray);
    } 
    c c1 = this.h;
    if (c1 != null)
      bundle.putBundle("android:menu:adapter", c1.e()); 
    if (this.d != null) {
      SparseArray sparseArray = new SparseArray();
      this.d.saveHierarchyState(sparseArray);
      bundle.putSparseParcelableArray("android:menu:header", sparseArray);
    } 
    return (Parcelable)bundle;
  }
  
  public void c(int paramInt) {
    this.o = paramInt;
    a(false);
  }
  
  public android.support.v7.view.menu.k d() {
    return this.h.f();
  }
  
  public void d(int paramInt) {
    this.p = paramInt;
    a(false);
  }
  
  public int e() {
    return this.d.getChildCount();
  }
  
  public void e(int paramInt) {
    this.j = paramInt;
    this.k = true;
    a(false);
  }
  
  public Drawable f() {
    return this.n;
  }
  
  public int g() {
    return this.o;
  }
  
  public int h() {
    return this.p;
  }
  
  public ColorStateList i() {
    return this.l;
  }
  
  public ColorStateList j() {
    return this.m;
  }
  
  class a implements View.OnClickListener {
    final c c;
    
    a(c this$0) {}
    
    public void onClick(View param1View) {
      NavigationMenuItemView navigationMenuItemView = (NavigationMenuItemView)param1View;
      this.c.b(true);
      android.support.v7.view.menu.k k = navigationMenuItemView.getItemData();
      c c1 = this.c;
      boolean bool = c1.f.a((MenuItem)k, c1, 0);
      if (k != null && k.isCheckable() && bool)
        this.c.h.a(k); 
      this.c.b(false);
      this.c.a(false);
    }
  }
  
  private static class b extends k {
    public b(View param1View) {
      super(param1View);
    }
  }
  
  private class c extends RecyclerView.g<k> {
    private final ArrayList<c.e> c = new ArrayList<c.e>();
    
    private android.support.v7.view.menu.k d;
    
    private boolean e;
    
    final c f;
    
    c(c this$0) {
      h();
    }
    
    private void a(int param1Int1, int param1Int2) {
      while (param1Int1 < param1Int2) {
        ((c.g)this.c.get(param1Int1)).b = true;
        param1Int1++;
      } 
    }
    
    private void h() {
      if (this.e)
        return; 
      this.e = true;
      this.c.clear();
      this.c.add(new c.d());
      int j = -1;
      int i = 0;
      boolean bool = false;
      byte b = 0;
      int m = this.f.f.n().size();
      while (true) {
        boolean bool1 = false;
        if (b < m) {
          int n;
          android.support.v7.view.menu.k k1 = this.f.f.n().get(b);
          if (k1.isChecked())
            a(k1); 
          if (k1.isCheckable())
            k1.c(false); 
          if (k1.hasSubMenu()) {
            SubMenu subMenu = k1.getSubMenu();
            if (subMenu.hasVisibleItems()) {
              if (b != 0)
                this.c.add(new c.f(this.f.r, 0)); 
              this.c.add(new c.g(k1));
              boolean bool2 = false;
              int i2 = this.c.size();
              byte b1 = 0;
              int i1 = subMenu.size();
              while (b1 < i1) {
                android.support.v7.view.menu.k k2 = (android.support.v7.view.menu.k)subMenu.getItem(b1);
                boolean bool3 = bool2;
                if (k2.isVisible()) {
                  bool3 = bool2;
                  if (!bool2) {
                    bool3 = bool2;
                    if (k2.getIcon() != null)
                      bool3 = true; 
                  } 
                  if (k2.isCheckable())
                    k2.c(false); 
                  if (k1.isChecked())
                    a(k1); 
                  this.c.add(new c.g(k2));
                } 
                b1++;
                bool2 = bool3;
              } 
              if (bool2)
                a(i2, this.c.size()); 
            } 
            n = i;
            bool1 = bool;
          } else {
            int i1 = k1.getGroupId();
            if (i1 != j) {
              i = this.c.size();
              if (k1.getIcon() != null)
                bool1 = true; 
              bool = bool1;
              n = i;
              bool1 = bool;
              if (b != 0) {
                n = i + 1;
                ArrayList<c.e> arrayList = this.c;
                i = this.f.r;
                arrayList.add(new c.f(i, i));
                bool1 = bool;
              } 
            } else {
              n = i;
              bool1 = bool;
              if (!bool) {
                n = i;
                bool1 = bool;
                if (k1.getIcon() != null) {
                  bool1 = true;
                  a(i, this.c.size());
                  n = i;
                } 
              } 
            } 
            c.g g1 = new c.g(k1);
            g1.b = bool1;
            this.c.add(g1);
            j = i1;
          } 
          b++;
          i = n;
          bool = bool1;
          continue;
        } 
        this.e = false;
        return;
      } 
    }
    
    public int a() {
      return this.c.size();
    }
    
    public long a(int param1Int) {
      return param1Int;
    }
    
    public void a(Bundle param1Bundle) {
      int i = param1Bundle.getInt("android:menu:checked", 0);
      if (i != 0) {
        this.e = true;
        byte b = 0;
        int j = this.c.size();
        while (b < j) {
          c.e e = this.c.get(b);
          if (e instanceof c.g) {
            android.support.v7.view.menu.k k1 = ((c.g)e).a();
            if (k1 != null && k1.getItemId() == i) {
              a(k1);
              break;
            } 
          } 
          b++;
        } 
        this.e = false;
        h();
      } 
      SparseArray sparseArray = param1Bundle.getSparseParcelableArray("android:menu:action_views");
      if (sparseArray != null) {
        byte b = 0;
        int j = this.c.size();
        while (b < j) {
          c.e e = this.c.get(b);
          if (e instanceof c.g) {
            android.support.v7.view.menu.k k1 = ((c.g)e).a();
            if (k1 != null) {
              View view = k1.getActionView();
              if (view != null) {
                e e1 = (e)sparseArray.get(k1.getItemId());
                if (e1 != null)
                  view.restoreHierarchyState(e1); 
              } 
            } 
          } 
          b++;
        } 
      } 
    }
    
    public void a(c.k param1k) {
      if (param1k instanceof c.h)
        ((NavigationMenuItemView)param1k.c).d(); 
    }
    
    public void a(c.k param1k, int param1Int) {
      int i = b(param1Int);
      if (i != 0) {
        if (i != 1) {
          if (i == 2) {
            c.f f = (c.f)this.c.get(param1Int);
            param1k.c.setPadding(0, f.b(), 0, f.a());
          } 
        } else {
          ((TextView)param1k.c).setText(((c.g)this.c.get(param1Int)).a().getTitle());
        } 
      } else {
        NavigationMenuItemView navigationMenuItemView = (NavigationMenuItemView)param1k.c;
        navigationMenuItemView.setIconTintList(this.f.m);
        c c1 = this.f;
        if (c1.k)
          navigationMenuItemView.setTextAppearance(c1.j); 
        ColorStateList colorStateList = this.f.l;
        if (colorStateList != null)
          navigationMenuItemView.setTextColor(colorStateList); 
        Drawable drawable = this.f.n;
        if (drawable != null) {
          drawable = drawable.getConstantState().newDrawable();
        } else {
          drawable = null;
        } 
        u.a((View)navigationMenuItemView, drawable);
        c.g g1 = (c.g)this.c.get(param1Int);
        navigationMenuItemView.setNeedsEmptyIcon(g1.b);
        navigationMenuItemView.setHorizontalPadding(this.f.o);
        navigationMenuItemView.setIconPadding(this.f.p);
        navigationMenuItemView.a(g1.a(), 0);
      } 
    }
    
    public void a(android.support.v7.view.menu.k param1k) {
      if (this.d == param1k || !param1k.isCheckable())
        return; 
      android.support.v7.view.menu.k k1 = this.d;
      if (k1 != null)
        k1.setChecked(false); 
      this.d = param1k;
      param1k.setChecked(true);
    }
    
    public int b(int param1Int) {
      c.e e = this.c.get(param1Int);
      if (e instanceof c.f)
        return 2; 
      if (e instanceof c.d)
        return 3; 
      if (e instanceof c.g)
        return ((c.g)e).a().hasSubMenu() ? 1 : 0; 
      throw new RuntimeException("Unknown item type.");
    }
    
    public c.k b(ViewGroup param1ViewGroup, int param1Int) {
      if (param1Int != 0)
        return (c.k)((param1Int != 1) ? ((param1Int != 2) ? ((param1Int != 3) ? null : new c.b((View)this.f.d)) : new c.i(this.f.i, param1ViewGroup)) : new c.j(this.f.i, param1ViewGroup)); 
      c c1 = this.f;
      return new c.h(c1.i, param1ViewGroup, c1.s);
    }
    
    public void b(boolean param1Boolean) {
      this.e = param1Boolean;
    }
    
    public Bundle e() {
      Bundle bundle = new Bundle();
      android.support.v7.view.menu.k k1 = this.d;
      if (k1 != null)
        bundle.putInt("android:menu:checked", k1.getItemId()); 
      SparseArray sparseArray = new SparseArray();
      byte b = 0;
      int i = this.c.size();
      while (b < i) {
        c.e e = this.c.get(b);
        if (e instanceof c.g) {
          android.support.v7.view.menu.k k2 = ((c.g)e).a();
          if (k2 != null) {
            View view = k2.getActionView();
          } else {
            e = null;
          } 
          if (e != null) {
            e e1 = new e();
            e.saveHierarchyState(e1);
            sparseArray.put(k2.getItemId(), e1);
          } 
        } 
        b++;
      } 
      bundle.putSparseParcelableArray("android:menu:action_views", sparseArray);
      return bundle;
    }
    
    public android.support.v7.view.menu.k f() {
      return this.d;
    }
    
    public void g() {
      h();
      d();
    }
  }
  
  private static class d implements e {}
  
  private static interface e {}
  
  private static class f implements e {
    private final int a;
    
    private final int b;
    
    public f(int param1Int1, int param1Int2) {
      this.a = param1Int1;
      this.b = param1Int2;
    }
    
    public int a() {
      return this.b;
    }
    
    public int b() {
      return this.a;
    }
  }
  
  private static class g implements e {
    private final android.support.v7.view.menu.k a;
    
    boolean b;
    
    g(android.support.v7.view.menu.k param1k) {
      this.a = param1k;
    }
    
    public android.support.v7.view.menu.k a() {
      return this.a;
    }
  }
  
  private static class h extends k {
    public h(LayoutInflater param1LayoutInflater, ViewGroup param1ViewGroup, View.OnClickListener param1OnClickListener) {
      super(param1LayoutInflater.inflate(a.b.c.h.design_navigation_item, param1ViewGroup, false));
      this.c.setOnClickListener(param1OnClickListener);
    }
  }
  
  private static class i extends k {
    public i(LayoutInflater param1LayoutInflater, ViewGroup param1ViewGroup) {
      super(param1LayoutInflater.inflate(a.b.c.h.design_navigation_item_separator, param1ViewGroup, false));
    }
  }
  
  private static class j extends k {
    public j(LayoutInflater param1LayoutInflater, ViewGroup param1ViewGroup) {
      super(param1LayoutInflater.inflate(a.b.c.h.design_navigation_item_subheader, param1ViewGroup, false));
    }
  }
  
  private static abstract class k extends RecyclerView.d0 {
    public k(View param1View) {
      super(param1View);
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\internal\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */