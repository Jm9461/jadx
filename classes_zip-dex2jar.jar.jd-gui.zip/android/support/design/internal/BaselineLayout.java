package android.support.design.internal;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

public class BaselineLayout extends ViewGroup {
  private int c = -1;
  
  public BaselineLayout(Context paramContext) {
    super(paramContext, null, 0);
  }
  
  public BaselineLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 0);
  }
  
  public BaselineLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  public int getBaseline() {
    return this.c;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int j = getChildCount();
    int k = getPaddingLeft();
    int m = getPaddingRight();
    int i = getPaddingTop();
    for (paramInt2 = 0; paramInt2 < j; paramInt2++) {
      View view = getChildAt(paramInt2);
      if (view.getVisibility() != 8) {
        int i1 = view.getMeasuredWidth();
        int i2 = view.getMeasuredHeight();
        int n = (paramInt3 - paramInt1 - m - k - i1) / 2 + k;
        if (this.c != -1 && view.getBaseline() != -1) {
          paramInt4 = this.c + i - view.getBaseline();
        } else {
          paramInt4 = i;
        } 
        view.layout(n, paramInt4, n + i1, paramInt4 + i2);
      } 
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i2 = getChildCount();
    int i1 = 0;
    int j = 0;
    int k = -1;
    int i = -1;
    int n = 0;
    for (byte b = 0; b < i2; b++) {
      View view = getChildAt(b);
      if (view.getVisibility() != 8) {
        measureChild(view, paramInt1, paramInt2);
        int i5 = view.getBaseline();
        int i3 = k;
        int i4 = i;
        if (i5 != -1) {
          i3 = Math.max(k, i5);
          i4 = Math.max(i, view.getMeasuredHeight() - i5);
        } 
        i1 = Math.max(i1, view.getMeasuredWidth());
        j = Math.max(j, view.getMeasuredHeight());
        n = View.combineMeasuredStates(n, view.getMeasuredState());
        i = i4;
        k = i3;
      } 
    } 
    int m = j;
    if (k != -1) {
      m = Math.max(j, k + Math.max(i, getPaddingBottom()));
      this.c = k;
    } 
    i = Math.max(m, getSuggestedMinimumHeight());
    j = Math.max(i1, getSuggestedMinimumWidth());
    setMeasuredDimension(View.resolveSizeAndState(j, paramInt1, n), View.resolveSizeAndState(i, paramInt2, n << 16));
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\internal\BaselineLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */