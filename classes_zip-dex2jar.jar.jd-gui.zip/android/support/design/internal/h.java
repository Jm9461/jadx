package android.support.design.internal;

import android.graphics.PorterDuff;
import android.support.v4.view.u;
import android.view.View;

public class h {
  public static PorterDuff.Mode a(int paramInt, PorterDuff.Mode paramMode) {
    if (paramInt != 3) {
      if (paramInt != 5) {
        if (paramInt != 9) {
          switch (paramInt) {
            default:
              return paramMode;
            case 16:
              return PorterDuff.Mode.ADD;
            case 15:
              return PorterDuff.Mode.SCREEN;
            case 14:
              break;
          } 
          return PorterDuff.Mode.MULTIPLY;
        } 
        return PorterDuff.Mode.SRC_ATOP;
      } 
      return PorterDuff.Mode.SRC_IN;
    } 
    return PorterDuff.Mode.SRC_OVER;
  }
  
  public static boolean a(View paramView) {
    int i = u.k(paramView);
    boolean bool = true;
    if (i != 1)
      bool = false; 
    return bool;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\internal\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */