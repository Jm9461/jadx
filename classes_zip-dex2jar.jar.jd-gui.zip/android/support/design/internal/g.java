package android.support.design.internal;

import a.b.c.b;
import a.b.c.k;
import android.content.Context;
import android.content.res.TypedArray;
import android.support.v7.widget.j1;
import android.util.AttributeSet;

public final class g {
  private static final int[] a = new int[] { b.colorPrimary };
  
  private static final int[] b = new int[] { b.colorSecondary };
  
  public static void a(Context paramContext) {
    a(paramContext, a, "Theme.AppCompat");
  }
  
  private static void a(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, k.ThemeEnforcement, paramInt1, paramInt2);
    boolean bool = typedArray.getBoolean(k.ThemeEnforcement_enforceMaterialTheme, false);
    typedArray.recycle();
    if (bool)
      b(paramContext); 
    a(paramContext);
  }
  
  private static void a(Context paramContext, AttributeSet paramAttributeSet, int[] paramArrayOfint1, int paramInt1, int paramInt2, int... paramVarArgs1) {
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, k.ThemeEnforcement, paramInt1, paramInt2);
    int i = k.ThemeEnforcement_enforceTextAppearance;
    boolean bool = false;
    if (!typedArray.getBoolean(i, false)) {
      typedArray.recycle();
      return;
    } 
    if (paramVarArgs1 == null || paramVarArgs1.length == 0) {
      if (typedArray.getResourceId(k.ThemeEnforcement_android_textAppearance, -1) != -1)
        bool = true; 
    } else {
      bool = b(paramContext, paramAttributeSet, paramArrayOfint1, paramInt1, paramInt2, paramVarArgs1);
    } 
    typedArray.recycle();
    if (bool)
      return; 
    throw new IllegalArgumentException("This component requires that you specify a valid TextAppearance attribute. Update your app theme to inherit from Theme.MaterialComponents (or a descendant).");
  }
  
  private static void a(Context paramContext, int[] paramArrayOfint, String paramString) {
    if (a(paramContext, paramArrayOfint))
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("The style on this component requires your app theme to be ");
    stringBuilder.append(paramString);
    stringBuilder.append(" (or a descendant).");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  private static boolean a(Context paramContext, int[] paramArrayOfint) {
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramArrayOfint);
    boolean bool = typedArray.hasValue(0);
    typedArray.recycle();
    return bool;
  }
  
  public static void b(Context paramContext) {
    a(paramContext, b, "Theme.MaterialComponents");
  }
  
  private static boolean b(Context paramContext, AttributeSet paramAttributeSet, int[] paramArrayOfint1, int paramInt1, int paramInt2, int... paramVarArgs1) {
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, paramArrayOfint1, paramInt1, paramInt2);
    paramInt2 = paramVarArgs1.length;
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
      if (typedArray.getResourceId(paramVarArgs1[paramInt1], -1) == -1) {
        typedArray.recycle();
        return false;
      } 
    } 
    typedArray.recycle();
    return true;
  }
  
  public static TypedArray c(Context paramContext, AttributeSet paramAttributeSet, int[] paramArrayOfint1, int paramInt1, int paramInt2, int... paramVarArgs1) {
    a(paramContext, paramAttributeSet, paramInt1, paramInt2);
    a(paramContext, paramAttributeSet, paramArrayOfint1, paramInt1, paramInt2, paramVarArgs1);
    return paramContext.obtainStyledAttributes(paramAttributeSet, paramArrayOfint1, paramInt1, paramInt2);
  }
  
  public static j1 d(Context paramContext, AttributeSet paramAttributeSet, int[] paramArrayOfint1, int paramInt1, int paramInt2, int... paramVarArgs1) {
    a(paramContext, paramAttributeSet, paramInt1, paramInt2);
    a(paramContext, paramAttributeSet, paramArrayOfint1, paramInt1, paramInt2, paramVarArgs1);
    return j1.a(paramContext, paramAttributeSet, paramArrayOfint1, paramInt1, paramInt2);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\internal\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */