package android.support.design.bottomappbar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.design.behavior.HideBottomViewOnScrollBehavior;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.view.u;
import android.support.v7.widget.ActionMenuView;
import android.support.v7.widget.Toolbar;
import android.util.AttributeSet;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public class BottomAppBar extends Toolbar implements CoordinatorLayout.b {
  private final int R;
  
  private final a.b.c.r.b S;
  
  private final a T;
  
  private Animator U;
  
  private Animator V;
  
  private Animator W;
  
  private int a0;
  
  private boolean b0;
  
  private boolean c0;
  
  AnimatorListenerAdapter d0;
  
  private float a(boolean paramBoolean) {
    FloatingActionButton floatingActionButton = m();
    if (floatingActionButton == null)
      return 0.0F; 
    Rect rect = new Rect();
    floatingActionButton.a(rect);
    float f2 = rect.height();
    float f1 = f2;
    if (f2 == 0.0F)
      f1 = floatingActionButton.getMeasuredHeight(); 
    float f4 = (floatingActionButton.getHeight() - rect.bottom);
    float f5 = (floatingActionButton.getHeight() - rect.height());
    float f3 = -getCradleVerticalOffset();
    float f6 = f1 / 2.0F;
    f1 = floatingActionButton.getPaddingBottom();
    f2 = -getMeasuredHeight();
    if (paramBoolean) {
      f1 = f3 + f6 + f4;
    } else {
      f1 = f5 - f1;
    } 
    return f2 + f1;
  }
  
  private int a(int paramInt) {
    int i = u.k((View)this);
    int j = 0;
    boolean bool = true;
    if (i == 1) {
      i = 1;
    } else {
      i = 0;
    } 
    if (paramInt == 1) {
      int k = getMeasuredWidth() / 2;
      j = this.R;
      paramInt = bool;
      if (i != 0)
        paramInt = -1; 
      paramInt = (k - j) * paramInt;
    } else {
      paramInt = j;
    } 
    return paramInt;
  }
  
  private void a(int paramInt, List<Animator> paramList) {
    if (!this.c0)
      return; 
    this.T.e();
    throw null;
  }
  
  private void a(int paramInt, boolean paramBoolean) {
    if (!u.y((View)this))
      return; 
    Animator animator = this.W;
    if (animator != null)
      animator.cancel(); 
    ArrayList<Animator> arrayList = new ArrayList();
    if (!o()) {
      paramInt = 0;
      paramBoolean = false;
    } 
    a(paramInt, paramBoolean, arrayList);
    AnimatorSet animatorSet = new AnimatorSet();
    animatorSet.playTogether(arrayList);
    this.W = (Animator)animatorSet;
    this.W.addListener((Animator.AnimatorListener)new b(this));
    this.W.start();
  }
  
  private void a(int paramInt, boolean paramBoolean, List<Animator> paramList) {
    AnimatorSet animatorSet;
    ActionMenuView actionMenuView = getActionMenuView();
    if (actionMenuView == null)
      return; 
    ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(actionMenuView, "alpha", new float[] { 1.0F });
    if ((this.c0 || (paramBoolean && o())) && (this.a0 == 1 || paramInt == 1)) {
      ObjectAnimator objectAnimator1 = ObjectAnimator.ofFloat(actionMenuView, "alpha", new float[] { 0.0F });
      objectAnimator1.addListener((Animator.AnimatorListener)new c(this, actionMenuView, paramInt, paramBoolean));
      animatorSet = new AnimatorSet();
      animatorSet.setDuration(150L);
      animatorSet.playSequentially(new Animator[] { (Animator)objectAnimator1, (Animator)objectAnimator });
      paramList.add(animatorSet);
      return;
    } 
    if (animatorSet.getAlpha() < 1.0F)
      paramList.add(objectAnimator); 
  }
  
  private void a(FloatingActionButton paramFloatingActionButton) {
    b(paramFloatingActionButton);
    paramFloatingActionButton.a((Animator.AnimatorListener)this.d0);
    paramFloatingActionButton.b((Animator.AnimatorListener)this.d0);
  }
  
  private void a(ActionMenuView paramActionMenuView, int paramInt, boolean paramBoolean) {
    float f;
    int i;
    int j = 0;
    if (u.k((View)this) == 1) {
      i = 1;
    } else {
      i = 0;
    } 
    byte b1 = 0;
    while (b1 < getChildCount()) {
      boolean bool;
      View view = getChildAt(b1);
      if (view.getLayoutParams() instanceof Toolbar.e && (((android.support.v7.app.a.a)view.getLayoutParams()).a & 0x800007) == 8388611) {
        bool = true;
      } else {
        bool = false;
      } 
      int k = j;
      if (bool) {
        if (i) {
          k = view.getLeft();
        } else {
          k = view.getRight();
        } 
        k = Math.max(j, k);
      } 
      b1++;
      j = k;
    } 
    if (i) {
      i = paramActionMenuView.getRight();
    } else {
      i = paramActionMenuView.getLeft();
    } 
    if (paramInt == 1 && paramBoolean) {
      f = (j - i);
    } else {
      f = 0.0F;
    } 
    paramActionMenuView.setTranslationX(f);
  }
  
  private void b(int paramInt) {
    if (this.a0 == paramInt || !u.y((View)this))
      return; 
    Animator animator = this.V;
    if (animator != null)
      animator.cancel(); 
    ArrayList<Animator> arrayList = new ArrayList();
    a(paramInt, arrayList);
    b(paramInt, arrayList);
    AnimatorSet animatorSet = new AnimatorSet();
    animatorSet.playTogether(arrayList);
    this.V = (Animator)animatorSet;
    this.V.addListener((Animator.AnimatorListener)new a(this));
    this.V.start();
  }
  
  private void b(int paramInt, List<Animator> paramList) {
    ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(m(), "translationX", new float[] { a(paramInt) });
    objectAnimator.setDuration(300L);
    paramList.add(objectAnimator);
  }
  
  private void b(FloatingActionButton paramFloatingActionButton) {
    paramFloatingActionButton.c((Animator.AnimatorListener)this.d0);
    paramFloatingActionButton.d((Animator.AnimatorListener)this.d0);
  }
  
  private ActionMenuView getActionMenuView() {
    for (byte b1 = 0; b1 < getChildCount(); b1++) {
      View view = getChildAt(b1);
      if (view instanceof ActionMenuView)
        return (ActionMenuView)view; 
    } 
    return null;
  }
  
  private float getFabTranslationX() {
    return a(this.a0);
  }
  
  private float getFabTranslationY() {
    return a(this.c0);
  }
  
  private void l() {
    Animator animator = this.U;
    if (animator != null)
      animator.cancel(); 
    animator = this.W;
    if (animator != null)
      animator.cancel(); 
    animator = this.V;
    if (animator != null)
      animator.cancel(); 
  }
  
  private FloatingActionButton m() {
    if (!(getParent() instanceof CoordinatorLayout))
      return null; 
    for (View view : ((CoordinatorLayout)getParent()).c((View)this)) {
      if (view instanceof FloatingActionButton)
        return (FloatingActionButton)view; 
    } 
    return null;
  }
  
  private boolean n() {
    Animator animator = this.U;
    if (animator == null || !animator.isRunning()) {
      animator = this.W;
      if (animator == null || !animator.isRunning()) {
        animator = this.V;
        return (animator != null && animator.isRunning());
      } 
    } 
    return true;
  }
  
  private boolean o() {
    boolean bool;
    FloatingActionButton floatingActionButton = m();
    if (floatingActionButton != null && floatingActionButton.b()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private void p() {
    this.T.d(getFabTranslationX());
    throw null;
  }
  
  public ColorStateList getBackgroundTint() {
    this.S.a();
    throw null;
  }
  
  public CoordinatorLayout.c<BottomAppBar> getBehavior() {
    return (CoordinatorLayout.c<BottomAppBar>)new Behavior();
  }
  
  public float getCradleVerticalOffset() {
    this.T.a();
    throw null;
  }
  
  public int getFabAlignmentMode() {
    return this.a0;
  }
  
  public float getFabCradleMargin() {
    this.T.b();
    throw null;
  }
  
  public float getFabCradleRoundedCornerRadius() {
    this.T.c();
    throw null;
  }
  
  public boolean getHideOnScroll() {
    return this.b0;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    l();
    p();
    throw null;
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof d)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    d d = (d)paramParcelable;
    super.onRestoreInstanceState(d.a());
    this.a0 = d.e;
    this.c0 = d.f;
  }
  
  protected Parcelable onSaveInstanceState() {
    d d = new d(super.onSaveInstanceState());
    d.e = this.a0;
    d.f = this.c0;
    return (Parcelable)d;
  }
  
  public void setBackgroundTint(ColorStateList paramColorStateList) {
    android.support.v4.graphics.drawable.a.a((Drawable)this.S, paramColorStateList);
  }
  
  public void setCradleVerticalOffset(float paramFloat) {
    if (paramFloat == getCradleVerticalOffset())
      return; 
    this.T.a(paramFloat);
    throw null;
  }
  
  public void setFabAlignmentMode(int paramInt) {
    b(paramInt);
    a(paramInt, this.c0);
    this.a0 = paramInt;
  }
  
  public void setFabCradleMargin(float paramFloat) {
    if (paramFloat == getFabCradleMargin())
      return; 
    this.T.b(paramFloat);
    throw null;
  }
  
  public void setFabCradleRoundedCornerRadius(float paramFloat) {
    if (paramFloat == getFabCradleRoundedCornerRadius())
      return; 
    this.T.c(paramFloat);
    throw null;
  }
  
  void setFabDiameter(int paramInt) {
    this.T.d();
    throw null;
  }
  
  public void setHideOnScroll(boolean paramBoolean) {
    this.b0 = paramBoolean;
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {}
  
  public void setTitle(CharSequence paramCharSequence) {}
  
  public static class Behavior extends HideBottomViewOnScrollBehavior<BottomAppBar> {
    private final Rect d = new Rect();
    
    public Behavior() {}
    
    public Behavior(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    private boolean a(FloatingActionButton param1FloatingActionButton, BottomAppBar param1BottomAppBar) {
      ((CoordinatorLayout.f)param1FloatingActionButton.getLayoutParams()).d = 17;
      BottomAppBar.a(param1BottomAppBar, param1FloatingActionButton);
      return true;
    }
    
    protected void a(BottomAppBar param1BottomAppBar) {
      super.a((View)param1BottomAppBar);
      FloatingActionButton floatingActionButton = BottomAppBar.a(param1BottomAppBar);
      if (floatingActionButton != null) {
        floatingActionButton.a(this.d);
        float f = (floatingActionButton.getMeasuredHeight() - this.d.height());
        floatingActionButton.clearAnimation();
        floatingActionButton.animate().translationY(-floatingActionButton.getPaddingBottom() + f).setInterpolator(a.b.c.l.a.c).setDuration(175L);
      } 
    }
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, BottomAppBar param1BottomAppBar, int param1Int) {
      FloatingActionButton floatingActionButton = BottomAppBar.a(param1BottomAppBar);
      if (floatingActionButton != null) {
        a(floatingActionButton, param1BottomAppBar);
        floatingActionButton.b(this.d);
        param1BottomAppBar.setFabDiameter(this.d.height());
      } 
      if (BottomAppBar.b(param1BottomAppBar)) {
        param1CoordinatorLayout.c((View)param1BottomAppBar, param1Int);
        return super.a(param1CoordinatorLayout, (View)param1BottomAppBar, param1Int);
      } 
      BottomAppBar.c(param1BottomAppBar);
      throw null;
    }
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, BottomAppBar param1BottomAppBar, View param1View1, View param1View2, int param1Int1, int param1Int2) {
      boolean bool;
      if (param1BottomAppBar.getHideOnScroll() && super.b(param1CoordinatorLayout, (View)param1BottomAppBar, param1View1, param1View2, param1Int1, param1Int2)) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    protected void b(BottomAppBar param1BottomAppBar) {
      super.b((View)param1BottomAppBar);
      FloatingActionButton floatingActionButton = BottomAppBar.a(param1BottomAppBar);
      if (floatingActionButton != null) {
        floatingActionButton.clearAnimation();
        floatingActionButton.animate().translationY(BottomAppBar.d(param1BottomAppBar)).setInterpolator(a.b.c.l.a.d).setDuration(225L);
      } 
    }
  }
  
  class a extends AnimatorListenerAdapter {
    final BottomAppBar a;
    
    a(BottomAppBar this$0) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      BottomAppBar.a(this.a, (Animator)null);
    }
  }
  
  class b extends AnimatorListenerAdapter {
    final BottomAppBar a;
    
    b(BottomAppBar this$0) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      BottomAppBar.b(this.a, (Animator)null);
    }
  }
  
  class c extends AnimatorListenerAdapter {
    public boolean a;
    
    final ActionMenuView b;
    
    final int c;
    
    final boolean d;
    
    final BottomAppBar e;
    
    c(BottomAppBar this$0, ActionMenuView param1ActionMenuView, int param1Int, boolean param1Boolean) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      this.a = true;
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      if (!this.a)
        BottomAppBar.a(this.e, this.b, this.c, this.d); 
    }
  }
  
  static class d extends android.support.v4.view.a {
    public static final Parcelable.Creator<d> CREATOR = (Parcelable.Creator<d>)new a();
    
    int e;
    
    boolean f;
    
    public d(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      boolean bool;
      this.e = param1Parcel.readInt();
      if (param1Parcel.readInt() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.f = bool;
    }
    
    public d(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.e);
      param1Parcel.writeInt(this.f);
    }
    
    static final class a implements Parcelable.ClassLoaderCreator<d> {
      public BottomAppBar.d createFromParcel(Parcel param2Parcel) {
        return new BottomAppBar.d(param2Parcel, null);
      }
      
      public BottomAppBar.d createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new BottomAppBar.d(param2Parcel, param2ClassLoader);
      }
      
      public BottomAppBar.d[] newArray(int param2Int) {
        return new BottomAppBar.d[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.ClassLoaderCreator<d> {
    public BottomAppBar.d createFromParcel(Parcel param1Parcel) {
      return new BottomAppBar.d(param1Parcel, null);
    }
    
    public BottomAppBar.d createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new BottomAppBar.d(param1Parcel, param1ClassLoader);
    }
    
    public BottomAppBar.d[] newArray(int param1Int) {
      return new BottomAppBar.d[param1Int];
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\bottomappbar\BottomAppBar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */