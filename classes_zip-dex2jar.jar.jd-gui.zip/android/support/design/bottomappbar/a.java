package android.support.design.bottomappbar;

import a.b.c.r.a;

public class a extends a {
  float a() {
    throw null;
  }
  
  void a(float paramFloat) {
    throw null;
  }
  
  float b() {
    throw null;
  }
  
  void b(float paramFloat) {
    throw null;
  }
  
  float c() {
    throw null;
  }
  
  void c(float paramFloat) {
    throw null;
  }
  
  float d() {
    throw null;
  }
  
  void d(float paramFloat) {
    throw null;
  }
  
  float e() {
    throw null;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\bottomappbar\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */