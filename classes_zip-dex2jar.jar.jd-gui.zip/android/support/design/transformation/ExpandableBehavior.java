package android.support.design.transformation;

import a.b.c.o.b;
import android.content.Context;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.view.u;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewTreeObserver;
import java.util.List;

public abstract class ExpandableBehavior extends CoordinatorLayout.c<View> {
  private int a = 0;
  
  public ExpandableBehavior() {}
  
  public ExpandableBehavior(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  private boolean a(boolean paramBoolean) {
    boolean bool2 = false;
    boolean bool1 = false;
    if (paramBoolean) {
      int i = this.a;
      if (i != 0) {
        paramBoolean = bool1;
        return (i == 2) ? true : paramBoolean;
      } 
    } else {
      paramBoolean = bool2;
      if (this.a == 1)
        paramBoolean = true; 
      return paramBoolean;
    } 
    return true;
  }
  
  public boolean a(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt) {
    if (!u.y(paramView)) {
      b b = e(paramCoordinatorLayout, paramView);
      if (b != null && a(b.a())) {
        if (b.a()) {
          paramInt = 1;
        } else {
          paramInt = 2;
        } 
        this.a = paramInt;
        paramInt = this.a;
        paramView.getViewTreeObserver().addOnPreDrawListener(new a(this, paramView, paramInt, b));
      } 
    } 
    return false;
  }
  
  protected abstract boolean a(View paramView1, View paramView2, boolean paramBoolean1, boolean paramBoolean2);
  
  public boolean b(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2) {
    b b = (b)paramView2;
    if (a(b.a())) {
      byte b1;
      if (b.a()) {
        b1 = 1;
      } else {
        b1 = 2;
      } 
      this.a = b1;
      return a((View)b, paramView1, b.a(), true);
    } 
    return false;
  }
  
  protected b e(CoordinatorLayout paramCoordinatorLayout, View paramView) {
    List<View> list = paramCoordinatorLayout.b(paramView);
    byte b = 0;
    int i = list.size();
    while (b < i) {
      View view = list.get(b);
      if (a(paramCoordinatorLayout, paramView, view))
        return (b)view; 
      b++;
    } 
    return null;
  }
  
  class a implements ViewTreeObserver.OnPreDrawListener {
    final View c;
    
    final int d;
    
    final b e;
    
    final ExpandableBehavior f;
    
    a(ExpandableBehavior this$0, View param1View, int param1Int, b param1b) {}
    
    public boolean onPreDraw() {
      this.c.getViewTreeObserver().removeOnPreDrawListener(this);
      if (ExpandableBehavior.a(this.f) == this.d) {
        ExpandableBehavior expandableBehavior = this.f;
        b b1 = this.e;
        expandableBehavior.a((View)b1, this.c, b1.a(), false);
      } 
      return false;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\transformation\ExpandableBehavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */