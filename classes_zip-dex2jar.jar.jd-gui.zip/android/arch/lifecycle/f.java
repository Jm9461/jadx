package android.arch.lifecycle;

import android.util.Log;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

public class f extends c {
  private a.a.a.b.a<d, b> a = new a.a.a.b.a();
  
  private c.b b;
  
  private final WeakReference<e> c;
  
  private int d = 0;
  
  private boolean e = false;
  
  private boolean f = false;
  
  private ArrayList<c.b> g = new ArrayList<c.b>();
  
  public f(e parame) {
    this.c = new WeakReference<e>(parame);
    this.b = c.b.d;
  }
  
  static c.b a(c.b paramb1, c.b paramb2) {
    if (paramb2 != null && paramb2.compareTo(paramb1) < 0)
      paramb1 = paramb2; 
    return paramb1;
  }
  
  private void a(e parame) {
    Iterator<Map.Entry> iterator = this.a.a();
    while (iterator.hasNext() && !this.f) {
      Map.Entry entry = iterator.next();
      b b1 = (b)entry.getValue();
      while (b1.a.compareTo(this.b) > 0 && !this.f && this.a.contains(entry.getKey())) {
        c.a a1 = b(b1.a);
        d(b(a1));
        b1.a(parame, a1);
        c();
      } 
    } 
  }
  
  private static c.a b(c.b paramb) {
    int i = a.b[paramb.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i != 4) {
            if (i != 5) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Unexpected state value ");
              stringBuilder.append(paramb);
              throw new IllegalArgumentException(stringBuilder.toString());
            } 
            throw new IllegalArgumentException();
          } 
          return c.a.ON_PAUSE;
        } 
        return c.a.ON_STOP;
      } 
      return c.a.ON_DESTROY;
    } 
    throw new IllegalArgumentException();
  }
  
  static c.b b(c.a parama) {
    StringBuilder stringBuilder;
    switch (a.a[parama.ordinal()]) {
      default:
        stringBuilder = new StringBuilder();
        stringBuilder.append("Unexpected event value ");
        stringBuilder.append(parama);
        throw new IllegalArgumentException(stringBuilder.toString());
      case 6:
        return c.b.c;
      case 5:
        return c.b.g;
      case 3:
      case 4:
        return c.b.f;
      case 1:
      case 2:
        break;
    } 
    return c.b.e;
  }
  
  private void b(e parame) {
    a.a.a.b.b.e<Map.Entry> e1 = this.a.c();
    while (e1.hasNext() && !this.f) {
      Map.Entry entry = e1.next();
      b b1 = (b)entry.getValue();
      while (b1.a.compareTo(this.b) < 0 && !this.f && this.a.contains(entry.getKey())) {
        d(b1.a);
        b1.a(parame, e(b1.a));
        c();
      } 
    } 
  }
  
  private boolean b() {
    int i = this.a.size();
    boolean bool = true;
    if (i == 0)
      return true; 
    c.b b2 = ((b)this.a.b().getValue()).a;
    c.b b1 = ((b)this.a.d().getValue()).a;
    if (b2 != b1 || this.b != b1)
      bool = false; 
    return bool;
  }
  
  private c.b c(d paramd) {
    c.b b1;
    Map.Entry entry = this.a.b(paramd);
    ArrayList<c.b> arrayList = null;
    if (entry != null) {
      c.b b2 = ((b)entry.getValue()).a;
    } else {
      entry = null;
    } 
    if (!this.g.isEmpty()) {
      arrayList = this.g;
      b1 = arrayList.get(arrayList.size() - 1);
    } 
    return a(a(this.b, (c.b)entry), b1);
  }
  
  private void c() {
    ArrayList<c.b> arrayList = this.g;
    arrayList.remove(arrayList.size() - 1);
  }
  
  private void c(c.b paramb) {
    if (this.b == paramb)
      return; 
    this.b = paramb;
    if (this.e || this.d != 0) {
      this.f = true;
      return;
    } 
    this.e = true;
    d();
    this.e = false;
  }
  
  private void d() {
    e e = this.c.get();
    if (e == null) {
      Log.w("LifecycleRegistry", "LifecycleOwner is garbage collected, you shouldn't try dispatch new events from it.");
      return;
    } 
    while (!b()) {
      this.f = false;
      if (this.b.compareTo(((b)this.a.b().getValue()).a) < 0)
        a(e); 
      Map.Entry entry = this.a.d();
      if (!this.f && entry != null && this.b.compareTo(((b)entry.getValue()).a) > 0)
        b(e); 
    } 
    this.f = false;
  }
  
  private void d(c.b paramb) {
    this.g.add(paramb);
  }
  
  private static c.a e(c.b paramb) {
    int i = a.b[paramb.ordinal()];
    if (i != 1)
      if (i != 2) {
        if (i != 3) {
          if (i != 4) {
            if (i != 5) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Unexpected state value ");
              stringBuilder.append(paramb);
              throw new IllegalArgumentException(stringBuilder.toString());
            } 
          } else {
            throw new IllegalArgumentException();
          } 
        } else {
          return c.a.ON_RESUME;
        } 
      } else {
        return c.a.ON_START;
      }  
    return c.a.ON_CREATE;
  }
  
  public c.b a() {
    return this.b;
  }
  
  public void a(c.a parama) {
    c(b(parama));
  }
  
  public void a(c.b paramb) {
    c(paramb);
  }
  
  public void a(d paramd) {
    boolean bool;
    c.b b2 = this.b;
    c.b b1 = c.b.c;
    if (b2 != b1)
      b1 = c.b.d; 
    b b3 = new b(paramd, b1);
    if ((b)this.a.b(paramd, b3) != null)
      return; 
    e e = this.c.get();
    if (e == null)
      return; 
    if (this.d != 0 || this.e) {
      bool = true;
    } else {
      bool = false;
    } 
    b1 = c(paramd);
    this.d++;
    while (b3.a.compareTo(b1) < 0 && this.a.contains(paramd)) {
      d(b3.a);
      b3.a(e, e(b3.a));
      c();
      b1 = c(paramd);
    } 
    if (!bool)
      d(); 
    this.d--;
  }
  
  public void b(d paramd) {
    this.a.remove(paramd);
  }
  
  static class b {
    c.b a;
    
    GenericLifecycleObserver b;
    
    b(d param1d, c.b param1b) {
      this.b = h.a(param1d);
      this.a = param1b;
    }
    
    void a(e param1e, c.a param1a) {
      c.b b1 = f.b(param1a);
      this.a = f.a(this.a, b1);
      this.b.a(param1e, param1a);
      this.a = b1;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\arch\lifecycle\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */