package android.arch.lifecycle;

public abstract class c {
  public abstract b a();
  
  public abstract void a(d paramd);
  
  public abstract void b(d paramd);
  
  public enum a {
    ON_ANY, ON_CREATE, ON_DESTROY, ON_PAUSE, ON_RESUME, ON_START, ON_STOP;
    
    private static final a[] $VALUES;
    
    static {
      ON_PAUSE = new a("ON_PAUSE", 3);
      ON_STOP = new a("ON_STOP", 4);
      ON_DESTROY = new a("ON_DESTROY", 5);
      ON_ANY = new a("ON_ANY", 6);
      $VALUES = new a[] { ON_CREATE, ON_START, ON_RESUME, ON_PAUSE, ON_STOP, ON_DESTROY, ON_ANY };
    }
  }
  
  public enum b {
    c, d, e, f, g;
    
    private static final b[] h = new b[] { c, d, e, f, g };
    
    public boolean a(b param1b) {
      boolean bool;
      if (compareTo((E)param1b) >= 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\arch\lifecycle\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */