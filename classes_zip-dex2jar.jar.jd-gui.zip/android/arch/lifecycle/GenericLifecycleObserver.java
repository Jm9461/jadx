package android.arch.lifecycle;

public interface GenericLifecycleObserver extends d {
  void a(e parame, c.a parama);
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\arch\lifecycle\GenericLifecycleObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */