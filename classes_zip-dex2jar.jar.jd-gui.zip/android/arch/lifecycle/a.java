package android.arch.lifecycle;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class a {
  static a c = new a();
  
  private final Map<Class, a> a = (Map)new HashMap<Class<?>, a>();
  
  private final Map<Class, Boolean> b = (Map)new HashMap<Class<?>, Boolean>();
  
  private a a(Class paramClass, Method[] paramArrayOfMethod) {
    Class clazz = paramClass.getSuperclass();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (clazz != null) {
      a a2 = a(clazz);
      if (a2 != null)
        hashMap.putAll(a2.b); 
    } 
    Class[] arrayOfClass = paramClass.getInterfaces();
    int i = arrayOfClass.length;
    byte b;
    for (b = 0; b < i; b++) {
      for (Map.Entry<b, c.a> entry : (a(arrayOfClass[b])).b.entrySet())
        a((Map)hashMap, (b)entry.getKey(), (c.a)entry.getValue(), paramClass); 
    } 
    if (paramArrayOfMethod == null)
      paramArrayOfMethod = c(paramClass); 
    int j = paramArrayOfMethod.length;
    boolean bool = false;
    for (i = 0; i < j; i++) {
      Method method = paramArrayOfMethod[i];
      l l = method.<l>getAnnotation(l.class);
      if (l != null) {
        bool = true;
        Class[] arrayOfClass1 = method.getParameterTypes();
        b = 0;
        if (arrayOfClass1.length > 0) {
          b = 1;
          if (!arrayOfClass1[0].isAssignableFrom(e.class))
            throw new IllegalArgumentException("invalid parameter type. Must be one and instanceof LifecycleOwner"); 
        } 
        c.a a2 = l.value();
        if (arrayOfClass1.length > 1) {
          b = 2;
          if (arrayOfClass1[1].isAssignableFrom(c.a.class)) {
            if (a2 != c.a.ON_ANY)
              throw new IllegalArgumentException("Second arg is supported only for ON_ANY value"); 
          } else {
            throw new IllegalArgumentException("invalid parameter type. second arg must be an event");
          } 
        } 
        if (arrayOfClass1.length <= 2) {
          a((Map)hashMap, new b(b, method), a2, paramClass);
        } else {
          throw new IllegalArgumentException("cannot have more than 2 params");
        } 
      } 
    } 
    a a1 = new a((Map)hashMap);
    this.a.put(paramClass, a1);
    this.b.put(paramClass, Boolean.valueOf(bool));
    return a1;
  }
  
  private void a(Map<b, c.a> paramMap, b paramb, c.a parama, Class paramClass) {
    c.a a1 = paramMap.get(paramb);
    if (a1 == null || parama == a1) {
      if (a1 == null)
        paramMap.put(paramb, parama); 
      return;
    } 
    Method method = paramb.b;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Method ");
    stringBuilder.append(method.getName());
    stringBuilder.append(" in ");
    stringBuilder.append(paramClass.getName());
    stringBuilder.append(" already declared with different @OnLifecycleEvent value: previous value ");
    stringBuilder.append(a1);
    stringBuilder.append(", new value ");
    stringBuilder.append(parama);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  private Method[] c(Class paramClass) {
    try {
      return paramClass.getDeclaredMethods();
    } catch (NoClassDefFoundError noClassDefFoundError) {
      throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", noClassDefFoundError);
    } 
  }
  
  a a(Class paramClass) {
    a a1 = this.a.get(paramClass);
    return (a1 != null) ? a1 : a(paramClass, null);
  }
  
  boolean b(Class paramClass) {
    if (this.b.containsKey(paramClass))
      return ((Boolean)this.b.get(paramClass)).booleanValue(); 
    Method[] arrayOfMethod = c(paramClass);
    int i = arrayOfMethod.length;
    for (byte b = 0; b < i; b++) {
      if ((l)arrayOfMethod[b].<l>getAnnotation(l.class) != null) {
        a(paramClass, arrayOfMethod);
        return true;
      } 
    } 
    this.b.put(paramClass, Boolean.valueOf(false));
    return false;
  }
  
  static class a {
    final Map<c.a, List<a.b>> a;
    
    final Map<a.b, c.a> b;
    
    a(Map<a.b, c.a> param1Map) {
      this.b = param1Map;
      this.a = new HashMap<c.a, List<a.b>>();
      for (Map.Entry<a.b, c.a> entry : param1Map.entrySet()) {
        c.a a1 = (c.a)entry.getValue();
        List<a.b> list2 = this.a.get(a1);
        List<a.b> list1 = list2;
        if (list2 == null) {
          list1 = new ArrayList();
          this.a.put(a1, list1);
        } 
        list1.add((a.b)entry.getKey());
      } 
    }
    
    private static void a(List<a.b> param1List, e param1e, c.a param1a, Object param1Object) {
      if (param1List != null)
        for (int i = param1List.size() - 1; i >= 0; i--)
          ((a.b)param1List.get(i)).a(param1e, param1a, param1Object);  
    }
    
    void a(e param1e, c.a param1a, Object param1Object) {
      a(this.a.get(param1a), param1e, param1a, param1Object);
      a(this.a.get(c.a.ON_ANY), param1e, param1a, param1Object);
    }
  }
  
  static class b {
    final int a;
    
    final Method b;
    
    b(int param1Int, Method param1Method) {
      this.a = param1Int;
      this.b = param1Method;
      this.b.setAccessible(true);
    }
    
    void a(e param1e, c.a param1a, Object param1Object) {
      try {
        int i = this.a;
        if (i != 0) {
          if (i != 1) {
            if (i == 2)
              this.b.invoke(param1Object, new Object[] { param1e, param1a }); 
          } else {
            this.b.invoke(param1Object, new Object[] { param1e });
          } 
        } else {
          this.b.invoke(param1Object, new Object[0]);
        } 
        return;
      } catch (InvocationTargetException invocationTargetException) {
        throw new RuntimeException("Failed to call observer method", invocationTargetException.getCause());
      } catch (IllegalAccessException illegalAccessException) {
        throw new RuntimeException(illegalAccessException);
      } 
    }
    
    public boolean equals(Object param1Object) {
      boolean bool = true;
      if (this == param1Object)
        return true; 
      if (param1Object == null || getClass() != param1Object.getClass())
        return false; 
      param1Object = param1Object;
      if (this.a != ((b)param1Object).a || !this.b.getName().equals(((b)param1Object).b.getName()))
        bool = false; 
      return bool;
    }
    
    public int hashCode() {
      return this.a * 31 + this.b.getName().hashCode();
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\arch\lifecycle\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */