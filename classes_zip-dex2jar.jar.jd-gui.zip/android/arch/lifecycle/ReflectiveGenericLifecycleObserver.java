package android.arch.lifecycle;

class ReflectiveGenericLifecycleObserver implements GenericLifecycleObserver {
  private final Object a;
  
  private final a.a b;
  
  ReflectiveGenericLifecycleObserver(Object paramObject) {
    this.a = paramObject;
    this.b = a.c.a(this.a.getClass());
  }
  
  public void a(e parame, c.a parama) {
    this.b.a(parame, parama, this.a);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\arch\lifecycle\ReflectiveGenericLifecycleObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */