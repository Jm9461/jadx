package android.databinding;

import android.annotation.TargetApi;
import android.arch.lifecycle.l;
import android.os.Build;
import android.os.Handler;
import android.view.Choreographer;
import android.view.View;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;

public abstract class ViewDataBinding extends a {
  static {
    "binding_".length();
    if (k >= 16) {
      bool = true;
    } else {
      bool = false;
    } 
    l = bool;
    new a();
    new b();
    new c();
    new d();
    new e();
    new ReferenceQueue();
    if (Build.VERSION.SDK_INT >= 19)
      new f(); 
  }
  
  static ViewDataBinding a(View paramView) {
    return (paramView != null) ? (ViewDataBinding)paramView.getTag(b.b.a.a.a.dataBinding) : null;
  }
  
  private void e() {
    if (this.e) {
      d();
      return;
    } 
    if (!c())
      return; 
    this.e = true;
    this.c = false;
    b<Object, ViewDataBinding, Void> b1 = this.d;
    if (b1 == null) {
      if (!this.c) {
        a();
        b1 = this.d;
        if (b1 != null) {
          b1.a(this, 3, null);
          throw null;
        } 
      } 
      this.e = false;
      return;
    } 
    b1.a(this, 1, null);
    throw null;
  }
  
  protected abstract void a();
  
  public void b() {
    ViewDataBinding viewDataBinding = this.i;
    if (viewDataBinding == null) {
      e();
    } else {
      viewDataBinding.b();
    } 
  }
  
  public abstract boolean c();
  
  protected void d() {
    // Byte code:
    //   0: aload_0
    //   1: getfield i : Landroid/databinding/ViewDataBinding;
    //   4: astore_1
    //   5: aload_1
    //   6: ifnull -> 16
    //   9: aload_1
    //   10: invokevirtual d : ()V
    //   13: goto -> 95
    //   16: aload_0
    //   17: getfield j : Landroid/arch/lifecycle/e;
    //   20: astore_1
    //   21: aload_1
    //   22: ifnull -> 44
    //   25: aload_1
    //   26: invokeinterface a : ()Landroid/arch/lifecycle/c;
    //   31: invokevirtual a : ()Landroid/arch/lifecycle/c$b;
    //   34: getstatic android/arch/lifecycle/c$b.f : Landroid/arch/lifecycle/c$b;
    //   37: invokevirtual a : (Landroid/arch/lifecycle/c$b;)Z
    //   40: ifne -> 44
    //   43: return
    //   44: aload_0
    //   45: monitorenter
    //   46: aload_0
    //   47: getfield b : Z
    //   50: ifeq -> 56
    //   53: aload_0
    //   54: monitorexit
    //   55: return
    //   56: aload_0
    //   57: iconst_1
    //   58: putfield b : Z
    //   61: aload_0
    //   62: monitorexit
    //   63: getstatic android/databinding/ViewDataBinding.l : Z
    //   66: ifeq -> 83
    //   69: aload_0
    //   70: getfield f : Landroid/view/Choreographer;
    //   73: aload_0
    //   74: getfield g : Landroid/view/Choreographer$FrameCallback;
    //   77: invokevirtual postFrameCallback : (Landroid/view/Choreographer$FrameCallback;)V
    //   80: goto -> 95
    //   83: aload_0
    //   84: getfield h : Landroid/os/Handler;
    //   87: aload_0
    //   88: getfield a : Ljava/lang/Runnable;
    //   91: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   94: pop
    //   95: return
    //   96: astore_1
    //   97: aload_0
    //   98: monitorexit
    //   99: aload_1
    //   100: athrow
    // Exception table:
    //   from	to	target	type
    //   46	55	96	finally
    //   56	63	96	finally
    //   97	99	96	finally
  }
  
  static {
    boolean bool;
  }
  
  static int k = Build.VERSION.SDK_INT;
  
  private static final boolean l;
  
  private final Runnable a;
  
  private boolean b;
  
  private boolean c;
  
  private b<Object, ViewDataBinding, Void> d;
  
  private boolean e;
  
  private Choreographer f;
  
  private final Choreographer.FrameCallback g;
  
  private Handler h;
  
  private ViewDataBinding i;
  
  private android.arch.lifecycle.e j;
  
  static class OnStartListener implements android.arch.lifecycle.d {
    final WeakReference<ViewDataBinding> a;
    
    @l(android.arch.lifecycle.c.a.ON_START)
    public void onStart() {
      ViewDataBinding viewDataBinding = this.a.get();
      if (viewDataBinding != null)
        viewDataBinding.b(); 
    }
  }
  
  static final class a implements g {}
  
  static final class b implements g {}
  
  static final class c implements g {}
  
  static final class d implements g {}
  
  static final class e extends b.a<Object, ViewDataBinding, Void> {}
  
  static final class f implements View.OnAttachStateChangeListener {
    @TargetApi(19)
    public void onViewAttachedToWindow(View param1View) {
      ViewDataBinding.a(ViewDataBinding.a(param1View)).run();
      param1View.removeOnAttachStateChangeListener(this);
    }
    
    public void onViewDetachedFromWindow(View param1View) {}
  }
  
  private static interface g {}
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\databinding\ViewDataBinding.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */