package a.a.a.a;

public abstract class c {
  public abstract void a(Runnable paramRunnable);
  
  public abstract boolean a();
  
  public abstract void b(Runnable paramRunnable);
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\a\a\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */