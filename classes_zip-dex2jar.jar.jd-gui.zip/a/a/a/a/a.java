package a.a.a.a;

import java.util.concurrent.Executor;

public class a extends c {
  private static volatile a c;
  
  private c a = this.b;
  
  private c b = new b();
  
  static {
    new a();
    new b();
  }
  
  public static a b() {
    // Byte code:
    //   0: getstatic a/a/a/a/a.c : La/a/a/a/a;
    //   3: ifnull -> 10
    //   6: getstatic a/a/a/a/a.c : La/a/a/a/a;
    //   9: areturn
    //   10: ldc a/a/a/a/a
    //   12: monitorenter
    //   13: getstatic a/a/a/a/a.c : La/a/a/a/a;
    //   16: ifnonnull -> 31
    //   19: new a/a/a/a/a
    //   22: astore_0
    //   23: aload_0
    //   24: invokespecial <init> : ()V
    //   27: aload_0
    //   28: putstatic a/a/a/a/a.c : La/a/a/a/a;
    //   31: ldc a/a/a/a/a
    //   33: monitorexit
    //   34: getstatic a/a/a/a/a.c : La/a/a/a/a;
    //   37: areturn
    //   38: astore_0
    //   39: ldc a/a/a/a/a
    //   41: monitorexit
    //   42: aload_0
    //   43: athrow
    // Exception table:
    //   from	to	target	type
    //   13	31	38	finally
    //   31	34	38	finally
    //   39	42	38	finally
  }
  
  public void a(Runnable paramRunnable) {
    this.a.a(paramRunnable);
  }
  
  public boolean a() {
    return this.a.a();
  }
  
  public void b(Runnable paramRunnable) {
    this.a.b(paramRunnable);
  }
  
  static final class a implements Executor {
    public void execute(Runnable param1Runnable) {
      a.b().b(param1Runnable);
    }
  }
  
  static final class b implements Executor {
    public void execute(Runnable param1Runnable) {
      a.b().a(param1Runnable);
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\a\a\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */