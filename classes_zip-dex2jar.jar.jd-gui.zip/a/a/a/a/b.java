package a.a.a.a;

import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class b extends c {
  private final Object a = new Object();
  
  private ExecutorService b = Executors.newFixedThreadPool(2);
  
  private volatile Handler c;
  
  public void a(Runnable paramRunnable) {
    this.b.execute(paramRunnable);
  }
  
  public boolean a() {
    boolean bool;
    if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void b(Runnable paramRunnable) {
    if (this.c == null)
      synchronized (this.a) {
        if (this.c == null) {
          Handler handler = new Handler();
          this(Looper.getMainLooper());
          this.c = handler;
        } 
      }  
    this.c.post(paramRunnable);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\a\a\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */