package a.a.a.b;

import java.util.HashMap;
import java.util.Map;

public class a<K, V> extends b<K, V> {
  private HashMap<K, b.d<K, V>> g = new HashMap<K, b.d<K, V>>();
  
  protected b.d<K, V> a(K paramK) {
    return this.g.get(paramK);
  }
  
  public V b(K paramK, V paramV) {
    b.d<K, V> d = a(paramK);
    if (d != null)
      return d.d; 
    this.g.put(paramK, a(paramK, paramV));
    return null;
  }
  
  public Map.Entry<K, V> b(K paramK) {
    return contains(paramK) ? ((b.d)this.g.get(paramK)).f : null;
  }
  
  public boolean contains(K paramK) {
    return this.g.containsKey(paramK);
  }
  
  public V remove(K paramK) {
    V v = super.remove(paramK);
    this.g.remove(paramK);
    return v;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\a\a\b\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */