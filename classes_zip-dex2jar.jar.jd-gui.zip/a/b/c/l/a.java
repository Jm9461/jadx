package a.b.c.l;

import android.animation.TimeInterpolator;
import android.support.v4.view.e0.b;
import android.support.v4.view.e0.c;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;

public class a {
  public static final TimeInterpolator a = (TimeInterpolator)new LinearInterpolator();
  
  public static final TimeInterpolator b = (TimeInterpolator)new b();
  
  public static final TimeInterpolator c = (TimeInterpolator)new android.support.v4.view.e0.a();
  
  public static final TimeInterpolator d = (TimeInterpolator)new c();
  
  public static final TimeInterpolator e = (TimeInterpolator)new DecelerateInterpolator();
  
  public static float a(float paramFloat1, float paramFloat2, float paramFloat3) {
    return (paramFloat2 - paramFloat1) * paramFloat3 + paramFloat1;
  }
  
  public static int a(int paramInt1, int paramInt2, float paramFloat) {
    return Math.round((paramInt2 - paramInt1) * paramFloat) + paramInt1;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\c\l\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */