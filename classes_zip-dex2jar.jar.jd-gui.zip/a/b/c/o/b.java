package a.b.c.o;

public interface b {
  boolean a();
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\c\o\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */