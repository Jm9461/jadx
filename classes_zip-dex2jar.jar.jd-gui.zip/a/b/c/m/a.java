package a.b.c.m;

import a.b.c.b;
import a.b.c.j;
import a.b.c.k;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.design.internal.g;
import android.support.design.internal.h;
import android.support.v4.view.u;
import android.support.v4.widget.p;
import android.support.v7.widget.g;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class a extends g {
  private final c e;
  
  private int f;
  
  private PorterDuff.Mode g;
  
  private ColorStateList h;
  
  private Drawable i;
  
  private int j;
  
  private int k;
  
  private int l;
  
  public a(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, b.materialButtonStyle);
  }
  
  public a(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TypedArray typedArray = g.c(paramContext, paramAttributeSet, k.MaterialButton, paramInt, j.Widget_MaterialComponents_Button, new int[0]);
    this.f = typedArray.getDimensionPixelSize(k.MaterialButton_iconPadding, 0);
    this.g = h.a(typedArray.getInt(k.MaterialButton_iconTintMode, -1), PorterDuff.Mode.SRC_IN);
    this.h = a.b.c.p.a.a(getContext(), typedArray, k.MaterialButton_iconTint);
    this.i = a.b.c.p.a.b(getContext(), typedArray, k.MaterialButton_icon);
    this.l = typedArray.getInteger(k.MaterialButton_iconGravity, 1);
    this.j = typedArray.getDimensionPixelSize(k.MaterialButton_iconSize, 0);
    this.e = new c(this);
    this.e.a(typedArray);
    typedArray.recycle();
    setCompoundDrawablePadding(this.f);
    c();
  }
  
  private boolean a() {
    int i = u.k((View)this);
    boolean bool = true;
    if (i != 1)
      bool = false; 
    return bool;
  }
  
  private boolean b() {
    boolean bool;
    c c1 = this.e;
    if (c1 != null && !c1.g()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private void c() {
    Drawable drawable = this.i;
    if (drawable != null) {
      this.i = drawable.mutate();
      android.support.v4.graphics.drawable.a.a(this.i, this.h);
      PorterDuff.Mode mode = this.g;
      if (mode != null)
        android.support.v4.graphics.drawable.a.a(this.i, mode); 
      int i = this.j;
      if (i == 0)
        i = this.i.getIntrinsicWidth(); 
      int j = this.j;
      if (j == 0)
        j = this.i.getIntrinsicHeight(); 
      Drawable drawable1 = this.i;
      int k = this.k;
      drawable1.setBounds(k, 0, k + i, j);
    } 
    p.a((TextView)this, this.i, null, null, null);
  }
  
  public ColorStateList getBackgroundTintList() {
    return getSupportBackgroundTintList();
  }
  
  public PorterDuff.Mode getBackgroundTintMode() {
    return getSupportBackgroundTintMode();
  }
  
  public int getCornerRadius() {
    boolean bool;
    if (b()) {
      bool = this.e.a();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public Drawable getIcon() {
    return this.i;
  }
  
  public int getIconGravity() {
    return this.l;
  }
  
  public int getIconPadding() {
    return this.f;
  }
  
  public int getIconSize() {
    return this.j;
  }
  
  public ColorStateList getIconTint() {
    return this.h;
  }
  
  public PorterDuff.Mode getIconTintMode() {
    return this.g;
  }
  
  public ColorStateList getRippleColor() {
    ColorStateList colorStateList;
    if (b()) {
      colorStateList = this.e.b();
    } else {
      colorStateList = null;
    } 
    return colorStateList;
  }
  
  public ColorStateList getStrokeColor() {
    ColorStateList colorStateList;
    if (b()) {
      colorStateList = this.e.c();
    } else {
      colorStateList = null;
    } 
    return colorStateList;
  }
  
  public int getStrokeWidth() {
    boolean bool;
    if (b()) {
      bool = this.e.d();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    return b() ? this.e.e() : super.getSupportBackgroundTintList();
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    return b() ? this.e.f() : super.getSupportBackgroundTintMode();
  }
  
  protected void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (Build.VERSION.SDK_INT < 21 && b())
      this.e.a(paramCanvas); 
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    if (Build.VERSION.SDK_INT == 21) {
      c c1 = this.e;
      if (c1 != null)
        c1.a(paramInt4 - paramInt2, paramInt3 - paramInt1); 
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (this.i == null || this.l != 2)
      return; 
    int i = (int)getPaint().measureText(getText().toString());
    paramInt2 = this.j;
    paramInt1 = paramInt2;
    if (paramInt2 == 0)
      paramInt1 = this.i.getIntrinsicWidth(); 
    paramInt2 = (getMeasuredWidth() - i - u.n((View)this) - paramInt1 - this.f - u.o((View)this)) / 2;
    paramInt1 = paramInt2;
    if (a())
      paramInt1 = -paramInt2; 
    if (this.k != paramInt1) {
      this.k = paramInt1;
      c();
    } 
  }
  
  public void setBackground(Drawable paramDrawable) {
    setBackgroundDrawable(paramDrawable);
  }
  
  public void setBackgroundColor(int paramInt) {
    if (b()) {
      this.e.a(paramInt);
    } else {
      super.setBackgroundColor(paramInt);
    } 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    if (b()) {
      if (paramDrawable != getBackground()) {
        Log.i("MaterialButton", "Setting a custom background is not supported.");
        this.e.h();
        super.setBackgroundDrawable(paramDrawable);
      } else {
        getBackground().setState(paramDrawable.getState());
      } 
    } else {
      super.setBackgroundDrawable(paramDrawable);
    } 
  }
  
  public void setBackgroundResource(int paramInt) {
    Drawable drawable = null;
    if (paramInt != 0)
      drawable = a.b.h.c.a.a.c(getContext(), paramInt); 
    setBackgroundDrawable(drawable);
  }
  
  public void setBackgroundTintList(ColorStateList paramColorStateList) {
    setSupportBackgroundTintList(paramColorStateList);
  }
  
  public void setBackgroundTintMode(PorterDuff.Mode paramMode) {
    setSupportBackgroundTintMode(paramMode);
  }
  
  public void setCornerRadius(int paramInt) {
    if (b())
      this.e.b(paramInt); 
  }
  
  public void setCornerRadiusResource(int paramInt) {
    if (b())
      setCornerRadius(getResources().getDimensionPixelSize(paramInt)); 
  }
  
  public void setIcon(Drawable paramDrawable) {
    if (this.i != paramDrawable) {
      this.i = paramDrawable;
      c();
    } 
  }
  
  public void setIconGravity(int paramInt) {
    this.l = paramInt;
  }
  
  public void setIconPadding(int paramInt) {
    if (this.f != paramInt) {
      this.f = paramInt;
      setCompoundDrawablePadding(paramInt);
    } 
  }
  
  public void setIconResource(int paramInt) {
    Drawable drawable = null;
    if (paramInt != 0)
      drawable = a.b.h.c.a.a.c(getContext(), paramInt); 
    setIcon(drawable);
  }
  
  public void setIconSize(int paramInt) {
    if (paramInt >= 0) {
      if (this.j != paramInt) {
        this.j = paramInt;
        c();
      } 
      return;
    } 
    throw new IllegalArgumentException("iconSize cannot be less than 0");
  }
  
  public void setIconTint(ColorStateList paramColorStateList) {
    if (this.h != paramColorStateList) {
      this.h = paramColorStateList;
      c();
    } 
  }
  
  public void setIconTintMode(PorterDuff.Mode paramMode) {
    if (this.g != paramMode) {
      this.g = paramMode;
      c();
    } 
  }
  
  public void setIconTintResource(int paramInt) {
    setIconTint(a.b.h.c.a.a.b(getContext(), paramInt));
  }
  
  void setInternalBackground(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
  }
  
  public void setRippleColor(ColorStateList paramColorStateList) {
    if (b())
      this.e.a(paramColorStateList); 
  }
  
  public void setRippleColorResource(int paramInt) {
    if (b())
      setRippleColor(a.b.h.c.a.a.b(getContext(), paramInt)); 
  }
  
  public void setStrokeColor(ColorStateList paramColorStateList) {
    if (b())
      this.e.b(paramColorStateList); 
  }
  
  public void setStrokeColorResource(int paramInt) {
    if (b())
      setStrokeColor(a.b.h.c.a.a.b(getContext(), paramInt)); 
  }
  
  public void setStrokeWidth(int paramInt) {
    if (b())
      this.e.c(paramInt); 
  }
  
  public void setStrokeWidthResource(int paramInt) {
    if (b())
      setStrokeWidth(getResources().getDimensionPixelSize(paramInt)); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    if (b()) {
      this.e.c(paramColorStateList);
    } else if (this.e != null) {
      super.setSupportBackgroundTintList(paramColorStateList);
    } 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    if (b()) {
      this.e.a(paramMode);
    } else if (this.e != null) {
      super.setSupportBackgroundTintMode(paramMode);
    } 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\c\m\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */