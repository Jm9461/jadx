package a.b.c.m;

import a.b.c.k;
import a.b.c.p.a;
import a.b.c.q.a;
import android.annotation.TargetApi;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.support.design.internal.h;
import android.support.v4.graphics.drawable.a;
import android.support.v4.view.u;
import android.view.View;

class c {
  private static final boolean w;
  
  private final a a;
  
  private int b;
  
  private int c;
  
  private int d;
  
  private int e;
  
  private int f;
  
  private int g;
  
  private PorterDuff.Mode h;
  
  private ColorStateList i;
  
  private ColorStateList j;
  
  private ColorStateList k;
  
  private final Paint l = new Paint(1);
  
  private final Rect m = new Rect();
  
  private final RectF n = new RectF();
  
  private GradientDrawable o;
  
  private Drawable p;
  
  private GradientDrawable q;
  
  private Drawable r;
  
  private GradientDrawable s;
  
  private GradientDrawable t;
  
  private GradientDrawable u;
  
  private boolean v = false;
  
  static {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 21) {
      bool = true;
    } else {
      bool = false;
    } 
    w = bool;
  }
  
  public c(a parama) {
    this.a = parama;
  }
  
  private InsetDrawable a(Drawable paramDrawable) {
    return new InsetDrawable(paramDrawable, this.b, this.d, this.c, this.e);
  }
  
  private Drawable i() {
    this.o = new GradientDrawable();
    this.o.setCornerRadius(this.f + 1.0E-5F);
    this.o.setColor(-1);
    this.p = a.h((Drawable)this.o);
    a.a(this.p, this.i);
    PorterDuff.Mode mode = this.h;
    if (mode != null)
      a.a(this.p, mode); 
    this.q = new GradientDrawable();
    this.q.setCornerRadius(this.f + 1.0E-5F);
    this.q.setColor(-1);
    this.r = a.h((Drawable)this.q);
    a.a(this.r, this.k);
    return (Drawable)a((Drawable)new LayerDrawable(new Drawable[] { this.p, this.r }));
  }
  
  @TargetApi(21)
  private Drawable j() {
    this.s = new GradientDrawable();
    this.s.setCornerRadius(this.f + 1.0E-5F);
    this.s.setColor(-1);
    n();
    this.t = new GradientDrawable();
    this.t.setCornerRadius(this.f + 1.0E-5F);
    this.t.setColor(0);
    this.t.setStroke(this.g, this.j);
    InsetDrawable insetDrawable = a((Drawable)new LayerDrawable(new Drawable[] { (Drawable)this.s, (Drawable)this.t }));
    this.u = new GradientDrawable();
    this.u.setCornerRadius(this.f + 1.0E-5F);
    this.u.setColor(-1);
    return (Drawable)new b(a.a(this.k), insetDrawable, (Drawable)this.u);
  }
  
  private GradientDrawable k() {
    return (w && this.a.getBackground() != null) ? (GradientDrawable)((LayerDrawable)((InsetDrawable)((RippleDrawable)this.a.getBackground()).getDrawable(0)).getDrawable()).getDrawable(0) : null;
  }
  
  private GradientDrawable l() {
    return (w && this.a.getBackground() != null) ? (GradientDrawable)((LayerDrawable)((InsetDrawable)((RippleDrawable)this.a.getBackground()).getDrawable(0)).getDrawable()).getDrawable(1) : null;
  }
  
  private void m() {
    if (w && this.t != null) {
      this.a.setInternalBackground(j());
    } else if (!w) {
      this.a.invalidate();
    } 
  }
  
  private void n() {
    GradientDrawable gradientDrawable = this.s;
    if (gradientDrawable != null) {
      a.a((Drawable)gradientDrawable, this.i);
      PorterDuff.Mode mode = this.h;
      if (mode != null)
        a.a((Drawable)this.s, mode); 
    } 
  }
  
  int a() {
    return this.f;
  }
  
  void a(int paramInt) {
    if (w) {
      GradientDrawable gradientDrawable = this.s;
      if (gradientDrawable != null) {
        gradientDrawable.setColor(paramInt);
        return;
      } 
    } 
    if (!w) {
      GradientDrawable gradientDrawable = this.o;
      if (gradientDrawable != null)
        gradientDrawable.setColor(paramInt); 
    } 
  }
  
  void a(int paramInt1, int paramInt2) {
    GradientDrawable gradientDrawable = this.u;
    if (gradientDrawable != null)
      gradientDrawable.setBounds(this.b, this.d, paramInt2 - this.c, paramInt1 - this.e); 
  }
  
  void a(ColorStateList paramColorStateList) {
    if (this.k != paramColorStateList) {
      this.k = paramColorStateList;
      if (w && this.a.getBackground() instanceof RippleDrawable) {
        ((RippleDrawable)this.a.getBackground()).setColor(paramColorStateList);
      } else if (!w) {
        Drawable drawable = this.r;
        if (drawable != null)
          a.a(drawable, paramColorStateList); 
      } 
    } 
  }
  
  public void a(TypedArray paramTypedArray) {
    Drawable drawable;
    int j = k.MaterialButton_android_insetLeft;
    int i = 0;
    this.b = paramTypedArray.getDimensionPixelOffset(j, 0);
    this.c = paramTypedArray.getDimensionPixelOffset(k.MaterialButton_android_insetRight, 0);
    this.d = paramTypedArray.getDimensionPixelOffset(k.MaterialButton_android_insetTop, 0);
    this.e = paramTypedArray.getDimensionPixelOffset(k.MaterialButton_android_insetBottom, 0);
    this.f = paramTypedArray.getDimensionPixelSize(k.MaterialButton_cornerRadius, 0);
    this.g = paramTypedArray.getDimensionPixelSize(k.MaterialButton_strokeWidth, 0);
    this.h = h.a(paramTypedArray.getInt(k.MaterialButton_backgroundTintMode, -1), PorterDuff.Mode.SRC_IN);
    this.i = a.a(this.a.getContext(), paramTypedArray, k.MaterialButton_backgroundTint);
    this.j = a.a(this.a.getContext(), paramTypedArray, k.MaterialButton_strokeColor);
    this.k = a.a(this.a.getContext(), paramTypedArray, k.MaterialButton_rippleColor);
    this.l.setStyle(Paint.Style.STROKE);
    this.l.setStrokeWidth(this.g);
    Paint paint = this.l;
    ColorStateList colorStateList = this.j;
    if (colorStateList != null)
      i = colorStateList.getColorForState(this.a.getDrawableState(), 0); 
    paint.setColor(i);
    int m = u.o((View)this.a);
    i = this.a.getPaddingTop();
    int k = u.n((View)this.a);
    j = this.a.getPaddingBottom();
    a a1 = this.a;
    if (w) {
      drawable = j();
    } else {
      drawable = i();
    } 
    a1.setInternalBackground(drawable);
    u.a((View)this.a, this.b + m, this.d + i, this.c + k, this.e + j);
  }
  
  void a(Canvas paramCanvas) {
    if (paramCanvas != null && this.j != null && this.g > 0) {
      this.m.set(this.a.getBackground().getBounds());
      RectF rectF = this.n;
      Rect rect = this.m;
      float f = rect.left;
      int i = this.g;
      rectF.set(f + i / 2.0F + this.b, rect.top + i / 2.0F + this.d, rect.right - i / 2.0F - this.c, rect.bottom - i / 2.0F - this.e);
      f = this.f - this.g / 2.0F;
      paramCanvas.drawRoundRect(this.n, f, f, this.l);
    } 
  }
  
  void a(PorterDuff.Mode paramMode) {
    if (this.h != paramMode) {
      this.h = paramMode;
      if (w) {
        n();
      } else {
        Drawable drawable = this.p;
        if (drawable != null) {
          paramMode = this.h;
          if (paramMode != null)
            a.a(drawable, paramMode); 
        } 
      } 
    } 
  }
  
  ColorStateList b() {
    return this.k;
  }
  
  void b(int paramInt) {
    if (this.f != paramInt) {
      this.f = paramInt;
      if (w && this.s != null && this.t != null && this.u != null) {
        if (Build.VERSION.SDK_INT == 21) {
          k().setCornerRadius(paramInt + 1.0E-5F);
          l().setCornerRadius(paramInt + 1.0E-5F);
        } 
        this.s.setCornerRadius(paramInt + 1.0E-5F);
        this.t.setCornerRadius(paramInt + 1.0E-5F);
        this.u.setCornerRadius(paramInt + 1.0E-5F);
      } else if (!w) {
        GradientDrawable gradientDrawable = this.o;
        if (gradientDrawable != null && this.q != null) {
          gradientDrawable.setCornerRadius(paramInt + 1.0E-5F);
          this.q.setCornerRadius(paramInt + 1.0E-5F);
          this.a.invalidate();
        } 
      } 
    } 
  }
  
  void b(ColorStateList paramColorStateList) {
    if (this.j != paramColorStateList) {
      this.j = paramColorStateList;
      Paint paint = this.l;
      int i = 0;
      if (paramColorStateList != null)
        i = paramColorStateList.getColorForState(this.a.getDrawableState(), 0); 
      paint.setColor(i);
      m();
    } 
  }
  
  ColorStateList c() {
    return this.j;
  }
  
  void c(int paramInt) {
    if (this.g != paramInt) {
      this.g = paramInt;
      this.l.setStrokeWidth(paramInt);
      m();
    } 
  }
  
  void c(ColorStateList paramColorStateList) {
    if (this.i != paramColorStateList) {
      this.i = paramColorStateList;
      if (w) {
        n();
      } else {
        Drawable drawable = this.p;
        if (drawable != null)
          a.a(drawable, this.i); 
      } 
    } 
  }
  
  int d() {
    return this.g;
  }
  
  ColorStateList e() {
    return this.i;
  }
  
  PorterDuff.Mode f() {
    return this.h;
  }
  
  boolean g() {
    return this.v;
  }
  
  void h() {
    this.v = true;
    this.a.setSupportBackgroundTintList(this.i);
    this.a.setSupportBackgroundTintMode(this.h);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\c\m\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */