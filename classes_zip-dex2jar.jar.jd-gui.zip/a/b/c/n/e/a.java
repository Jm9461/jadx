package a.b.c.n.e;

import a.b.c.n.c;
import a.b.c.n.d;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.CardView;

public class a extends CardView implements d {
  private final c l;
  
  public void a() {
    this.l.a();
    throw null;
  }
  
  public void b() {
    this.l.b();
    throw null;
  }
  
  public void draw(Canvas paramCanvas) {
    c c1 = this.l;
    if (c1 == null) {
      super.draw(paramCanvas);
      return;
    } 
    c1.a(paramCanvas);
    throw null;
  }
  
  public Drawable getCircularRevealOverlayDrawable() {
    this.l.c();
    throw null;
  }
  
  public int getCircularRevealScrimColor() {
    this.l.d();
    throw null;
  }
  
  public d.e getRevealInfo() {
    this.l.e();
    throw null;
  }
  
  public boolean isOpaque() {
    c c1 = this.l;
    if (c1 == null)
      return super.isOpaque(); 
    c1.f();
    throw null;
  }
  
  public void setCircularRevealOverlayDrawable(Drawable paramDrawable) {
    this.l.a(paramDrawable);
    throw null;
  }
  
  public void setCircularRevealScrimColor(int paramInt) {
    this.l.a(paramInt);
    throw null;
  }
  
  public void setRevealInfo(d.e parame) {
    this.l.a(parame);
    throw null;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\c\n\e\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */