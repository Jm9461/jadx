package a.b.h.b;

public final class b {
  public static final int cardview_dark_background = 2131099693;
  
  public static final int cardview_light_background = 2131099694;
  
  public static final int cardview_shadow_end_color = 2131099695;
  
  public static final int cardview_shadow_start_color = 2131099696;
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\h\b\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */