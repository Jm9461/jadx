package a.b.h.b;

public final class c {
  public static final int cardview_compat_inset_shadow = 2131165297;
  
  public static final int cardview_default_elevation = 2131165298;
  
  public static final int cardview_default_radius = 2131165299;
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\h\b\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */