package a.b.h.b;

public final class e {
  public static final int[] CardView = new int[] { 
      16843071, 16843072, 2130968686, 2130968687, 2130968688, 2130968689, 2130968690, 2130968691, 2130968770, 2130968771, 
      2130968772, 2130968773, 2130968774 };
  
  public static final int CardView_android_minHeight = 1;
  
  public static final int CardView_android_minWidth = 0;
  
  public static final int CardView_cardBackgroundColor = 2;
  
  public static final int CardView_cardCornerRadius = 3;
  
  public static final int CardView_cardElevation = 4;
  
  public static final int CardView_cardMaxElevation = 5;
  
  public static final int CardView_cardPreventCornerOverlap = 6;
  
  public static final int CardView_cardUseCompatPadding = 7;
  
  public static final int CardView_contentPadding = 8;
  
  public static final int CardView_contentPaddingBottom = 9;
  
  public static final int CardView_contentPaddingLeft = 10;
  
  public static final int CardView_contentPaddingRight = 11;
  
  public static final int CardView_contentPaddingTop = 12;
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\h\b\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */