package a.b.h.f;

import a.b.h.a.j;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff;
import android.support.v4.view.c;
import android.support.v4.view.h;
import android.support.v7.view.menu.k;
import android.support.v7.view.menu.l;
import android.support.v7.widget.h0;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class g extends MenuInflater {
  static final Class<?>[] e = new Class[] { Context.class };
  
  static final Class<?>[] f = e;
  
  final Object[] a;
  
  final Object[] b;
  
  Context c;
  
  private Object d;
  
  public g(Context paramContext) {
    super(paramContext);
    this.c = paramContext;
    this.a = new Object[] { paramContext };
    this.b = this.a;
  }
  
  private Object a(Object paramObject) {
    return (paramObject instanceof android.app.Activity) ? paramObject : ((paramObject instanceof ContextWrapper) ? a(((ContextWrapper)paramObject).getBaseContext()) : paramObject);
  }
  
  private void a(XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Menu paramMenu) {
    StringBuilder stringBuilder;
    int i;
    b b = new b(this, paramMenu);
    int j = paramXmlPullParser.getEventType();
    int k = 0;
    Menu menu = null;
    do {
      if (j == 2) {
        String str = paramXmlPullParser.getName();
        if (str.equals("menu")) {
          int n = paramXmlPullParser.next();
          break;
        } 
        stringBuilder = new StringBuilder();
        stringBuilder.append("Expecting menu, got ");
        stringBuilder.append(str);
        throw new RuntimeException(stringBuilder.toString());
      } 
      i = stringBuilder.next();
      j = i;
    } while (i != 1);
    j = 0;
    int m = i;
    while (j == 0) {
      if (m != 1) {
        Menu menu1;
        int n;
        if (m != 2) {
          if (m != 3) {
            i = k;
            paramMenu = menu;
            n = j;
          } else {
            String str = stringBuilder.getName();
            if (k && str.equals(menu)) {
              i = 0;
              paramMenu = null;
              n = j;
            } else if (str.equals("group")) {
              b.d();
              i = k;
              paramMenu = menu;
              n = j;
            } else if (str.equals("item")) {
              i = k;
              paramMenu = menu;
              n = j;
              if (!b.c()) {
                c c = b.A;
                if (c != null && c.a()) {
                  b.b();
                  i = k;
                  menu1 = menu;
                  n = j;
                } else {
                  b.a();
                  i = k;
                  menu1 = menu;
                  n = j;
                } 
              } 
            } else {
              i = k;
              paramMenu = menu;
              n = j;
              if (str.equals("menu")) {
                n = 1;
                i = k;
                paramMenu = menu;
              } 
            } 
          } 
        } else if (k) {
          i = k;
          paramMenu = menu;
          n = j;
        } else {
          String str = stringBuilder.getName();
          if (str.equals("group")) {
            b.a(paramAttributeSet);
            i = k;
            menu1 = menu;
            n = j;
          } else if (menu1.equals("item")) {
            b.b(paramAttributeSet);
            i = k;
            menu1 = menu;
            n = j;
          } else if (menu1.equals("menu")) {
            a((XmlPullParser)stringBuilder, paramAttributeSet, (Menu)b.b());
            i = k;
            menu1 = menu;
            n = j;
          } else {
            i = 1;
            n = j;
          } 
        } 
        m = stringBuilder.next();
        k = i;
        menu = menu1;
        j = n;
        continue;
      } 
      throw new RuntimeException("Unexpected end of document");
    } 
  }
  
  Object a() {
    if (this.d == null)
      this.d = a(this.c); 
    return this.d;
  }
  
  public void inflate(int paramInt, Menu paramMenu) {
    InflateException inflateException1;
    InflateException inflateException2;
    if (!(paramMenu instanceof a.b.g.b.a.a)) {
      super.inflate(paramInt, paramMenu);
      return;
    } 
    XmlResourceParser xmlResourceParser2 = null;
    XmlResourceParser xmlResourceParser3 = null;
    XmlResourceParser xmlResourceParser1 = null;
    try {
      XmlResourceParser xmlResourceParser = this.c.getResources().getLayout(paramInt);
      xmlResourceParser1 = xmlResourceParser;
      xmlResourceParser2 = xmlResourceParser;
      xmlResourceParser3 = xmlResourceParser;
      a((XmlPullParser)xmlResourceParser, Xml.asAttributeSet((XmlPullParser)xmlResourceParser), paramMenu);
      if (xmlResourceParser != null)
        xmlResourceParser.close(); 
      return;
    } catch (XmlPullParserException xmlPullParserException) {
      xmlResourceParser1 = xmlResourceParser3;
      inflateException2 = new InflateException();
      xmlResourceParser1 = xmlResourceParser3;
      this("Error inflating menu XML", (Throwable)xmlPullParserException);
      xmlResourceParser1 = xmlResourceParser3;
      throw inflateException2;
    } catch (IOException iOException) {
      inflateException1 = inflateException2;
      InflateException inflateException = new InflateException();
      inflateException1 = inflateException2;
      this("Error inflating menu XML", iOException);
      inflateException1 = inflateException2;
      throw inflateException;
    } finally {}
    if (inflateException1 != null)
      inflateException1.close(); 
    throw paramMenu;
  }
  
  private static class a implements MenuItem.OnMenuItemClickListener {
    private static final Class<?>[] c = new Class[] { MenuItem.class };
    
    private Object a;
    
    private Method b;
    
    public a(Object param1Object, String param1String) {
      this.a = param1Object;
      Class<?> clazz = param1Object.getClass();
      try {
        this.b = clazz.getMethod(param1String, c);
        return;
      } catch (Exception exception) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Couldn't resolve menu item onClick handler ");
        stringBuilder.append(param1String);
        stringBuilder.append(" in class ");
        stringBuilder.append(clazz.getName());
        InflateException inflateException = new InflateException(stringBuilder.toString());
        inflateException.initCause(exception);
        throw inflateException;
      } 
    }
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      try {
        if (this.b.getReturnType() == boolean.class)
          return ((Boolean)this.b.invoke(this.a, new Object[] { param1MenuItem })).booleanValue(); 
        this.b.invoke(this.a, new Object[] { param1MenuItem });
        return true;
      } catch (Exception exception) {
        throw new RuntimeException(exception);
      } 
    }
  }
  
  private class b {
    c A;
    
    private CharSequence B;
    
    private CharSequence C;
    
    private ColorStateList D = null;
    
    private PorterDuff.Mode E = null;
    
    final g F;
    
    private Menu a;
    
    private int b;
    
    private int c;
    
    private int d;
    
    private int e;
    
    private boolean f;
    
    private boolean g;
    
    private boolean h;
    
    private int i;
    
    private int j;
    
    private CharSequence k;
    
    private CharSequence l;
    
    private int m;
    
    private char n;
    
    private int o;
    
    private char p;
    
    private int q;
    
    private int r;
    
    private boolean s;
    
    private boolean t;
    
    private boolean u;
    
    private int v;
    
    private int w;
    
    private String x;
    
    private String y;
    
    private String z;
    
    public b(g this$0, Menu param1Menu) {
      this.a = param1Menu;
      d();
    }
    
    private char a(String param1String) {
      return (param1String == null) ? Character.MIN_VALUE : param1String.charAt(0);
    }
    
    private <T> T a(String param1String, Class<?>[] param1ArrayOfClass, Object[] param1ArrayOfObject) {
      try {
        null = this.F.c.getClassLoader().loadClass(param1String).getConstructor(param1ArrayOfClass);
        null.setAccessible(true);
        return (T)null.newInstance(param1ArrayOfObject);
      } catch (Exception exception) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot instantiate class: ");
        stringBuilder.append(param1String);
        Log.w("SupportMenuInflater", stringBuilder.toString(), exception);
        return null;
      } 
    }
    
    private void a(MenuItem param1MenuItem) {
      boolean bool;
      MenuItem menuItem = param1MenuItem.setChecked(this.s).setVisible(this.t).setEnabled(this.u);
      if (this.r >= 1) {
        bool = true;
      } else {
        bool = false;
      } 
      menuItem.setCheckable(bool).setTitleCondensed(this.l).setIcon(this.m);
      int i = this.v;
      if (i >= 0)
        param1MenuItem.setShowAsAction(i); 
      if (this.z != null)
        if (!this.F.c.isRestricted()) {
          param1MenuItem.setOnMenuItemClickListener(new g.a(this.F.a(), this.z));
        } else {
          throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
        }  
      if (param1MenuItem instanceof k)
        k k = (k)param1MenuItem; 
      if (this.r >= 2)
        if (param1MenuItem instanceof k) {
          ((k)param1MenuItem).c(true);
        } else if (param1MenuItem instanceof l) {
          ((l)param1MenuItem).a(true);
        }  
      i = 0;
      String str = this.x;
      if (str != null) {
        param1MenuItem.setActionView(a(str, g.e, this.F.a));
        i = 1;
      } 
      int j = this.w;
      if (j > 0)
        if (i == 0) {
          param1MenuItem.setActionView(j);
        } else {
          Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
        }  
      c c1 = this.A;
      if (c1 != null)
        h.a(param1MenuItem, c1); 
      h.a(param1MenuItem, this.B);
      h.b(param1MenuItem, this.C);
      h.a(param1MenuItem, this.n, this.o);
      h.b(param1MenuItem, this.p, this.q);
      PorterDuff.Mode mode = this.E;
      if (mode != null)
        h.a(param1MenuItem, mode); 
      ColorStateList colorStateList = this.D;
      if (colorStateList != null)
        h.a(param1MenuItem, colorStateList); 
    }
    
    public void a() {
      this.h = true;
      a(this.a.add(this.b, this.i, this.j, this.k));
    }
    
    public void a(AttributeSet param1AttributeSet) {
      TypedArray typedArray = this.F.c.obtainStyledAttributes(param1AttributeSet, j.MenuGroup);
      this.b = typedArray.getResourceId(j.MenuGroup_android_id, 0);
      this.c = typedArray.getInt(j.MenuGroup_android_menuCategory, 0);
      this.d = typedArray.getInt(j.MenuGroup_android_orderInCategory, 0);
      this.e = typedArray.getInt(j.MenuGroup_android_checkableBehavior, 0);
      this.f = typedArray.getBoolean(j.MenuGroup_android_visible, true);
      this.g = typedArray.getBoolean(j.MenuGroup_android_enabled, true);
      typedArray.recycle();
    }
    
    public SubMenu b() {
      this.h = true;
      SubMenu subMenu = this.a.addSubMenu(this.b, this.i, this.j, this.k);
      a(subMenu.getItem());
      return subMenu;
    }
    
    public void b(AttributeSet param1AttributeSet) {
      boolean bool;
      TypedArray typedArray = this.F.c.obtainStyledAttributes(param1AttributeSet, j.MenuItem);
      this.i = typedArray.getResourceId(j.MenuItem_android_id, 0);
      this.j = 0xFFFF0000 & typedArray.getInt(j.MenuItem_android_menuCategory, this.c) | 0xFFFF & typedArray.getInt(j.MenuItem_android_orderInCategory, this.d);
      this.k = typedArray.getText(j.MenuItem_android_title);
      this.l = typedArray.getText(j.MenuItem_android_titleCondensed);
      this.m = typedArray.getResourceId(j.MenuItem_android_icon, 0);
      this.n = a(typedArray.getString(j.MenuItem_android_alphabeticShortcut));
      this.o = typedArray.getInt(j.MenuItem_alphabeticModifiers, 4096);
      this.p = a(typedArray.getString(j.MenuItem_android_numericShortcut));
      this.q = typedArray.getInt(j.MenuItem_numericModifiers, 4096);
      if (typedArray.hasValue(j.MenuItem_android_checkable)) {
        this.r = typedArray.getBoolean(j.MenuItem_android_checkable, false);
      } else {
        this.r = this.e;
      } 
      this.s = typedArray.getBoolean(j.MenuItem_android_checked, false);
      this.t = typedArray.getBoolean(j.MenuItem_android_visible, this.f);
      this.u = typedArray.getBoolean(j.MenuItem_android_enabled, this.g);
      this.v = typedArray.getInt(j.MenuItem_showAsAction, -1);
      this.z = typedArray.getString(j.MenuItem_android_onClick);
      this.w = typedArray.getResourceId(j.MenuItem_actionLayout, 0);
      this.x = typedArray.getString(j.MenuItem_actionViewClass);
      this.y = typedArray.getString(j.MenuItem_actionProviderClass);
      if (this.y != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool && this.w == 0 && this.x == null) {
        this.A = a(this.y, g.f, this.F.b);
      } else {
        if (bool)
          Log.w("SupportMenuInflater", "Ignoring attribute 'actionProviderClass'. Action view already specified."); 
        this.A = null;
      } 
      this.B = typedArray.getText(j.MenuItem_contentDescription);
      this.C = typedArray.getText(j.MenuItem_tooltipText);
      if (typedArray.hasValue(j.MenuItem_iconTintMode)) {
        this.E = h0.a(typedArray.getInt(j.MenuItem_iconTintMode, -1), this.E);
      } else {
        this.E = null;
      } 
      if (typedArray.hasValue(j.MenuItem_iconTint)) {
        this.D = typedArray.getColorStateList(j.MenuItem_iconTint);
      } else {
        this.D = null;
      } 
      typedArray.recycle();
      this.h = false;
    }
    
    public boolean c() {
      return this.h;
    }
    
    public void d() {
      this.b = 0;
      this.c = 0;
      this.d = 0;
      this.e = 0;
      this.f = true;
      this.g = true;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\h\f\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */