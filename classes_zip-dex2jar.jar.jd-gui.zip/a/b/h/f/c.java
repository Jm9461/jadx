package a.b.h.f;

public interface c {
  void b();
  
  void c();
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\h\f\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */