package a.b.h.f;

import android.content.Context;
import android.support.v7.view.menu.h;
import android.support.v7.widget.ActionBarContextView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import java.lang.ref.WeakReference;

public class e extends b implements h.a {
  private Context e;
  
  private ActionBarContextView f;
  
  private b.a g;
  
  private WeakReference<View> h;
  
  private boolean i;
  
  private h j;
  
  public e(Context paramContext, ActionBarContextView paramActionBarContextView, b.a parama, boolean paramBoolean) {
    this.e = paramContext;
    this.f = paramActionBarContextView;
    this.g = parama;
    h h1 = new h(paramActionBarContextView.getContext());
    h1.c(1);
    this.j = h1;
    this.j.a(this);
  }
  
  public void a() {
    if (this.i)
      return; 
    this.i = true;
    this.f.sendAccessibilityEvent(32);
    this.g.a(this);
  }
  
  public void a(int paramInt) {
    a(this.e.getString(paramInt));
  }
  
  public void a(h paramh) {
    i();
    this.f.d();
  }
  
  public void a(View paramView) {
    this.f.setCustomView(paramView);
    if (paramView != null) {
      WeakReference<View> weakReference = new WeakReference<View>(paramView);
    } else {
      paramView = null;
    } 
    this.h = (WeakReference<View>)paramView;
  }
  
  public void a(CharSequence paramCharSequence) {
    this.f.setSubtitle(paramCharSequence);
  }
  
  public void a(boolean paramBoolean) {
    super.a(paramBoolean);
    this.f.setTitleOptional(paramBoolean);
  }
  
  public boolean a(h paramh, MenuItem paramMenuItem) {
    return this.g.a(this, paramMenuItem);
  }
  
  public View b() {
    WeakReference<View> weakReference = this.h;
    if (weakReference != null) {
      View view = weakReference.get();
    } else {
      weakReference = null;
    } 
    return (View)weakReference;
  }
  
  public void b(int paramInt) {
    b(this.e.getString(paramInt));
  }
  
  public void b(CharSequence paramCharSequence) {
    this.f.setTitle(paramCharSequence);
  }
  
  public Menu c() {
    return (Menu)this.j;
  }
  
  public MenuInflater d() {
    return new g(this.f.getContext());
  }
  
  public CharSequence e() {
    return this.f.getSubtitle();
  }
  
  public CharSequence g() {
    return this.f.getTitle();
  }
  
  public void i() {
    this.g.b(this, (Menu)this.j);
  }
  
  public boolean j() {
    return this.f.b();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\h\f\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */