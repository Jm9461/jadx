package a.b.h.a;

public final class b {
  public static final int abc_action_bar_embed_tabs = 2131034112;
  
  public static final int abc_allow_stacked_button_bar = 2131034113;
  
  public static final int abc_config_actionMenuItemAllCaps = 2131034114;
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\h\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */