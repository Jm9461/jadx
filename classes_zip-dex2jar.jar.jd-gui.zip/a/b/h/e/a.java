package a.b.h.e;

public final class a {
  public static final int compat_button_inset_horizontal_material = 2131165301;
  
  public static final int compat_button_inset_vertical_material = 2131165302;
  
  public static final int compat_button_padding_horizontal_material = 2131165303;
  
  public static final int compat_button_padding_vertical_material = 2131165304;
  
  public static final int compat_control_corner_material = 2131165305;
  
  public static final int compat_notification_large_icon_max_height = 2131165306;
  
  public static final int compat_notification_large_icon_max_width = 2131165307;
  
  public static final int fastscroll_default_thickness = 2131165360;
  
  public static final int fastscroll_margin = 2131165361;
  
  public static final int fastscroll_minimum_range = 2131165362;
  
  public static final int item_touch_helper_max_drag_scroll_per_frame = 2131165376;
  
  public static final int item_touch_helper_swipe_escape_max_velocity = 2131165377;
  
  public static final int item_touch_helper_swipe_escape_velocity = 2131165378;
  
  public static final int notification_action_icon_size = 2131165521;
  
  public static final int notification_action_text_size = 2131165522;
  
  public static final int notification_big_circle_margin = 2131165523;
  
  public static final int notification_content_margin_start = 2131165524;
  
  public static final int notification_large_icon_height = 2131165525;
  
  public static final int notification_large_icon_width = 2131165526;
  
  public static final int notification_main_column_padding_top = 2131165527;
  
  public static final int notification_media_narrow_margin = 2131165528;
  
  public static final int notification_right_icon_size = 2131165529;
  
  public static final int notification_right_side_padding_top = 2131165530;
  
  public static final int notification_small_icon_background_padding = 2131165531;
  
  public static final int notification_small_icon_size_as_large = 2131165532;
  
  public static final int notification_subtext_size = 2131165533;
  
  public static final int notification_top_pad = 2131165534;
  
  public static final int notification_top_pad_large_text = 2131165535;
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\h\e\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */