package a.b.h.d.a;

import a.b.h.a.a;
import a.b.h.a.i;
import a.b.h.a.j;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.v4.graphics.drawable.a;

public class d extends Drawable {
  private static final float m = (float)Math.toRadians(45.0D);
  
  private final Paint a = new Paint();
  
  private float b;
  
  private float c;
  
  private float d;
  
  private float e;
  
  private boolean f;
  
  private final Path g = new Path();
  
  private final int h;
  
  private boolean i = false;
  
  private float j;
  
  private float k;
  
  private int l = 2;
  
  public d(Context paramContext) {
    this.a.setStyle(Paint.Style.STROKE);
    this.a.setStrokeJoin(Paint.Join.MITER);
    this.a.setStrokeCap(Paint.Cap.BUTT);
    this.a.setAntiAlias(true);
    TypedArray typedArray = paramContext.getTheme().obtainStyledAttributes(null, j.DrawerArrowToggle, a.drawerArrowStyle, i.Base_Widget_AppCompat_DrawerArrowToggle);
    a(typedArray.getColor(j.DrawerArrowToggle_color, 0));
    a(typedArray.getDimension(j.DrawerArrowToggle_thickness, 0.0F));
    a(typedArray.getBoolean(j.DrawerArrowToggle_spinBars, true));
    b(Math.round(typedArray.getDimension(j.DrawerArrowToggle_gapBetweenBars, 0.0F)));
    this.h = typedArray.getDimensionPixelSize(j.DrawerArrowToggle_drawableSize, 0);
    this.c = Math.round(typedArray.getDimension(j.DrawerArrowToggle_barLength, 0.0F));
    this.b = Math.round(typedArray.getDimension(j.DrawerArrowToggle_arrowHeadLength, 0.0F));
    this.d = typedArray.getDimension(j.DrawerArrowToggle_arrowShaftLength, 0.0F);
    typedArray.recycle();
  }
  
  private static float a(float paramFloat1, float paramFloat2, float paramFloat3) {
    return (paramFloat2 - paramFloat1) * paramFloat3 + paramFloat1;
  }
  
  public void a(float paramFloat) {
    if (this.a.getStrokeWidth() != paramFloat) {
      this.a.setStrokeWidth(paramFloat);
      double d1 = (paramFloat / 2.0F);
      double d2 = Math.cos(m);
      Double.isNaN(d1);
      this.k = (float)(d1 * d2);
      invalidateSelf();
    } 
  }
  
  public void a(int paramInt) {
    if (paramInt != this.a.getColor()) {
      this.a.setColor(paramInt);
      invalidateSelf();
    } 
  }
  
  public void a(boolean paramBoolean) {
    if (this.f != paramBoolean) {
      this.f = paramBoolean;
      invalidateSelf();
    } 
  }
  
  public void b(float paramFloat) {
    if (paramFloat != this.e) {
      this.e = paramFloat;
      invalidateSelf();
    } 
  }
  
  public void b(boolean paramBoolean) {
    if (this.i != paramBoolean) {
      this.i = paramBoolean;
      invalidateSelf();
    } 
  }
  
  public void c(float paramFloat) {
    if (this.j != paramFloat) {
      this.j = paramFloat;
      invalidateSelf();
    } 
  }
  
  public void draw(Canvas paramCanvas) {
    boolean bool;
    Rect rect = getBounds();
    int i = this.l;
    if (i != 0) {
      if (i != 1) {
        bool = false;
        boolean bool1 = false;
        if (i != 3) {
          bool = bool1;
          if (a.e(this) == 1)
            bool = true; 
        } else if (a.e(this) == 0) {
          bool = true;
        } 
      } else {
        bool = true;
      } 
    } else {
      bool = false;
    } 
    float f1 = this.b;
    f1 = (float)Math.sqrt((f1 * f1 * 2.0F));
    float f5 = a(this.c, f1, this.j);
    float f3 = a(this.c, this.d, this.j);
    float f4 = Math.round(a(0.0F, this.k, this.j));
    float f6 = a(0.0F, m, this.j);
    if (bool) {
      f1 = 0.0F;
    } else {
      f1 = -180.0F;
    } 
    if (bool) {
      f2 = 180.0F;
    } else {
      f2 = 0.0F;
    } 
    f1 = a(f1, f2, this.j);
    double d2 = f5;
    double d1 = Math.cos(f6);
    Double.isNaN(d2);
    float f2 = (float)Math.round(d2 * d1);
    d2 = f5;
    d1 = Math.sin(f6);
    Double.isNaN(d2);
    f6 = (float)Math.round(d2 * d1);
    this.g.rewind();
    float f7 = a(this.e + this.a.getStrokeWidth(), -this.k, this.j);
    f5 = -f3 / 2.0F;
    this.g.moveTo(f5 + f4, 0.0F);
    this.g.rLineTo(f3 - f4 * 2.0F, 0.0F);
    this.g.moveTo(f5, f7);
    this.g.rLineTo(f2, f6);
    this.g.moveTo(f5, -f7);
    this.g.rLineTo(f2, -f6);
    this.g.close();
    paramCanvas.save();
    f2 = this.a.getStrokeWidth();
    f4 = rect.height();
    f3 = this.e;
    f4 = ((int)(f4 - 3.0F * f2 - 2.0F * f3) / 4 * 2);
    paramCanvas.translate(rect.centerX(), f4 + 1.5F * f2 + f3);
    if (this.f) {
      if (this.i ^ bool) {
        byte b = -1;
      } else {
        bool = true;
      } 
      paramCanvas.rotate(bool * f1);
    } else if (bool) {
      paramCanvas.rotate(180.0F);
    } 
    paramCanvas.drawPath(this.g, this.a);
    paramCanvas.restore();
  }
  
  public int getIntrinsicHeight() {
    return this.h;
  }
  
  public int getIntrinsicWidth() {
    return this.h;
  }
  
  public int getOpacity() {
    return -3;
  }
  
  public void setAlpha(int paramInt) {
    if (paramInt != this.a.getAlpha()) {
      this.a.setAlpha(paramInt);
      invalidateSelf();
    } 
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    this.a.setColorFilter(paramColorFilter);
    invalidateSelf();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\h\d\a\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */