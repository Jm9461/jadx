package a.b.d.a;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class i extends h {
  static final PorterDuff.Mode l = PorterDuff.Mode.SRC_IN;
  
  private h d = new h();
  
  private PorterDuffColorFilter e;
  
  private ColorFilter f;
  
  private boolean g;
  
  private boolean h = true;
  
  private final float[] i = new float[9];
  
  private final Matrix j = new Matrix();
  
  private final Rect k = new Rect();
  
  i() {}
  
  i(h paramh) {
    this.e = a(this.e, paramh.c, paramh.d);
  }
  
  static int a(int paramInt, float paramFloat) {
    return paramInt & 0xFFFFFF | (int)(Color.alpha(paramInt) * paramFloat) << 24;
  }
  
  public static i a(Resources paramResources, int paramInt, Resources.Theme paramTheme) {
    if (Build.VERSION.SDK_INT >= 24) {
      i i1 = new i();
      i1.c = android.support.v4.content.e.f.a(paramResources, paramInt, paramTheme);
      new i(i1.c.getConstantState());
      return i1;
    } 
    try {
      XmlResourceParser xmlResourceParser = paramResources.getXml(paramInt);
      AttributeSet attributeSet = Xml.asAttributeSet((XmlPullParser)xmlResourceParser);
      while (true) {
        paramInt = xmlResourceParser.next();
        if (paramInt != 2 && paramInt != 1)
          continue; 
        break;
      } 
      if (paramInt == 2)
        return createFromXmlInner(paramResources, (XmlPullParser)xmlResourceParser, attributeSet, paramTheme); 
      XmlPullParserException xmlPullParserException = new XmlPullParserException();
      this("No start tag found");
      throw xmlPullParserException;
    } catch (XmlPullParserException xmlPullParserException) {
      Log.e("VectorDrawableCompat", "parser error", (Throwable)xmlPullParserException);
    } catch (IOException iOException) {
      Log.e("VectorDrawableCompat", "parser error", iOException);
    } 
    return null;
  }
  
  private static PorterDuff.Mode a(int paramInt, PorterDuff.Mode paramMode) {
    if (paramInt != 3) {
      if (paramInt != 5) {
        if (paramInt != 9) {
          switch (paramInt) {
            default:
              return paramMode;
            case 16:
              return PorterDuff.Mode.ADD;
            case 15:
              return PorterDuff.Mode.SCREEN;
            case 14:
              break;
          } 
          return PorterDuff.Mode.MULTIPLY;
        } 
        return PorterDuff.Mode.SRC_ATOP;
      } 
      return PorterDuff.Mode.SRC_IN;
    } 
    return PorterDuff.Mode.SRC_OVER;
  }
  
  private void a(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    Object object;
    h h1 = this.d;
    g g = h1.b;
    boolean bool = true;
    ArrayDeque<d> arrayDeque = new ArrayDeque();
    arrayDeque.push(g.h);
    int j = paramXmlPullParser.getEventType();
    int k = paramXmlPullParser.getDepth();
    while (j != 1 && (paramXmlPullParser.getDepth() >= k + 1 || j != 3)) {
      if (j == 2) {
        c c;
        b b;
        String str = paramXmlPullParser.getName();
        d d = arrayDeque.peek();
        if ("path".equals(str)) {
          c = new c();
          c.a(paramResources, paramAttributeSet, paramTheme, paramXmlPullParser);
          d.b.add(c);
          if (c.getPathName() != null)
            g.p.put(c.getPathName(), c); 
          boolean bool1 = false;
          h1.a |= c.c;
          continue;
        } 
        if ("clip-path".equals(c)) {
          b = new b();
          b.a(paramResources, paramAttributeSet, paramTheme, paramXmlPullParser);
          d.b.add(b);
          if (b.getPathName() != null)
            g.p.put(b.getPathName(), b); 
          h1.a |= b.c;
        } else if ("group".equals(b)) {
          d d1 = new d();
          d1.a(paramResources, paramAttributeSet, paramTheme, paramXmlPullParser);
          d.b.add(d1);
          arrayDeque.push(d1);
          if (d1.getGroupName() != null)
            g.p.put(d1.getGroupName(), d1); 
          h1.a |= d1.k;
          Object object3 = object;
          continue;
        } 
        Object object2 = object;
        continue;
      } 
      Object object1 = object;
      if (j == 3) {
        object1 = object;
        if ("group".equals(paramXmlPullParser.getName())) {
          arrayDeque.pop();
          object1 = object;
        } 
      } 
      continue;
      j = paramXmlPullParser.next();
      object = SYNTHETIC_LOCAL_VARIABLE_6;
    } 
    if (object == null)
      return; 
    XmlPullParserException xmlPullParserException = new XmlPullParserException("no path defined");
    throw xmlPullParserException;
  }
  
  private void a(TypedArray paramTypedArray, XmlPullParser paramXmlPullParser) {
    String str;
    h h1 = this.d;
    g g = h1.b;
    h1.d = a(android.support.v4.content.e.g.b(paramTypedArray, paramXmlPullParser, "tintMode", 6, -1), PorterDuff.Mode.SRC_IN);
    ColorStateList colorStateList = paramTypedArray.getColorStateList(1);
    if (colorStateList != null)
      h1.c = colorStateList; 
    h1.e = android.support.v4.content.e.g.a(paramTypedArray, paramXmlPullParser, "autoMirrored", 5, h1.e);
    g.k = android.support.v4.content.e.g.a(paramTypedArray, paramXmlPullParser, "viewportWidth", 7, g.k);
    g.l = android.support.v4.content.e.g.a(paramTypedArray, paramXmlPullParser, "viewportHeight", 8, g.l);
    if (g.k > 0.0F) {
      if (g.l > 0.0F) {
        g.i = paramTypedArray.getDimension(3, g.i);
        g.j = paramTypedArray.getDimension(2, g.j);
        if (g.i > 0.0F) {
          if (g.j > 0.0F) {
            g.setAlpha(android.support.v4.content.e.g.a(paramTypedArray, paramXmlPullParser, "alpha", 4, g.getAlpha()));
            str = paramTypedArray.getString(0);
            if (str != null) {
              g.n = str;
              g.p.put(str, g);
            } 
            return;
          } 
          StringBuilder stringBuilder3 = new StringBuilder();
          stringBuilder3.append(str.getPositionDescription());
          stringBuilder3.append("<vector> tag requires height > 0");
          throw new XmlPullParserException(stringBuilder3.toString());
        } 
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(str.getPositionDescription());
        stringBuilder2.append("<vector> tag requires width > 0");
        throw new XmlPullParserException(stringBuilder2.toString());
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str.getPositionDescription());
      stringBuilder1.append("<vector> tag requires viewportHeight > 0");
      throw new XmlPullParserException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(str.getPositionDescription());
    stringBuilder.append("<vector> tag requires viewportWidth > 0");
    throw new XmlPullParserException(stringBuilder.toString());
  }
  
  private boolean a() {
    int j = Build.VERSION.SDK_INT;
    boolean bool = false;
    if (j >= 17) {
      if (isAutoMirrored() && android.support.v4.graphics.drawable.a.e(this) == 1)
        bool = true; 
      return bool;
    } 
    return false;
  }
  
  public static i createFromXmlInner(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    i i1 = new i();
    i1.inflate(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
    return i1;
  }
  
  PorterDuffColorFilter a(PorterDuffColorFilter paramPorterDuffColorFilter, ColorStateList paramColorStateList, PorterDuff.Mode paramMode) {
    return (paramColorStateList == null || paramMode == null) ? null : new PorterDuffColorFilter(paramColorStateList.getColorForState(getState(), 0), paramMode);
  }
  
  Object a(String paramString) {
    return this.d.b.p.get(paramString);
  }
  
  void a(boolean paramBoolean) {
    this.h = paramBoolean;
  }
  
  public boolean canApplyTheme() {
    Drawable drawable = this.c;
    if (drawable != null)
      android.support.v4.graphics.drawable.a.a(drawable); 
    return false;
  }
  
  public void draw(Canvas paramCanvas) {
    PorterDuffColorFilter porterDuffColorFilter;
    Drawable drawable = this.c;
    if (drawable != null) {
      drawable.draw(paramCanvas);
      return;
    } 
    copyBounds(this.k);
    if (this.k.width() <= 0 || this.k.height() <= 0)
      return; 
    ColorFilter colorFilter2 = this.f;
    ColorFilter colorFilter1 = colorFilter2;
    if (colorFilter2 == null)
      porterDuffColorFilter = this.e; 
    paramCanvas.getMatrix(this.j);
    this.j.getValues(this.i);
    float f2 = Math.abs(this.i[0]);
    float f1 = Math.abs(this.i[4]);
    float f4 = Math.abs(this.i[1]);
    float f3 = Math.abs(this.i[3]);
    if (f4 != 0.0F || f3 != 0.0F) {
      f2 = 1.0F;
      f1 = 1.0F;
    } 
    int j = (int)(this.k.width() * f2);
    int k = (int)(this.k.height() * f1);
    j = Math.min(2048, j);
    k = Math.min(2048, k);
    if (j <= 0 || k <= 0)
      return; 
    int m = paramCanvas.save();
    Rect rect = this.k;
    paramCanvas.translate(rect.left, rect.top);
    if (a()) {
      paramCanvas.translate(this.k.width(), 0.0F);
      paramCanvas.scale(-1.0F, 1.0F);
    } 
    this.k.offsetTo(0, 0);
    this.d.b(j, k);
    if (!this.h) {
      this.d.c(j, k);
    } else if (!this.d.a()) {
      this.d.c(j, k);
      this.d.d();
    } 
    this.d.a(paramCanvas, (ColorFilter)porterDuffColorFilter, this.k);
    paramCanvas.restoreToCount(m);
  }
  
  public int getAlpha() {
    Drawable drawable = this.c;
    return (drawable != null) ? android.support.v4.graphics.drawable.a.c(drawable) : this.d.b.getRootAlpha();
  }
  
  public int getChangingConfigurations() {
    Drawable drawable = this.c;
    return (drawable != null) ? drawable.getChangingConfigurations() : (super.getChangingConfigurations() | this.d.getChangingConfigurations());
  }
  
  public Drawable.ConstantState getConstantState() {
    Drawable drawable = this.c;
    if (drawable != null && Build.VERSION.SDK_INT >= 24)
      return new i(drawable.getConstantState()); 
    this.d.a = getChangingConfigurations();
    return this.d;
  }
  
  public int getIntrinsicHeight() {
    Drawable drawable = this.c;
    return (drawable != null) ? drawable.getIntrinsicHeight() : (int)this.d.b.j;
  }
  
  public int getIntrinsicWidth() {
    Drawable drawable = this.c;
    return (drawable != null) ? drawable.getIntrinsicWidth() : (int)this.d.b.i;
  }
  
  public int getOpacity() {
    Drawable drawable = this.c;
    return (drawable != null) ? drawable.getOpacity() : -3;
  }
  
  public void inflate(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet) {
    Drawable drawable = this.c;
    if (drawable != null) {
      drawable.inflate(paramResources, paramXmlPullParser, paramAttributeSet);
      return;
    } 
    inflate(paramResources, paramXmlPullParser, paramAttributeSet, null);
  }
  
  public void inflate(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    Drawable drawable = this.c;
    if (drawable != null) {
      android.support.v4.graphics.drawable.a.a(drawable, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
      return;
    } 
    h h1 = this.d;
    h1.b = new g();
    TypedArray typedArray = android.support.v4.content.e.g.a(paramResources, paramTheme, paramAttributeSet, a.a);
    a(typedArray, paramXmlPullParser);
    typedArray.recycle();
    h1.a = getChangingConfigurations();
    h1.k = true;
    a(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
    this.e = a(this.e, h1.c, h1.d);
  }
  
  public void invalidateSelf() {
    Drawable drawable = this.c;
    if (drawable != null) {
      drawable.invalidateSelf();
      return;
    } 
    super.invalidateSelf();
  }
  
  public boolean isAutoMirrored() {
    Drawable drawable = this.c;
    return (drawable != null) ? android.support.v4.graphics.drawable.a.f(drawable) : this.d.e;
  }
  
  public boolean isStateful() {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Landroid/graphics/drawable/Drawable;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 14
    //   9: aload_2
    //   10: invokevirtual isStateful : ()Z
    //   13: ireturn
    //   14: aload_0
    //   15: invokespecial isStateful : ()Z
    //   18: ifne -> 64
    //   21: aload_0
    //   22: getfield d : La/b/d/a/i$h;
    //   25: astore_2
    //   26: aload_2
    //   27: ifnull -> 59
    //   30: aload_2
    //   31: invokevirtual c : ()Z
    //   34: ifne -> 64
    //   37: aload_0
    //   38: getfield d : La/b/d/a/i$h;
    //   41: getfield c : Landroid/content/res/ColorStateList;
    //   44: astore_2
    //   45: aload_2
    //   46: ifnull -> 59
    //   49: aload_2
    //   50: invokevirtual isStateful : ()Z
    //   53: ifeq -> 59
    //   56: goto -> 64
    //   59: iconst_0
    //   60: istore_1
    //   61: goto -> 66
    //   64: iconst_1
    //   65: istore_1
    //   66: iload_1
    //   67: ireturn
  }
  
  public Drawable mutate() {
    Drawable drawable = this.c;
    if (drawable != null) {
      drawable.mutate();
      return this;
    } 
    if (!this.g && super.mutate() == this) {
      this.d = new h(this.d);
      this.g = true;
    } 
    return this;
  }
  
  protected void onBoundsChange(Rect paramRect) {
    Drawable drawable = this.c;
    if (drawable != null)
      drawable.setBounds(paramRect); 
  }
  
  protected boolean onStateChange(int[] paramArrayOfint) {
    Drawable drawable = this.c;
    if (drawable != null)
      return drawable.setState(paramArrayOfint); 
    boolean bool2 = false;
    h h1 = this.d;
    ColorStateList colorStateList = h1.c;
    boolean bool1 = bool2;
    if (colorStateList != null) {
      PorterDuff.Mode mode = h1.d;
      bool1 = bool2;
      if (mode != null) {
        this.e = a(this.e, colorStateList, mode);
        invalidateSelf();
        bool1 = true;
      } 
    } 
    bool2 = bool1;
    if (h1.c()) {
      bool2 = bool1;
      if (h1.a(paramArrayOfint)) {
        invalidateSelf();
        bool2 = true;
      } 
    } 
    return bool2;
  }
  
  public void scheduleSelf(Runnable paramRunnable, long paramLong) {
    Drawable drawable = this.c;
    if (drawable != null) {
      drawable.scheduleSelf(paramRunnable, paramLong);
      return;
    } 
    super.scheduleSelf(paramRunnable, paramLong);
  }
  
  public void setAlpha(int paramInt) {
    Drawable drawable = this.c;
    if (drawable != null) {
      drawable.setAlpha(paramInt);
      return;
    } 
    if (this.d.b.getRootAlpha() != paramInt) {
      this.d.b.setRootAlpha(paramInt);
      invalidateSelf();
    } 
  }
  
  public void setAutoMirrored(boolean paramBoolean) {
    Drawable drawable = this.c;
    if (drawable != null) {
      android.support.v4.graphics.drawable.a.a(drawable, paramBoolean);
      return;
    } 
    this.d.e = paramBoolean;
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    Drawable drawable = this.c;
    if (drawable != null) {
      drawable.setColorFilter(paramColorFilter);
      return;
    } 
    this.f = paramColorFilter;
    invalidateSelf();
  }
  
  public void setTint(int paramInt) {
    Drawable drawable = this.c;
    if (drawable != null) {
      android.support.v4.graphics.drawable.a.b(drawable, paramInt);
      return;
    } 
    setTintList(ColorStateList.valueOf(paramInt));
  }
  
  public void setTintList(ColorStateList paramColorStateList) {
    Drawable drawable = this.c;
    if (drawable != null) {
      android.support.v4.graphics.drawable.a.a(drawable, paramColorStateList);
      return;
    } 
    h h1 = this.d;
    if (h1.c != paramColorStateList) {
      h1.c = paramColorStateList;
      this.e = a(this.e, paramColorStateList, h1.d);
      invalidateSelf();
    } 
  }
  
  public void setTintMode(PorterDuff.Mode paramMode) {
    Drawable drawable = this.c;
    if (drawable != null) {
      android.support.v4.graphics.drawable.a.a(drawable, paramMode);
      return;
    } 
    h h1 = this.d;
    if (h1.d != paramMode) {
      h1.d = paramMode;
      this.e = a(this.e, h1.c, paramMode);
      invalidateSelf();
    } 
  }
  
  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2) {
    Drawable drawable = this.c;
    return (drawable != null) ? drawable.setVisible(paramBoolean1, paramBoolean2) : super.setVisible(paramBoolean1, paramBoolean2);
  }
  
  public void unscheduleSelf(Runnable paramRunnable) {
    Drawable drawable = this.c;
    if (drawable != null) {
      drawable.unscheduleSelf(paramRunnable);
      return;
    } 
    super.unscheduleSelf(paramRunnable);
  }
  
  private static class b extends f {
    public b() {}
    
    public b(b param1b) {
      super(param1b);
    }
    
    private void a(TypedArray param1TypedArray) {
      String str2 = param1TypedArray.getString(0);
      if (str2 != null)
        this.b = str2; 
      String str1 = param1TypedArray.getString(1);
      if (str1 != null)
        this.a = a.b.g.a.b.a(str1); 
    }
    
    public void a(Resources param1Resources, AttributeSet param1AttributeSet, Resources.Theme param1Theme, XmlPullParser param1XmlPullParser) {
      if (!android.support.v4.content.e.g.a(param1XmlPullParser, "pathData"))
        return; 
      TypedArray typedArray = android.support.v4.content.e.g.a(param1Resources, param1Theme, param1AttributeSet, a.d);
      a(typedArray);
      typedArray.recycle();
    }
    
    public boolean b() {
      return true;
    }
  }
  
  private static class c extends f {
    private int[] d;
    
    android.support.v4.content.e.b e;
    
    float f = 0.0F;
    
    android.support.v4.content.e.b g;
    
    float h = 1.0F;
    
    int i = 0;
    
    float j = 1.0F;
    
    float k = 0.0F;
    
    float l = 1.0F;
    
    float m = 0.0F;
    
    Paint.Cap n = Paint.Cap.BUTT;
    
    Paint.Join o = Paint.Join.MITER;
    
    float p = 4.0F;
    
    public c() {}
    
    public c(c param1c) {
      super(param1c);
      this.d = param1c.d;
      this.e = param1c.e;
      this.f = param1c.f;
      this.h = param1c.h;
      this.g = param1c.g;
      this.i = param1c.i;
      this.j = param1c.j;
      this.k = param1c.k;
      this.l = param1c.l;
      this.m = param1c.m;
      this.n = param1c.n;
      this.o = param1c.o;
      this.p = param1c.p;
    }
    
    private Paint.Cap a(int param1Int, Paint.Cap param1Cap) {
      return (param1Int != 0) ? ((param1Int != 1) ? ((param1Int != 2) ? param1Cap : Paint.Cap.SQUARE) : Paint.Cap.ROUND) : Paint.Cap.BUTT;
    }
    
    private Paint.Join a(int param1Int, Paint.Join param1Join) {
      return (param1Int != 0) ? ((param1Int != 1) ? ((param1Int != 2) ? param1Join : Paint.Join.BEVEL) : Paint.Join.ROUND) : Paint.Join.MITER;
    }
    
    private void a(TypedArray param1TypedArray, XmlPullParser param1XmlPullParser, Resources.Theme param1Theme) {
      this.d = null;
      if (!android.support.v4.content.e.g.a(param1XmlPullParser, "pathData"))
        return; 
      String str = param1TypedArray.getString(0);
      if (str != null)
        this.b = str; 
      str = param1TypedArray.getString(2);
      if (str != null)
        this.a = a.b.g.a.b.a(str); 
      this.g = android.support.v4.content.e.g.a(param1TypedArray, param1XmlPullParser, param1Theme, "fillColor", 1, 0);
      this.j = android.support.v4.content.e.g.a(param1TypedArray, param1XmlPullParser, "fillAlpha", 12, this.j);
      this.n = a(android.support.v4.content.e.g.b(param1TypedArray, param1XmlPullParser, "strokeLineCap", 8, -1), this.n);
      this.o = a(android.support.v4.content.e.g.b(param1TypedArray, param1XmlPullParser, "strokeLineJoin", 9, -1), this.o);
      this.p = android.support.v4.content.e.g.a(param1TypedArray, param1XmlPullParser, "strokeMiterLimit", 10, this.p);
      this.e = android.support.v4.content.e.g.a(param1TypedArray, param1XmlPullParser, param1Theme, "strokeColor", 3, 0);
      this.h = android.support.v4.content.e.g.a(param1TypedArray, param1XmlPullParser, "strokeAlpha", 11, this.h);
      this.f = android.support.v4.content.e.g.a(param1TypedArray, param1XmlPullParser, "strokeWidth", 4, this.f);
      this.l = android.support.v4.content.e.g.a(param1TypedArray, param1XmlPullParser, "trimPathEnd", 6, this.l);
      this.m = android.support.v4.content.e.g.a(param1TypedArray, param1XmlPullParser, "trimPathOffset", 7, this.m);
      this.k = android.support.v4.content.e.g.a(param1TypedArray, param1XmlPullParser, "trimPathStart", 5, this.k);
      this.i = android.support.v4.content.e.g.b(param1TypedArray, param1XmlPullParser, "fillType", 13, this.i);
    }
    
    public void a(Resources param1Resources, AttributeSet param1AttributeSet, Resources.Theme param1Theme, XmlPullParser param1XmlPullParser) {
      TypedArray typedArray = android.support.v4.content.e.g.a(param1Resources, param1Theme, param1AttributeSet, a.c);
      a(typedArray, param1XmlPullParser, param1Theme);
      typedArray.recycle();
    }
    
    public boolean a() {
      return (this.g.d() || this.e.d());
    }
    
    public boolean a(int[] param1ArrayOfint) {
      return this.g.a(param1ArrayOfint) | this.e.a(param1ArrayOfint);
    }
    
    float getFillAlpha() {
      return this.j;
    }
    
    int getFillColor() {
      return this.g.a();
    }
    
    float getStrokeAlpha() {
      return this.h;
    }
    
    int getStrokeColor() {
      return this.e.a();
    }
    
    float getStrokeWidth() {
      return this.f;
    }
    
    float getTrimPathEnd() {
      return this.l;
    }
    
    float getTrimPathOffset() {
      return this.m;
    }
    
    float getTrimPathStart() {
      return this.k;
    }
    
    void setFillAlpha(float param1Float) {
      this.j = param1Float;
    }
    
    void setFillColor(int param1Int) {
      this.g.a(param1Int);
    }
    
    void setStrokeAlpha(float param1Float) {
      this.h = param1Float;
    }
    
    void setStrokeColor(int param1Int) {
      this.e.a(param1Int);
    }
    
    void setStrokeWidth(float param1Float) {
      this.f = param1Float;
    }
    
    void setTrimPathEnd(float param1Float) {
      this.l = param1Float;
    }
    
    void setTrimPathOffset(float param1Float) {
      this.m = param1Float;
    }
    
    void setTrimPathStart(float param1Float) {
      this.k = param1Float;
    }
  }
  
  private static class d extends e {
    final Matrix a = new Matrix();
    
    final ArrayList<i.e> b = new ArrayList<i.e>();
    
    float c = 0.0F;
    
    private float d = 0.0F;
    
    private float e = 0.0F;
    
    private float f = 1.0F;
    
    private float g = 1.0F;
    
    private float h = 0.0F;
    
    private float i = 0.0F;
    
    final Matrix j = new Matrix();
    
    int k;
    
    private int[] l;
    
    private String m = null;
    
    public d() {
      super(null);
    }
    
    public d(d param1d, a.b.g.g.a<String, Object> param1a) {
      super(null);
      this.c = param1d.c;
      this.d = param1d.d;
      this.e = param1d.e;
      this.f = param1d.f;
      this.g = param1d.g;
      this.h = param1d.h;
      this.i = param1d.i;
      this.l = param1d.l;
      this.m = param1d.m;
      this.k = param1d.k;
      String str = this.m;
      if (str != null)
        param1a.put(str, this); 
      this.j.set(param1d.j);
      ArrayList<i.e> arrayList = param1d.b;
      for (byte b = 0; b < arrayList.size(); b++) {
        param1d = (d)arrayList.get(b);
        if (param1d instanceof d) {
          param1d = param1d;
          this.b.add(new d(param1d, param1a));
        } else {
          i.c c;
          i.b b1;
          if (param1d instanceof i.c) {
            c = new i.c((i.c)param1d);
          } else if (c instanceof i.b) {
            b1 = new i.b((i.b)c);
          } else {
            throw new IllegalStateException("Unknown object in the tree!");
          } 
          this.b.add(b1);
          String str1 = b1.b;
          if (str1 != null)
            param1a.put(str1, b1); 
        } 
      } 
    }
    
    private void a(TypedArray param1TypedArray, XmlPullParser param1XmlPullParser) {
      this.l = null;
      this.c = android.support.v4.content.e.g.a(param1TypedArray, param1XmlPullParser, "rotation", 5, this.c);
      this.d = param1TypedArray.getFloat(1, this.d);
      this.e = param1TypedArray.getFloat(2, this.e);
      this.f = android.support.v4.content.e.g.a(param1TypedArray, param1XmlPullParser, "scaleX", 3, this.f);
      this.g = android.support.v4.content.e.g.a(param1TypedArray, param1XmlPullParser, "scaleY", 4, this.g);
      this.h = android.support.v4.content.e.g.a(param1TypedArray, param1XmlPullParser, "translateX", 6, this.h);
      this.i = android.support.v4.content.e.g.a(param1TypedArray, param1XmlPullParser, "translateY", 7, this.i);
      String str = param1TypedArray.getString(0);
      if (str != null)
        this.m = str; 
      b();
    }
    
    private void b() {
      this.j.reset();
      this.j.postTranslate(-this.d, -this.e);
      this.j.postScale(this.f, this.g);
      this.j.postRotate(this.c, 0.0F, 0.0F);
      this.j.postTranslate(this.h + this.d, this.i + this.e);
    }
    
    public void a(Resources param1Resources, AttributeSet param1AttributeSet, Resources.Theme param1Theme, XmlPullParser param1XmlPullParser) {
      TypedArray typedArray = android.support.v4.content.e.g.a(param1Resources, param1Theme, param1AttributeSet, a.b);
      a(typedArray, param1XmlPullParser);
      typedArray.recycle();
    }
    
    public boolean a() {
      for (byte b = 0; b < this.b.size(); b++) {
        if (((i.e)this.b.get(b)).a())
          return true; 
      } 
      return false;
    }
    
    public boolean a(int[] param1ArrayOfint) {
      boolean bool = false;
      for (byte b = 0; b < this.b.size(); b++)
        bool |= ((i.e)this.b.get(b)).a(param1ArrayOfint); 
      return bool;
    }
    
    public String getGroupName() {
      return this.m;
    }
    
    public Matrix getLocalMatrix() {
      return this.j;
    }
    
    public float getPivotX() {
      return this.d;
    }
    
    public float getPivotY() {
      return this.e;
    }
    
    public float getRotation() {
      return this.c;
    }
    
    public float getScaleX() {
      return this.f;
    }
    
    public float getScaleY() {
      return this.g;
    }
    
    public float getTranslateX() {
      return this.h;
    }
    
    public float getTranslateY() {
      return this.i;
    }
    
    public void setPivotX(float param1Float) {
      if (param1Float != this.d) {
        this.d = param1Float;
        b();
      } 
    }
    
    public void setPivotY(float param1Float) {
      if (param1Float != this.e) {
        this.e = param1Float;
        b();
      } 
    }
    
    public void setRotation(float param1Float) {
      if (param1Float != this.c) {
        this.c = param1Float;
        b();
      } 
    }
    
    public void setScaleX(float param1Float) {
      if (param1Float != this.f) {
        this.f = param1Float;
        b();
      } 
    }
    
    public void setScaleY(float param1Float) {
      if (param1Float != this.g) {
        this.g = param1Float;
        b();
      } 
    }
    
    public void setTranslateX(float param1Float) {
      if (param1Float != this.h) {
        this.h = param1Float;
        b();
      } 
    }
    
    public void setTranslateY(float param1Float) {
      if (param1Float != this.i) {
        this.i = param1Float;
        b();
      } 
    }
  }
  
  private static abstract class e {
    private e() {}
    
    public boolean a() {
      return false;
    }
    
    public boolean a(int[] param1ArrayOfint) {
      return false;
    }
  }
  
  private static abstract class f extends e {
    protected a.b.g.a.b.b[] a = null;
    
    String b;
    
    int c;
    
    public f() {
      super(null);
    }
    
    public f(f param1f) {
      super(null);
      this.b = param1f.b;
      this.c = param1f.c;
      this.a = a.b.g.a.b.a(param1f.a);
    }
    
    public void a(Path param1Path) {
      param1Path.reset();
      a.b.g.a.b.b[] arrayOfB = this.a;
      if (arrayOfB != null)
        a.b.g.a.b.b.a(arrayOfB, param1Path); 
    }
    
    public boolean b() {
      return false;
    }
    
    public a.b.g.a.b.b[] getPathData() {
      return this.a;
    }
    
    public String getPathName() {
      return this.b;
    }
    
    public void setPathData(a.b.g.a.b.b[] param1ArrayOfb) {
      if (!a.b.g.a.b.a(this.a, param1ArrayOfb)) {
        this.a = a.b.g.a.b.a(param1ArrayOfb);
      } else {
        a.b.g.a.b.b(this.a, param1ArrayOfb);
      } 
    }
  }
  
  private static class g {
    private static final Matrix q = new Matrix();
    
    private final Path a = new Path();
    
    private final Path b = new Path();
    
    private final Matrix c = new Matrix();
    
    Paint d;
    
    Paint e;
    
    private PathMeasure f;
    
    private int g;
    
    final i.d h = new i.d();
    
    float i = 0.0F;
    
    float j = 0.0F;
    
    float k = 0.0F;
    
    float l = 0.0F;
    
    int m = 255;
    
    String n = null;
    
    Boolean o = null;
    
    final a.b.g.g.a<String, Object> p = new a.b.g.g.a();
    
    public g() {}
    
    public g(g param1g) {
      this.i = param1g.i;
      this.j = param1g.j;
      this.k = param1g.k;
      this.l = param1g.l;
      this.g = param1g.g;
      this.m = param1g.m;
      this.n = param1g.n;
      String str = param1g.n;
      if (str != null)
        this.p.put(str, this); 
      this.o = param1g.o;
    }
    
    private static float a(float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
      return param1Float1 * param1Float4 - param1Float2 * param1Float3;
    }
    
    private float a(Matrix param1Matrix) {
      float[] arrayOfFloat = new float[4];
      arrayOfFloat[0] = 0.0F;
      arrayOfFloat[1] = 1.0F;
      arrayOfFloat[2] = 1.0F;
      arrayOfFloat[3] = 0.0F;
      param1Matrix.mapVectors(arrayOfFloat);
      float f3 = (float)Math.hypot(arrayOfFloat[0], arrayOfFloat[1]);
      float f1 = (float)Math.hypot(arrayOfFloat[2], arrayOfFloat[3]);
      float f2 = a(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2], arrayOfFloat[3]);
      f3 = Math.max(f3, f1);
      f1 = 0.0F;
      if (f3 > 0.0F)
        f1 = Math.abs(f2) / f3; 
      return f1;
    }
    
    private void a(i.d param1d, i.f param1f, Canvas param1Canvas, int param1Int1, int param1Int2, ColorFilter param1ColorFilter) {
      float f2 = param1Int1 / this.k;
      float f3 = param1Int2 / this.l;
      float f1 = Math.min(f2, f3);
      Matrix matrix = param1d.a;
      this.c.set(matrix);
      this.c.postScale(f2, f3);
      f2 = a(matrix);
      if (f2 == 0.0F)
        return; 
      param1f.a(this.a);
      Path path = this.a;
      this.b.reset();
      if (param1f.b()) {
        this.b.addPath(path, this.c);
        param1Canvas.clipPath(this.b);
      } else {
        param1f = param1f;
        if (((i.c)param1f).k != 0.0F || ((i.c)param1f).l != 1.0F) {
          float f4 = ((i.c)param1f).k;
          float f6 = ((i.c)param1f).m;
          float f5 = ((i.c)param1f).l;
          if (this.f == null)
            this.f = new PathMeasure(); 
          this.f.setPath(this.a, false);
          f3 = this.f.getLength();
          f4 = (f4 + f6) % 1.0F * f3;
          f5 = (f5 + f6) % 1.0F * f3;
          path.reset();
          if (f4 > f5) {
            this.f.getSegment(f4, f3, path, true);
            this.f.getSegment(0.0F, f5, path, true);
          } else {
            this.f.getSegment(f4, f5, path, true);
          } 
          path.rLineTo(0.0F, 0.0F);
        } 
        this.b.addPath(path, this.c);
        if (((i.c)param1f).g.e()) {
          Shader shader;
          Path.FillType fillType;
          android.support.v4.content.e.b b = ((i.c)param1f).g;
          if (this.e == null) {
            this.e = new Paint(1);
            this.e.setStyle(Paint.Style.FILL);
          } 
          Paint paint = this.e;
          if (b.c()) {
            shader = b.b();
            shader.setLocalMatrix(this.c);
            paint.setShader(shader);
            paint.setAlpha(Math.round(((i.c)param1f).j * 255.0F));
          } else {
            paint.setColor(i.a(shader.a(), ((i.c)param1f).j));
          } 
          paint.setColorFilter(param1ColorFilter);
          Path path1 = this.b;
          if (((i.c)param1f).i == 0) {
            fillType = Path.FillType.WINDING;
          } else {
            fillType = Path.FillType.EVEN_ODD;
          } 
          path1.setFillType(fillType);
          param1Canvas.drawPath(this.b, paint);
        } 
        if (((i.c)param1f).e.e()) {
          Shader shader;
          android.support.v4.content.e.b b = ((i.c)param1f).e;
          if (this.d == null) {
            this.d = new Paint(1);
            this.d.setStyle(Paint.Style.STROKE);
          } 
          Paint paint = this.d;
          Paint.Join join = ((i.c)param1f).o;
          if (join != null)
            paint.setStrokeJoin(join); 
          Paint.Cap cap = ((i.c)param1f).n;
          if (cap != null)
            paint.setStrokeCap(cap); 
          paint.setStrokeMiter(((i.c)param1f).p);
          if (b.c()) {
            shader = b.b();
            shader.setLocalMatrix(this.c);
            paint.setShader(shader);
            paint.setAlpha(Math.round(((i.c)param1f).h * 255.0F));
          } else {
            paint.setColor(i.a(shader.a(), ((i.c)param1f).h));
          } 
          paint.setColorFilter(param1ColorFilter);
          paint.setStrokeWidth(((i.c)param1f).f * f1 * f2);
          param1Canvas.drawPath(this.b, paint);
        } 
      } 
    }
    
    private void a(i.d param1d, Matrix param1Matrix, Canvas param1Canvas, int param1Int1, int param1Int2, ColorFilter param1ColorFilter) {
      param1d.a.set(param1Matrix);
      param1d.a.preConcat(param1d.j);
      param1Canvas.save();
      for (byte b = 0; b < param1d.b.size(); b++) {
        i.e e = param1d.b.get(b);
        if (e instanceof i.d) {
          a((i.d)e, param1d.a, param1Canvas, param1Int1, param1Int2, param1ColorFilter);
        } else if (e instanceof i.f) {
          a(param1d, (i.f)e, param1Canvas, param1Int1, param1Int2, param1ColorFilter);
        } 
      } 
      param1Canvas.restore();
    }
    
    public void a(Canvas param1Canvas, int param1Int1, int param1Int2, ColorFilter param1ColorFilter) {
      a(this.h, q, param1Canvas, param1Int1, param1Int2, param1ColorFilter);
    }
    
    public boolean a() {
      if (this.o == null)
        this.o = Boolean.valueOf(this.h.a()); 
      return this.o.booleanValue();
    }
    
    public boolean a(int[] param1ArrayOfint) {
      return this.h.a(param1ArrayOfint);
    }
    
    public float getAlpha() {
      return getRootAlpha() / 255.0F;
    }
    
    public int getRootAlpha() {
      return this.m;
    }
    
    public void setAlpha(float param1Float) {
      setRootAlpha((int)(255.0F * param1Float));
    }
    
    public void setRootAlpha(int param1Int) {
      this.m = param1Int;
    }
  }
  
  private static class h extends Drawable.ConstantState {
    int a;
    
    i.g b;
    
    ColorStateList c = null;
    
    PorterDuff.Mode d = i.l;
    
    boolean e;
    
    Bitmap f;
    
    ColorStateList g;
    
    PorterDuff.Mode h;
    
    int i;
    
    boolean j;
    
    boolean k;
    
    Paint l;
    
    public h() {
      this.b = new i.g();
    }
    
    public h(h param1h) {
      if (param1h != null) {
        this.a = param1h.a;
        this.b = new i.g(param1h.b);
        Paint paint = param1h.b.e;
        if (paint != null)
          this.b.e = new Paint(paint); 
        paint = param1h.b.d;
        if (paint != null)
          this.b.d = new Paint(paint); 
        this.c = param1h.c;
        this.d = param1h.d;
        this.e = param1h.e;
      } 
    }
    
    public Paint a(ColorFilter param1ColorFilter) {
      if (!b() && param1ColorFilter == null)
        return null; 
      if (this.l == null) {
        this.l = new Paint();
        this.l.setFilterBitmap(true);
      } 
      this.l.setAlpha(this.b.getRootAlpha());
      this.l.setColorFilter(param1ColorFilter);
      return this.l;
    }
    
    public void a(Canvas param1Canvas, ColorFilter param1ColorFilter, Rect param1Rect) {
      Paint paint = a(param1ColorFilter);
      param1Canvas.drawBitmap(this.f, null, param1Rect, paint);
    }
    
    public boolean a() {
      return (!this.k && this.g == this.c && this.h == this.d && this.j == this.e && this.i == this.b.getRootAlpha());
    }
    
    public boolean a(int param1Int1, int param1Int2) {
      return (param1Int1 == this.f.getWidth() && param1Int2 == this.f.getHeight());
    }
    
    public boolean a(int[] param1ArrayOfint) {
      boolean bool = this.b.a(param1ArrayOfint);
      this.k |= bool;
      return bool;
    }
    
    public void b(int param1Int1, int param1Int2) {
      if (this.f == null || !a(param1Int1, param1Int2)) {
        this.f = Bitmap.createBitmap(param1Int1, param1Int2, Bitmap.Config.ARGB_8888);
        this.k = true;
      } 
    }
    
    public boolean b() {
      boolean bool;
      if (this.b.getRootAlpha() < 255) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public void c(int param1Int1, int param1Int2) {
      this.f.eraseColor(0);
      Canvas canvas = new Canvas(this.f);
      this.b.a(canvas, param1Int1, param1Int2, (ColorFilter)null);
    }
    
    public boolean c() {
      return this.b.a();
    }
    
    public void d() {
      this.g = this.c;
      this.h = this.d;
      this.i = this.b.getRootAlpha();
      this.j = this.e;
      this.k = false;
    }
    
    public int getChangingConfigurations() {
      return this.a;
    }
    
    public Drawable newDrawable() {
      return new i(this);
    }
    
    public Drawable newDrawable(Resources param1Resources) {
      return new i(this);
    }
  }
  
  private static class i extends Drawable.ConstantState {
    private final Drawable.ConstantState a;
    
    public i(Drawable.ConstantState param1ConstantState) {
      this.a = param1ConstantState;
    }
    
    public boolean canApplyTheme() {
      return this.a.canApplyTheme();
    }
    
    public int getChangingConfigurations() {
      return this.a.getChangingConfigurations();
    }
    
    public Drawable newDrawable() {
      i i1 = new i();
      i1.c = this.a.newDrawable();
      return i1;
    }
    
    public Drawable newDrawable(Resources param1Resources) {
      i i1 = new i();
      i1.c = this.a.newDrawable(param1Resources);
      return i1;
    }
    
    public Drawable newDrawable(Resources param1Resources, Resources.Theme param1Theme) {
      i i1 = new i();
      i1.c = this.a.newDrawable(param1Resources, param1Theme);
      return i1;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\d\a\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */