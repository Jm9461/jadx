package a.b.g.a;

import a.b.g.e.b;
import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

class d extends h {
  private File a(ParcelFileDescriptor paramParcelFileDescriptor) {
    try {
      StringBuilder stringBuilder = new StringBuilder();
      this();
      stringBuilder.append("/proc/self/fd/");
      stringBuilder.append(paramParcelFileDescriptor.getFd());
      String str = Os.readlink(stringBuilder.toString());
      return OsConstants.S_ISREG((Os.stat(str)).st_mode) ? new File(str) : null;
    } catch (ErrnoException errnoException) {
      return null;
    } 
  }
  
  public Typeface a(Context paramContext, CancellationSignal paramCancellationSignal, b.f[] paramArrayOff, int paramInt) {
    if (paramArrayOff.length < 1)
      return null; 
    b.f f1 = a(paramArrayOff, paramInt);
    ContentResolver contentResolver = paramContext.getContentResolver();
    try {
      ParcelFileDescriptor parcelFileDescriptor = contentResolver.openFileDescriptor(f1.c(), "r", paramCancellationSignal);
      try {
        FileInputStream fileInputStream;
        File file = a(parcelFileDescriptor);
        if (file == null || !file.canRead()) {
          fileInputStream = new FileInputStream();
          this(parcelFileDescriptor.getFileDescriptor());
          try {
            return a(paramContext, fileInputStream);
          } finally {
            paramContext = null;
          } 
        } 
        return Typeface.createFromFile((File)fileInputStream);
      } finally {
        paramContext = null;
      } 
    } catch (IOException iOException) {
      return null;
    } 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\a\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */