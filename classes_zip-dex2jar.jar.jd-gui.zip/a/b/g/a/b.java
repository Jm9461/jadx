package a.b.g.a;

import android.graphics.Path;
import android.util.Log;
import java.util.ArrayList;

public class b {
  private static int a(String paramString, int paramInt) {
    while (paramInt < paramString.length()) {
      char c = paramString.charAt(paramInt);
      if (((c - 65) * (c - 90) <= 0 || (c - 97) * (c - 122) <= 0) && c != 'e' && c != 'E')
        return paramInt; 
      paramInt++;
    } 
    return paramInt;
  }
  
  private static void a(String paramString, int paramInt, a parama) {
    int i = paramInt;
    char c = Character.MIN_VALUE;
    parama.b = false;
    boolean bool1 = false;
    boolean bool2 = false;
    while (i < paramString.length()) {
      boolean bool = false;
      char c1 = paramString.charAt(i);
      if (c1 != ' ') {
        boolean bool3;
        boolean bool4;
        if (c1 != 'E' && c1 != 'e') {
          switch (c1) {
            default:
              c1 = c;
              bool4 = bool1;
              bool3 = bool;
              break;
            case '.':
              if (!bool1) {
                bool4 = true;
                c1 = c;
                bool3 = bool;
                break;
              } 
              c1 = '\001';
              parama.b = true;
              bool4 = bool1;
              bool3 = bool;
              break;
            case '-':
              c1 = c;
              bool4 = bool1;
              bool3 = bool;
              if (i != paramInt) {
                c1 = c;
                bool4 = bool1;
                bool3 = bool;
                if (!bool2) {
                  c1 = '\001';
                  parama.b = true;
                  bool4 = bool1;
                  bool3 = bool;
                } 
              } 
              break;
            case ',':
              c1 = '\001';
              bool3 = bool;
              bool4 = bool1;
              break;
          } 
        } else {
          bool3 = true;
          c1 = c;
          bool4 = bool1;
        } 
        if (c1 != '\000')
          break; 
        i++;
        c = c1;
        bool1 = bool4;
        bool2 = bool3;
      } 
    } 
    parama.a = i;
  }
  
  private static void a(ArrayList<b> paramArrayList, char paramChar, float[] paramArrayOffloat) {
    paramArrayList.add(new b(paramChar, paramArrayOffloat));
  }
  
  public static boolean a(b[] paramArrayOfb1, b[] paramArrayOfb2) {
    if (paramArrayOfb1 == null || paramArrayOfb2 == null)
      return false; 
    if (paramArrayOfb1.length != paramArrayOfb2.length)
      return false; 
    for (byte b1 = 0; b1 < paramArrayOfb1.length; b1++) {
      if ((paramArrayOfb1[b1]).a != (paramArrayOfb2[b1]).a || (paramArrayOfb1[b1]).b.length != (paramArrayOfb2[b1]).b.length)
        return false; 
    } 
    return true;
  }
  
  static float[] a(float[] paramArrayOffloat, int paramInt1, int paramInt2) {
    if (paramInt1 <= paramInt2) {
      int i = paramArrayOffloat.length;
      if (paramInt1 >= 0 && paramInt1 <= i) {
        paramInt2 -= paramInt1;
        i = Math.min(paramInt2, i - paramInt1);
        float[] arrayOfFloat = new float[paramInt2];
        System.arraycopy(paramArrayOffloat, paramInt1, arrayOfFloat, 0, i);
        return arrayOfFloat;
      } 
      throw new ArrayIndexOutOfBoundsException();
    } 
    throw new IllegalArgumentException();
  }
  
  public static b[] a(String paramString) {
    if (paramString == null)
      return null; 
    int i = 0;
    int j = 1;
    ArrayList<b> arrayList = new ArrayList();
    while (j < paramString.length()) {
      j = a(paramString, j);
      String str = paramString.substring(i, j).trim();
      if (str.length() > 0) {
        float[] arrayOfFloat = c(str);
        a(arrayList, str.charAt(0), arrayOfFloat);
      } 
      i = j;
      j++;
    } 
    if (j - i == 1 && i < paramString.length())
      a(arrayList, paramString.charAt(i), new float[0]); 
    return arrayList.<b>toArray(new b[arrayList.size()]);
  }
  
  public static b[] a(b[] paramArrayOfb) {
    if (paramArrayOfb == null)
      return null; 
    b[] arrayOfB = new b[paramArrayOfb.length];
    for (byte b1 = 0; b1 < paramArrayOfb.length; b1++)
      arrayOfB[b1] = new b(paramArrayOfb[b1]); 
    return arrayOfB;
  }
  
  public static Path b(String paramString) {
    Path path = new Path();
    b[] arrayOfB = a(paramString);
    if (arrayOfB != null)
      try {
        b.a(arrayOfB, path);
        return path;
      } catch (RuntimeException runtimeException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Error in parsing ");
        stringBuilder.append(paramString);
        throw new RuntimeException(stringBuilder.toString(), runtimeException);
      }  
    return null;
  }
  
  public static void b(b[] paramArrayOfb1, b[] paramArrayOfb2) {
    for (byte b1 = 0; b1 < paramArrayOfb2.length; b1++) {
      (paramArrayOfb1[b1]).a = (paramArrayOfb2[b1]).a;
      for (byte b2 = 0; b2 < (paramArrayOfb2[b1]).b.length; b2++)
        (paramArrayOfb1[b1]).b[b2] = (paramArrayOfb2[b1]).b[b2]; 
    } 
  }
  
  private static float[] c(String paramString) {
    if (paramString.charAt(0) == 'z' || paramString.charAt(0) == 'Z')
      return new float[0]; 
    try {
      float[] arrayOfFloat = new float[paramString.length()];
      int j = 0;
      int i = 1;
      a a = new a();
      this();
      int k = paramString.length();
      while (i < k) {
        a(paramString, i, a);
        int n = a.a;
        int m = j;
        if (i < n) {
          arrayOfFloat[j] = Float.parseFloat(paramString.substring(i, n));
          m = j + 1;
        } 
        if (a.b) {
          i = n;
          j = m;
          continue;
        } 
        i = n + 1;
        j = m;
      } 
      return a(arrayOfFloat, 0, j);
    } catch (NumberFormatException numberFormatException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("error in parsing \"");
      stringBuilder.append(paramString);
      stringBuilder.append("\"");
      throw new RuntimeException(stringBuilder.toString(), numberFormatException);
    } 
  }
  
  private static class a {
    int a;
    
    boolean b;
  }
  
  public static class b {
    public char a;
    
    public float[] b;
    
    b(char param1Char, float[] param1ArrayOffloat) {
      this.a = param1Char;
      this.b = param1ArrayOffloat;
    }
    
    b(b param1b) {
      this.a = param1b.a;
      float[] arrayOfFloat = param1b.b;
      this.b = b.a(arrayOfFloat, 0, arrayOfFloat.length);
    }
    
    private static void a(Path param1Path, double param1Double1, double param1Double2, double param1Double3, double param1Double4, double param1Double5, double param1Double6, double param1Double7, double param1Double8, double param1Double9) {
      int i = (int)Math.ceil(Math.abs(param1Double9 * 4.0D / Math.PI));
      double d6 = Math.cos(param1Double7);
      param1Double7 = Math.sin(param1Double7);
      double d8 = Math.cos(param1Double8);
      double d2 = Math.sin(param1Double8);
      double d3 = -param1Double3;
      double d1 = -param1Double3;
      double d4 = i;
      Double.isNaN(d4);
      double d7 = param1Double9 / d4;
      d3 = d3 * d6 * d2 - param1Double4 * param1Double7 * d8;
      d1 = d1 * param1Double7 * d2 + param1Double4 * d6 * d8;
      byte b1 = 0;
      double d5 = param1Double8;
      d4 = param1Double6;
      param1Double9 = param1Double5;
      param1Double6 = d8;
      param1Double5 = param1Double7;
      param1Double7 = d6;
      param1Double8 = d7;
      while (b1 < i) {
        double d10 = d5 + param1Double8;
        double d11 = Math.sin(d10);
        d8 = Math.cos(d10);
        double d9 = param1Double1 + param1Double3 * param1Double7 * d8 - param1Double4 * param1Double5 * d11;
        d7 = param1Double2 + param1Double3 * param1Double5 * d8 + param1Double4 * param1Double7 * d11;
        d6 = -param1Double3 * param1Double7 * d11 - param1Double4 * param1Double5 * d8;
        d8 = -param1Double3 * param1Double5 * d11 + param1Double4 * param1Double7 * d8;
        d11 = Math.tan((d10 - d5) / 2.0D);
        d5 = Math.sin(d10 - d5) * (Math.sqrt(d11 * 3.0D * d11 + 4.0D) - 1.0D) / 3.0D;
        param1Path.rLineTo(0.0F, 0.0F);
        param1Path.cubicTo((float)(param1Double9 + d5 * d3), (float)(d4 + d5 * d1), (float)(d9 - d5 * d6), (float)(d7 - d5 * d8), (float)d9, (float)d7);
        d5 = d10;
        param1Double9 = d9;
        d4 = d7;
        d3 = d6;
        d1 = d8;
        b1++;
      } 
    }
    
    private static void a(Path param1Path, float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6, float param1Float7, boolean param1Boolean1, boolean param1Boolean2) {
      double d6 = Math.toRadians(param1Float7);
      double d5 = Math.cos(d6);
      double d7 = Math.sin(d6);
      double d1 = param1Float1;
      Double.isNaN(d1);
      double d3 = param1Float2;
      Double.isNaN(d3);
      double d2 = param1Float5;
      Double.isNaN(d2);
      d1 = (d1 * d5 + d3 * d7) / d2;
      d3 = -param1Float1;
      Double.isNaN(d3);
      double d4 = param1Float2;
      Double.isNaN(d4);
      d2 = param1Float6;
      Double.isNaN(d2);
      d4 = (d3 * d7 + d4 * d5) / d2;
      d2 = param1Float3;
      Double.isNaN(d2);
      d3 = param1Float4;
      Double.isNaN(d3);
      double d8 = param1Float5;
      Double.isNaN(d8);
      d8 = (d2 * d5 + d3 * d7) / d8;
      d2 = -param1Float3;
      Double.isNaN(d2);
      double d9 = param1Float4;
      Double.isNaN(d9);
      d3 = param1Float6;
      Double.isNaN(d3);
      d9 = (d2 * d7 + d9 * d5) / d3;
      double d10 = d1 - d8;
      double d11 = d4 - d9;
      d3 = (d1 + d8) / 2.0D;
      d2 = (d4 + d9) / 2.0D;
      double d13 = d10 * d10 + d11 * d11;
      if (d13 == 0.0D) {
        Log.w("PathParser", " Points are coincident");
        return;
      } 
      double d12 = 1.0D / d13 - 0.25D;
      if (d12 < 0.0D) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Points are too far apart ");
        stringBuilder.append(d13);
        Log.w("PathParser", stringBuilder.toString());
        float f = (float)(Math.sqrt(d13) / 1.99999D);
        a(param1Path, param1Float1, param1Float2, param1Float3, param1Float4, param1Float5 * f, param1Float6 * f, param1Float7, param1Boolean1, param1Boolean2);
        return;
      } 
      d12 = Math.sqrt(d12);
      d10 = d12 * d10;
      d11 = d12 * d11;
      if (param1Boolean1 == param1Boolean2) {
        d3 -= d11;
        d2 += d10;
      } else {
        d3 += d11;
        d2 -= d10;
      } 
      d10 = Math.atan2(d4 - d2, d1 - d3);
      d4 = Math.atan2(d9 - d2, d8 - d3) - d10;
      if (d4 >= 0.0D) {
        param1Boolean1 = true;
      } else {
        param1Boolean1 = false;
      } 
      d1 = d4;
      if (param1Boolean2 != param1Boolean1)
        if (d4 > 0.0D) {
          d1 = d4 - 6.283185307179586D;
        } else {
          d1 = d4 + 6.283185307179586D;
        }  
      d4 = param1Float5;
      Double.isNaN(d4);
      d3 *= d4;
      d4 = param1Float6;
      Double.isNaN(d4);
      d2 = d4 * d2;
      a(param1Path, d3 * d5 - d2 * d7, d3 * d7 + d2 * d5, param1Float5, param1Float6, param1Float1, param1Float2, d6, d10, d1);
    }
    
    private static void a(Path param1Path, float[] param1ArrayOffloat1, char param1Char1, char param1Char2, float[] param1ArrayOffloat2) {
      byte b1;
      float f6 = param1ArrayOffloat1[0];
      float f5 = param1ArrayOffloat1[1];
      float f4 = param1ArrayOffloat1[2];
      float f3 = param1ArrayOffloat1[3];
      float f2 = param1ArrayOffloat1[4];
      float f1 = param1ArrayOffloat1[5];
      switch (param1Char2) {
        default:
          b1 = 2;
          break;
        case 'Z':
        case 'z':
          param1Path.close();
          f6 = f2;
          f5 = f1;
          f4 = f2;
          f3 = f1;
          param1Path.moveTo(f6, f5);
          b1 = 2;
          break;
        case 'Q':
        case 'S':
        case 'q':
        case 's':
          b1 = 4;
          break;
        case 'L':
        case 'M':
        case 'T':
        case 'l':
        case 'm':
        case 't':
          b1 = 2;
          break;
        case 'H':
        case 'V':
        case 'h':
        case 'v':
          b1 = 1;
          break;
        case 'C':
        case 'c':
          b1 = 6;
          break;
        case 'A':
        case 'a':
          b1 = 7;
          break;
      } 
      boolean bool = false;
      float f9 = f6;
      float f10 = f5;
      char c = param1Char1;
      f6 = f1;
      f5 = f2;
      float f7 = f3;
      float f8 = f4;
      param1Char1 = bool;
      f2 = f9;
      f1 = f10;
      while (param1Char1 < param1ArrayOffloat2.length) {
        if (param1Char2 != 'A') {
          if (param1Char2 != 'C') {
            if (param1Char2 != 'H') {
              if (param1Char2 != 'Q') {
                if (param1Char2 != 'V') {
                  if (param1Char2 != 'a') {
                    if (param1Char2 != 'c') {
                      if (param1Char2 != 'h') {
                        if (param1Char2 != 'q') {
                          if (param1Char2 != 'v') {
                            if (param1Char2 != 'L') {
                              if (param1Char2 != 'M') {
                                if (param1Char2 != 'S') {
                                  if (param1Char2 != 'T') {
                                    if (param1Char2 != 'l') {
                                      if (param1Char2 != 'm') {
                                        if (param1Char2 != 's') {
                                          if (param1Char2 != 't') {
                                            f3 = f8;
                                            f4 = f7;
                                          } else {
                                            f4 = 0.0F;
                                            f3 = 0.0F;
                                            if (c == 'q' || c == 't' || c == 'Q' || c == 'T') {
                                              f4 = f2 - f8;
                                              f3 = f1 - f7;
                                            } 
                                            param1Path.rQuadTo(f4, f3, param1ArrayOffloat2[param1Char1 + 0], param1ArrayOffloat2[param1Char1 + 1]);
                                            f7 = f2 + param1ArrayOffloat2[param1Char1 + 0];
                                            f8 = f1 + param1ArrayOffloat2[param1Char1 + 1];
                                            f4 = f2 + f4;
                                            f9 = f1 + f3;
                                            f1 = f8;
                                            f2 = f7;
                                            f3 = f4;
                                            f4 = f9;
                                          } 
                                        } else {
                                          if (c == 'c' || c == 's' || c == 'C' || c == 'S') {
                                            f3 = f2 - f8;
                                            f4 = f1 - f7;
                                          } else {
                                            f3 = 0.0F;
                                            f4 = 0.0F;
                                          } 
                                          param1Path.rCubicTo(f3, f4, param1ArrayOffloat2[param1Char1 + 0], param1ArrayOffloat2[param1Char1 + 1], param1ArrayOffloat2[param1Char1 + 2], param1ArrayOffloat2[param1Char1 + 3]);
                                          f7 = param1ArrayOffloat2[param1Char1 + 0];
                                          f8 = param1ArrayOffloat2[param1Char1 + 1];
                                          f3 = f2 + param1ArrayOffloat2[param1Char1 + 2];
                                          f4 = f1 + param1ArrayOffloat2[param1Char1 + 3];
                                          f7 += f2;
                                          f8 += f1;
                                          f1 = f4;
                                          f2 = f3;
                                          f3 = f7;
                                          f4 = f8;
                                        } 
                                      } else {
                                        f2 += param1ArrayOffloat2[param1Char1 + 0];
                                        f1 += param1ArrayOffloat2[param1Char1 + 1];
                                        if (param1Char1 > '\000') {
                                          param1Path.rLineTo(param1ArrayOffloat2[param1Char1 + 0], param1ArrayOffloat2[param1Char1 + 1]);
                                          f3 = f8;
                                          f4 = f7;
                                        } else {
                                          param1Path.rMoveTo(param1ArrayOffloat2[param1Char1 + 0], param1ArrayOffloat2[param1Char1 + 1]);
                                          f5 = f2;
                                          f6 = f1;
                                          f3 = f8;
                                          f4 = f7;
                                        } 
                                      } 
                                    } else {
                                      param1Path.rLineTo(param1ArrayOffloat2[param1Char1 + 0], param1ArrayOffloat2[param1Char1 + 1]);
                                      f2 += param1ArrayOffloat2[param1Char1 + 0];
                                      f1 += param1ArrayOffloat2[param1Char1 + 1];
                                      f3 = f8;
                                      f4 = f7;
                                    } 
                                  } else {
                                    f4 = f2;
                                    f3 = f1;
                                    if (c == 'q' || c == 't' || c == 'Q' || c == 'T') {
                                      f4 = f2 * 2.0F - f8;
                                      f3 = 2.0F * f1 - f7;
                                    } 
                                    param1Path.quadTo(f4, f3, param1ArrayOffloat2[param1Char1 + 0], param1ArrayOffloat2[param1Char1 + 1]);
                                    f2 = param1ArrayOffloat2[param1Char1 + 0];
                                    f1 = param1ArrayOffloat2[param1Char1 + 1];
                                    f7 = f3;
                                    f3 = f4;
                                    f4 = f7;
                                  } 
                                } else {
                                  if (c == 'c' || c == 's' || c == 'C' || c == 'S') {
                                    f2 = f2 * 2.0F - f8;
                                    f1 = 2.0F * f1 - f7;
                                  } 
                                  param1Path.cubicTo(f2, f1, param1ArrayOffloat2[param1Char1 + 0], param1ArrayOffloat2[param1Char1 + 1], param1ArrayOffloat2[param1Char1 + 2], param1ArrayOffloat2[param1Char1 + 3]);
                                  f3 = param1ArrayOffloat2[param1Char1 + 0];
                                  f4 = param1ArrayOffloat2[param1Char1 + 1];
                                  f2 = param1ArrayOffloat2[param1Char1 + 2];
                                  f1 = param1ArrayOffloat2[param1Char1 + 3];
                                } 
                              } else {
                                f2 = param1ArrayOffloat2[param1Char1 + 0];
                                f1 = param1ArrayOffloat2[param1Char1 + 1];
                                if (param1Char1 > '\000') {
                                  param1Path.lineTo(param1ArrayOffloat2[param1Char1 + 0], param1ArrayOffloat2[param1Char1 + 1]);
                                  f3 = f8;
                                  f4 = f7;
                                } else {
                                  param1Path.moveTo(param1ArrayOffloat2[param1Char1 + 0], param1ArrayOffloat2[param1Char1 + 1]);
                                  f5 = f2;
                                  f6 = f1;
                                  f3 = f8;
                                  f4 = f7;
                                } 
                              } 
                            } else {
                              param1Path.lineTo(param1ArrayOffloat2[param1Char1 + 0], param1ArrayOffloat2[param1Char1 + 1]);
                              f2 = param1ArrayOffloat2[param1Char1 + 0];
                              f1 = param1ArrayOffloat2[param1Char1 + 1];
                              f3 = f8;
                              f4 = f7;
                            } 
                          } else {
                            param1Path.rLineTo(0.0F, param1ArrayOffloat2[param1Char1 + 0]);
                            f1 += param1ArrayOffloat2[param1Char1 + 0];
                            f3 = f8;
                            f4 = f7;
                          } 
                        } else {
                          param1Path.rQuadTo(param1ArrayOffloat2[param1Char1 + 0], param1ArrayOffloat2[param1Char1 + 1], param1ArrayOffloat2[param1Char1 + 2], param1ArrayOffloat2[param1Char1 + 3]);
                          f4 = param1ArrayOffloat2[param1Char1 + 0];
                          f8 = param1ArrayOffloat2[param1Char1 + 1];
                          f3 = f2 + param1ArrayOffloat2[param1Char1 + 2];
                          f7 = f1 + param1ArrayOffloat2[param1Char1 + 3];
                          f4 += f2;
                          f8 += f1;
                          f1 = f7;
                          f2 = f3;
                          f3 = f4;
                          f4 = f8;
                        } 
                      } else {
                        param1Path.rLineTo(param1ArrayOffloat2[param1Char1 + 0], 0.0F);
                        f2 += param1ArrayOffloat2[param1Char1 + 0];
                        f3 = f8;
                        f4 = f7;
                      } 
                    } else {
                      param1Path.rCubicTo(param1ArrayOffloat2[param1Char1 + 0], param1ArrayOffloat2[param1Char1 + 1], param1ArrayOffloat2[param1Char1 + 2], param1ArrayOffloat2[param1Char1 + 3], param1ArrayOffloat2[param1Char1 + 4], param1ArrayOffloat2[param1Char1 + 5]);
                      f7 = param1ArrayOffloat2[param1Char1 + 2];
                      f8 = param1ArrayOffloat2[param1Char1 + 3];
                      f3 = f2 + param1ArrayOffloat2[param1Char1 + 4];
                      f4 = f1 + param1ArrayOffloat2[param1Char1 + 5];
                      f7 += f2;
                      f8 += f1;
                      f1 = f4;
                      f2 = f3;
                      f3 = f7;
                      f4 = f8;
                    } 
                  } else {
                    boolean bool1;
                    boolean bool2;
                    f3 = param1ArrayOffloat2[param1Char1 + 5];
                    f7 = param1ArrayOffloat2[param1Char1 + 6];
                    f9 = param1ArrayOffloat2[param1Char1 + 0];
                    f8 = param1ArrayOffloat2[param1Char1 + 1];
                    f4 = param1ArrayOffloat2[param1Char1 + 2];
                    if (param1ArrayOffloat2[param1Char1 + 3] != 0.0F) {
                      bool1 = true;
                    } else {
                      bool1 = false;
                    } 
                    if (param1ArrayOffloat2[param1Char1 + 4] != 0.0F) {
                      bool2 = true;
                    } else {
                      bool2 = false;
                    } 
                    a(param1Path, f2, f1, f3 + f2, f7 + f1, f9, f8, f4, bool1, bool2);
                    f2 += param1ArrayOffloat2[param1Char1 + 5];
                    f1 += param1ArrayOffloat2[param1Char1 + 6];
                    f3 = f2;
                    f4 = f1;
                  } 
                } else {
                  param1Path.lineTo(f2, param1ArrayOffloat2[param1Char1 + 0]);
                  f1 = param1ArrayOffloat2[param1Char1 + 0];
                  f3 = f8;
                  f4 = f7;
                } 
              } else {
                param1Path.quadTo(param1ArrayOffloat2[param1Char1 + 0], param1ArrayOffloat2[param1Char1 + 1], param1ArrayOffloat2[param1Char1 + 2], param1ArrayOffloat2[param1Char1 + 3]);
                f3 = param1ArrayOffloat2[param1Char1 + 0];
                f4 = param1ArrayOffloat2[param1Char1 + 1];
                f2 = param1ArrayOffloat2[param1Char1 + 2];
                f1 = param1ArrayOffloat2[param1Char1 + 3];
              } 
            } else {
              param1Path.lineTo(param1ArrayOffloat2[param1Char1 + 0], f1);
              f2 = param1ArrayOffloat2[param1Char1 + 0];
              f3 = f8;
              f4 = f7;
            } 
          } else {
            param1Path.cubicTo(param1ArrayOffloat2[param1Char1 + 0], param1ArrayOffloat2[param1Char1 + 1], param1ArrayOffloat2[param1Char1 + 2], param1ArrayOffloat2[param1Char1 + 3], param1ArrayOffloat2[param1Char1 + 4], param1ArrayOffloat2[param1Char1 + 5]);
            f2 = param1ArrayOffloat2[param1Char1 + 4];
            f1 = param1ArrayOffloat2[param1Char1 + 5];
            f3 = param1ArrayOffloat2[param1Char1 + 2];
            f4 = param1ArrayOffloat2[param1Char1 + 3];
          } 
        } else {
          boolean bool1;
          boolean bool2;
          f4 = param1ArrayOffloat2[param1Char1 + 5];
          f3 = param1ArrayOffloat2[param1Char1 + 6];
          f7 = param1ArrayOffloat2[param1Char1 + 0];
          f8 = param1ArrayOffloat2[param1Char1 + 1];
          f9 = param1ArrayOffloat2[param1Char1 + 2];
          if (param1ArrayOffloat2[param1Char1 + 3] != 0.0F) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          if (param1ArrayOffloat2[param1Char1 + 4] != 0.0F) {
            bool2 = true;
          } else {
            bool2 = false;
          } 
          a(param1Path, f2, f1, f4, f3, f7, f8, f9, bool1, bool2);
          f2 = param1ArrayOffloat2[param1Char1 + 5];
          f1 = param1ArrayOffloat2[param1Char1 + 6];
          f3 = f2;
          f4 = f1;
        } 
        c = param1Char2;
        int i = param1Char1 + b1;
        f8 = f3;
        f7 = f4;
      } 
      param1ArrayOffloat1[0] = f2;
      param1ArrayOffloat1[1] = f1;
      param1ArrayOffloat1[2] = f8;
      param1ArrayOffloat1[3] = f7;
      param1ArrayOffloat1[4] = f5;
      param1ArrayOffloat1[5] = f6;
    }
    
    public static void a(b[] param1ArrayOfb, Path param1Path) {
      float[] arrayOfFloat = new float[6];
      char c = 'm';
      for (byte b1 = 0; b1 < param1ArrayOfb.length; b1++) {
        a(param1Path, arrayOfFloat, c, (param1ArrayOfb[b1]).a, (param1ArrayOfb[b1]).b);
        c = (param1ArrayOfb[b1]).a;
      } 
    }
    
    public void a(b param1b1, b param1b2, float param1Float) {
      byte b1 = 0;
      while (true) {
        float[] arrayOfFloat = param1b1.b;
        if (b1 < arrayOfFloat.length) {
          this.b[b1] = arrayOfFloat[b1] * (1.0F - param1Float) + param1b2.b[b1] * param1Float;
          b1++;
          continue;
        } 
        break;
      } 
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */