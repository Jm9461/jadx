package a.b.g.a;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

class h {
  private android.support.v4.content.e.c.c a(android.support.v4.content.e.c.b paramb, int paramInt) {
    return a(paramb.a(), paramInt, new b(this));
  }
  
  private static <T> T a(T[] paramArrayOfT, int paramInt, c<T> paramc) {
    // Byte code:
    //   0: iload_1
    //   1: iconst_1
    //   2: iand
    //   3: ifne -> 13
    //   6: sipush #400
    //   9: istore_3
    //   10: goto -> 17
    //   13: sipush #700
    //   16: istore_3
    //   17: iload_1
    //   18: iconst_2
    //   19: iand
    //   20: ifeq -> 29
    //   23: iconst_1
    //   24: istore #8
    //   26: goto -> 32
    //   29: iconst_0
    //   30: istore #8
    //   32: aload_0
    //   33: arraylength
    //   34: istore #7
    //   36: ldc 2147483647
    //   38: istore_1
    //   39: aconst_null
    //   40: astore #9
    //   42: iconst_0
    //   43: istore #4
    //   45: iload #4
    //   47: iload #7
    //   49: if_icmpge -> 135
    //   52: aload_0
    //   53: iload #4
    //   55: aaload
    //   56: astore #10
    //   58: aload_2
    //   59: aload #10
    //   61: invokeinterface a : (Ljava/lang/Object;)I
    //   66: iload_3
    //   67: isub
    //   68: invokestatic abs : (I)I
    //   71: istore #6
    //   73: aload_2
    //   74: aload #10
    //   76: invokeinterface b : (Ljava/lang/Object;)Z
    //   81: iload #8
    //   83: if_icmpne -> 92
    //   86: iconst_0
    //   87: istore #5
    //   89: goto -> 95
    //   92: iconst_1
    //   93: istore #5
    //   95: iload #6
    //   97: iconst_2
    //   98: imul
    //   99: iload #5
    //   101: iadd
    //   102: istore #6
    //   104: aload #9
    //   106: ifnull -> 118
    //   109: iload_1
    //   110: istore #5
    //   112: iload_1
    //   113: iload #6
    //   115: if_icmple -> 126
    //   118: aload #10
    //   120: astore #9
    //   122: iload #6
    //   124: istore #5
    //   126: iinc #4, 1
    //   129: iload #5
    //   131: istore_1
    //   132: goto -> 45
    //   135: aload #9
    //   137: areturn
  }
  
  protected a.b.g.e.b.f a(a.b.g.e.b.f[] paramArrayOff, int paramInt) {
    return a(paramArrayOff, paramInt, new a(this));
  }
  
  public Typeface a(Context paramContext, Resources paramResources, int paramInt1, String paramString, int paramInt2) {
    File file = i.a(paramContext);
    if (file == null)
      return null; 
    try {
      boolean bool = i.a(file, paramResources, paramInt1);
      if (!bool)
        return null; 
      return Typeface.createFromFile(file.getPath());
    } catch (RuntimeException runtimeException) {
      return null;
    } finally {
      file.delete();
    } 
  }
  
  public Typeface a(Context paramContext, CancellationSignal paramCancellationSignal, a.b.g.e.b.f[] paramArrayOff, int paramInt) {
    InputStream inputStream1;
    InputStream inputStream2;
    if (paramArrayOff.length < 1)
      return null; 
    a.b.g.e.b.f f1 = a(paramArrayOff, paramInt);
    paramArrayOff = null;
    paramCancellationSignal = null;
    try {
      InputStream inputStream = paramContext.getContentResolver().openInputStream(f1.c());
      inputStream1 = inputStream;
      inputStream2 = inputStream;
      return a(paramContext, inputStream);
    } catch (IOException iOException) {
      return null;
    } finally {
      i.a(inputStream1);
    } 
  }
  
  public Typeface a(Context paramContext, android.support.v4.content.e.c.b paramb, Resources paramResources, int paramInt) {
    android.support.v4.content.e.c.c c = a(paramb, paramInt);
    return (c == null) ? null : c.a(paramContext, paramResources, c.b(), c.a(), paramInt);
  }
  
  protected Typeface a(Context paramContext, InputStream paramInputStream) {
    File file = i.a(paramContext);
    if (file == null)
      return null; 
    try {
      boolean bool = i.a(file, paramInputStream);
      if (!bool)
        return null; 
      return Typeface.createFromFile(file.getPath());
    } catch (RuntimeException runtimeException) {
      return null;
    } finally {
      file.delete();
    } 
  }
  
  class a implements c<a.b.g.e.b.f> {
    a(h this$0) {}
    
    public int a(a.b.g.e.b.f param1f) {
      return param1f.d();
    }
    
    public boolean b(a.b.g.e.b.f param1f) {
      return param1f.e();
    }
  }
  
  class b implements c<android.support.v4.content.e.c.c> {
    b(h this$0) {}
    
    public int a(android.support.v4.content.e.c.c param1c) {
      return param1c.e();
    }
    
    public boolean b(android.support.v4.content.e.c.c param1c) {
      return param1c.f();
    }
  }
  
  private static interface c<T> {
    int a(T param1T);
    
    boolean b(T param1T);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\a\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */