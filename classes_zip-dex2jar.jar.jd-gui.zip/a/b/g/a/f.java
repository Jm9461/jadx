package a.b.g.a;

import a.b.g.e.b;
import android.content.ContentResolver;
import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.fonts.FontVariationAxis;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.support.v4.content.e.c;
import android.util.Log;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.Map;

public class f extends d {
  protected final Class a;
  
  protected final Constructor b;
  
  protected final Method c;
  
  protected final Method d;
  
  protected final Method e;
  
  protected final Method f;
  
  protected final Method g;
  
  public f() {
    StringBuilder stringBuilder;
    Method method1;
    Method method2;
    Constructor constructor;
    Method method3;
    Method method4;
    try {
      Class clazz = a();
      constructor = e(clazz);
      method3 = b(clazz);
      Method method = c(clazz);
      method2 = f(clazz);
      method4 = a(clazz);
      method1 = d(clazz);
    } catch (ClassNotFoundException classNotFoundException) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to collect necessary methods for class ");
      stringBuilder.append(classNotFoundException.getClass().getName());
      Log.e("TypefaceCompatApi26Impl", stringBuilder.toString(), classNotFoundException);
      method1 = null;
      stringBuilder = null;
      constructor = null;
      method3 = null;
      classNotFoundException = null;
      method2 = null;
      method4 = null;
    } catch (NoSuchMethodException noSuchMethodException) {}
    this.a = (Class)stringBuilder;
    this.b = constructor;
    this.c = method3;
    this.d = (Method)noSuchMethodException;
    this.e = method2;
    this.f = method4;
    this.g = method1;
  }
  
  private boolean a(Context paramContext, Object paramObject, String paramString, int paramInt1, int paramInt2, int paramInt3, FontVariationAxis[] paramArrayOfFontVariationAxis) {
    try {
      return ((Boolean)this.c.invoke(paramObject, new Object[] { paramContext.getAssets(), paramString, Integer.valueOf(0), Boolean.valueOf(false), Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), paramArrayOfFontVariationAxis })).booleanValue();
    } catch (IllegalAccessException illegalAccessException) {
    
    } catch (InvocationTargetException invocationTargetException) {}
    throw new RuntimeException(invocationTargetException);
  }
  
  private boolean a(Object paramObject, ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, int paramInt3) {
    try {
      return ((Boolean)this.d.invoke(paramObject, new Object[] { paramByteBuffer, Integer.valueOf(paramInt1), null, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3) })).booleanValue();
    } catch (IllegalAccessException illegalAccessException) {
    
    } catch (InvocationTargetException invocationTargetException) {}
    throw new RuntimeException(invocationTargetException);
  }
  
  private void b(Object paramObject) {
    try {
      this.f.invoke(paramObject, new Object[0]);
      return;
    } catch (IllegalAccessException illegalAccessException) {
    
    } catch (InvocationTargetException invocationTargetException) {}
    throw new RuntimeException(invocationTargetException);
  }
  
  private boolean b() {
    boolean bool;
    if (this.c == null)
      Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation."); 
    if (this.c != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private Object c() {
    try {
      return this.b.newInstance(new Object[0]);
    } catch (IllegalAccessException illegalAccessException) {
    
    } catch (InstantiationException instantiationException) {
    
    } catch (InvocationTargetException invocationTargetException) {}
    throw new RuntimeException(invocationTargetException);
  }
  
  private boolean c(Object paramObject) {
    try {
      return ((Boolean)this.e.invoke(paramObject, new Object[0])).booleanValue();
    } catch (IllegalAccessException illegalAccessException) {
    
    } catch (InvocationTargetException invocationTargetException) {}
    throw new RuntimeException(invocationTargetException);
  }
  
  public Typeface a(Context paramContext, Resources paramResources, int paramInt1, String paramString, int paramInt2) {
    if (!b())
      return super.a(paramContext, paramResources, paramInt1, paramString, paramInt2); 
    Object object = c();
    if (!a(paramContext, object, paramString, 0, -1, -1, null)) {
      b(object);
      return null;
    } 
    return !c(object) ? null : a(object);
  }
  
  public Typeface a(Context paramContext, CancellationSignal paramCancellationSignal, b.f[] paramArrayOff, int paramInt) {
    if (paramArrayOff.length < 1)
      return null; 
    if (!b()) {
      b.f f1 = a(paramArrayOff, paramInt);
      ContentResolver contentResolver = paramContext.getContentResolver();
      try {
        ParcelFileDescriptor parcelFileDescriptor = contentResolver.openFileDescriptor(f1.c(), "r", paramCancellationSignal);
        if (parcelFileDescriptor == null) {
          if (parcelFileDescriptor != null)
            parcelFileDescriptor.close(); 
          return null;
        } 
        try {
          Typeface.Builder builder = new Typeface.Builder();
          this(parcelFileDescriptor.getFileDescriptor());
          return builder.setWeight(f1.d()).setItalic(f1.e()).build();
        } finally {
          paramCancellationSignal = null;
        } 
      } catch (IOException iOException) {
        return null;
      } 
    } 
    Map map = b.a((Context)iOException, paramArrayOff, paramCancellationSignal);
    Object object = c();
    int i = paramArrayOff.length;
    boolean bool = false;
    for (byte b = 0; b < i; b++) {
      b.f f1 = paramArrayOff[b];
      ByteBuffer byteBuffer = (ByteBuffer)map.get(f1.c());
      if (byteBuffer != null) {
        if (!a(object, byteBuffer, f1.b(), f1.d(), f1.e())) {
          b(object);
          return null;
        } 
        bool = true;
      } 
    } 
    if (!bool) {
      b(object);
      return null;
    } 
    return !c(object) ? null : Typeface.create(a(object), paramInt);
  }
  
  public Typeface a(Context paramContext, c.b paramb, Resources paramResources, int paramInt) {
    if (!b())
      return super.a(paramContext, paramb, paramResources, paramInt); 
    Object object = c();
    c.c[] arrayOfC = paramb.a();
    int i = arrayOfC.length;
    for (paramInt = 0; paramInt < i; paramInt++) {
      c.c c = arrayOfC[paramInt];
      if (!a(paramContext, object, c.a(), c.c(), c.e(), c.f(), FontVariationAxis.fromFontVariationSettings(c.d()))) {
        b(object);
        return null;
      } 
    } 
    return !c(object) ? null : a(object);
  }
  
  protected Typeface a(Object paramObject) {
    try {
      Object object = Array.newInstance(this.a, 1);
      Array.set(object, 0, paramObject);
      return (Typeface)this.g.invoke(null, new Object[] { object, Integer.valueOf(-1), Integer.valueOf(-1) });
    } catch (IllegalAccessException illegalAccessException) {
    
    } catch (InvocationTargetException invocationTargetException) {}
    throw new RuntimeException(invocationTargetException);
  }
  
  protected Class a() {
    return Class.forName("android.graphics.FontFamily");
  }
  
  protected Method a(Class paramClass) {
    return paramClass.getMethod("abortCreation", new Class[0]);
  }
  
  protected Method b(Class paramClass) {
    Class<int> clazz2 = int.class;
    Class<boolean> clazz = boolean.class;
    Class<int> clazz1 = int.class;
    return paramClass.getMethod("addFontFromAssetManager", new Class[] { AssetManager.class, String.class, clazz2, clazz, clazz1, clazz1, clazz1, FontVariationAxis[].class });
  }
  
  protected Method c(Class paramClass) {
    Class<int> clazz = int.class;
    return paramClass.getMethod("addFontFromBuffer", new Class[] { ByteBuffer.class, clazz, FontVariationAxis[].class, clazz, clazz });
  }
  
  protected Method d(Class<?> paramClass) {
    Class<?> clazz = Array.newInstance(paramClass, 1).getClass();
    paramClass = int.class;
    Method method = Typeface.class.getDeclaredMethod("createFromFamiliesWithDefault", new Class[] { clazz, paramClass, paramClass });
    method.setAccessible(true);
    return method;
  }
  
  protected Constructor e(Class paramClass) {
    return paramClass.getConstructor(new Class[0]);
  }
  
  protected Method f(Class paramClass) {
    return paramClass.getMethod("freeze", new Class[0]);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\a\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */