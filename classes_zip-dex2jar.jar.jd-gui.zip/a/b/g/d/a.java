package a.b.g.d;

import android.os.Build;
import android.os.Trace;

public final class a {
  public static void a() {
    if (Build.VERSION.SDK_INT >= 18)
      Trace.endSection(); 
  }
  
  public static void a(String paramString) {
    if (Build.VERSION.SDK_INT >= 18)
      Trace.beginSection(paramString); 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\d\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */