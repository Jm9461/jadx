package a.b.g.e;

import a.b.g.a.i;
import a.b.g.g.m;
import a.b.g.g.n;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.Signature;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.CancellationSignal;
import android.os.Handler;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

public class b {
  static final a.b.g.g.g<String, Typeface> a = new a.b.g.g.g(16);
  
  private static final c b = new c("fonts", 10, 10000);
  
  static final Object c = new Object();
  
  static final n<String, ArrayList<c.d<g>>> d = new n();
  
  private static final Comparator<byte[]> e = new d();
  
  public static e a(Context paramContext, CancellationSignal paramCancellationSignal, a parama) {
    ProviderInfo providerInfo = a(paramContext.getPackageManager(), parama, paramContext.getResources());
    return (providerInfo == null) ? new e(1, null) : new e(0, a(paramContext, parama, providerInfo.authority, paramCancellationSignal));
  }
  
  static g a(Context paramContext, a parama, int paramInt) {
    try {
      e e = a(paramContext, (CancellationSignal)null, parama);
      int i = e.b();
      byte b1 = -3;
      if (i == 0) {
        Typeface typeface = a.b.g.a.c.a(paramContext, null, e.a(), paramInt);
        if (typeface != null)
          b1 = 0; 
        return new g(typeface, b1);
      } 
      if (e.b() == 1)
        b1 = -2; 
      return new g(null, b1);
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      return new g(null, -1);
    } 
  }
  
  public static ProviderInfo a(PackageManager paramPackageManager, a parama, Resources paramResources) {
    String str = parama.d();
    ProviderInfo providerInfo = paramPackageManager.resolveContentProvider(str, 0);
    if (providerInfo != null) {
      List<List<byte[]>> list;
      if (providerInfo.packageName.equals(parama.e())) {
        List<byte[]> list1 = a((paramPackageManager.getPackageInfo(providerInfo.packageName, 64)).signatures);
        Collections.sort((List)list1, (Comparator)e);
        list = a(parama, paramResources);
        for (byte b1 = 0; b1 < list.size(); b1++) {
          ArrayList<byte> arrayList = new ArrayList(list.get(b1));
          Collections.sort(arrayList, (Comparator)e);
          if (a(list1, (List)arrayList))
            return providerInfo; 
        } 
        return null;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Found content provider ");
      stringBuilder1.append(str);
      stringBuilder1.append(", but package was not ");
      stringBuilder1.append(list.e());
      throw new PackageManager.NameNotFoundException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("No package found for authority: ");
    stringBuilder.append(str);
    PackageManager.NameNotFoundException nameNotFoundException = new PackageManager.NameNotFoundException(stringBuilder.toString());
    throw nameNotFoundException;
  }
  
  public static Typeface a(Context paramContext, a parama, android.support.v4.content.e.f.a parama1, Handler paramHandler, boolean paramBoolean, int paramInt1, int paramInt2) {
    g g1;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(parama.c());
    stringBuilder.append("-");
    stringBuilder.append(paramInt2);
    String str = stringBuilder.toString();
    Typeface typeface = (Typeface)a.b(str);
    if (typeface != null) {
      if (parama1 != null)
        parama1.a(typeface); 
      return typeface;
    } 
    if (paramBoolean && paramInt1 == -1) {
      g1 = a(paramContext, parama, paramInt2);
      if (parama1 != null) {
        paramInt1 = g1.b;
        if (paramInt1 == 0) {
          parama1.a(g1.a, paramHandler);
        } else {
          parama1.a(paramInt1, paramHandler);
        } 
      } 
      return g1.a;
    } 
    a a1 = new a((Context)g1, parama, paramInt2, str);
    if (paramBoolean)
      try {
        return ((g)b.a(a1, paramInt1)).a;
      } catch (InterruptedException interruptedException) {
        return null;
      }  
    if (parama1 == null) {
      g1 = null;
    } else {
      null = new b(parama1, paramHandler);
    } 
    synchronized (c) {
      if (d.containsKey(str)) {
        if (null != null)
          ((ArrayList<b>)d.get(str)).add(null); 
        return null;
      } 
      if (null != null) {
        ArrayList<b> arrayList = new ArrayList();
        this();
        arrayList.add(null);
        d.put(str, arrayList);
      } 
      b.a(a1, new c(str));
      return null;
    } 
  }
  
  private static List<List<byte[]>> a(a parama, Resources paramResources) {
    return (parama.a() != null) ? parama.a() : android.support.v4.content.e.c.a(paramResources, parama.b());
  }
  
  private static List<byte[]> a(Signature[] paramArrayOfSignature) {
    ArrayList<byte[]> arrayList = new ArrayList();
    for (byte b1 = 0; b1 < paramArrayOfSignature.length; b1++)
      arrayList.add(paramArrayOfSignature[b1].toByteArray()); 
    return (List<byte[]>)arrayList;
  }
  
  public static Map<Uri, ByteBuffer> a(Context paramContext, f[] paramArrayOff, CancellationSignal paramCancellationSignal) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    int i = paramArrayOff.length;
    for (byte b1 = 0; b1 < i; b1++) {
      f f1 = paramArrayOff[b1];
      if (f1.a() == 0) {
        Uri uri = f1.c();
        if (!hashMap.containsKey(uri))
          hashMap.put(uri, i.a(paramContext, paramCancellationSignal, uri)); 
      } 
    } 
    return (Map)Collections.unmodifiableMap(hashMap);
  }
  
  private static boolean a(List<byte[]> paramList1, List<byte[]> paramList2) {
    if (paramList1.size() != paramList2.size())
      return false; 
    for (byte b1 = 0; b1 < paramList1.size(); b1++) {
      if (!Arrays.equals(paramList1.get(b1), paramList2.get(b1)))
        return false; 
    } 
    return true;
  }
  
  static f[] a(Context paramContext, a parama, String paramString, CancellationSignal paramCancellationSignal) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #14
    //   9: new android/net/Uri$Builder
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: ldc_w 'content'
    //   19: invokevirtual scheme : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   22: aload_2
    //   23: invokevirtual authority : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   26: invokevirtual build : ()Landroid/net/Uri;
    //   29: astore #16
    //   31: new android/net/Uri$Builder
    //   34: dup
    //   35: invokespecial <init> : ()V
    //   38: ldc_w 'content'
    //   41: invokevirtual scheme : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   44: aload_2
    //   45: invokevirtual authority : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   48: ldc_w 'file'
    //   51: invokevirtual appendPath : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   54: invokevirtual build : ()Landroid/net/Uri;
    //   57: astore #17
    //   59: aconst_null
    //   60: astore_2
    //   61: aconst_null
    //   62: astore #15
    //   64: getstatic android/os/Build$VERSION.SDK_INT : I
    //   67: istore #4
    //   69: iload #4
    //   71: bipush #16
    //   73: if_icmple -> 160
    //   76: aload_0
    //   77: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   80: astore_0
    //   81: aload_1
    //   82: invokevirtual f : ()Ljava/lang/String;
    //   85: astore_1
    //   86: aload #15
    //   88: astore_2
    //   89: aload_0
    //   90: aload #16
    //   92: bipush #7
    //   94: anewarray java/lang/String
    //   97: dup
    //   98: iconst_0
    //   99: ldc_w '_id'
    //   102: aastore
    //   103: dup
    //   104: iconst_1
    //   105: ldc_w 'file_id'
    //   108: aastore
    //   109: dup
    //   110: iconst_2
    //   111: ldc_w 'font_ttc_index'
    //   114: aastore
    //   115: dup
    //   116: iconst_3
    //   117: ldc_w 'font_variation_settings'
    //   120: aastore
    //   121: dup
    //   122: iconst_4
    //   123: ldc_w 'font_weight'
    //   126: aastore
    //   127: dup
    //   128: iconst_5
    //   129: ldc_w 'font_italic'
    //   132: aastore
    //   133: dup
    //   134: bipush #6
    //   136: ldc_w 'result_code'
    //   139: aastore
    //   140: ldc_w 'query = ?'
    //   143: iconst_1
    //   144: anewarray java/lang/String
    //   147: dup
    //   148: iconst_0
    //   149: aload_1
    //   150: aastore
    //   151: aconst_null
    //   152: aload_3
    //   153: invokevirtual query : (Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/database/Cursor;
    //   156: astore_0
    //   157: goto -> 246
    //   160: aload #15
    //   162: astore_2
    //   163: aload_0
    //   164: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   167: astore_0
    //   168: aload #15
    //   170: astore_2
    //   171: aload_1
    //   172: invokevirtual f : ()Ljava/lang/String;
    //   175: astore_1
    //   176: aload #15
    //   178: astore_2
    //   179: aload_0
    //   180: aload #16
    //   182: bipush #7
    //   184: anewarray java/lang/String
    //   187: dup
    //   188: iconst_0
    //   189: ldc_w '_id'
    //   192: aastore
    //   193: dup
    //   194: iconst_1
    //   195: ldc_w 'file_id'
    //   198: aastore
    //   199: dup
    //   200: iconst_2
    //   201: ldc_w 'font_ttc_index'
    //   204: aastore
    //   205: dup
    //   206: iconst_3
    //   207: ldc_w 'font_variation_settings'
    //   210: aastore
    //   211: dup
    //   212: iconst_4
    //   213: ldc_w 'font_weight'
    //   216: aastore
    //   217: dup
    //   218: iconst_5
    //   219: ldc_w 'font_italic'
    //   222: aastore
    //   223: dup
    //   224: bipush #6
    //   226: ldc_w 'result_code'
    //   229: aastore
    //   230: ldc_w 'query = ?'
    //   233: iconst_1
    //   234: anewarray java/lang/String
    //   237: dup
    //   238: iconst_0
    //   239: aload_1
    //   240: aastore
    //   241: aconst_null
    //   242: invokevirtual query : (Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   245: astore_0
    //   246: aload_0
    //   247: ifnull -> 514
    //   250: aload_0
    //   251: astore_2
    //   252: aload_0
    //   253: invokeinterface getCount : ()I
    //   258: ifle -> 514
    //   261: aload_0
    //   262: astore_2
    //   263: aload_0
    //   264: ldc_w 'result_code'
    //   267: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   272: istore #12
    //   274: aload_0
    //   275: astore_2
    //   276: new java/util/ArrayList
    //   279: astore_3
    //   280: aload_0
    //   281: astore_2
    //   282: aload_3
    //   283: invokespecial <init> : ()V
    //   286: aload_0
    //   287: ldc_w '_id'
    //   290: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   295: istore #8
    //   297: aload_0
    //   298: ldc_w 'file_id'
    //   301: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   306: istore #7
    //   308: aload_0
    //   309: ldc_w 'font_ttc_index'
    //   312: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   317: istore #9
    //   319: aload_0
    //   320: ldc_w 'font_weight'
    //   323: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   328: istore #10
    //   330: aload_0
    //   331: ldc_w 'font_italic'
    //   334: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   339: istore #11
    //   341: aload_3
    //   342: astore_1
    //   343: aload_0
    //   344: invokeinterface moveToNext : ()Z
    //   349: ifeq -> 517
    //   352: iload #12
    //   354: iconst_m1
    //   355: if_icmpeq -> 371
    //   358: aload_0
    //   359: iload #12
    //   361: invokeinterface getInt : (I)I
    //   366: istore #4
    //   368: goto -> 374
    //   371: iconst_0
    //   372: istore #4
    //   374: iload #9
    //   376: iconst_m1
    //   377: if_icmpeq -> 393
    //   380: aload_0
    //   381: iload #9
    //   383: invokeinterface getInt : (I)I
    //   388: istore #5
    //   390: goto -> 396
    //   393: iconst_0
    //   394: istore #5
    //   396: iload #7
    //   398: iconst_m1
    //   399: if_icmpne -> 419
    //   402: aload #16
    //   404: aload_0
    //   405: iload #8
    //   407: invokeinterface getLong : (I)J
    //   412: invokestatic withAppendedId : (Landroid/net/Uri;J)Landroid/net/Uri;
    //   415: astore_1
    //   416: goto -> 433
    //   419: aload #17
    //   421: aload_0
    //   422: iload #7
    //   424: invokeinterface getLong : (I)J
    //   429: invokestatic withAppendedId : (Landroid/net/Uri;J)Landroid/net/Uri;
    //   432: astore_1
    //   433: iload #10
    //   435: iconst_m1
    //   436: if_icmpeq -> 452
    //   439: aload_0
    //   440: iload #10
    //   442: invokeinterface getInt : (I)I
    //   447: istore #6
    //   449: goto -> 457
    //   452: sipush #400
    //   455: istore #6
    //   457: iload #11
    //   459: iconst_m1
    //   460: if_icmpeq -> 481
    //   463: aload_0
    //   464: iload #11
    //   466: invokeinterface getInt : (I)I
    //   471: iconst_1
    //   472: if_icmpne -> 481
    //   475: iconst_1
    //   476: istore #13
    //   478: goto -> 484
    //   481: iconst_0
    //   482: istore #13
    //   484: new a/b/g/e/b$f
    //   487: astore_2
    //   488: aload_2
    //   489: aload_1
    //   490: iload #5
    //   492: iload #6
    //   494: iload #13
    //   496: iload #4
    //   498: invokespecial <init> : (Landroid/net/Uri;IIZI)V
    //   501: aload_3
    //   502: aload_2
    //   503: invokevirtual add : (Ljava/lang/Object;)Z
    //   506: pop
    //   507: goto -> 341
    //   510: astore_1
    //   511: goto -> 548
    //   514: aload #14
    //   516: astore_1
    //   517: aload_0
    //   518: ifnull -> 527
    //   521: aload_0
    //   522: invokeinterface close : ()V
    //   527: aload_1
    //   528: iconst_0
    //   529: anewarray a/b/g/e/b$f
    //   532: invokevirtual toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
    //   535: checkcast [La/b/g/e/b$f;
    //   538: areturn
    //   539: astore_1
    //   540: aload_2
    //   541: astore_0
    //   542: goto -> 548
    //   545: astore_1
    //   546: aload_2
    //   547: astore_0
    //   548: aload_0
    //   549: ifnull -> 558
    //   552: aload_0
    //   553: invokeinterface close : ()V
    //   558: goto -> 563
    //   561: aload_1
    //   562: athrow
    //   563: goto -> 561
    // Exception table:
    //   from	to	target	type
    //   64	69	545	finally
    //   76	86	545	finally
    //   89	157	539	finally
    //   163	168	539	finally
    //   171	176	539	finally
    //   179	246	539	finally
    //   252	261	539	finally
    //   263	274	539	finally
    //   276	280	539	finally
    //   282	286	539	finally
    //   286	341	510	finally
    //   343	352	510	finally
    //   358	368	510	finally
    //   380	390	510	finally
    //   402	416	510	finally
    //   419	433	510	finally
    //   439	449	510	finally
    //   463	475	510	finally
    //   484	507	510	finally
  }
  
  static final class a implements Callable<g> {
    final Context a;
    
    final a b;
    
    final int c;
    
    final String d;
    
    a(Context param1Context, a param1a, int param1Int, String param1String) {}
    
    public b.g call() {
      b.g g = b.a(this.a, this.b, this.c);
      Typeface typeface = g.a;
      if (typeface != null)
        b.a.a(this.d, typeface); 
      return g;
    }
  }
  
  static final class b implements c.d<g> {
    final android.support.v4.content.e.f.a a;
    
    final Handler b;
    
    b(android.support.v4.content.e.f.a param1a, Handler param1Handler) {}
    
    public void a(b.g param1g) {
      if (param1g == null) {
        this.a.a(1, this.b);
      } else {
        int i = param1g.b;
        if (i == 0) {
          this.a.a(param1g.a, this.b);
        } else {
          this.a.a(i, this.b);
        } 
      } 
    }
  }
  
  static final class c implements c.d<g> {
    final String a;
    
    c(String param1String) {}
    
    public void a(b.g param1g) {
      Object object = b.c;
      /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
      try {
        ArrayList<c.d<b.g>> arrayList = (ArrayList)b.d.get(this.a);
        if (arrayList == null) {
          try {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } finally {}
        } else {
          b.d.remove(this.a);
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          for (byte b = 0; b < arrayList.size(); b++)
            ((c.d<b.g>)arrayList.get(b)).a(param1g); 
          return;
        } 
      } finally {}
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
      throw param1g;
    }
  }
  
  static final class d implements Comparator<byte[]> {
    public int a(byte[] param1ArrayOfbyte1, byte[] param1ArrayOfbyte2) {
      if (param1ArrayOfbyte1.length != param1ArrayOfbyte2.length)
        return param1ArrayOfbyte1.length - param1ArrayOfbyte2.length; 
      for (byte b = 0; b < param1ArrayOfbyte1.length; b++) {
        if (param1ArrayOfbyte1[b] != param1ArrayOfbyte2[b])
          return param1ArrayOfbyte1[b] - param1ArrayOfbyte2[b]; 
      } 
      return 0;
    }
  }
  
  public static class e {
    private final int a;
    
    private final b.f[] b;
    
    public e(int param1Int, b.f[] param1ArrayOff) {
      this.a = param1Int;
      this.b = param1ArrayOff;
    }
    
    public b.f[] a() {
      return this.b;
    }
    
    public int b() {
      return this.a;
    }
  }
  
  public static class f {
    private final Uri a;
    
    private final int b;
    
    private final int c;
    
    private final boolean d;
    
    private final int e;
    
    public f(Uri param1Uri, int param1Int1, int param1Int2, boolean param1Boolean, int param1Int3) {
      m.a(param1Uri);
      this.a = param1Uri;
      this.b = param1Int1;
      this.c = param1Int2;
      this.d = param1Boolean;
      this.e = param1Int3;
    }
    
    public int a() {
      return this.e;
    }
    
    public int b() {
      return this.b;
    }
    
    public Uri c() {
      return this.a;
    }
    
    public int d() {
      return this.c;
    }
    
    public boolean e() {
      return this.d;
    }
  }
  
  private static final class g {
    final Typeface a;
    
    final int b;
    
    g(Typeface param1Typeface, int param1Int) {
      this.a = param1Typeface;
      this.b = param1Int;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\e\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */