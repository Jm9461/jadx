package a.b.g.g;

import java.util.LinkedHashMap;
import java.util.Map;

public class g<K, V> {
  private final LinkedHashMap<K, V> a;
  
  private int b;
  
  private int c;
  
  private int d;
  
  private int e;
  
  private int f;
  
  private int g;
  
  private int h;
  
  public g(int paramInt) {
    if (paramInt > 0) {
      this.c = paramInt;
      this.a = new LinkedHashMap<K, V>(0, 0.75F, true);
      return;
    } 
    throw new IllegalArgumentException("maxSize <= 0");
  }
  
  private int c(K paramK, V paramV) {
    int i = b(paramK, paramV);
    if (i >= 0)
      return i; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Negative size: ");
    stringBuilder.append(paramK);
    stringBuilder.append("=");
    stringBuilder.append(paramV);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  protected V a(K paramK) {
    return null;
  }
  
  public final V a(K paramK, V paramV) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 97
    //   4: aload_2
    //   5: ifnull -> 97
    //   8: aload_0
    //   9: monitorenter
    //   10: aload_0
    //   11: aload_0
    //   12: getfield d : I
    //   15: iconst_1
    //   16: iadd
    //   17: putfield d : I
    //   20: aload_0
    //   21: aload_0
    //   22: getfield b : I
    //   25: aload_0
    //   26: aload_1
    //   27: aload_2
    //   28: invokespecial c : (Ljava/lang/Object;Ljava/lang/Object;)I
    //   31: iadd
    //   32: putfield b : I
    //   35: aload_0
    //   36: getfield a : Ljava/util/LinkedHashMap;
    //   39: aload_1
    //   40: aload_2
    //   41: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   44: astore_3
    //   45: aload_3
    //   46: ifnull -> 64
    //   49: aload_0
    //   50: aload_0
    //   51: getfield b : I
    //   54: aload_0
    //   55: aload_1
    //   56: aload_3
    //   57: invokespecial c : (Ljava/lang/Object;Ljava/lang/Object;)I
    //   60: isub
    //   61: putfield b : I
    //   64: aload_0
    //   65: monitorexit
    //   66: aload_3
    //   67: ifnull -> 78
    //   70: aload_0
    //   71: iconst_0
    //   72: aload_1
    //   73: aload_3
    //   74: aload_2
    //   75: invokevirtual a : (ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    //   78: aload_0
    //   79: aload_0
    //   80: getfield c : I
    //   83: invokevirtual a : (I)V
    //   86: aload_3
    //   87: areturn
    //   88: astore_1
    //   89: aload_0
    //   90: monitorexit
    //   91: aload_1
    //   92: athrow
    //   93: astore_1
    //   94: goto -> 89
    //   97: new java/lang/NullPointerException
    //   100: dup
    //   101: ldc 'key == null || value == null'
    //   103: invokespecial <init> : (Ljava/lang/String;)V
    //   106: astore_1
    //   107: goto -> 112
    //   110: aload_1
    //   111: athrow
    //   112: goto -> 110
    // Exception table:
    //   from	to	target	type
    //   10	45	88	finally
    //   49	64	93	finally
    //   64	66	93	finally
    //   89	91	93	finally
  }
  
  public void a(int paramInt) {
    /* monitor enter ThisExpression{ObjectType{a/b/g/g/g}} */
    while (true) {
      Object object;
      try {
        if (this.b >= 0 && (!this.a.isEmpty() || this.b == 0)) {
          if (this.b <= paramInt || this.a.isEmpty()) {
            /* monitor exit ThisExpression{ObjectType{a/b/g/g/g}} */
            return;
          } 
          Map.Entry entry = this.a.entrySet().iterator().next();
          object = entry.getKey();
          try {
            entry = (Map.Entry)entry.getValue();
            try {
              this.a.remove(object);
              this.b -= c((K)object, (V)entry);
              this.f++;
              /* monitor exit ThisExpression{ObjectType{a/b/g/g/g}} */
              a(true, (K)object, (V)entry, null);
              continue;
            } finally {}
          } finally {}
        } else {
          IllegalStateException illegalStateException = new IllegalStateException();
          object = new StringBuilder();
          this();
          object.append(getClass().getName());
          object.append(".sizeOf() is reporting inconsistent results!");
          this(object.toString());
          throw illegalStateException;
        } 
      } finally {}
      /* monitor exit ThisExpression{ObjectType{a/b/g/g/g}} */
      throw object;
    } 
  }
  
  protected void a(boolean paramBoolean, K paramK, V paramV1, V paramV2) {}
  
  protected int b(K paramK, V paramV) {
    return 1;
  }
  
  public final V b(K paramK) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 151
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: getfield a : Ljava/util/LinkedHashMap;
    //   10: aload_1
    //   11: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   14: astore_2
    //   15: aload_2
    //   16: ifnull -> 33
    //   19: aload_0
    //   20: aload_0
    //   21: getfield g : I
    //   24: iconst_1
    //   25: iadd
    //   26: putfield g : I
    //   29: aload_0
    //   30: monitorexit
    //   31: aload_2
    //   32: areturn
    //   33: aload_0
    //   34: aload_0
    //   35: getfield h : I
    //   38: iconst_1
    //   39: iadd
    //   40: putfield h : I
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_0
    //   46: aload_1
    //   47: invokevirtual a : (Ljava/lang/Object;)Ljava/lang/Object;
    //   50: astore_3
    //   51: aload_3
    //   52: ifnonnull -> 57
    //   55: aconst_null
    //   56: areturn
    //   57: aload_0
    //   58: monitorenter
    //   59: aload_0
    //   60: aload_0
    //   61: getfield e : I
    //   64: iconst_1
    //   65: iadd
    //   66: putfield e : I
    //   69: aload_0
    //   70: getfield a : Ljava/util/LinkedHashMap;
    //   73: aload_1
    //   74: aload_3
    //   75: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   78: astore_2
    //   79: aload_2
    //   80: ifnull -> 96
    //   83: aload_0
    //   84: getfield a : Ljava/util/LinkedHashMap;
    //   87: aload_1
    //   88: aload_2
    //   89: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   92: pop
    //   93: goto -> 111
    //   96: aload_0
    //   97: aload_0
    //   98: getfield b : I
    //   101: aload_0
    //   102: aload_1
    //   103: aload_3
    //   104: invokespecial c : (Ljava/lang/Object;Ljava/lang/Object;)I
    //   107: iadd
    //   108: putfield b : I
    //   111: aload_0
    //   112: monitorexit
    //   113: aload_2
    //   114: ifnull -> 127
    //   117: aload_0
    //   118: iconst_0
    //   119: aload_1
    //   120: aload_3
    //   121: aload_2
    //   122: invokevirtual a : (ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    //   125: aload_2
    //   126: areturn
    //   127: aload_0
    //   128: aload_0
    //   129: getfield c : I
    //   132: invokevirtual a : (I)V
    //   135: aload_3
    //   136: areturn
    //   137: astore_1
    //   138: aload_0
    //   139: monitorexit
    //   140: aload_1
    //   141: athrow
    //   142: astore_1
    //   143: aload_0
    //   144: monitorexit
    //   145: aload_1
    //   146: athrow
    //   147: astore_1
    //   148: goto -> 143
    //   151: new java/lang/NullPointerException
    //   154: dup
    //   155: ldc 'key == null'
    //   157: invokespecial <init> : (Ljava/lang/String;)V
    //   160: astore_1
    //   161: goto -> 166
    //   164: aload_1
    //   165: athrow
    //   166: goto -> 164
    // Exception table:
    //   from	to	target	type
    //   6	15	142	finally
    //   19	31	147	finally
    //   33	45	147	finally
    //   59	79	137	finally
    //   83	93	137	finally
    //   96	111	137	finally
    //   111	113	137	finally
    //   138	140	137	finally
    //   143	145	147	finally
  }
  
  public final String toString() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield g : I
    //   6: aload_0
    //   7: getfield h : I
    //   10: iadd
    //   11: istore_1
    //   12: iload_1
    //   13: ifeq -> 29
    //   16: aload_0
    //   17: getfield g : I
    //   20: bipush #100
    //   22: imul
    //   23: iload_1
    //   24: idiv
    //   25: istore_1
    //   26: goto -> 31
    //   29: iconst_0
    //   30: istore_1
    //   31: getstatic java/util/Locale.US : Ljava/util/Locale;
    //   34: ldc 'LruCache[maxSize=%d,hits=%d,misses=%d,hitRate=%d%%]'
    //   36: iconst_4
    //   37: anewarray java/lang/Object
    //   40: dup
    //   41: iconst_0
    //   42: aload_0
    //   43: getfield c : I
    //   46: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   49: aastore
    //   50: dup
    //   51: iconst_1
    //   52: aload_0
    //   53: getfield g : I
    //   56: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   59: aastore
    //   60: dup
    //   61: iconst_2
    //   62: aload_0
    //   63: getfield h : I
    //   66: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   69: aastore
    //   70: dup
    //   71: iconst_3
    //   72: iload_1
    //   73: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   76: aastore
    //   77: invokestatic format : (Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   80: astore_2
    //   81: aload_0
    //   82: monitorexit
    //   83: aload_2
    //   84: areturn
    //   85: astore_2
    //   86: aload_0
    //   87: monitorexit
    //   88: aload_2
    //   89: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	85	finally
    //   16	26	85	finally
    //   31	81	85	finally
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\g\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */