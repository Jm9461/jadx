package a.b.g.g;

class c {
  static final int[] a = new int[0];
  
  static final long[] b = new long[0];
  
  static final Object[] c = new Object[0];
  
  public static int a(int paramInt) {
    for (byte b = 4; b < 32; b++) {
      if (paramInt <= (1 << b) - 12)
        return (1 << b) - 12; 
    } 
    return paramInt;
  }
  
  static int a(int[] paramArrayOfint, int paramInt1, int paramInt2) {
    int i = 0;
    while (i <= --paramInt1) {
      int j = i + paramInt1 >>> 1;
      int k = paramArrayOfint[j];
      if (k < paramInt2) {
        i = j + 1;
        continue;
      } 
      if (k > paramInt2) {
        paramInt1 = j - 1;
        continue;
      } 
      return j;
    } 
    return i ^ 0xFFFFFFFF;
  }
  
  static int a(long[] paramArrayOflong, int paramInt, long paramLong) {
    int i = 0;
    while (i <= --paramInt) {
      int j = i + paramInt >>> 1;
      long l = paramArrayOflong[j];
      if (l < paramLong) {
        i = j + 1;
        continue;
      } 
      if (l > paramLong) {
        paramInt = j - 1;
        continue;
      } 
      return j;
    } 
    return i ^ 0xFFFFFFFF;
  }
  
  public static boolean a(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2 || (paramObject1 != null && paramObject1.equals(paramObject2)));
  }
  
  public static int b(int paramInt) {
    return a(paramInt * 4) / 4;
  }
  
  public static int c(int paramInt) {
    return a(paramInt * 8) / 8;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\g\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */