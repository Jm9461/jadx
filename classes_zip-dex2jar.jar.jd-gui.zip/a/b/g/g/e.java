package a.b.g.g;

import android.util.Log;
import java.io.Writer;

public class e extends Writer {
  private final String c;
  
  private StringBuilder d = new StringBuilder(128);
  
  public e(String paramString) {
    this.c = paramString;
  }
  
  private void l() {
    if (this.d.length() > 0) {
      Log.d(this.c, this.d.toString());
      StringBuilder stringBuilder = this.d;
      stringBuilder.delete(0, stringBuilder.length());
    } 
  }
  
  public void close() {
    l();
  }
  
  public void flush() {
    l();
  }
  
  public void write(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
    for (byte b = 0; b < paramInt2; b++) {
      char c = paramArrayOfchar[paramInt1 + b];
      if (c == '\n') {
        l();
      } else {
        this.d.append(c);
      } 
    } 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\g\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */