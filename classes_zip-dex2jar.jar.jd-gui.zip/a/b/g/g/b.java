package a.b.g.g;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class b<E> implements Collection<E>, Set<E> {
  private static final int[] g = new int[0];
  
  private static final Object[] h = new Object[0];
  
  private static Object[] i;
  
  private static int j;
  
  private static Object[] k;
  
  private static int l;
  
  private int[] c;
  
  Object[] d;
  
  int e;
  
  private h<E, E> f;
  
  public b() {
    this(0);
  }
  
  public b(int paramInt) {
    if (paramInt == 0) {
      this.c = g;
      this.d = h;
    } else {
      d(paramInt);
    } 
    this.e = 0;
  }
  
  private int a(Object paramObject, int paramInt) {
    int j = this.e;
    if (j == 0)
      return -1; 
    int k = c.a(this.c, j, paramInt);
    if (k < 0)
      return k; 
    if (paramObject.equals(this.d[k]))
      return k; 
    int i;
    for (i = k + 1; i < j && this.c[i] == paramInt; i++) {
      if (paramObject.equals(this.d[i]))
        return i; 
    } 
    for (j = k - 1; j >= 0 && this.c[j] == paramInt; j--) {
      if (paramObject.equals(this.d[j]))
        return j; 
    } 
    return i ^ 0xFFFFFFFF;
  }
  
  private h<E, E> a() {
    if (this.f == null)
      this.f = new a(this); 
    return this.f;
  }
  
  private static void a(int[] paramArrayOfint, Object[] paramArrayOfObject, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: arraylength
    //   2: bipush #8
    //   4: if_icmpne -> 70
    //   7: ldc a/b/g/g/b
    //   9: monitorenter
    //   10: getstatic a/b/g/g/b.l : I
    //   13: bipush #10
    //   15: if_icmpge -> 58
    //   18: aload_1
    //   19: iconst_0
    //   20: getstatic a/b/g/g/b.k : [Ljava/lang/Object;
    //   23: aastore
    //   24: aload_1
    //   25: iconst_1
    //   26: aload_0
    //   27: aastore
    //   28: iinc #2, -1
    //   31: iload_2
    //   32: iconst_2
    //   33: if_icmplt -> 46
    //   36: aload_1
    //   37: iload_2
    //   38: aconst_null
    //   39: aastore
    //   40: iinc #2, -1
    //   43: goto -> 31
    //   46: aload_1
    //   47: putstatic a/b/g/g/b.k : [Ljava/lang/Object;
    //   50: getstatic a/b/g/g/b.l : I
    //   53: iconst_1
    //   54: iadd
    //   55: putstatic a/b/g/g/b.l : I
    //   58: ldc a/b/g/g/b
    //   60: monitorexit
    //   61: goto -> 139
    //   64: astore_0
    //   65: ldc a/b/g/g/b
    //   67: monitorexit
    //   68: aload_0
    //   69: athrow
    //   70: aload_0
    //   71: arraylength
    //   72: iconst_4
    //   73: if_icmpne -> 139
    //   76: ldc a/b/g/g/b
    //   78: monitorenter
    //   79: getstatic a/b/g/g/b.j : I
    //   82: bipush #10
    //   84: if_icmpge -> 127
    //   87: aload_1
    //   88: iconst_0
    //   89: getstatic a/b/g/g/b.i : [Ljava/lang/Object;
    //   92: aastore
    //   93: aload_1
    //   94: iconst_1
    //   95: aload_0
    //   96: aastore
    //   97: iinc #2, -1
    //   100: iload_2
    //   101: iconst_2
    //   102: if_icmplt -> 115
    //   105: aload_1
    //   106: iload_2
    //   107: aconst_null
    //   108: aastore
    //   109: iinc #2, -1
    //   112: goto -> 100
    //   115: aload_1
    //   116: putstatic a/b/g/g/b.i : [Ljava/lang/Object;
    //   119: getstatic a/b/g/g/b.j : I
    //   122: iconst_1
    //   123: iadd
    //   124: putstatic a/b/g/g/b.j : I
    //   127: ldc a/b/g/g/b
    //   129: monitorexit
    //   130: goto -> 139
    //   133: astore_0
    //   134: ldc a/b/g/g/b
    //   136: monitorexit
    //   137: aload_0
    //   138: athrow
    //   139: return
    // Exception table:
    //   from	to	target	type
    //   10	24	64	finally
    //   46	58	64	finally
    //   58	61	64	finally
    //   65	68	64	finally
    //   79	93	133	finally
    //   115	127	133	finally
    //   127	130	133	finally
    //   134	137	133	finally
  }
  
  private int b() {
    int j = this.e;
    if (j == 0)
      return -1; 
    int k = c.a(this.c, j, 0);
    if (k < 0)
      return k; 
    if (this.d[k] == null)
      return k; 
    int i;
    for (i = k + 1; i < j && this.c[i] == 0; i++) {
      if (this.d[i] == null)
        return i; 
    } 
    for (j = k - 1; j >= 0 && this.c[j] == 0; j--) {
      if (this.d[j] == null)
        return j; 
    } 
    return i ^ 0xFFFFFFFF;
  }
  
  private void d(int paramInt) {
    // Byte code:
    //   0: iload_1
    //   1: bipush #8
    //   3: if_icmpne -> 75
    //   6: ldc a/b/g/g/b
    //   8: monitorenter
    //   9: getstatic a/b/g/g/b.k : [Ljava/lang/Object;
    //   12: ifnull -> 63
    //   15: getstatic a/b/g/g/b.k : [Ljava/lang/Object;
    //   18: astore_2
    //   19: aload_0
    //   20: aload_2
    //   21: putfield d : [Ljava/lang/Object;
    //   24: aload_2
    //   25: iconst_0
    //   26: aaload
    //   27: checkcast [Ljava/lang/Object;
    //   30: putstatic a/b/g/g/b.k : [Ljava/lang/Object;
    //   33: aload_0
    //   34: aload_2
    //   35: iconst_1
    //   36: aaload
    //   37: checkcast [I
    //   40: putfield c : [I
    //   43: aload_2
    //   44: iconst_1
    //   45: aconst_null
    //   46: aastore
    //   47: aload_2
    //   48: iconst_0
    //   49: aconst_null
    //   50: aastore
    //   51: getstatic a/b/g/g/b.l : I
    //   54: iconst_1
    //   55: isub
    //   56: putstatic a/b/g/g/b.l : I
    //   59: ldc a/b/g/g/b
    //   61: monitorexit
    //   62: return
    //   63: ldc a/b/g/g/b
    //   65: monitorexit
    //   66: goto -> 149
    //   69: astore_2
    //   70: ldc a/b/g/g/b
    //   72: monitorexit
    //   73: aload_2
    //   74: athrow
    //   75: iload_1
    //   76: iconst_4
    //   77: if_icmpne -> 149
    //   80: ldc a/b/g/g/b
    //   82: monitorenter
    //   83: getstatic a/b/g/g/b.i : [Ljava/lang/Object;
    //   86: ifnull -> 137
    //   89: getstatic a/b/g/g/b.i : [Ljava/lang/Object;
    //   92: astore_2
    //   93: aload_0
    //   94: aload_2
    //   95: putfield d : [Ljava/lang/Object;
    //   98: aload_2
    //   99: iconst_0
    //   100: aaload
    //   101: checkcast [Ljava/lang/Object;
    //   104: putstatic a/b/g/g/b.i : [Ljava/lang/Object;
    //   107: aload_0
    //   108: aload_2
    //   109: iconst_1
    //   110: aaload
    //   111: checkcast [I
    //   114: putfield c : [I
    //   117: aload_2
    //   118: iconst_1
    //   119: aconst_null
    //   120: aastore
    //   121: aload_2
    //   122: iconst_0
    //   123: aconst_null
    //   124: aastore
    //   125: getstatic a/b/g/g/b.j : I
    //   128: iconst_1
    //   129: isub
    //   130: putstatic a/b/g/g/b.j : I
    //   133: ldc a/b/g/g/b
    //   135: monitorexit
    //   136: return
    //   137: ldc a/b/g/g/b
    //   139: monitorexit
    //   140: goto -> 149
    //   143: astore_2
    //   144: ldc a/b/g/g/b
    //   146: monitorexit
    //   147: aload_2
    //   148: athrow
    //   149: aload_0
    //   150: iload_1
    //   151: newarray int
    //   153: putfield c : [I
    //   156: aload_0
    //   157: iload_1
    //   158: anewarray java/lang/Object
    //   161: putfield d : [Ljava/lang/Object;
    //   164: return
    // Exception table:
    //   from	to	target	type
    //   9	43	69	finally
    //   51	62	69	finally
    //   63	66	69	finally
    //   70	73	69	finally
    //   83	117	143	finally
    //   125	136	143	finally
    //   137	140	143	finally
    //   144	147	143	finally
  }
  
  public int a(Object paramObject) {
    int i;
    if (paramObject == null) {
      i = b();
    } else {
      i = a(paramObject, paramObject.hashCode());
    } 
    return i;
  }
  
  public void a(int paramInt) {
    if (this.c.length < paramInt) {
      int[] arrayOfInt = this.c;
      Object[] arrayOfObject = this.d;
      d(paramInt);
      paramInt = this.e;
      if (paramInt > 0) {
        System.arraycopy(arrayOfInt, 0, this.c, 0, paramInt);
        System.arraycopy(arrayOfObject, 0, this.d, 0, this.e);
      } 
      a(arrayOfInt, arrayOfObject, this.e);
    } 
  }
  
  public boolean add(E paramE) {
    int j;
    if (paramE == null) {
      j = 0;
      i = b();
    } else {
      j = paramE.hashCode();
      i = a(paramE, j);
    } 
    if (i >= 0)
      return false; 
    int k = i ^ 0xFFFFFFFF;
    int m = this.e;
    if (m >= this.c.length) {
      i = 4;
      if (m >= 8) {
        i = (m >> 1) + m;
      } else if (m >= 4) {
        i = 8;
      } 
      int[] arrayOfInt1 = this.c;
      Object[] arrayOfObject = this.d;
      d(i);
      int[] arrayOfInt2 = this.c;
      if (arrayOfInt2.length > 0) {
        System.arraycopy(arrayOfInt1, 0, arrayOfInt2, 0, arrayOfInt1.length);
        System.arraycopy(arrayOfObject, 0, this.d, 0, arrayOfObject.length);
      } 
      a(arrayOfInt1, arrayOfObject, this.e);
    } 
    int i = this.e;
    if (k < i) {
      int[] arrayOfInt = this.c;
      System.arraycopy(arrayOfInt, k, arrayOfInt, k + 1, i - k);
      Object[] arrayOfObject = this.d;
      System.arraycopy(arrayOfObject, k, arrayOfObject, k + 1, this.e - k);
    } 
    this.c[k] = j;
    this.d[k] = paramE;
    this.e++;
    return true;
  }
  
  public boolean addAll(Collection<? extends E> paramCollection) {
    a(this.e + paramCollection.size());
    boolean bool = false;
    Iterator<? extends E> iterator = paramCollection.iterator();
    while (iterator.hasNext())
      bool |= add(iterator.next()); 
    return bool;
  }
  
  public E b(int paramInt) {
    Object[] arrayOfObject = this.d;
    Object object = arrayOfObject[paramInt];
    int i = this.e;
    if (i <= 1) {
      a(this.c, arrayOfObject, i);
      this.c = g;
      this.d = h;
      this.e = 0;
    } else {
      int[] arrayOfInt = this.c;
      int k = arrayOfInt.length;
      int j = 8;
      if (k > 8 && i < arrayOfInt.length / 3) {
        if (i > 8)
          j = i + (i >> 1); 
        int[] arrayOfInt1 = this.c;
        Object[] arrayOfObject1 = this.d;
        d(j);
        this.e--;
        if (paramInt > 0) {
          System.arraycopy(arrayOfInt1, 0, this.c, 0, paramInt);
          System.arraycopy(arrayOfObject1, 0, this.d, 0, paramInt);
        } 
        j = this.e;
        if (paramInt < j) {
          System.arraycopy(arrayOfInt1, paramInt + 1, this.c, paramInt, j - paramInt);
          System.arraycopy(arrayOfObject1, paramInt + 1, this.d, paramInt, this.e - paramInt);
        } 
      } else {
        j = --this.e;
        if (paramInt < j) {
          arrayOfInt = this.c;
          System.arraycopy(arrayOfInt, paramInt + 1, arrayOfInt, paramInt, j - paramInt);
          Object[] arrayOfObject1 = this.d;
          System.arraycopy(arrayOfObject1, paramInt + 1, arrayOfObject1, paramInt, this.e - paramInt);
        } 
        this.d[this.e] = null;
      } 
    } 
    return (E)object;
  }
  
  public E c(int paramInt) {
    return (E)this.d[paramInt];
  }
  
  public void clear() {
    int i = this.e;
    if (i != 0) {
      a(this.c, this.d, i);
      this.c = g;
      this.d = h;
      this.e = 0;
    } 
  }
  
  public boolean contains(Object paramObject) {
    boolean bool;
    if (a(paramObject) >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean containsAll(Collection<?> paramCollection) {
    Iterator<?> iterator = paramCollection.iterator();
    while (iterator.hasNext()) {
      if (!contains(iterator.next()))
        return false; 
    } 
    return true;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject instanceof Set) {
      paramObject = paramObject;
      if (size() != paramObject.size())
        return false; 
      byte b1 = 0;
      try {
        while (b1 < this.e) {
          boolean bool = paramObject.contains(c(b1));
          if (!bool)
            return false; 
          b1++;
        } 
        return true;
      } catch (NullPointerException nullPointerException) {
        return false;
      } catch (ClassCastException classCastException) {
        return false;
      } 
    } 
    return false;
  }
  
  public int hashCode() {
    int[] arrayOfInt = this.c;
    int i = 0;
    byte b1 = 0;
    int j = this.e;
    while (b1 < j) {
      i += arrayOfInt[b1];
      b1++;
    } 
    return i;
  }
  
  public boolean isEmpty() {
    boolean bool;
    if (this.e <= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public Iterator<E> iterator() {
    return a().e().iterator();
  }
  
  public boolean remove(Object paramObject) {
    int i = a(paramObject);
    if (i >= 0) {
      b(i);
      return true;
    } 
    return false;
  }
  
  public boolean removeAll(Collection<?> paramCollection) {
    boolean bool = false;
    Iterator<?> iterator = paramCollection.iterator();
    while (iterator.hasNext())
      bool |= remove(iterator.next()); 
    return bool;
  }
  
  public boolean retainAll(Collection<?> paramCollection) {
    boolean bool = false;
    for (int i = this.e - 1; i >= 0; i--) {
      if (!paramCollection.contains(this.d[i])) {
        b(i);
        bool = true;
      } 
    } 
    return bool;
  }
  
  public int size() {
    return this.e;
  }
  
  public Object[] toArray() {
    int i = this.e;
    Object[] arrayOfObject = new Object[i];
    System.arraycopy(this.d, 0, arrayOfObject, 0, i);
    return arrayOfObject;
  }
  
  public <T> T[] toArray(T[] paramArrayOfT) {
    T[] arrayOfT = paramArrayOfT;
    if (paramArrayOfT.length < this.e)
      arrayOfT = (T[])Array.newInstance(paramArrayOfT.getClass().getComponentType(), this.e); 
    System.arraycopy(this.d, 0, arrayOfT, 0, this.e);
    int j = arrayOfT.length;
    int i = this.e;
    if (j > i)
      arrayOfT[i] = null; 
    return arrayOfT;
  }
  
  public String toString() {
    if (isEmpty())
      return "{}"; 
    StringBuilder stringBuilder = new StringBuilder(this.e * 14);
    stringBuilder.append('{');
    for (byte b1 = 0; b1 < this.e; b1++) {
      if (b1 > 0)
        stringBuilder.append(", "); 
      E e = c(b1);
      if (e != this) {
        stringBuilder.append(e);
      } else {
        stringBuilder.append("(this Set)");
      } 
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  class a extends h<E, E> {
    final b d;
    
    a(b this$0) {}
    
    protected int a(Object param1Object) {
      return this.d.a(param1Object);
    }
    
    protected Object a(int param1Int1, int param1Int2) {
      return this.d.d[param1Int1];
    }
    
    protected E a(int param1Int, E param1E) {
      throw new UnsupportedOperationException("not a map");
    }
    
    protected void a() {
      this.d.clear();
    }
    
    protected void a(int param1Int) {
      this.d.b(param1Int);
    }
    
    protected void a(E param1E1, E param1E2) {
      this.d.add(param1E1);
    }
    
    protected int b(Object param1Object) {
      return this.d.a(param1Object);
    }
    
    protected Map<E, E> b() {
      throw new UnsupportedOperationException("not a map");
    }
    
    protected int c() {
      return this.d.e;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\g\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */