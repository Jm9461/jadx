package a.b.g.g;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

abstract class h<K, V> {
  b a;
  
  c b;
  
  e c;
  
  public static <K, V> boolean a(Map<K, V> paramMap, Collection<?> paramCollection) {
    Iterator<?> iterator = paramCollection.iterator();
    while (iterator.hasNext()) {
      if (!paramMap.containsKey(iterator.next()))
        return false; 
    } 
    return true;
  }
  
  public static <T> boolean a(Set<T> paramSet, Object paramObject) {
    boolean bool = true;
    if (paramSet == paramObject)
      return true; 
    if (paramObject instanceof Set) {
      paramObject = paramObject;
      try {
        if (paramSet.size() == paramObject.size()) {
          boolean bool1 = paramSet.containsAll((Collection<?>)paramObject);
          if (bool1)
            return bool; 
        } 
        return false;
      } catch (NullPointerException nullPointerException) {
        return false;
      } catch (ClassCastException classCastException) {
        return false;
      } 
    } 
    return false;
  }
  
  public static <K, V> boolean b(Map<K, V> paramMap, Collection<?> paramCollection) {
    boolean bool;
    int i = paramMap.size();
    Iterator<?> iterator = paramCollection.iterator();
    while (iterator.hasNext())
      paramMap.remove(iterator.next()); 
    if (i != paramMap.size()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public static <K, V> boolean c(Map<K, V> paramMap, Collection<?> paramCollection) {
    boolean bool;
    int i = paramMap.size();
    Iterator iterator = paramMap.keySet().iterator();
    while (iterator.hasNext()) {
      if (!paramCollection.contains(iterator.next()))
        iterator.remove(); 
    } 
    if (i != paramMap.size()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  protected abstract int a(Object paramObject);
  
  protected abstract Object a(int paramInt1, int paramInt2);
  
  protected abstract V a(int paramInt, V paramV);
  
  protected abstract void a();
  
  protected abstract void a(int paramInt);
  
  protected abstract void a(K paramK, V paramV);
  
  public <T> T[] a(T[] paramArrayOfT, int paramInt) {
    int i = c();
    T[] arrayOfT = paramArrayOfT;
    if (paramArrayOfT.length < i)
      arrayOfT = (T[])Array.newInstance(paramArrayOfT.getClass().getComponentType(), i); 
    for (byte b1 = 0; b1 < i; b1++)
      arrayOfT[b1] = (T)a(b1, paramInt); 
    if (arrayOfT.length > i)
      arrayOfT[i] = null; 
    return arrayOfT;
  }
  
  protected abstract int b(Object paramObject);
  
  protected abstract Map<K, V> b();
  
  public Object[] b(int paramInt) {
    int i = c();
    Object[] arrayOfObject = new Object[i];
    for (byte b1 = 0; b1 < i; b1++)
      arrayOfObject[b1] = a(b1, paramInt); 
    return arrayOfObject;
  }
  
  protected abstract int c();
  
  public Set<Map.Entry<K, V>> d() {
    if (this.a == null)
      this.a = new b(this); 
    return this.a;
  }
  
  public Set<K> e() {
    if (this.b == null)
      this.b = new c(this); 
    return this.b;
  }
  
  public Collection<V> f() {
    if (this.c == null)
      this.c = new e(this); 
    return this.c;
  }
  
  final class a<T> implements Iterator<T> {
    final int c;
    
    int d;
    
    int e;
    
    boolean f = false;
    
    final h g;
    
    a(h this$0, int param1Int) {
      this.c = param1Int;
      this.d = this$0.c();
    }
    
    public boolean hasNext() {
      boolean bool;
      if (this.e < this.d) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public T next() {
      if (hasNext()) {
        Object object = this.g.a(this.e, this.c);
        this.e++;
        this.f = true;
        return (T)object;
      } 
      throw new NoSuchElementException();
    }
    
    public void remove() {
      if (this.f) {
        this.e--;
        this.d--;
        this.f = false;
        this.g.a(this.e);
        return;
      } 
      throw new IllegalStateException();
    }
  }
  
  final class b implements Set<Map.Entry<K, V>> {
    final h c;
    
    b(h this$0) {}
    
    public boolean a(Map.Entry<K, V> param1Entry) {
      throw new UnsupportedOperationException();
    }
    
    public boolean addAll(Collection<? extends Map.Entry<K, V>> param1Collection) {
      boolean bool;
      int i = this.c.c();
      for (Map.Entry<K, V> entry : param1Collection)
        this.c.a(entry.getKey(), entry.getValue()); 
      if (i != this.c.c()) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public void clear() {
      this.c.a();
    }
    
    public boolean contains(Object param1Object) {
      if (!(param1Object instanceof Map.Entry))
        return false; 
      param1Object = param1Object;
      int i = this.c.a(param1Object.getKey());
      return (i < 0) ? false : c.a(this.c.a(i, 1), param1Object.getValue());
    }
    
    public boolean containsAll(Collection<?> param1Collection) {
      Iterator<?> iterator = param1Collection.iterator();
      while (iterator.hasNext()) {
        if (!contains(iterator.next()))
          return false; 
      } 
      return true;
    }
    
    public boolean equals(Object param1Object) {
      return h.a(this, param1Object);
    }
    
    public int hashCode() {
      int j = 0;
      for (int i = this.c.c() - 1; i >= 0; i--) {
        int k;
        h h1 = this.c;
        int m = 0;
        Object object1 = h1.a(i, 0);
        Object object2 = this.c.a(i, 1);
        if (object1 == null) {
          k = 0;
        } else {
          k = object1.hashCode();
        } 
        if (object2 != null)
          m = object2.hashCode(); 
        j += m ^ k;
      } 
      return j;
    }
    
    public boolean isEmpty() {
      boolean bool;
      if (this.c.c() == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public Iterator<Map.Entry<K, V>> iterator() {
      return new h.d(this.c);
    }
    
    public boolean remove(Object param1Object) {
      throw new UnsupportedOperationException();
    }
    
    public boolean removeAll(Collection<?> param1Collection) {
      throw new UnsupportedOperationException();
    }
    
    public boolean retainAll(Collection<?> param1Collection) {
      throw new UnsupportedOperationException();
    }
    
    public int size() {
      return this.c.c();
    }
    
    public Object[] toArray() {
      throw new UnsupportedOperationException();
    }
    
    public <T> T[] toArray(T[] param1ArrayOfT) {
      throw new UnsupportedOperationException();
    }
  }
  
  final class c implements Set<K> {
    final h c;
    
    c(h this$0) {}
    
    public boolean add(K param1K) {
      throw new UnsupportedOperationException();
    }
    
    public boolean addAll(Collection<? extends K> param1Collection) {
      throw new UnsupportedOperationException();
    }
    
    public void clear() {
      this.c.a();
    }
    
    public boolean contains(Object param1Object) {
      boolean bool;
      if (this.c.a(param1Object) >= 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public boolean containsAll(Collection<?> param1Collection) {
      return h.a(this.c.b(), param1Collection);
    }
    
    public boolean equals(Object param1Object) {
      return h.a(this, param1Object);
    }
    
    public int hashCode() {
      int j = 0;
      for (int i = this.c.c() - 1; i >= 0; i--) {
        h h1 = this.c;
        int k = 0;
        Object object = h1.a(i, 0);
        if (object != null)
          k = object.hashCode(); 
        j += k;
      } 
      return j;
    }
    
    public boolean isEmpty() {
      boolean bool;
      if (this.c.c() == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public Iterator<K> iterator() {
      return new h.a<K>(this.c, 0);
    }
    
    public boolean remove(Object param1Object) {
      int i = this.c.a(param1Object);
      if (i >= 0) {
        this.c.a(i);
        return true;
      } 
      return false;
    }
    
    public boolean removeAll(Collection<?> param1Collection) {
      return h.b(this.c.b(), param1Collection);
    }
    
    public boolean retainAll(Collection<?> param1Collection) {
      return h.c(this.c.b(), param1Collection);
    }
    
    public int size() {
      return this.c.c();
    }
    
    public Object[] toArray() {
      return this.c.b(0);
    }
    
    public <T> T[] toArray(T[] param1ArrayOfT) {
      return (T[])this.c.a((Object[])param1ArrayOfT, 0);
    }
  }
  
  final class d implements Iterator<Map.Entry<K, V>>, Map.Entry<K, V> {
    int c;
    
    int d;
    
    boolean e = false;
    
    final h f;
    
    d(h this$0) {
      this.c = this$0.c() - 1;
      this.d = -1;
    }
    
    public boolean equals(Object param1Object) {
      if (this.e) {
        boolean bool1 = param1Object instanceof Map.Entry;
        boolean bool = false;
        if (!bool1)
          return false; 
        param1Object = param1Object;
        if (c.a(param1Object.getKey(), this.f.a(this.d, 0)) && c.a(param1Object.getValue(), this.f.a(this.d, 1)))
          bool = true; 
        return bool;
      } 
      throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }
    
    public K getKey() {
      if (this.e)
        return (K)this.f.a(this.d, 0); 
      throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }
    
    public V getValue() {
      if (this.e)
        return (V)this.f.a(this.d, 1); 
      throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }
    
    public boolean hasNext() {
      boolean bool;
      if (this.d < this.c) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public int hashCode() {
      if (this.e) {
        h h1 = this.f;
        int i = this.d;
        int j = 0;
        Object object2 = h1.a(i, 0);
        Object object1 = this.f.a(this.d, 1);
        if (object2 == null) {
          i = 0;
        } else {
          i = object2.hashCode();
        } 
        if (object1 != null)
          j = object1.hashCode(); 
        return j ^ i;
      } 
      throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }
    
    public Map.Entry<K, V> next() {
      if (hasNext()) {
        this.d++;
        this.e = true;
        return this;
      } 
      throw new NoSuchElementException();
    }
    
    public void remove() {
      if (this.e) {
        this.f.a(this.d);
        this.d--;
        this.c--;
        this.e = false;
        return;
      } 
      throw new IllegalStateException();
    }
    
    public V setValue(V param1V) {
      if (this.e)
        return (V)this.f.a(this.d, param1V); 
      throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(getKey());
      stringBuilder.append("=");
      stringBuilder.append(getValue());
      return stringBuilder.toString();
    }
  }
  
  final class e implements Collection<V> {
    final h c;
    
    e(h this$0) {}
    
    public boolean add(V param1V) {
      throw new UnsupportedOperationException();
    }
    
    public boolean addAll(Collection<? extends V> param1Collection) {
      throw new UnsupportedOperationException();
    }
    
    public void clear() {
      this.c.a();
    }
    
    public boolean contains(Object param1Object) {
      boolean bool;
      if (this.c.b(param1Object) >= 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public boolean containsAll(Collection<?> param1Collection) {
      Iterator<?> iterator = param1Collection.iterator();
      while (iterator.hasNext()) {
        if (!contains(iterator.next()))
          return false; 
      } 
      return true;
    }
    
    public boolean isEmpty() {
      boolean bool;
      if (this.c.c() == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public Iterator<V> iterator() {
      return new h.a<V>(this.c, 1);
    }
    
    public boolean remove(Object param1Object) {
      int i = this.c.b(param1Object);
      if (i >= 0) {
        this.c.a(i);
        return true;
      } 
      return false;
    }
    
    public boolean removeAll(Collection<?> param1Collection) {
      int j = this.c.c();
      boolean bool = false;
      int i = 0;
      while (i < j) {
        int k = j;
        int m = i;
        if (param1Collection.contains(this.c.a(i, 1))) {
          this.c.a(i);
          m = i - 1;
          k = j - 1;
          bool = true;
        } 
        i = m + 1;
        j = k;
      } 
      return bool;
    }
    
    public boolean retainAll(Collection<?> param1Collection) {
      int j = this.c.c();
      boolean bool = false;
      int i = 0;
      while (i < j) {
        int m = j;
        int k = i;
        if (!param1Collection.contains(this.c.a(i, 1))) {
          this.c.a(i);
          k = i - 1;
          m = j - 1;
          bool = true;
        } 
        i = k + 1;
        j = m;
      } 
      return bool;
    }
    
    public int size() {
      return this.c.c();
    }
    
    public Object[] toArray() {
      return this.c.b(1);
    }
    
    public <T> T[] toArray(T[] param1ArrayOfT) {
      return (T[])this.c.a((Object[])param1ArrayOfT, 1);
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\g\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */