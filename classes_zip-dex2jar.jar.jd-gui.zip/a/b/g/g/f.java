package a.b.g.g;

public class f<E> implements Cloneable {
  private static final Object g = new Object();
  
  private boolean c = false;
  
  private long[] d;
  
  private Object[] e;
  
  private int f;
  
  public f() {
    this(10);
  }
  
  public f(int paramInt) {
    if (paramInt == 0) {
      this.d = c.b;
      this.e = c.c;
    } else {
      paramInt = c.c(paramInt);
      this.d = new long[paramInt];
      this.e = new Object[paramInt];
    } 
    this.f = 0;
  }
  
  private void c() {
    int k = this.f;
    int j = 0;
    long[] arrayOfLong = this.d;
    Object[] arrayOfObject = this.e;
    int i = 0;
    while (i < k) {
      Object object = arrayOfObject[i];
      int m = j;
      if (object != g) {
        if (i != j) {
          arrayOfLong[j] = arrayOfLong[i];
          arrayOfObject[j] = object;
          arrayOfObject[i] = null;
        } 
        m = j + 1;
      } 
      i++;
      j = m;
    } 
    this.c = false;
    this.f = j;
  }
  
  public long a(int paramInt) {
    if (this.c)
      c(); 
    return this.d[paramInt];
  }
  
  public void a() {
    int i = this.f;
    Object[] arrayOfObject = this.e;
    for (byte b = 0; b < i; b++)
      arrayOfObject[b] = null; 
    this.f = 0;
    this.c = false;
  }
  
  public void a(long paramLong) {
    int i = c.a(this.d, this.f, paramLong);
    if (i >= 0) {
      Object[] arrayOfObject = this.e;
      Object object2 = arrayOfObject[i];
      Object object1 = g;
      if (object2 != object1) {
        arrayOfObject[i] = object1;
        this.c = true;
      } 
    } 
  }
  
  public void a(long paramLong, E paramE) {
    int i = this.f;
    if (i != 0 && paramLong <= this.d[i - 1]) {
      c(paramLong, paramE);
      return;
    } 
    if (this.c && this.f >= this.d.length)
      c(); 
    i = this.f;
    if (i >= this.d.length) {
      int j = c.c(i + 1);
      long[] arrayOfLong1 = new long[j];
      Object[] arrayOfObject1 = new Object[j];
      long[] arrayOfLong2 = this.d;
      System.arraycopy(arrayOfLong2, 0, arrayOfLong1, 0, arrayOfLong2.length);
      Object[] arrayOfObject2 = this.e;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.d = arrayOfLong1;
      this.e = arrayOfObject1;
    } 
    this.d[i] = paramLong;
    this.e[i] = paramE;
    this.f = i + 1;
  }
  
  public int b() {
    if (this.c)
      c(); 
    return this.f;
  }
  
  public E b(long paramLong) {
    return b(paramLong, null);
  }
  
  public E b(long paramLong, E paramE) {
    int i = c.a(this.d, this.f, paramLong);
    if (i >= 0) {
      Object[] arrayOfObject = this.e;
      if (arrayOfObject[i] != g)
        return (E)arrayOfObject[i]; 
    } 
    return paramE;
  }
  
  public void b(int paramInt) {
    Object[] arrayOfObject = this.e;
    Object object1 = arrayOfObject[paramInt];
    Object object2 = g;
    if (object1 != object2) {
      arrayOfObject[paramInt] = object2;
      this.c = true;
    } 
  }
  
  public int c(long paramLong) {
    if (this.c)
      c(); 
    return c.a(this.d, this.f, paramLong);
  }
  
  public E c(int paramInt) {
    if (this.c)
      c(); 
    return (E)this.e[paramInt];
  }
  
  public void c(long paramLong, E paramE) {
    int i = c.a(this.d, this.f, paramLong);
    if (i >= 0) {
      this.e[i] = paramE;
    } else {
      int j = i ^ 0xFFFFFFFF;
      if (j < this.f) {
        Object[] arrayOfObject = this.e;
        if (arrayOfObject[j] == g) {
          this.d[j] = paramLong;
          arrayOfObject[j] = paramE;
          return;
        } 
      } 
      i = j;
      if (this.c) {
        i = j;
        if (this.f >= this.d.length) {
          c();
          i = c.a(this.d, this.f, paramLong) ^ 0xFFFFFFFF;
        } 
      } 
      j = this.f;
      if (j >= this.d.length) {
        j = c.c(j + 1);
        long[] arrayOfLong1 = new long[j];
        Object[] arrayOfObject1 = new Object[j];
        long[] arrayOfLong2 = this.d;
        System.arraycopy(arrayOfLong2, 0, arrayOfLong1, 0, arrayOfLong2.length);
        Object[] arrayOfObject2 = this.e;
        System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
        this.d = arrayOfLong1;
        this.e = arrayOfObject1;
      } 
      j = this.f;
      if (j - i != 0) {
        long[] arrayOfLong = this.d;
        System.arraycopy(arrayOfLong, i, arrayOfLong, i + 1, j - i);
        Object[] arrayOfObject = this.e;
        System.arraycopy(arrayOfObject, i, arrayOfObject, i + 1, this.f - i);
      } 
      this.d[i] = paramLong;
      this.e[i] = paramE;
      this.f++;
    } 
  }
  
  public f<E> clone() {
    try {
      f<E> f1 = (f)super.clone();
      f1.d = (long[])this.d.clone();
      f1.e = (Object[])this.e.clone();
      return f1;
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      throw new AssertionError(cloneNotSupportedException);
    } 
  }
  
  public String toString() {
    if (b() <= 0)
      return "{}"; 
    StringBuilder stringBuilder = new StringBuilder(this.f * 28);
    stringBuilder.append('{');
    for (byte b = 0; b < this.f; b++) {
      if (b > 0)
        stringBuilder.append(", "); 
      stringBuilder.append(a(b));
      stringBuilder.append('=');
      E e = c(b);
      if (e != this) {
        stringBuilder.append(e);
      } else {
        stringBuilder.append("(this Map)");
      } 
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\g\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */