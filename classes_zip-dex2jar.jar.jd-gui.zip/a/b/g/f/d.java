package a.b.g.f;

import java.util.Locale;

public final class d {
  public static final c a = new e(b.a, false);
  
  public static final c b = new e(b.a, true);
  
  static {
    new e(a.b, false);
    f f = f.b;
  }
  
  static int a(int paramInt) {
    return (paramInt != 0) ? ((paramInt != 1 && paramInt != 2) ? 2 : 0) : 1;
  }
  
  static int b(int paramInt) {
    if (paramInt != 0)
      if (paramInt != 1 && paramInt != 2) {
        switch (paramInt) {
          default:
            return 2;
          case 16:
          case 17:
            return 0;
          case 14:
          case 15:
            break;
        } 
        return 1;
      }  
    return 1;
  }
  
  static {
    new e(null, false);
    new e(null, true);
  }
  
  private static class a implements c {
    static final a b = new a(true);
    
    private final boolean a;
    
    static {
      new a(false);
    }
    
    private a(boolean param1Boolean) {
      this.a = param1Boolean;
    }
    
    public int a(CharSequence param1CharSequence, int param1Int1, int param1Int2) {
      boolean bool = false;
      for (int i = param1Int1; i < param1Int1 + param1Int2; i++) {
        int j = d.a(Character.getDirectionality(param1CharSequence.charAt(i)));
        if (j != 0) {
          if (j == 1) {
            if (!this.a)
              return 1; 
            bool = true;
          } 
        } else {
          if (this.a)
            return 0; 
          bool = true;
        } 
      } 
      return bool ? this.a : 2;
    }
  }
  
  private static class b implements c {
    static final b a = new b();
    
    public int a(CharSequence param1CharSequence, int param1Int1, int param1Int2) {
      int j = 2;
      for (int i = param1Int1; i < param1Int1 + param1Int2 && j == 2; i++)
        j = d.b(Character.getDirectionality(param1CharSequence.charAt(i))); 
      return j;
    }
  }
  
  private static interface c {
    int a(CharSequence param1CharSequence, int param1Int1, int param1Int2);
  }
  
  private static abstract class d implements c {
    private final d.c a;
    
    d(d.c param1c) {
      this.a = param1c;
    }
    
    private boolean b(CharSequence param1CharSequence, int param1Int1, int param1Int2) {
      param1Int1 = this.a.a(param1CharSequence, param1Int1, param1Int2);
      return (param1Int1 != 0) ? ((param1Int1 != 1) ? a() : false) : true;
    }
    
    protected abstract boolean a();
    
    public boolean a(CharSequence param1CharSequence, int param1Int1, int param1Int2) {
      if (param1CharSequence != null && param1Int1 >= 0 && param1Int2 >= 0 && param1CharSequence.length() - param1Int2 >= param1Int1)
        return (this.a == null) ? a() : b(param1CharSequence, param1Int1, param1Int2); 
      throw new IllegalArgumentException();
    }
  }
  
  private static class e extends d {
    private final boolean b;
    
    e(d.c param1c, boolean param1Boolean) {
      super(param1c);
      this.b = param1Boolean;
    }
    
    protected boolean a() {
      return this.b;
    }
  }
  
  private static class f extends d {
    static final f b = new f();
    
    f() {
      super(null);
    }
    
    protected boolean a() {
      int i = e.b(Locale.getDefault());
      boolean bool = true;
      if (i != 1)
        bool = false; 
      return bool;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\f\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */