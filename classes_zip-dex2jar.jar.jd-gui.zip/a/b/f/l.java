package a.b.f;

import android.view.View;
import android.view.ViewGroup;

public class l {
  private ViewGroup a;
  
  private Runnable b;
  
  static l a(View paramView) {
    return (l)paramView.getTag(j.transition_current_scene);
  }
  
  static void a(View paramView, l paraml) {
    paramView.setTag(j.transition_current_scene, paraml);
  }
  
  public void a() {
    if (a((View)this.a) == this) {
      Runnable runnable = this.b;
      if (runnable != null)
        runnable.run(); 
    } 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */