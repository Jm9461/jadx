package a.b.f;

import android.os.IBinder;

class j0 implements l0 {
  private final IBinder a;
  
  j0(IBinder paramIBinder) {
    this.a = paramIBinder;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool;
    if (paramObject instanceof j0 && ((j0)paramObject).a.equals(this.a)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int hashCode() {
    return this.a.hashCode();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */