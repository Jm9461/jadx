package a.b.f;

import android.animation.TimeInterpolator;
import android.util.AndroidRuntimeException;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Iterator;

public class q extends m {
  private ArrayList<m> L = new ArrayList<m>();
  
  private boolean M = true;
  
  int N;
  
  boolean O = false;
  
  private int P = 0;
  
  private void r() {
    b b = new b(this);
    Iterator<m> iterator = this.L.iterator();
    while (iterator.hasNext())
      ((m)iterator.next()).a(b); 
    this.N = this.L.size();
  }
  
  public m a(int paramInt) {
    return (paramInt < 0 || paramInt >= this.L.size()) ? null : this.L.get(paramInt);
  }
  
  public q a(long paramLong) {
    super.a(paramLong);
    if (this.e >= 0L) {
      int i = this.L.size();
      for (byte b = 0; b < i; b++)
        ((m)this.L.get(b)).a(paramLong); 
    } 
    return this;
  }
  
  public q a(m.f paramf) {
    super.a(paramf);
    return this;
  }
  
  public q a(m paramm) {
    this.L.add(paramm);
    paramm.t = this;
    long l = this.e;
    if (l >= 0L)
      paramm.a(l); 
    if ((this.P & 0x1) != 0)
      paramm.a(d()); 
    if ((this.P & 0x2) != 0)
      paramm.a(g()); 
    if ((this.P & 0x4) != 0)
      paramm.a(f()); 
    if ((this.P & 0x8) != 0)
      paramm.a(c()); 
    return this;
  }
  
  public q a(TimeInterpolator paramTimeInterpolator) {
    this.P |= 0x1;
    ArrayList<m> arrayList = this.L;
    if (arrayList != null) {
      int i = arrayList.size();
      for (byte b = 0; b < i; b++)
        ((m)this.L.get(b)).a(paramTimeInterpolator); 
    } 
    super.a(paramTimeInterpolator);
    return this;
  }
  
  public q a(View paramView) {
    for (byte b = 0; b < this.L.size(); b++)
      ((m)this.L.get(b)).a(paramView); 
    super.a(paramView);
    return this;
  }
  
  String a(String paramString) {
    String str = super.a(paramString);
    for (byte b = 0; b < this.L.size(); b++) {
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str);
      stringBuilder2.append("\n");
      m m1 = this.L.get(b);
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(paramString);
      stringBuilder1.append("  ");
      stringBuilder2.append(m1.a(stringBuilder1.toString()));
      str = stringBuilder2.toString();
    } 
    return str;
  }
  
  public void a(g paramg) {
    super.a(paramg);
    this.P |= 0x4;
    for (byte b = 0; b < this.L.size(); b++)
      ((m)this.L.get(b)).a(paramg); 
  }
  
  public void a(m.e parame) {
    super.a(parame);
    this.P |= 0x8;
    int i = this.L.size();
    for (byte b = 0; b < i; b++)
      ((m)this.L.get(b)).a(parame); 
  }
  
  public void a(p paramp) {
    super.a(paramp);
    this.P |= 0x2;
    int i = this.L.size();
    for (byte b = 0; b < i; b++)
      ((m)this.L.get(b)).a(paramp); 
  }
  
  public void a(s params) {
    if (b(params.b))
      for (m m1 : this.L) {
        if (m1.b(params.b)) {
          m1.a(params);
          params.c.add(m1);
        } 
      }  
  }
  
  protected void a(ViewGroup paramViewGroup, t paramt1, t paramt2, ArrayList<s> paramArrayList1, ArrayList<s> paramArrayList2) {
    long l = h();
    int i = this.L.size();
    for (byte b = 0; b < i; b++) {
      m m1 = this.L.get(b);
      if (l > 0L && (this.M || b == 0)) {
        long l1 = m1.h();
        if (l1 > 0L) {
          m1.b(l + l1);
        } else {
          m1.b(l);
        } 
      } 
      m1.a(paramViewGroup, paramt1, paramt2, paramArrayList1, paramArrayList2);
    } 
  }
  
  public q b(int paramInt) {
    if (paramInt != 0) {
      if (paramInt == 1) {
        this.M = false;
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid parameter for TransitionSet ordering: ");
        stringBuilder.append(paramInt);
        throw new AndroidRuntimeException(stringBuilder.toString());
      } 
    } else {
      this.M = true;
    } 
    return this;
  }
  
  public q b(long paramLong) {
    super.b(paramLong);
    return this;
  }
  
  public q b(m.f paramf) {
    super.b(paramf);
    return this;
  }
  
  void b(s params) {
    super.b(params);
    int i = this.L.size();
    for (byte b = 0; b < i; b++)
      ((m)this.L.get(b)).b(params); 
  }
  
  public void c(s params) {
    if (b(params.b))
      for (m m1 : this.L) {
        if (m1.b(params.b)) {
          m1.c(params);
          params.c.add(m1);
        } 
      }  
  }
  
  public void c(View paramView) {
    super.c(paramView);
    int i = this.L.size();
    for (byte b = 0; b < i; b++)
      ((m)this.L.get(b)).c(paramView); 
  }
  
  public m clone() {
    q q1 = (q)super.clone();
    q1.L = new ArrayList<m>();
    int i = this.L.size();
    for (byte b = 0; b < i; b++)
      q1.a(((m)this.L.get(b)).clone()); 
    return q1;
  }
  
  public q d(View paramView) {
    for (byte b = 0; b < this.L.size(); b++)
      ((m)this.L.get(b)).d(paramView); 
    super.d(paramView);
    return this;
  }
  
  public void e(View paramView) {
    super.e(paramView);
    int i = this.L.size();
    for (byte b = 0; b < i; b++)
      ((m)this.L.get(b)).e(paramView); 
  }
  
  protected void o() {
    if (this.L.isEmpty()) {
      p();
      a();
      return;
    } 
    r();
    if (!this.M) {
      for (byte b = 1; b < this.L.size(); b++)
        ((m)this.L.get(b - 1)).a(new a(this, this.L.get(b))); 
      m m1 = this.L.get(0);
      if (m1 != null)
        m1.o(); 
    } else {
      Iterator<m> iterator = this.L.iterator();
      while (iterator.hasNext())
        ((m)iterator.next()).o(); 
    } 
  }
  
  public int q() {
    return this.L.size();
  }
  
  class a extends n {
    final m a;
    
    a(q this$0, m param1m) {}
    
    public void b(m param1m) {
      this.a.o();
      param1m.b(this);
    }
  }
  
  static class b extends n {
    q a;
    
    b(q param1q) {
      this.a = param1q;
    }
    
    public void b(m param1m) {
      q q1 = this.a;
      q1.N--;
      if (q1.N == 0) {
        q1.O = false;
        q1.a();
      } 
      param1m.b(this);
    }
    
    public void c(m param1m) {
      param1m = this.a;
      if (!((q)param1m).O) {
        param1m.p();
        this.a.O = true;
      } 
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */