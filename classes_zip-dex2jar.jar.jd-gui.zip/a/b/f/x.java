package a.b.f;

import android.os.Build;
import android.view.ViewGroup;

class x {
  static w a(ViewGroup paramViewGroup) {
    return (w)((Build.VERSION.SDK_INT >= 18) ? new v(paramViewGroup) : u.a(paramViewGroup));
  }
  
  static void a(ViewGroup paramViewGroup, boolean paramBoolean) {
    if (Build.VERSION.SDK_INT >= 18) {
      z.a(paramViewGroup, paramBoolean);
    } else {
      y.a(paramViewGroup, paramBoolean);
    } 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */