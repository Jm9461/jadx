package a.b.f;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v4.view.u;
import android.util.Property;
import android.view.View;
import android.view.ViewGroup;

public class c extends m {
  private static final String[] O = new String[] { "android:changeBounds:bounds", "android:changeBounds:clip", "android:changeBounds:parent", "android:changeBounds:windowX", "android:changeBounds:windowY" };
  
  private static final Property<Drawable, PointF> P = new b(PointF.class, "boundsOrigin");
  
  private static final Property<k, PointF> Q = new c(PointF.class, "topLeft");
  
  private static final Property<k, PointF> R = new d(PointF.class, "bottomRight");
  
  private static final Property<View, PointF> S = new e(PointF.class, "bottomRight");
  
  private static final Property<View, PointF> T = new f(PointF.class, "topLeft");
  
  private static final Property<View, PointF> U = new g(PointF.class, "position");
  
  private static k V = new k();
  
  private int[] L = new int[2];
  
  private boolean M = false;
  
  private boolean N = false;
  
  private boolean a(View paramView1, View paramView2) {
    boolean bool = true;
    if (this.N) {
      boolean bool1 = true;
      bool = true;
      s s = a(paramView1, true);
      if (s == null) {
        if (paramView1 != paramView2)
          bool = false; 
      } else if (paramView2 == s.b) {
        bool = bool1;
      } else {
        bool = false;
      } 
    } 
    return bool;
  }
  
  private void d(s params) {
    View view = params.b;
    if (u.y(view) || view.getWidth() != 0 || view.getHeight() != 0) {
      params.a.put("android:changeBounds:bounds", new Rect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom()));
      params.a.put("android:changeBounds:parent", params.b.getParent());
      if (this.N) {
        params.b.getLocationInWindow(this.L);
        params.a.put("android:changeBounds:windowX", Integer.valueOf(this.L[0]));
        params.a.put("android:changeBounds:windowY", Integer.valueOf(this.L[1]));
      } 
      if (this.M)
        params.a.put("android:changeBounds:clip", u.e(view)); 
    } 
  }
  
  public Animator a(ViewGroup paramViewGroup, s params1, s params2) {
    // Byte code:
    //   0: aload_2
    //   1: ifnull -> 1109
    //   4: aload_3
    //   5: ifnonnull -> 11
    //   8: goto -> 1109
    //   11: aload_2
    //   12: getfield a : Ljava/util/Map;
    //   15: astore #20
    //   17: aload_3
    //   18: getfield a : Ljava/util/Map;
    //   21: astore #21
    //   23: aload #20
    //   25: ldc 'android:changeBounds:parent'
    //   27: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   32: checkcast android/view/ViewGroup
    //   35: astore #20
    //   37: aload #21
    //   39: ldc 'android:changeBounds:parent'
    //   41: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   46: checkcast android/view/ViewGroup
    //   49: astore #22
    //   51: aload #20
    //   53: ifnull -> 1107
    //   56: aload #22
    //   58: ifnonnull -> 64
    //   61: goto -> 1107
    //   64: aload_3
    //   65: getfield b : Landroid/view/View;
    //   68: astore #21
    //   70: aload_0
    //   71: aload #20
    //   73: aload #22
    //   75: invokespecial a : (Landroid/view/View;Landroid/view/View;)Z
    //   78: ifeq -> 858
    //   81: aload_2
    //   82: getfield a : Ljava/util/Map;
    //   85: ldc 'android:changeBounds:bounds'
    //   87: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   92: checkcast android/graphics/Rect
    //   95: astore_1
    //   96: aload_3
    //   97: getfield a : Ljava/util/Map;
    //   100: ldc 'android:changeBounds:bounds'
    //   102: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   107: checkcast android/graphics/Rect
    //   110: astore #20
    //   112: aload_1
    //   113: getfield left : I
    //   116: istore #10
    //   118: aload #20
    //   120: getfield left : I
    //   123: istore #8
    //   125: aload_1
    //   126: getfield top : I
    //   129: istore #11
    //   131: aload #20
    //   133: getfield top : I
    //   136: istore #14
    //   138: aload_1
    //   139: getfield right : I
    //   142: istore #19
    //   144: aload #20
    //   146: getfield right : I
    //   149: istore #17
    //   151: aload_1
    //   152: getfield bottom : I
    //   155: istore #18
    //   157: aload #20
    //   159: getfield bottom : I
    //   162: istore #15
    //   164: iload #19
    //   166: iload #10
    //   168: isub
    //   169: istore #9
    //   171: iload #18
    //   173: iload #11
    //   175: isub
    //   176: istore #13
    //   178: iload #17
    //   180: iload #8
    //   182: isub
    //   183: istore #16
    //   185: iload #15
    //   187: iload #14
    //   189: isub
    //   190: istore #12
    //   192: aload_2
    //   193: getfield a : Ljava/util/Map;
    //   196: ldc 'android:changeBounds:clip'
    //   198: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   203: checkcast android/graphics/Rect
    //   206: astore_2
    //   207: aload_3
    //   208: getfield a : Ljava/util/Map;
    //   211: ldc 'android:changeBounds:clip'
    //   213: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   218: checkcast android/graphics/Rect
    //   221: astore #20
    //   223: iconst_0
    //   224: istore #6
    //   226: iconst_0
    //   227: istore #7
    //   229: iload #9
    //   231: ifeq -> 239
    //   234: iload #13
    //   236: ifne -> 257
    //   239: iload #6
    //   241: istore #5
    //   243: iload #16
    //   245: ifeq -> 304
    //   248: iload #6
    //   250: istore #5
    //   252: iload #12
    //   254: ifeq -> 304
    //   257: iload #10
    //   259: iload #8
    //   261: if_icmpne -> 275
    //   264: iload #7
    //   266: istore #6
    //   268: iload #11
    //   270: iload #14
    //   272: if_icmpeq -> 280
    //   275: iconst_0
    //   276: iconst_1
    //   277: iadd
    //   278: istore #6
    //   280: iload #19
    //   282: iload #17
    //   284: if_icmpne -> 298
    //   287: iload #6
    //   289: istore #5
    //   291: iload #18
    //   293: iload #15
    //   295: if_icmpeq -> 304
    //   298: iload #6
    //   300: iconst_1
    //   301: iadd
    //   302: istore #5
    //   304: aload_2
    //   305: ifnull -> 317
    //   308: aload_2
    //   309: aload #20
    //   311: invokevirtual equals : (Ljava/lang/Object;)Z
    //   314: ifeq -> 334
    //   317: iload #5
    //   319: istore #6
    //   321: aload_2
    //   322: ifnonnull -> 340
    //   325: iload #5
    //   327: istore #6
    //   329: aload #20
    //   331: ifnull -> 340
    //   334: iload #5
    //   336: iconst_1
    //   337: iadd
    //   338: istore #6
    //   340: iload #6
    //   342: ifle -> 855
    //   345: aload_0
    //   346: getfield M : Z
    //   349: ifne -> 611
    //   352: aload #21
    //   354: iload #10
    //   356: iload #11
    //   358: iload #19
    //   360: iload #18
    //   362: invokestatic a : (Landroid/view/View;IIII)V
    //   365: iload #6
    //   367: iconst_2
    //   368: if_icmpne -> 528
    //   371: iload #9
    //   373: iload #16
    //   375: if_icmpne -> 418
    //   378: iload #13
    //   380: iload #12
    //   382: if_icmpne -> 418
    //   385: aload_0
    //   386: invokevirtual f : ()La/b/f/g;
    //   389: iload #10
    //   391: i2f
    //   392: iload #11
    //   394: i2f
    //   395: iload #8
    //   397: i2f
    //   398: iload #14
    //   400: i2f
    //   401: invokevirtual a : (FFFF)Landroid/graphics/Path;
    //   404: astore_1
    //   405: aload #21
    //   407: getstatic a/b/f/c.U : Landroid/util/Property;
    //   410: aload_1
    //   411: invokestatic a : (Ljava/lang/Object;Landroid/util/Property;Landroid/graphics/Path;)Landroid/animation/ObjectAnimator;
    //   414: astore_1
    //   415: goto -> 814
    //   418: new a/b/f/c$k
    //   421: dup
    //   422: aload #21
    //   424: invokespecial <init> : (Landroid/view/View;)V
    //   427: astore_2
    //   428: aload_0
    //   429: invokevirtual f : ()La/b/f/g;
    //   432: iload #10
    //   434: i2f
    //   435: iload #11
    //   437: i2f
    //   438: iload #8
    //   440: i2f
    //   441: iload #14
    //   443: i2f
    //   444: invokevirtual a : (FFFF)Landroid/graphics/Path;
    //   447: astore_1
    //   448: aload_2
    //   449: getstatic a/b/f/c.Q : Landroid/util/Property;
    //   452: aload_1
    //   453: invokestatic a : (Ljava/lang/Object;Landroid/util/Property;Landroid/graphics/Path;)Landroid/animation/ObjectAnimator;
    //   456: astore_3
    //   457: aload_0
    //   458: invokevirtual f : ()La/b/f/g;
    //   461: iload #19
    //   463: i2f
    //   464: iload #18
    //   466: i2f
    //   467: iload #17
    //   469: i2f
    //   470: iload #15
    //   472: i2f
    //   473: invokevirtual a : (FFFF)Landroid/graphics/Path;
    //   476: astore_1
    //   477: aload_2
    //   478: getstatic a/b/f/c.R : Landroid/util/Property;
    //   481: aload_1
    //   482: invokestatic a : (Ljava/lang/Object;Landroid/util/Property;Landroid/graphics/Path;)Landroid/animation/ObjectAnimator;
    //   485: astore #20
    //   487: new android/animation/AnimatorSet
    //   490: dup
    //   491: invokespecial <init> : ()V
    //   494: astore_1
    //   495: aload_1
    //   496: iconst_2
    //   497: anewarray android/animation/Animator
    //   500: dup
    //   501: iconst_0
    //   502: aload_3
    //   503: aastore
    //   504: dup
    //   505: iconst_1
    //   506: aload #20
    //   508: aastore
    //   509: invokevirtual playTogether : ([Landroid/animation/Animator;)V
    //   512: aload_1
    //   513: new a/b/f/c$h
    //   516: dup
    //   517: aload_0
    //   518: aload_2
    //   519: invokespecial <init> : (La/b/f/c;La/b/f/c$k;)V
    //   522: invokevirtual addListener : (Landroid/animation/Animator$AnimatorListener;)V
    //   525: goto -> 814
    //   528: iload #10
    //   530: iload #8
    //   532: if_icmpne -> 578
    //   535: iload #11
    //   537: iload #14
    //   539: if_icmpeq -> 545
    //   542: goto -> 578
    //   545: aload_0
    //   546: invokevirtual f : ()La/b/f/g;
    //   549: iload #19
    //   551: i2f
    //   552: iload #18
    //   554: i2f
    //   555: iload #17
    //   557: i2f
    //   558: iload #15
    //   560: i2f
    //   561: invokevirtual a : (FFFF)Landroid/graphics/Path;
    //   564: astore_1
    //   565: aload #21
    //   567: getstatic a/b/f/c.S : Landroid/util/Property;
    //   570: aload_1
    //   571: invokestatic a : (Ljava/lang/Object;Landroid/util/Property;Landroid/graphics/Path;)Landroid/animation/ObjectAnimator;
    //   574: astore_1
    //   575: goto -> 814
    //   578: aload_0
    //   579: invokevirtual f : ()La/b/f/g;
    //   582: iload #10
    //   584: i2f
    //   585: iload #11
    //   587: i2f
    //   588: iload #8
    //   590: i2f
    //   591: iload #14
    //   593: i2f
    //   594: invokevirtual a : (FFFF)Landroid/graphics/Path;
    //   597: astore_1
    //   598: aload #21
    //   600: getstatic a/b/f/c.T : Landroid/util/Property;
    //   603: aload_1
    //   604: invokestatic a : (Ljava/lang/Object;Landroid/util/Property;Landroid/graphics/Path;)Landroid/animation/ObjectAnimator;
    //   607: astore_1
    //   608: goto -> 814
    //   611: iload #9
    //   613: iload #16
    //   615: invokestatic max : (II)I
    //   618: istore #5
    //   620: aload #21
    //   622: iload #10
    //   624: iload #11
    //   626: iload #10
    //   628: iload #5
    //   630: iadd
    //   631: iload #11
    //   633: iload #13
    //   635: iload #12
    //   637: invokestatic max : (II)I
    //   640: iadd
    //   641: invokestatic a : (Landroid/view/View;IIII)V
    //   644: iload #10
    //   646: iload #8
    //   648: if_icmpne -> 666
    //   651: iload #11
    //   653: iload #14
    //   655: if_icmpeq -> 661
    //   658: goto -> 666
    //   661: aconst_null
    //   662: astore_1
    //   663: goto -> 696
    //   666: aload_0
    //   667: invokevirtual f : ()La/b/f/g;
    //   670: iload #10
    //   672: i2f
    //   673: iload #11
    //   675: i2f
    //   676: iload #8
    //   678: i2f
    //   679: iload #14
    //   681: i2f
    //   682: invokevirtual a : (FFFF)Landroid/graphics/Path;
    //   685: astore_1
    //   686: aload #21
    //   688: getstatic a/b/f/c.U : Landroid/util/Property;
    //   691: aload_1
    //   692: invokestatic a : (Ljava/lang/Object;Landroid/util/Property;Landroid/graphics/Path;)Landroid/animation/ObjectAnimator;
    //   695: astore_1
    //   696: aload_2
    //   697: ifnonnull -> 717
    //   700: new android/graphics/Rect
    //   703: dup
    //   704: iconst_0
    //   705: iconst_0
    //   706: iload #9
    //   708: iload #13
    //   710: invokespecial <init> : (IIII)V
    //   713: astore_2
    //   714: goto -> 717
    //   717: aload #20
    //   719: ifnonnull -> 739
    //   722: new android/graphics/Rect
    //   725: dup
    //   726: iconst_0
    //   727: iconst_0
    //   728: iload #16
    //   730: iload #12
    //   732: invokespecial <init> : (IIII)V
    //   735: astore_3
    //   736: goto -> 742
    //   739: aload #20
    //   741: astore_3
    //   742: aload_2
    //   743: aload_3
    //   744: invokevirtual equals : (Ljava/lang/Object;)Z
    //   747: ifne -> 806
    //   750: aload #21
    //   752: aload_2
    //   753: invokestatic a : (Landroid/view/View;Landroid/graphics/Rect;)V
    //   756: aload #21
    //   758: ldc 'clipBounds'
    //   760: getstatic a/b/f/c.V : La/b/f/k;
    //   763: iconst_2
    //   764: anewarray java/lang/Object
    //   767: dup
    //   768: iconst_0
    //   769: aload_2
    //   770: aastore
    //   771: dup
    //   772: iconst_1
    //   773: aload_3
    //   774: aastore
    //   775: invokestatic ofObject : (Ljava/lang/Object;Ljava/lang/String;Landroid/animation/TypeEvaluator;[Ljava/lang/Object;)Landroid/animation/ObjectAnimator;
    //   778: astore_2
    //   779: aload_2
    //   780: new a/b/f/c$i
    //   783: dup
    //   784: aload_0
    //   785: aload #21
    //   787: aload #20
    //   789: iload #8
    //   791: iload #14
    //   793: iload #17
    //   795: iload #15
    //   797: invokespecial <init> : (La/b/f/c;Landroid/view/View;Landroid/graphics/Rect;IIII)V
    //   800: invokevirtual addListener : (Landroid/animation/Animator$AnimatorListener;)V
    //   803: goto -> 808
    //   806: aconst_null
    //   807: astore_2
    //   808: aload_1
    //   809: aload_2
    //   810: invokestatic a : (Landroid/animation/Animator;Landroid/animation/Animator;)Landroid/animation/Animator;
    //   813: astore_1
    //   814: aload #21
    //   816: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   819: instanceof android/view/ViewGroup
    //   822: ifeq -> 853
    //   825: aload #21
    //   827: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   830: checkcast android/view/ViewGroup
    //   833: astore_2
    //   834: aload_2
    //   835: iconst_1
    //   836: invokestatic a : (Landroid/view/ViewGroup;Z)V
    //   839: aload_0
    //   840: new a/b/f/c$j
    //   843: dup
    //   844: aload_0
    //   845: aload_2
    //   846: invokespecial <init> : (La/b/f/c;Landroid/view/ViewGroup;)V
    //   849: invokevirtual a : (La/b/f/m$f;)La/b/f/m;
    //   852: pop
    //   853: aload_1
    //   854: areturn
    //   855: goto -> 951
    //   858: aload_2
    //   859: getfield a : Ljava/util/Map;
    //   862: ldc 'android:changeBounds:windowX'
    //   864: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   869: checkcast java/lang/Integer
    //   872: invokevirtual intValue : ()I
    //   875: istore #8
    //   877: aload_2
    //   878: getfield a : Ljava/util/Map;
    //   881: ldc 'android:changeBounds:windowY'
    //   883: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   888: checkcast java/lang/Integer
    //   891: invokevirtual intValue : ()I
    //   894: istore #5
    //   896: aload_3
    //   897: getfield a : Ljava/util/Map;
    //   900: ldc 'android:changeBounds:windowX'
    //   902: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   907: checkcast java/lang/Integer
    //   910: invokevirtual intValue : ()I
    //   913: istore #7
    //   915: aload_3
    //   916: getfield a : Ljava/util/Map;
    //   919: ldc 'android:changeBounds:windowY'
    //   921: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   926: checkcast java/lang/Integer
    //   929: invokevirtual intValue : ()I
    //   932: istore #6
    //   934: iload #8
    //   936: iload #7
    //   938: if_icmpne -> 953
    //   941: iload #5
    //   943: iload #6
    //   945: if_icmpeq -> 951
    //   948: goto -> 953
    //   951: aconst_null
    //   952: areturn
    //   953: aload_1
    //   954: aload_0
    //   955: getfield L : [I
    //   958: invokevirtual getLocationInWindow : ([I)V
    //   961: aload #21
    //   963: invokevirtual getWidth : ()I
    //   966: aload #21
    //   968: invokevirtual getHeight : ()I
    //   971: getstatic android/graphics/Bitmap$Config.ARGB_8888 : Landroid/graphics/Bitmap$Config;
    //   974: invokestatic createBitmap : (IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;
    //   977: astore_2
    //   978: aload #21
    //   980: new android/graphics/Canvas
    //   983: dup
    //   984: aload_2
    //   985: invokespecial <init> : (Landroid/graphics/Bitmap;)V
    //   988: invokevirtual draw : (Landroid/graphics/Canvas;)V
    //   991: new android/graphics/drawable/BitmapDrawable
    //   994: dup
    //   995: aload_2
    //   996: invokespecial <init> : (Landroid/graphics/Bitmap;)V
    //   999: astore_2
    //   1000: aload #21
    //   1002: invokestatic c : (Landroid/view/View;)F
    //   1005: fstore #4
    //   1007: aload #21
    //   1009: fconst_0
    //   1010: invokestatic a : (Landroid/view/View;F)V
    //   1013: aload_1
    //   1014: invokestatic b : (Landroid/view/View;)La/b/f/c0;
    //   1017: aload_2
    //   1018: invokeinterface a : (Landroid/graphics/drawable/Drawable;)V
    //   1023: aload_0
    //   1024: invokevirtual f : ()La/b/f/g;
    //   1027: astore #20
    //   1029: aload_0
    //   1030: getfield L : [I
    //   1033: astore_3
    //   1034: aload #20
    //   1036: iload #8
    //   1038: aload_3
    //   1039: iconst_0
    //   1040: iaload
    //   1041: isub
    //   1042: i2f
    //   1043: iload #5
    //   1045: aload_3
    //   1046: iconst_1
    //   1047: iaload
    //   1048: isub
    //   1049: i2f
    //   1050: iload #7
    //   1052: aload_3
    //   1053: iconst_0
    //   1054: iaload
    //   1055: isub
    //   1056: i2f
    //   1057: iload #6
    //   1059: aload_3
    //   1060: iconst_1
    //   1061: iaload
    //   1062: isub
    //   1063: i2f
    //   1064: invokevirtual a : (FFFF)Landroid/graphics/Path;
    //   1067: astore_3
    //   1068: aload_2
    //   1069: iconst_1
    //   1070: anewarray android/animation/PropertyValuesHolder
    //   1073: dup
    //   1074: iconst_0
    //   1075: getstatic a/b/f/c.P : Landroid/util/Property;
    //   1078: aload_3
    //   1079: invokestatic a : (Landroid/util/Property;Landroid/graphics/Path;)Landroid/animation/PropertyValuesHolder;
    //   1082: aastore
    //   1083: invokestatic ofPropertyValuesHolder : (Ljava/lang/Object;[Landroid/animation/PropertyValuesHolder;)Landroid/animation/ObjectAnimator;
    //   1086: astore_3
    //   1087: aload_3
    //   1088: new a/b/f/c$a
    //   1091: dup
    //   1092: aload_0
    //   1093: aload_1
    //   1094: aload_2
    //   1095: aload #21
    //   1097: fload #4
    //   1099: invokespecial <init> : (La/b/f/c;Landroid/view/ViewGroup;Landroid/graphics/drawable/BitmapDrawable;Landroid/view/View;F)V
    //   1102: invokevirtual addListener : (Landroid/animation/Animator$AnimatorListener;)V
    //   1105: aload_3
    //   1106: areturn
    //   1107: aconst_null
    //   1108: areturn
    //   1109: aconst_null
    //   1110: areturn
  }
  
  public void a(s params) {
    d(params);
  }
  
  public void c(s params) {
    d(params);
  }
  
  public String[] n() {
    return O;
  }
  
  class a extends AnimatorListenerAdapter {
    final ViewGroup a;
    
    final BitmapDrawable b;
    
    final View c;
    
    final float d;
    
    a(c this$0, ViewGroup param1ViewGroup, BitmapDrawable param1BitmapDrawable, View param1View, float param1Float) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      d0.b((View)this.a).b((Drawable)this.b);
      d0.a(this.c, this.d);
    }
  }
  
  static final class b extends Property<Drawable, PointF> {
    private Rect a = new Rect();
    
    b(Class param1Class, String param1String) {
      super(param1Class, param1String);
    }
    
    public PointF a(Drawable param1Drawable) {
      param1Drawable.copyBounds(this.a);
      Rect rect = this.a;
      return new PointF(rect.left, rect.top);
    }
    
    public void a(Drawable param1Drawable, PointF param1PointF) {
      param1Drawable.copyBounds(this.a);
      this.a.offsetTo(Math.round(param1PointF.x), Math.round(param1PointF.y));
      param1Drawable.setBounds(this.a);
    }
  }
  
  static final class c extends Property<k, PointF> {
    c(Class param1Class, String param1String) {
      super(param1Class, param1String);
    }
    
    public PointF a(c.k param1k) {
      return null;
    }
    
    public void a(c.k param1k, PointF param1PointF) {
      param1k.b(param1PointF);
    }
  }
  
  static final class d extends Property<k, PointF> {
    d(Class param1Class, String param1String) {
      super(param1Class, param1String);
    }
    
    public PointF a(c.k param1k) {
      return null;
    }
    
    public void a(c.k param1k, PointF param1PointF) {
      param1k.a(param1PointF);
    }
  }
  
  static final class e extends Property<View, PointF> {
    e(Class param1Class, String param1String) {
      super(param1Class, param1String);
    }
    
    public PointF a(View param1View) {
      return null;
    }
    
    public void a(View param1View, PointF param1PointF) {
      d0.a(param1View, param1View.getLeft(), param1View.getTop(), Math.round(param1PointF.x), Math.round(param1PointF.y));
    }
  }
  
  static final class f extends Property<View, PointF> {
    f(Class param1Class, String param1String) {
      super(param1Class, param1String);
    }
    
    public PointF a(View param1View) {
      return null;
    }
    
    public void a(View param1View, PointF param1PointF) {
      d0.a(param1View, Math.round(param1PointF.x), Math.round(param1PointF.y), param1View.getRight(), param1View.getBottom());
    }
  }
  
  static final class g extends Property<View, PointF> {
    g(Class param1Class, String param1String) {
      super(param1Class, param1String);
    }
    
    public PointF a(View param1View) {
      return null;
    }
    
    public void a(View param1View, PointF param1PointF) {
      int j = Math.round(param1PointF.x);
      int i = Math.round(param1PointF.y);
      d0.a(param1View, j, i, param1View.getWidth() + j, param1View.getHeight() + i);
    }
  }
  
  class h extends AnimatorListenerAdapter {
    final c.k a;
    
    private c.k mViewBounds = this.a;
    
    h(c this$0, c.k param1k) {}
  }
  
  class i extends AnimatorListenerAdapter {
    private boolean a;
    
    final View b;
    
    final Rect c;
    
    final int d;
    
    final int e;
    
    final int f;
    
    final int g;
    
    i(c this$0, View param1View, Rect param1Rect, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      this.a = true;
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      if (!this.a) {
        u.a(this.b, this.c);
        d0.a(this.b, this.d, this.e, this.f, this.g);
      } 
    }
  }
  
  class j extends n {
    boolean a = false;
    
    final ViewGroup b;
    
    j(c this$0, ViewGroup param1ViewGroup) {}
    
    public void a(m param1m) {
      x.a(this.b, false);
    }
    
    public void b(m param1m) {
      if (!this.a)
        x.a(this.b, false); 
      param1m.b(this);
    }
    
    public void d(m param1m) {
      x.a(this.b, true);
    }
  }
  
  private static class k {
    private int a;
    
    private int b;
    
    private int c;
    
    private int d;
    
    private View e;
    
    private int f;
    
    private int g;
    
    k(View param1View) {
      this.e = param1View;
    }
    
    private void a() {
      d0.a(this.e, this.a, this.b, this.c, this.d);
      this.f = 0;
      this.g = 0;
    }
    
    void a(PointF param1PointF) {
      this.c = Math.round(param1PointF.x);
      this.d = Math.round(param1PointF.y);
      this.g++;
      if (this.f == this.g)
        a(); 
    }
    
    void b(PointF param1PointF) {
      this.a = Math.round(param1PointF.x);
      this.b = Math.round(param1PointF.y);
      this.f++;
      if (this.f == this.g)
        a(); 
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */