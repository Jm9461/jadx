package a.b.f;

import a.b.g.g.n;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.graphics.Path;
import android.support.v4.view.u;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public abstract class m implements Cloneable {
  private static final int[] I = new int[] { 2, 1, 3, 4 };
  
  private static final g J = new a();
  
  private static ThreadLocal<a.b.g.g.a<Animator, d>> K = new ThreadLocal<a.b.g.g.a<Animator, d>>();
  
  private boolean A = false;
  
  private boolean B = false;
  
  private ArrayList<f> C = null;
  
  private ArrayList<Animator> D = new ArrayList<Animator>();
  
  p E;
  
  private e F;
  
  private a.b.g.g.a<String, String> G;
  
  private g H = J;
  
  private String c = getClass().getName();
  
  private long d = -1L;
  
  long e = -1L;
  
  private TimeInterpolator f = null;
  
  ArrayList<Integer> g = new ArrayList<Integer>();
  
  ArrayList<View> h = new ArrayList<View>();
  
  private ArrayList<String> i = null;
  
  private ArrayList<Class> j = null;
  
  private ArrayList<Integer> k = null;
  
  private ArrayList<View> l = null;
  
  private ArrayList<Class> m = null;
  
  private ArrayList<String> n = null;
  
  private ArrayList<Integer> o = null;
  
  private ArrayList<View> p = null;
  
  private ArrayList<Class> q = null;
  
  private t r = new t();
  
  private t s = new t();
  
  q t = null;
  
  private int[] u = I;
  
  private ArrayList<s> v;
  
  private ArrayList<s> w;
  
  boolean x = false;
  
  ArrayList<Animator> y = new ArrayList<Animator>();
  
  private int z = 0;
  
  private void a(t paramt1, t paramt2) {
    a.b.g.g.a<View, s> a2 = new a.b.g.g.a((n)paramt1.a);
    a.b.g.g.a<View, s> a1 = new a.b.g.g.a((n)paramt2.a);
    byte b = 0;
    while (true) {
      int[] arrayOfInt = this.u;
      if (b < arrayOfInt.length) {
        int i = arrayOfInt[b];
        if (i != 1) {
          if (i != 2) {
            if (i != 3) {
              if (i == 4)
                a(a2, a1, paramt1.c, paramt2.c); 
            } else {
              a(a2, a1, paramt1.b, paramt2.b);
            } 
          } else {
            a(a2, a1, paramt1.d, paramt2.d);
          } 
        } else {
          b(a2, a1);
        } 
        b++;
        continue;
      } 
      a(a2, a1);
      return;
    } 
  }
  
  private static void a(t paramt, View paramView, s params) {
    paramt.a.put(paramView, params);
    int i = paramView.getId();
    if (i >= 0)
      if (paramt.b.indexOfKey(i) >= 0) {
        paramt.b.put(i, null);
      } else {
        paramt.b.put(i, paramView);
      }  
    String str = u.q(paramView);
    if (str != null)
      if (paramt.d.containsKey(str)) {
        paramt.d.put(str, null);
      } else {
        paramt.d.put(str, paramView);
      }  
    if (paramView.getParent() instanceof ListView) {
      ListView listView = (ListView)paramView.getParent();
      if (listView.getAdapter().hasStableIds()) {
        long l = listView.getItemIdAtPosition(listView.getPositionForView(paramView));
        if (paramt.c.c(l) >= 0) {
          paramView = (View)paramt.c.b(l);
          if (paramView != null) {
            u.b(paramView, false);
            paramt.c.c(l, null);
          } 
        } else {
          u.b(paramView, true);
          paramt.c.c(l, paramView);
        } 
      } 
    } 
  }
  
  private void a(a.b.g.g.a<View, s> parama1, a.b.g.g.a<View, s> parama2) {
    byte b;
    for (b = 0; b < parama1.size(); b++) {
      s s = (s)parama1.d(b);
      if (b(s.b)) {
        this.v.add(s);
        this.w.add(null);
      } 
    } 
    for (b = 0; b < parama2.size(); b++) {
      s s = (s)parama2.d(b);
      if (b(s.b)) {
        this.w.add(s);
        this.v.add(null);
      } 
    } 
  }
  
  private void a(a.b.g.g.a<View, s> parama1, a.b.g.g.a<View, s> parama2, a.b.g.g.a<String, View> parama3, a.b.g.g.a<String, View> parama4) {
    int i = parama3.size();
    for (byte b = 0; b < i; b++) {
      View view = (View)parama3.d(b);
      if (view != null && b(view)) {
        View view1 = (View)parama4.get(parama3.b(b));
        if (view1 != null && b(view1)) {
          s s1 = (s)parama1.get(view);
          s s2 = (s)parama2.get(view1);
          if (s1 != null && s2 != null) {
            this.v.add(s1);
            this.w.add(s2);
            parama1.remove(view);
            parama2.remove(view1);
          } 
        } 
      } 
    } 
  }
  
  private void a(a.b.g.g.a<View, s> parama1, a.b.g.g.a<View, s> parama2, a.b.g.g.f<View> paramf1, a.b.g.g.f<View> paramf2) {
    int i = paramf1.b();
    for (byte b = 0; b < i; b++) {
      View view = (View)paramf1.c(b);
      if (view != null && b(view)) {
        View view1 = (View)paramf2.b(paramf1.a(b));
        if (view1 != null && b(view1)) {
          s s2 = (s)parama1.get(view);
          s s1 = (s)parama2.get(view1);
          if (s2 != null && s1 != null) {
            this.v.add(s2);
            this.w.add(s1);
            parama1.remove(view);
            parama2.remove(view1);
          } 
        } 
      } 
    } 
  }
  
  private void a(a.b.g.g.a<View, s> parama1, a.b.g.g.a<View, s> parama2, SparseArray<View> paramSparseArray1, SparseArray<View> paramSparseArray2) {
    int i = paramSparseArray1.size();
    for (byte b = 0; b < i; b++) {
      View view = (View)paramSparseArray1.valueAt(b);
      if (view != null && b(view)) {
        View view1 = (View)paramSparseArray2.get(paramSparseArray1.keyAt(b));
        if (view1 != null && b(view1)) {
          s s2 = (s)parama1.get(view);
          s s1 = (s)parama2.get(view1);
          if (s2 != null && s1 != null) {
            this.v.add(s2);
            this.w.add(s1);
            parama1.remove(view);
            parama2.remove(view1);
          } 
        } 
      } 
    } 
  }
  
  private void a(Animator paramAnimator, a.b.g.g.a<Animator, d> parama) {
    if (paramAnimator != null) {
      paramAnimator.addListener((Animator.AnimatorListener)new b(this, parama));
      a(paramAnimator);
    } 
  }
  
  private static boolean a(s params1, s params2, String paramString) {
    int i;
    params1 = (s)params1.a.get(paramString);
    params2 = (s)params2.a.get(paramString);
    if (params1 == null && params2 == null) {
      i = 0;
    } else {
      if (params1 == null || params2 == null)
        return true; 
      i = params1.equals(params2) ^ true;
    } 
    return i;
  }
  
  private void b(a.b.g.g.a<View, s> parama1, a.b.g.g.a<View, s> parama2) {
    for (int i = parama1.size() - 1; i >= 0; i--) {
      View view = (View)parama1.b(i);
      if (view != null && b(view)) {
        s s = (s)parama2.remove(view);
        if (s != null) {
          View view1 = s.b;
          if (view1 != null && b(view1)) {
            s s1 = (s)parama1.c(i);
            this.v.add(s1);
            this.w.add(s);
          } 
        } 
      } 
    } 
  }
  
  private void c(View paramView, boolean paramBoolean) {
    if (paramView == null)
      return; 
    int i = paramView.getId();
    ArrayList<Integer> arrayList2 = this.k;
    if (arrayList2 != null && arrayList2.contains(Integer.valueOf(i)))
      return; 
    ArrayList<View> arrayList1 = this.l;
    if (arrayList1 != null && arrayList1.contains(paramView))
      return; 
    ArrayList<Class> arrayList = this.m;
    if (arrayList != null) {
      int j = arrayList.size();
      for (byte b = 0; b < j; b++) {
        if (((Class)this.m.get(b)).isInstance(paramView))
          return; 
      } 
    } 
    if (paramView.getParent() instanceof ViewGroup) {
      s s = new s();
      s.b = paramView;
      if (paramBoolean) {
        c(s);
      } else {
        a(s);
      } 
      s.c.add(this);
      b(s);
      if (paramBoolean) {
        a(this.r, paramView, s);
      } else {
        a(this.s, paramView, s);
      } 
    } 
    if (paramView instanceof ViewGroup) {
      ArrayList<Integer> arrayList5 = this.o;
      if (arrayList5 != null && arrayList5.contains(Integer.valueOf(i)))
        return; 
      ArrayList<View> arrayList4 = this.p;
      if (arrayList4 != null && arrayList4.contains(paramView))
        return; 
      ArrayList<Class> arrayList3 = this.q;
      if (arrayList3 != null) {
        int j = arrayList3.size();
        for (byte b1 = 0; b1 < j; b1++) {
          if (((Class)this.q.get(b1)).isInstance(paramView))
            return; 
        } 
      } 
      ViewGroup viewGroup = (ViewGroup)paramView;
      for (byte b = 0; b < viewGroup.getChildCount(); b++)
        c(viewGroup.getChildAt(b), paramBoolean); 
    } 
  }
  
  private static a.b.g.g.a<Animator, d> q() {
    a.b.g.g.a<Animator, d> a2 = K.get();
    a.b.g.g.a<Animator, d> a1 = a2;
    if (a2 == null) {
      a1 = new a.b.g.g.a();
      K.set(a1);
    } 
    return a1;
  }
  
  public m a(long paramLong) {
    this.e = paramLong;
    return this;
  }
  
  public m a(f paramf) {
    if (this.C == null)
      this.C = new ArrayList<f>(); 
    this.C.add(paramf);
    return this;
  }
  
  public m a(TimeInterpolator paramTimeInterpolator) {
    this.f = paramTimeInterpolator;
    return this;
  }
  
  public m a(View paramView) {
    this.h.add(paramView);
    return this;
  }
  
  s a(View paramView, boolean paramBoolean) {
    s s;
    byte b1;
    ArrayList<s> arrayList;
    q q1 = this.t;
    if (q1 != null)
      return q1.a(paramView, paramBoolean); 
    if (paramBoolean) {
      arrayList = this.v;
    } else {
      arrayList = this.w;
    } 
    if (arrayList == null)
      return null; 
    int i = arrayList.size();
    byte b2 = -1;
    byte b = 0;
    while (true) {
      b1 = b2;
      if (b < i) {
        s s1 = arrayList.get(b);
        if (s1 == null)
          return null; 
        if (s1.b == paramView) {
          b1 = b;
          break;
        } 
        b++;
        continue;
      } 
      break;
    } 
    paramView = null;
    if (b1 >= 0) {
      ArrayList<s> arrayList1;
      if (paramBoolean) {
        arrayList1 = this.w;
      } else {
        arrayList1 = this.v;
      } 
      s = arrayList1.get(b1);
    } 
    return s;
  }
  
  public Animator a(ViewGroup paramViewGroup, s params1, s params2) {
    return null;
  }
  
  String a(String paramString) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_3
    //   8: aload_3
    //   9: aload_1
    //   10: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   13: pop
    //   14: aload_3
    //   15: aload_0
    //   16: invokevirtual getClass : ()Ljava/lang/Class;
    //   19: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   22: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   25: pop
    //   26: aload_3
    //   27: ldc_w '@'
    //   30: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   33: pop
    //   34: aload_3
    //   35: aload_0
    //   36: invokevirtual hashCode : ()I
    //   39: invokestatic toHexString : (I)Ljava/lang/String;
    //   42: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   45: pop
    //   46: aload_3
    //   47: ldc_w ': '
    //   50: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   53: pop
    //   54: aload_3
    //   55: invokevirtual toString : ()Ljava/lang/String;
    //   58: astore_3
    //   59: aload_3
    //   60: astore_1
    //   61: aload_0
    //   62: getfield e : J
    //   65: ldc2_w -1
    //   68: lcmp
    //   69: ifeq -> 116
    //   72: new java/lang/StringBuilder
    //   75: dup
    //   76: invokespecial <init> : ()V
    //   79: astore_1
    //   80: aload_1
    //   81: aload_3
    //   82: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   85: pop
    //   86: aload_1
    //   87: ldc_w 'dur('
    //   90: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   93: pop
    //   94: aload_1
    //   95: aload_0
    //   96: getfield e : J
    //   99: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   102: pop
    //   103: aload_1
    //   104: ldc_w ') '
    //   107: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   110: pop
    //   111: aload_1
    //   112: invokevirtual toString : ()Ljava/lang/String;
    //   115: astore_1
    //   116: aload_1
    //   117: astore_3
    //   118: aload_0
    //   119: getfield d : J
    //   122: ldc2_w -1
    //   125: lcmp
    //   126: ifeq -> 173
    //   129: new java/lang/StringBuilder
    //   132: dup
    //   133: invokespecial <init> : ()V
    //   136: astore_3
    //   137: aload_3
    //   138: aload_1
    //   139: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   142: pop
    //   143: aload_3
    //   144: ldc_w 'dly('
    //   147: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   150: pop
    //   151: aload_3
    //   152: aload_0
    //   153: getfield d : J
    //   156: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   159: pop
    //   160: aload_3
    //   161: ldc_w ') '
    //   164: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   167: pop
    //   168: aload_3
    //   169: invokevirtual toString : ()Ljava/lang/String;
    //   172: astore_3
    //   173: aload_3
    //   174: astore_1
    //   175: aload_0
    //   176: getfield f : Landroid/animation/TimeInterpolator;
    //   179: ifnull -> 226
    //   182: new java/lang/StringBuilder
    //   185: dup
    //   186: invokespecial <init> : ()V
    //   189: astore_1
    //   190: aload_1
    //   191: aload_3
    //   192: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   195: pop
    //   196: aload_1
    //   197: ldc_w 'interp('
    //   200: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   203: pop
    //   204: aload_1
    //   205: aload_0
    //   206: getfield f : Landroid/animation/TimeInterpolator;
    //   209: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   212: pop
    //   213: aload_1
    //   214: ldc_w ') '
    //   217: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   220: pop
    //   221: aload_1
    //   222: invokevirtual toString : ()Ljava/lang/String;
    //   225: astore_1
    //   226: aload_0
    //   227: getfield g : Ljava/util/ArrayList;
    //   230: invokevirtual size : ()I
    //   233: ifgt -> 248
    //   236: aload_1
    //   237: astore_3
    //   238: aload_0
    //   239: getfield h : Ljava/util/ArrayList;
    //   242: invokevirtual size : ()I
    //   245: ifle -> 503
    //   248: new java/lang/StringBuilder
    //   251: dup
    //   252: invokespecial <init> : ()V
    //   255: astore_3
    //   256: aload_3
    //   257: aload_1
    //   258: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   261: pop
    //   262: aload_3
    //   263: ldc_w 'tgts('
    //   266: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   269: pop
    //   270: aload_3
    //   271: invokevirtual toString : ()Ljava/lang/String;
    //   274: astore_1
    //   275: aload_1
    //   276: astore_3
    //   277: aload_0
    //   278: getfield g : Ljava/util/ArrayList;
    //   281: invokevirtual size : ()I
    //   284: ifle -> 373
    //   287: iconst_0
    //   288: istore_2
    //   289: aload_1
    //   290: astore_3
    //   291: iload_2
    //   292: aload_0
    //   293: getfield g : Ljava/util/ArrayList;
    //   296: invokevirtual size : ()I
    //   299: if_icmpge -> 373
    //   302: aload_1
    //   303: astore_3
    //   304: iload_2
    //   305: ifle -> 335
    //   308: new java/lang/StringBuilder
    //   311: dup
    //   312: invokespecial <init> : ()V
    //   315: astore_3
    //   316: aload_3
    //   317: aload_1
    //   318: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   321: pop
    //   322: aload_3
    //   323: ldc_w ', '
    //   326: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   329: pop
    //   330: aload_3
    //   331: invokevirtual toString : ()Ljava/lang/String;
    //   334: astore_3
    //   335: new java/lang/StringBuilder
    //   338: dup
    //   339: invokespecial <init> : ()V
    //   342: astore_1
    //   343: aload_1
    //   344: aload_3
    //   345: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   348: pop
    //   349: aload_1
    //   350: aload_0
    //   351: getfield g : Ljava/util/ArrayList;
    //   354: iload_2
    //   355: invokevirtual get : (I)Ljava/lang/Object;
    //   358: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   361: pop
    //   362: aload_1
    //   363: invokevirtual toString : ()Ljava/lang/String;
    //   366: astore_1
    //   367: iinc #2, 1
    //   370: goto -> 289
    //   373: aload_3
    //   374: astore #4
    //   376: aload_0
    //   377: getfield h : Ljava/util/ArrayList;
    //   380: invokevirtual size : ()I
    //   383: ifle -> 475
    //   386: iconst_0
    //   387: istore_2
    //   388: aload_3
    //   389: astore_1
    //   390: aload_1
    //   391: astore #4
    //   393: iload_2
    //   394: aload_0
    //   395: getfield h : Ljava/util/ArrayList;
    //   398: invokevirtual size : ()I
    //   401: if_icmpge -> 475
    //   404: aload_1
    //   405: astore_3
    //   406: iload_2
    //   407: ifle -> 437
    //   410: new java/lang/StringBuilder
    //   413: dup
    //   414: invokespecial <init> : ()V
    //   417: astore_3
    //   418: aload_3
    //   419: aload_1
    //   420: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   423: pop
    //   424: aload_3
    //   425: ldc_w ', '
    //   428: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   431: pop
    //   432: aload_3
    //   433: invokevirtual toString : ()Ljava/lang/String;
    //   436: astore_3
    //   437: new java/lang/StringBuilder
    //   440: dup
    //   441: invokespecial <init> : ()V
    //   444: astore_1
    //   445: aload_1
    //   446: aload_3
    //   447: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   450: pop
    //   451: aload_1
    //   452: aload_0
    //   453: getfield h : Ljava/util/ArrayList;
    //   456: iload_2
    //   457: invokevirtual get : (I)Ljava/lang/Object;
    //   460: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   463: pop
    //   464: aload_1
    //   465: invokevirtual toString : ()Ljava/lang/String;
    //   468: astore_1
    //   469: iinc #2, 1
    //   472: goto -> 390
    //   475: new java/lang/StringBuilder
    //   478: dup
    //   479: invokespecial <init> : ()V
    //   482: astore_1
    //   483: aload_1
    //   484: aload #4
    //   486: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   489: pop
    //   490: aload_1
    //   491: ldc_w ')'
    //   494: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   497: pop
    //   498: aload_1
    //   499: invokevirtual toString : ()Ljava/lang/String;
    //   502: astore_3
    //   503: aload_3
    //   504: areturn
  }
  
  protected void a() {
    this.z--;
    if (this.z == 0) {
      ArrayList<f> arrayList = this.C;
      if (arrayList != null && arrayList.size() > 0) {
        arrayList = (ArrayList<f>)this.C.clone();
        int i = arrayList.size();
        for (byte b1 = 0; b1 < i; b1++)
          ((f)arrayList.get(b1)).b(this); 
      } 
      byte b;
      for (b = 0; b < this.r.c.b(); b++) {
        View view = (View)this.r.c.c(b);
        if (view != null)
          u.b(view, false); 
      } 
      for (b = 0; b < this.s.c.b(); b++) {
        View view = (View)this.s.c.c(b);
        if (view != null)
          u.b(view, false); 
      } 
      this.B = true;
    } 
  }
  
  public void a(g paramg) {
    if (paramg == null) {
      this.H = J;
    } else {
      this.H = paramg;
    } 
  }
  
  public void a(e parame) {
    this.F = parame;
  }
  
  public void a(p paramp) {
    this.E = paramp;
  }
  
  public abstract void a(s params);
  
  protected void a(Animator paramAnimator) {
    if (paramAnimator == null) {
      a();
    } else {
      if (b() >= 0L)
        paramAnimator.setDuration(b()); 
      if (h() >= 0L)
        paramAnimator.setStartDelay(h()); 
      if (d() != null)
        paramAnimator.setInterpolator(d()); 
      paramAnimator.addListener((Animator.AnimatorListener)new c(this));
      paramAnimator.start();
    } 
  }
  
  void a(ViewGroup paramViewGroup) {
    this.v = new ArrayList<s>();
    this.w = new ArrayList<s>();
    a(this.r, this.s);
    a.b.g.g.a<Animator, d> a1 = q();
    int i = a1.size();
    l0 l0 = d0.d((View)paramViewGroup);
    while (--i >= 0) {
      Animator animator = (Animator)a1.b(i);
      if (animator != null) {
        d d = (d)a1.get(animator);
        if (d != null && d.a != null && l0.equals(d.d)) {
          s s2 = d.c;
          View view = d.a;
          boolean bool = true;
          s s1 = b(view, true);
          s s3 = a(view, true);
          if ((s1 == null && s3 == null) || !d.e.a(s2, s3))
            bool = false; 
          if (bool)
            if (animator.isRunning() || animator.isStarted()) {
              animator.cancel();
            } else {
              a1.remove(animator);
            }  
        } 
      } 
      i--;
    } 
    a(paramViewGroup, this.r, this.s, this.v, this.w);
    o();
  }
  
  protected void a(ViewGroup paramViewGroup, t paramt1, t paramt2, ArrayList<s> paramArrayList1, ArrayList<s> paramArrayList2) {
    a.b.g.g.a<Animator, d> a1 = q();
    long l = Long.MAX_VALUE;
    SparseIntArray sparseIntArray = new SparseIntArray();
    int i = paramArrayList1.size();
    byte b = 0;
    while (b < i) {
      long l1;
      s s1 = paramArrayList1.get(b);
      s s2 = paramArrayList2.get(b);
      if (s1 != null && !s1.c.contains(this))
        s1 = null; 
      if (s2 != null && !s2.c.contains(this))
        s2 = null; 
      if (s1 == null && s2 == null) {
        l1 = l;
      } else {
        byte b1;
        if (s1 == null || s2 == null || a(s1, s2)) {
          b1 = 1;
        } else {
          b1 = 0;
        } 
        if (b1) {
          Animator animator = a(paramViewGroup, s1, s2);
          if (animator != null) {
            View view1;
            View view2;
            s s = null;
            if (s2 != null) {
              View view = s2.b;
              String[] arrayOfString = n();
              if (view != null && arrayOfString != null && arrayOfString.length > 0) {
                s s3 = new s();
                s3.b = view;
                s = (s)paramt2.a.get(view);
                if (s != null)
                  for (b1 = 0; b1 < arrayOfString.length; b1++)
                    s3.a.put(arrayOfString[b1], s.a.get(arrayOfString[b1]));  
                int j = a1.size();
                b1 = 0;
                while (true) {
                  if (b1 < j) {
                    d d = (d)a1.get(a1.b(b1));
                    if (d.c != null && d.a == view && d.b.equals(e()) && d.c.equals(s3)) {
                      animator = null;
                      s s4 = s3;
                      break;
                    } 
                    b1++;
                    continue;
                  } 
                  s = s3;
                  break;
                } 
              } 
              Animator animator1 = animator;
              view1 = view;
              b1 = b;
            } else {
              View view = s1.b;
              s = null;
              view2 = view1;
              b1 = b;
              view1 = view;
            } 
            l1 = l;
            b = b1;
            if (view2 != null) {
              p p1 = this.E;
              if (p1 != null) {
                l1 = p1.a(paramViewGroup, this, s1, s2);
                sparseIntArray.put(this.D.size(), (int)l1);
                l = Math.min(l1, l);
              } 
              a1.put(view2, new d(view1, e(), this, d0.d((View)paramViewGroup), s));
              this.D.add(view2);
              l1 = l;
              b = b1;
            } 
          } else {
            l1 = l;
          } 
        } else {
          l1 = l;
        } 
      } 
      b++;
      l = l1;
    } 
    if (l != 0L)
      for (b = 0; b < sparseIntArray.size(); b++) {
        int j = sparseIntArray.keyAt(b);
        Animator animator = this.D.get(j);
        animator.setStartDelay(sparseIntArray.valueAt(b) - l + animator.getStartDelay());
      }  
  }
  
  void a(ViewGroup paramViewGroup, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: iload_2
    //   2: invokevirtual a : (Z)V
    //   5: aload_0
    //   6: getfield g : Ljava/util/ArrayList;
    //   9: invokevirtual size : ()I
    //   12: ifgt -> 25
    //   15: aload_0
    //   16: getfield h : Ljava/util/ArrayList;
    //   19: invokevirtual size : ()I
    //   22: ifle -> 66
    //   25: aload_0
    //   26: getfield i : Ljava/util/ArrayList;
    //   29: astore #5
    //   31: aload #5
    //   33: ifnull -> 44
    //   36: aload #5
    //   38: invokevirtual isEmpty : ()Z
    //   41: ifeq -> 66
    //   44: aload_0
    //   45: getfield j : Ljava/util/ArrayList;
    //   48: astore #5
    //   50: aload #5
    //   52: ifnull -> 75
    //   55: aload #5
    //   57: invokevirtual isEmpty : ()Z
    //   60: ifeq -> 66
    //   63: goto -> 75
    //   66: aload_0
    //   67: aload_1
    //   68: iload_2
    //   69: invokespecial c : (Landroid/view/View;Z)V
    //   72: goto -> 307
    //   75: iconst_0
    //   76: istore_3
    //   77: iload_3
    //   78: aload_0
    //   79: getfield g : Ljava/util/ArrayList;
    //   82: invokevirtual size : ()I
    //   85: if_icmpge -> 199
    //   88: aload_1
    //   89: aload_0
    //   90: getfield g : Ljava/util/ArrayList;
    //   93: iload_3
    //   94: invokevirtual get : (I)Ljava/lang/Object;
    //   97: checkcast java/lang/Integer
    //   100: invokevirtual intValue : ()I
    //   103: invokevirtual findViewById : (I)Landroid/view/View;
    //   106: astore #5
    //   108: aload #5
    //   110: ifnull -> 193
    //   113: new a/b/f/s
    //   116: dup
    //   117: invokespecial <init> : ()V
    //   120: astore #6
    //   122: aload #6
    //   124: aload #5
    //   126: putfield b : Landroid/view/View;
    //   129: iload_2
    //   130: ifeq -> 142
    //   133: aload_0
    //   134: aload #6
    //   136: invokevirtual c : (La/b/f/s;)V
    //   139: goto -> 148
    //   142: aload_0
    //   143: aload #6
    //   145: invokevirtual a : (La/b/f/s;)V
    //   148: aload #6
    //   150: getfield c : Ljava/util/ArrayList;
    //   153: aload_0
    //   154: invokevirtual add : (Ljava/lang/Object;)Z
    //   157: pop
    //   158: aload_0
    //   159: aload #6
    //   161: invokevirtual b : (La/b/f/s;)V
    //   164: iload_2
    //   165: ifeq -> 182
    //   168: aload_0
    //   169: getfield r : La/b/f/t;
    //   172: aload #5
    //   174: aload #6
    //   176: invokestatic a : (La/b/f/t;Landroid/view/View;La/b/f/s;)V
    //   179: goto -> 193
    //   182: aload_0
    //   183: getfield s : La/b/f/t;
    //   186: aload #5
    //   188: aload #6
    //   190: invokestatic a : (La/b/f/t;Landroid/view/View;La/b/f/s;)V
    //   193: iinc #3, 1
    //   196: goto -> 77
    //   199: iconst_0
    //   200: istore_3
    //   201: iload_3
    //   202: aload_0
    //   203: getfield h : Ljava/util/ArrayList;
    //   206: invokevirtual size : ()I
    //   209: if_icmpge -> 307
    //   212: aload_0
    //   213: getfield h : Ljava/util/ArrayList;
    //   216: iload_3
    //   217: invokevirtual get : (I)Ljava/lang/Object;
    //   220: checkcast android/view/View
    //   223: astore_1
    //   224: new a/b/f/s
    //   227: dup
    //   228: invokespecial <init> : ()V
    //   231: astore #5
    //   233: aload #5
    //   235: aload_1
    //   236: putfield b : Landroid/view/View;
    //   239: iload_2
    //   240: ifeq -> 252
    //   243: aload_0
    //   244: aload #5
    //   246: invokevirtual c : (La/b/f/s;)V
    //   249: goto -> 258
    //   252: aload_0
    //   253: aload #5
    //   255: invokevirtual a : (La/b/f/s;)V
    //   258: aload #5
    //   260: getfield c : Ljava/util/ArrayList;
    //   263: aload_0
    //   264: invokevirtual add : (Ljava/lang/Object;)Z
    //   267: pop
    //   268: aload_0
    //   269: aload #5
    //   271: invokevirtual b : (La/b/f/s;)V
    //   274: iload_2
    //   275: ifeq -> 291
    //   278: aload_0
    //   279: getfield r : La/b/f/t;
    //   282: aload_1
    //   283: aload #5
    //   285: invokestatic a : (La/b/f/t;Landroid/view/View;La/b/f/s;)V
    //   288: goto -> 301
    //   291: aload_0
    //   292: getfield s : La/b/f/t;
    //   295: aload_1
    //   296: aload #5
    //   298: invokestatic a : (La/b/f/t;Landroid/view/View;La/b/f/s;)V
    //   301: iinc #3, 1
    //   304: goto -> 201
    //   307: iload_2
    //   308: ifne -> 437
    //   311: aload_0
    //   312: getfield G : La/b/g/g/a;
    //   315: astore_1
    //   316: aload_1
    //   317: ifnull -> 437
    //   320: aload_1
    //   321: invokevirtual size : ()I
    //   324: istore #4
    //   326: new java/util/ArrayList
    //   329: dup
    //   330: iload #4
    //   332: invokespecial <init> : (I)V
    //   335: astore_1
    //   336: iconst_0
    //   337: istore_3
    //   338: iload_3
    //   339: iload #4
    //   341: if_icmpge -> 380
    //   344: aload_0
    //   345: getfield G : La/b/g/g/a;
    //   348: iload_3
    //   349: invokevirtual b : (I)Ljava/lang/Object;
    //   352: checkcast java/lang/String
    //   355: astore #5
    //   357: aload_1
    //   358: aload_0
    //   359: getfield r : La/b/f/t;
    //   362: getfield d : La/b/g/g/a;
    //   365: aload #5
    //   367: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   370: invokevirtual add : (Ljava/lang/Object;)Z
    //   373: pop
    //   374: iinc #3, 1
    //   377: goto -> 338
    //   380: iconst_0
    //   381: istore_3
    //   382: iload_3
    //   383: iload #4
    //   385: if_icmpge -> 437
    //   388: aload_1
    //   389: iload_3
    //   390: invokevirtual get : (I)Ljava/lang/Object;
    //   393: checkcast android/view/View
    //   396: astore #5
    //   398: aload #5
    //   400: ifnull -> 431
    //   403: aload_0
    //   404: getfield G : La/b/g/g/a;
    //   407: iload_3
    //   408: invokevirtual d : (I)Ljava/lang/Object;
    //   411: checkcast java/lang/String
    //   414: astore #6
    //   416: aload_0
    //   417: getfield r : La/b/f/t;
    //   420: getfield d : La/b/g/g/a;
    //   423: aload #6
    //   425: aload #5
    //   427: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   430: pop
    //   431: iinc #3, 1
    //   434: goto -> 382
    //   437: return
  }
  
  void a(boolean paramBoolean) {
    if (paramBoolean) {
      this.r.a.clear();
      this.r.b.clear();
      this.r.c.a();
    } else {
      this.s.a.clear();
      this.s.b.clear();
      this.s.c.a();
    } 
  }
  
  public boolean a(s params1, s params2) {
    boolean bool3 = false;
    boolean bool2 = false;
    boolean bool1 = bool3;
    if (params1 != null) {
      bool1 = bool3;
      if (params2 != null) {
        String[] arrayOfString = n();
        if (arrayOfString != null) {
          int i = arrayOfString.length;
          byte b = 0;
          while (true) {
            bool1 = bool2;
            if (b < i) {
              if (a(params1, params2, arrayOfString[b])) {
                bool1 = true;
                break;
              } 
              b++;
              continue;
            } 
            break;
          } 
        } else {
          Iterator<String> iterator = params1.a.keySet().iterator();
          while (true) {
            bool1 = bool3;
            if (iterator.hasNext()) {
              if (a(params1, params2, iterator.next())) {
                bool1 = true;
                break;
              } 
              continue;
            } 
            break;
          } 
        } 
      } 
    } 
    return bool1;
  }
  
  public long b() {
    return this.e;
  }
  
  public m b(long paramLong) {
    this.d = paramLong;
    return this;
  }
  
  public m b(f paramf) {
    ArrayList<f> arrayList = this.C;
    if (arrayList == null)
      return this; 
    arrayList.remove(paramf);
    if (this.C.size() == 0)
      this.C = null; 
    return this;
  }
  
  public s b(View paramView, boolean paramBoolean) {
    t t1;
    q q1 = this.t;
    if (q1 != null)
      return q1.b(paramView, paramBoolean); 
    if (paramBoolean) {
      t1 = this.r;
    } else {
      t1 = this.s;
    } 
    return (s)t1.a.get(paramView);
  }
  
  void b(s params) {
    if (this.E != null && !params.a.isEmpty()) {
      boolean bool1;
      String[] arrayOfString = this.E.a();
      if (arrayOfString == null)
        return; 
      boolean bool2 = true;
      byte b = 0;
      while (true) {
        bool1 = bool2;
        if (b < arrayOfString.length) {
          if (!params.a.containsKey(arrayOfString[b])) {
            bool1 = false;
            break;
          } 
          b++;
          continue;
        } 
        break;
      } 
      if (!bool1)
        this.E.a(params); 
    } 
  }
  
  boolean b(View paramView) {
    int i = paramView.getId();
    ArrayList<Integer> arrayList3 = this.k;
    if (arrayList3 != null && arrayList3.contains(Integer.valueOf(i)))
      return false; 
    ArrayList<View> arrayList2 = this.l;
    if (arrayList2 != null && arrayList2.contains(paramView))
      return false; 
    ArrayList<Class> arrayList1 = this.m;
    if (arrayList1 != null) {
      int j = arrayList1.size();
      for (byte b = 0; b < j; b++) {
        if (((Class)this.m.get(b)).isInstance(paramView))
          return false; 
      } 
    } 
    if (this.n != null && u.q(paramView) != null && this.n.contains(u.q(paramView)))
      return false; 
    if (this.g.size() == 0 && this.h.size() == 0) {
      arrayList1 = this.j;
      if (arrayList1 == null || arrayList1.isEmpty()) {
        ArrayList<String> arrayList4 = this.i;
        if (arrayList4 == null || arrayList4.isEmpty())
          return true; 
      } 
    } 
    if (this.g.contains(Integer.valueOf(i)) || this.h.contains(paramView))
      return true; 
    ArrayList<String> arrayList = this.i;
    if (arrayList != null && arrayList.contains(u.q(paramView)))
      return true; 
    if (this.j != null)
      for (byte b = 0; b < this.j.size(); b++) {
        if (((Class)this.j.get(b)).isInstance(paramView))
          return true; 
      }  
    return false;
  }
  
  public e c() {
    return this.F;
  }
  
  public abstract void c(s params);
  
  public void c(View paramView) {
    if (!this.B) {
      a.b.g.g.a<Animator, d> a1 = q();
      int i = a1.size();
      l0 l0 = d0.d(paramView);
      while (--i >= 0) {
        d d = (d)a1.d(i);
        if (d.a != null && l0.equals(d.d))
          a.a((Animator)a1.b(i)); 
        i--;
      } 
      ArrayList<f> arrayList = this.C;
      if (arrayList != null && arrayList.size() > 0) {
        arrayList = (ArrayList<f>)this.C.clone();
        int j = arrayList.size();
        for (i = 0; i < j; i++)
          ((f)arrayList.get(i)).a(this); 
      } 
      this.A = true;
    } 
  }
  
  public m clone() {
    try {
      m m1 = (m)super.clone();
      ArrayList<Animator> arrayList = new ArrayList();
      this();
      m1.D = arrayList;
      t t1 = new t();
      this();
      m1.r = t1;
      t1 = new t();
      this();
      m1.s = t1;
      m1.v = null;
      m1.w = null;
      return m1;
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      return null;
    } 
  }
  
  public m d(View paramView) {
    this.h.remove(paramView);
    return this;
  }
  
  public TimeInterpolator d() {
    return this.f;
  }
  
  public String e() {
    return this.c;
  }
  
  public void e(View paramView) {
    if (this.A) {
      if (!this.B) {
        a.b.g.g.a<Animator, d> a1 = q();
        int i = a1.size();
        l0 l0 = d0.d(paramView);
        while (--i >= 0) {
          d d = (d)a1.d(i);
          if (d.a != null && l0.equals(d.d))
            a.b((Animator)a1.b(i)); 
          i--;
        } 
        ArrayList<f> arrayList = this.C;
        if (arrayList != null && arrayList.size() > 0) {
          arrayList = (ArrayList<f>)this.C.clone();
          int j = arrayList.size();
          for (i = 0; i < j; i++)
            ((f)arrayList.get(i)).d(this); 
        } 
      } 
      this.A = false;
    } 
  }
  
  public g f() {
    return this.H;
  }
  
  public p g() {
    return this.E;
  }
  
  public long h() {
    return this.d;
  }
  
  public List<Integer> i() {
    return this.g;
  }
  
  public List<String> j() {
    return this.i;
  }
  
  public List<Class> k() {
    return this.j;
  }
  
  public List<View> m() {
    return this.h;
  }
  
  public String[] n() {
    return null;
  }
  
  protected void o() {
    p();
    a.b.g.g.a<Animator, d> a1 = q();
    for (Animator animator : this.D) {
      if (a1.containsKey(animator)) {
        p();
        a(animator, a1);
      } 
    } 
    this.D.clear();
    a();
  }
  
  protected void p() {
    if (this.z == 0) {
      ArrayList<f> arrayList = this.C;
      if (arrayList != null && arrayList.size() > 0) {
        arrayList = (ArrayList<f>)this.C.clone();
        int i = arrayList.size();
        for (byte b = 0; b < i; b++)
          ((f)arrayList.get(b)).c(this); 
      } 
      this.B = false;
    } 
    this.z++;
  }
  
  public String toString() {
    return a("");
  }
  
  static final class a extends g {
    public Path a(float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
      Path path = new Path();
      path.moveTo(param1Float1, param1Float2);
      path.lineTo(param1Float3, param1Float4);
      return path;
    }
  }
  
  class b extends AnimatorListenerAdapter {
    final a.b.g.g.a a;
    
    final m b;
    
    b(m this$0, a.b.g.g.a param1a) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.remove(param1Animator);
      this.b.y.remove(param1Animator);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.b.y.add(param1Animator);
    }
  }
  
  class c extends AnimatorListenerAdapter {
    final m a;
    
    c(m this$0) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.a();
      param1Animator.removeListener((Animator.AnimatorListener)this);
    }
  }
  
  private static class d {
    View a;
    
    String b;
    
    s c;
    
    l0 d;
    
    m e;
    
    d(View param1View, String param1String, m param1m, l0 param1l0, s param1s) {
      this.a = param1View;
      this.b = param1String;
      this.c = param1s;
      this.d = param1l0;
      this.e = param1m;
    }
  }
  
  public static abstract class e {}
  
  public static interface f {
    void a(m param1m);
    
    void b(m param1m);
    
    void c(m param1m);
    
    void d(m param1m);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */