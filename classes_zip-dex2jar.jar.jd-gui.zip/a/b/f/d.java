package a.b.f;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.support.v4.view.u;
import android.view.View;
import android.view.ViewGroup;

public class d extends i0 {
  public d(int paramInt) {
    a(paramInt);
  }
  
  private static float a(s params, float paramFloat) {
    float f = paramFloat;
    if (params != null) {
      Float float_ = (Float)params.a.get("android:fade:transitionAlpha");
      f = paramFloat;
      if (float_ != null)
        f = float_.floatValue(); 
    } 
    return f;
  }
  
  private Animator a(View paramView, float paramFloat1, float paramFloat2) {
    if (paramFloat1 == paramFloat2)
      return null; 
    d0.a(paramView, paramFloat1);
    ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(paramView, d0.d, new float[] { paramFloat2 });
    objectAnimator.addListener((Animator.AnimatorListener)new b(paramView));
    a(new a(this, paramView));
    return (Animator)objectAnimator;
  }
  
  public Animator a(ViewGroup paramViewGroup, View paramView, s params1, s params2) {
    float f2 = a(params1, 0.0F);
    float f1 = f2;
    if (f2 == 1.0F)
      f1 = 0.0F; 
    return a(paramView, f1, 1.0F);
  }
  
  public Animator b(ViewGroup paramViewGroup, View paramView, s params1, s params2) {
    d0.e(paramView);
    return a(paramView, a(params1, 1.0F), 0.0F);
  }
  
  public void c(s params) {
    super.c(params);
    params.a.put("android:fade:transitionAlpha", Float.valueOf(d0.c(params.b)));
  }
  
  class a extends n {
    final View a;
    
    a(d this$0, View param1View) {}
    
    public void b(m param1m) {
      d0.a(this.a, 1.0F);
      d0.a(this.a);
      param1m.b(this);
    }
  }
  
  private static class b extends AnimatorListenerAdapter {
    private final View a;
    
    private boolean b = false;
    
    b(View param1View) {
      this.a = param1View;
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      d0.a(this.a, 1.0F);
      if (this.b)
        this.a.setLayerType(0, null); 
    }
    
    public void onAnimationStart(Animator param1Animator) {
      if (u.v(this.a) && this.a.getLayerType() == 0) {
        this.b = true;
        this.a.setLayerType(2, null);
      } 
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */