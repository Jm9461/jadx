package a.b.f;

import android.animation.TypeEvaluator;
import android.graphics.Rect;

class k implements TypeEvaluator<Rect> {
  private Rect a;
  
  public Rect a(float paramFloat, Rect paramRect1, Rect paramRect2) {
    int i = paramRect1.left;
    i += (int)((paramRect2.left - i) * paramFloat);
    int j = paramRect1.top;
    j += (int)((paramRect2.top - j) * paramFloat);
    int m = paramRect1.right;
    m += (int)((paramRect2.right - m) * paramFloat);
    int n = paramRect1.bottom;
    n += (int)((paramRect2.bottom - n) * paramFloat);
    paramRect1 = this.a;
    if (paramRect1 == null)
      return new Rect(i, j, m, n); 
    paramRect1.set(i, j, m, n);
    return this.a;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */