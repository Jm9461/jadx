package a.b.f;

import android.graphics.Path;

public abstract class g {
  public abstract Path a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */