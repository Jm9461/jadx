package a.b.f;

import android.view.View;
import android.view.WindowId;

class k0 implements l0 {
  private final WindowId a;
  
  k0(View paramView) {
    this.a = paramView.getWindowId();
  }
  
  public boolean equals(Object paramObject) {
    boolean bool;
    if (paramObject instanceof k0 && ((k0)paramObject).a.equals(this.a)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int hashCode() {
    return this.a.hashCode();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */