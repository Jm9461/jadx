package a.b.f;

import android.animation.LayoutTransition;
import android.util.Log;
import android.view.ViewGroup;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

class y {
  private static LayoutTransition a;
  
  private static Field b;
  
  private static boolean c;
  
  private static Method d;
  
  private static boolean e;
  
  private static void a(LayoutTransition paramLayoutTransition) {
    if (!e) {
      try {
        d = LayoutTransition.class.getDeclaredMethod("cancel", new Class[0]);
        d.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ViewGroupUtilsApi14", "Failed to access cancel method by reflection");
      } 
      e = true;
    } 
    Method method = d;
    if (method != null)
      try {
        method.invoke(paramLayoutTransition, new Object[0]);
      } catch (IllegalAccessException illegalAccessException) {
        Log.i("ViewGroupUtilsApi14", "Failed to access cancel method by reflection");
      } catch (InvocationTargetException invocationTargetException) {
        Log.i("ViewGroupUtilsApi14", "Failed to invoke cancel method by reflection");
      }  
  }
  
  static void a(ViewGroup paramViewGroup, boolean paramBoolean) {
    if (a == null) {
      a = new a();
      a.setAnimator(2, null);
      a.setAnimator(0, null);
      a.setAnimator(1, null);
      a.setAnimator(3, null);
      a.setAnimator(4, null);
    } 
    if (paramBoolean) {
      LayoutTransition layoutTransition = paramViewGroup.getLayoutTransition();
      if (layoutTransition != null) {
        if (layoutTransition.isRunning())
          a(layoutTransition); 
        if (layoutTransition != a)
          paramViewGroup.setTag(j.transition_layout_save, layoutTransition); 
      } 
      paramViewGroup.setLayoutTransition(a);
    } else {
      paramViewGroup.setLayoutTransition(null);
      if (!c) {
        try {
          b = ViewGroup.class.getDeclaredField("mLayoutSuppressed");
          b.setAccessible(true);
        } catch (NoSuchFieldException noSuchFieldException) {
          Log.i("ViewGroupUtilsApi14", "Failed to access mLayoutSuppressed field by reflection");
        } 
        c = true;
      } 
      paramBoolean = false;
      boolean bool = false;
      Field field = b;
      if (field != null) {
        paramBoolean = bool;
        try {
          bool = field.getBoolean(paramViewGroup);
          if (bool) {
            paramBoolean = bool;
            b.setBoolean(paramViewGroup, false);
          } 
          paramBoolean = bool;
        } catch (IllegalAccessException illegalAccessException) {
          Log.i("ViewGroupUtilsApi14", "Failed to get mLayoutSuppressed field by reflection");
        } 
      } 
      if (paramBoolean)
        paramViewGroup.requestLayout(); 
      LayoutTransition layoutTransition = (LayoutTransition)paramViewGroup.getTag(j.transition_layout_save);
      if (layoutTransition != null) {
        paramViewGroup.setTag(j.transition_layout_save, null);
        paramViewGroup.setLayoutTransition(layoutTransition);
      } 
    } 
  }
  
  static final class a extends LayoutTransition {
    public boolean isChangingLayout() {
      return true;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */