package a.b.f;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewOverlay;

class b0 implements c0 {
  private final ViewOverlay a;
  
  b0(View paramView) {
    this.a = paramView.getOverlay();
  }
  
  public void a(Drawable paramDrawable) {
    this.a.add(paramDrawable);
  }
  
  public void b(Drawable paramDrawable) {
    this.a.remove(paramDrawable);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */