package a.b.f;

import android.view.View;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class s {
  public final Map<String, Object> a = new HashMap<String, Object>();
  
  public View b;
  
  final ArrayList<m> c = new ArrayList<m>();
  
  public boolean equals(Object paramObject) {
    return (paramObject instanceof s && this.b == ((s)paramObject).b && this.a.equals(((s)paramObject).a));
  }
  
  public int hashCode() {
    return this.b.hashCode() * 31 + this.a.hashCode();
  }
  
  public String toString() {
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("TransitionValues@");
    stringBuilder1.append(Integer.toHexString(hashCode()));
    stringBuilder1.append(":\n");
    String str2 = stringBuilder1.toString();
    stringBuilder1 = new StringBuilder();
    stringBuilder1.append(str2);
    stringBuilder1.append("    view = ");
    stringBuilder1.append(this.b);
    stringBuilder1.append("\n");
    String str1 = stringBuilder1.toString();
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(str1);
    stringBuilder2.append("    values:");
    str1 = stringBuilder2.toString();
    for (String str : this.a.keySet()) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str1);
      stringBuilder.append("    ");
      stringBuilder.append(str);
      stringBuilder.append(": ");
      stringBuilder.append(this.a.get(str));
      stringBuilder.append("\n");
      str1 = stringBuilder.toString();
    } 
    return str1;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */