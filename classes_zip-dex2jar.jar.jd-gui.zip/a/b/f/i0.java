package a.b.f;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewGroup;

public abstract class i0 extends m {
  private static final String[] M = new String[] { "android:visibility:visibility", "android:visibility:parent" };
  
  private int L = 3;
  
  private c b(s params1, s params2) {
    c c = new c();
    c.a = false;
    c.b = false;
    if (params1 != null && params1.a.containsKey("android:visibility:visibility")) {
      c.c = ((Integer)params1.a.get("android:visibility:visibility")).intValue();
      c.e = (ViewGroup)params1.a.get("android:visibility:parent");
    } else {
      c.c = -1;
      c.e = null;
    } 
    if (params2 != null && params2.a.containsKey("android:visibility:visibility")) {
      c.d = ((Integer)params2.a.get("android:visibility:visibility")).intValue();
      c.f = (ViewGroup)params2.a.get("android:visibility:parent");
    } else {
      c.d = -1;
      c.f = null;
    } 
    if (params1 != null && params2 != null) {
      if (c.c == c.d && c.e == c.f)
        return c; 
      int i = c.c;
      int j = c.d;
      if (i != j) {
        if (i == 0) {
          c.b = false;
          c.a = true;
        } else if (j == 0) {
          c.b = true;
          c.a = true;
        } 
      } else if (c.f == null) {
        c.b = false;
        c.a = true;
      } else if (c.e == null) {
        c.b = true;
        c.a = true;
      } 
    } else if (params1 == null && c.d == 0) {
      c.b = true;
      c.a = true;
    } else if (params2 == null && c.c == 0) {
      c.b = false;
      c.a = true;
    } 
    return c;
  }
  
  private void d(s params) {
    int i = params.b.getVisibility();
    params.a.put("android:visibility:visibility", Integer.valueOf(i));
    params.a.put("android:visibility:parent", params.b.getParent());
    int[] arrayOfInt = new int[2];
    params.b.getLocationOnScreen(arrayOfInt);
    params.a.put("android:visibility:screenLocation", arrayOfInt);
  }
  
  public Animator a(ViewGroup paramViewGroup, s params1, int paramInt1, s params2, int paramInt2) {
    if ((this.L & 0x1) != 1 || params2 == null)
      return null; 
    if (params1 == null) {
      View view = (View)params2.b.getParent();
      s s1 = a(view, false);
      s s2 = b(view, false);
      if ((b(s1, s2)).a)
        return null; 
    } 
    return a(paramViewGroup, params2.b, params1, params2);
  }
  
  public Animator a(ViewGroup paramViewGroup, s params1, s params2) {
    c c = b(params1, params2);
    return (c.a && (c.e != null || c.f != null)) ? (c.b ? a(paramViewGroup, params1, c.c, params2, c.d) : b(paramViewGroup, params1, c.c, params2, c.d)) : null;
  }
  
  public abstract Animator a(ViewGroup paramViewGroup, View paramView, s params1, s params2);
  
  public void a(int paramInt) {
    if ((paramInt & 0xFFFFFFFC) == 0) {
      this.L = paramInt;
      return;
    } 
    throw new IllegalArgumentException("Only MODE_IN and MODE_OUT flags are allowed");
  }
  
  public void a(s params) {
    d(params);
  }
  
  public boolean a(s params1, s params2) {
    boolean bool = false;
    if (params1 == null && params2 == null)
      return false; 
    if (params1 != null && params2 != null && params2.a.containsKey("android:visibility:visibility") != params1.a.containsKey("android:visibility:visibility"))
      return false; 
    c c = b(params1, params2);
    null = bool;
    if (c.a) {
      if (c.c != 0) {
        null = bool;
        return (c.d == 0) ? true : null;
      } 
    } else {
      return null;
    } 
    return true;
  }
  
  public Animator b(ViewGroup paramViewGroup, s params1, int paramInt1, s params2, int paramInt2) {
    Animator animator;
    View view1;
    View view2;
    s s1;
    if ((this.L & 0x2) != 2)
      return null; 
    if (params1 != null) {
      view2 = params1.b;
    } else {
      view2 = null;
    } 
    if (params2 != null) {
      view1 = params2.b;
    } else {
      view1 = null;
    } 
    View view3 = null;
    s s2 = null;
    if (view1 == null || view1.getParent() == null) {
      if (view1 != null) {
        s1 = s2;
      } else {
        view1 = view3;
        s1 = s2;
        if (view2 != null)
          if (view2.getParent() == null) {
            view1 = view2;
            s1 = s2;
          } else {
            view1 = view3;
            s1 = s2;
            if (view2.getParent() instanceof View) {
              View view = (View)view2.getParent();
              s s3 = b(view, true);
              s1 = a(view, true);
              if (!(b(s3, s1)).a) {
                View view4 = r.a(paramViewGroup, view2, view);
                s1 = s2;
              } else {
                view1 = view3;
                s1 = s2;
                if (view.getParent() == null) {
                  paramInt1 = view.getId();
                  view1 = view3;
                  s1 = s2;
                  if (paramInt1 != -1) {
                    view1 = view3;
                    s1 = s2;
                    if (paramViewGroup.findViewById(paramInt1) != null) {
                      view1 = view3;
                      s1 = s2;
                      if (this.x) {
                        view1 = view2;
                        s1 = s2;
                      } 
                    } 
                  } 
                } 
              } 
            } 
          }  
      } 
    } else if (paramInt2 == 4) {
      View view = view1;
      view1 = view3;
    } else if (view2 == view1) {
      View view = view1;
      view1 = view3;
    } else if (this.x) {
      view1 = view2;
      s1 = s2;
    } else {
      view1 = r.a(paramViewGroup, view2, (View)view2.getParent());
      s1 = s2;
    } 
    if (view1 != null && params1 != null) {
      int[] arrayOfInt = (int[])params1.a.get("android:visibility:screenLocation");
      paramInt1 = arrayOfInt[0];
      paramInt2 = arrayOfInt[1];
      arrayOfInt = new int[2];
      paramViewGroup.getLocationOnScreen(arrayOfInt);
      view1.offsetLeftAndRight(paramInt1 - arrayOfInt[0] - view1.getLeft());
      view1.offsetTopAndBottom(paramInt2 - arrayOfInt[1] - view1.getTop());
      w w = x.a(paramViewGroup);
      w.a(view1);
      animator = b(paramViewGroup, view1, params1, params2);
      if (animator == null) {
        w.b(view1);
      } else {
        animator.addListener((Animator.AnimatorListener)new a(this, w, view1));
      } 
      return animator;
    } 
    if (s1 != null) {
      paramInt1 = s1.getVisibility();
      d0.a((View)s1, 0);
      animator = b((ViewGroup)animator, (View)s1, params1, params2);
      if (animator != null) {
        b b = new b((View)s1, paramInt2, true);
        animator.addListener((Animator.AnimatorListener)b);
        a.a(animator, b);
        a(b);
      } else {
        d0.a((View)s1, paramInt1);
      } 
      return animator;
    } 
    return null;
  }
  
  public abstract Animator b(ViewGroup paramViewGroup, View paramView, s params1, s params2);
  
  public void c(s params) {
    d(params);
  }
  
  public String[] n() {
    return M;
  }
  
  class a extends AnimatorListenerAdapter {
    final w a;
    
    final View b;
    
    a(i0 this$0, w param1w, View param1View) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.b(this.b);
    }
  }
  
  private static class b extends AnimatorListenerAdapter implements m.f, a.a {
    private final View a;
    
    private final int b;
    
    private final ViewGroup c;
    
    private final boolean d;
    
    private boolean e;
    
    boolean f = false;
    
    b(View param1View, int param1Int, boolean param1Boolean) {
      this.a = param1View;
      this.b = param1Int;
      this.c = (ViewGroup)param1View.getParent();
      this.d = param1Boolean;
      a(true);
    }
    
    private void a() {
      if (!this.f) {
        d0.a(this.a, this.b);
        ViewGroup viewGroup = this.c;
        if (viewGroup != null)
          viewGroup.invalidate(); 
      } 
      a(false);
    }
    
    private void a(boolean param1Boolean) {
      if (this.d && this.e != param1Boolean) {
        ViewGroup viewGroup = this.c;
        if (viewGroup != null) {
          this.e = param1Boolean;
          x.a(viewGroup, param1Boolean);
        } 
      } 
    }
    
    public void a(m param1m) {
      a(false);
    }
    
    public void b(m param1m) {
      a();
      param1m.b(this);
    }
    
    public void c(m param1m) {}
    
    public void d(m param1m) {
      a(true);
    }
    
    public void onAnimationCancel(Animator param1Animator) {
      this.f = true;
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      a();
    }
    
    public void onAnimationPause(Animator param1Animator) {
      if (!this.f)
        d0.a(this.a, this.b); 
    }
    
    public void onAnimationRepeat(Animator param1Animator) {}
    
    public void onAnimationResume(Animator param1Animator) {
      if (!this.f)
        d0.a(this.a, 0); 
    }
    
    public void onAnimationStart(Animator param1Animator) {}
  }
  
  private static class c {
    boolean a;
    
    boolean b;
    
    int c;
    
    int d;
    
    ViewGroup e;
    
    ViewGroup f;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\i0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */