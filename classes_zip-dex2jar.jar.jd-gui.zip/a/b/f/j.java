package a.b.f;

public final class j {
  public static final int action_container = 2131296286;
  
  public static final int action_divider = 2131296289;
  
  public static final int action_image = 2131296292;
  
  public static final int action_text = 2131296304;
  
  public static final int actions = 2131296307;
  
  public static final int async = 2131296318;
  
  public static final int blocking = 2131296325;
  
  public static final int chronometer = 2131296382;
  
  public static final int forever = 2131296447;
  
  public static final int ghost_view = 2131296451;
  
  public static final int icon = 2131296462;
  
  public static final int icon_group = 2131296463;
  
  public static final int info = 2131296485;
  
  public static final int italic = 2131296554;
  
  public static final int line1 = 2131296563;
  
  public static final int line3 = 2131296564;
  
  public static final int normal = 2131296646;
  
  public static final int notification_background = 2131296647;
  
  public static final int notification_main_column = 2131296648;
  
  public static final int notification_main_column_container = 2131296649;
  
  public static final int parent_matrix = 2131296664;
  
  public static final int right_icon = 2131296691;
  
  public static final int right_side = 2131296692;
  
  public static final int save_image_matrix = 2131296698;
  
  public static final int save_non_transition_alpha = 2131296699;
  
  public static final int save_scale_type = 2131296700;
  
  public static final int tag_transition_group = 2131296767;
  
  public static final int tag_unhandled_key_event_manager = 2131296768;
  
  public static final int tag_unhandled_key_listeners = 2131296769;
  
  public static final int text = 2131296770;
  
  public static final int text2 = 2131296771;
  
  public static final int time = 2131296824;
  
  public static final int title = 2131296831;
  
  public static final int transition_current_scene = 2131296844;
  
  public static final int transition_layout_save = 2131296845;
  
  public static final int transition_position = 2131296846;
  
  public static final int transition_scene_layoutid_cache = 2131296847;
  
  public static final int transition_transform = 2131296848;
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */