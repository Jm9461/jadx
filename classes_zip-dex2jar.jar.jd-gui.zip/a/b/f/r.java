package a.b.f;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Picture;
import android.graphics.RectF;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

class r {
  private static final boolean a;
  
  private static final boolean b;
  
  private static final boolean c;
  
  static {
    boolean bool1;
    int i = Build.VERSION.SDK_INT;
    boolean bool2 = true;
    if (i >= 19) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    a = bool1;
    if (Build.VERSION.SDK_INT >= 18) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    b = bool1;
    if (Build.VERSION.SDK_INT >= 28) {
      bool1 = bool2;
    } else {
      bool1 = false;
    } 
    c = bool1;
  }
  
  static Animator a(Animator paramAnimator1, Animator paramAnimator2) {
    if (paramAnimator1 == null)
      return paramAnimator2; 
    if (paramAnimator2 == null)
      return paramAnimator1; 
    AnimatorSet animatorSet = new AnimatorSet();
    animatorSet.playTogether(new Animator[] { paramAnimator1, paramAnimator2 });
    return (Animator)animatorSet;
  }
  
  private static Bitmap a(View paramView, Matrix paramMatrix, RectF paramRectF, ViewGroup paramViewGroup) {
    boolean bool1;
    boolean bool2;
    Bitmap bitmap;
    if (a) {
      bool1 = paramView.isAttachedToWindow() ^ true;
      if (paramViewGroup == null) {
        bool2 = false;
      } else {
        bool2 = paramViewGroup.isAttachedToWindow();
      } 
    } else {
      bool1 = false;
      bool2 = false;
    } 
    ViewGroup viewGroup1 = null;
    int j = 0;
    ViewGroup viewGroup2 = viewGroup1;
    int i = j;
    if (b) {
      viewGroup2 = viewGroup1;
      i = j;
      if (bool1) {
        if (!bool2)
          return null; 
        viewGroup2 = (ViewGroup)paramView.getParent();
        i = viewGroup2.indexOfChild(paramView);
        paramViewGroup.getOverlay().add(paramView);
      } 
    } 
    ViewGroup viewGroup3 = null;
    int k = Math.round(paramRectF.width());
    j = Math.round(paramRectF.height());
    viewGroup1 = viewGroup3;
    if (k > 0) {
      viewGroup1 = viewGroup3;
      if (j > 0) {
        float f = Math.min(1.0F, 1048576.0F / (k * j));
        k = Math.round(k * f);
        j = Math.round(j * f);
        paramMatrix.postTranslate(-paramRectF.left, -paramRectF.top);
        paramMatrix.postScale(f, f);
        if (c) {
          Picture picture = new Picture();
          Canvas canvas = picture.beginRecording(k, j);
          canvas.concat(paramMatrix);
          paramView.draw(canvas);
          picture.endRecording();
          bitmap = Bitmap.createBitmap(picture);
        } else {
          bitmap = Bitmap.createBitmap(k, j, Bitmap.Config.ARGB_8888);
          Canvas canvas = new Canvas(bitmap);
          canvas.concat(paramMatrix);
          paramView.draw(canvas);
        } 
      } 
    } 
    if (b && bool1) {
      paramViewGroup.getOverlay().remove(paramView);
      viewGroup2.addView(paramView, i);
    } 
    return bitmap;
  }
  
  static View a(ViewGroup paramViewGroup, View paramView1, View paramView2) {
    Matrix matrix = new Matrix();
    matrix.setTranslate(-paramView2.getScrollX(), -paramView2.getScrollY());
    d0.a(paramView1, matrix);
    d0.b((View)paramViewGroup, matrix);
    RectF rectF = new RectF(0.0F, 0.0F, paramView1.getWidth(), paramView1.getHeight());
    matrix.mapRect(rectF);
    int k = Math.round(rectF.left);
    int m = Math.round(rectF.top);
    int i = Math.round(rectF.right);
    int j = Math.round(rectF.bottom);
    ImageView imageView = new ImageView(paramView1.getContext());
    imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
    Bitmap bitmap = a(paramView1, matrix, rectF, paramViewGroup);
    if (bitmap != null)
      imageView.setImageBitmap(bitmap); 
    imageView.measure(View.MeasureSpec.makeMeasureSpec(i - k, 1073741824), View.MeasureSpec.makeMeasureSpec(j - m, 1073741824));
    imageView.layout(k, m, i, j);
    return (View)imageView;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */