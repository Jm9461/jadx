package a.b.f;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

class u extends a0 implements w {
  u(Context paramContext, ViewGroup paramViewGroup, View paramView) {
    super(paramContext, paramViewGroup, paramView);
  }
  
  static u a(ViewGroup paramViewGroup) {
    return (u)a0.c((View)paramViewGroup);
  }
  
  public void a(View paramView) {
    this.a.a(paramView);
  }
  
  public void b(View paramView) {
    this.a.b(paramView);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */