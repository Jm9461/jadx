package a.a.a.b;

import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

public class b<K, V> implements Iterable<Map.Entry<K, V>> {
  private d<K, V> c;
  
  private d<K, V> d;
  
  private WeakHashMap<g<K, V>, Boolean> e = new WeakHashMap<g<K, V>, Boolean>();
  
  private int f = 0;
  
  protected d<K, V> a(K paramK) {
    d<K, V> d1;
    for (d1 = this.c; d1 != null && !d1.c.equals(paramK); d1 = d1.e);
    return d1;
  }
  
  protected d<K, V> a(K paramK, V paramV) {
    d<K, V> d1 = new d<K, V>(paramK, paramV);
    this.f++;
    d<K, V> d2 = this.d;
    if (d2 == null) {
      this.c = d1;
      this.d = this.c;
      return d1;
    } 
    d2.e = d1;
    d1.f = d2;
    this.d = d1;
    return d1;
  }
  
  public Iterator<Map.Entry<K, V>> a() {
    c<K, V> c = new c<K, V>(this.d, this.c);
    this.e.put(c, Boolean.valueOf(false));
    return c;
  }
  
  public V b(K paramK, V paramV) {
    d<K, V> d1 = a(paramK);
    if (d1 != null)
      return d1.d; 
    a(paramK, paramV);
    return null;
  }
  
  public Map.Entry<K, V> b() {
    return this.c;
  }
  
  public e c() {
    e e = new e(null);
    this.e.put(e, Boolean.valueOf(false));
    return e;
  }
  
  public Map.Entry<K, V> d() {
    return this.d;
  }
  
  public boolean equals(Object<Map.Entry<K, V>> paramObject) {
    boolean bool = true;
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof b))
      return false; 
    b b1 = (b)paramObject;
    if (size() != b1.size())
      return false; 
    paramObject = (Object<Map.Entry<K, V>>)iterator();
    Iterator<Object> iterator = b1.iterator();
    while (paramObject.hasNext() && iterator.hasNext()) {
      Map.Entry entry = paramObject.next();
      Object object = iterator.next();
      if ((entry == null && object != null) || (entry != null && !entry.equals(object)))
        return false; 
    } 
    if (paramObject.hasNext() || iterator.hasNext())
      bool = false; 
    return bool;
  }
  
  public Iterator<Map.Entry<K, V>> iterator() {
    b<K, V> b1 = new b<K, V>(this.c, this.d);
    this.e.put(b1, Boolean.valueOf(false));
    return b1;
  }
  
  public V remove(K paramK) {
    d<K, V> d1 = a(paramK);
    if (d1 == null)
      return null; 
    this.f--;
    if (!this.e.isEmpty()) {
      Iterator<g<K, V>> iterator = this.e.keySet().iterator();
      while (iterator.hasNext())
        ((g<K, V>)iterator.next()).a(d1); 
    } 
    d<K, V> d2 = d1.f;
    if (d2 != null) {
      d2.e = d1.e;
    } else {
      this.c = d1.e;
    } 
    d2 = d1.e;
    if (d2 != null) {
      d2.f = d1.f;
    } else {
      this.d = d1.f;
    } 
    d1.e = null;
    d1.f = null;
    return d1.d;
  }
  
  public int size() {
    return this.f;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[");
    Iterator<Map.Entry<K, V>> iterator = iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(((Map.Entry)iterator.next()).toString());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append("]");
    return stringBuilder.toString();
  }
  
  static class b<K, V> extends f<K, V> {
    b(b.d<K, V> param1d1, b.d<K, V> param1d2) {
      super(param1d1, param1d2);
    }
    
    b.d<K, V> b(b.d<K, V> param1d) {
      return param1d.f;
    }
    
    b.d<K, V> c(b.d<K, V> param1d) {
      return param1d.e;
    }
  }
  
  private static class c<K, V> extends f<K, V> {
    c(b.d<K, V> param1d1, b.d<K, V> param1d2) {
      super(param1d1, param1d2);
    }
    
    b.d<K, V> b(b.d<K, V> param1d) {
      return param1d.e;
    }
    
    b.d<K, V> c(b.d<K, V> param1d) {
      return param1d.f;
    }
  }
  
  static class d<K, V> implements Map.Entry<K, V> {
    final K c;
    
    final V d;
    
    d<K, V> e;
    
    d<K, V> f;
    
    d(K param1K, V param1V) {
      this.c = param1K;
      this.d = param1V;
    }
    
    public boolean equals(Object param1Object) {
      boolean bool = true;
      if (param1Object == this)
        return true; 
      if (!(param1Object instanceof d))
        return false; 
      param1Object = param1Object;
      if (!this.c.equals(((d)param1Object).c) || !this.d.equals(((d)param1Object).d))
        bool = false; 
      return bool;
    }
    
    public K getKey() {
      return this.c;
    }
    
    public V getValue() {
      return this.d;
    }
    
    public V setValue(V param1V) {
      throw new UnsupportedOperationException("An entry modification is not supported");
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.c);
      stringBuilder.append("=");
      stringBuilder.append(this.d);
      return stringBuilder.toString();
    }
  }
  
  private class e implements Iterator<Map.Entry<K, V>>, g<K, V> {
    private b.d<K, V> c;
    
    private boolean d = true;
    
    final b e;
    
    private e(b this$0) {}
    
    public void a(b.d<K, V> param1d) {
      b.d<K, V> d1 = this.c;
      if (param1d == d1) {
        boolean bool;
        this.c = d1.f;
        if (this.c == null) {
          bool = true;
        } else {
          bool = false;
        } 
        this.d = bool;
      } 
    }
    
    public boolean hasNext() {
      boolean bool = this.d;
      boolean bool2 = true;
      boolean bool1 = true;
      if (bool) {
        if (b.a(this.e) == null)
          bool1 = false; 
        return bool1;
      } 
      b.d<K, V> d1 = this.c;
      if (d1 != null && d1.e != null) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      return bool1;
    }
    
    public Map.Entry<K, V> next() {
      if (this.d) {
        this.d = false;
        this.c = b.a(this.e);
      } else {
        b.d<K, V> d1 = this.c;
        if (d1 != null) {
          d1 = d1.e;
        } else {
          d1 = null;
        } 
        this.c = d1;
      } 
      return this.c;
    }
  }
  
  private static abstract class f<K, V> implements Iterator<Map.Entry<K, V>>, g<K, V> {
    b.d<K, V> c;
    
    b.d<K, V> d;
    
    f(b.d<K, V> param1d1, b.d<K, V> param1d2) {
      this.c = param1d2;
      this.d = param1d1;
    }
    
    private b.d<K, V> a() {
      b.d<K, V> d1 = this.d;
      b.d<K, V> d2 = this.c;
      return (d1 == d2 || d2 == null) ? null : c(d1);
    }
    
    public void a(b.d<K, V> param1d) {
      if (this.c == param1d && param1d == this.d) {
        this.d = null;
        this.c = null;
      } 
      b.d<K, V> d1 = this.c;
      if (d1 == param1d)
        this.c = b(d1); 
      if (this.d == param1d)
        this.d = a(); 
    }
    
    abstract b.d<K, V> b(b.d<K, V> param1d);
    
    abstract b.d<K, V> c(b.d<K, V> param1d);
    
    public boolean hasNext() {
      boolean bool;
      if (this.d != null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public Map.Entry<K, V> next() {
      b.d<K, V> d1 = this.d;
      this.d = a();
      return d1;
    }
  }
  
  static interface g<K, V> {
    void a(b.d<K, V> param1d);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\a\a\b\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */