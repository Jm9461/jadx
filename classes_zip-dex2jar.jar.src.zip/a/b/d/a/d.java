package a.b.d.a;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.os.Build;
import android.support.v4.view.e0.a;
import android.support.v4.view.e0.b;
import android.support.v4.view.e0.c;
import android.util.AttributeSet;
import android.util.Xml;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.AnticipateOvershootInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.CycleInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class d {
  public static Interpolator a(Context paramContext, int paramInt) {
    if (Build.VERSION.SDK_INT >= 21)
      return AnimationUtils.loadInterpolator(paramContext, paramInt); 
    XmlResourceParser xmlResourceParser2 = null;
    XmlResourceParser xmlResourceParser3 = null;
    XmlResourceParser xmlResourceParser1 = null;
    if (paramInt == 17563663) {
      try {
        a a = new a();
        if (false)
          throw new NullPointerException(); 
        return (Interpolator)a;
      } catch (XmlPullParserException xmlPullParserException) {
      
      } catch (IOException iOException) {
      
      } finally {}
    } else {
      c c;
      if (paramInt == 17563661) {
        b b = new b();
        if (false)
          throw new NullPointerException(); 
        return (Interpolator)b;
      } 
      if (paramInt == 17563662) {
        c = new c();
        if (false)
          throw new NullPointerException(); 
        return (Interpolator)c;
      } 
      XmlResourceParser xmlResourceParser = c.getResources().getAnimation(paramInt);
      xmlResourceParser1 = xmlResourceParser;
      xmlResourceParser2 = xmlResourceParser;
      xmlResourceParser3 = xmlResourceParser;
      interpolator = a((Context)c, c.getResources(), c.getTheme(), (XmlPullParser)xmlResourceParser);
      if (xmlResourceParser != null)
        xmlResourceParser.close(); 
      return interpolator;
    } 
    xmlResourceParser1 = xmlResourceParser2;
    Resources.NotFoundException notFoundException = new Resources.NotFoundException();
    xmlResourceParser1 = xmlResourceParser2;
    StringBuilder stringBuilder = new StringBuilder();
    xmlResourceParser1 = xmlResourceParser2;
    this();
    Interpolator interpolator;
    xmlResourceParser1 = xmlResourceParser2;
    stringBuilder.append("Can't load animation resource ID #0x");
    xmlResourceParser1 = xmlResourceParser2;
    stringBuilder.append(Integer.toHexString(paramInt));
    xmlResourceParser1 = xmlResourceParser2;
    this(stringBuilder.toString());
    xmlResourceParser1 = xmlResourceParser2;
    notFoundException.initCause((Throwable)interpolator);
    xmlResourceParser1 = xmlResourceParser2;
    throw notFoundException;
  }
  
  private static Interpolator a(Context paramContext, Resources paramResources, Resources.Theme paramTheme, XmlPullParser paramXmlPullParser) {
    g g;
    paramResources = null;
    int i = paramXmlPullParser.getDepth();
    while (true) {
      int j = paramXmlPullParser.next();
      if ((j != 3 || paramXmlPullParser.getDepth() > i) && j != 1) {
        LinearInterpolator linearInterpolator;
        AccelerateInterpolator accelerateInterpolator;
        DecelerateInterpolator decelerateInterpolator;
        AccelerateDecelerateInterpolator accelerateDecelerateInterpolator;
        CycleInterpolator cycleInterpolator;
        AnticipateInterpolator anticipateInterpolator;
        OvershootInterpolator overshootInterpolator;
        AnticipateOvershootInterpolator anticipateOvershootInterpolator;
        BounceInterpolator bounceInterpolator;
        if (j != 2)
          continue; 
        AttributeSet attributeSet = Xml.asAttributeSet(paramXmlPullParser);
        String str = paramXmlPullParser.getName();
        if (str.equals("linearInterpolator")) {
          linearInterpolator = new LinearInterpolator();
          continue;
        } 
        if (linearInterpolator.equals("accelerateInterpolator")) {
          accelerateInterpolator = new AccelerateInterpolator(paramContext, attributeSet);
          continue;
        } 
        if (accelerateInterpolator.equals("decelerateInterpolator")) {
          decelerateInterpolator = new DecelerateInterpolator(paramContext, attributeSet);
          continue;
        } 
        if (decelerateInterpolator.equals("accelerateDecelerateInterpolator")) {
          accelerateDecelerateInterpolator = new AccelerateDecelerateInterpolator();
          continue;
        } 
        if (accelerateDecelerateInterpolator.equals("cycleInterpolator")) {
          cycleInterpolator = new CycleInterpolator(paramContext, attributeSet);
          continue;
        } 
        if (cycleInterpolator.equals("anticipateInterpolator")) {
          anticipateInterpolator = new AnticipateInterpolator(paramContext, attributeSet);
          continue;
        } 
        if (anticipateInterpolator.equals("overshootInterpolator")) {
          overshootInterpolator = new OvershootInterpolator(paramContext, attributeSet);
          continue;
        } 
        if (overshootInterpolator.equals("anticipateOvershootInterpolator")) {
          anticipateOvershootInterpolator = new AnticipateOvershootInterpolator(paramContext, attributeSet);
          continue;
        } 
        if (anticipateOvershootInterpolator.equals("bounceInterpolator")) {
          bounceInterpolator = new BounceInterpolator();
          continue;
        } 
        if (bounceInterpolator.equals("pathInterpolator")) {
          g = new g(paramContext, attributeSet, paramXmlPullParser);
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unknown interpolator name: ");
        stringBuilder.append(paramXmlPullParser.getName());
        throw new RuntimeException(stringBuilder.toString());
      } 
      break;
    } 
    return g;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\d\a\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */