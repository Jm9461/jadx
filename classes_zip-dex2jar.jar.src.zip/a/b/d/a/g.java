package a.b.d.a;

import a.b.g.a.b;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.util.AttributeSet;
import android.view.InflateException;
import android.view.animation.Interpolator;
import org.xmlpull.v1.XmlPullParser;

public class g implements Interpolator {
  private float[] a;
  
  private float[] b;
  
  public g(Context paramContext, AttributeSet paramAttributeSet, XmlPullParser paramXmlPullParser) {
    this(paramContext.getResources(), paramContext.getTheme(), paramAttributeSet, paramXmlPullParser);
  }
  
  public g(Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, XmlPullParser paramXmlPullParser) {
    TypedArray typedArray = android.support.v4.content.e.g.a(paramResources, paramTheme, paramAttributeSet, a.l);
    a(typedArray, paramXmlPullParser);
    typedArray.recycle();
  }
  
  private void a(float paramFloat1, float paramFloat2) {
    Path path = new Path();
    path.moveTo(0.0F, 0.0F);
    path.quadTo(paramFloat1, paramFloat2, 1.0F, 1.0F);
    a(path);
  }
  
  private void a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    Path path = new Path();
    path.moveTo(0.0F, 0.0F);
    path.cubicTo(paramFloat1, paramFloat2, paramFloat3, paramFloat4, 1.0F, 1.0F);
    a(path);
  }
  
  private void a(TypedArray paramTypedArray, XmlPullParser paramXmlPullParser) {
    String str;
    StringBuilder stringBuilder;
    if (android.support.v4.content.e.g.a(paramXmlPullParser, "pathData")) {
      str = android.support.v4.content.e.g.a(paramTypedArray, paramXmlPullParser, "pathData", 4);
      Path path = b.b(str);
      if (path != null) {
        a(path);
      } else {
        stringBuilder = new StringBuilder();
        stringBuilder.append("The path is null, which is created from ");
        stringBuilder.append(str);
        throw new InflateException(stringBuilder.toString());
      } 
    } else {
      if (android.support.v4.content.e.g.a((XmlPullParser)stringBuilder, "controlX1")) {
        if (android.support.v4.content.e.g.a((XmlPullParser)stringBuilder, "controlY1")) {
          float f1 = android.support.v4.content.e.g.a((TypedArray)str, (XmlPullParser)stringBuilder, "controlX1", 0, 0.0F);
          float f2 = android.support.v4.content.e.g.a((TypedArray)str, (XmlPullParser)stringBuilder, "controlY1", 1, 0.0F);
          boolean bool = android.support.v4.content.e.g.a((XmlPullParser)stringBuilder, "controlX2");
          if (bool == android.support.v4.content.e.g.a((XmlPullParser)stringBuilder, "controlY2")) {
            if (!bool) {
              a(f1, f2);
            } else {
              a(f1, f2, android.support.v4.content.e.g.a((TypedArray)str, (XmlPullParser)stringBuilder, "controlX2", 2, 0.0F), android.support.v4.content.e.g.a((TypedArray)str, (XmlPullParser)stringBuilder, "controlY2", 3, 0.0F));
            } 
            return;
          } 
          throw new InflateException("pathInterpolator requires both controlX2 and controlY2 for cubic Beziers.");
        } 
        throw new InflateException("pathInterpolator requires the controlY1 attribute");
      } 
      throw new InflateException("pathInterpolator requires the controlX1 attribute");
    } 
  }
  
  private void a(Path paramPath) {
    PathMeasure pathMeasure = new PathMeasure(paramPath, false);
    float f = pathMeasure.getLength();
    int i = Math.min(3000, (int)(f / 0.002F) + 1);
    if (i > 0) {
      this.a = new float[i];
      this.b = new float[i];
      float[] arrayOfFloat = new float[2];
      byte b;
      for (b = 0; b < i; b++) {
        pathMeasure.getPosTan(b * f / (i - 1), arrayOfFloat, null);
        this.a[b] = arrayOfFloat[0];
        this.b[b] = arrayOfFloat[1];
      } 
      if (Math.abs(this.a[0]) <= 1.0E-5D && Math.abs(this.b[0]) <= 1.0E-5D && Math.abs(this.a[i - 1] - 1.0F) <= 1.0E-5D && Math.abs(this.b[i - 1] - 1.0F) <= 1.0E-5D) {
        StringBuilder stringBuilder2;
        f = 0.0F;
        byte b1 = 0;
        b = 0;
        while (b < i) {
          arrayOfFloat = this.a;
          float f1 = arrayOfFloat[b1];
          if (f1 >= f) {
            arrayOfFloat[b] = f1;
            f = f1;
            b++;
            b1++;
            continue;
          } 
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("The Path cannot loop back on itself, x :");
          stringBuilder2.append(f1);
          throw new IllegalArgumentException(stringBuilder2.toString());
        } 
        if (!stringBuilder2.nextContour())
          return; 
        throw new IllegalArgumentException("The Path should be continuous, can't have 2+ contours");
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("The Path must start at (0,0) and end at (1,1) start: ");
      stringBuilder1.append(this.a[0]);
      stringBuilder1.append(",");
      stringBuilder1.append(this.b[0]);
      stringBuilder1.append(" end:");
      stringBuilder1.append(this.a[i - 1]);
      stringBuilder1.append(",");
      stringBuilder1.append(this.b[i - 1]);
      throw new IllegalArgumentException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("The Path has a invalid length ");
    stringBuilder.append(f);
    IllegalArgumentException illegalArgumentException = new IllegalArgumentException(stringBuilder.toString());
    throw illegalArgumentException;
  }
  
  public float getInterpolation(float paramFloat) {
    if (paramFloat <= 0.0F)
      return 0.0F; 
    if (paramFloat >= 1.0F)
      return 1.0F; 
    int j = 0;
    int i = this.a.length - 1;
    while (i - j > 1) {
      int k = (j + i) / 2;
      if (paramFloat < this.a[k]) {
        i = k;
        continue;
      } 
      j = k;
    } 
    float[] arrayOfFloat = this.a;
    float f = arrayOfFloat[i] - arrayOfFloat[j];
    if (f == 0.0F)
      return this.b[j]; 
    paramFloat = (paramFloat - arrayOfFloat[j]) / f;
    arrayOfFloat = this.b;
    f = arrayOfFloat[j];
    return (arrayOfFloat[i] - f) * paramFloat + f;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\d\a\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */