package a.b.d.a;

import android.graphics.drawable.Animatable;

public interface b extends Animatable {}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\d\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */