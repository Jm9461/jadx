package a.b.f;

import android.graphics.Matrix;
import android.graphics.Rect;
import android.os.Build;
import android.support.v4.view.u;
import android.util.Log;
import android.util.Property;
import android.view.View;
import java.lang.reflect.Field;

class d0 {
  private static final h0 a;
  
  private static Field b;
  
  private static boolean c;
  
  static final Property<View, Float> d = new a(Float.class, "translationAlpha");
  
  static {
    new b(Rect.class, "clipBounds");
  }
  
  private static void a() {
    if (!c) {
      try {
        b = View.class.getDeclaredField("mViewFlags");
        b.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {
        Log.i("ViewUtils", "fetchViewFlagsField: ");
      } 
      c = true;
    } 
  }
  
  static void a(View paramView) {
    a.a(paramView);
  }
  
  static void a(View paramView, float paramFloat) {
    a.a(paramView, paramFloat);
  }
  
  static void a(View paramView, int paramInt) {
    a();
    Field field = b;
    if (field != null)
      try {
        int i = field.getInt(paramView);
        b.setInt(paramView, i & 0xFFFFFFF3 | paramInt);
      } catch (IllegalAccessException illegalAccessException) {} 
  }
  
  static void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    a.a(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  static void a(View paramView, Matrix paramMatrix) {
    a.a(paramView, paramMatrix);
  }
  
  static c0 b(View paramView) {
    return (c0)((Build.VERSION.SDK_INT >= 18) ? new b0(paramView) : a0.c(paramView));
  }
  
  static void b(View paramView, Matrix paramMatrix) {
    a.b(paramView, paramMatrix);
  }
  
  static float c(View paramView) {
    return a.b(paramView);
  }
  
  static l0 d(View paramView) {
    return (l0)((Build.VERSION.SDK_INT >= 18) ? new k0(paramView) : new j0(paramView.getWindowToken()));
  }
  
  static void e(View paramView) {
    a.c(paramView);
  }
  
  static {
    int i = Build.VERSION.SDK_INT;
    if (i >= 22) {
      a = new g0();
    } else if (i >= 21) {
      a = new f0();
    } else if (i >= 19) {
      a = new e0();
    } else {
      a = new h0();
    } 
  }
  
  static final class a extends Property<View, Float> {
    a(Class param1Class, String param1String) {
      super(param1Class, param1String);
    }
    
    public Float a(View param1View) {
      return Float.valueOf(d0.c(param1View));
    }
    
    public void a(View param1View, Float param1Float) {
      d0.a(param1View, param1Float.floatValue());
    }
  }
  
  static final class b extends Property<View, Rect> {
    b(Class param1Class, String param1String) {
      super(param1Class, param1String);
    }
    
    public Rect a(View param1View) {
      return u.e(param1View);
    }
    
    public void a(View param1View, Rect param1Rect) {
      u.a(param1View, param1Rect);
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */