package a.b.f;

import android.graphics.Matrix;
import android.util.Log;
import android.view.View;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

class f0 extends e0 {
  private static Method e;
  
  private static boolean f;
  
  private static Method g;
  
  private static boolean h;
  
  private void a() {
    if (!f) {
      try {
        e = View.class.getDeclaredMethod("transformMatrixToGlobal", new Class[] { Matrix.class });
        e.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ViewUtilsApi21", "Failed to retrieve transformMatrixToGlobal method", noSuchMethodException);
      } 
      f = true;
    } 
  }
  
  private void b() {
    if (!h) {
      try {
        g = View.class.getDeclaredMethod("transformMatrixToLocal", new Class[] { Matrix.class });
        g.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ViewUtilsApi21", "Failed to retrieve transformMatrixToLocal method", noSuchMethodException);
      } 
      h = true;
    } 
  }
  
  public void a(View paramView, Matrix paramMatrix) {
    a();
    Method method = e;
    if (method != null)
      try {
        method.invoke(paramView, new Object[] { paramMatrix });
      } catch (IllegalAccessException illegalAccessException) {
      
      } catch (InvocationTargetException invocationTargetException) {
        throw new RuntimeException(invocationTargetException.getCause());
      }  
  }
  
  public void b(View paramView, Matrix paramMatrix) {
    b();
    Method method = g;
    if (method != null)
      try {
        method.invoke(paramView, new Object[] { paramMatrix });
      } catch (IllegalAccessException illegalAccessException) {
      
      } catch (InvocationTargetException invocationTargetException) {
        throw new RuntimeException(invocationTargetException.getCause());
      }  
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */