package a.b.f;

import android.graphics.drawable.Drawable;

interface c0 {
  void a(Drawable paramDrawable);
  
  void b(Drawable paramDrawable);
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */