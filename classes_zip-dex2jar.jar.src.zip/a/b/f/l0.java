package a.b.f;

interface l0 {}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\l0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */