package a.b.f;

import android.util.Log;
import android.view.View;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

class e0 extends h0 {
  private static Method a;
  
  private static boolean b;
  
  private static Method c;
  
  private static boolean d;
  
  private void a() {
    if (!d) {
      try {
        c = View.class.getDeclaredMethod("getTransitionAlpha", new Class[0]);
        c.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ViewUtilsApi19", "Failed to retrieve getTransitionAlpha method", noSuchMethodException);
      } 
      d = true;
    } 
  }
  
  private void b() {
    if (!b) {
      try {
        a = View.class.getDeclaredMethod("setTransitionAlpha", new Class[] { float.class });
        a.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ViewUtilsApi19", "Failed to retrieve setTransitionAlpha method", noSuchMethodException);
      } 
      b = true;
    } 
  }
  
  public void a(View paramView) {}
  
  public void a(View paramView, float paramFloat) {
    b();
    Method method = a;
    if (method != null) {
      try {
        method.invoke(paramView, new Object[] { Float.valueOf(paramFloat) });
      } catch (IllegalAccessException illegalAccessException) {
      
      } catch (InvocationTargetException invocationTargetException) {
        throw new RuntimeException(invocationTargetException.getCause());
      } 
    } else {
      invocationTargetException.setAlpha(paramFloat);
    } 
  }
  
  public float b(View paramView) {
    a();
    Method method = c;
    if (method != null)
      try {
        return ((Float)method.invoke(paramView, new Object[0])).floatValue();
      } catch (IllegalAccessException illegalAccessException) {
      
      } catch (InvocationTargetException invocationTargetException) {
        throw new RuntimeException(invocationTargetException.getCause());
      }  
    return super.b((View)invocationTargetException);
  }
  
  public void c(View paramView) {}
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */