package a.b.f;

import android.support.v4.view.u;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;

public class o {
  private static m a = new b();
  
  private static ThreadLocal<WeakReference<a.b.g.g.a<ViewGroup, ArrayList<m>>>> b = new ThreadLocal<WeakReference<a.b.g.g.a<ViewGroup, ArrayList<m>>>>();
  
  static ArrayList<ViewGroup> c = new ArrayList<ViewGroup>();
  
  static a.b.g.g.a<ViewGroup, ArrayList<m>> a() {
    WeakReference<a.b.g.g.a> weakReference1 = (WeakReference)b.get();
    if (weakReference1 != null) {
      a.b.g.g.a<ViewGroup, ArrayList<m>> a1 = weakReference1.get();
      if (a1 != null)
        return a1; 
    } 
    a.b.g.g.a<ViewGroup, ArrayList<m>> a = new a.b.g.g.a();
    WeakReference<a.b.g.g.a> weakReference2 = new WeakReference<a.b.g.g.a>(a);
    b.set(weakReference2);
    return a;
  }
  
  public static void a(ViewGroup paramViewGroup, m paramm) {
    if (!c.contains(paramViewGroup) && u.y((View)paramViewGroup)) {
      c.add(paramViewGroup);
      m m1 = paramm;
      if (paramm == null)
        m1 = a; 
      paramm = m1.clone();
      c(paramViewGroup, paramm);
      l.a((View)paramViewGroup, null);
      b(paramViewGroup, paramm);
    } 
  }
  
  private static void b(ViewGroup paramViewGroup, m paramm) {
    if (paramm != null && paramViewGroup != null) {
      a a = new a(paramm, paramViewGroup);
      paramViewGroup.addOnAttachStateChangeListener(a);
      paramViewGroup.getViewTreeObserver().addOnPreDrawListener(a);
    } 
  }
  
  private static void c(ViewGroup paramViewGroup, m paramm) {
    ArrayList arrayList = (ArrayList)a().get(paramViewGroup);
    if (arrayList != null && arrayList.size() > 0) {
      Iterator<m> iterator = arrayList.iterator();
      while (iterator.hasNext())
        ((m)iterator.next()).c((View)paramViewGroup); 
    } 
    if (paramm != null)
      paramm.a(paramViewGroup, true); 
    l l = l.a((View)paramViewGroup);
    if (l != null)
      l.a(); 
  }
  
  private static class a implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {
    m c;
    
    ViewGroup d;
    
    a(m param1m, ViewGroup param1ViewGroup) {
      this.c = param1m;
      this.d = param1ViewGroup;
    }
    
    private void a() {
      this.d.getViewTreeObserver().removeOnPreDrawListener(this);
      this.d.removeOnAttachStateChangeListener(this);
    }
    
    public boolean onPreDraw() {
      ArrayList<?> arrayList1;
      a();
      if (!o.c.remove(this.d))
        return true; 
      a.b.g.g.a<ViewGroup, ArrayList<m>> a1 = o.a();
      ArrayList<?> arrayList2 = (ArrayList)a1.get(this.d);
      ArrayList arrayList = null;
      if (arrayList2 == null) {
        arrayList1 = new ArrayList();
        a1.put(this.d, arrayList1);
      } else {
        arrayList1 = arrayList2;
        if (arrayList2.size() > 0) {
          arrayList = new ArrayList(arrayList2);
          arrayList1 = arrayList2;
        } 
      } 
      arrayList1.add(this.c);
      this.c.a(new a(this, a1));
      this.c.a(this.d, false);
      if (arrayList != null) {
        Iterator<m> iterator = arrayList.iterator();
        while (iterator.hasNext())
          ((m)iterator.next()).e((View)this.d); 
      } 
      this.c.a(this.d);
      return true;
    }
    
    public void onViewAttachedToWindow(View param1View) {}
    
    public void onViewDetachedFromWindow(View param1View) {
      a();
      o.c.remove(this.d);
      ArrayList arrayList = (ArrayList)o.a().get(this.d);
      if (arrayList != null && arrayList.size() > 0) {
        Iterator<m> iterator = arrayList.iterator();
        while (iterator.hasNext())
          ((m)iterator.next()).e((View)this.d); 
      } 
      this.c.a(true);
    }
    
    class a extends n {
      final a.b.g.g.a a;
      
      final o.a b;
      
      a(o.a this$0, a.b.g.g.a param2a) {}
      
      public void b(m param2m) {
        ((ArrayList)this.a.get(this.b.d)).remove(param2m);
      }
    }
  }
  
  class a extends n {
    final a.b.g.g.a a;
    
    final o.a b;
    
    a(o this$0, a.b.g.g.a param1a) {}
    
    public void b(m param1m) {
      ((ArrayList)this.a.get(this.b.d)).remove(param1m);
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */