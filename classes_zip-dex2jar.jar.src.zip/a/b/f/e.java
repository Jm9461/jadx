package a.b.f;

import android.graphics.Rect;
import android.support.v4.app.t;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;

public class e extends t {
  private static boolean a(m paramm) {
    return (!t.a(paramm.i()) || !t.a(paramm.j()) || !t.a(paramm.k()));
  }
  
  public Object a(Object paramObject1, Object paramObject2, Object paramObject3) {
    q q = null;
    paramObject1 = paramObject1;
    paramObject2 = paramObject2;
    paramObject3 = paramObject3;
    if (paramObject1 != null && paramObject2 != null) {
      q = new q();
      q.a((m)paramObject1);
      q.a((m)paramObject2);
      paramObject1 = q.b(1);
    } else if (paramObject1 == null) {
      paramObject1 = q;
      if (paramObject2 != null)
        paramObject1 = paramObject2; 
    } 
    if (paramObject3 != null) {
      paramObject2 = new q();
      if (paramObject1 != null)
        paramObject2.a((m)paramObject1); 
      paramObject2.a((m)paramObject3);
      return paramObject2;
    } 
    return paramObject1;
  }
  
  public void a(ViewGroup paramViewGroup, Object paramObject) {
    o.a(paramViewGroup, (m)paramObject);
  }
  
  public void a(Object paramObject, Rect paramRect) {
    if (paramObject != null)
      ((m)paramObject).a(new d(this, paramRect)); 
  }
  
  public void a(Object paramObject, View paramView) {
    if (paramObject != null)
      ((m)paramObject).a(paramView); 
  }
  
  public void a(Object paramObject, View paramView, ArrayList<View> paramArrayList) {
    ((m)paramObject).a(new b(this, paramView, paramArrayList));
  }
  
  public void a(Object paramObject1, Object paramObject2, ArrayList<View> paramArrayList1, Object paramObject3, ArrayList<View> paramArrayList2, Object paramObject4, ArrayList<View> paramArrayList3) {
    ((m)paramObject1).a(new c(this, paramObject2, paramArrayList1, paramObject3, paramArrayList2, paramObject4, paramArrayList3));
  }
  
  public void a(Object paramObject, ArrayList<View> paramArrayList) {
    paramObject = paramObject;
    if (paramObject == null)
      return; 
    if (paramObject instanceof q) {
      paramObject = paramObject;
      int i = paramObject.q();
      for (byte b = 0; b < i; b++)
        a(paramObject.a(b), paramArrayList); 
    } else if (!a((m)paramObject) && t.a(paramObject.m())) {
      int i = paramArrayList.size();
      for (byte b = 0; b < i; b++)
        paramObject.a(paramArrayList.get(b)); 
    } 
  }
  
  public void a(Object paramObject, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2) {
    paramObject = paramObject;
    if (paramObject instanceof q) {
      paramObject = paramObject;
      int i = paramObject.q();
      for (byte b = 0; b < i; b++)
        a(paramObject.a(b), paramArrayList1, paramArrayList2); 
    } else if (!a((m)paramObject)) {
      List<View> list = paramObject.m();
      if (list.size() == paramArrayList1.size() && list.containsAll(paramArrayList1)) {
        if (paramArrayList2 == null) {
          i = 0;
        } else {
          i = paramArrayList2.size();
        } 
        for (byte b = 0; b < i; b++)
          paramObject.a(paramArrayList2.get(b)); 
        for (int i = paramArrayList1.size() - 1; i >= 0; i--)
          paramObject.d(paramArrayList1.get(i)); 
      } 
    } 
  }
  
  public boolean a(Object paramObject) {
    return paramObject instanceof m;
  }
  
  public Object b(Object paramObject) {
    m m = null;
    if (paramObject != null)
      m = ((m)paramObject).clone(); 
    return m;
  }
  
  public Object b(Object paramObject1, Object paramObject2, Object paramObject3) {
    q q = new q();
    if (paramObject1 != null)
      q.a((m)paramObject1); 
    if (paramObject2 != null)
      q.a((m)paramObject2); 
    if (paramObject3 != null)
      q.a((m)paramObject3); 
    return q;
  }
  
  public void b(Object paramObject, View paramView) {
    if (paramObject != null)
      ((m)paramObject).d(paramView); 
  }
  
  public void b(Object paramObject, View paramView, ArrayList<View> paramArrayList) {
    paramObject = paramObject;
    List<View> list = paramObject.m();
    list.clear();
    int i = paramArrayList.size();
    for (byte b = 0; b < i; b++)
      t.a(list, paramArrayList.get(b)); 
    list.add(paramView);
    paramArrayList.add(paramView);
    a(paramObject, paramArrayList);
  }
  
  public void b(Object paramObject, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2) {
    paramObject = paramObject;
    if (paramObject != null) {
      paramObject.m().clear();
      paramObject.m().addAll(paramArrayList2);
      a(paramObject, paramArrayList1, paramArrayList2);
    } 
  }
  
  public Object c(Object paramObject) {
    if (paramObject == null)
      return null; 
    q q = new q();
    q.a((m)paramObject);
    return q;
  }
  
  public void c(Object paramObject, View paramView) {
    if (paramView != null) {
      paramObject = paramObject;
      Rect rect = new Rect();
      a(paramView, rect);
      paramObject.a(new a(this, rect));
    } 
  }
  
  class a extends m.e {
    a(e this$0, Rect param1Rect) {}
  }
  
  class b implements m.f {
    final View a;
    
    final ArrayList b;
    
    b(e this$0, View param1View, ArrayList param1ArrayList) {}
    
    public void a(m param1m) {}
    
    public void b(m param1m) {
      param1m.b(this);
      this.a.setVisibility(8);
      int i = this.b.size();
      for (byte b1 = 0; b1 < i; b1++)
        ((View)this.b.get(b1)).setVisibility(0); 
    }
    
    public void c(m param1m) {}
    
    public void d(m param1m) {}
  }
  
  class c implements m.f {
    final Object a;
    
    final ArrayList b;
    
    final Object c;
    
    final ArrayList d;
    
    final Object e;
    
    final ArrayList f;
    
    final e g;
    
    c(e this$0, Object param1Object1, ArrayList param1ArrayList1, Object param1Object2, ArrayList param1ArrayList2, Object param1Object3, ArrayList param1ArrayList3) {}
    
    public void a(m param1m) {}
    
    public void b(m param1m) {}
    
    public void c(m param1m) {
      Object object = this.a;
      if (object != null)
        this.g.a(object, this.b, (ArrayList<View>)null); 
      object = this.c;
      if (object != null)
        this.g.a(object, this.d, (ArrayList<View>)null); 
      object = this.e;
      if (object != null)
        this.g.a(object, this.f, (ArrayList<View>)null); 
    }
    
    public void d(m param1m) {}
  }
  
  class d extends m.e {
    d(e this$0, Rect param1Rect) {}
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\f\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */