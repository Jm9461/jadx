package a.b.b;

public final class a {
  public static final int alpha = 2130968616;
  
  public static final int coordinatorLayoutStyle = 2130968777;
  
  public static final int font = 2130968985;
  
  public static final int fontProviderAuthority = 2130968988;
  
  public static final int fontProviderCerts = 2130968989;
  
  public static final int fontProviderFetchStrategy = 2130968990;
  
  public static final int fontProviderFetchTimeout = 2130968991;
  
  public static final int fontProviderPackage = 2130968992;
  
  public static final int fontProviderQuery = 2130968993;
  
  public static final int fontStyle = 2130968994;
  
  public static final int fontVariationSettings = 2130968995;
  
  public static final int fontWeight = 2130968996;
  
  public static final int keylines = 2130969043;
  
  public static final int layout_anchor = 2130969048;
  
  public static final int layout_anchorGravity = 2130969049;
  
  public static final int layout_behavior = 2130969050;
  
  public static final int layout_dodgeInsetEdges = 2130969094;
  
  public static final int layout_insetEdge = 2130969103;
  
  public static final int layout_keyline = 2130969104;
  
  public static final int statusBarBackground = 2130969474;
  
  public static final int ttcIndex = 2130969613;
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\b\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */