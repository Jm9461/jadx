package a.b.b;

public final class c {
  public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 2130968616 };
  
  public static final int ColorStateListItem_alpha = 2;
  
  public static final int ColorStateListItem_android_alpha = 1;
  
  public static final int ColorStateListItem_android_color = 0;
  
  public static final int[] CoordinatorLayout = new int[] { 2130969043, 2130969474 };
  
  public static final int[] CoordinatorLayout_Layout = new int[] { 16842931, 2130969048, 2130969049, 2130969050, 2130969094, 2130969103, 2130969104 };
  
  public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
  
  public static final int CoordinatorLayout_Layout_layout_anchor = 1;
  
  public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
  
  public static final int CoordinatorLayout_Layout_layout_behavior = 3;
  
  public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
  
  public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
  
  public static final int CoordinatorLayout_Layout_layout_keyline = 6;
  
  public static final int CoordinatorLayout_keylines = 0;
  
  public static final int CoordinatorLayout_statusBarBackground = 1;
  
  public static final int[] FontFamily = new int[] { 2130968988, 2130968989, 2130968990, 2130968991, 2130968992, 2130968993 };
  
  public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130968985, 2130968994, 2130968995, 2130968996, 2130969613 };
  
  public static final int FontFamilyFont_android_font = 0;
  
  public static final int FontFamilyFont_android_fontStyle = 2;
  
  public static final int FontFamilyFont_android_fontVariationSettings = 4;
  
  public static final int FontFamilyFont_android_fontWeight = 1;
  
  public static final int FontFamilyFont_android_ttcIndex = 3;
  
  public static final int FontFamilyFont_font = 5;
  
  public static final int FontFamilyFont_fontStyle = 6;
  
  public static final int FontFamilyFont_fontVariationSettings = 7;
  
  public static final int FontFamilyFont_fontWeight = 8;
  
  public static final int FontFamilyFont_ttcIndex = 9;
  
  public static final int FontFamily_fontProviderAuthority = 0;
  
  public static final int FontFamily_fontProviderCerts = 1;
  
  public static final int FontFamily_fontProviderFetchStrategy = 2;
  
  public static final int FontFamily_fontProviderFetchTimeout = 3;
  
  public static final int FontFamily_fontProviderPackage = 4;
  
  public static final int FontFamily_fontProviderQuery = 5;
  
  public static final int[] GradientColor = new int[] { 
      16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
      16844050, 16844051 };
  
  public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
  
  public static final int GradientColorItem_android_color = 0;
  
  public static final int GradientColorItem_android_offset = 1;
  
  public static final int GradientColor_android_centerColor = 7;
  
  public static final int GradientColor_android_centerX = 3;
  
  public static final int GradientColor_android_centerY = 4;
  
  public static final int GradientColor_android_endColor = 1;
  
  public static final int GradientColor_android_endX = 10;
  
  public static final int GradientColor_android_endY = 11;
  
  public static final int GradientColor_android_gradientRadius = 5;
  
  public static final int GradientColor_android_startColor = 0;
  
  public static final int GradientColor_android_startX = 8;
  
  public static final int GradientColor_android_startY = 9;
  
  public static final int GradientColor_android_tileMode = 6;
  
  public static final int GradientColor_android_type = 2;
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\b\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */