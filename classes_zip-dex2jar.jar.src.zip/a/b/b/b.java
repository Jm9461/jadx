package a.b.b;

public final class b {
  public static final int TextAppearance_Compat_Notification = 2131820917;
  
  public static final int TextAppearance_Compat_Notification_Info = 2131820918;
  
  public static final int TextAppearance_Compat_Notification_Line2 = 2131820919;
  
  public static final int TextAppearance_Compat_Notification_Time = 2131820920;
  
  public static final int TextAppearance_Compat_Notification_Title = 2131820921;
  
  public static final int Widget_Compat_NotificationActionContainer = 2131821088;
  
  public static final int Widget_Compat_NotificationActionText = 2131821089;
  
  public static final int Widget_Support_CoordinatorLayout = 2131821144;
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\b\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */