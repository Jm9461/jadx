package a.b.g.f;

public interface c {
  boolean a(CharSequence paramCharSequence, int paramInt1, int paramInt2);
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\f\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */