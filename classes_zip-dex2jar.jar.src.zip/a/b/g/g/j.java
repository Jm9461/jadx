package a.b.g.g;

public interface j<T> {
  T a();
  
  boolean a(T paramT);
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\g\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */