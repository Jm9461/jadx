package a.b.g.g;

public class l<T> extends k<T> {
  private final Object c = new Object();
  
  public l(int paramInt) {
    super(paramInt);
  }
  
  public T a() {
    synchronized (this.c) {
      return super.a();
    } 
  }
  
  public boolean a(T paramT) {
    synchronized (this.c) {
      return super.a(paramT);
    } 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\g\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */