package a.b.g.g;

import java.util.ConcurrentModificationException;
import java.util.Map;

public class n<K, V> {
  static Object[] f;
  
  static int g;
  
  static Object[] h;
  
  static int i;
  
  int[] c;
  
  Object[] d;
  
  int e;
  
  public n() {
    this.c = c.a;
    this.d = c.c;
    this.e = 0;
  }
  
  public n(int paramInt) {
    if (paramInt == 0) {
      this.c = c.a;
      this.d = c.c;
    } else {
      e(paramInt);
    } 
    this.e = 0;
  }
  
  public n(n<K, V> paramn) {
    this();
    if (paramn != null)
      a(paramn); 
  }
  
  private static int a(int[] paramArrayOfint, int paramInt1, int paramInt2) {
    try {
      return c.a(paramArrayOfint, paramInt1, paramInt2);
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      throw new ConcurrentModificationException();
    } 
  }
  
  private static void a(int[] paramArrayOfint, Object[] paramArrayOfObject, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: arraylength
    //   2: bipush #8
    //   4: if_icmpne -> 73
    //   7: ldc a/b/g/g/a
    //   9: monitorenter
    //   10: getstatic a/b/g/g/n.i : I
    //   13: bipush #10
    //   15: if_icmpge -> 61
    //   18: aload_1
    //   19: iconst_0
    //   20: getstatic a/b/g/g/n.h : [Ljava/lang/Object;
    //   23: aastore
    //   24: aload_1
    //   25: iconst_1
    //   26: aload_0
    //   27: aastore
    //   28: iload_2
    //   29: iconst_1
    //   30: ishl
    //   31: iconst_1
    //   32: isub
    //   33: istore_2
    //   34: iload_2
    //   35: iconst_2
    //   36: if_icmplt -> 49
    //   39: aload_1
    //   40: iload_2
    //   41: aconst_null
    //   42: aastore
    //   43: iinc #2, -1
    //   46: goto -> 34
    //   49: aload_1
    //   50: putstatic a/b/g/g/n.h : [Ljava/lang/Object;
    //   53: getstatic a/b/g/g/n.i : I
    //   56: iconst_1
    //   57: iadd
    //   58: putstatic a/b/g/g/n.i : I
    //   61: ldc a/b/g/g/a
    //   63: monitorexit
    //   64: goto -> 145
    //   67: astore_0
    //   68: ldc a/b/g/g/a
    //   70: monitorexit
    //   71: aload_0
    //   72: athrow
    //   73: aload_0
    //   74: arraylength
    //   75: iconst_4
    //   76: if_icmpne -> 145
    //   79: ldc a/b/g/g/a
    //   81: monitorenter
    //   82: getstatic a/b/g/g/n.g : I
    //   85: bipush #10
    //   87: if_icmpge -> 133
    //   90: aload_1
    //   91: iconst_0
    //   92: getstatic a/b/g/g/n.f : [Ljava/lang/Object;
    //   95: aastore
    //   96: aload_1
    //   97: iconst_1
    //   98: aload_0
    //   99: aastore
    //   100: iload_2
    //   101: iconst_1
    //   102: ishl
    //   103: iconst_1
    //   104: isub
    //   105: istore_2
    //   106: iload_2
    //   107: iconst_2
    //   108: if_icmplt -> 121
    //   111: aload_1
    //   112: iload_2
    //   113: aconst_null
    //   114: aastore
    //   115: iinc #2, -1
    //   118: goto -> 106
    //   121: aload_1
    //   122: putstatic a/b/g/g/n.f : [Ljava/lang/Object;
    //   125: getstatic a/b/g/g/n.g : I
    //   128: iconst_1
    //   129: iadd
    //   130: putstatic a/b/g/g/n.g : I
    //   133: ldc a/b/g/g/a
    //   135: monitorexit
    //   136: goto -> 145
    //   139: astore_0
    //   140: ldc a/b/g/g/a
    //   142: monitorexit
    //   143: aload_0
    //   144: athrow
    //   145: return
    // Exception table:
    //   from	to	target	type
    //   10	24	67	finally
    //   49	61	67	finally
    //   61	64	67	finally
    //   68	71	67	finally
    //   82	96	139	finally
    //   121	133	139	finally
    //   133	136	139	finally
    //   140	143	139	finally
  }
  
  private void e(int paramInt) {
    // Byte code:
    //   0: iload_1
    //   1: bipush #8
    //   3: if_icmpne -> 75
    //   6: ldc a/b/g/g/a
    //   8: monitorenter
    //   9: getstatic a/b/g/g/n.h : [Ljava/lang/Object;
    //   12: ifnull -> 63
    //   15: getstatic a/b/g/g/n.h : [Ljava/lang/Object;
    //   18: astore_2
    //   19: aload_0
    //   20: aload_2
    //   21: putfield d : [Ljava/lang/Object;
    //   24: aload_2
    //   25: iconst_0
    //   26: aaload
    //   27: checkcast [Ljava/lang/Object;
    //   30: putstatic a/b/g/g/n.h : [Ljava/lang/Object;
    //   33: aload_0
    //   34: aload_2
    //   35: iconst_1
    //   36: aaload
    //   37: checkcast [I
    //   40: putfield c : [I
    //   43: aload_2
    //   44: iconst_1
    //   45: aconst_null
    //   46: aastore
    //   47: aload_2
    //   48: iconst_0
    //   49: aconst_null
    //   50: aastore
    //   51: getstatic a/b/g/g/n.i : I
    //   54: iconst_1
    //   55: isub
    //   56: putstatic a/b/g/g/n.i : I
    //   59: ldc a/b/g/g/a
    //   61: monitorexit
    //   62: return
    //   63: ldc a/b/g/g/a
    //   65: monitorexit
    //   66: goto -> 149
    //   69: astore_2
    //   70: ldc a/b/g/g/a
    //   72: monitorexit
    //   73: aload_2
    //   74: athrow
    //   75: iload_1
    //   76: iconst_4
    //   77: if_icmpne -> 149
    //   80: ldc a/b/g/g/a
    //   82: monitorenter
    //   83: getstatic a/b/g/g/n.f : [Ljava/lang/Object;
    //   86: ifnull -> 137
    //   89: getstatic a/b/g/g/n.f : [Ljava/lang/Object;
    //   92: astore_2
    //   93: aload_0
    //   94: aload_2
    //   95: putfield d : [Ljava/lang/Object;
    //   98: aload_2
    //   99: iconst_0
    //   100: aaload
    //   101: checkcast [Ljava/lang/Object;
    //   104: putstatic a/b/g/g/n.f : [Ljava/lang/Object;
    //   107: aload_0
    //   108: aload_2
    //   109: iconst_1
    //   110: aaload
    //   111: checkcast [I
    //   114: putfield c : [I
    //   117: aload_2
    //   118: iconst_1
    //   119: aconst_null
    //   120: aastore
    //   121: aload_2
    //   122: iconst_0
    //   123: aconst_null
    //   124: aastore
    //   125: getstatic a/b/g/g/n.g : I
    //   128: iconst_1
    //   129: isub
    //   130: putstatic a/b/g/g/n.g : I
    //   133: ldc a/b/g/g/a
    //   135: monitorexit
    //   136: return
    //   137: ldc a/b/g/g/a
    //   139: monitorexit
    //   140: goto -> 149
    //   143: astore_2
    //   144: ldc a/b/g/g/a
    //   146: monitorexit
    //   147: aload_2
    //   148: athrow
    //   149: aload_0
    //   150: iload_1
    //   151: newarray int
    //   153: putfield c : [I
    //   156: aload_0
    //   157: iload_1
    //   158: iconst_1
    //   159: ishl
    //   160: anewarray java/lang/Object
    //   163: putfield d : [Ljava/lang/Object;
    //   166: return
    // Exception table:
    //   from	to	target	type
    //   9	43	69	finally
    //   51	62	69	finally
    //   63	66	69	finally
    //   70	73	69	finally
    //   83	117	143	finally
    //   125	136	143	finally
    //   137	140	143	finally
    //   144	147	143	finally
  }
  
  int a() {
    int k = this.e;
    if (k == 0)
      return -1; 
    int j = a(this.c, k, 0);
    if (j < 0)
      return j; 
    if (this.d[j << 1] == null)
      return j; 
    int i;
    for (i = j + 1; i < k && this.c[i] == 0; i++) {
      if (this.d[i << 1] == null)
        return i; 
    } 
    while (--j >= 0 && this.c[j] == 0) {
      if (this.d[j << 1] == null)
        return j; 
      j--;
    } 
    return i ^ 0xFFFFFFFF;
  }
  
  public int a(Object paramObject) {
    int i;
    if (paramObject == null) {
      i = a();
    } else {
      i = a(paramObject, paramObject.hashCode());
    } 
    return i;
  }
  
  int a(Object paramObject, int paramInt) {
    int k = this.e;
    if (k == 0)
      return -1; 
    int j = a(this.c, k, paramInt);
    if (j < 0)
      return j; 
    if (paramObject.equals(this.d[j << 1]))
      return j; 
    int i;
    for (i = j + 1; i < k && this.c[i] == paramInt; i++) {
      if (paramObject.equals(this.d[i << 1]))
        return i; 
    } 
    while (--j >= 0 && this.c[j] == paramInt) {
      if (paramObject.equals(this.d[j << 1]))
        return j; 
      j--;
    } 
    return i ^ 0xFFFFFFFF;
  }
  
  public V a(int paramInt, V paramV) {
    paramInt = (paramInt << 1) + 1;
    Object[] arrayOfObject = this.d;
    Object object = arrayOfObject[paramInt];
    arrayOfObject[paramInt] = paramV;
    return (V)object;
  }
  
  public void a(int paramInt) {
    int i = this.e;
    if (this.c.length < paramInt) {
      int[] arrayOfInt = this.c;
      Object[] arrayOfObject = this.d;
      e(paramInt);
      if (this.e > 0) {
        System.arraycopy(arrayOfInt, 0, this.c, 0, i);
        System.arraycopy(arrayOfObject, 0, this.d, 0, i << 1);
      } 
      a(arrayOfInt, arrayOfObject, i);
    } 
    if (this.e == i)
      return; 
    throw new ConcurrentModificationException();
  }
  
  public void a(n<? extends K, ? extends V> paramn) {
    int i = paramn.e;
    a(this.e + i);
    if (this.e == 0) {
      if (i > 0) {
        System.arraycopy(paramn.c, 0, this.c, 0, i);
        System.arraycopy(paramn.d, 0, this.d, 0, i << 1);
        this.e = i;
      } 
    } else {
      for (byte b = 0; b < i; b++)
        put(paramn.b(b), paramn.d(b)); 
    } 
  }
  
  int b(Object paramObject) {
    int i = this.e * 2;
    Object[] arrayOfObject = this.d;
    if (paramObject == null) {
      for (byte b = 1; b < i; b += 2) {
        if (arrayOfObject[b] == null)
          return b >> 1; 
      } 
    } else {
      for (byte b = 1; b < i; b += 2) {
        if (paramObject.equals(arrayOfObject[b]))
          return b >> 1; 
      } 
    } 
    return -1;
  }
  
  public K b(int paramInt) {
    return (K)this.d[paramInt << 1];
  }
  
  public V c(int paramInt) {
    Object[] arrayOfObject = this.d;
    Object object = arrayOfObject[(paramInt << 1) + 1];
    int i = this.e;
    if (i <= 1) {
      a(this.c, arrayOfObject, i);
      this.c = c.a;
      this.d = c.c;
      paramInt = 0;
    } else {
      int k = i - 1;
      int[] arrayOfInt = this.c;
      int m = arrayOfInt.length;
      int j = 8;
      if (m > 8 && this.e < arrayOfInt.length / 3) {
        if (i > 8)
          j = i + (i >> 1); 
        int[] arrayOfInt1 = this.c;
        Object[] arrayOfObject1 = this.d;
        e(j);
        if (i == this.e) {
          if (paramInt > 0) {
            System.arraycopy(arrayOfInt1, 0, this.c, 0, paramInt);
            System.arraycopy(arrayOfObject1, 0, this.d, 0, paramInt << 1);
          } 
          if (paramInt < k) {
            System.arraycopy(arrayOfInt1, paramInt + 1, this.c, paramInt, k - paramInt);
            System.arraycopy(arrayOfObject1, paramInt + 1 << 1, this.d, paramInt << 1, k - paramInt << 1);
          } 
          paramInt = k;
        } else {
          throw new ConcurrentModificationException();
        } 
      } else {
        if (paramInt < k) {
          arrayOfInt = this.c;
          System.arraycopy(arrayOfInt, paramInt + 1, arrayOfInt, paramInt, k - paramInt);
          Object[] arrayOfObject2 = this.d;
          System.arraycopy(arrayOfObject2, paramInt + 1 << 1, arrayOfObject2, paramInt << 1, k - paramInt << 1);
        } 
        Object[] arrayOfObject1 = this.d;
        arrayOfObject1[k << 1] = null;
        arrayOfObject1[(k << 1) + 1] = null;
        paramInt = k;
      } 
    } 
    if (i == this.e) {
      this.e = paramInt;
      return (V)object;
    } 
    throw new ConcurrentModificationException();
  }
  
  public void clear() {
    if (this.e > 0) {
      int[] arrayOfInt = this.c;
      Object[] arrayOfObject = this.d;
      int i = this.e;
      this.c = c.a;
      this.d = c.c;
      this.e = 0;
      a(arrayOfInt, arrayOfObject, i);
    } 
    if (this.e <= 0)
      return; 
    throw new ConcurrentModificationException();
  }
  
  public boolean containsKey(Object paramObject) {
    boolean bool;
    if (a(paramObject) >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean containsValue(Object paramObject) {
    boolean bool;
    if (b(paramObject) >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public V d(int paramInt) {
    return (V)this.d[(paramInt << 1) + 1];
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject instanceof n) {
      paramObject = paramObject;
      if (size() != paramObject.size())
        return false; 
      byte b = 0;
      try {
        while (b < this.e) {
          K k = b(b);
          V v = d(b);
          Object object = paramObject.get(k);
          if (v == null) {
            if (object != null || !paramObject.containsKey(k))
              return false; 
          } else {
            boolean bool = v.equals(object);
            if (!bool)
              return false; 
          } 
          b++;
        } 
        return true;
      } catch (NullPointerException nullPointerException) {
        return false;
      } catch (ClassCastException classCastException) {
        return false;
      } 
    } 
    if (classCastException instanceof Map) {
      Map map = (Map)classCastException;
      if (size() != map.size())
        return false; 
      byte b = 0;
      try {
        while (b < this.e) {
          K k = b(b);
          V v = d(b);
          Object object = map.get(k);
          if (v == null) {
            if (object != null || !map.containsKey(k))
              return false; 
          } else {
            boolean bool = v.equals(object);
            if (!bool)
              return false; 
          } 
          b++;
        } 
        return true;
      } catch (NullPointerException nullPointerException) {
        return false;
      } catch (ClassCastException classCastException1) {
        return false;
      } 
    } 
    return false;
  }
  
  public V get(Object paramObject) {
    int i = a(paramObject);
    if (i >= 0) {
      paramObject = this.d[(i << 1) + 1];
    } else {
      paramObject = null;
    } 
    return (V)paramObject;
  }
  
  public int hashCode() {
    int[] arrayOfInt = this.c;
    Object[] arrayOfObject = this.d;
    int i = 0;
    byte b = 0;
    boolean bool = true;
    int j = this.e;
    while (b < j) {
      int k;
      Object object = arrayOfObject[bool];
      int m = arrayOfInt[b];
      if (object == null) {
        k = 0;
      } else {
        k = object.hashCode();
      } 
      i += m ^ k;
      b++;
      bool += true;
    } 
    return i;
  }
  
  public boolean isEmpty() {
    boolean bool;
    if (this.e <= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public V put(K paramK, V paramV) {
    int j;
    int k = this.e;
    if (paramK == null) {
      j = 0;
      i = a();
    } else {
      j = paramK.hashCode();
      i = a(paramK, j);
    } 
    if (i >= 0) {
      i = (i << 1) + 1;
      Object[] arrayOfObject = this.d;
      paramK = (K)arrayOfObject[i];
      arrayOfObject[i] = paramV;
      return (V)paramK;
    } 
    int m = i ^ 0xFFFFFFFF;
    if (k >= this.c.length) {
      i = 4;
      if (k >= 8) {
        i = (k >> 1) + k;
      } else if (k >= 4) {
        i = 8;
      } 
      int[] arrayOfInt = this.c;
      Object[] arrayOfObject = this.d;
      e(i);
      if (k == this.e) {
        int[] arrayOfInt1 = this.c;
        if (arrayOfInt1.length > 0) {
          System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
          System.arraycopy(arrayOfObject, 0, this.d, 0, arrayOfObject.length);
        } 
        a(arrayOfInt, arrayOfObject, k);
      } else {
        throw new ConcurrentModificationException();
      } 
    } 
    if (m < k) {
      int[] arrayOfInt = this.c;
      System.arraycopy(arrayOfInt, m, arrayOfInt, m + 1, k - m);
      Object[] arrayOfObject = this.d;
      System.arraycopy(arrayOfObject, m << 1, arrayOfObject, m + 1 << 1, this.e - m << 1);
    } 
    int i = this.e;
    if (k == i) {
      int[] arrayOfInt = this.c;
      if (m < arrayOfInt.length) {
        arrayOfInt[m] = j;
        Object[] arrayOfObject = this.d;
        arrayOfObject[m << 1] = paramK;
        arrayOfObject[(m << 1) + 1] = paramV;
        this.e = i + 1;
        return null;
      } 
    } 
    throw new ConcurrentModificationException();
  }
  
  public V remove(Object paramObject) {
    int i = a(paramObject);
    return (i >= 0) ? c(i) : null;
  }
  
  public int size() {
    return this.e;
  }
  
  public String toString() {
    if (isEmpty())
      return "{}"; 
    StringBuilder stringBuilder = new StringBuilder(this.e * 28);
    stringBuilder.append('{');
    for (byte b = 0; b < this.e; b++) {
      if (b > 0)
        stringBuilder.append(", "); 
      V v = (V)b(b);
      if (v != this) {
        stringBuilder.append(v);
      } else {
        stringBuilder.append("(this Map)");
      } 
      stringBuilder.append('=');
      v = d(b);
      if (v != this) {
        stringBuilder.append(v);
      } else {
        stringBuilder.append("(this Map)");
      } 
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\g\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */