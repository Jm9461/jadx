package a.b.g.g;

public class o<E> implements Cloneable {
  private static final Object g = new Object();
  
  private boolean c = false;
  
  private int[] d;
  
  private Object[] e;
  
  private int f;
  
  public o() {
    this(10);
  }
  
  public o(int paramInt) {
    if (paramInt == 0) {
      this.d = c.a;
      this.e = c.c;
    } else {
      paramInt = c.b(paramInt);
      this.d = new int[paramInt];
      this.e = new Object[paramInt];
    } 
    this.f = 0;
  }
  
  private void c() {
    int k = this.f;
    int j = 0;
    int[] arrayOfInt = this.d;
    Object[] arrayOfObject = this.e;
    int i = 0;
    while (i < k) {
      Object object = arrayOfObject[i];
      int m = j;
      if (object != g) {
        if (i != j) {
          arrayOfInt[j] = arrayOfInt[i];
          arrayOfObject[j] = object;
          arrayOfObject[i] = null;
        } 
        m = j + 1;
      } 
      i++;
      j = m;
    } 
    this.c = false;
    this.f = j;
  }
  
  public void a() {
    int i = this.f;
    Object[] arrayOfObject = this.e;
    for (byte b = 0; b < i; b++)
      arrayOfObject[b] = null; 
    this.f = 0;
    this.c = false;
  }
  
  public void a(int paramInt) {
    paramInt = c.a(this.d, this.f, paramInt);
    if (paramInt >= 0) {
      Object[] arrayOfObject = this.e;
      Object object1 = arrayOfObject[paramInt];
      Object object2 = g;
      if (object1 != object2) {
        arrayOfObject[paramInt] = object2;
        this.c = true;
      } 
    } 
  }
  
  public void a(int paramInt, E paramE) {
    int i = this.f;
    if (i != 0 && paramInt <= this.d[i - 1]) {
      c(paramInt, paramE);
      return;
    } 
    if (this.c && this.f >= this.d.length)
      c(); 
    i = this.f;
    if (i >= this.d.length) {
      int j = c.b(i + 1);
      int[] arrayOfInt1 = new int[j];
      Object[] arrayOfObject1 = new Object[j];
      int[] arrayOfInt2 = this.d;
      System.arraycopy(arrayOfInt2, 0, arrayOfInt1, 0, arrayOfInt2.length);
      Object[] arrayOfObject2 = this.e;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.d = arrayOfInt1;
      this.e = arrayOfObject1;
    } 
    this.d[i] = paramInt;
    this.e[i] = paramE;
    this.f = i + 1;
  }
  
  public int b() {
    if (this.c)
      c(); 
    return this.f;
  }
  
  public E b(int paramInt) {
    return b(paramInt, null);
  }
  
  public E b(int paramInt, E paramE) {
    paramInt = c.a(this.d, this.f, paramInt);
    if (paramInt >= 0) {
      Object[] arrayOfObject = this.e;
      if (arrayOfObject[paramInt] != g)
        return (E)arrayOfObject[paramInt]; 
    } 
    return paramE;
  }
  
  public int c(int paramInt) {
    if (this.c)
      c(); 
    return c.a(this.d, this.f, paramInt);
  }
  
  public void c(int paramInt, E paramE) {
    int i = c.a(this.d, this.f, paramInt);
    if (i >= 0) {
      this.e[i] = paramE;
    } else {
      int j = i ^ 0xFFFFFFFF;
      if (j < this.f) {
        Object[] arrayOfObject = this.e;
        if (arrayOfObject[j] == g) {
          this.d[j] = paramInt;
          arrayOfObject[j] = paramE;
          return;
        } 
      } 
      i = j;
      if (this.c) {
        i = j;
        if (this.f >= this.d.length) {
          c();
          i = c.a(this.d, this.f, paramInt) ^ 0xFFFFFFFF;
        } 
      } 
      j = this.f;
      if (j >= this.d.length) {
        j = c.b(j + 1);
        int[] arrayOfInt1 = new int[j];
        Object[] arrayOfObject1 = new Object[j];
        int[] arrayOfInt2 = this.d;
        System.arraycopy(arrayOfInt2, 0, arrayOfInt1, 0, arrayOfInt2.length);
        Object[] arrayOfObject2 = this.e;
        System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
        this.d = arrayOfInt1;
        this.e = arrayOfObject1;
      } 
      j = this.f;
      if (j - i != 0) {
        int[] arrayOfInt = this.d;
        System.arraycopy(arrayOfInt, i, arrayOfInt, i + 1, j - i);
        Object[] arrayOfObject = this.e;
        System.arraycopy(arrayOfObject, i, arrayOfObject, i + 1, this.f - i);
      } 
      this.d[i] = paramInt;
      this.e[i] = paramE;
      this.f++;
    } 
  }
  
  public o<E> clone() {
    try {
      o<E> o1 = (o)super.clone();
      o1.d = (int[])this.d.clone();
      o1.e = (Object[])this.e.clone();
      return o1;
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      throw new AssertionError(cloneNotSupportedException);
    } 
  }
  
  public int d(int paramInt) {
    if (this.c)
      c(); 
    return this.d[paramInt];
  }
  
  public void e(int paramInt) {
    a(paramInt);
  }
  
  public E f(int paramInt) {
    if (this.c)
      c(); 
    return (E)this.e[paramInt];
  }
  
  public String toString() {
    if (b() <= 0)
      return "{}"; 
    StringBuilder stringBuilder = new StringBuilder(this.f * 28);
    stringBuilder.append('{');
    for (byte b = 0; b < this.f; b++) {
      if (b > 0)
        stringBuilder.append(", "); 
      stringBuilder.append(d(b));
      stringBuilder.append('=');
      E e = f(b);
      if (e != this) {
        stringBuilder.append(e);
      } else {
        stringBuilder.append("(this Map)");
      } 
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\g\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */