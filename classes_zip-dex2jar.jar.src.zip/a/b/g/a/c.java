package a.b.g.a;

import a.b.g.e.b;
import a.b.g.g.g;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import android.support.v4.content.e.f;

public class c {
  private static final h a;
  
  private static final g<String, Typeface> b = new g(16);
  
  public static Typeface a(Context paramContext, Resources paramResources, int paramInt1, String paramString, int paramInt2) {
    Typeface typeface = a.a(paramContext, paramResources, paramInt1, paramString, paramInt2);
    if (typeface != null) {
      String str = a(paramResources, paramInt1, paramInt2);
      b.a(str, typeface);
    } 
    return typeface;
  }
  
  public static Typeface a(Context paramContext, CancellationSignal paramCancellationSignal, b.f[] paramArrayOff, int paramInt) {
    return a.a(paramContext, paramCancellationSignal, paramArrayOff, paramInt);
  }
  
  public static Typeface a(Context paramContext, android.support.v4.content.e.c.a parama, Resources paramResources, int paramInt1, int paramInt2, f.a parama1, Handler paramHandler, boolean paramBoolean) {
    Typeface typeface;
    android.support.v4.content.e.c.d d;
    if (parama instanceof android.support.v4.content.e.c.d) {
      byte b;
      boolean bool;
      d = (android.support.v4.content.e.c.d)parama;
      if (paramBoolean ? (d.a() == 0) : (parama1 == null)) {
        bool = true;
      } else {
        bool = false;
      } 
      if (paramBoolean) {
        b = d.c();
      } else {
        b = -1;
      } 
      typeface = b.a(paramContext, d.b(), parama1, paramHandler, bool, b, paramInt2);
    } else {
      Typeface typeface1 = a.a((Context)typeface, (android.support.v4.content.e.c.b)d, paramResources, paramInt2);
      typeface = typeface1;
      if (parama1 != null)
        if (typeface1 != null) {
          parama1.a(typeface1, paramHandler);
          typeface = typeface1;
        } else {
          parama1.a(-3, paramHandler);
          typeface = typeface1;
        }  
    } 
    if (typeface != null)
      b.a(a(paramResources, paramInt1, paramInt2), typeface); 
    return typeface;
  }
  
  private static String a(Resources paramResources, int paramInt1, int paramInt2) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramResources.getResourcePackageName(paramInt1));
    stringBuilder.append("-");
    stringBuilder.append(paramInt1);
    stringBuilder.append("-");
    stringBuilder.append(paramInt2);
    return stringBuilder.toString();
  }
  
  public static Typeface b(Resources paramResources, int paramInt1, int paramInt2) {
    return (Typeface)b.b(a(paramResources, paramInt1, paramInt2));
  }
  
  static {
    int i = Build.VERSION.SDK_INT;
    if (i >= 28) {
      a = new g();
    } else if (i >= 26) {
      a = new f();
    } else if (i >= 24 && e.a()) {
      a = new e();
    } else if (Build.VERSION.SDK_INT >= 21) {
      a = new d();
    } else {
      a = new h();
    } 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */