package a.b.g.a;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.Resources;
import android.net.Uri;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.os.Process;
import android.os.StrictMode;
import android.util.Log;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class i {
  public static File a(Context paramContext) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(".font");
    stringBuilder.append(Process.myPid());
    stringBuilder.append("-");
    stringBuilder.append(Process.myTid());
    stringBuilder.append("-");
    String str = stringBuilder.toString();
    for (byte b = 0; b < 100; b++) {
      File file = paramContext.getCacheDir();
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str);
      stringBuilder1.append(b);
      file = new File(file, stringBuilder1.toString());
      try {
        boolean bool = file.createNewFile();
        if (bool)
          return file; 
      } catch (IOException iOException) {}
    } 
    return null;
  }
  
  public static ByteBuffer a(Context paramContext, Resources paramResources, int paramInt) {
    File file = a(paramContext);
    paramContext = null;
    if (file == null)
      return null; 
    try {
      ByteBuffer byteBuffer;
      boolean bool = a(file, paramResources, paramInt);
      if (bool)
        byteBuffer = a(file); 
      return byteBuffer;
    } finally {
      file.delete();
    } 
  }
  
  public static ByteBuffer a(Context paramContext, CancellationSignal paramCancellationSignal, Uri paramUri) {
    ContentResolver contentResolver = paramContext.getContentResolver();
    try {
      ParcelFileDescriptor parcelFileDescriptor = contentResolver.openFileDescriptor(paramUri, "r", paramCancellationSignal);
      if (parcelFileDescriptor == null) {
        if (parcelFileDescriptor != null)
          parcelFileDescriptor.close(); 
        return null;
      } 
      try {
        FileInputStream fileInputStream = new FileInputStream();
        this(parcelFileDescriptor.getFileDescriptor());
      } finally {
        paramCancellationSignal = null;
      } 
    } catch (IOException iOException) {
      return null;
    } 
  }
  
  private static ByteBuffer a(File paramFile) {
    try {
      FileInputStream fileInputStream = new FileInputStream();
      this(paramFile);
      try {
        FileChannel fileChannel = fileInputStream.getChannel();
        long l = fileChannel.size();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, 0L, l);
      } finally {
        paramFile = null;
      } 
    } catch (IOException iOException) {
      return null;
    } 
  }
  
  public static void a(Closeable paramCloseable) {
    if (paramCloseable != null)
      try {
        paramCloseable.close();
      } catch (IOException iOException) {} 
  }
  
  public static boolean a(File paramFile, Resources paramResources, int paramInt) {
    InputStream inputStream = null;
    try {
      InputStream inputStream1 = paramResources.openRawResource(paramInt);
      inputStream = inputStream1;
      return a(paramFile, inputStream1);
    } finally {
      a(inputStream);
    } 
  }
  
  public static boolean a(File paramFile, InputStream paramInputStream) {
    FileOutputStream fileOutputStream3 = null;
    FileOutputStream fileOutputStream4 = null;
    StrictMode.ThreadPolicy threadPolicy = StrictMode.allowThreadDiskWrites();
    FileOutputStream fileOutputStream1 = fileOutputStream4;
    FileOutputStream fileOutputStream2 = fileOutputStream3;
    try {
      FileOutputStream fileOutputStream6 = new FileOutputStream();
      fileOutputStream1 = fileOutputStream4;
      fileOutputStream2 = fileOutputStream3;
      this(paramFile, false);
      FileOutputStream fileOutputStream5 = fileOutputStream6;
      fileOutputStream1 = fileOutputStream5;
      fileOutputStream2 = fileOutputStream5;
      byte[] arrayOfByte = new byte[1024];
      while (true) {
        fileOutputStream1 = fileOutputStream5;
        fileOutputStream2 = fileOutputStream5;
        int j = paramInputStream.read(arrayOfByte);
        if (j != -1) {
          fileOutputStream1 = fileOutputStream5;
          fileOutputStream2 = fileOutputStream5;
          fileOutputStream5.write(arrayOfByte, 0, j);
          continue;
        } 
        a(fileOutputStream5);
        StrictMode.setThreadPolicy(threadPolicy);
        return true;
      } 
    } catch (IOException iOException) {
      fileOutputStream1 = fileOutputStream2;
      StringBuilder stringBuilder = new StringBuilder();
      fileOutputStream1 = fileOutputStream2;
      this();
      fileOutputStream1 = fileOutputStream2;
      stringBuilder.append("Error copying resource contents to temp file: ");
      fileOutputStream1 = fileOutputStream2;
      stringBuilder.append(iOException.getMessage());
      fileOutputStream1 = fileOutputStream2;
      Log.e("TypefaceCompatUtil", stringBuilder.toString());
      a(fileOutputStream2);
      StrictMode.setThreadPolicy(threadPolicy);
      return false;
    } finally {}
    a(fileOutputStream1);
    StrictMode.setThreadPolicy(threadPolicy);
    throw paramFile;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\a\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */