package a.b.g.a;

import a.b.g.e.b;
import a.b.g.g.n;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.CancellationSignal;
import android.support.v4.content.e.c;
import android.util.Log;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.List;

class e extends h {
  private static final Class a;
  
  private static final Constructor b;
  
  private static final Method c;
  
  private static final Method d;
  
  static {
    try {
      Class<?> clazz = Class.forName("android.graphics.FontFamily");
      try {
        Constructor<?> constructor = clazz.getConstructor(new Class[0]);
        try {
          Method method = clazz.getMethod("addFontWeightStyle", new Class[] { ByteBuffer.class, int.class, List.class, int.class, boolean.class });
          try {
            Method method1 = Typeface.class.getMethod("createFromFamiliesWithDefault", new Class[] { Array.newInstance(clazz, 1).getClass() });
          } catch (ClassNotFoundException classNotFoundException) {
            Log.e("TypefaceCompatApi24Impl", classNotFoundException.getClass().getName(), classNotFoundException);
            clazz = null;
            classNotFoundException = null;
            method = null;
            Object object = null;
          } catch (NoSuchMethodException null) {}
        } catch (ClassNotFoundException classNotFoundException) {
        
        } catch (NoSuchMethodException null) {}
      } catch (ClassNotFoundException classNotFoundException) {
      
      } catch (NoSuchMethodException null) {}
    } catch (ClassNotFoundException classNotFoundException) {
    
    } catch (NoSuchMethodException noSuchMethodException) {}
    Log.e("TypefaceCompatApi24Impl", noSuchMethodException.getClass().getName(), noSuchMethodException);
    Object object2 = null;
    noSuchMethodException = null;
    Object object1 = null;
    Object object3 = null;
  }
  
  private static Typeface a(Object paramObject) {
    try {
      Object object = Array.newInstance(a, 1);
      Array.set(object, 0, paramObject);
      return (Typeface)d.invoke(null, new Object[] { object });
    } catch (IllegalAccessException illegalAccessException) {
    
    } catch (InvocationTargetException invocationTargetException) {}
    throw new RuntimeException(invocationTargetException);
  }
  
  public static boolean a() {
    boolean bool;
    if (c == null)
      Log.w("TypefaceCompatApi24Impl", "Unable to collect necessary private methods.Fallback to legacy implementation."); 
    if (c != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private static boolean a(Object paramObject, ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, boolean paramBoolean) {
    try {
      return ((Boolean)c.invoke(paramObject, new Object[] { paramByteBuffer, Integer.valueOf(paramInt1), null, Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) })).booleanValue();
    } catch (IllegalAccessException illegalAccessException) {
    
    } catch (InvocationTargetException invocationTargetException) {}
    throw new RuntimeException(invocationTargetException);
  }
  
  private static Object b() {
    try {
      return b.newInstance(new Object[0]);
    } catch (IllegalAccessException illegalAccessException) {
    
    } catch (InstantiationException instantiationException) {
    
    } catch (InvocationTargetException invocationTargetException) {}
    throw new RuntimeException(invocationTargetException);
  }
  
  public Typeface a(Context paramContext, CancellationSignal paramCancellationSignal, b.f[] paramArrayOff, int paramInt) {
    Object object = b();
    n n = new n();
    int i = paramArrayOff.length;
    for (byte b = 0; b < i; b++) {
      b.f f1 = paramArrayOff[b];
      Uri uri = f1.c();
      ByteBuffer byteBuffer2 = (ByteBuffer)n.get(uri);
      ByteBuffer byteBuffer1 = byteBuffer2;
      if (byteBuffer2 == null) {
        byteBuffer1 = i.a(paramContext, paramCancellationSignal, uri);
        n.put(uri, byteBuffer1);
      } 
      if (!a(object, byteBuffer1, f1.b(), f1.d(), f1.e()))
        return null; 
    } 
    return Typeface.create(a(object), paramInt);
  }
  
  public Typeface a(Context paramContext, c.b paramb, Resources paramResources, int paramInt) {
    Object object = b();
    c.c[] arrayOfC = paramb.a();
    int i = arrayOfC.length;
    for (paramInt = 0; paramInt < i; paramInt++) {
      c.c c = arrayOfC[paramInt];
      ByteBuffer byteBuffer = i.a(paramContext, paramResources, c.b());
      if (byteBuffer == null)
        return null; 
      if (!a(object, byteBuffer, c.c(), c.e(), c.f()))
        return null; 
    } 
    return a(object);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\g\a\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */