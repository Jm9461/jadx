package a.b.a;

public final class a {
  public static final int alpha = 2130968616;
  
  public static final int font = 2130968985;
  
  public static final int fontProviderAuthority = 2130968988;
  
  public static final int fontProviderCerts = 2130968989;
  
  public static final int fontProviderFetchStrategy = 2130968990;
  
  public static final int fontProviderFetchTimeout = 2130968991;
  
  public static final int fontProviderPackage = 2130968992;
  
  public static final int fontProviderQuery = 2130968993;
  
  public static final int fontStyle = 2130968994;
  
  public static final int fontVariationSettings = 2130968995;
  
  public static final int fontWeight = 2130968996;
  
  public static final int ttcIndex = 2130969613;
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */