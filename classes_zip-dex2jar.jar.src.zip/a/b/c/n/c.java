package a.b.c.n;

import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build;

public class c {
  public static final int a;
  
  static {
    int i = Build.VERSION.SDK_INT;
    if (i >= 21) {
      a = 2;
    } else if (i >= 18) {
      a = 1;
    } else {
      a = 0;
    } 
  }
  
  public void a() {
    throw null;
  }
  
  public void a(int paramInt) {
    throw null;
  }
  
  public void a(d.e parame) {
    throw null;
  }
  
  public void a(Canvas paramCanvas) {
    throw null;
  }
  
  public void a(Drawable paramDrawable) {
    throw null;
  }
  
  public void b() {
    throw null;
  }
  
  public Drawable c() {
    throw null;
  }
  
  public int d() {
    throw null;
  }
  
  public d.e e() {
    throw null;
  }
  
  public boolean f() {
    throw null;
  }
  
  static interface a {}
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\c\n\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */