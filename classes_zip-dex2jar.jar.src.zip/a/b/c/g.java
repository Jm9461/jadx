package a.b.c;

public final class g {
  public static final int abc_config_activityDefaultDur = 2131361792;
  
  public static final int abc_config_activityShortDur = 2131361793;
  
  public static final int app_bar_elevation_anim_duration = 2131361794;
  
  public static final int bottom_sheet_slide_duration = 2131361796;
  
  public static final int cancel_button_image_alpha = 2131361797;
  
  public static final int config_tooltipAnimTime = 2131361798;
  
  public static final int design_snackbar_text_max_lines = 2131361799;
  
  public static final int design_tab_indicator_anim_duration_ms = 2131361800;
  
  public static final int hide_password_duration = 2131361802;
  
  public static final int mtrl_btn_anim_delay_ms = 2131361803;
  
  public static final int mtrl_btn_anim_duration_ms = 2131361804;
  
  public static final int mtrl_chip_anim_duration = 2131361805;
  
  public static final int mtrl_tab_indicator_anim_duration_ms = 2131361806;
  
  public static final int show_password_duration = 2131361809;
  
  public static final int status_bar_notification_info_maxnum = 2131361810;
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\c\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */