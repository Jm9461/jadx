package a.b.c.l;

import a.b.c.f;
import android.util.Property;
import android.view.ViewGroup;

public class d extends Property<ViewGroup, Float> {
  public static final Property<ViewGroup, Float> a = new d("childrenAlpha");
  
  private d(String paramString) {
    super(Float.class, paramString);
  }
  
  public Float a(ViewGroup paramViewGroup) {
    Float float_ = (Float)paramViewGroup.getTag(f.mtrl_internal_children_alpha_tag);
    return (float_ != null) ? float_ : Float.valueOf(1.0F);
  }
  
  public void a(ViewGroup paramViewGroup, Float paramFloat) {
    float f = paramFloat.floatValue();
    paramViewGroup.setTag(f.mtrl_internal_children_alpha_tag, Float.valueOf(f));
    byte b = 0;
    int i = paramViewGroup.getChildCount();
    while (b < i) {
      paramViewGroup.getChildAt(b).setAlpha(f);
      b++;
    } 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\c\l\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */