package a.b.c.l;

public class j {
  public final int a;
  
  public final float b;
  
  public final float c;
  
  public j(int paramInt, float paramFloat1, float paramFloat2) {
    this.a = paramInt;
    this.b = paramFloat1;
    this.c = paramFloat2;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\c\l\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */