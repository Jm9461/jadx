package a.b.c.l;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ValueAnimator;
import java.util.List;

public class b {
  public static void a(AnimatorSet paramAnimatorSet, List<Animator> paramList) {
    long l = 0L;
    byte b1 = 0;
    int i = paramList.size();
    while (b1 < i) {
      Animator animator = paramList.get(b1);
      l = Math.max(l, animator.getStartDelay() + animator.getDuration());
      b1++;
    } 
    ValueAnimator valueAnimator = ValueAnimator.ofInt(new int[] { 0, 0 });
    valueAnimator.setDuration(l);
    paramList.add(0, valueAnimator);
    paramAnimatorSet.playTogether(paramList);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\c\l\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */