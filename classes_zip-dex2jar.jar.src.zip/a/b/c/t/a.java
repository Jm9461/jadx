package a.b.c.t;

import a.b.g.g.n;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.view.a;

public class a extends a {
  public static final Parcelable.Creator<a> CREATOR = (Parcelable.Creator<a>)new a();
  
  public final n<String, Bundle> e;
  
  private a(Parcel paramParcel, ClassLoader paramClassLoader) {
    super(paramParcel, paramClassLoader);
    int i = paramParcel.readInt();
    String[] arrayOfString = new String[i];
    paramParcel.readStringArray(arrayOfString);
    Bundle[] arrayOfBundle = new Bundle[i];
    paramParcel.readTypedArray((Object[])arrayOfBundle, Bundle.CREATOR);
    this.e = new n(i);
    for (byte b = 0; b < i; b++)
      this.e.put(arrayOfString[b], arrayOfBundle[b]); 
  }
  
  public a(Parcelable paramParcelable) {
    super(paramParcelable);
    this.e = new n();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ExtendableSavedState{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" states=");
    stringBuilder.append(this.e);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    super.writeToParcel(paramParcel, paramInt);
    int i = this.e.size();
    paramParcel.writeInt(i);
    String[] arrayOfString = new String[i];
    Bundle[] arrayOfBundle = new Bundle[i];
    for (paramInt = 0; paramInt < i; paramInt++) {
      arrayOfString[paramInt] = (String)this.e.b(paramInt);
      arrayOfBundle[paramInt] = (Bundle)this.e.d(paramInt);
    } 
    paramParcel.writeStringArray(arrayOfString);
    paramParcel.writeTypedArray((Parcelable[])arrayOfBundle, 0);
  }
  
  static final class a implements Parcelable.ClassLoaderCreator<a> {
    public a createFromParcel(Parcel param1Parcel) {
      return new a(param1Parcel, null, null);
    }
    
    public a createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new a(param1Parcel, param1ClassLoader, null);
    }
    
    public a[] newArray(int param1Int) {
      return new a[param1Int];
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\c\t\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */