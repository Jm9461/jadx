package a.b.c.o;

public interface a extends b {}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\c\o\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */