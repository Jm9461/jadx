package a.b.c.q;

import android.annotation.TargetApi;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build;
import android.util.StateSet;

public class a {
  public static final boolean a;
  
  private static final int[] b = new int[] { 16842919 };
  
  private static final int[] c = new int[] { 16843623, 16842908 };
  
  private static final int[] d = new int[] { 16842908 };
  
  private static final int[] e = new int[] { 16843623 };
  
  private static final int[] f = new int[] { 16842913, 16842919 };
  
  private static final int[] g = new int[] { 16842913, 16843623, 16842908 };
  
  private static final int[] h = new int[] { 16842913, 16842908 };
  
  private static final int[] i = new int[] { 16842913, 16843623 };
  
  private static final int[] j = new int[] { 16842913 };
  
  @TargetApi(21)
  private static int a(int paramInt) {
    return a.b.g.a.a.c(paramInt, Math.min(Color.alpha(paramInt) * 2, 255));
  }
  
  private static int a(ColorStateList paramColorStateList, int[] paramArrayOfint) {
    int i;
    if (paramColorStateList != null) {
      i = paramColorStateList.getColorForState(paramArrayOfint, paramColorStateList.getDefaultColor());
    } else {
      i = 0;
    } 
    if (a)
      i = a(i); 
    return i;
  }
  
  public static ColorStateList a(ColorStateList paramColorStateList) {
    if (a) {
      int[][] arrayOfInt4 = new int[2][];
      int[] arrayOfInt3 = new int[2];
      arrayOfInt4[0] = j;
      arrayOfInt3[0] = a(paramColorStateList, f);
      int j = 0 + 1;
      arrayOfInt4[j] = StateSet.NOTHING;
      arrayOfInt3[j] = a(paramColorStateList, b);
      return new ColorStateList(arrayOfInt4, arrayOfInt3);
    } 
    int[][] arrayOfInt = new int[10][];
    int[] arrayOfInt1 = new int[10];
    int[] arrayOfInt2 = f;
    arrayOfInt[0] = arrayOfInt2;
    arrayOfInt1[0] = a(paramColorStateList, arrayOfInt2);
    int i = 0 + 1;
    arrayOfInt2 = g;
    arrayOfInt[i] = arrayOfInt2;
    arrayOfInt1[i] = a(paramColorStateList, arrayOfInt2);
    i++;
    arrayOfInt2 = h;
    arrayOfInt[i] = arrayOfInt2;
    arrayOfInt1[i] = a(paramColorStateList, arrayOfInt2);
    i++;
    arrayOfInt2 = i;
    arrayOfInt[i] = arrayOfInt2;
    arrayOfInt1[i] = a(paramColorStateList, arrayOfInt2);
    arrayOfInt[++i] = j;
    arrayOfInt1[i] = 0;
    i++;
    arrayOfInt2 = b;
    arrayOfInt[i] = arrayOfInt2;
    arrayOfInt1[i] = a(paramColorStateList, arrayOfInt2);
    i++;
    arrayOfInt2 = c;
    arrayOfInt[i] = arrayOfInt2;
    arrayOfInt1[i] = a(paramColorStateList, arrayOfInt2);
    i++;
    arrayOfInt2 = d;
    arrayOfInt[i] = arrayOfInt2;
    arrayOfInt1[i] = a(paramColorStateList, arrayOfInt2);
    i++;
    arrayOfInt2 = e;
    arrayOfInt[i] = arrayOfInt2;
    arrayOfInt1[i] = a(paramColorStateList, arrayOfInt2);
    arrayOfInt[++i] = StateSet.NOTHING;
    arrayOfInt1[i] = 0;
    return new ColorStateList(arrayOfInt, arrayOfInt1);
  }
  
  static {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 21) {
      bool = true;
    } else {
      bool = false;
    } 
    a = bool;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\c\q\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */