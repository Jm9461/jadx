package a.b.c;

public final class a {
  public static final int design_appbar_state_list_animator = 2130837504;
  
  public static final int design_fab_hide_motion_spec = 2130837505;
  
  public static final int design_fab_show_motion_spec = 2130837506;
  
  public static final int mtrl_btn_state_list_anim = 2130837507;
  
  public static final int mtrl_btn_unelevated_state_list_anim = 2130837508;
  
  public static final int mtrl_chip_state_list_anim = 2130837509;
  
  public static final int mtrl_fab_hide_motion_spec = 2130837510;
  
  public static final int mtrl_fab_show_motion_spec = 2130837511;
  
  public static final int mtrl_fab_transformation_sheet_collapse_spec = 2130837512;
  
  public static final int mtrl_fab_transformation_sheet_expand_spec = 2130837513;
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\c\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */