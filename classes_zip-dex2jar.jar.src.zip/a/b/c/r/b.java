package a.b.c.r;

import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.support.v4.graphics.drawable.b;

public class b extends Drawable implements b {
  public ColorStateList a() {
    throw null;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\c\r\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */