package a.b.e;

import android.content.res.AssetManager;
import android.util.Log;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TimeZone;
import java.util.regex.Pattern;

public class a {
  private static final d[] A;
  
  private static final d[] B;
  
  private static final d[] C;
  
  private static final d[] D;
  
  static final d[][] E;
  
  private static final d[] F;
  
  private static final HashMap<Integer, d>[] G;
  
  private static final HashMap<String, d>[] H;
  
  private static final HashSet<String> I;
  
  private static final HashMap<Integer, Integer> J;
  
  private static final Charset K;
  
  static final byte[] L;
  
  public static final int[] l = new int[] { 8, 8, 8 };
  
  public static final int[] m = new int[] { 8 };
  
  static final byte[] n = new byte[] { -1, -40, -1 };
  
  private static final byte[] o = new byte[] { 79, 76, 89, 77, 80, 0 };
  
  private static final byte[] p = new byte[] { 79, 76, 89, 77, 80, 85, 83, 0, 73, 73 };
  
  private static SimpleDateFormat q;
  
  static final String[] r = new String[] { 
      "", "BYTE", "STRING", "USHORT", "ULONG", "URATIONAL", "SBYTE", "UNDEFINED", "SSHORT", "SLONG", 
      "SRATIONAL", "SINGLE", "DOUBLE" };
  
  static final int[] s = new int[] { 
      0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 
      8, 4, 8, 1 };
  
  private static final byte[] t = new byte[] { 65, 83, 67, 73, 73, 0, 0, 0 };
  
  private static final d[] u = new d[] { 
      new d("NewSubfileType", 254, 4, null), new d("SubfileType", 255, 4, null), new d("ImageWidth", 256, 3, 4, null), new d("ImageLength", 257, 3, 4, null), new d("BitsPerSample", 258, 3, null), new d("Compression", 259, 3, null), new d("PhotometricInterpretation", 262, 3, null), new d("ImageDescription", 270, 2, null), new d("Make", 271, 2, null), new d("Model", 272, 2, null), 
      new d("StripOffsets", 273, 3, 4, null), new d("Orientation", 274, 3, null), new d("SamplesPerPixel", 277, 3, null), new d("RowsPerStrip", 278, 3, 4, null), new d("StripByteCounts", 279, 3, 4, null), new d("XResolution", 282, 5, null), new d("YResolution", 283, 5, null), new d("PlanarConfiguration", 284, 3, null), new d("ResolutionUnit", 296, 3, null), new d("TransferFunction", 301, 3, null), 
      new d("Software", 305, 2, null), new d("DateTime", 306, 2, null), new d("Artist", 315, 2, null), new d("WhitePoint", 318, 5, null), new d("PrimaryChromaticities", 319, 5, null), new d("SubIFDPointer", 330, 4, null), new d("JPEGInterchangeFormat", 513, 4, null), new d("JPEGInterchangeFormatLength", 514, 4, null), new d("YCbCrCoefficients", 529, 5, null), new d("YCbCrSubSampling", 530, 3, null), 
      new d("YCbCrPositioning", 531, 3, null), new d("ReferenceBlackWhite", 532, 5, null), new d("Copyright", 33432, 2, null), new d("ExifIFDPointer", 34665, 4, null), new d("GPSInfoIFDPointer", 34853, 4, null), new d("SensorTopBorder", 4, 4, null), new d("SensorLeftBorder", 5, 4, null), new d("SensorBottomBorder", 6, 4, null), new d("SensorRightBorder", 7, 4, null), new d("ISO", 23, 3, null), 
      new d("JpgFromRaw", 46, 7, null) };
  
  private static final d[] v = new d[] { 
      new d("ExposureTime", 33434, 5, null), new d("FNumber", 33437, 5, null), new d("ExposureProgram", 34850, 3, null), new d("SpectralSensitivity", 34852, 2, null), new d("PhotographicSensitivity", 34855, 3, null), new d("OECF", 34856, 7, null), new d("ExifVersion", 36864, 2, null), new d("DateTimeOriginal", 36867, 2, null), new d("DateTimeDigitized", 36868, 2, null), new d("ComponentsConfiguration", 37121, 7, null), 
      new d("CompressedBitsPerPixel", 37122, 5, null), new d("ShutterSpeedValue", 37377, 10, null), new d("ApertureValue", 37378, 5, null), new d("BrightnessValue", 37379, 10, null), new d("ExposureBiasValue", 37380, 10, null), new d("MaxApertureValue", 37381, 5, null), new d("SubjectDistance", 37382, 5, null), new d("MeteringMode", 37383, 3, null), new d("LightSource", 37384, 3, null), new d("Flash", 37385, 3, null), 
      new d("FocalLength", 37386, 5, null), new d("SubjectArea", 37396, 3, null), new d("MakerNote", 37500, 7, null), new d("UserComment", 37510, 7, null), new d("SubSecTime", 37520, 2, null), new d("SubSecTimeOriginal", 37521, 2, null), new d("SubSecTimeDigitized", 37522, 2, null), new d("FlashpixVersion", 40960, 7, null), new d("ColorSpace", 40961, 3, null), new d("PixelXDimension", 40962, 3, 4, null), 
      new d("PixelYDimension", 40963, 3, 4, null), new d("RelatedSoundFile", 40964, 2, null), new d("InteroperabilityIFDPointer", 40965, 4, null), new d("FlashEnergy", 41483, 5, null), new d("SpatialFrequencyResponse", 41484, 7, null), new d("FocalPlaneXResolution", 41486, 5, null), new d("FocalPlaneYResolution", 41487, 5, null), new d("FocalPlaneResolutionUnit", 41488, 3, null), new d("SubjectLocation", 41492, 3, null), new d("ExposureIndex", 41493, 5, null), 
      new d("SensingMethod", 41495, 3, null), new d("FileSource", 41728, 7, null), new d("SceneType", 41729, 7, null), new d("CFAPattern", 41730, 7, null), new d("CustomRendered", 41985, 3, null), new d("ExposureMode", 41986, 3, null), new d("WhiteBalance", 41987, 3, null), new d("DigitalZoomRatio", 41988, 5, null), new d("FocalLengthIn35mmFilm", 41989, 3, null), new d("SceneCaptureType", 41990, 3, null), 
      new d("GainControl", 41991, 3, null), new d("Contrast", 41992, 3, null), new d("Saturation", 41993, 3, null), new d("Sharpness", 41994, 3, null), new d("DeviceSettingDescription", 41995, 7, null), new d("SubjectDistanceRange", 41996, 3, null), new d("ImageUniqueID", 42016, 2, null), new d("DNGVersion", 50706, 1, null), new d("DefaultCropSize", 50720, 3, 4, null) };
  
  private static final d[] w = new d[] { 
      new d("GPSVersionID", 0, 1, null), new d("GPSLatitudeRef", 1, 2, null), new d("GPSLatitude", 2, 5, null), new d("GPSLongitudeRef", 3, 2, null), new d("GPSLongitude", 4, 5, null), new d("GPSAltitudeRef", 5, 1, null), new d("GPSAltitude", 6, 5, null), new d("GPSTimeStamp", 7, 5, null), new d("GPSSatellites", 8, 2, null), new d("GPSStatus", 9, 2, null), 
      new d("GPSMeasureMode", 10, 2, null), new d("GPSDOP", 11, 5, null), new d("GPSSpeedRef", 12, 2, null), new d("GPSSpeed", 13, 5, null), new d("GPSTrackRef", 14, 2, null), new d("GPSTrack", 15, 5, null), new d("GPSImgDirectionRef", 16, 2, null), new d("GPSImgDirection", 17, 5, null), new d("GPSMapDatum", 18, 2, null), new d("GPSDestLatitudeRef", 19, 2, null), 
      new d("GPSDestLatitude", 20, 5, null), new d("GPSDestLongitudeRef", 21, 2, null), new d("GPSDestLongitude", 22, 5, null), new d("GPSDestBearingRef", 23, 2, null), new d("GPSDestBearing", 24, 5, null), new d("GPSDestDistanceRef", 25, 2, null), new d("GPSDestDistance", 26, 5, null), new d("GPSProcessingMethod", 27, 7, null), new d("GPSAreaInformation", 28, 7, null), new d("GPSDateStamp", 29, 2, null), 
      new d("GPSDifferential", 30, 3, null) };
  
  private static final d[] x = new d[] { new d("InteroperabilityIndex", 1, 2, null) };
  
  private static final d[] y = new d[] { 
      new d("NewSubfileType", 254, 4, null), new d("SubfileType", 255, 4, null), new d("ThumbnailImageWidth", 256, 3, 4, null), new d("ThumbnailImageLength", 257, 3, 4, null), new d("BitsPerSample", 258, 3, null), new d("Compression", 259, 3, null), new d("PhotometricInterpretation", 262, 3, null), new d("ImageDescription", 270, 2, null), new d("Make", 271, 2, null), new d("Model", 272, 2, null), 
      new d("StripOffsets", 273, 3, 4, null), new d("Orientation", 274, 3, null), new d("SamplesPerPixel", 277, 3, null), new d("RowsPerStrip", 278, 3, 4, null), new d("StripByteCounts", 279, 3, 4, null), new d("XResolution", 282, 5, null), new d("YResolution", 283, 5, null), new d("PlanarConfiguration", 284, 3, null), new d("ResolutionUnit", 296, 3, null), new d("TransferFunction", 301, 3, null), 
      new d("Software", 305, 2, null), new d("DateTime", 306, 2, null), new d("Artist", 315, 2, null), new d("WhitePoint", 318, 5, null), new d("PrimaryChromaticities", 319, 5, null), new d("SubIFDPointer", 330, 4, null), new d("JPEGInterchangeFormat", 513, 4, null), new d("JPEGInterchangeFormatLength", 514, 4, null), new d("YCbCrCoefficients", 529, 5, null), new d("YCbCrSubSampling", 530, 3, null), 
      new d("YCbCrPositioning", 531, 3, null), new d("ReferenceBlackWhite", 532, 5, null), new d("Copyright", 33432, 2, null), new d("ExifIFDPointer", 34665, 4, null), new d("GPSInfoIFDPointer", 34853, 4, null), new d("DNGVersion", 50706, 1, null), new d("DefaultCropSize", 50720, 3, 4, null) };
  
  private static final d z = new d("StripOffsets", 273, 3, null);
  
  private final String a;
  
  private final AssetManager.AssetInputStream b;
  
  private int c;
  
  private final HashMap<String, c>[] d = (HashMap<String, c>[])new HashMap[E.length];
  
  private ByteOrder e = ByteOrder.BIG_ENDIAN;
  
  private int f;
  
  private int g;
  
  private int h;
  
  private int i;
  
  private int j;
  
  private int k;
  
  static {
    A = new d[] { new d("ThumbnailImage", 256, 7, null), new d("CameraSettingsIFDPointer", 8224, 4, null), new d("ImageProcessingIFDPointer", 8256, 4, null) };
    B = new d[] { new d("PreviewImageStart", 257, 4, null), new d("PreviewImageLength", 258, 4, null) };
    C = new d[] { new d("AspectFrame", 4371, 3, null) };
    D = new d[] { new d("ColorSpace", 55, 3, null) };
    d[] arrayOfD1 = u;
    E = new d[][] { arrayOfD1, v, w, x, y, arrayOfD1, A, B, C, D };
    F = new d[] { new d("SubIFDPointer", 330, 4, null), new d("ExifIFDPointer", 34665, 4, null), new d("GPSInfoIFDPointer", 34853, 4, null), new d("InteroperabilityIFDPointer", 40965, 4, null), new d("CameraSettingsIFDPointer", 8224, 1, null), new d("ImageProcessingIFDPointer", 8256, 1, null) };
    new d("JPEGInterchangeFormat", 513, 4, null);
    new d("JPEGInterchangeFormatLength", 514, 4, null);
    d[][] arrayOfD = E;
    G = (HashMap<Integer, d>[])new HashMap[arrayOfD.length];
    H = (HashMap<String, d>[])new HashMap[arrayOfD.length];
    I = new HashSet<String>(Arrays.asList(new String[] { "FNumber", "DigitalZoomRatio", "ExposureTime", "SubjectDistance", "GPSTimeStamp" }));
    J = new HashMap<Integer, Integer>();
    K = Charset.forName("US-ASCII");
    L = "Exif\000\000".getBytes(K);
    q = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss");
    q.setTimeZone(TimeZone.getTimeZone("UTC"));
    for (byte b = 0; b < E.length; b++) {
      G[b] = new HashMap<Integer, d>();
      H[b] = new HashMap<String, d>();
      for (d d1 : E[b]) {
        G[b].put(Integer.valueOf(d1.a), d1);
        H[b].put(d1.b, d1);
      } 
    } 
    J.put(Integer.valueOf((F[0]).a), integer3);
    J.put(Integer.valueOf((F[1]).a), integer2);
    J.put(Integer.valueOf((F[2]).a), integer6);
    J.put(Integer.valueOf((F[3]).a), integer5);
    J.put(Integer.valueOf((F[4]).a), integer1);
    J.put(Integer.valueOf((F[5]).a), integer4);
    Pattern.compile(".*[1-9].*");
    Pattern.compile("^([0-9][0-9]):([0-9][0-9]):([0-9][0-9])$");
  }
  
  public a(String paramString) {
    if (paramString != null) {
      FileInputStream fileInputStream2 = null;
      this.b = null;
      this.a = paramString;
      FileInputStream fileInputStream1 = fileInputStream2;
      try {
        FileInputStream fileInputStream4 = new FileInputStream();
        fileInputStream1 = fileInputStream2;
        this(paramString);
        FileInputStream fileInputStream3 = fileInputStream4;
        fileInputStream1 = fileInputStream3;
        a(fileInputStream3);
        return;
      } finally {
        a(fileInputStream1);
      } 
    } 
    throw new IllegalArgumentException("filename cannot be null");
  }
  
  private int a(BufferedInputStream paramBufferedInputStream) {
    paramBufferedInputStream.mark(5000);
    byte[] arrayOfByte = new byte[5000];
    paramBufferedInputStream.read(arrayOfByte);
    paramBufferedInputStream.reset();
    return a(arrayOfByte) ? 4 : (c(arrayOfByte) ? 9 : (b(arrayOfByte) ? 7 : (d(arrayOfByte) ? 10 : 0)));
  }
  
  private void a(int paramInt1, int paramInt2) {
    if (this.d[paramInt1].isEmpty() || this.d[paramInt2].isEmpty())
      return; 
    c c3 = this.d[paramInt1].get("ImageLength");
    c c1 = this.d[paramInt1].get("ImageWidth");
    c c4 = this.d[paramInt2].get("ImageLength");
    c c2 = this.d[paramInt2].get("ImageWidth");
    if (c3 != null && c1 != null && c4 != null && c2 != null) {
      int j = c3.b(this.e);
      int i = c1.b(this.e);
      int m = c4.b(this.e);
      int k = c2.b(this.e);
      if (j < m && i < k) {
        HashMap<String, c>[] arrayOfHashMap = this.d;
        HashMap<String, c> hashMap = arrayOfHashMap[paramInt1];
        arrayOfHashMap[paramInt1] = arrayOfHashMap[paramInt2];
        arrayOfHashMap[paramInt2] = hashMap;
      } 
    } 
  }
  
  private void a(b paramb) {
    c(paramb);
    c c = this.d[1].get("MakerNote");
    if (c != null) {
      b b1 = new b(c.c);
      b1.a(this.e);
      byte[] arrayOfByte2 = new byte[o.length];
      b1.readFully(arrayOfByte2);
      b1.g(0L);
      byte[] arrayOfByte1 = new byte[p.length];
      b1.readFully(arrayOfByte1);
      if (Arrays.equals(arrayOfByte2, o)) {
        b1.g(8L);
      } else if (Arrays.equals(arrayOfByte1, p)) {
        b1.g(12L);
      } 
      b(b1, 6);
      c c2 = this.d[7].get("PreviewImageStart");
      c c1 = this.d[7].get("PreviewImageLength");
      if (c2 != null && c1 != null) {
        this.d[5].put("JPEGInterchangeFormat", c2);
        this.d[5].put("JPEGInterchangeFormatLength", c1);
      } 
      c1 = this.d[8].get("AspectFrame");
      if (c1 != null) {
        int[] arrayOfInt = (int[])c.a(c1, this.e);
        if (arrayOfInt == null || arrayOfInt.length != 4) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid aspect frame values. frame=");
          stringBuilder.append(Arrays.toString(arrayOfInt));
          Log.w("ExifInterface", stringBuilder.toString());
          return;
        } 
        if (arrayOfInt[2] > arrayOfInt[0] && arrayOfInt[3] > arrayOfInt[1]) {
          int m = arrayOfInt[2] - arrayOfInt[0] + 1;
          int k = arrayOfInt[3] - arrayOfInt[1] + 1;
          int j = m;
          int i = k;
          if (m < k) {
            j = m + k;
            i = j - k;
            j -= i;
          } 
          c c3 = c.a(j, this.e);
          c2 = c.a(i, this.e);
          this.d[0].put("ImageWidth", c3);
          this.d[0].put("ImageLength", c2);
        } 
      } 
    } 
  }
  
  private void a(b paramb, int paramInt) {
    this.e = e(paramb);
    paramb.a(this.e);
    int i = paramb.readUnsignedShort();
    int j = this.c;
    if (j == 7 || j == 10 || i == 42) {
      i = paramb.readInt();
      if (i >= 8 && i < paramInt) {
        paramInt = i - 8;
        if (paramInt <= 0 || paramb.skipBytes(paramInt) == paramInt)
          return; 
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Couldn't jump to first Ifd: ");
        stringBuilder2.append(paramInt);
        throw new IOException(stringBuilder2.toString());
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Invalid first Ifd offset: ");
      stringBuilder1.append(i);
      throw new IOException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Invalid start code: ");
    stringBuilder.append(Integer.toHexString(i));
    throw new IOException(stringBuilder.toString());
  }
  
  private void a(b paramb, int paramInt1, int paramInt2) {
    paramb.a(ByteOrder.BIG_ENDIAN);
    paramb.g(paramInt1);
    int i = paramb.readByte();
    if (i == -1) {
      if (paramb.readByte() == -40) {
        paramInt1 = paramInt1 + 1 + 1;
        while (true) {
          i = paramb.readByte();
          if (i == -1) {
            i = paramb.readByte();
            if (i != -39) {
              if (i == -38)
                continue; 
              int k = paramb.readUnsignedShort() - 2;
              int j = paramInt1 + 1 + 1 + 2;
              if (k >= 0) {
                if (i != -31) {
                  if (i != -2) {
                    switch (i) {
                      default:
                        switch (i) {
                          default:
                            switch (i) {
                              default:
                                switch (i) {
                                  default:
                                    i = j;
                                    paramInt1 = k;
                                    break;
                                  case -51:
                                  case -50:
                                  case -49:
                                    break;
                                } 
                                break;
                              case -55:
                              case -54:
                              case -53:
                                break;
                            } 
                            break;
                          case -59:
                          case -58:
                          case -57:
                            break;
                        } 
                      case -64:
                      case -63:
                      case -62:
                      case -61:
                        if (paramb.skipBytes(1) == 1) {
                          this.d[paramInt2].put("ImageLength", c.a(paramb.readUnsignedShort(), this.e));
                          this.d[paramInt2].put("ImageWidth", c.a(paramb.readUnsignedShort(), this.e));
                          paramInt1 = k - 5;
                          i = j;
                          break;
                        } 
                        throw new IOException("Invalid SOFx");
                    } 
                  } else {
                    byte[] arrayOfByte = new byte[k];
                    if (paramb.read(arrayOfByte) == k) {
                      k = 0;
                      i = j;
                      paramInt1 = k;
                      if (a("UserComment") == null) {
                        this.d[1].put("UserComment", c.a(new String(arrayOfByte, K)));
                        i = j;
                        paramInt1 = k;
                      } 
                    } else {
                      throw new IOException("Invalid exif");
                    } 
                  } 
                } else if (k < 6) {
                  i = j;
                  paramInt1 = k;
                } else {
                  byte[] arrayOfByte = new byte[6];
                  if (paramb.read(arrayOfByte) == 6) {
                    i = j + 6;
                    paramInt1 = k - 6;
                    if (Arrays.equals(arrayOfByte, L))
                      if (paramInt1 > 0) {
                        this.g = i;
                        arrayOfByte = new byte[paramInt1];
                        if (paramb.read(arrayOfByte) == paramInt1) {
                          i += paramInt1;
                          paramInt1 = 0;
                          a(arrayOfByte, paramInt2);
                        } else {
                          throw new IOException("Invalid exif");
                        } 
                      } else {
                        throw new IOException("Invalid exif");
                      }  
                  } else {
                    throw new IOException("Invalid exif");
                  } 
                } 
                if (paramInt1 >= 0) {
                  if (paramb.skipBytes(paramInt1) == paramInt1) {
                    paramInt1 = i + paramInt1;
                    continue;
                  } 
                  throw new IOException("Invalid JPEG segment");
                } 
                throw new IOException("Invalid length");
              } 
              throw new IOException("Invalid length");
            } 
            paramb.a(this.e);
            return;
          } 
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Invalid marker:");
          stringBuilder2.append(Integer.toHexString(i & 0xFF));
          throw new IOException(stringBuilder2.toString());
        } 
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Invalid marker: ");
      stringBuilder1.append(Integer.toHexString(i & 0xFF));
      throw new IOException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Invalid marker: ");
    stringBuilder.append(Integer.toHexString(i & 0xFF));
    IOException iOException = new IOException(stringBuilder.toString());
    throw iOException;
  }
  
  private void a(b paramb, HashMap paramHashMap) {
    c c2 = (c)paramHashMap.get("JPEGInterchangeFormat");
    c c1 = (c)paramHashMap.get("JPEGInterchangeFormatLength");
    if (c2 != null && c1 != null) {
      int i;
      int j = c2.b(this.e);
      int k = Math.min(c1.b(this.e), paramb.available() - j);
      int m = this.c;
      if (m == 4 || m == 9 || m == 10) {
        i = j + this.g;
      } else {
        i = j;
        if (m == 7)
          i = j + this.h; 
      } 
      if (i > 0 && k > 0 && this.a == null && this.b == null) {
        byte[] arrayOfByte = new byte[k];
        paramb.g(i);
        paramb.readFully(arrayOfByte);
      } 
    } 
  }
  
  private static void a(Closeable paramCloseable) {
    if (paramCloseable != null)
      try {
        paramCloseable.close();
      } catch (RuntimeException runtimeException) {
        throw runtimeException;
      } catch (Exception exception) {} 
  }
  
  private void a(InputStream paramInputStream) {
    byte b = 0;
    try {
      while (b < E.length) {
        this.d[b] = new HashMap<String, c>();
        b++;
      } 
      BufferedInputStream bufferedInputStream = new BufferedInputStream();
      this(paramInputStream, 5000);
      this.c = a(bufferedInputStream);
      paramInputStream = new b();
      super(bufferedInputStream);
      switch (this.c) {
        case 10:
          d((b)paramInputStream);
          break;
        case 9:
          b((b)paramInputStream);
          break;
        case 7:
          a((b)paramInputStream);
          break;
        case 4:
          a((b)paramInputStream, 0, 0);
          break;
        case 0:
        case 1:
        case 2:
        case 3:
        case 5:
        case 6:
        case 8:
        case 11:
          c((b)paramInputStream);
          break;
      } 
    } catch (IOException iOException) {
    
    } finally {
      c();
    } 
    c();
  }
  
  private void a(byte[] paramArrayOfbyte, int paramInt) {
    b b = new b(paramArrayOfbyte);
    a(b, paramArrayOfbyte.length);
    b(b, paramInt);
  }
  
  private boolean a(HashMap paramHashMap) {
    c c = (c)paramHashMap.get("BitsPerSample");
    if (c != null) {
      int[] arrayOfInt = (int[])c.a(c, this.e);
      if (Arrays.equals(l, arrayOfInt))
        return true; 
      if (this.c == 3) {
        c c1 = (c)paramHashMap.get("PhotometricInterpretation");
        if (c1 != null) {
          int i = c1.b(this.e);
          if ((i == 1 && Arrays.equals(arrayOfInt, m)) || (i == 6 && Arrays.equals(arrayOfInt, l)))
            return true; 
        } 
      } 
    } 
    return false;
  }
  
  private static boolean a(byte[] paramArrayOfbyte) {
    byte b = 0;
    while (true) {
      byte[] arrayOfByte = n;
      if (b < arrayOfByte.length) {
        if (paramArrayOfbyte[b] != arrayOfByte[b])
          return false; 
        b++;
        continue;
      } 
      return true;
    } 
  }
  
  private static long[] a(Object paramObject) {
    if (paramObject instanceof int[]) {
      int[] arrayOfInt = (int[])paramObject;
      paramObject = new long[arrayOfInt.length];
      for (byte b = 0; b < arrayOfInt.length; b++)
        paramObject[b] = arrayOfInt[b]; 
      return (long[])paramObject;
    } 
    return (paramObject instanceof long[]) ? (long[])paramObject : null;
  }
  
  private c b(String paramString) {
    String str = paramString;
    if ("ISOSpeedRatings".equals(paramString))
      str = "PhotographicSensitivity"; 
    for (byte b = 0; b < E.length; b++) {
      c c = this.d[b].get(str);
      if (c != null)
        return c; 
    } 
    return null;
  }
  
  private void b(b paramb) {
    paramb.skipBytes(84);
    byte[] arrayOfByte2 = new byte[4];
    byte[] arrayOfByte1 = new byte[4];
    paramb.read(arrayOfByte2);
    paramb.skipBytes(4);
    paramb.read(arrayOfByte1);
    int j = ByteBuffer.wrap(arrayOfByte2).getInt();
    int i = ByteBuffer.wrap(arrayOfByte1).getInt();
    a(paramb, j, 5);
    paramb.g(i);
    paramb.a(ByteOrder.BIG_ENDIAN);
    j = paramb.readInt();
    for (i = 0; i < j; i++) {
      c c;
      int k = paramb.readUnsignedShort();
      int m = paramb.readUnsignedShort();
      if (k == z.a) {
        j = paramb.readShort();
        i = paramb.readShort();
        c c1 = c.a(j, this.e);
        c = c.a(i, this.e);
        this.d[0].put("ImageLength", c1);
        this.d[0].put("ImageWidth", c);
        return;
      } 
      c.skipBytes(m);
    } 
  }
  
  private void b(b paramb, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic a : (La/b/e/a$b;)I
    //   4: iconst_2
    //   5: iadd
    //   6: aload_1
    //   7: invokestatic b : (La/b/e/a$b;)I
    //   10: if_icmple -> 14
    //   13: return
    //   14: aload_1
    //   15: invokevirtual readShort : ()S
    //   18: istore #5
    //   20: aload_1
    //   21: invokestatic a : (La/b/e/a$b;)I
    //   24: iload #5
    //   26: bipush #12
    //   28: imul
    //   29: iadd
    //   30: aload_1
    //   31: invokestatic b : (La/b/e/a$b;)I
    //   34: if_icmple -> 38
    //   37: return
    //   38: iconst_0
    //   39: istore #4
    //   41: iload #4
    //   43: iload #5
    //   45: if_icmpge -> 1005
    //   48: aload_1
    //   49: invokevirtual readUnsignedShort : ()I
    //   52: istore #9
    //   54: aload_1
    //   55: invokevirtual readUnsignedShort : ()I
    //   58: istore #6
    //   60: aload_1
    //   61: invokevirtual readInt : ()I
    //   64: istore #8
    //   66: aload_1
    //   67: invokevirtual l : ()I
    //   70: i2l
    //   71: ldc2_w 4
    //   74: ladd
    //   75: lstore #12
    //   77: getstatic a/b/e/a.G : [Ljava/util/HashMap;
    //   80: iload_2
    //   81: aaload
    //   82: iload #9
    //   84: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   87: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   90: checkcast a/b/e/a$d
    //   93: astore #14
    //   95: iconst_0
    //   96: istore #7
    //   98: aload #14
    //   100: ifnonnull -> 144
    //   103: new java/lang/StringBuilder
    //   106: dup
    //   107: invokespecial <init> : ()V
    //   110: astore #15
    //   112: aload #15
    //   114: ldc_w 'Skip the tag entry since tag number is not defined: '
    //   117: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   120: pop
    //   121: aload #15
    //   123: iload #9
    //   125: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   128: pop
    //   129: ldc_w 'ExifInterface'
    //   132: aload #15
    //   134: invokevirtual toString : ()Ljava/lang/String;
    //   137: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   140: pop
    //   141: goto -> 368
    //   144: iload #6
    //   146: ifle -> 330
    //   149: iload #6
    //   151: getstatic a/b/e/a.s : [I
    //   154: arraylength
    //   155: if_icmplt -> 161
    //   158: goto -> 330
    //   161: aload #14
    //   163: iload #6
    //   165: invokestatic a : (La/b/e/a$d;I)Z
    //   168: ifne -> 236
    //   171: new java/lang/StringBuilder
    //   174: dup
    //   175: invokespecial <init> : ()V
    //   178: astore #15
    //   180: aload #15
    //   182: ldc_w 'Skip the tag entry since data format ('
    //   185: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   188: pop
    //   189: aload #15
    //   191: getstatic a/b/e/a.r : [Ljava/lang/String;
    //   194: iload #6
    //   196: aaload
    //   197: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   200: pop
    //   201: aload #15
    //   203: ldc_w ') is unexpected for tag: '
    //   206: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   209: pop
    //   210: aload #15
    //   212: aload #14
    //   214: getfield b : Ljava/lang/String;
    //   217: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   220: pop
    //   221: ldc_w 'ExifInterface'
    //   224: aload #15
    //   226: invokevirtual toString : ()Ljava/lang/String;
    //   229: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   232: pop
    //   233: goto -> 368
    //   236: iload #6
    //   238: istore_3
    //   239: iload #6
    //   241: bipush #7
    //   243: if_icmpne -> 252
    //   246: aload #14
    //   248: getfield c : I
    //   251: istore_3
    //   252: iload #8
    //   254: i2l
    //   255: getstatic a/b/e/a.s : [I
    //   258: iload_3
    //   259: iaload
    //   260: i2l
    //   261: lmul
    //   262: lstore #10
    //   264: lload #10
    //   266: lconst_0
    //   267: lcmp
    //   268: iflt -> 289
    //   271: lload #10
    //   273: ldc2_w 2147483647
    //   276: lcmp
    //   277: ifle -> 283
    //   280: goto -> 289
    //   283: iconst_1
    //   284: istore #7
    //   286: goto -> 374
    //   289: new java/lang/StringBuilder
    //   292: dup
    //   293: invokespecial <init> : ()V
    //   296: astore #15
    //   298: aload #15
    //   300: ldc_w 'Skip the tag entry since the number of components is invalid: '
    //   303: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   306: pop
    //   307: aload #15
    //   309: iload #8
    //   311: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   314: pop
    //   315: ldc_w 'ExifInterface'
    //   318: aload #15
    //   320: invokevirtual toString : ()Ljava/lang/String;
    //   323: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   326: pop
    //   327: goto -> 374
    //   330: new java/lang/StringBuilder
    //   333: dup
    //   334: invokespecial <init> : ()V
    //   337: astore #15
    //   339: aload #15
    //   341: ldc_w 'Skip the tag entry since data format is invalid: '
    //   344: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   347: pop
    //   348: aload #15
    //   350: iload #6
    //   352: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   355: pop
    //   356: ldc_w 'ExifInterface'
    //   359: aload #15
    //   361: invokevirtual toString : ()Ljava/lang/String;
    //   364: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   367: pop
    //   368: lconst_0
    //   369: lstore #10
    //   371: iload #6
    //   373: istore_3
    //   374: iload #7
    //   376: ifne -> 388
    //   379: aload_1
    //   380: lload #12
    //   382: invokevirtual g : (J)V
    //   385: goto -> 995
    //   388: lload #10
    //   390: ldc2_w 4
    //   393: lcmp
    //   394: ifle -> 659
    //   397: aload_1
    //   398: invokevirtual readInt : ()I
    //   401: istore #7
    //   403: aload_0
    //   404: getfield c : I
    //   407: istore #6
    //   409: iload #6
    //   411: bipush #7
    //   413: if_icmpne -> 561
    //   416: ldc_w 'MakerNote'
    //   419: aload #14
    //   421: getfield b : Ljava/lang/String;
    //   424: invokevirtual equals : (Ljava/lang/Object;)Z
    //   427: ifeq -> 439
    //   430: aload_0
    //   431: iload #7
    //   433: putfield h : I
    //   436: goto -> 587
    //   439: iload_2
    //   440: bipush #6
    //   442: if_icmpne -> 558
    //   445: ldc_w 'ThumbnailImage'
    //   448: aload #14
    //   450: getfield b : Ljava/lang/String;
    //   453: invokevirtual equals : (Ljava/lang/Object;)Z
    //   456: ifeq -> 555
    //   459: aload_0
    //   460: iload #7
    //   462: putfield i : I
    //   465: aload_0
    //   466: iload #8
    //   468: putfield j : I
    //   471: bipush #6
    //   473: aload_0
    //   474: getfield e : Ljava/nio/ByteOrder;
    //   477: invokestatic a : (ILjava/nio/ByteOrder;)La/b/e/a$c;
    //   480: astore #15
    //   482: aload_0
    //   483: getfield i : I
    //   486: i2l
    //   487: aload_0
    //   488: getfield e : Ljava/nio/ByteOrder;
    //   491: invokestatic a : (JLjava/nio/ByteOrder;)La/b/e/a$c;
    //   494: astore #17
    //   496: aload_0
    //   497: getfield j : I
    //   500: i2l
    //   501: aload_0
    //   502: getfield e : Ljava/nio/ByteOrder;
    //   505: invokestatic a : (JLjava/nio/ByteOrder;)La/b/e/a$c;
    //   508: astore #16
    //   510: aload_0
    //   511: getfield d : [Ljava/util/HashMap;
    //   514: iconst_4
    //   515: aaload
    //   516: ldc 'Compression'
    //   518: aload #15
    //   520: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   523: pop
    //   524: aload_0
    //   525: getfield d : [Ljava/util/HashMap;
    //   528: iconst_4
    //   529: aaload
    //   530: ldc 'JPEGInterchangeFormat'
    //   532: aload #17
    //   534: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   537: pop
    //   538: aload_0
    //   539: getfield d : [Ljava/util/HashMap;
    //   542: iconst_4
    //   543: aaload
    //   544: ldc 'JPEGInterchangeFormatLength'
    //   546: aload #16
    //   548: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   551: pop
    //   552: goto -> 587
    //   555: goto -> 587
    //   558: goto -> 587
    //   561: iload #6
    //   563: bipush #10
    //   565: if_icmpne -> 587
    //   568: ldc 'JpgFromRaw'
    //   570: aload #14
    //   572: getfield b : Ljava/lang/String;
    //   575: invokevirtual equals : (Ljava/lang/Object;)Z
    //   578: ifeq -> 587
    //   581: aload_0
    //   582: iload #7
    //   584: putfield k : I
    //   587: iload #7
    //   589: i2l
    //   590: lload #10
    //   592: ladd
    //   593: aload_1
    //   594: invokestatic b : (La/b/e/a$b;)I
    //   597: i2l
    //   598: lcmp
    //   599: ifgt -> 612
    //   602: aload_1
    //   603: iload #7
    //   605: i2l
    //   606: invokevirtual g : (J)V
    //   609: goto -> 659
    //   612: new java/lang/StringBuilder
    //   615: dup
    //   616: invokespecial <init> : ()V
    //   619: astore #14
    //   621: aload #14
    //   623: ldc_w 'Skip the tag entry since data offset is invalid: '
    //   626: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   629: pop
    //   630: aload #14
    //   632: iload #7
    //   634: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   637: pop
    //   638: ldc_w 'ExifInterface'
    //   641: aload #14
    //   643: invokevirtual toString : ()Ljava/lang/String;
    //   646: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   649: pop
    //   650: aload_1
    //   651: lload #12
    //   653: invokevirtual g : (J)V
    //   656: goto -> 995
    //   659: getstatic a/b/e/a.J : Ljava/util/HashMap;
    //   662: iload #9
    //   664: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   667: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   670: checkcast java/lang/Integer
    //   673: astore #15
    //   675: aload #15
    //   677: ifnull -> 836
    //   680: ldc2_w -1
    //   683: lstore #10
    //   685: iload_3
    //   686: iconst_3
    //   687: if_icmpeq -> 745
    //   690: iload_3
    //   691: iconst_4
    //   692: if_icmpeq -> 736
    //   695: iload_3
    //   696: bipush #8
    //   698: if_icmpeq -> 726
    //   701: iload_3
    //   702: bipush #9
    //   704: if_icmpeq -> 716
    //   707: iload_3
    //   708: bipush #13
    //   710: if_icmpeq -> 716
    //   713: goto -> 752
    //   716: aload_1
    //   717: invokevirtual readInt : ()I
    //   720: i2l
    //   721: lstore #10
    //   723: goto -> 752
    //   726: aload_1
    //   727: invokevirtual readShort : ()S
    //   730: i2l
    //   731: lstore #10
    //   733: goto -> 752
    //   736: aload_1
    //   737: invokevirtual m : ()J
    //   740: lstore #10
    //   742: goto -> 752
    //   745: aload_1
    //   746: invokevirtual readUnsignedShort : ()I
    //   749: i2l
    //   750: lstore #10
    //   752: lload #10
    //   754: lconst_0
    //   755: lcmp
    //   756: ifle -> 789
    //   759: lload #10
    //   761: aload_1
    //   762: invokestatic b : (La/b/e/a$b;)I
    //   765: i2l
    //   766: lcmp
    //   767: ifge -> 789
    //   770: aload_1
    //   771: lload #10
    //   773: invokevirtual g : (J)V
    //   776: aload_0
    //   777: aload_1
    //   778: aload #15
    //   780: invokevirtual intValue : ()I
    //   783: invokespecial b : (La/b/e/a$b;I)V
    //   786: goto -> 827
    //   789: new java/lang/StringBuilder
    //   792: dup
    //   793: invokespecial <init> : ()V
    //   796: astore #14
    //   798: aload #14
    //   800: ldc_w 'Skip jump into the IFD since its offset is invalid: '
    //   803: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   806: pop
    //   807: aload #14
    //   809: lload #10
    //   811: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   814: pop
    //   815: ldc_w 'ExifInterface'
    //   818: aload #14
    //   820: invokevirtual toString : ()Ljava/lang/String;
    //   823: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   826: pop
    //   827: aload_1
    //   828: lload #12
    //   830: invokevirtual g : (J)V
    //   833: goto -> 995
    //   836: lload #10
    //   838: l2i
    //   839: newarray byte
    //   841: astore #15
    //   843: aload_1
    //   844: aload #15
    //   846: invokevirtual readFully : ([B)V
    //   849: new a/b/e/a$c
    //   852: dup
    //   853: iload_3
    //   854: iload #8
    //   856: aload #15
    //   858: aconst_null
    //   859: invokespecial <init> : (II[BLa/b/e/a$a;)V
    //   862: astore #15
    //   864: aload_0
    //   865: getfield d : [Ljava/util/HashMap;
    //   868: iload_2
    //   869: aaload
    //   870: aload #14
    //   872: getfield b : Ljava/lang/String;
    //   875: aload #15
    //   877: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   880: pop
    //   881: ldc_w 'DNGVersion'
    //   884: aload #14
    //   886: getfield b : Ljava/lang/String;
    //   889: invokevirtual equals : (Ljava/lang/Object;)Z
    //   892: ifeq -> 900
    //   895: aload_0
    //   896: iconst_3
    //   897: putfield c : I
    //   900: ldc 'Make'
    //   902: aload #14
    //   904: getfield b : Ljava/lang/String;
    //   907: invokevirtual equals : (Ljava/lang/Object;)Z
    //   910: ifne -> 926
    //   913: ldc 'Model'
    //   915: aload #14
    //   917: getfield b : Ljava/lang/String;
    //   920: invokevirtual equals : (Ljava/lang/Object;)Z
    //   923: ifeq -> 944
    //   926: aload #15
    //   928: aload_0
    //   929: getfield e : Ljava/nio/ByteOrder;
    //   932: invokevirtual c : (Ljava/nio/ByteOrder;)Ljava/lang/String;
    //   935: ldc_w 'PENTAX'
    //   938: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   941: ifne -> 972
    //   944: ldc 'Compression'
    //   946: aload #14
    //   948: getfield b : Ljava/lang/String;
    //   951: invokevirtual equals : (Ljava/lang/Object;)Z
    //   954: ifeq -> 978
    //   957: aload #15
    //   959: aload_0
    //   960: getfield e : Ljava/nio/ByteOrder;
    //   963: invokevirtual b : (Ljava/nio/ByteOrder;)I
    //   966: ldc_w 65535
    //   969: if_icmpne -> 978
    //   972: aload_0
    //   973: bipush #8
    //   975: putfield c : I
    //   978: aload_1
    //   979: invokevirtual l : ()I
    //   982: i2l
    //   983: lload #12
    //   985: lcmp
    //   986: ifeq -> 995
    //   989: aload_1
    //   990: lload #12
    //   992: invokevirtual g : (J)V
    //   995: iload #4
    //   997: iconst_1
    //   998: iadd
    //   999: i2s
    //   1000: istore #4
    //   1002: goto -> 41
    //   1005: aload_1
    //   1006: invokevirtual l : ()I
    //   1009: iconst_4
    //   1010: iadd
    //   1011: aload_1
    //   1012: invokestatic b : (La/b/e/a$b;)I
    //   1015: if_icmpgt -> 1082
    //   1018: aload_1
    //   1019: invokevirtual readInt : ()I
    //   1022: istore_2
    //   1023: iload_2
    //   1024: bipush #8
    //   1026: if_icmple -> 1082
    //   1029: iload_2
    //   1030: aload_1
    //   1031: invokestatic b : (La/b/e/a$b;)I
    //   1034: if_icmpge -> 1082
    //   1037: aload_1
    //   1038: iload_2
    //   1039: i2l
    //   1040: invokevirtual g : (J)V
    //   1043: aload_0
    //   1044: getfield d : [Ljava/util/HashMap;
    //   1047: iconst_4
    //   1048: aaload
    //   1049: invokevirtual isEmpty : ()Z
    //   1052: ifeq -> 1064
    //   1055: aload_0
    //   1056: aload_1
    //   1057: iconst_4
    //   1058: invokespecial b : (La/b/e/a$b;I)V
    //   1061: goto -> 1082
    //   1064: aload_0
    //   1065: getfield d : [Ljava/util/HashMap;
    //   1068: iconst_5
    //   1069: aaload
    //   1070: invokevirtual isEmpty : ()Z
    //   1073: ifeq -> 1082
    //   1076: aload_0
    //   1077: aload_1
    //   1078: iconst_5
    //   1079: invokespecial b : (La/b/e/a$b;I)V
    //   1082: return
  }
  
  private void b(b paramb, HashMap paramHashMap) {
    c c2 = (c)paramHashMap.get("StripOffsets");
    c c1 = (c)paramHashMap.get("StripByteCounts");
    if (c2 != null && c1 != null) {
      long[] arrayOfLong1 = a(c.a(c2, this.e));
      long[] arrayOfLong2 = a(c.a(c1, this.e));
      if (arrayOfLong1 == null) {
        Log.w("ExifInterface", "stripOffsets should not be null.");
        return;
      } 
      if (arrayOfLong2 == null) {
        Log.w("ExifInterface", "stripByteCounts should not be null.");
        return;
      } 
      int i = arrayOfLong2.length;
      long l = 0L;
      byte b1;
      for (b1 = 0; b1 < i; b1++)
        l += arrayOfLong2[b1]; 
      byte[] arrayOfByte = new byte[(int)l];
      int j = 0;
      i = 0;
      for (b1 = 0; b1 < arrayOfLong1.length; b1++) {
        int m = (int)arrayOfLong1[b1];
        int k = (int)arrayOfLong2[b1];
        m -= j;
        if (m < 0)
          Log.d("ExifInterface", "Invalid strip offset value"); 
        paramb.g(m);
        byte[] arrayOfByte1 = new byte[k];
        paramb.read(arrayOfByte1);
        j = j + m + k;
        System.arraycopy(arrayOfByte1, 0, arrayOfByte, i, arrayOfByte1.length);
        i += arrayOfByte1.length;
      } 
    } 
  }
  
  private void b(InputStream paramInputStream) {
    a(0, 5);
    a(0, 4);
    a(5, 4);
    c c2 = this.d[1].get("PixelXDimension");
    c c1 = this.d[1].get("PixelYDimension");
    if (c2 != null && c1 != null) {
      this.d[0].put("ImageWidth", c2);
      this.d[0].put("ImageLength", c1);
    } 
    if (this.d[4].isEmpty() && b(this.d[5])) {
      HashMap<String, c>[] arrayOfHashMap = this.d;
      arrayOfHashMap[4] = arrayOfHashMap[5];
      arrayOfHashMap[5] = new HashMap<String, c>();
    } 
    if (!b(this.d[4]))
      Log.d("ExifInterface", "No image meets the size requirements of a thumbnail image."); 
  }
  
  private boolean b(HashMap paramHashMap) {
    c c2 = (c)paramHashMap.get("ImageLength");
    c c1 = (c)paramHashMap.get("ImageWidth");
    if (c2 != null && c1 != null) {
      int i = c2.b(this.e);
      int j = c1.b(this.e);
      if (i <= 512 && j <= 512)
        return true; 
    } 
    return false;
  }
  
  private boolean b(byte[] paramArrayOfbyte) {
    b b = new b(paramArrayOfbyte);
    this.e = e(b);
    b.a(this.e);
    short s = b.readShort();
    b.close();
    return (s == 20306 || s == 21330);
  }
  
  private void c() {
    String str = a("DateTimeOriginal");
    if (str != null && a("DateTime") == null)
      this.d[0].put("DateTime", c.a(str)); 
    if (a("ImageWidth") == null)
      this.d[0].put("ImageWidth", c.a(0L, this.e)); 
    if (a("ImageLength") == null)
      this.d[0].put("ImageLength", c.a(0L, this.e)); 
    if (a("Orientation") == null)
      this.d[0].put("Orientation", c.a(0L, this.e)); 
    if (a("LightSource") == null)
      this.d[1].put("LightSource", c.a(0L, this.e)); 
  }
  
  private void c(b paramb) {
    a(paramb, paramb.available());
    b(paramb, 0);
    d(paramb, 0);
    d(paramb, 5);
    d(paramb, 4);
    b(paramb);
    if (this.c == 8) {
      c c = this.d[1].get("MakerNote");
      if (c != null) {
        b b1 = new b(c.c);
        b1.a(this.e);
        b1.g(6L);
        b(b1, 9);
        c c1 = this.d[9].get("ColorSpace");
        if (c1 != null)
          this.d[1].put("ColorSpace", c1); 
      } 
    } 
  }
  
  private void c(b paramb, int paramInt) {
    c c1 = this.d[paramInt].get("ImageLength");
    c c2 = this.d[paramInt].get("ImageWidth");
    if (c1 == null || c2 == null) {
      c1 = this.d[paramInt].get("JPEGInterchangeFormat");
      if (c1 != null)
        a(paramb, c1.b(this.e), paramInt); 
    } 
  }
  
  private boolean c(byte[] paramArrayOfbyte) {
    byte[] arrayOfByte = "FUJIFILMCCD-RAW".getBytes(Charset.defaultCharset());
    for (byte b = 0; b < arrayOfByte.length; b++) {
      if (paramArrayOfbyte[b] != arrayOfByte[b])
        return false; 
    } 
    return true;
  }
  
  private void d(b paramb) {
    c(paramb);
    if ((c)this.d[0].get("JpgFromRaw") != null)
      a(paramb, this.k, 5); 
    c c2 = this.d[0].get("ISO");
    c c1 = this.d[1].get("PhotographicSensitivity");
    if (c2 != null && c1 == null)
      this.d[1].put("PhotographicSensitivity", c2); 
  }
  
  private void d(b paramb, int paramInt) {
    c c2 = this.d[paramInt].get("DefaultCropSize");
    c c1 = this.d[paramInt].get("SensorTopBorder");
    c c5 = this.d[paramInt].get("SensorLeftBorder");
    c c4 = this.d[paramInt].get("SensorBottomBorder");
    c c3 = this.d[paramInt].get("SensorRightBorder");
    if (c2 != null) {
      c c;
      if (c2.a == 5) {
        e[] arrayOfE = (e[])c.a(c2, this.e);
        if (arrayOfE == null || arrayOfE.length != 2) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid crop size values. cropSize=");
          stringBuilder.append(Arrays.toString((Object[])arrayOfE));
          Log.w("ExifInterface", stringBuilder.toString());
          return;
        } 
        c1 = c.a(arrayOfE[0], this.e);
        c = c.a(arrayOfE[1], this.e);
      } else {
        int[] arrayOfInt = (int[])c.a(c2, this.e);
        if (arrayOfInt == null || arrayOfInt.length != 2) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid crop size values. cropSize=");
          stringBuilder.append(Arrays.toString(arrayOfInt));
          Log.w("ExifInterface", stringBuilder.toString());
          return;
        } 
        c1 = c.a(arrayOfInt[0], this.e);
        c = c.a(arrayOfInt[1], this.e);
      } 
      this.d[paramInt].put("ImageWidth", c1);
      this.d[paramInt].put("ImageLength", c);
    } else {
      c c;
      if (c1 != null && c5 != null && c4 != null && c3 != null) {
        int m = c1.b(this.e);
        int k = c4.b(this.e);
        int j = c3.b(this.e);
        int i = c5.b(this.e);
        if (k > m && j > i) {
          c = c.a(k - m, this.e);
          c1 = c.a(j - i, this.e);
          this.d[paramInt].put("ImageLength", c);
          this.d[paramInt].put("ImageWidth", c1);
        } 
      } else {
        c((b)c, paramInt);
      } 
    } 
  }
  
  private boolean d(byte[] paramArrayOfbyte) {
    boolean bool;
    b b = new b(paramArrayOfbyte);
    this.e = e(b);
    b.a(this.e);
    short s = b.readShort();
    b.close();
    if (s == 85) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private ByteOrder e(b paramb) {
    short s = paramb.readShort();
    if (s != 18761) {
      if (s == 19789)
        return ByteOrder.BIG_ENDIAN; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid byte order: ");
      stringBuilder.append(Integer.toHexString(s));
      throw new IOException(stringBuilder.toString());
    } 
    return ByteOrder.LITTLE_ENDIAN;
  }
  
  private void f(b paramb) {
    HashMap<String, c> hashMap = this.d[4];
    c c = hashMap.get("Compression");
    if (c != null) {
      this.f = c.b(this.e);
      int i = this.f;
      if (i != 1)
        if (i != 6) {
          if (i != 7)
            return; 
        } else {
          a(paramb, hashMap);
          return;
        }  
      if (a(hashMap))
        b(paramb, hashMap); 
    } else {
      this.f = 6;
      a(paramb, hashMap);
    } 
  }
  
  public int a(String paramString, int paramInt) {
    c c = b(paramString);
    if (c == null)
      return paramInt; 
    try {
      return c.b(this.e);
    } catch (NumberFormatException numberFormatException) {
      return paramInt;
    } 
  }
  
  public String a(String paramString) {
    c c = b(paramString);
    if (c != null) {
      StringBuilder stringBuilder;
      if (!I.contains(paramString))
        return c.c(this.e); 
      if (paramString.equals("GPSTimeStamp")) {
        int i = c.a;
        if (i != 5 && i != 10) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("GPS Timestamp format is not rational. format=");
          stringBuilder1.append(c.a);
          Log.w("ExifInterface", stringBuilder1.toString());
          return null;
        } 
        e[] arrayOfE = (e[])c.a(c, this.e);
        if (arrayOfE == null || arrayOfE.length != 3) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid GPS Timestamp array. array=");
          stringBuilder.append(Arrays.toString((Object[])arrayOfE));
          Log.w("ExifInterface", stringBuilder.toString());
          return null;
        } 
        return String.format("%02d:%02d:%02d", new Object[] { Integer.valueOf((int)((float)(arrayOfE[0]).a / (float)(arrayOfE[0]).b)), Integer.valueOf((int)((float)(arrayOfE[1]).a / (float)(arrayOfE[1]).b)), Integer.valueOf((int)((float)(arrayOfE[2]).a / (float)(arrayOfE[2]).b)) });
      } 
      try {
        return Double.toString(stringBuilder.a(this.e));
      } catch (NumberFormatException numberFormatException) {
        return null;
      } 
    } 
    return null;
  }
  
  static {
    Integer integer2 = Integer.valueOf(1);
    Integer integer5 = Integer.valueOf(3);
    Integer integer6 = Integer.valueOf(2);
    Integer integer4 = Integer.valueOf(8);
    Arrays.asList(new Integer[] { integer2, Integer.valueOf(6), integer5, integer4 });
    Integer integer1 = Integer.valueOf(7);
    Integer integer3 = Integer.valueOf(5);
    Arrays.asList(new Integer[] { integer6, integer1, Integer.valueOf(4), integer3 });
  }
  
  private static class b extends InputStream implements DataInput {
    private static final ByteOrder g = ByteOrder.LITTLE_ENDIAN;
    
    private static final ByteOrder h = ByteOrder.BIG_ENDIAN;
    
    private DataInputStream c;
    
    private ByteOrder d = ByteOrder.BIG_ENDIAN;
    
    private final int e;
    
    private int f;
    
    public b(InputStream param1InputStream) {
      this.c = new DataInputStream(param1InputStream);
      this.e = this.c.available();
      this.f = 0;
      this.c.mark(this.e);
    }
    
    public b(byte[] param1ArrayOfbyte) {
      this(new ByteArrayInputStream(param1ArrayOfbyte));
    }
    
    public void a(ByteOrder param1ByteOrder) {
      this.d = param1ByteOrder;
    }
    
    public int available() {
      return this.c.available();
    }
    
    public void g(long param1Long) {
      int i = this.f;
      if (i > param1Long) {
        this.f = 0;
        this.c.reset();
        this.c.mark(this.e);
      } else {
        param1Long -= i;
      } 
      if (skipBytes((int)param1Long) == (int)param1Long)
        return; 
      throw new IOException("Couldn't seek up to the byteCount");
    }
    
    public int l() {
      return this.f;
    }
    
    public long m() {
      return readInt() & 0xFFFFFFFFL;
    }
    
    public int read() {
      this.f++;
      return this.c.read();
    }
    
    public int read(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      param1Int1 = this.c.read(param1ArrayOfbyte, param1Int1, param1Int2);
      this.f += param1Int1;
      return param1Int1;
    }
    
    public boolean readBoolean() {
      this.f++;
      return this.c.readBoolean();
    }
    
    public byte readByte() {
      this.f++;
      if (this.f <= this.e) {
        int i = this.c.read();
        if (i >= 0)
          return (byte)i; 
        throw new EOFException();
      } 
      throw new EOFException();
    }
    
    public char readChar() {
      this.f += 2;
      return this.c.readChar();
    }
    
    public double readDouble() {
      return Double.longBitsToDouble(readLong());
    }
    
    public float readFloat() {
      return Float.intBitsToFloat(readInt());
    }
    
    public void readFully(byte[] param1ArrayOfbyte) {
      this.f += param1ArrayOfbyte.length;
      if (this.f <= this.e) {
        if (this.c.read(param1ArrayOfbyte, 0, param1ArrayOfbyte.length) == param1ArrayOfbyte.length)
          return; 
        throw new IOException("Couldn't read up to the length of buffer");
      } 
      throw new EOFException();
    }
    
    public void readFully(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      this.f += param1Int2;
      if (this.f <= this.e) {
        if (this.c.read(param1ArrayOfbyte, param1Int1, param1Int2) == param1Int2)
          return; 
        throw new IOException("Couldn't read up to the length of buffer");
      } 
      throw new EOFException();
    }
    
    public int readInt() {
      this.f += 4;
      if (this.f <= this.e) {
        int i = this.c.read();
        int k = this.c.read();
        int j = this.c.read();
        int m = this.c.read();
        if ((i | k | j | m) >= 0) {
          ByteOrder byteOrder = this.d;
          if (byteOrder == g)
            return (m << 24) + (j << 16) + (k << 8) + i; 
          if (byteOrder == h)
            return (i << 24) + (k << 16) + (j << 8) + m; 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid byte order: ");
          stringBuilder.append(this.d);
          throw new IOException(stringBuilder.toString());
        } 
        throw new EOFException();
      } 
      throw new EOFException();
    }
    
    public String readLine() {
      Log.d("ExifInterface", "Currently unsupported");
      return null;
    }
    
    public long readLong() {
      this.f += 8;
      if (this.f <= this.e) {
        int n = this.c.read();
        int j = this.c.read();
        int i1 = this.c.read();
        int i2 = this.c.read();
        int k = this.c.read();
        int i3 = this.c.read();
        int i = this.c.read();
        int m = this.c.read();
        if ((n | j | i1 | i2 | k | i3 | i | m) >= 0) {
          ByteOrder byteOrder = this.d;
          if (byteOrder == g)
            return (m << 56L) + (i << 48L) + (i3 << 40L) + (k << 32L) + (i2 << 24L) + (i1 << 16L) + (j << 8L) + n; 
          if (byteOrder == h)
            return (n << 56L) + (j << 48L) + (i1 << 40L) + (i2 << 32L) + (k << 24L) + (i3 << 16L) + (i << 8L) + m; 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid byte order: ");
          stringBuilder.append(this.d);
          throw new IOException(stringBuilder.toString());
        } 
        throw new EOFException();
      } 
      throw new EOFException();
    }
    
    public short readShort() {
      this.f += 2;
      if (this.f <= this.e) {
        int i = this.c.read();
        int j = this.c.read();
        if ((i | j) >= 0) {
          ByteOrder byteOrder = this.d;
          if (byteOrder == g)
            return (short)((j << 8) + i); 
          if (byteOrder == h)
            return (short)((i << 8) + j); 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid byte order: ");
          stringBuilder.append(this.d);
          throw new IOException(stringBuilder.toString());
        } 
        throw new EOFException();
      } 
      throw new EOFException();
    }
    
    public String readUTF() {
      this.f += 2;
      return this.c.readUTF();
    }
    
    public int readUnsignedByte() {
      this.f++;
      return this.c.readUnsignedByte();
    }
    
    public int readUnsignedShort() {
      this.f += 2;
      if (this.f <= this.e) {
        int j = this.c.read();
        int i = this.c.read();
        if ((j | i) >= 0) {
          ByteOrder byteOrder = this.d;
          if (byteOrder == g)
            return (i << 8) + j; 
          if (byteOrder == h)
            return (j << 8) + i; 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid byte order: ");
          stringBuilder.append(this.d);
          throw new IOException(stringBuilder.toString());
        } 
        throw new EOFException();
      } 
      throw new EOFException();
    }
    
    public int skipBytes(int param1Int) {
      int i = Math.min(param1Int, this.e - this.f);
      for (param1Int = 0; param1Int < i; param1Int += this.c.skipBytes(i - param1Int));
      this.f += param1Int;
      return param1Int;
    }
  }
  
  private static class c {
    public final int a;
    
    public final int b;
    
    public final byte[] c;
    
    private c(int param1Int1, int param1Int2, byte[] param1ArrayOfbyte) {
      this.a = param1Int1;
      this.b = param1Int2;
      this.c = param1ArrayOfbyte;
    }
    
    public static c a(int param1Int, ByteOrder param1ByteOrder) {
      return a(new int[] { param1Int }, param1ByteOrder);
    }
    
    public static c a(long param1Long, ByteOrder param1ByteOrder) {
      return a(new long[] { param1Long }, param1ByteOrder);
    }
    
    public static c a(a.e param1e, ByteOrder param1ByteOrder) {
      return a(new a.e[] { param1e }, param1ByteOrder);
    }
    
    public static c a(String param1String) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(param1String);
      stringBuilder.append(false);
      byte[] arrayOfByte = stringBuilder.toString().getBytes(a.a());
      return new c(2, arrayOfByte.length, arrayOfByte);
    }
    
    public static c a(int[] param1ArrayOfint, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[a.s[3] * param1ArrayOfint.length]);
      byteBuffer.order(param1ByteOrder);
      int i = param1ArrayOfint.length;
      for (byte b = 0; b < i; b++)
        byteBuffer.putShort((short)param1ArrayOfint[b]); 
      return new c(3, param1ArrayOfint.length, byteBuffer.array());
    }
    
    public static c a(long[] param1ArrayOflong, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[a.s[4] * param1ArrayOflong.length]);
      byteBuffer.order(param1ByteOrder);
      int i = param1ArrayOflong.length;
      for (byte b = 0; b < i; b++)
        byteBuffer.putInt((int)param1ArrayOflong[b]); 
      return new c(4, param1ArrayOflong.length, byteBuffer.array());
    }
    
    public static c a(a.e[] param1ArrayOfe, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[a.s[5] * param1ArrayOfe.length]);
      byteBuffer.order(param1ByteOrder);
      int i = param1ArrayOfe.length;
      for (byte b = 0; b < i; b++) {
        a.e e1 = param1ArrayOfe[b];
        byteBuffer.putInt((int)e1.a);
        byteBuffer.putInt((int)e1.b);
      } 
      return new c(5, param1ArrayOfe.length, byteBuffer.array());
    }
    
    private Object d(ByteOrder param1ByteOrder) {
      // Byte code:
      //   0: aconst_null
      //   1: astore #7
      //   3: aconst_null
      //   4: astore #6
      //   6: new a/b/e/a$b
      //   9: astore #8
      //   11: aload #8
      //   13: aload_0
      //   14: getfield c : [B
      //   17: invokespecial <init> : ([B)V
      //   20: aload #8
      //   22: astore #7
      //   24: aload #7
      //   26: astore #6
      //   28: aload #7
      //   30: aload_1
      //   31: invokevirtual a : (Ljava/nio/ByteOrder;)V
      //   34: aload #7
      //   36: astore #6
      //   38: aload_0
      //   39: getfield a : I
      //   42: istore_2
      //   43: iconst_0
      //   44: istore_3
      //   45: iload_2
      //   46: tableswitch default -> 108, 1 -> 862, 2 -> 662, 3 -> 597, 4 -> 532, 5 -> 453, 6 -> 862, 7 -> 662, 8 -> 388, 9 -> 323, 10 -> 242, 11 -> 176, 12 -> 111
      //   108: goto -> 993
      //   111: aload #7
      //   113: astore #6
      //   115: aload_0
      //   116: getfield b : I
      //   119: newarray double
      //   121: astore_1
      //   122: iconst_0
      //   123: istore_2
      //   124: aload #7
      //   126: astore #6
      //   128: iload_2
      //   129: aload_0
      //   130: getfield b : I
      //   133: if_icmpge -> 154
      //   136: aload #7
      //   138: astore #6
      //   140: aload_1
      //   141: iload_2
      //   142: aload #7
      //   144: invokevirtual readDouble : ()D
      //   147: dastore
      //   148: iinc #2, 1
      //   151: goto -> 124
      //   154: aload #7
      //   156: invokevirtual close : ()V
      //   159: goto -> 174
      //   162: astore #6
      //   164: ldc 'ExifInterface'
      //   166: ldc 'IOException occurred while closing InputStream'
      //   168: aload #6
      //   170: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   173: pop
      //   174: aload_1
      //   175: areturn
      //   176: aload #7
      //   178: astore #6
      //   180: aload_0
      //   181: getfield b : I
      //   184: newarray double
      //   186: astore_1
      //   187: iconst_0
      //   188: istore_2
      //   189: aload #7
      //   191: astore #6
      //   193: iload_2
      //   194: aload_0
      //   195: getfield b : I
      //   198: if_icmpge -> 220
      //   201: aload #7
      //   203: astore #6
      //   205: aload_1
      //   206: iload_2
      //   207: aload #7
      //   209: invokevirtual readFloat : ()F
      //   212: f2d
      //   213: dastore
      //   214: iinc #2, 1
      //   217: goto -> 189
      //   220: aload #7
      //   222: invokevirtual close : ()V
      //   225: goto -> 240
      //   228: astore #6
      //   230: ldc 'ExifInterface'
      //   232: ldc 'IOException occurred while closing InputStream'
      //   234: aload #6
      //   236: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   239: pop
      //   240: aload_1
      //   241: areturn
      //   242: aload #7
      //   244: astore #6
      //   246: aload_0
      //   247: getfield b : I
      //   250: anewarray a/b/e/a$e
      //   253: astore_1
      //   254: iconst_0
      //   255: istore_2
      //   256: aload #7
      //   258: astore #6
      //   260: iload_2
      //   261: aload_0
      //   262: getfield b : I
      //   265: if_icmpge -> 301
      //   268: aload #7
      //   270: astore #6
      //   272: aload_1
      //   273: iload_2
      //   274: new a/b/e/a$e
      //   277: dup
      //   278: aload #7
      //   280: invokevirtual readInt : ()I
      //   283: i2l
      //   284: aload #7
      //   286: invokevirtual readInt : ()I
      //   289: i2l
      //   290: aconst_null
      //   291: invokespecial <init> : (JJLa/b/e/a$a;)V
      //   294: aastore
      //   295: iinc #2, 1
      //   298: goto -> 256
      //   301: aload #7
      //   303: invokevirtual close : ()V
      //   306: goto -> 321
      //   309: astore #6
      //   311: ldc 'ExifInterface'
      //   313: ldc 'IOException occurred while closing InputStream'
      //   315: aload #6
      //   317: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   320: pop
      //   321: aload_1
      //   322: areturn
      //   323: aload #7
      //   325: astore #6
      //   327: aload_0
      //   328: getfield b : I
      //   331: newarray int
      //   333: astore_1
      //   334: iconst_0
      //   335: istore_2
      //   336: aload #7
      //   338: astore #6
      //   340: iload_2
      //   341: aload_0
      //   342: getfield b : I
      //   345: if_icmpge -> 366
      //   348: aload #7
      //   350: astore #6
      //   352: aload_1
      //   353: iload_2
      //   354: aload #7
      //   356: invokevirtual readInt : ()I
      //   359: iastore
      //   360: iinc #2, 1
      //   363: goto -> 336
      //   366: aload #7
      //   368: invokevirtual close : ()V
      //   371: goto -> 386
      //   374: astore #6
      //   376: ldc 'ExifInterface'
      //   378: ldc 'IOException occurred while closing InputStream'
      //   380: aload #6
      //   382: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   385: pop
      //   386: aload_1
      //   387: areturn
      //   388: aload #7
      //   390: astore #6
      //   392: aload_0
      //   393: getfield b : I
      //   396: newarray int
      //   398: astore_1
      //   399: iconst_0
      //   400: istore_2
      //   401: aload #7
      //   403: astore #6
      //   405: iload_2
      //   406: aload_0
      //   407: getfield b : I
      //   410: if_icmpge -> 431
      //   413: aload #7
      //   415: astore #6
      //   417: aload_1
      //   418: iload_2
      //   419: aload #7
      //   421: invokevirtual readShort : ()S
      //   424: iastore
      //   425: iinc #2, 1
      //   428: goto -> 401
      //   431: aload #7
      //   433: invokevirtual close : ()V
      //   436: goto -> 451
      //   439: astore #6
      //   441: ldc 'ExifInterface'
      //   443: ldc 'IOException occurred while closing InputStream'
      //   445: aload #6
      //   447: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   450: pop
      //   451: aload_1
      //   452: areturn
      //   453: aload #7
      //   455: astore #6
      //   457: aload_0
      //   458: getfield b : I
      //   461: anewarray a/b/e/a$e
      //   464: astore_1
      //   465: iconst_0
      //   466: istore_2
      //   467: aload #7
      //   469: astore #6
      //   471: iload_2
      //   472: aload_0
      //   473: getfield b : I
      //   476: if_icmpge -> 510
      //   479: aload #7
      //   481: astore #6
      //   483: aload_1
      //   484: iload_2
      //   485: new a/b/e/a$e
      //   488: dup
      //   489: aload #7
      //   491: invokevirtual m : ()J
      //   494: aload #7
      //   496: invokevirtual m : ()J
      //   499: aconst_null
      //   500: invokespecial <init> : (JJLa/b/e/a$a;)V
      //   503: aastore
      //   504: iinc #2, 1
      //   507: goto -> 467
      //   510: aload #7
      //   512: invokevirtual close : ()V
      //   515: goto -> 530
      //   518: astore #6
      //   520: ldc 'ExifInterface'
      //   522: ldc 'IOException occurred while closing InputStream'
      //   524: aload #6
      //   526: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   529: pop
      //   530: aload_1
      //   531: areturn
      //   532: aload #7
      //   534: astore #6
      //   536: aload_0
      //   537: getfield b : I
      //   540: newarray long
      //   542: astore_1
      //   543: iconst_0
      //   544: istore_2
      //   545: aload #7
      //   547: astore #6
      //   549: iload_2
      //   550: aload_0
      //   551: getfield b : I
      //   554: if_icmpge -> 575
      //   557: aload #7
      //   559: astore #6
      //   561: aload_1
      //   562: iload_2
      //   563: aload #7
      //   565: invokevirtual m : ()J
      //   568: lastore
      //   569: iinc #2, 1
      //   572: goto -> 545
      //   575: aload #7
      //   577: invokevirtual close : ()V
      //   580: goto -> 595
      //   583: astore #6
      //   585: ldc 'ExifInterface'
      //   587: ldc 'IOException occurred while closing InputStream'
      //   589: aload #6
      //   591: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   594: pop
      //   595: aload_1
      //   596: areturn
      //   597: aload #7
      //   599: astore #6
      //   601: aload_0
      //   602: getfield b : I
      //   605: newarray int
      //   607: astore_1
      //   608: iconst_0
      //   609: istore_2
      //   610: aload #7
      //   612: astore #6
      //   614: iload_2
      //   615: aload_0
      //   616: getfield b : I
      //   619: if_icmpge -> 640
      //   622: aload #7
      //   624: astore #6
      //   626: aload_1
      //   627: iload_2
      //   628: aload #7
      //   630: invokevirtual readUnsignedShort : ()I
      //   633: iastore
      //   634: iinc #2, 1
      //   637: goto -> 610
      //   640: aload #7
      //   642: invokevirtual close : ()V
      //   645: goto -> 660
      //   648: astore #6
      //   650: ldc 'ExifInterface'
      //   652: ldc 'IOException occurred while closing InputStream'
      //   654: aload #6
      //   656: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   659: pop
      //   660: aload_1
      //   661: areturn
      //   662: iconst_0
      //   663: istore #4
      //   665: iload #4
      //   667: istore_2
      //   668: aload #7
      //   670: astore #6
      //   672: aload_0
      //   673: getfield b : I
      //   676: invokestatic b : ()[B
      //   679: arraylength
      //   680: if_icmplt -> 748
      //   683: iconst_1
      //   684: istore #5
      //   686: iload_3
      //   687: istore_2
      //   688: iload #5
      //   690: istore_3
      //   691: aload #7
      //   693: astore #6
      //   695: iload_2
      //   696: invokestatic b : ()[B
      //   699: arraylength
      //   700: if_icmpge -> 732
      //   703: aload #7
      //   705: astore #6
      //   707: aload_0
      //   708: getfield c : [B
      //   711: iload_2
      //   712: baload
      //   713: invokestatic b : ()[B
      //   716: iload_2
      //   717: baload
      //   718: if_icmpeq -> 726
      //   721: iconst_0
      //   722: istore_3
      //   723: goto -> 732
      //   726: iinc #2, 1
      //   729: goto -> 688
      //   732: iload #4
      //   734: istore_2
      //   735: iload_3
      //   736: ifeq -> 748
      //   739: aload #7
      //   741: astore #6
      //   743: invokestatic b : ()[B
      //   746: arraylength
      //   747: istore_2
      //   748: aload #7
      //   750: astore #6
      //   752: new java/lang/StringBuilder
      //   755: astore_1
      //   756: aload #7
      //   758: astore #6
      //   760: aload_1
      //   761: invokespecial <init> : ()V
      //   764: aload #7
      //   766: astore #6
      //   768: iload_2
      //   769: aload_0
      //   770: getfield b : I
      //   773: if_icmpge -> 831
      //   776: aload #7
      //   778: astore #6
      //   780: aload_0
      //   781: getfield c : [B
      //   784: iload_2
      //   785: baload
      //   786: istore_3
      //   787: iload_3
      //   788: ifne -> 794
      //   791: goto -> 831
      //   794: iload_3
      //   795: bipush #32
      //   797: if_icmplt -> 814
      //   800: aload #7
      //   802: astore #6
      //   804: aload_1
      //   805: iload_3
      //   806: i2c
      //   807: invokevirtual append : (C)Ljava/lang/StringBuilder;
      //   810: pop
      //   811: goto -> 825
      //   814: aload #7
      //   816: astore #6
      //   818: aload_1
      //   819: bipush #63
      //   821: invokevirtual append : (C)Ljava/lang/StringBuilder;
      //   824: pop
      //   825: iinc #2, 1
      //   828: goto -> 764
      //   831: aload #7
      //   833: astore #6
      //   835: aload_1
      //   836: invokevirtual toString : ()Ljava/lang/String;
      //   839: astore_1
      //   840: aload #7
      //   842: invokevirtual close : ()V
      //   845: goto -> 860
      //   848: astore #6
      //   850: ldc 'ExifInterface'
      //   852: ldc 'IOException occurred while closing InputStream'
      //   854: aload #6
      //   856: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   859: pop
      //   860: aload_1
      //   861: areturn
      //   862: aload #7
      //   864: astore #6
      //   866: aload_0
      //   867: getfield c : [B
      //   870: arraylength
      //   871: iconst_1
      //   872: if_icmpne -> 952
      //   875: aload #7
      //   877: astore #6
      //   879: aload_0
      //   880: getfield c : [B
      //   883: iconst_0
      //   884: baload
      //   885: iflt -> 952
      //   888: aload #7
      //   890: astore #6
      //   892: aload_0
      //   893: getfield c : [B
      //   896: iconst_0
      //   897: baload
      //   898: iconst_1
      //   899: if_icmpgt -> 952
      //   902: aload #7
      //   904: astore #6
      //   906: new java/lang/String
      //   909: dup
      //   910: iconst_1
      //   911: newarray char
      //   913: dup
      //   914: iconst_0
      //   915: aload_0
      //   916: getfield c : [B
      //   919: iconst_0
      //   920: baload
      //   921: bipush #48
      //   923: iadd
      //   924: i2c
      //   925: castore
      //   926: invokespecial <init> : ([C)V
      //   929: astore_1
      //   930: aload #7
      //   932: invokevirtual close : ()V
      //   935: goto -> 950
      //   938: astore #6
      //   940: ldc 'ExifInterface'
      //   942: ldc 'IOException occurred while closing InputStream'
      //   944: aload #6
      //   946: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   949: pop
      //   950: aload_1
      //   951: areturn
      //   952: aload #7
      //   954: astore #6
      //   956: new java/lang/String
      //   959: dup
      //   960: aload_0
      //   961: getfield c : [B
      //   964: invokestatic a : ()Ljava/nio/charset/Charset;
      //   967: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
      //   970: astore_1
      //   971: aload #7
      //   973: invokevirtual close : ()V
      //   976: goto -> 991
      //   979: astore #6
      //   981: ldc 'ExifInterface'
      //   983: ldc 'IOException occurred while closing InputStream'
      //   985: aload #6
      //   987: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   990: pop
      //   991: aload_1
      //   992: areturn
      //   993: aload #7
      //   995: invokevirtual close : ()V
      //   998: goto -> 1011
      //   1001: astore_1
      //   1002: ldc 'ExifInterface'
      //   1004: ldc 'IOException occurred while closing InputStream'
      //   1006: aload_1
      //   1007: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   1010: pop
      //   1011: aconst_null
      //   1012: areturn
      //   1013: astore_1
      //   1014: goto -> 1022
      //   1017: astore_1
      //   1018: goto -> 1064
      //   1021: astore_1
      //   1022: aload #7
      //   1024: astore #6
      //   1026: ldc 'ExifInterface'
      //   1028: ldc 'IOException occurred during reading a value'
      //   1030: aload_1
      //   1031: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   1034: pop
      //   1035: aload #7
      //   1037: ifnull -> 1058
      //   1040: aload #7
      //   1042: invokevirtual close : ()V
      //   1045: goto -> 1058
      //   1048: astore_1
      //   1049: ldc 'ExifInterface'
      //   1051: ldc 'IOException occurred while closing InputStream'
      //   1053: aload_1
      //   1054: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   1057: pop
      //   1058: aconst_null
      //   1059: areturn
      //   1060: astore_1
      //   1061: goto -> 1018
      //   1064: aload #6
      //   1066: ifnull -> 1089
      //   1069: aload #6
      //   1071: invokevirtual close : ()V
      //   1074: goto -> 1089
      //   1077: astore #6
      //   1079: ldc 'ExifInterface'
      //   1081: ldc 'IOException occurred while closing InputStream'
      //   1083: aload #6
      //   1085: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   1088: pop
      //   1089: goto -> 1094
      //   1092: aload_1
      //   1093: athrow
      //   1094: goto -> 1092
      // Exception table:
      //   from	to	target	type
      //   6	20	1021	java/io/IOException
      //   6	20	1017	finally
      //   28	34	1013	java/io/IOException
      //   28	34	1060	finally
      //   38	43	1013	java/io/IOException
      //   38	43	1060	finally
      //   115	122	1013	java/io/IOException
      //   115	122	1060	finally
      //   128	136	1013	java/io/IOException
      //   128	136	1060	finally
      //   140	148	1013	java/io/IOException
      //   140	148	1060	finally
      //   154	159	162	java/io/IOException
      //   180	187	1013	java/io/IOException
      //   180	187	1060	finally
      //   193	201	1013	java/io/IOException
      //   193	201	1060	finally
      //   205	214	1013	java/io/IOException
      //   205	214	1060	finally
      //   220	225	228	java/io/IOException
      //   246	254	1013	java/io/IOException
      //   246	254	1060	finally
      //   260	268	1013	java/io/IOException
      //   260	268	1060	finally
      //   272	295	1013	java/io/IOException
      //   272	295	1060	finally
      //   301	306	309	java/io/IOException
      //   327	334	1013	java/io/IOException
      //   327	334	1060	finally
      //   340	348	1013	java/io/IOException
      //   340	348	1060	finally
      //   352	360	1013	java/io/IOException
      //   352	360	1060	finally
      //   366	371	374	java/io/IOException
      //   392	399	1013	java/io/IOException
      //   392	399	1060	finally
      //   405	413	1013	java/io/IOException
      //   405	413	1060	finally
      //   417	425	1013	java/io/IOException
      //   417	425	1060	finally
      //   431	436	439	java/io/IOException
      //   457	465	1013	java/io/IOException
      //   457	465	1060	finally
      //   471	479	1013	java/io/IOException
      //   471	479	1060	finally
      //   483	504	1013	java/io/IOException
      //   483	504	1060	finally
      //   510	515	518	java/io/IOException
      //   536	543	1013	java/io/IOException
      //   536	543	1060	finally
      //   549	557	1013	java/io/IOException
      //   549	557	1060	finally
      //   561	569	1013	java/io/IOException
      //   561	569	1060	finally
      //   575	580	583	java/io/IOException
      //   601	608	1013	java/io/IOException
      //   601	608	1060	finally
      //   614	622	1013	java/io/IOException
      //   614	622	1060	finally
      //   626	634	1013	java/io/IOException
      //   626	634	1060	finally
      //   640	645	648	java/io/IOException
      //   672	683	1013	java/io/IOException
      //   672	683	1060	finally
      //   695	703	1013	java/io/IOException
      //   695	703	1060	finally
      //   707	721	1013	java/io/IOException
      //   707	721	1060	finally
      //   743	748	1013	java/io/IOException
      //   743	748	1060	finally
      //   752	756	1013	java/io/IOException
      //   752	756	1060	finally
      //   760	764	1013	java/io/IOException
      //   760	764	1060	finally
      //   768	776	1013	java/io/IOException
      //   768	776	1060	finally
      //   780	787	1013	java/io/IOException
      //   780	787	1060	finally
      //   804	811	1013	java/io/IOException
      //   804	811	1060	finally
      //   818	825	1013	java/io/IOException
      //   818	825	1060	finally
      //   835	840	1013	java/io/IOException
      //   835	840	1060	finally
      //   840	845	848	java/io/IOException
      //   866	875	1013	java/io/IOException
      //   866	875	1060	finally
      //   879	888	1013	java/io/IOException
      //   879	888	1060	finally
      //   892	902	1013	java/io/IOException
      //   892	902	1060	finally
      //   906	930	1013	java/io/IOException
      //   906	930	1060	finally
      //   930	935	938	java/io/IOException
      //   956	971	1013	java/io/IOException
      //   956	971	1060	finally
      //   971	976	979	java/io/IOException
      //   993	998	1001	java/io/IOException
      //   1026	1035	1060	finally
      //   1040	1045	1048	java/io/IOException
      //   1069	1074	1077	java/io/IOException
    }
    
    public double a(ByteOrder param1ByteOrder) {
      Object object = d(param1ByteOrder);
      if (object != null) {
        if (object instanceof String)
          return Double.parseDouble((String)object); 
        if (object instanceof long[]) {
          object = object;
          if (object.length == 1)
            return object[0]; 
          throw new NumberFormatException("There are more than one component");
        } 
        if (object instanceof int[]) {
          object = object;
          if (object.length == 1)
            return object[0]; 
          throw new NumberFormatException("There are more than one component");
        } 
        if (object instanceof double[]) {
          object = object;
          if (object.length == 1)
            return object[0]; 
          throw new NumberFormatException("There are more than one component");
        } 
        if (object instanceof a.e[]) {
          object = object;
          if (object.length == 1)
            return object[0].a(); 
          throw new NumberFormatException("There are more than one component");
        } 
        throw new NumberFormatException("Couldn't find a double value");
      } 
      throw new NumberFormatException("NULL can't be converted to a double value");
    }
    
    public int b(ByteOrder param1ByteOrder) {
      Object object = d(param1ByteOrder);
      if (object != null) {
        if (object instanceof String)
          return Integer.parseInt((String)object); 
        if (object instanceof long[]) {
          object = object;
          if (object.length == 1)
            return (int)object[0]; 
          throw new NumberFormatException("There are more than one component");
        } 
        if (object instanceof int[]) {
          object = object;
          if (object.length == 1)
            return object[0]; 
          throw new NumberFormatException("There are more than one component");
        } 
        throw new NumberFormatException("Couldn't find a integer value");
      } 
      throw new NumberFormatException("NULL can't be converted to a integer value");
    }
    
    public String c(ByteOrder param1ByteOrder) {
      Object object = d(param1ByteOrder);
      if (object == null)
        return null; 
      if (object instanceof String)
        return (String)object; 
      StringBuilder stringBuilder = new StringBuilder();
      if (object instanceof long[]) {
        object = object;
        for (byte b = 0; b < object.length; b++) {
          stringBuilder.append(object[b]);
          if (b + 1 != object.length)
            stringBuilder.append(","); 
        } 
        return stringBuilder.toString();
      } 
      if (object instanceof int[]) {
        object = object;
        for (byte b = 0; b < object.length; b++) {
          stringBuilder.append(object[b]);
          if (b + 1 != object.length)
            stringBuilder.append(","); 
        } 
        return stringBuilder.toString();
      } 
      if (object instanceof double[]) {
        object = object;
        for (byte b = 0; b < object.length; b++) {
          stringBuilder.append(object[b]);
          if (b + 1 != object.length)
            stringBuilder.append(","); 
        } 
        return stringBuilder.toString();
      } 
      if (object instanceof a.e[]) {
        object = object;
        for (byte b = 0; b < object.length; b++) {
          stringBuilder.append(((a.e)object[b]).a);
          stringBuilder.append('/');
          stringBuilder.append(((a.e)object[b]).b);
          if (b + 1 != object.length)
            stringBuilder.append(","); 
        } 
        return stringBuilder.toString();
      } 
      return null;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("(");
      stringBuilder.append(a.r[this.a]);
      stringBuilder.append(", data length:");
      stringBuilder.append(this.c.length);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  static class d {
    public final int a;
    
    public final String b;
    
    public final int c;
    
    public final int d;
    
    private d(String param1String, int param1Int1, int param1Int2) {
      this.b = param1String;
      this.a = param1Int1;
      this.c = param1Int2;
      this.d = -1;
    }
    
    private d(String param1String, int param1Int1, int param1Int2, int param1Int3) {
      this.b = param1String;
      this.a = param1Int1;
      this.c = param1Int2;
      this.d = param1Int3;
    }
    
    private boolean a(int param1Int) {
      int i = this.c;
      if (i == 7 || param1Int == 7)
        return true; 
      if (i != param1Int) {
        int j = this.d;
        if (j != param1Int)
          return ((i == 4 || j == 4) && param1Int == 3) ? true : (((this.c == 9 || this.d == 9) && param1Int == 8) ? true : (((this.c == 12 || this.d == 12) && param1Int == 11))); 
      } 
      return true;
    }
  }
  
  private static class e {
    public final long a;
    
    public final long b;
    
    private e(long param1Long1, long param1Long2) {
      if (param1Long2 == 0L) {
        this.a = 0L;
        this.b = 1L;
        return;
      } 
      this.a = param1Long1;
      this.b = param1Long2;
    }
    
    public double a() {
      double d1 = this.a;
      double d2 = this.b;
      Double.isNaN(d1);
      Double.isNaN(d2);
      return d1 / d2;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.a);
      stringBuilder.append("/");
      stringBuilder.append(this.b);
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\e\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */