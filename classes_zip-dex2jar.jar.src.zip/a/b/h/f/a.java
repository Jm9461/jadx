package a.b.h.f;

import a.b.h.a.b;
import a.b.h.a.d;
import a.b.h.a.j;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Build;
import android.view.ViewConfiguration;

public class a {
  private Context a;
  
  private a(Context paramContext) {
    this.a = paramContext;
  }
  
  public static a a(Context paramContext) {
    return new a(paramContext);
  }
  
  public boolean a() {
    boolean bool;
    if ((this.a.getApplicationInfo()).targetSdkVersion < 14) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int b() {
    return (this.a.getResources().getDisplayMetrics()).widthPixels / 2;
  }
  
  public int c() {
    Configuration configuration = this.a.getResources().getConfiguration();
    int j = configuration.screenWidthDp;
    int i = configuration.screenHeightDp;
    return (configuration.smallestScreenWidthDp > 600 || j > 600 || (j > 960 && i > 720) || (j > 720 && i > 960)) ? 5 : ((j >= 500 || (j > 640 && i > 480) || (j > 480 && i > 640)) ? 4 : ((j >= 360) ? 3 : 2));
  }
  
  public int d() {
    return this.a.getResources().getDimensionPixelSize(d.abc_action_bar_stacked_tab_max_width);
  }
  
  public int e() {
    TypedArray typedArray = this.a.obtainStyledAttributes(null, j.ActionBar, a.b.h.a.a.actionBarStyle, 0);
    int j = typedArray.getLayoutDimension(j.ActionBar_height, 0);
    Resources resources = this.a.getResources();
    int i = j;
    if (!f())
      i = Math.min(j, resources.getDimensionPixelSize(d.abc_action_bar_stacked_max_height)); 
    typedArray.recycle();
    return i;
  }
  
  public boolean f() {
    return this.a.getResources().getBoolean(b.abc_action_bar_embed_tabs);
  }
  
  public boolean g() {
    return (Build.VERSION.SDK_INT >= 19) ? true : (ViewConfiguration.get(this.a).hasPermanentMenuKey() ^ true);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\h\f\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */