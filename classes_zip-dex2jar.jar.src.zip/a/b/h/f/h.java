package a.b.h.f;

import android.support.v4.view.a0;
import android.support.v4.view.y;
import android.support.v4.view.z;
import android.view.View;
import android.view.animation.Interpolator;
import java.util.ArrayList;
import java.util.Iterator;

public class h {
  final ArrayList<y> a = new ArrayList<y>();
  
  private long b = -1L;
  
  private Interpolator c;
  
  z d;
  
  private boolean e;
  
  private final a0 f = new a(this);
  
  public h a(long paramLong) {
    if (!this.e)
      this.b = paramLong; 
    return this;
  }
  
  public h a(y paramy) {
    if (!this.e)
      this.a.add(paramy); 
    return this;
  }
  
  public h a(y paramy1, y paramy2) {
    this.a.add(paramy1);
    paramy2.b(paramy1.b());
    this.a.add(paramy2);
    return this;
  }
  
  public h a(z paramz) {
    if (!this.e)
      this.d = paramz; 
    return this;
  }
  
  public h a(Interpolator paramInterpolator) {
    if (!this.e)
      this.c = paramInterpolator; 
    return this;
  }
  
  public void a() {
    if (!this.e)
      return; 
    Iterator<y> iterator = this.a.iterator();
    while (iterator.hasNext())
      ((y)iterator.next()).a(); 
    this.e = false;
  }
  
  void b() {
    this.e = false;
  }
  
  public void c() {
    if (this.e)
      return; 
    for (y y : this.a) {
      long l = this.b;
      if (l >= 0L)
        y.a(l); 
      Interpolator interpolator = this.c;
      if (interpolator != null)
        y.a(interpolator); 
      if (this.d != null)
        y.a((z)this.f); 
      y.c();
    } 
    this.e = true;
  }
  
  class a extends a0 {
    private boolean a = false;
    
    private int b = 0;
    
    final h c;
    
    a(h this$0) {}
    
    void a() {
      this.b = 0;
      this.a = false;
      this.c.b();
    }
    
    public void a(View param1View) {
      int i = this.b + 1;
      this.b = i;
      if (i == this.c.a.size()) {
        z z = this.c.d;
        if (z != null)
          z.a(null); 
        a();
      } 
    }
    
    public void b(View param1View) {
      if (this.a)
        return; 
      this.a = true;
      z z = this.c.d;
      if (z != null)
        z.b(null); 
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\h\f\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */