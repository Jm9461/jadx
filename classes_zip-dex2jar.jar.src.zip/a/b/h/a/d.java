package a.b.h.a;

public final class d {
  public static final int abc_action_bar_content_inset_material = 2131165187;
  
  public static final int abc_action_bar_content_inset_with_nav = 2131165188;
  
  public static final int abc_action_bar_default_height_material = 2131165189;
  
  public static final int abc_action_bar_default_padding_end_material = 2131165190;
  
  public static final int abc_action_bar_default_padding_start_material = 2131165191;
  
  public static final int abc_action_bar_elevation_material = 2131165192;
  
  public static final int abc_action_bar_icon_vertical_padding_material = 2131165193;
  
  public static final int abc_action_bar_overflow_padding_end_material = 2131165194;
  
  public static final int abc_action_bar_overflow_padding_start_material = 2131165195;
  
  public static final int abc_action_bar_stacked_max_height = 2131165196;
  
  public static final int abc_action_bar_stacked_tab_max_width = 2131165197;
  
  public static final int abc_action_bar_subtitle_bottom_margin_material = 2131165198;
  
  public static final int abc_action_bar_subtitle_top_margin_material = 2131165199;
  
  public static final int abc_action_button_min_height_material = 2131165200;
  
  public static final int abc_action_button_min_width_material = 2131165201;
  
  public static final int abc_action_button_min_width_overflow_material = 2131165202;
  
  public static final int abc_alert_dialog_button_bar_height = 2131165203;
  
  public static final int abc_alert_dialog_button_dimen = 2131165204;
  
  public static final int abc_button_inset_horizontal_material = 2131165205;
  
  public static final int abc_button_inset_vertical_material = 2131165206;
  
  public static final int abc_button_padding_horizontal_material = 2131165207;
  
  public static final int abc_button_padding_vertical_material = 2131165208;
  
  public static final int abc_cascading_menus_min_smallest_width = 2131165209;
  
  public static final int abc_config_prefDialogWidth = 2131165210;
  
  public static final int abc_control_corner_material = 2131165211;
  
  public static final int abc_control_inset_material = 2131165212;
  
  public static final int abc_control_padding_material = 2131165213;
  
  public static final int abc_dialog_corner_radius_material = 2131165214;
  
  public static final int abc_dialog_fixed_height_major = 2131165215;
  
  public static final int abc_dialog_fixed_height_minor = 2131165216;
  
  public static final int abc_dialog_fixed_width_major = 2131165217;
  
  public static final int abc_dialog_fixed_width_minor = 2131165218;
  
  public static final int abc_dialog_list_padding_bottom_no_buttons = 2131165219;
  
  public static final int abc_dialog_list_padding_top_no_title = 2131165220;
  
  public static final int abc_dialog_min_width_major = 2131165221;
  
  public static final int abc_dialog_min_width_minor = 2131165222;
  
  public static final int abc_dialog_padding_material = 2131165223;
  
  public static final int abc_dialog_padding_top_material = 2131165224;
  
  public static final int abc_dialog_title_divider_material = 2131165225;
  
  public static final int abc_disabled_alpha_material_dark = 2131165226;
  
  public static final int abc_disabled_alpha_material_light = 2131165227;
  
  public static final int abc_dropdownitem_icon_width = 2131165228;
  
  public static final int abc_dropdownitem_text_padding_left = 2131165229;
  
  public static final int abc_dropdownitem_text_padding_right = 2131165230;
  
  public static final int abc_edit_text_inset_bottom_material = 2131165231;
  
  public static final int abc_edit_text_inset_horizontal_material = 2131165232;
  
  public static final int abc_edit_text_inset_top_material = 2131165233;
  
  public static final int abc_floating_window_z = 2131165234;
  
  public static final int abc_list_item_padding_horizontal_material = 2131165235;
  
  public static final int abc_panel_menu_list_width = 2131165236;
  
  public static final int abc_progress_bar_height_material = 2131165237;
  
  public static final int abc_search_view_preferred_height = 2131165238;
  
  public static final int abc_search_view_preferred_width = 2131165239;
  
  public static final int abc_seekbar_track_background_height_material = 2131165240;
  
  public static final int abc_seekbar_track_progress_height_material = 2131165241;
  
  public static final int abc_select_dialog_padding_start_material = 2131165242;
  
  public static final int abc_switch_padding = 2131165243;
  
  public static final int abc_text_size_body_1_material = 2131165244;
  
  public static final int abc_text_size_body_2_material = 2131165245;
  
  public static final int abc_text_size_button_material = 2131165246;
  
  public static final int abc_text_size_caption_material = 2131165247;
  
  public static final int abc_text_size_display_1_material = 2131165248;
  
  public static final int abc_text_size_display_2_material = 2131165249;
  
  public static final int abc_text_size_display_3_material = 2131165250;
  
  public static final int abc_text_size_display_4_material = 2131165251;
  
  public static final int abc_text_size_headline_material = 2131165252;
  
  public static final int abc_text_size_large_material = 2131165253;
  
  public static final int abc_text_size_medium_material = 2131165254;
  
  public static final int abc_text_size_menu_header_material = 2131165255;
  
  public static final int abc_text_size_menu_material = 2131165256;
  
  public static final int abc_text_size_small_material = 2131165257;
  
  public static final int abc_text_size_subhead_material = 2131165258;
  
  public static final int abc_text_size_subtitle_material_toolbar = 2131165259;
  
  public static final int abc_text_size_title_material = 2131165260;
  
  public static final int abc_text_size_title_material_toolbar = 2131165261;
  
  public static final int compat_button_inset_horizontal_material = 2131165301;
  
  public static final int compat_button_inset_vertical_material = 2131165302;
  
  public static final int compat_button_padding_horizontal_material = 2131165303;
  
  public static final int compat_button_padding_vertical_material = 2131165304;
  
  public static final int compat_control_corner_material = 2131165305;
  
  public static final int compat_notification_large_icon_max_height = 2131165306;
  
  public static final int compat_notification_large_icon_max_width = 2131165307;
  
  public static final int disabled_alpha_material_dark = 2131165355;
  
  public static final int disabled_alpha_material_light = 2131165356;
  
  public static final int highlight_alpha_material_colored = 2131165369;
  
  public static final int highlight_alpha_material_dark = 2131165370;
  
  public static final int highlight_alpha_material_light = 2131165371;
  
  public static final int hint_alpha_material_dark = 2131165372;
  
  public static final int hint_alpha_material_light = 2131165373;
  
  public static final int hint_pressed_alpha_material_dark = 2131165374;
  
  public static final int hint_pressed_alpha_material_light = 2131165375;
  
  public static final int notification_action_icon_size = 2131165521;
  
  public static final int notification_action_text_size = 2131165522;
  
  public static final int notification_big_circle_margin = 2131165523;
  
  public static final int notification_content_margin_start = 2131165524;
  
  public static final int notification_large_icon_height = 2131165525;
  
  public static final int notification_large_icon_width = 2131165526;
  
  public static final int notification_main_column_padding_top = 2131165527;
  
  public static final int notification_media_narrow_margin = 2131165528;
  
  public static final int notification_right_icon_size = 2131165529;
  
  public static final int notification_right_side_padding_top = 2131165530;
  
  public static final int notification_small_icon_background_padding = 2131165531;
  
  public static final int notification_small_icon_size_as_large = 2131165532;
  
  public static final int notification_subtext_size = 2131165533;
  
  public static final int notification_top_pad = 2131165534;
  
  public static final int notification_top_pad_large_text = 2131165535;
  
  public static final int tooltip_corner_radius = 2131165544;
  
  public static final int tooltip_horizontal_padding = 2131165545;
  
  public static final int tooltip_margin = 2131165546;
  
  public static final int tooltip_precise_anchor_extra_offset = 2131165547;
  
  public static final int tooltip_precise_anchor_threshold = 2131165548;
  
  public static final int tooltip_vertical_padding = 2131165549;
  
  public static final int tooltip_y_offset_non_touch = 2131165550;
  
  public static final int tooltip_y_offset_touch = 2131165551;
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\h\a\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */