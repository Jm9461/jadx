package a.b.h.a;

public final class h {
  public static final int abc_action_bar_home_description = 2131755024;
  
  public static final int abc_action_bar_up_description = 2131755025;
  
  public static final int abc_action_menu_overflow_description = 2131755026;
  
  public static final int abc_action_mode_done = 2131755027;
  
  public static final int abc_activity_chooser_view_see_all = 2131755028;
  
  public static final int abc_activitychooserview_choose_application = 2131755029;
  
  public static final int abc_capital_off = 2131755030;
  
  public static final int abc_capital_on = 2131755031;
  
  public static final int abc_font_family_body_1_material = 2131755032;
  
  public static final int abc_font_family_body_2_material = 2131755033;
  
  public static final int abc_font_family_button_material = 2131755034;
  
  public static final int abc_font_family_caption_material = 2131755035;
  
  public static final int abc_font_family_display_1_material = 2131755036;
  
  public static final int abc_font_family_display_2_material = 2131755037;
  
  public static final int abc_font_family_display_3_material = 2131755038;
  
  public static final int abc_font_family_display_4_material = 2131755039;
  
  public static final int abc_font_family_headline_material = 2131755040;
  
  public static final int abc_font_family_menu_material = 2131755041;
  
  public static final int abc_font_family_subhead_material = 2131755042;
  
  public static final int abc_font_family_title_material = 2131755043;
  
  public static final int abc_menu_alt_shortcut_label = 2131755044;
  
  public static final int abc_menu_ctrl_shortcut_label = 2131755045;
  
  public static final int abc_menu_delete_shortcut_label = 2131755046;
  
  public static final int abc_menu_enter_shortcut_label = 2131755047;
  
  public static final int abc_menu_function_shortcut_label = 2131755048;
  
  public static final int abc_menu_meta_shortcut_label = 2131755049;
  
  public static final int abc_menu_shift_shortcut_label = 2131755050;
  
  public static final int abc_menu_space_shortcut_label = 2131755051;
  
  public static final int abc_menu_sym_shortcut_label = 2131755052;
  
  public static final int abc_prepend_shortcut_label = 2131755053;
  
  public static final int abc_search_hint = 2131755054;
  
  public static final int abc_searchview_description_clear = 2131755055;
  
  public static final int abc_searchview_description_query = 2131755056;
  
  public static final int abc_searchview_description_search = 2131755057;
  
  public static final int abc_searchview_description_submit = 2131755058;
  
  public static final int abc_searchview_description_voice = 2131755059;
  
  public static final int abc_shareactionprovider_share_with = 2131755060;
  
  public static final int abc_shareactionprovider_share_with_application = 2131755061;
  
  public static final int abc_toolbar_collapse_description = 2131755062;
  
  public static final int search_menu_title = 2131755193;
  
  public static final int status_bar_notification_info_overflow = 2131755195;
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\h\a\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */