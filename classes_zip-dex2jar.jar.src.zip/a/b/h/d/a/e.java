package a.b.h.d.a;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.StateSet;

class e extends b {
  private a o;
  
  private boolean p;
  
  e(a parama) {
    if (parama != null)
      a(parama); 
  }
  
  e(a parama, Resources paramResources) {
    a(new a(parama, this, paramResources));
    onStateChange(getState());
  }
  
  a a() {
    return new a(this.o, this, null);
  }
  
  protected void a(b.c paramc) {
    super.a(paramc);
    if (paramc instanceof a)
      this.o = (a)paramc; 
  }
  
  int[] a(AttributeSet paramAttributeSet) {
    byte b2 = 0;
    int i = paramAttributeSet.getAttributeCount();
    int[] arrayOfInt = new int[i];
    for (byte b1 = 0; b1 < i; b1++) {
      int j = paramAttributeSet.getAttributeNameResource(b1);
      if (j != 0 && j != 16842960 && j != 16843161) {
        if (!paramAttributeSet.getAttributeBooleanValue(b1, false))
          j = -j; 
        arrayOfInt[b2] = j;
        b2++;
      } 
    } 
    return StateSet.trimStateSet(arrayOfInt, b2);
  }
  
  public void applyTheme(Resources.Theme paramTheme) {
    super.applyTheme(paramTheme);
    onStateChange(getState());
  }
  
  public boolean isStateful() {
    return true;
  }
  
  public Drawable mutate() {
    if (!this.p) {
      super.mutate();
      this.o.m();
      this.p = true;
    } 
    return this;
  }
  
  protected boolean onStateChange(int[] paramArrayOfint) {
    null = super.onStateChange(paramArrayOfint);
    int j = this.o.a(paramArrayOfint);
    int i = j;
    if (j < 0)
      i = this.o.a(StateSet.WILD_CARD); 
    return (a(i) || null);
  }
  
  static class a extends b.c {
    int[][] J;
    
    a(a param1a, e param1e, Resources param1Resources) {
      super(param1a, param1e, param1Resources);
      if (param1a != null) {
        this.J = param1a.J;
      } else {
        this.J = new int[c()][];
      } 
    }
    
    int a(int[] param1ArrayOfint) {
      int[][] arrayOfInt = this.J;
      int i = d();
      for (byte b = 0; b < i; b++) {
        if (StateSet.stateSetMatches(arrayOfInt[b], param1ArrayOfint))
          return b; 
      } 
      return -1;
    }
    
    int a(int[] param1ArrayOfint, Drawable param1Drawable) {
      int i = a(param1Drawable);
      this.J[i] = param1ArrayOfint;
      return i;
    }
    
    public void a(int param1Int1, int param1Int2) {
      super.a(param1Int1, param1Int2);
      int[][] arrayOfInt = new int[param1Int2][];
      System.arraycopy(this.J, 0, arrayOfInt, 0, param1Int1);
      this.J = arrayOfInt;
    }
    
    void m() {
      int[][] arrayOfInt1 = this.J;
      int[][] arrayOfInt2 = new int[arrayOfInt1.length][];
      for (int i = arrayOfInt1.length - 1; i >= 0; i--) {
        arrayOfInt1 = this.J;
        if (arrayOfInt1[i] != null) {
          int[] arrayOfInt = (int[])arrayOfInt1[i].clone();
        } else {
          arrayOfInt1 = null;
        } 
        arrayOfInt2[i] = (int[])arrayOfInt1;
      } 
      this.J = arrayOfInt2;
    }
    
    public Drawable newDrawable() {
      return new e(this, null);
    }
    
    public Drawable newDrawable(Resources param1Resources) {
      return new e(this, param1Resources);
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\h\d\a\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */