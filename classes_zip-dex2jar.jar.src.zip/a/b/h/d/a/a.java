package a.b.h.d.a;

import a.b.d.a.i;
import a.b.g.g.o;
import a.b.h.a.j;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.StateSet;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class a extends e {
  private c q;
  
  private g r;
  
  private int s = -1;
  
  private int t = -1;
  
  private boolean u;
  
  static {
    a.class.getSimpleName();
  }
  
  public a() {
    this((c)null, (Resources)null);
  }
  
  a(c paramc, Resources paramResources) {
    super((e.a)null);
    a(new c(paramc, this, paramResources));
    onStateChange(getState());
    jumpToCurrentState();
  }
  
  private void a(TypedArray paramTypedArray) {
    c c1 = this.q;
    if (Build.VERSION.SDK_INT >= 21)
      c1.d |= paramTypedArray.getChangingConfigurations(); 
    c1.b(paramTypedArray.getBoolean(j.AnimatedStateListDrawableCompat_android_variablePadding, c1.i));
    c1.a(paramTypedArray.getBoolean(j.AnimatedStateListDrawableCompat_android_constantSize, c1.l));
    c1.b(paramTypedArray.getInt(j.AnimatedStateListDrawableCompat_android_enterFadeDuration, c1.A));
    c1.c(paramTypedArray.getInt(j.AnimatedStateListDrawableCompat_android_exitFadeDuration, c1.B));
    setDither(paramTypedArray.getBoolean(j.AnimatedStateListDrawableCompat_android_dither, c1.x));
  }
  
  public static a b(Context paramContext, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    a a1;
    String str = paramXmlPullParser.getName();
    if (str.equals("animated-selector")) {
      a1 = new a();
      a1.a(paramContext, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
      return a1;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramXmlPullParser.getPositionDescription());
    stringBuilder.append(": invalid animated-selector tag ");
    stringBuilder.append((String)a1);
    throw new XmlPullParserException(stringBuilder.toString());
  }
  
  private boolean b(int paramInt) {
    int i;
    b b;
    g g1 = this.r;
    if (g1 != null) {
      if (paramInt == this.s)
        return true; 
      if (paramInt == this.t && g1.a()) {
        g1.b();
        this.s = this.t;
        this.t = paramInt;
        return true;
      } 
      i = this.s;
      g1.d();
    } else {
      i = b();
    } 
    this.r = null;
    this.t = -1;
    this.s = -1;
    c c1 = this.q;
    int m = c1.d(i);
    int j = c1.d(paramInt);
    if (j == 0 || m == 0)
      return false; 
    int k = c1.c(m, j);
    if (k < 0)
      return false; 
    boolean bool = c1.e(m, j);
    a(k);
    Drawable drawable = getCurrent();
    if (drawable instanceof AnimationDrawable) {
      boolean bool1 = c1.d(m, j);
      e e1 = new e((AnimationDrawable)drawable, bool1, bool);
    } else if (drawable instanceof a.b.d.a.c) {
      d d = new d((a.b.d.a.c)drawable);
    } else {
      if (drawable instanceof Animatable) {
        b = new b((Animatable)drawable);
        b.c();
        this.r = b;
        this.t = i;
        this.s = paramInt;
        return true;
      } 
      return false;
    } 
    b.c();
    this.r = b;
    this.t = i;
    this.s = paramInt;
    return true;
  }
  
  private void c() {
    onStateChange(getState());
  }
  
  private void c(Context paramContext, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    int i = paramXmlPullParser.getDepth() + 1;
    while (true) {
      int j = paramXmlPullParser.next();
      if (j != 1) {
        int k = paramXmlPullParser.getDepth();
        if (k >= i || j != 3) {
          if (j != 2 || k > i)
            continue; 
          if (paramXmlPullParser.getName().equals("item")) {
            d(paramContext, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
            continue;
          } 
          if (paramXmlPullParser.getName().equals("transition"))
            e(paramContext, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme); 
          continue;
        } 
      } 
      break;
    } 
  }
  
  private int d(Context paramContext, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    XmlPullParserException xmlPullParserException2;
    TypedArray typedArray = android.support.v4.content.e.g.a(paramResources, paramTheme, paramAttributeSet, j.AnimatedStateListDrawableItem);
    int i = typedArray.getResourceId(j.AnimatedStateListDrawableItem_android_id, 0);
    Drawable drawable2 = null;
    int j = typedArray.getResourceId(j.AnimatedStateListDrawableItem_android_drawable, -1);
    if (j > 0)
      drawable2 = a.b.h.c.a.a.c(paramContext, j); 
    typedArray.recycle();
    int[] arrayOfInt = a(paramAttributeSet);
    Drawable drawable1 = drawable2;
    if (drawable2 == null)
      while (true) {
        j = paramXmlPullParser.next();
        if (j == 4)
          continue; 
        if (j == 2) {
          if (paramXmlPullParser.getName().equals("vector")) {
            i i1 = i.createFromXmlInner(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
            break;
          } 
          if (Build.VERSION.SDK_INT >= 21) {
            drawable1 = Drawable.createFromXmlInner(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
          } else {
            drawable1 = Drawable.createFromXmlInner(paramResources, paramXmlPullParser, paramAttributeSet);
          } 
        } else {
          stringBuilder1 = new StringBuilder();
          stringBuilder1.append(paramXmlPullParser.getPositionDescription());
          stringBuilder1.append(": <item> tag requires a 'drawable' attribute or child tag defining a drawable");
          throw new XmlPullParserException(stringBuilder1.toString());
        } 
        if (stringBuilder1 != null)
          return this.q.a(arrayOfInt, (Drawable)stringBuilder1, i); 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(paramXmlPullParser.getPositionDescription());
        stringBuilder1.append(": <item> tag requires a 'drawable' attribute or child tag defining a drawable");
        xmlPullParserException2 = new XmlPullParserException(stringBuilder1.toString());
        throw xmlPullParserException2;
      }  
    if (xmlPullParserException2 != null)
      return this.q.a(arrayOfInt, (Drawable)xmlPullParserException2, i); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramXmlPullParser.getPositionDescription());
    stringBuilder.append(": <item> tag requires a 'drawable' attribute or child tag defining a drawable");
    XmlPullParserException xmlPullParserException1 = new XmlPullParserException(stringBuilder.toString());
    throw xmlPullParserException1;
  }
  
  private int e(Context paramContext, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    // Byte code:
    //   0: aload_2
    //   1: aload #5
    //   3: aload #4
    //   5: getstatic a/b/h/a/j.AnimatedStateListDrawableTransition : [I
    //   8: invokestatic a : (Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   11: astore #10
    //   13: aload #10
    //   15: getstatic a/b/h/a/j.AnimatedStateListDrawableTransition_android_fromId : I
    //   18: iconst_m1
    //   19: invokevirtual getResourceId : (II)I
    //   22: istore #6
    //   24: aload #10
    //   26: getstatic a/b/h/a/j.AnimatedStateListDrawableTransition_android_toId : I
    //   29: iconst_m1
    //   30: invokevirtual getResourceId : (II)I
    //   33: istore #7
    //   35: aconst_null
    //   36: astore #11
    //   38: aload #10
    //   40: getstatic a/b/h/a/j.AnimatedStateListDrawableTransition_android_drawable : I
    //   43: iconst_m1
    //   44: invokevirtual getResourceId : (II)I
    //   47: istore #8
    //   49: iload #8
    //   51: ifle -> 65
    //   54: aload_1
    //   55: iload #8
    //   57: invokestatic c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   60: astore #11
    //   62: goto -> 65
    //   65: aload #10
    //   67: getstatic a/b/h/a/j.AnimatedStateListDrawableTransition_android_reversible : I
    //   70: iconst_0
    //   71: invokevirtual getBoolean : (IZ)Z
    //   74: istore #9
    //   76: aload #10
    //   78: invokevirtual recycle : ()V
    //   81: aload #11
    //   83: astore #10
    //   85: aload #11
    //   87: ifnonnull -> 216
    //   90: aload_3
    //   91: invokeinterface next : ()I
    //   96: istore #8
    //   98: iload #8
    //   100: iconst_4
    //   101: if_icmpne -> 107
    //   104: goto -> 90
    //   107: iload #8
    //   109: iconst_2
    //   110: if_icmpne -> 177
    //   113: aload_3
    //   114: invokeinterface getName : ()Ljava/lang/String;
    //   119: ldc_w 'animated-vector'
    //   122: invokevirtual equals : (Ljava/lang/Object;)Z
    //   125: ifeq -> 143
    //   128: aload_1
    //   129: aload_2
    //   130: aload_3
    //   131: aload #4
    //   133: aload #5
    //   135: invokestatic a : (Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)La/b/d/a/c;
    //   138: astore #10
    //   140: goto -> 216
    //   143: getstatic android/os/Build$VERSION.SDK_INT : I
    //   146: bipush #21
    //   148: if_icmplt -> 165
    //   151: aload_2
    //   152: aload_3
    //   153: aload #4
    //   155: aload #5
    //   157: invokestatic createFromXmlInner : (Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;
    //   160: astore #10
    //   162: goto -> 216
    //   165: aload_2
    //   166: aload_3
    //   167: aload #4
    //   169: invokestatic createFromXmlInner : (Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;)Landroid/graphics/drawable/Drawable;
    //   172: astore #10
    //   174: goto -> 216
    //   177: new java/lang/StringBuilder
    //   180: dup
    //   181: invokespecial <init> : ()V
    //   184: astore_1
    //   185: aload_1
    //   186: aload_3
    //   187: invokeinterface getPositionDescription : ()Ljava/lang/String;
    //   192: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   195: pop
    //   196: aload_1
    //   197: ldc_w ': <transition> tag requires a 'drawable' attribute or child tag defining a drawable'
    //   200: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   203: pop
    //   204: new org/xmlpull/v1/XmlPullParserException
    //   207: dup
    //   208: aload_1
    //   209: invokevirtual toString : ()Ljava/lang/String;
    //   212: invokespecial <init> : (Ljava/lang/String;)V
    //   215: athrow
    //   216: aload #10
    //   218: ifnull -> 288
    //   221: iload #6
    //   223: iconst_m1
    //   224: if_icmpeq -> 249
    //   227: iload #7
    //   229: iconst_m1
    //   230: if_icmpeq -> 249
    //   233: aload_0
    //   234: getfield q : La/b/h/d/a/a$c;
    //   237: iload #6
    //   239: iload #7
    //   241: aload #10
    //   243: iload #9
    //   245: invokevirtual a : (IILandroid/graphics/drawable/Drawable;Z)I
    //   248: ireturn
    //   249: new java/lang/StringBuilder
    //   252: dup
    //   253: invokespecial <init> : ()V
    //   256: astore_1
    //   257: aload_1
    //   258: aload_3
    //   259: invokeinterface getPositionDescription : ()Ljava/lang/String;
    //   264: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   267: pop
    //   268: aload_1
    //   269: ldc_w ': <transition> tag requires 'fromId' & 'toId' attributes'
    //   272: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   275: pop
    //   276: new org/xmlpull/v1/XmlPullParserException
    //   279: dup
    //   280: aload_1
    //   281: invokevirtual toString : ()Ljava/lang/String;
    //   284: invokespecial <init> : (Ljava/lang/String;)V
    //   287: athrow
    //   288: new java/lang/StringBuilder
    //   291: dup
    //   292: invokespecial <init> : ()V
    //   295: astore_1
    //   296: aload_1
    //   297: aload_3
    //   298: invokeinterface getPositionDescription : ()Ljava/lang/String;
    //   303: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   306: pop
    //   307: aload_1
    //   308: ldc_w ': <transition> tag requires a 'drawable' attribute or child tag defining a drawable'
    //   311: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   314: pop
    //   315: new org/xmlpull/v1/XmlPullParserException
    //   318: dup
    //   319: aload_1
    //   320: invokevirtual toString : ()Ljava/lang/String;
    //   323: invokespecial <init> : (Ljava/lang/String;)V
    //   326: astore_1
    //   327: goto -> 332
    //   330: aload_1
    //   331: athrow
    //   332: goto -> 330
  }
  
  c a() {
    return new c(this.q, this, null);
  }
  
  protected void a(b.c paramc) {
    super.a(paramc);
    if (paramc instanceof c)
      this.q = (c)paramc; 
  }
  
  public void a(Context paramContext, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    TypedArray typedArray = android.support.v4.content.e.g.a(paramResources, paramTheme, paramAttributeSet, j.AnimatedStateListDrawableCompat);
    setVisible(typedArray.getBoolean(j.AnimatedStateListDrawableCompat_android_visible, true), true);
    a(typedArray);
    a(paramResources);
    typedArray.recycle();
    c(paramContext, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
    c();
  }
  
  public boolean isStateful() {
    return true;
  }
  
  public void jumpToCurrentState() {
    super.jumpToCurrentState();
    g g1 = this.r;
    if (g1 != null) {
      g1.d();
      this.r = null;
      a(this.s);
      this.s = -1;
      this.t = -1;
    } 
  }
  
  public Drawable mutate() {
    if (!this.u) {
      super.mutate();
      this.q.m();
      this.u = true;
    } 
    return this;
  }
  
  protected boolean onStateChange(int[] paramArrayOfint) {
    boolean bool1;
    int i = this.q.b(paramArrayOfint);
    if (i != b() && (b(i) || a(i))) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    Drawable drawable = getCurrent();
    boolean bool2 = bool1;
    if (drawable != null)
      bool2 = bool1 | drawable.setState(paramArrayOfint); 
    return bool2;
  }
  
  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2) {
    boolean bool = super.setVisible(paramBoolean1, paramBoolean2);
    if (this.r != null && (bool || paramBoolean2))
      if (paramBoolean1) {
        this.r.c();
      } else {
        jumpToCurrentState();
      }  
    return bool;
  }
  
  private static class b extends g {
    private final Animatable a;
    
    b(Animatable param1Animatable) {
      super(null);
      this.a = param1Animatable;
    }
    
    public void c() {
      this.a.start();
    }
    
    public void d() {
      this.a.stop();
    }
  }
  
  static class c extends e.a {
    a.b.g.g.f<Long> K;
    
    o<Integer> L;
    
    c(c param1c, a param1a, Resources param1Resources) {
      super(param1c, param1a, param1Resources);
      if (param1c != null) {
        this.K = param1c.K;
        this.L = param1c.L;
      } else {
        this.K = new a.b.g.g.f();
        this.L = new o();
      } 
    }
    
    private static long f(int param1Int1, int param1Int2) {
      return param1Int1 << 32L | param1Int2;
    }
    
    int a(int param1Int1, int param1Int2, Drawable param1Drawable, boolean param1Boolean) {
      int i = a(param1Drawable);
      long l2 = f(param1Int1, param1Int2);
      long l1 = 0L;
      if (param1Boolean)
        l1 = 8589934592L; 
      this.K.a(l2, Long.valueOf(i | l1));
      if (param1Boolean) {
        l2 = f(param1Int2, param1Int1);
        this.K.a(l2, Long.valueOf(i | 0x100000000L | l1));
      } 
      return i;
    }
    
    int a(int[] param1ArrayOfint, Drawable param1Drawable, int param1Int) {
      int i = a(param1ArrayOfint, param1Drawable);
      this.L.c(i, Integer.valueOf(param1Int));
      return i;
    }
    
    int b(int[] param1ArrayOfint) {
      int i = a(param1ArrayOfint);
      return (i >= 0) ? i : a(StateSet.WILD_CARD);
    }
    
    int c(int param1Int1, int param1Int2) {
      long l = f(param1Int1, param1Int2);
      return (int)((Long)this.K.b(l, Long.valueOf(-1L))).longValue();
    }
    
    int d(int param1Int) {
      boolean bool = false;
      if (param1Int < 0) {
        param1Int = bool;
      } else {
        param1Int = ((Integer)this.L.b(param1Int, Integer.valueOf(0))).intValue();
      } 
      return param1Int;
    }
    
    boolean d(int param1Int1, int param1Int2) {
      boolean bool;
      long l = f(param1Int1, param1Int2);
      if ((((Long)this.K.b(l, Long.valueOf(-1L))).longValue() & 0x100000000L) != 0L) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    boolean e(int param1Int1, int param1Int2) {
      boolean bool;
      long l = f(param1Int1, param1Int2);
      if ((((Long)this.K.b(l, Long.valueOf(-1L))).longValue() & 0x200000000L) != 0L) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    void m() {
      this.K = this.K.clone();
      this.L = this.L.clone();
    }
    
    public Drawable newDrawable() {
      return new a(this, null);
    }
    
    public Drawable newDrawable(Resources param1Resources) {
      return new a(this, param1Resources);
    }
  }
  
  private static class d extends g {
    private final a.b.d.a.c a;
    
    d(a.b.d.a.c param1c) {
      super(null);
      this.a = param1c;
    }
    
    public void c() {
      this.a.start();
    }
    
    public void d() {
      this.a.stop();
    }
  }
  
  private static class e extends g {
    private final ObjectAnimator a;
    
    private final boolean b;
    
    e(AnimationDrawable param1AnimationDrawable, boolean param1Boolean1, boolean param1Boolean2) {
      super(null);
      boolean bool;
      int i = param1AnimationDrawable.getNumberOfFrames();
      if (param1Boolean1) {
        bool = i - 1;
      } else {
        bool = false;
      } 
      if (param1Boolean1) {
        i = 0;
      } else {
        i--;
      } 
      a.f f = new a.f(param1AnimationDrawable, param1Boolean1);
      ObjectAnimator objectAnimator = ObjectAnimator.ofInt(param1AnimationDrawable, "currentIndex", new int[] { bool, i });
      if (Build.VERSION.SDK_INT >= 18)
        objectAnimator.setAutoCancel(true); 
      objectAnimator.setDuration(f.a());
      objectAnimator.setInterpolator(f);
      this.b = param1Boolean2;
      this.a = objectAnimator;
    }
    
    public boolean a() {
      return this.b;
    }
    
    public void b() {
      this.a.reverse();
    }
    
    public void c() {
      this.a.start();
    }
    
    public void d() {
      this.a.cancel();
    }
  }
  
  private static class f implements TimeInterpolator {
    private int[] a;
    
    private int b;
    
    private int c;
    
    f(AnimationDrawable param1AnimationDrawable, boolean param1Boolean) {
      a(param1AnimationDrawable, param1Boolean);
    }
    
    int a() {
      return this.c;
    }
    
    int a(AnimationDrawable param1AnimationDrawable, boolean param1Boolean) {
      int j = param1AnimationDrawable.getNumberOfFrames();
      this.b = j;
      int[] arrayOfInt = this.a;
      if (arrayOfInt == null || arrayOfInt.length < j)
        this.a = new int[j]; 
      arrayOfInt = this.a;
      int i = 0;
      for (byte b = 0; b < j; b++) {
        if (param1Boolean) {
          k = j - b - 1;
        } else {
          k = b;
        } 
        int k = param1AnimationDrawable.getDuration(k);
        arrayOfInt[b] = k;
        i += k;
      } 
      this.c = i;
      return i;
    }
    
    public float getInterpolation(float param1Float) {
      int i = (int)(this.c * param1Float + 0.5F);
      int j = this.b;
      int[] arrayOfInt = this.a;
      byte b;
      for (b = 0; b < j && i >= arrayOfInt[b]; b++)
        i -= arrayOfInt[b]; 
      if (b < j) {
        param1Float = i / this.c;
      } else {
        param1Float = 0.0F;
      } 
      return b / j + param1Float;
    }
  }
  
  private static abstract class g {
    private g() {}
    
    public boolean a() {
      return false;
    }
    
    public void b() {}
    
    public abstract void c();
    
    public abstract void d();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\h\d\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */