package a.b.h.d.a;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.SystemClock;
import android.util.SparseArray;

class b extends Drawable implements Drawable.Callback {
  private c c;
  
  private Rect d;
  
  private Drawable e;
  
  private Drawable f;
  
  private int g = 255;
  
  private boolean h;
  
  private int i = -1;
  
  private boolean j;
  
  private Runnable k;
  
  private long l;
  
  private long m;
  
  private b n;
  
  static int a(Resources paramResources, int paramInt) {
    if (paramResources != null)
      paramInt = (paramResources.getDisplayMetrics()).densityDpi; 
    if (paramInt == 0)
      paramInt = 160; 
    return paramInt;
  }
  
  private void a(Drawable paramDrawable) {
    if (this.n == null)
      this.n = new b(); 
    null = this.n;
    null.a(paramDrawable.getCallback());
    paramDrawable.setCallback(null);
    try {
      if (this.c.A <= 0 && this.h)
        paramDrawable.setAlpha(this.g); 
      if (this.c.E) {
        paramDrawable.setColorFilter(this.c.D);
      } else {
        if (this.c.H)
          android.support.v4.graphics.drawable.a.a(paramDrawable, this.c.F); 
        if (this.c.I)
          android.support.v4.graphics.drawable.a.a(paramDrawable, this.c.G); 
      } 
      paramDrawable.setVisible(isVisible(), true);
      paramDrawable.setDither(this.c.x);
      paramDrawable.setState(getState());
      paramDrawable.setLevel(getLevel());
      paramDrawable.setBounds(getBounds());
      if (Build.VERSION.SDK_INT >= 23)
        paramDrawable.setLayoutDirection(getLayoutDirection()); 
      if (Build.VERSION.SDK_INT >= 19)
        paramDrawable.setAutoMirrored(this.c.C); 
      Rect rect = this.d;
      if (Build.VERSION.SDK_INT >= 21 && rect != null)
        paramDrawable.setHotspotBounds(rect.left, rect.top, rect.right, rect.bottom); 
      return;
    } finally {
      paramDrawable.setCallback(this.n.a());
    } 
  }
  
  @SuppressLint({"WrongConstant"})
  @TargetApi(23)
  private boolean c() {
    boolean bool1 = isAutoMirrored();
    boolean bool = true;
    if (!bool1 || getLayoutDirection() != 1)
      bool = false; 
    return bool;
  }
  
  c a() {
    throw null;
  }
  
  protected void a(c paramc) {
    this.c = paramc;
    int i = this.i;
    if (i >= 0) {
      this.e = paramc.a(i);
      Drawable drawable = this.e;
      if (drawable != null)
        a(drawable); 
    } 
    this.f = null;
  }
  
  final void a(Resources paramResources) {
    this.c.a(paramResources);
  }
  
  void a(boolean paramBoolean) {
    int i;
    this.h = true;
    long l = SystemClock.uptimeMillis();
    int j = 0;
    Drawable drawable = this.e;
    if (drawable != null) {
      long l1 = this.l;
      i = j;
      if (l1 != 0L)
        if (l1 <= l) {
          drawable.setAlpha(this.g);
          this.l = 0L;
          i = j;
        } else {
          drawable.setAlpha((255 - (int)((l1 - l) * 255L) / this.c.A) * this.g / 255);
          i = 1;
        }  
    } else {
      this.l = 0L;
      i = j;
    } 
    drawable = this.f;
    if (drawable != null) {
      long l1 = this.m;
      j = i;
      if (l1 != 0L)
        if (l1 <= l) {
          drawable.setVisible(false, false);
          this.f = null;
          this.m = 0L;
          j = i;
        } else {
          i = (int)((l1 - l) * 255L) / this.c.B;
          drawable.setAlpha(this.g * i / 255);
          j = 1;
        }  
    } else {
      this.m = 0L;
      j = i;
    } 
    if (paramBoolean && j != 0)
      scheduleSelf(this.k, 16L + l); 
  }
  
  boolean a(int paramInt) {
    // Byte code:
    //   0: iload_1
    //   1: aload_0
    //   2: getfield i : I
    //   5: if_icmpne -> 10
    //   8: iconst_0
    //   9: ireturn
    //   10: invokestatic uptimeMillis : ()J
    //   13: lstore_2
    //   14: aload_0
    //   15: getfield c : La/b/h/d/a/b$c;
    //   18: getfield B : I
    //   21: ifle -> 90
    //   24: aload_0
    //   25: getfield f : Landroid/graphics/drawable/Drawable;
    //   28: astore #4
    //   30: aload #4
    //   32: ifnull -> 43
    //   35: aload #4
    //   37: iconst_0
    //   38: iconst_0
    //   39: invokevirtual setVisible : (ZZ)Z
    //   42: pop
    //   43: aload_0
    //   44: getfield e : Landroid/graphics/drawable/Drawable;
    //   47: astore #4
    //   49: aload #4
    //   51: ifnull -> 77
    //   54: aload_0
    //   55: aload #4
    //   57: putfield f : Landroid/graphics/drawable/Drawable;
    //   60: aload_0
    //   61: aload_0
    //   62: getfield c : La/b/h/d/a/b$c;
    //   65: getfield B : I
    //   68: i2l
    //   69: lload_2
    //   70: ladd
    //   71: putfield m : J
    //   74: goto -> 109
    //   77: aload_0
    //   78: aconst_null
    //   79: putfield f : Landroid/graphics/drawable/Drawable;
    //   82: aload_0
    //   83: lconst_0
    //   84: putfield m : J
    //   87: goto -> 109
    //   90: aload_0
    //   91: getfield e : Landroid/graphics/drawable/Drawable;
    //   94: astore #4
    //   96: aload #4
    //   98: ifnull -> 109
    //   101: aload #4
    //   103: iconst_0
    //   104: iconst_0
    //   105: invokevirtual setVisible : (ZZ)Z
    //   108: pop
    //   109: iload_1
    //   110: iflt -> 181
    //   113: aload_0
    //   114: getfield c : La/b/h/d/a/b$c;
    //   117: astore #4
    //   119: iload_1
    //   120: aload #4
    //   122: getfield h : I
    //   125: if_icmpge -> 181
    //   128: aload #4
    //   130: iload_1
    //   131: invokevirtual a : (I)Landroid/graphics/drawable/Drawable;
    //   134: astore #4
    //   136: aload_0
    //   137: aload #4
    //   139: putfield e : Landroid/graphics/drawable/Drawable;
    //   142: aload_0
    //   143: iload_1
    //   144: putfield i : I
    //   147: aload #4
    //   149: ifnull -> 178
    //   152: aload_0
    //   153: getfield c : La/b/h/d/a/b$c;
    //   156: getfield A : I
    //   159: istore_1
    //   160: iload_1
    //   161: ifle -> 172
    //   164: aload_0
    //   165: iload_1
    //   166: i2l
    //   167: lload_2
    //   168: ladd
    //   169: putfield l : J
    //   172: aload_0
    //   173: aload #4
    //   175: invokespecial a : (Landroid/graphics/drawable/Drawable;)V
    //   178: goto -> 191
    //   181: aload_0
    //   182: aconst_null
    //   183: putfield e : Landroid/graphics/drawable/Drawable;
    //   186: aload_0
    //   187: iconst_m1
    //   188: putfield i : I
    //   191: aload_0
    //   192: getfield l : J
    //   195: lconst_0
    //   196: lcmp
    //   197: ifne -> 209
    //   200: aload_0
    //   201: getfield m : J
    //   204: lconst_0
    //   205: lcmp
    //   206: ifeq -> 246
    //   209: aload_0
    //   210: getfield k : Ljava/lang/Runnable;
    //   213: astore #4
    //   215: aload #4
    //   217: ifnonnull -> 235
    //   220: aload_0
    //   221: new a/b/h/d/a/b$a
    //   224: dup
    //   225: aload_0
    //   226: invokespecial <init> : (La/b/h/d/a/b;)V
    //   229: putfield k : Ljava/lang/Runnable;
    //   232: goto -> 241
    //   235: aload_0
    //   236: aload #4
    //   238: invokevirtual unscheduleSelf : (Ljava/lang/Runnable;)V
    //   241: aload_0
    //   242: iconst_1
    //   243: invokevirtual a : (Z)V
    //   246: aload_0
    //   247: invokevirtual invalidateSelf : ()V
    //   250: iconst_1
    //   251: ireturn
  }
  
  public void applyTheme(Resources.Theme paramTheme) {
    this.c.a(paramTheme);
  }
  
  int b() {
    return this.i;
  }
  
  public boolean canApplyTheme() {
    return this.c.canApplyTheme();
  }
  
  public void draw(Canvas paramCanvas) {
    Drawable drawable = this.e;
    if (drawable != null)
      drawable.draw(paramCanvas); 
    drawable = this.f;
    if (drawable != null)
      drawable.draw(paramCanvas); 
  }
  
  public int getAlpha() {
    return this.g;
  }
  
  public int getChangingConfigurations() {
    return super.getChangingConfigurations() | this.c.getChangingConfigurations();
  }
  
  public final Drawable.ConstantState getConstantState() {
    if (this.c.a()) {
      this.c.d = getChangingConfigurations();
      return this.c;
    } 
    return null;
  }
  
  public Drawable getCurrent() {
    return this.e;
  }
  
  public void getHotspotBounds(Rect paramRect) {
    Rect rect = this.d;
    if (rect != null) {
      paramRect.set(rect);
    } else {
      super.getHotspotBounds(paramRect);
    } 
  }
  
  public int getIntrinsicHeight() {
    byte b1;
    if (this.c.l())
      return this.c.e(); 
    Drawable drawable = this.e;
    if (drawable != null) {
      b1 = drawable.getIntrinsicHeight();
    } else {
      b1 = -1;
    } 
    return b1;
  }
  
  public int getIntrinsicWidth() {
    byte b1;
    if (this.c.l())
      return this.c.i(); 
    Drawable drawable = this.e;
    if (drawable != null) {
      b1 = drawable.getIntrinsicWidth();
    } else {
      b1 = -1;
    } 
    return b1;
  }
  
  public int getMinimumHeight() {
    boolean bool;
    if (this.c.l())
      return this.c.f(); 
    Drawable drawable = this.e;
    if (drawable != null) {
      bool = drawable.getMinimumHeight();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int getMinimumWidth() {
    boolean bool;
    if (this.c.l())
      return this.c.g(); 
    Drawable drawable = this.e;
    if (drawable != null) {
      bool = drawable.getMinimumWidth();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int getOpacity() {
    Drawable drawable = this.e;
    return (drawable == null || !drawable.isVisible()) ? -2 : this.c.j();
  }
  
  public void getOutline(Outline paramOutline) {
    Drawable drawable = this.e;
    if (drawable != null)
      drawable.getOutline(paramOutline); 
  }
  
  public boolean getPadding(Rect paramRect) {
    boolean bool;
    Rect rect = this.c.h();
    if (rect != null) {
      paramRect.set(rect);
      if ((rect.left | rect.top | rect.bottom | rect.right) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
    } else {
      Drawable drawable = this.e;
      if (drawable != null) {
        bool = drawable.getPadding(paramRect);
      } else {
        bool = super.getPadding(paramRect);
      } 
    } 
    if (c()) {
      int i = paramRect.left;
      paramRect.left = paramRect.right;
      paramRect.right = i;
    } 
    return bool;
  }
  
  public void invalidateDrawable(Drawable paramDrawable) {
    c c1 = this.c;
    if (c1 != null)
      c1.k(); 
    if (paramDrawable == this.e && getCallback() != null)
      getCallback().invalidateDrawable(this); 
  }
  
  public boolean isAutoMirrored() {
    return this.c.C;
  }
  
  public void jumpToCurrentState() {
    boolean bool = false;
    Drawable drawable = this.f;
    if (drawable != null) {
      drawable.jumpToCurrentState();
      this.f = null;
      bool = true;
    } 
    drawable = this.e;
    if (drawable != null) {
      drawable.jumpToCurrentState();
      if (this.h)
        this.e.setAlpha(this.g); 
    } 
    if (this.m != 0L) {
      this.m = 0L;
      bool = true;
    } 
    if (this.l != 0L) {
      this.l = 0L;
      bool = true;
    } 
    if (bool)
      invalidateSelf(); 
  }
  
  public Drawable mutate() {
    if (!this.j && super.mutate() == this) {
      c c1 = a();
      c1.m();
      a(c1);
      this.j = true;
    } 
    return this;
  }
  
  protected void onBoundsChange(Rect paramRect) {
    Drawable drawable = this.f;
    if (drawable != null)
      drawable.setBounds(paramRect); 
    drawable = this.e;
    if (drawable != null)
      drawable.setBounds(paramRect); 
  }
  
  public boolean onLayoutDirectionChanged(int paramInt) {
    return this.c.b(paramInt, b());
  }
  
  protected boolean onLevelChange(int paramInt) {
    Drawable drawable = this.f;
    if (drawable != null)
      return drawable.setLevel(paramInt); 
    drawable = this.e;
    return (drawable != null) ? drawable.setLevel(paramInt) : false;
  }
  
  protected boolean onStateChange(int[] paramArrayOfint) {
    Drawable drawable = this.f;
    if (drawable != null)
      return drawable.setState(paramArrayOfint); 
    drawable = this.e;
    return (drawable != null) ? drawable.setState(paramArrayOfint) : false;
  }
  
  public void scheduleDrawable(Drawable paramDrawable, Runnable paramRunnable, long paramLong) {
    if (paramDrawable == this.e && getCallback() != null)
      getCallback().scheduleDrawable(this, paramRunnable, paramLong); 
  }
  
  public void setAlpha(int paramInt) {
    if (!this.h || this.g != paramInt) {
      this.h = true;
      this.g = paramInt;
      Drawable drawable = this.e;
      if (drawable != null)
        if (this.l == 0L) {
          drawable.setAlpha(paramInt);
        } else {
          a(false);
        }  
    } 
  }
  
  public void setAutoMirrored(boolean paramBoolean) {
    c c1 = this.c;
    if (c1.C != paramBoolean) {
      c1.C = paramBoolean;
      Drawable drawable = this.e;
      if (drawable != null)
        android.support.v4.graphics.drawable.a.a(drawable, c1.C); 
    } 
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    c c1 = this.c;
    c1.E = true;
    if (c1.D != paramColorFilter) {
      c1.D = paramColorFilter;
      Drawable drawable = this.e;
      if (drawable != null)
        drawable.setColorFilter(paramColorFilter); 
    } 
  }
  
  public void setDither(boolean paramBoolean) {
    c c1 = this.c;
    if (c1.x != paramBoolean) {
      c1.x = paramBoolean;
      Drawable drawable = this.e;
      if (drawable != null)
        drawable.setDither(c1.x); 
    } 
  }
  
  public void setHotspot(float paramFloat1, float paramFloat2) {
    Drawable drawable = this.e;
    if (drawable != null)
      android.support.v4.graphics.drawable.a.a(drawable, paramFloat1, paramFloat2); 
  }
  
  public void setHotspotBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Rect rect = this.d;
    if (rect == null) {
      this.d = new Rect(paramInt1, paramInt2, paramInt3, paramInt4);
    } else {
      rect.set(paramInt1, paramInt2, paramInt3, paramInt4);
    } 
    Drawable drawable = this.e;
    if (drawable != null)
      android.support.v4.graphics.drawable.a.a(drawable, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void setTintList(ColorStateList paramColorStateList) {
    c c1 = this.c;
    c1.H = true;
    if (c1.F != paramColorStateList) {
      c1.F = paramColorStateList;
      android.support.v4.graphics.drawable.a.a(this.e, paramColorStateList);
    } 
  }
  
  public void setTintMode(PorterDuff.Mode paramMode) {
    c c1 = this.c;
    c1.I = true;
    if (c1.G != paramMode) {
      c1.G = paramMode;
      android.support.v4.graphics.drawable.a.a(this.e, paramMode);
    } 
  }
  
  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2) {
    boolean bool = super.setVisible(paramBoolean1, paramBoolean2);
    Drawable drawable = this.f;
    if (drawable != null)
      drawable.setVisible(paramBoolean1, paramBoolean2); 
    drawable = this.e;
    if (drawable != null)
      drawable.setVisible(paramBoolean1, paramBoolean2); 
    return bool;
  }
  
  public void unscheduleDrawable(Drawable paramDrawable, Runnable paramRunnable) {
    if (paramDrawable == this.e && getCallback() != null)
      getCallback().unscheduleDrawable(this, paramRunnable); 
  }
  
  class a implements Runnable {
    final b c;
    
    a(b this$0) {}
    
    public void run() {
      this.c.a(true);
      this.c.invalidateSelf();
    }
  }
  
  static class b implements Drawable.Callback {
    private Drawable.Callback c;
    
    public b a(Drawable.Callback param1Callback) {
      this.c = param1Callback;
      return this;
    }
    
    public Drawable.Callback a() {
      Drawable.Callback callback = this.c;
      this.c = null;
      return callback;
    }
    
    public void invalidateDrawable(Drawable param1Drawable) {}
    
    public void scheduleDrawable(Drawable param1Drawable, Runnable param1Runnable, long param1Long) {
      Drawable.Callback callback = this.c;
      if (callback != null)
        callback.scheduleDrawable(param1Drawable, param1Runnable, param1Long); 
    }
    
    public void unscheduleDrawable(Drawable param1Drawable, Runnable param1Runnable) {
      Drawable.Callback callback = this.c;
      if (callback != null)
        callback.unscheduleDrawable(param1Drawable, param1Runnable); 
    }
  }
  
  static abstract class c extends Drawable.ConstantState {
    int A;
    
    int B;
    
    boolean C;
    
    ColorFilter D;
    
    boolean E;
    
    ColorStateList F;
    
    PorterDuff.Mode G;
    
    boolean H;
    
    boolean I;
    
    final b a;
    
    Resources b;
    
    int c;
    
    int d;
    
    int e;
    
    SparseArray<Drawable.ConstantState> f;
    
    Drawable[] g;
    
    int h;
    
    boolean i;
    
    boolean j;
    
    Rect k;
    
    boolean l;
    
    boolean m;
    
    int n;
    
    int o;
    
    int p;
    
    int q;
    
    boolean r;
    
    int s;
    
    boolean t;
    
    boolean u;
    
    boolean v;
    
    boolean w;
    
    boolean x;
    
    boolean y;
    
    int z;
    
    c(c param1c, b param1b, Resources param1Resources) {
      byte b1;
      this.c = 160;
      this.i = false;
      this.l = false;
      this.x = true;
      this.A = 0;
      this.B = 0;
      this.a = param1b;
      if (param1Resources != null) {
        Resources resources = param1Resources;
      } else if (param1c != null) {
        Resources resources = param1c.b;
      } else {
        param1b = null;
      } 
      this.b = (Resources)param1b;
      if (param1c != null) {
        b1 = param1c.c;
      } else {
        b1 = 0;
      } 
      this.c = b.a(param1Resources, b1);
      if (param1c != null) {
        this.d = param1c.d;
        this.e = param1c.e;
        this.v = true;
        this.w = true;
        this.i = param1c.i;
        this.l = param1c.l;
        this.x = param1c.x;
        this.y = param1c.y;
        this.z = param1c.z;
        this.A = param1c.A;
        this.B = param1c.B;
        this.C = param1c.C;
        this.D = param1c.D;
        this.E = param1c.E;
        this.F = param1c.F;
        this.G = param1c.G;
        this.H = param1c.H;
        this.I = param1c.I;
        if (param1c.c == this.c) {
          if (param1c.j) {
            this.k = new Rect(param1c.k);
            this.j = true;
          } 
          if (param1c.m) {
            this.n = param1c.n;
            this.o = param1c.o;
            this.p = param1c.p;
            this.q = param1c.q;
            this.m = true;
          } 
        } 
        if (param1c.r) {
          this.s = param1c.s;
          this.r = true;
        } 
        if (param1c.t) {
          this.u = param1c.u;
          this.t = true;
        } 
        Drawable[] arrayOfDrawable = param1c.g;
        this.g = new Drawable[arrayOfDrawable.length];
        this.h = param1c.h;
        SparseArray<Drawable.ConstantState> sparseArray = param1c.f;
        if (sparseArray != null) {
          this.f = sparseArray.clone();
        } else {
          this.f = new SparseArray(this.h);
        } 
        int i = this.h;
        for (b1 = 0; b1 < i; b1++) {
          if (arrayOfDrawable[b1] != null) {
            Drawable.ConstantState constantState = arrayOfDrawable[b1].getConstantState();
            if (constantState != null) {
              this.f.put(b1, constantState);
            } else {
              this.g[b1] = arrayOfDrawable[b1];
            } 
          } 
        } 
      } else {
        this.g = new Drawable[10];
        this.h = 0;
      } 
    }
    
    private Drawable b(Drawable param1Drawable) {
      if (Build.VERSION.SDK_INT >= 23)
        param1Drawable.setLayoutDirection(this.z); 
      param1Drawable = param1Drawable.mutate();
      param1Drawable.setCallback(this.a);
      return param1Drawable;
    }
    
    private void n() {
      SparseArray<Drawable.ConstantState> sparseArray = this.f;
      if (sparseArray != null) {
        int i = sparseArray.size();
        for (byte b1 = 0; b1 < i; b1++) {
          int j = this.f.keyAt(b1);
          Drawable.ConstantState constantState = (Drawable.ConstantState)this.f.valueAt(b1);
          this.g[j] = b(constantState.newDrawable(this.b));
        } 
        this.f = null;
      } 
    }
    
    public final int a(Drawable param1Drawable) {
      int i = this.h;
      if (i >= this.g.length)
        a(i, i + 10); 
      param1Drawable.mutate();
      param1Drawable.setVisible(false, true);
      param1Drawable.setCallback(this.a);
      this.g[i] = param1Drawable;
      this.h++;
      this.e |= param1Drawable.getChangingConfigurations();
      k();
      this.k = null;
      this.j = false;
      this.m = false;
      this.v = false;
      return i;
    }
    
    public final Drawable a(int param1Int) {
      Drawable drawable = this.g[param1Int];
      if (drawable != null)
        return drawable; 
      SparseArray<Drawable.ConstantState> sparseArray = this.f;
      if (sparseArray != null) {
        int i = sparseArray.indexOfKey(param1Int);
        if (i >= 0) {
          Drawable drawable1 = b(((Drawable.ConstantState)this.f.valueAt(i)).newDrawable(this.b));
          this.g[param1Int] = drawable1;
          this.f.removeAt(i);
          if (this.f.size() == 0)
            this.f = null; 
          return drawable1;
        } 
      } 
      return null;
    }
    
    public void a(int param1Int1, int param1Int2) {
      Drawable[] arrayOfDrawable = new Drawable[param1Int2];
      System.arraycopy(this.g, 0, arrayOfDrawable, 0, param1Int1);
      this.g = arrayOfDrawable;
    }
    
    final void a(Resources.Theme param1Theme) {
      if (param1Theme != null) {
        n();
        int i = this.h;
        Drawable[] arrayOfDrawable = this.g;
        for (byte b1 = 0; b1 < i; b1++) {
          if (arrayOfDrawable[b1] != null && arrayOfDrawable[b1].canApplyTheme()) {
            arrayOfDrawable[b1].applyTheme(param1Theme);
            this.e |= arrayOfDrawable[b1].getChangingConfigurations();
          } 
        } 
        a(param1Theme.getResources());
      } 
    }
    
    final void a(Resources param1Resources) {
      if (param1Resources != null) {
        this.b = param1Resources;
        int j = b.a(param1Resources, this.c);
        int i = this.c;
        this.c = j;
        if (i != j) {
          this.m = false;
          this.j = false;
        } 
      } 
    }
    
    public final void a(boolean param1Boolean) {
      this.l = param1Boolean;
    }
    
    public boolean a() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield v : Z
      //   6: ifeq -> 18
      //   9: aload_0
      //   10: getfield w : Z
      //   13: istore_3
      //   14: aload_0
      //   15: monitorexit
      //   16: iload_3
      //   17: ireturn
      //   18: aload_0
      //   19: invokespecial n : ()V
      //   22: aload_0
      //   23: iconst_1
      //   24: putfield v : Z
      //   27: aload_0
      //   28: getfield h : I
      //   31: istore_2
      //   32: aload_0
      //   33: getfield g : [Landroid/graphics/drawable/Drawable;
      //   36: astore #4
      //   38: iconst_0
      //   39: istore_1
      //   40: iload_1
      //   41: iload_2
      //   42: if_icmpge -> 70
      //   45: aload #4
      //   47: iload_1
      //   48: aaload
      //   49: invokevirtual getConstantState : ()Landroid/graphics/drawable/Drawable$ConstantState;
      //   52: ifnonnull -> 64
      //   55: aload_0
      //   56: iconst_0
      //   57: putfield w : Z
      //   60: aload_0
      //   61: monitorexit
      //   62: iconst_0
      //   63: ireturn
      //   64: iinc #1, 1
      //   67: goto -> 40
      //   70: aload_0
      //   71: iconst_1
      //   72: putfield w : Z
      //   75: aload_0
      //   76: monitorexit
      //   77: iconst_1
      //   78: ireturn
      //   79: astore #4
      //   81: aload_0
      //   82: monitorexit
      //   83: goto -> 89
      //   86: aload #4
      //   88: athrow
      //   89: goto -> 86
      // Exception table:
      //   from	to	target	type
      //   2	14	79	finally
      //   18	38	79	finally
      //   45	60	79	finally
      //   70	75	79	finally
    }
    
    protected void b() {
      this.m = true;
      n();
      int i = this.h;
      Drawable[] arrayOfDrawable = this.g;
      this.o = -1;
      this.n = -1;
      this.q = 0;
      this.p = 0;
      for (byte b1 = 0; b1 < i; b1++) {
        Drawable drawable = arrayOfDrawable[b1];
        int j = drawable.getIntrinsicWidth();
        if (j > this.n)
          this.n = j; 
        j = drawable.getIntrinsicHeight();
        if (j > this.o)
          this.o = j; 
        j = drawable.getMinimumWidth();
        if (j > this.p)
          this.p = j; 
        j = drawable.getMinimumHeight();
        if (j > this.q)
          this.q = j; 
      } 
    }
    
    public final void b(int param1Int) {
      this.A = param1Int;
    }
    
    public final void b(boolean param1Boolean) {
      this.i = param1Boolean;
    }
    
    final boolean b(int param1Int1, int param1Int2) {
      boolean bool = false;
      int i = this.h;
      Drawable[] arrayOfDrawable = this.g;
      byte b1 = 0;
      while (b1 < i) {
        boolean bool1 = bool;
        if (arrayOfDrawable[b1] != null) {
          boolean bool2 = false;
          if (Build.VERSION.SDK_INT >= 23)
            bool2 = arrayOfDrawable[b1].setLayoutDirection(param1Int1); 
          bool1 = bool;
          if (b1 == param1Int2)
            bool1 = bool2; 
        } 
        b1++;
        bool = bool1;
      } 
      this.z = param1Int1;
      return bool;
    }
    
    final int c() {
      return this.g.length;
    }
    
    public final void c(int param1Int) {
      this.B = param1Int;
    }
    
    public boolean canApplyTheme() {
      int i = this.h;
      Drawable[] arrayOfDrawable = this.g;
      for (byte b1 = 0; b1 < i; b1++) {
        Drawable drawable = arrayOfDrawable[b1];
        if (drawable != null) {
          if (drawable.canApplyTheme())
            return true; 
        } else {
          Drawable.ConstantState constantState = (Drawable.ConstantState)this.f.get(b1);
          if (constantState != null && constantState.canApplyTheme())
            return true; 
        } 
      } 
      return false;
    }
    
    public final int d() {
      return this.h;
    }
    
    public final int e() {
      if (!this.m)
        b(); 
      return this.o;
    }
    
    public final int f() {
      if (!this.m)
        b(); 
      return this.q;
    }
    
    public final int g() {
      if (!this.m)
        b(); 
      return this.p;
    }
    
    public int getChangingConfigurations() {
      return this.d | this.e;
    }
    
    public final Rect h() {
      if (this.i)
        return null; 
      if (this.k != null || this.j)
        return this.k; 
      n();
      Rect rect1 = null;
      Rect rect2 = new Rect();
      int i = this.h;
      Drawable[] arrayOfDrawable = this.g;
      byte b1 = 0;
      while (b1 < i) {
        Rect rect = rect1;
        if (arrayOfDrawable[b1].getPadding(rect2)) {
          Rect rect3 = rect1;
          if (rect1 == null)
            rect3 = new Rect(0, 0, 0, 0); 
          int j = rect2.left;
          if (j > rect3.left)
            rect3.left = j; 
          j = rect2.top;
          if (j > rect3.top)
            rect3.top = j; 
          j = rect2.right;
          if (j > rect3.right)
            rect3.right = j; 
          j = rect2.bottom;
          rect = rect3;
          if (j > rect3.bottom) {
            rect3.bottom = j;
            rect = rect3;
          } 
        } 
        b1++;
        rect1 = rect;
      } 
      this.j = true;
      this.k = rect1;
      return rect1;
    }
    
    public final int i() {
      if (!this.m)
        b(); 
      return this.n;
    }
    
    public final int j() {
      int i;
      if (this.r)
        return this.s; 
      n();
      int j = this.h;
      Drawable[] arrayOfDrawable = this.g;
      if (j > 0) {
        i = arrayOfDrawable[0].getOpacity();
      } else {
        i = -2;
      } 
      for (byte b1 = 1; b1 < j; b1++)
        i = Drawable.resolveOpacity(i, arrayOfDrawable[b1].getOpacity()); 
      this.s = i;
      this.r = true;
      return i;
    }
    
    void k() {
      this.r = false;
      this.t = false;
    }
    
    public final boolean l() {
      return this.l;
    }
    
    abstract void m();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\h\d\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */