package a.b.h.b;

public final class a {
  public static final int cardBackgroundColor = 2130968686;
  
  public static final int cardCornerRadius = 2130968687;
  
  public static final int cardElevation = 2130968688;
  
  public static final int cardMaxElevation = 2130968689;
  
  public static final int cardPreventCornerOverlap = 2130968690;
  
  public static final int cardUseCompatPadding = 2130968691;
  
  public static final int cardViewStyle = 2130968692;
  
  public static final int contentPadding = 2130968770;
  
  public static final int contentPaddingBottom = 2130968771;
  
  public static final int contentPaddingLeft = 2130968772;
  
  public static final int contentPaddingRight = 2130968773;
  
  public static final int contentPaddingTop = 2130968774;
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\a\b\h\b\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */