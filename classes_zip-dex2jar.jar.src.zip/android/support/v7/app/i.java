package android.support.v7.app;

import a.b.h.f.b;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.view.e;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

public class i extends Dialog implements f {
  private g c;
  
  private final e.a d = new a(this);
  
  public i(Context paramContext, int paramInt) {
    super(paramContext, a(paramContext, paramInt));
    a().a((Bundle)null);
    a().a();
  }
  
  private static int a(Context paramContext, int paramInt) {
    int j = paramInt;
    if (paramInt == 0) {
      TypedValue typedValue = new TypedValue();
      paramContext.getTheme().resolveAttribute(a.b.h.a.a.dialogTheme, typedValue, true);
      j = typedValue.resourceId;
    } 
    return j;
  }
  
  public b a(b.a parama) {
    return null;
  }
  
  public g a() {
    if (this.c == null)
      this.c = g.a(this, this); 
    return this.c;
  }
  
  public void a(b paramb) {}
  
  public boolean a(int paramInt) {
    return a().b(paramInt);
  }
  
  boolean a(KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    a().a(paramView, paramLayoutParams);
  }
  
  public void b(b paramb) {}
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return e.a(this.d, view, (Window.Callback)this, paramKeyEvent);
  }
  
  public <T extends View> T findViewById(int paramInt) {
    return a().a(paramInt);
  }
  
  public void invalidateOptionsMenu() {
    a().f();
  }
  
  protected void onCreate(Bundle paramBundle) {
    a().e();
    super.onCreate(paramBundle);
    a().a(paramBundle);
  }
  
  protected void onStop() {
    super.onStop();
    a().j();
  }
  
  public void setContentView(int paramInt) {
    a().c(paramInt);
  }
  
  public void setContentView(View paramView) {
    a().a(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    a().b(paramView, paramLayoutParams);
  }
  
  public void setTitle(int paramInt) {
    super.setTitle(paramInt);
    a().a(getContext().getString(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    super.setTitle(paramCharSequence);
    a().a(paramCharSequence);
  }
  
  class a implements e.a {
    final i c;
    
    a(i this$0) {}
    
    public boolean a(KeyEvent param1KeyEvent) {
      return this.c.a(param1KeyEvent);
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\app\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */