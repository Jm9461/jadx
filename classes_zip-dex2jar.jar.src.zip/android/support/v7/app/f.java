package android.support.v7.app;

import a.b.h.f.b;

public interface f {
  b a(b.a parama);
  
  void a(b paramb);
  
  void b(b paramb);
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\app\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */