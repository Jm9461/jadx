package android.support.v7.app;

class l {
  private static l d;
  
  public long a;
  
  public long b;
  
  public int c;
  
  static l a() {
    if (d == null)
      d = new l(); 
    return d;
  }
  
  public void a(long paramLong, double paramDouble1, double paramDouble2) {
    float f2 = (float)(paramLong - 946728000000L) / 8.64E7F;
    float f1 = 0.01720197F * f2 + 6.24006F;
    double d2 = f1;
    double d1 = Math.sin(f1);
    Double.isNaN(d2);
    d1 = 1.796593063D + d2 + d1 * 0.03341960161924362D + Math.sin((2.0F * f1)) * 3.4906598739326E-4D + Math.sin((3.0F * f1)) * 5.236000106378924E-6D + Math.PI;
    paramDouble2 = -paramDouble2 / 360.0D;
    d2 = (f2 - 9.0E-4F);
    Double.isNaN(d2);
    d2 = (9.0E-4F + (float)Math.round(d2 - paramDouble2));
    Double.isNaN(d2);
    paramDouble2 = d2 + paramDouble2 + Math.sin(f1) * 0.0053D + Math.sin(2.0D * d1) * -0.0069D;
    d1 = Math.asin(Math.sin(d1) * Math.sin(0.4092797040939331D));
    paramDouble1 = 0.01745329238474369D * paramDouble1;
    paramDouble1 = (Math.sin(-0.10471975803375244D) - Math.sin(paramDouble1) * Math.sin(d1)) / Math.cos(paramDouble1) * Math.cos(d1);
    if (paramDouble1 >= 1.0D) {
      this.c = 1;
      this.a = -1L;
      this.b = -1L;
      return;
    } 
    if (paramDouble1 <= -1.0D) {
      this.c = 0;
      this.a = -1L;
      this.b = -1L;
      return;
    } 
    f1 = (float)(Math.acos(paramDouble1) / 6.283185307179586D);
    paramDouble1 = f1;
    Double.isNaN(paramDouble1);
    this.a = Math.round((paramDouble1 + paramDouble2) * 8.64E7D) + 946728000000L;
    paramDouble1 = f1;
    Double.isNaN(paramDouble1);
    this.b = Math.round((paramDouble2 - paramDouble1) * 8.64E7D) + 946728000000L;
    if (this.b < paramLong && this.a > paramLong) {
      this.c = 0;
    } else {
      this.c = 1;
    } 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\app\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */