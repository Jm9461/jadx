package android.support.v7.view.menu;

import android.content.Context;
import android.os.Parcelable;

public interface p {
  int a();
  
  void a(Context paramContext, h paramh);
  
  void a(Parcelable paramParcelable);
  
  void a(h paramh, boolean paramBoolean);
  
  void a(a parama);
  
  void a(boolean paramBoolean);
  
  boolean a(h paramh, k paramk);
  
  boolean a(v paramv);
  
  boolean b();
  
  boolean b(h paramh, k paramk);
  
  Parcelable c();
  
  public static interface a {
    void a(h param1h, boolean param1Boolean);
    
    boolean a(h param1h);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\view\menu\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */