package android.support.v7.view.menu;

public interface q {
  void a(h paramh);
  
  public static interface a {
    void a(k param1k, int param1Int);
    
    boolean a();
    
    k getItemData();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\view\menu\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */