package android.support.v7.view.menu;

import android.content.Context;
import android.graphics.Rect;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;

abstract class n implements t, p, AdapterView.OnItemClickListener {
  private Rect c;
  
  protected static int a(ListAdapter paramListAdapter, ViewGroup paramViewGroup, Context paramContext, int paramInt) {
    int i = 0;
    ViewGroup viewGroup2 = null;
    int j = 0;
    int m = View.MeasureSpec.makeMeasureSpec(0, 0);
    int k = View.MeasureSpec.makeMeasureSpec(0, 0);
    int i1 = paramListAdapter.getCount();
    byte b = 0;
    ViewGroup viewGroup1 = paramViewGroup;
    paramViewGroup = viewGroup2;
    while (b < i1) {
      FrameLayout frameLayout2;
      int i3 = paramListAdapter.getItemViewType(b);
      int i2 = j;
      if (i3 != j) {
        i2 = i3;
        paramViewGroup = null;
      } 
      viewGroup2 = viewGroup1;
      if (viewGroup1 == null)
        frameLayout2 = new FrameLayout(paramContext); 
      View view = paramListAdapter.getView(b, (View)paramViewGroup, (ViewGroup)frameLayout2);
      view.measure(m, k);
      i3 = view.getMeasuredWidth();
      if (i3 >= paramInt)
        return paramInt; 
      j = i;
      if (i3 > i)
        j = i3; 
      b++;
      i = j;
      j = i2;
      FrameLayout frameLayout1 = frameLayout2;
    } 
    return i;
  }
  
  protected static g a(ListAdapter paramListAdapter) {
    return (paramListAdapter instanceof HeaderViewListAdapter) ? (g)((HeaderViewListAdapter)paramListAdapter).getWrappedAdapter() : (g)paramListAdapter;
  }
  
  protected static boolean b(h paramh) {
    boolean bool1;
    boolean bool2 = false;
    int i = paramh.size();
    byte b = 0;
    while (true) {
      bool1 = bool2;
      if (b < i) {
        MenuItem menuItem = paramh.getItem(b);
        if (menuItem.isVisible() && menuItem.getIcon() != null) {
          bool1 = true;
          break;
        } 
        b++;
        continue;
      } 
      break;
    } 
    return bool1;
  }
  
  public int a() {
    return 0;
  }
  
  public abstract void a(int paramInt);
  
  public void a(Context paramContext, h paramh) {}
  
  public void a(Rect paramRect) {
    this.c = paramRect;
  }
  
  public abstract void a(h paramh);
  
  public abstract void a(View paramView);
  
  public abstract void a(PopupWindow.OnDismissListener paramOnDismissListener);
  
  public boolean a(h paramh, k paramk) {
    return false;
  }
  
  public abstract void b(int paramInt);
  
  public abstract void b(boolean paramBoolean);
  
  public boolean b(h paramh, k paramk) {
    return false;
  }
  
  public abstract void c(int paramInt);
  
  public abstract void c(boolean paramBoolean);
  
  protected boolean g() {
    return true;
  }
  
  public Rect h() {
    return this.c;
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    ListAdapter listAdapter = (ListAdapter)paramAdapterView.getAdapter();
    h h = (a(listAdapter)).c;
    MenuItem menuItem = (MenuItem)listAdapter.getItem(paramInt);
    if (g()) {
      paramInt = 0;
    } else {
      paramInt = 4;
    } 
    h.a(menuItem, this, paramInt);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\view\menu\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */