package android.support.v7.view.menu;

import android.content.Context;
import android.support.v7.widget.j1;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public final class ExpandedMenuView extends ListView implements h.b, q, AdapterView.OnItemClickListener {
  private static final int[] e = new int[] { 16842964, 16843049 };
  
  private h c;
  
  private int d;
  
  public ExpandedMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16842868);
  }
  
  public ExpandedMenuView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet);
    setOnItemClickListener(this);
    j1 j1 = j1.a(paramContext, paramAttributeSet, e, paramInt, 0);
    if (j1.g(0))
      setBackgroundDrawable(j1.b(0)); 
    if (j1.g(1))
      setDivider(j1.b(1)); 
    j1.a();
  }
  
  public void a(h paramh) {
    this.c = paramh;
  }
  
  public boolean a(k paramk) {
    return this.c.a((MenuItem)paramk, 0);
  }
  
  public int getWindowAnimations() {
    return this.d;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    setChildrenDrawingCacheEnabled(false);
  }
  
  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong) {
    a((k)getAdapter().getItem(paramInt));
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\view\menu\ExpandedMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */