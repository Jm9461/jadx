package android.support.v7.view.menu;

import a.b.g.b.a.b;
import a.b.g.g.a;
import android.content.Context;
import android.view.MenuItem;
import android.view.SubMenu;
import java.util.Iterator;
import java.util.Map;

abstract class c<T> extends d<T> {
  final Context b;
  
  private Map<b, MenuItem> c;
  
  private Map<a.b.g.b.a.c, SubMenu> d;
  
  c(Context paramContext, T paramT) {
    super(paramT);
    this.b = paramContext;
  }
  
  final MenuItem a(MenuItem paramMenuItem) {
    if (paramMenuItem instanceof b) {
      b b = (b)paramMenuItem;
      if (this.c == null)
        this.c = (Map<b, MenuItem>)new a(); 
      MenuItem menuItem = this.c.get(paramMenuItem);
      paramMenuItem = menuItem;
      if (menuItem == null) {
        paramMenuItem = r.a(this.b, b);
        this.c.put(b, paramMenuItem);
      } 
      return paramMenuItem;
    } 
    return paramMenuItem;
  }
  
  final SubMenu a(SubMenu paramSubMenu) {
    if (paramSubMenu instanceof a.b.g.b.a.c) {
      a.b.g.b.a.c c1 = (a.b.g.b.a.c)paramSubMenu;
      if (this.d == null)
        this.d = (Map<a.b.g.b.a.c, SubMenu>)new a(); 
      SubMenu subMenu = this.d.get(c1);
      paramSubMenu = subMenu;
      if (subMenu == null) {
        paramSubMenu = r.a(this.b, c1);
        this.d.put(c1, paramSubMenu);
      } 
      return paramSubMenu;
    } 
    return paramSubMenu;
  }
  
  final void a(int paramInt) {
    Map<b, MenuItem> map = this.c;
    if (map == null)
      return; 
    Iterator<MenuItem> iterator = map.keySet().iterator();
    while (iterator.hasNext()) {
      if (paramInt == ((MenuItem)iterator.next()).getGroupId())
        iterator.remove(); 
    } 
  }
  
  final void b() {
    Map<b, MenuItem> map1 = this.c;
    if (map1 != null)
      map1.clear(); 
    Map<a.b.g.b.a.c, SubMenu> map = this.d;
    if (map != null)
      map.clear(); 
  }
  
  final void b(int paramInt) {
    Map<b, MenuItem> map = this.c;
    if (map == null)
      return; 
    Iterator<MenuItem> iterator = map.keySet().iterator();
    while (iterator.hasNext()) {
      if (paramInt == ((MenuItem)iterator.next()).getItemId()) {
        iterator.remove();
        break;
      } 
    } 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\view\menu\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */