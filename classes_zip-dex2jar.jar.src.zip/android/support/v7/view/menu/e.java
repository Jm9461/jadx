package android.support.v7.view.menu;

import a.b.h.a.g;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Parcelable;
import android.os.SystemClock;
import android.support.v4.view.u;
import android.support.v7.widget.q0;
import android.support.v7.widget.r0;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

final class e extends n implements p, View.OnKeyListener, PopupWindow.OnDismissListener {
  private static final int D = g.abc_cascading_menu_item_layout;
  
  ViewTreeObserver A;
  
  private PopupWindow.OnDismissListener B;
  
  boolean C;
  
  private final Context d;
  
  private final int e;
  
  private final int f;
  
  private final int g;
  
  private final boolean h;
  
  final Handler i;
  
  private final List<h> j = new ArrayList<h>();
  
  final List<d> k = new ArrayList<d>();
  
  final ViewTreeObserver.OnGlobalLayoutListener l = new a(this);
  
  private final View.OnAttachStateChangeListener m = new b(this);
  
  private final q0 n = new c(this);
  
  private int o = 0;
  
  private int p = 0;
  
  private View q;
  
  View r;
  
  private int s;
  
  private boolean t;
  
  private boolean u;
  
  private int v;
  
  private int w;
  
  private boolean x;
  
  private boolean y;
  
  private p.a z;
  
  public e(Context paramContext, View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    this.d = paramContext;
    this.q = paramView;
    this.f = paramInt1;
    this.g = paramInt2;
    this.h = paramBoolean;
    this.x = false;
    this.s = j();
    Resources resources = paramContext.getResources();
    this.e = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(a.b.h.a.d.abc_config_prefDialogWidth));
    this.i = new Handler();
  }
  
  private MenuItem a(h paramh1, h paramh2) {
    byte b = 0;
    int i = paramh1.size();
    while (b < i) {
      MenuItem menuItem = paramh1.getItem(b);
      if (menuItem.hasSubMenu() && paramh2 == menuItem.getSubMenu())
        return menuItem; 
      b++;
    } 
    return null;
  }
  
  private View a(d paramd, h paramh) {
    g g;
    byte b;
    int j;
    MenuItem menuItem = a(paramd.b, paramh);
    if (menuItem == null)
      return null; 
    ListView listView = paramd.a();
    ListAdapter listAdapter = listView.getAdapter();
    if (listAdapter instanceof HeaderViewListAdapter) {
      HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter)listAdapter;
      b = headerViewListAdapter.getHeadersCount();
      g = (g)headerViewListAdapter.getWrappedAdapter();
    } else {
      b = 0;
      g = g;
    } 
    byte b1 = -1;
    int i = 0;
    int k = g.getCount();
    while (true) {
      j = b1;
      if (i < k) {
        if (menuItem == g.getItem(i)) {
          j = i;
          break;
        } 
        i++;
        continue;
      } 
      break;
    } 
    if (j == -1)
      return null; 
    i = j + b - listView.getFirstVisiblePosition();
    return (i < 0 || i >= listView.getChildCount()) ? null : listView.getChildAt(i);
  }
  
  private int c(h paramh) {
    byte b = 0;
    int i = this.k.size();
    while (b < i) {
      if (paramh == ((d)this.k.get(b)).b)
        return b; 
      b++;
    } 
    return -1;
  }
  
  private int d(int paramInt) {
    List<d> list = this.k;
    ListView listView = ((d)list.get(list.size() - 1)).a();
    int[] arrayOfInt = new int[2];
    listView.getLocationOnScreen(arrayOfInt);
    Rect rect = new Rect();
    this.r.getWindowVisibleDisplayFrame(rect);
    return (this.s == 1) ? ((arrayOfInt[0] + listView.getWidth() + paramInt > rect.right) ? 0 : 1) : ((arrayOfInt[0] - paramInt < 0) ? 1 : 0);
  }
  
  private void d(h paramh) {
    View view;
    LayoutInflater layoutInflater = LayoutInflater.from(this.d);
    g g = new g(paramh, layoutInflater, this.h, D);
    if (!e() && this.x) {
      g.a(true);
    } else if (e()) {
      g.a(n.b(paramh));
    } 
    int i = n.a((ListAdapter)g, null, this.d, this.e);
    r0 r0 = i();
    r0.a((ListAdapter)g);
    r0.b(i);
    r0.c(this.p);
    if (this.k.size() > 0) {
      List<d> list = this.k;
      d d1 = list.get(list.size() - 1);
      view = a(d1, paramh);
    } else {
      g = null;
      view = null;
    } 
    if (view != null) {
      int j;
      int m;
      r0.c(false);
      r0.a(null);
      int k = d(i);
      if (k == 1) {
        j = 1;
      } else {
        j = 0;
      } 
      this.s = k;
      if (Build.VERSION.SDK_INT >= 26) {
        r0.a(view);
        m = 0;
        k = 0;
      } else {
        int[] arrayOfInt1 = new int[2];
        this.q.getLocationOnScreen(arrayOfInt1);
        int[] arrayOfInt2 = new int[2];
        view.getLocationOnScreen(arrayOfInt2);
        if ((this.p & 0x7) == 5) {
          arrayOfInt1[0] = arrayOfInt1[0] + this.q.getWidth();
          arrayOfInt2[0] = arrayOfInt2[0] + view.getWidth();
        } 
        m = arrayOfInt2[0] - arrayOfInt1[0];
        k = arrayOfInt2[1] - arrayOfInt1[1];
      } 
      if ((this.p & 0x5) == 5) {
        if (j) {
          j = m + i;
        } else {
          j = m - view.getWidth();
        } 
      } else if (j != 0) {
        j = view.getWidth() + m;
      } else {
        j = m - i;
      } 
      r0.d(j);
      r0.b(true);
      r0.h(k);
    } else {
      if (this.t)
        r0.d(this.v); 
      if (this.u)
        r0.h(this.w); 
      r0.a(h());
    } 
    d d = new d(r0, paramh, this.s);
    this.k.add(d);
    r0.d();
    ListView listView = r0.f();
    listView.setOnKeyListener(this);
    if (g == null && this.y && paramh.h() != null) {
      FrameLayout frameLayout = (FrameLayout)layoutInflater.inflate(g.abc_popup_menu_header_item_layout, (ViewGroup)listView, false);
      TextView textView = (TextView)frameLayout.findViewById(16908310);
      frameLayout.setEnabled(false);
      textView.setText(paramh.h());
      listView.addHeaderView((View)frameLayout, null, false);
      r0.d();
    } 
  }
  
  private r0 i() {
    r0 r0 = new r0(this.d, null, this.f, this.g);
    r0.a(this.n);
    r0.a(this);
    r0.a(this);
    r0.a(this.q);
    r0.c(this.p);
    r0.a(true);
    r0.e(2);
    return r0;
  }
  
  private int j() {
    int i = u.k(this.q);
    boolean bool = true;
    if (i == 1)
      bool = false; 
    return bool;
  }
  
  public void a(int paramInt) {
    if (this.o != paramInt) {
      this.o = paramInt;
      this.p = android.support.v4.view.d.a(paramInt, u.k(this.q));
    } 
  }
  
  public void a(Parcelable paramParcelable) {}
  
  public void a(h paramh) {
    paramh.a(this, this.d);
    if (e()) {
      d(paramh);
    } else {
      this.j.add(paramh);
    } 
  }
  
  public void a(h paramh, boolean paramBoolean) {
    int i = c(paramh);
    if (i < 0)
      return; 
    int j = i + 1;
    if (j < this.k.size())
      ((d)this.k.get(j)).b.a(false); 
    d d = this.k.remove(i);
    d.b.b(this);
    if (this.C) {
      d.a.b(null);
      d.a.a(0);
    } 
    d.a.dismiss();
    i = this.k.size();
    if (i > 0) {
      this.s = ((d)this.k.get(i - 1)).c;
    } else {
      this.s = j();
    } 
    if (i == 0) {
      dismiss();
      p.a a1 = this.z;
      if (a1 != null)
        a1.a(paramh, true); 
      ViewTreeObserver viewTreeObserver = this.A;
      if (viewTreeObserver != null) {
        if (viewTreeObserver.isAlive())
          this.A.removeGlobalOnLayoutListener(this.l); 
        this.A = null;
      } 
      this.r.removeOnAttachStateChangeListener(this.m);
      this.B.onDismiss();
    } else if (paramBoolean) {
      ((d)this.k.get(0)).b.a(false);
    } 
  }
  
  public void a(p.a parama) {
    this.z = parama;
  }
  
  public void a(View paramView) {
    if (this.q != paramView) {
      this.q = paramView;
      this.p = android.support.v4.view.d.a(this.o, u.k(this.q));
    } 
  }
  
  public void a(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.B = paramOnDismissListener;
  }
  
  public void a(boolean paramBoolean) {
    Iterator<d> iterator = this.k.iterator();
    while (iterator.hasNext())
      n.a(((d)iterator.next()).a().getAdapter()).notifyDataSetChanged(); 
  }
  
  public boolean a(v paramv) {
    for (d d : this.k) {
      if (paramv == d.b) {
        d.a().requestFocus();
        return true;
      } 
    } 
    if (paramv.hasVisibleItems()) {
      a(paramv);
      p.a a1 = this.z;
      if (a1 != null)
        a1.a(paramv); 
      return true;
    } 
    return false;
  }
  
  public void b(int paramInt) {
    this.t = true;
    this.v = paramInt;
  }
  
  public void b(boolean paramBoolean) {
    this.x = paramBoolean;
  }
  
  public boolean b() {
    return false;
  }
  
  public Parcelable c() {
    return null;
  }
  
  public void c(int paramInt) {
    this.u = true;
    this.w = paramInt;
  }
  
  public void c(boolean paramBoolean) {
    this.y = paramBoolean;
  }
  
  public void d() {
    if (e())
      return; 
    Iterator<h> iterator = this.j.iterator();
    while (iterator.hasNext())
      d(iterator.next()); 
    this.j.clear();
    this.r = this.q;
    if (this.r != null) {
      boolean bool;
      if (this.A == null) {
        bool = true;
      } else {
        bool = false;
      } 
      this.A = this.r.getViewTreeObserver();
      if (bool)
        this.A.addOnGlobalLayoutListener(this.l); 
      this.r.addOnAttachStateChangeListener(this.m);
    } 
  }
  
  public void dismiss() {
    int i = this.k.size();
    if (i > 0) {
      d[] arrayOfD = this.k.<d>toArray(new d[i]);
      while (--i >= 0) {
        d d = arrayOfD[i];
        if (d.a.e())
          d.a.dismiss(); 
        i--;
      } 
    } 
  }
  
  public boolean e() {
    int i = this.k.size();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i > 0) {
      bool1 = bool2;
      if (((d)this.k.get(0)).a.e())
        bool1 = true; 
    } 
    return bool1;
  }
  
  public ListView f() {
    ListView listView;
    if (this.k.isEmpty()) {
      listView = null;
    } else {
      List<d> list = this.k;
      listView = ((d)list.get(list.size() - 1)).a();
    } 
    return listView;
  }
  
  protected boolean g() {
    return false;
  }
  
  public void onDismiss() {
    d d1;
    d d2 = null;
    byte b = 0;
    int i = this.k.size();
    while (true) {
      d1 = d2;
      if (b < i) {
        d1 = this.k.get(b);
        if (!d1.a.e())
          break; 
        b++;
        continue;
      } 
      break;
    } 
    if (d1 != null)
      d1.b.a(false); 
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1 && paramInt == 82) {
      dismiss();
      return true;
    } 
    return false;
  }
  
  class a implements ViewTreeObserver.OnGlobalLayoutListener {
    final e c;
    
    a(e this$0) {}
    
    public void onGlobalLayout() {
      if (this.c.e() && this.c.k.size() > 0 && !((e.d)this.c.k.get(0)).a.k()) {
        View view = this.c.r;
        if (view == null || !view.isShown()) {
          this.c.dismiss();
          return;
        } 
        Iterator<e.d> iterator = this.c.k.iterator();
        while (iterator.hasNext())
          ((e.d)iterator.next()).a.d(); 
      } 
    }
  }
  
  class b implements View.OnAttachStateChangeListener {
    final e c;
    
    b(e this$0) {}
    
    public void onViewAttachedToWindow(View param1View) {}
    
    public void onViewDetachedFromWindow(View param1View) {
      ViewTreeObserver viewTreeObserver = this.c.A;
      if (viewTreeObserver != null) {
        if (!viewTreeObserver.isAlive())
          this.c.A = param1View.getViewTreeObserver(); 
        e e1 = this.c;
        e1.A.removeGlobalOnLayoutListener(e1.l);
      } 
      param1View.removeOnAttachStateChangeListener(this);
    }
  }
  
  class c implements q0 {
    final e c;
    
    c(e this$0) {}
    
    public void a(h param1h, MenuItem param1MenuItem) {
      int j;
      e.d d;
      this.c.i.removeCallbacksAndMessages(null);
      byte b = -1;
      int i = 0;
      int k = this.c.k.size();
      while (true) {
        j = b;
        if (i < k) {
          if (param1h == ((e.d)this.c.k.get(i)).b) {
            j = i;
            break;
          } 
          i++;
          continue;
        } 
        break;
      } 
      if (j == -1)
        return; 
      i = j + 1;
      if (i < this.c.k.size()) {
        d = this.c.k.get(i);
      } else {
        d = null;
      } 
      a a = new a(this, d, param1MenuItem, param1h);
      long l = SystemClock.uptimeMillis();
      this.c.i.postAtTime(a, param1h, l + 200L);
    }
    
    public void b(h param1h, MenuItem param1MenuItem) {
      this.c.i.removeCallbacksAndMessages(param1h);
    }
    
    class a implements Runnable {
      final e.d c;
      
      final MenuItem d;
      
      final h e;
      
      final e.c f;
      
      a(e.c this$0, e.d param2d, MenuItem param2MenuItem, h param2h) {}
      
      public void run() {
        e.d d1 = this.c;
        if (d1 != null) {
          this.f.c.C = true;
          d1.b.a(false);
          this.f.c.C = false;
        } 
        if (this.d.isEnabled() && this.d.hasSubMenu())
          this.e.a(this.d, 4); 
      }
    }
  }
  
  class a implements Runnable {
    final e.d c;
    
    final MenuItem d;
    
    final h e;
    
    final e.c f;
    
    a(e this$0, e.d param1d, MenuItem param1MenuItem, h param1h) {}
    
    public void run() {
      e.d d1 = this.c;
      if (d1 != null) {
        this.f.c.C = true;
        d1.b.a(false);
        this.f.c.C = false;
      } 
      if (this.d.isEnabled() && this.d.hasSubMenu())
        this.e.a(this.d, 4); 
    }
  }
  
  private static class d {
    public final r0 a;
    
    public final h b;
    
    public final int c;
    
    public d(r0 param1r0, h param1h, int param1Int) {
      this.a = param1r0;
      this.b = param1h;
      this.c = param1Int;
    }
    
    public ListView a() {
      return this.a.f();
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\view\menu\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */