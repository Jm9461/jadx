package android.support.v7.view.menu;

class d<T> {
  final T a;
  
  d(T paramT) {
    if (paramT != null) {
      this.a = paramT;
      return;
    } 
    throw new IllegalArgumentException("Wrapped Object can not be null.");
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\view\menu\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */