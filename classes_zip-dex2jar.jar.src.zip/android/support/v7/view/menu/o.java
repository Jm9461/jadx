package android.support.v7.view.menu;

import a.b.h.a.d;
import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Build;
import android.support.v4.view.d;
import android.support.v4.view.u;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;

public class o implements j {
  private final Context a;
  
  private final h b;
  
  private final boolean c;
  
  private final int d;
  
  private final int e;
  
  private View f;
  
  private int g = 8388611;
  
  private boolean h;
  
  private p.a i;
  
  private n j;
  
  private PopupWindow.OnDismissListener k;
  
  private final PopupWindow.OnDismissListener l = new a(this);
  
  public o(Context paramContext, h paramh, View paramView, boolean paramBoolean, int paramInt) {
    this(paramContext, paramh, paramView, paramBoolean, paramInt, 0);
  }
  
  public o(Context paramContext, h paramh, View paramView, boolean paramBoolean, int paramInt1, int paramInt2) {
    this.a = paramContext;
    this.b = paramh;
    this.f = paramView;
    this.c = paramBoolean;
    this.d = paramInt1;
    this.e = paramInt2;
  }
  
  private void a(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    n n1 = b();
    n1.c(paramBoolean2);
    if (paramBoolean1) {
      int i = paramInt1;
      if ((d.a(this.g, u.k(this.f)) & 0x7) == 5)
        i = paramInt1 - this.f.getWidth(); 
      n1.b(i);
      n1.c(paramInt2);
      paramInt1 = (int)(48.0F * (this.a.getResources().getDisplayMetrics()).density / 2.0F);
      n1.a(new Rect(i - paramInt1, paramInt2 - paramInt1, i + paramInt1, paramInt2 + paramInt1));
    } 
    n1.d();
  }
  
  private n g() {
    boolean bool;
    u u;
    Display display = ((WindowManager)this.a.getSystemService("window")).getDefaultDisplay();
    Point point = new Point();
    if (Build.VERSION.SDK_INT >= 17) {
      display.getRealSize(point);
    } else {
      display.getSize(point);
    } 
    if (Math.min(point.x, point.y) >= this.a.getResources().getDimensionPixelSize(d.abc_cascading_menus_min_smallest_width)) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      e e = new e(this.a, this.f, this.d, this.e, this.c);
    } else {
      u = new u(this.a, this.b, this.f, this.d, this.e, this.c);
    } 
    u.a(this.b);
    u.a(this.l);
    u.a(this.f);
    u.a(this.i);
    u.b(this.h);
    u.a(this.g);
    return u;
  }
  
  public void a() {
    if (c())
      this.j.dismiss(); 
  }
  
  public void a(int paramInt) {
    this.g = paramInt;
  }
  
  public void a(p.a parama) {
    this.i = parama;
    n n1 = this.j;
    if (n1 != null)
      n1.a(parama); 
  }
  
  public void a(View paramView) {
    this.f = paramView;
  }
  
  public void a(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.k = paramOnDismissListener;
  }
  
  public void a(boolean paramBoolean) {
    this.h = paramBoolean;
    n n1 = this.j;
    if (n1 != null)
      n1.b(paramBoolean); 
  }
  
  public boolean a(int paramInt1, int paramInt2) {
    if (c())
      return true; 
    if (this.f == null)
      return false; 
    a(paramInt1, paramInt2, true, true);
    return true;
  }
  
  public n b() {
    if (this.j == null)
      this.j = g(); 
    return this.j;
  }
  
  public boolean c() {
    boolean bool;
    n n1 = this.j;
    if (n1 != null && n1.e()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  protected void d() {
    this.j = null;
    PopupWindow.OnDismissListener onDismissListener = this.k;
    if (onDismissListener != null)
      onDismissListener.onDismiss(); 
  }
  
  public void e() {
    if (f())
      return; 
    throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
  }
  
  public boolean f() {
    if (c())
      return true; 
    if (this.f == null)
      return false; 
    a(0, 0, false, false);
    return true;
  }
  
  class a implements PopupWindow.OnDismissListener {
    final o c;
    
    a(o this$0) {}
    
    public void onDismiss() {
      this.c.d();
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\view\menu\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */