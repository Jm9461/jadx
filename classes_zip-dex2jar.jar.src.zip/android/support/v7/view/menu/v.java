package android.support.v7.view.menu;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

public class v extends h implements SubMenu {
  private h B;
  
  private k C;
  
  public v(Context paramContext, h paramh, k paramk) {
    super(paramContext);
    this.B = paramh;
    this.C = paramk;
  }
  
  public void a(h.a parama) {
    this.B.a(parama);
  }
  
  boolean a(h paramh, MenuItem paramMenuItem) {
    return (super.a(paramh, paramMenuItem) || this.B.a(paramh, paramMenuItem));
  }
  
  public boolean a(k paramk) {
    return this.B.a(paramk);
  }
  
  public boolean b(k paramk) {
    return this.B.b(paramk);
  }
  
  public String d() {
    boolean bool;
    k k1 = this.C;
    if (k1 != null) {
      bool = k1.getItemId();
    } else {
      bool = false;
    } 
    if (!bool)
      return null; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(super.d());
    stringBuilder.append(":");
    stringBuilder.append(bool);
    return stringBuilder.toString();
  }
  
  public MenuItem getItem() {
    return (MenuItem)this.C;
  }
  
  public h m() {
    return this.B.m();
  }
  
  public boolean o() {
    return this.B.o();
  }
  
  public boolean p() {
    return this.B.p();
  }
  
  public boolean q() {
    return this.B.q();
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    this.B.setGroupDividerEnabled(paramBoolean);
  }
  
  public SubMenu setHeaderIcon(int paramInt) {
    d(paramInt);
    return this;
  }
  
  public SubMenu setHeaderIcon(Drawable paramDrawable) {
    a(paramDrawable);
    return this;
  }
  
  public SubMenu setHeaderTitle(int paramInt) {
    e(paramInt);
    return this;
  }
  
  public SubMenu setHeaderTitle(CharSequence paramCharSequence) {
    a(paramCharSequence);
    return this;
  }
  
  public SubMenu setHeaderView(View paramView) {
    a(paramView);
    return this;
  }
  
  public SubMenu setIcon(int paramInt) {
    this.C.setIcon(paramInt);
    return this;
  }
  
  public SubMenu setIcon(Drawable paramDrawable) {
    this.C.setIcon(paramDrawable);
    return this;
  }
  
  public void setQwertyMode(boolean paramBoolean) {
    this.B.setQwertyMode(paramBoolean);
  }
  
  public Menu t() {
    return (Menu)this.B;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\view\menu\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */