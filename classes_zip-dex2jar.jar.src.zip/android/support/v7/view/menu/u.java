package android.support.v7.view.menu;

import a.b.h.a.d;
import a.b.h.a.g;
import android.content.Context;
import android.content.res.Resources;
import android.os.Parcelable;
import android.support.v7.widget.r0;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

final class u extends n implements PopupWindow.OnDismissListener, AdapterView.OnItemClickListener, p, View.OnKeyListener {
  private static final int x = g.abc_popup_menu_item_layout;
  
  private final Context d;
  
  private final h e;
  
  private final g f;
  
  private final boolean g;
  
  private final int h;
  
  private final int i;
  
  private final int j;
  
  final r0 k;
  
  final ViewTreeObserver.OnGlobalLayoutListener l = new a(this);
  
  private final View.OnAttachStateChangeListener m = new b(this);
  
  private PopupWindow.OnDismissListener n;
  
  private View o;
  
  View p;
  
  private p.a q;
  
  ViewTreeObserver r;
  
  private boolean s;
  
  private boolean t;
  
  private int u;
  
  private int v = 0;
  
  private boolean w;
  
  public u(Context paramContext, h paramh, View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    this.d = paramContext;
    this.e = paramh;
    this.g = paramBoolean;
    this.f = new g(paramh, LayoutInflater.from(paramContext), this.g, x);
    this.i = paramInt1;
    this.j = paramInt2;
    Resources resources = paramContext.getResources();
    this.h = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(d.abc_config_prefDialogWidth));
    this.o = paramView;
    this.k = new r0(this.d, null, this.i, this.j);
    paramh.a(this, paramContext);
  }
  
  private boolean i() {
    if (e())
      return true; 
    if (!this.s) {
      View view = this.o;
      if (view != null) {
        boolean bool;
        this.p = view;
        this.k.a(this);
        this.k.a(this);
        this.k.a(true);
        view = this.p;
        if (this.r == null) {
          bool = true;
        } else {
          bool = false;
        } 
        this.r = view.getViewTreeObserver();
        if (bool)
          this.r.addOnGlobalLayoutListener(this.l); 
        view.addOnAttachStateChangeListener(this.m);
        this.k.a(view);
        this.k.c(this.v);
        if (!this.t) {
          this.u = n.a((ListAdapter)this.f, null, this.d, this.h);
          this.t = true;
        } 
        this.k.b(this.u);
        this.k.e(2);
        this.k.a(h());
        this.k.d();
        ListView listView = this.k.f();
        listView.setOnKeyListener(this);
        if (this.w && this.e.h() != null) {
          FrameLayout frameLayout = (FrameLayout)LayoutInflater.from(this.d).inflate(g.abc_popup_menu_header_item_layout, (ViewGroup)listView, false);
          TextView textView = (TextView)frameLayout.findViewById(16908310);
          if (textView != null)
            textView.setText(this.e.h()); 
          frameLayout.setEnabled(false);
          listView.addHeaderView((View)frameLayout, null, false);
        } 
        this.k.a((ListAdapter)this.f);
        this.k.d();
        return true;
      } 
    } 
    return false;
  }
  
  public void a(int paramInt) {
    this.v = paramInt;
  }
  
  public void a(Parcelable paramParcelable) {}
  
  public void a(h paramh) {}
  
  public void a(h paramh, boolean paramBoolean) {
    if (paramh != this.e)
      return; 
    dismiss();
    p.a a1 = this.q;
    if (a1 != null)
      a1.a(paramh, paramBoolean); 
  }
  
  public void a(p.a parama) {
    this.q = parama;
  }
  
  public void a(View paramView) {
    this.o = paramView;
  }
  
  public void a(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.n = paramOnDismissListener;
  }
  
  public void a(boolean paramBoolean) {
    this.t = false;
    g g1 = this.f;
    if (g1 != null)
      g1.notifyDataSetChanged(); 
  }
  
  public boolean a(v paramv) {
    if (paramv.hasVisibleItems()) {
      o o = new o(this.d, paramv, this.p, this.g, this.i, this.j);
      o.a(this.q);
      o.a(n.b(paramv));
      o.a(this.n);
      this.n = null;
      this.e.a(false);
      int j = this.k.g();
      int k = this.k.h();
      int i = j;
      if ((Gravity.getAbsoluteGravity(this.v, android.support.v4.view.u.k(this.o)) & 0x7) == 5)
        i = j + this.o.getWidth(); 
      if (o.a(i, k)) {
        p.a a1 = this.q;
        if (a1 != null)
          a1.a(paramv); 
        return true;
      } 
    } 
    return false;
  }
  
  public void b(int paramInt) {
    this.k.d(paramInt);
  }
  
  public void b(boolean paramBoolean) {
    this.f.a(paramBoolean);
  }
  
  public boolean b() {
    return false;
  }
  
  public Parcelable c() {
    return null;
  }
  
  public void c(int paramInt) {
    this.k.h(paramInt);
  }
  
  public void c(boolean paramBoolean) {
    this.w = paramBoolean;
  }
  
  public void d() {
    if (i())
      return; 
    throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
  }
  
  public void dismiss() {
    if (e())
      this.k.dismiss(); 
  }
  
  public boolean e() {
    boolean bool;
    if (!this.s && this.k.e()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public ListView f() {
    return this.k.f();
  }
  
  public void onDismiss() {
    this.s = true;
    this.e.close();
    ViewTreeObserver viewTreeObserver = this.r;
    if (viewTreeObserver != null) {
      if (!viewTreeObserver.isAlive())
        this.r = this.p.getViewTreeObserver(); 
      this.r.removeGlobalOnLayoutListener(this.l);
      this.r = null;
    } 
    this.p.removeOnAttachStateChangeListener(this.m);
    PopupWindow.OnDismissListener onDismissListener = this.n;
    if (onDismissListener != null)
      onDismissListener.onDismiss(); 
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1 && paramInt == 82) {
      dismiss();
      return true;
    } 
    return false;
  }
  
  class a implements ViewTreeObserver.OnGlobalLayoutListener {
    final u c;
    
    a(u this$0) {}
    
    public void onGlobalLayout() {
      if (this.c.e() && !this.c.k.k()) {
        View view = this.c.p;
        if (view == null || !view.isShown()) {
          this.c.dismiss();
          return;
        } 
        this.c.k.d();
      } 
    }
  }
  
  class b implements View.OnAttachStateChangeListener {
    final u c;
    
    b(u this$0) {}
    
    public void onViewAttachedToWindow(View param1View) {}
    
    public void onViewDetachedFromWindow(View param1View) {
      ViewTreeObserver viewTreeObserver = this.c.r;
      if (viewTreeObserver != null) {
        if (!viewTreeObserver.isAlive())
          this.c.r = param1View.getViewTreeObserver(); 
        u u1 = this.c;
        u1.r.removeGlobalOnLayoutListener(u1.l);
      } 
      param1View.removeOnAttachStateChangeListener(this);
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\view\men\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */