package android.support.v7.view.menu;

import a.b.g.b.a.b;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.ActionProvider;
import android.view.CollapsibleActionView;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.FrameLayout;
import java.lang.reflect.Method;

public class l extends c<b> implements MenuItem {
  private Method e;
  
  l(Context paramContext, b paramb) {
    super(paramContext, paramb);
  }
  
  a a(ActionProvider paramActionProvider) {
    return new a(this, this.b, paramActionProvider);
  }
  
  public void a(boolean paramBoolean) {
    try {
      if (this.e == null)
        this.e = ((b)this.a).getClass().getDeclaredMethod("setExclusiveCheckable", new Class[] { boolean.class }); 
      this.e.invoke(this.a, new Object[] { Boolean.valueOf(paramBoolean) });
    } catch (Exception exception) {
      Log.w("MenuItemWrapper", "Error while calling setExclusiveCheckable", exception);
    } 
  }
  
  public boolean collapseActionView() {
    return ((b)this.a).collapseActionView();
  }
  
  public boolean expandActionView() {
    return ((b)this.a).expandActionView();
  }
  
  public ActionProvider getActionProvider() {
    android.support.v4.view.c c1 = ((b)this.a).a();
    return (c1 instanceof a) ? ((a)c1).b : null;
  }
  
  public View getActionView() {
    View view = ((b)this.a).getActionView();
    return (view instanceof b) ? ((b)view).a() : view;
  }
  
  public int getAlphabeticModifiers() {
    return ((b)this.a).getAlphabeticModifiers();
  }
  
  public char getAlphabeticShortcut() {
    return ((b)this.a).getAlphabeticShortcut();
  }
  
  public CharSequence getContentDescription() {
    return ((b)this.a).getContentDescription();
  }
  
  public int getGroupId() {
    return ((b)this.a).getGroupId();
  }
  
  public Drawable getIcon() {
    return ((b)this.a).getIcon();
  }
  
  public ColorStateList getIconTintList() {
    return ((b)this.a).getIconTintList();
  }
  
  public PorterDuff.Mode getIconTintMode() {
    return ((b)this.a).getIconTintMode();
  }
  
  public Intent getIntent() {
    return ((b)this.a).getIntent();
  }
  
  public int getItemId() {
    return ((b)this.a).getItemId();
  }
  
  public ContextMenu.ContextMenuInfo getMenuInfo() {
    return ((b)this.a).getMenuInfo();
  }
  
  public int getNumericModifiers() {
    return ((b)this.a).getNumericModifiers();
  }
  
  public char getNumericShortcut() {
    return ((b)this.a).getNumericShortcut();
  }
  
  public int getOrder() {
    return ((b)this.a).getOrder();
  }
  
  public SubMenu getSubMenu() {
    return a(((b)this.a).getSubMenu());
  }
  
  public CharSequence getTitle() {
    return ((b)this.a).getTitle();
  }
  
  public CharSequence getTitleCondensed() {
    return ((b)this.a).getTitleCondensed();
  }
  
  public CharSequence getTooltipText() {
    return ((b)this.a).getTooltipText();
  }
  
  public boolean hasSubMenu() {
    return ((b)this.a).hasSubMenu();
  }
  
  public boolean isActionViewExpanded() {
    return ((b)this.a).isActionViewExpanded();
  }
  
  public boolean isCheckable() {
    return ((b)this.a).isCheckable();
  }
  
  public boolean isChecked() {
    return ((b)this.a).isChecked();
  }
  
  public boolean isEnabled() {
    return ((b)this.a).isEnabled();
  }
  
  public boolean isVisible() {
    return ((b)this.a).isVisible();
  }
  
  public MenuItem setActionProvider(ActionProvider paramActionProvider) {
    b b = (b)this.a;
    if (paramActionProvider != null) {
      a a = a(paramActionProvider);
    } else {
      paramActionProvider = null;
    } 
    b.a((android.support.v4.view.c)paramActionProvider);
    return this;
  }
  
  public MenuItem setActionView(int paramInt) {
    ((b)this.a).setActionView(paramInt);
    View view = ((b)this.a).getActionView();
    if (view instanceof CollapsibleActionView)
      ((b)this.a).setActionView((View)new b(view)); 
    return this;
  }
  
  public MenuItem setActionView(View paramView) {
    b b;
    View view = paramView;
    if (paramView instanceof CollapsibleActionView)
      b = new b(paramView); 
    ((b)this.a).setActionView((View)b);
    return this;
  }
  
  public MenuItem setAlphabeticShortcut(char paramChar) {
    ((b)this.a).setAlphabeticShortcut(paramChar);
    return this;
  }
  
  public MenuItem setAlphabeticShortcut(char paramChar, int paramInt) {
    ((b)this.a).setAlphabeticShortcut(paramChar, paramInt);
    return this;
  }
  
  public MenuItem setCheckable(boolean paramBoolean) {
    ((b)this.a).setCheckable(paramBoolean);
    return this;
  }
  
  public MenuItem setChecked(boolean paramBoolean) {
    ((b)this.a).setChecked(paramBoolean);
    return this;
  }
  
  public MenuItem setContentDescription(CharSequence paramCharSequence) {
    ((b)this.a).setContentDescription(paramCharSequence);
    return this;
  }
  
  public MenuItem setEnabled(boolean paramBoolean) {
    ((b)this.a).setEnabled(paramBoolean);
    return this;
  }
  
  public MenuItem setIcon(int paramInt) {
    ((b)this.a).setIcon(paramInt);
    return this;
  }
  
  public MenuItem setIcon(Drawable paramDrawable) {
    ((b)this.a).setIcon(paramDrawable);
    return this;
  }
  
  public MenuItem setIconTintList(ColorStateList paramColorStateList) {
    ((b)this.a).setIconTintList(paramColorStateList);
    return this;
  }
  
  public MenuItem setIconTintMode(PorterDuff.Mode paramMode) {
    ((b)this.a).setIconTintMode(paramMode);
    return this;
  }
  
  public MenuItem setIntent(Intent paramIntent) {
    ((b)this.a).setIntent(paramIntent);
    return this;
  }
  
  public MenuItem setNumericShortcut(char paramChar) {
    ((b)this.a).setNumericShortcut(paramChar);
    return this;
  }
  
  public MenuItem setNumericShortcut(char paramChar, int paramInt) {
    ((b)this.a).setNumericShortcut(paramChar, paramInt);
    return this;
  }
  
  public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener paramOnActionExpandListener) {
    b b = (b)this.a;
    if (paramOnActionExpandListener != null) {
      paramOnActionExpandListener = new c(this, paramOnActionExpandListener);
    } else {
      paramOnActionExpandListener = null;
    } 
    b.setOnActionExpandListener(paramOnActionExpandListener);
    return this;
  }
  
  public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener paramOnMenuItemClickListener) {
    b b = (b)this.a;
    if (paramOnMenuItemClickListener != null) {
      paramOnMenuItemClickListener = new d(this, paramOnMenuItemClickListener);
    } else {
      paramOnMenuItemClickListener = null;
    } 
    b.setOnMenuItemClickListener(paramOnMenuItemClickListener);
    return this;
  }
  
  public MenuItem setShortcut(char paramChar1, char paramChar2) {
    ((b)this.a).setShortcut(paramChar1, paramChar2);
    return this;
  }
  
  public MenuItem setShortcut(char paramChar1, char paramChar2, int paramInt1, int paramInt2) {
    ((b)this.a).setShortcut(paramChar1, paramChar2, paramInt1, paramInt2);
    return this;
  }
  
  public void setShowAsAction(int paramInt) {
    ((b)this.a).setShowAsAction(paramInt);
  }
  
  public MenuItem setShowAsActionFlags(int paramInt) {
    ((b)this.a).setShowAsActionFlags(paramInt);
    return this;
  }
  
  public MenuItem setTitle(int paramInt) {
    ((b)this.a).setTitle(paramInt);
    return this;
  }
  
  public MenuItem setTitle(CharSequence paramCharSequence) {
    ((b)this.a).setTitle(paramCharSequence);
    return this;
  }
  
  public MenuItem setTitleCondensed(CharSequence paramCharSequence) {
    ((b)this.a).setTitleCondensed(paramCharSequence);
    return this;
  }
  
  public MenuItem setTooltipText(CharSequence paramCharSequence) {
    ((b)this.a).setTooltipText(paramCharSequence);
    return this;
  }
  
  public MenuItem setVisible(boolean paramBoolean) {
    return ((b)this.a).setVisible(paramBoolean);
  }
  
  class a extends android.support.v4.view.c {
    final ActionProvider b;
    
    final l c;
    
    public a(l this$0, Context param1Context, ActionProvider param1ActionProvider) {
      super(param1Context);
      this.b = param1ActionProvider;
    }
    
    public void a(SubMenu param1SubMenu) {
      this.b.onPrepareSubMenu(this.c.a(param1SubMenu));
    }
    
    public boolean a() {
      return this.b.hasSubMenu();
    }
    
    public View c() {
      return this.b.onCreateActionView();
    }
    
    public boolean d() {
      return this.b.onPerformDefaultAction();
    }
  }
  
  static class b extends FrameLayout implements a.b.h.f.c {
    final CollapsibleActionView c;
    
    b(View param1View) {
      super(param1View.getContext());
      this.c = (CollapsibleActionView)param1View;
      addView(param1View);
    }
    
    View a() {
      return (View)this.c;
    }
    
    public void b() {
      this.c.onActionViewExpanded();
    }
    
    public void c() {
      this.c.onActionViewCollapsed();
    }
  }
  
  private class c extends d<MenuItem.OnActionExpandListener> implements MenuItem.OnActionExpandListener {
    final l b;
    
    c(l this$0, MenuItem.OnActionExpandListener param1OnActionExpandListener) {
      super(param1OnActionExpandListener);
    }
    
    public boolean onMenuItemActionCollapse(MenuItem param1MenuItem) {
      return ((MenuItem.OnActionExpandListener)this.a).onMenuItemActionCollapse(this.b.a(param1MenuItem));
    }
    
    public boolean onMenuItemActionExpand(MenuItem param1MenuItem) {
      return ((MenuItem.OnActionExpandListener)this.a).onMenuItemActionExpand(this.b.a(param1MenuItem));
    }
  }
  
  private class d extends d<MenuItem.OnMenuItemClickListener> implements MenuItem.OnMenuItemClickListener {
    final l b;
    
    d(l this$0, MenuItem.OnMenuItemClickListener param1OnMenuItemClickListener) {
      super(param1OnMenuItemClickListener);
    }
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      return ((MenuItem.OnMenuItemClickListener)this.a).onMenuItemClick(this.b.a(param1MenuItem));
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\view\menu\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */