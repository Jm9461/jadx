package android.support.v7.view.menu;

import android.widget.ListView;

public interface t {
  void d();
  
  void dismiss();
  
  boolean e();
  
  ListView f();
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\view\menu\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */