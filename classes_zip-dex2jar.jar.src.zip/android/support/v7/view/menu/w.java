package android.support.v7.view.menu;

import a.b.g.b.a.a;
import a.b.g.b.a.c;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

class w extends s implements SubMenu {
  w(Context paramContext, c paramc) {
    super(paramContext, (a)paramc);
  }
  
  public c c() {
    return (c)this.a;
  }
  
  public void clearHeader() {
    c().clearHeader();
  }
  
  public MenuItem getItem() {
    return a(c().getItem());
  }
  
  public SubMenu setHeaderIcon(int paramInt) {
    c().setHeaderIcon(paramInt);
    return this;
  }
  
  public SubMenu setHeaderIcon(Drawable paramDrawable) {
    c().setHeaderIcon(paramDrawable);
    return this;
  }
  
  public SubMenu setHeaderTitle(int paramInt) {
    c().setHeaderTitle(paramInt);
    return this;
  }
  
  public SubMenu setHeaderTitle(CharSequence paramCharSequence) {
    c().setHeaderTitle(paramCharSequence);
    return this;
  }
  
  public SubMenu setHeaderView(View paramView) {
    c().setHeaderView(paramView);
    return this;
  }
  
  public SubMenu setIcon(int paramInt) {
    c().setIcon(paramInt);
    return this;
  }
  
  public SubMenu setIcon(Drawable paramDrawable) {
    c().setIcon(paramDrawable);
    return this;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\view\menu\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */