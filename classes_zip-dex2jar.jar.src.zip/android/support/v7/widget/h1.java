package android.support.v7.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

class h1 {
  public ColorStateList a;
  
  public PorterDuff.Mode b;
  
  public boolean c;
  
  public boolean d;
  
  void a() {
    this.a = null;
    this.d = false;
    this.b = null;
    this.c = false;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\h1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */