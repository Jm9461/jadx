package android.support.v7.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.support.v7.view.menu.ActionMenuItemView;
import android.support.v7.view.menu.h;
import android.support.v7.view.menu.k;
import android.support.v7.view.menu.p;
import android.support.v7.view.menu.q;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewDebug.ExportedProperty;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;

public class ActionMenuView extends o0 implements h.b, q {
  private int A;
  
  private int B;
  
  e C;
  
  private h r;
  
  private Context s;
  
  private int t;
  
  private boolean u;
  
  private c v;
  
  private p.a w;
  
  h.a x;
  
  private boolean y;
  
  private int z;
  
  public ActionMenuView(Context paramContext) {
    this(paramContext, null);
  }
  
  public ActionMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setBaselineAligned(false);
    float f = (paramContext.getResources().getDisplayMetrics()).density;
    this.A = (int)(56.0F * f);
    this.B = (int)(4.0F * f);
    this.s = paramContext;
    this.t = 0;
  }
  
  static int a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   4: checkcast android/support/v7/widget/ActionMenuView$c
    //   7: astore #10
    //   9: iload_3
    //   10: invokestatic getSize : (I)I
    //   13: iload #4
    //   15: isub
    //   16: iload_3
    //   17: invokestatic getMode : (I)I
    //   20: invokestatic makeMeasureSpec : (II)I
    //   23: istore #6
    //   25: aload_0
    //   26: instanceof android/support/v7/view/menu/ActionMenuItemView
    //   29: ifeq -> 41
    //   32: aload_0
    //   33: checkcast android/support/v7/view/menu/ActionMenuItemView
    //   36: astore #9
    //   38: goto -> 44
    //   41: aconst_null
    //   42: astore #9
    //   44: iconst_0
    //   45: istore #8
    //   47: aload #9
    //   49: ifnull -> 66
    //   52: aload #9
    //   54: invokevirtual d : ()Z
    //   57: ifeq -> 66
    //   60: iconst_1
    //   61: istore #4
    //   63: goto -> 69
    //   66: iconst_0
    //   67: istore #4
    //   69: iconst_0
    //   70: istore #5
    //   72: iload #5
    //   74: istore_3
    //   75: iload_2
    //   76: ifle -> 146
    //   79: iload #4
    //   81: ifeq -> 92
    //   84: iload #5
    //   86: istore_3
    //   87: iload_2
    //   88: iconst_2
    //   89: if_icmplt -> 146
    //   92: aload_0
    //   93: iload_1
    //   94: iload_2
    //   95: imul
    //   96: ldc -2147483648
    //   98: invokestatic makeMeasureSpec : (II)I
    //   101: iload #6
    //   103: invokevirtual measure : (II)V
    //   106: aload_0
    //   107: invokevirtual getMeasuredWidth : ()I
    //   110: istore #5
    //   112: iload #5
    //   114: iload_1
    //   115: idiv
    //   116: istore_3
    //   117: iload_3
    //   118: istore_2
    //   119: iload #5
    //   121: iload_1
    //   122: irem
    //   123: ifeq -> 130
    //   126: iload_3
    //   127: iconst_1
    //   128: iadd
    //   129: istore_2
    //   130: iload_2
    //   131: istore_3
    //   132: iload #4
    //   134: ifeq -> 146
    //   137: iload_2
    //   138: istore_3
    //   139: iload_2
    //   140: iconst_2
    //   141: if_icmpge -> 146
    //   144: iconst_2
    //   145: istore_3
    //   146: iload #8
    //   148: istore #7
    //   150: aload #10
    //   152: getfield c : Z
    //   155: ifne -> 170
    //   158: iload #8
    //   160: istore #7
    //   162: iload #4
    //   164: ifeq -> 170
    //   167: iconst_1
    //   168: istore #7
    //   170: aload #10
    //   172: iload #7
    //   174: putfield f : Z
    //   177: aload #10
    //   179: iload_3
    //   180: putfield d : I
    //   183: aload_0
    //   184: iload_3
    //   185: iload_1
    //   186: imul
    //   187: ldc 1073741824
    //   189: invokestatic makeMeasureSpec : (II)I
    //   192: iload #6
    //   194: invokevirtual measure : (II)V
    //   197: iload_3
    //   198: ireturn
  }
  
  private void c(int paramInt1, int paramInt2) {
    int i7 = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = View.MeasureSpec.getSize(paramInt1);
    int i6 = View.MeasureSpec.getSize(paramInt2);
    int i3 = getPaddingLeft() + getPaddingRight();
    int i2 = getPaddingTop() + getPaddingBottom();
    int i8 = ViewGroup.getChildMeasureSpec(paramInt2, i2, -2);
    int i5 = paramInt1 - i3;
    paramInt1 = this.A;
    int i1 = i5 / paramInt1;
    int m = i5 % paramInt1;
    if (i1 == 0) {
      setMeasuredDimension(i5, 0);
      return;
    } 
    int i10 = paramInt1 + m / i1;
    paramInt2 = 0;
    int i9 = getChildCount();
    int j = 0;
    byte b1 = 0;
    int i = 0;
    int n = 0;
    paramInt1 = i1;
    int i4 = 0;
    long l = 0L;
    while (i4 < i9) {
      View view = getChildAt(i4);
      if (view.getVisibility() != 8) {
        boolean bool = view instanceof ActionMenuItemView;
        b1++;
        if (bool) {
          i11 = this.B;
          view.setPadding(i11, 0, i11, 0);
        } 
        c c1 = (c)view.getLayoutParams();
        c1.h = false;
        c1.e = 0;
        c1.d = 0;
        c1.f = false;
        c1.leftMargin = 0;
        c1.rightMargin = 0;
        if (bool && ((ActionMenuItemView)view).d()) {
          bool = true;
        } else {
          bool = false;
        } 
        c1.g = bool;
        if (c1.c) {
          i11 = 1;
        } else {
          i11 = paramInt1;
        } 
        int i12 = a(view, i10, i11, i8, i2);
        n = Math.max(n, i12);
        int i11 = i;
        if (c1.f)
          i11 = i + 1; 
        if (c1.c)
          paramInt2 = 1; 
        paramInt1 -= i12;
        j = Math.max(j, view.getMeasuredHeight());
        if (i12 == 1) {
          l |= (1 << i4);
          i = i11;
        } else {
          i = i11;
        } 
      } 
      i4++;
    } 
    if (paramInt2 != 0 && b1 == 2) {
      i2 = 1;
    } else {
      i2 = 0;
    } 
    int k = 0;
    i3 = paramInt1;
    paramInt1 = k;
    i1 = i5;
    while (i > 0 && i3 > 0) {
      long l1 = 0L;
      i4 = Integer.MAX_VALUE;
      m = 0;
      i5 = 0;
      k = paramInt1;
      paramInt1 = m;
      while (i5 < i9) {
        int i11;
        long l2;
        c c1 = (c)getChildAt(i5).getLayoutParams();
        if (!c1.f) {
          m = paramInt1;
          i11 = i4;
          l2 = l1;
        } else {
          int i12 = c1.d;
          if (i12 < i4) {
            i11 = c1.d;
            l2 = 1L << i5;
            m = 1;
          } else {
            m = paramInt1;
            i11 = i4;
            l2 = l1;
            if (i12 == i4) {
              l2 = l1 | 1L << i5;
              m = paramInt1 + 1;
              i11 = i4;
            } 
          } 
        } 
        i5++;
        paramInt1 = m;
        i4 = i11;
        l1 = l2;
      } 
      l |= l1;
      if (paramInt1 > i3) {
        paramInt1 = k;
        break;
      } 
      k = 0;
      while (k < i9) {
        long l2;
        View view = getChildAt(k);
        c c1 = (c)view.getLayoutParams();
        if ((l1 & (1 << k)) == 0L) {
          m = i3;
          l2 = l;
          if (c1.d == i4 + 1) {
            l2 = l | (1 << k);
            m = i3;
          } 
        } else {
          if (i2 != 0 && c1.g && i3 == 1) {
            m = this.B;
            view.setPadding(m + i10, 0, m, 0);
          } 
          c1.d++;
          c1.h = true;
          m = i3 - 1;
          l2 = l;
        } 
        k++;
        i3 = m;
        l = l2;
      } 
      paramInt1 = 1;
    } 
    if (paramInt2 == 0 && b1 == 1) {
      paramInt2 = 1;
    } else {
      paramInt2 = 0;
    } 
    if (i3 > 0 && l != 0L && (i3 < b1 - 1 || paramInt2 != 0 || n > 1)) {
      float f = Long.bitCount(l);
      if (paramInt2 == 0) {
        float f1;
        if ((l & 0x1L) != 0L) {
          f1 = f;
          if (!((c)getChildAt(0).getLayoutParams()).g)
            f1 = f - 0.5F; 
        } else {
          f1 = f;
        } 
        f = f1;
        if ((l & (1 << i9 - 1)) != 0L) {
          f = f1;
          if (!((c)getChildAt(i9 - 1).getLayoutParams()).g)
            f = f1 - 0.5F; 
        } 
      } 
      if (f > 0.0F) {
        i = (int)((i3 * i10) / f);
      } else {
        i = 0;
      } 
      m = 0;
      k = paramInt2;
      while (m < i9) {
        if ((l & (1 << m)) == 0L) {
          paramInt2 = paramInt1;
        } else {
          View view = getChildAt(m);
          c c1 = (c)view.getLayoutParams();
          if (view instanceof ActionMenuItemView) {
            c1.e = i;
            c1.h = true;
            if (m == 0 && !c1.g)
              c1.leftMargin = -i / 2; 
            paramInt2 = 1;
          } else if (c1.c) {
            c1.e = i;
            c1.h = true;
            c1.rightMargin = -i / 2;
            paramInt2 = 1;
          } else {
            if (m != 0)
              c1.leftMargin = i / 2; 
            paramInt2 = paramInt1;
            if (m != i9 - 1) {
              c1.rightMargin = i / 2;
              paramInt2 = paramInt1;
            } 
          } 
        } 
        m++;
        paramInt1 = paramInt2;
      } 
    } 
    if (paramInt1 != 0)
      for (paramInt1 = 0; paramInt1 < i9; paramInt1++) {
        View view = getChildAt(paramInt1);
        c c1 = (c)view.getLayoutParams();
        if (c1.h)
          view.measure(View.MeasureSpec.makeMeasureSpec(c1.d * i10 + c1.e, 1073741824), i8); 
      }  
    if (i7 != 1073741824) {
      paramInt1 = j;
    } else {
      paramInt1 = i6;
    } 
    setMeasuredDimension(i1, paramInt1);
  }
  
  public void a(h paramh) {
    this.r = paramh;
  }
  
  public void a(p.a parama, h.a parama1) {
    this.w = parama;
    this.x = parama1;
  }
  
  public boolean a(k paramk) {
    return this.r.a((MenuItem)paramk, 0);
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    boolean bool;
    if (paramLayoutParams != null && paramLayoutParams instanceof c) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void d() {
    c c1 = this.v;
    if (c1 != null)
      c1.e(); 
  }
  
  protected boolean d(int paramInt) {
    boolean bool;
    if (paramInt == 0)
      return false; 
    View view1 = getChildAt(paramInt - 1);
    View view2 = getChildAt(paramInt);
    int j = 0;
    int i = j;
    if (paramInt < getChildCount()) {
      i = j;
      if (view1 instanceof a)
        i = false | ((a)view1).b(); 
    } 
    j = i;
    if (paramInt > 0) {
      j = i;
      if (view2 instanceof a)
        bool = i | ((a)view2).c(); 
    } 
    return bool;
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    return false;
  }
  
  public c e() {
    c c1 = generateDefaultLayoutParams();
    c1.c = true;
    return c1;
  }
  
  public boolean f() {
    boolean bool;
    c c1 = this.v;
    if (c1 != null && c1.g()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean g() {
    boolean bool;
    c c1 = this.v;
    if (c1 != null && c1.i()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  protected c generateDefaultLayoutParams() {
    c c1 = new c(-2, -2);
    c1.b = 16;
    return c1;
  }
  
  public c generateLayoutParams(AttributeSet paramAttributeSet) {
    return new c(getContext(), paramAttributeSet);
  }
  
  protected c generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    if (paramLayoutParams != null) {
      c c1;
      if (paramLayoutParams instanceof c) {
        c1 = new c((c)paramLayoutParams);
      } else {
        c1 = new c((ViewGroup.LayoutParams)c1);
      } 
      if (c1.b <= 0)
        c1.b = 16; 
      return c1;
    } 
    return generateDefaultLayoutParams();
  }
  
  public Menu getMenu() {
    if (this.r == null) {
      Context context = getContext();
      this.r = new h(context);
      this.r.a(new d(this));
      this.v = new c(context);
      this.v.c(true);
      c c1 = this.v;
      p.a a1 = this.w;
      if (a1 == null)
        a1 = new b(); 
      c1.a(a1);
      this.r.a((p)this.v, this.s);
      this.v.a(this);
    } 
    return (Menu)this.r;
  }
  
  public Drawable getOverflowIcon() {
    getMenu();
    return this.v.f();
  }
  
  public int getPopupTheme() {
    return this.t;
  }
  
  public int getWindowAnimations() {
    return 0;
  }
  
  public boolean h() {
    boolean bool;
    c c1 = this.v;
    if (c1 != null && c1.j()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean i() {
    return this.u;
  }
  
  public h j() {
    return this.r;
  }
  
  public boolean k() {
    boolean bool;
    c c1 = this.v;
    if (c1 != null && c1.k()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    c c1 = this.v;
    if (c1 != null) {
      c1.a(false);
      if (this.v.j()) {
        this.v.g();
        this.v.k();
      } 
    } 
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    d();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!this.y) {
      super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    int i2 = getChildCount();
    int j = (paramInt4 - paramInt2) / 2;
    int i1 = getDividerWidth();
    paramInt2 = 0;
    int i = 0;
    int m = 0;
    paramInt4 = paramInt3 - paramInt1 - getPaddingRight() - getPaddingLeft();
    int n = 0;
    paramBoolean = r1.a((View)this);
    int k;
    for (k = 0; k < i2; k++) {
      View view = getChildAt(k);
      if (view.getVisibility() != 8) {
        c c1 = (c)view.getLayoutParams();
        if (c1.c) {
          int i3;
          n = view.getMeasuredWidth();
          paramInt2 = n;
          if (d(k))
            paramInt2 = n + i1; 
          int i4 = view.getMeasuredHeight();
          if (paramBoolean) {
            i3 = getPaddingLeft() + c1.leftMargin;
            n = i3 + paramInt2;
          } else {
            n = getWidth() - getPaddingRight() - c1.rightMargin;
            i3 = n - paramInt2;
          } 
          int i5 = j - i4 / 2;
          view.layout(i3, i5, n, i5 + i4);
          paramInt4 -= paramInt2;
          n = 1;
        } else {
          int i4 = view.getMeasuredWidth() + c1.leftMargin + c1.rightMargin;
          int i3 = i + i4;
          paramInt4 -= i4;
          i = i3;
          if (d(k))
            i = i3 + i1; 
          m++;
        } 
      } 
    } 
    if (i2 == 1 && n == 0) {
      View view = getChildAt(0);
      paramInt4 = view.getMeasuredWidth();
      paramInt2 = view.getMeasuredHeight();
      paramInt1 = (paramInt3 - paramInt1) / 2 - paramInt4 / 2;
      paramInt3 = j - paramInt2 / 2;
      view.layout(paramInt1, paramInt3, paramInt1 + paramInt4, paramInt3 + paramInt2);
      return;
    } 
    paramInt1 = m - (n ^ 0x1);
    if (paramInt1 > 0) {
      paramInt1 = paramInt4 / paramInt1;
    } else {
      paramInt1 = 0;
    } 
    i = Math.max(0, paramInt1);
    if (paramBoolean) {
      paramInt4 = getWidth() - getPaddingRight();
      paramInt1 = 0;
      paramInt3 = i1;
      while (paramInt1 < i2) {
        View view = getChildAt(paramInt1);
        c c1 = (c)view.getLayoutParams();
        if (view.getVisibility() != 8 && !c1.c) {
          n = paramInt4 - c1.rightMargin;
          paramInt4 = view.getMeasuredWidth();
          k = view.getMeasuredHeight();
          m = j - k / 2;
          view.layout(n - paramInt4, m, n, m + k);
          paramInt4 = n - c1.leftMargin + paramInt4 + i;
        } 
        paramInt1++;
      } 
    } else {
      paramInt3 = getPaddingLeft();
      paramInt1 = 0;
      while (paramInt1 < i2) {
        View view = getChildAt(paramInt1);
        c c1 = (c)view.getLayoutParams();
        paramInt2 = paramInt3;
        if (view.getVisibility() != 8)
          if (c1.c) {
            paramInt2 = paramInt3;
          } else {
            paramInt2 = paramInt3 + c1.leftMargin;
            k = view.getMeasuredWidth();
            paramInt4 = view.getMeasuredHeight();
            paramInt3 = j - paramInt4 / 2;
            view.layout(paramInt2, paramInt3, paramInt2 + k, paramInt3 + paramInt4);
            paramInt2 += c1.rightMargin + k + i;
          }  
        paramInt1++;
        paramInt3 = paramInt2;
      } 
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    boolean bool;
    boolean bool1 = this.y;
    if (View.MeasureSpec.getMode(paramInt1) == 1073741824) {
      bool = true;
    } else {
      bool = false;
    } 
    this.y = bool;
    if (bool1 != this.y)
      this.z = 0; 
    int i = View.MeasureSpec.getSize(paramInt1);
    if (this.y) {
      h h1 = this.r;
      if (h1 != null && i != this.z) {
        this.z = i;
        h1.b(true);
      } 
    } 
    int j = getChildCount();
    if (this.y && j > 0) {
      c(paramInt1, paramInt2);
    } else {
      for (i = 0; i < j; i++) {
        c c1 = (c)getChildAt(i).getLayoutParams();
        c1.rightMargin = 0;
        c1.leftMargin = 0;
      } 
      super.onMeasure(paramInt1, paramInt2);
    } 
  }
  
  public void setExpandedActionViewsExclusive(boolean paramBoolean) {
    this.v.b(paramBoolean);
  }
  
  public void setOnMenuItemClickListener(e parame) {
    this.C = parame;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    getMenu();
    this.v.a(paramDrawable);
  }
  
  public void setOverflowReserved(boolean paramBoolean) {
    this.u = paramBoolean;
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.t != paramInt) {
      this.t = paramInt;
      if (paramInt == 0) {
        this.s = getContext();
      } else {
        this.s = (Context)new ContextThemeWrapper(getContext(), paramInt);
      } 
    } 
  }
  
  public void setPresenter(c paramc) {
    this.v = paramc;
    this.v.a(this);
  }
  
  public static interface a {
    boolean b();
    
    boolean c();
  }
  
  private static class b implements p.a {
    public void a(h param1h, boolean param1Boolean) {}
    
    public boolean a(h param1h) {
      return false;
    }
  }
  
  public static class c extends o0.a {
    @ExportedProperty
    public boolean c;
    
    @ExportedProperty
    public int d;
    
    @ExportedProperty
    public int e;
    
    @ExportedProperty
    public boolean f;
    
    @ExportedProperty
    public boolean g;
    
    boolean h;
    
    public c(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.c = false;
    }
    
    public c(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public c(c param1c) {
      super((ViewGroup.LayoutParams)param1c);
      this.c = param1c.c;
    }
    
    public c(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
  }
  
  private class d implements h.a {
    final ActionMenuView c;
    
    d(ActionMenuView this$0) {}
    
    public void a(h param1h) {
      h.a a1 = this.c.x;
      if (a1 != null)
        a1.a(param1h); 
    }
    
    public boolean a(h param1h, MenuItem param1MenuItem) {
      boolean bool;
      ActionMenuView.e e = this.c.C;
      if (e != null && e.onMenuItemClick(param1MenuItem)) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
  }
  
  public static interface e {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\ActionMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */