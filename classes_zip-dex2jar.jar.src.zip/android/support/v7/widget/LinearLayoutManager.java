package android.support.v7.widget;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v7.widget.t1.a;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import java.util.List;

public class LinearLayoutManager extends RecyclerView.o implements a, RecyclerView.z.a {
  int A = -1;
  
  int B = Integer.MIN_VALUE;
  
  private boolean C;
  
  d D = null;
  
  final a E = new a();
  
  private final b F = new b();
  
  private int G = 2;
  
  int s = 1;
  
  private c t;
  
  t0 u;
  
  private boolean v;
  
  private boolean w = false;
  
  boolean x = false;
  
  private boolean y = false;
  
  private boolean z = true;
  
  public LinearLayoutManager(Context paramContext) {
    this(paramContext, 1, false);
  }
  
  public LinearLayoutManager(Context paramContext, int paramInt, boolean paramBoolean) {
    j(paramInt);
    a(paramBoolean);
  }
  
  public LinearLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    RecyclerView.o.d d1 = RecyclerView.o.a(paramContext, paramAttributeSet, paramInt1, paramInt2);
    j(d1.a);
    a(d1.c);
    b(d1.d);
  }
  
  private View K() {
    int i;
    if (this.x) {
      i = 0;
    } else {
      i = e() - 1;
    } 
    return c(i);
  }
  
  private View L() {
    boolean bool;
    if (this.x) {
      bool = e() - 1;
    } else {
      bool = false;
    } 
    return c(bool);
  }
  
  private void M() {
    if (this.s == 1 || !I()) {
      this.x = this.w;
      return;
    } 
    this.x = this.w ^ true;
  }
  
  private int a(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0, boolean paramBoolean) {
    int i = this.u.b() - paramInt;
    if (i > 0) {
      i = -c(-i, paramv, parama0);
      if (paramBoolean) {
        paramInt = this.u.b() - paramInt + i;
        if (paramInt > 0) {
          this.u.a(paramInt);
          return paramInt + i;
        } 
      } 
      return i;
    } 
    return 0;
  }
  
  private View a(boolean paramBoolean1, boolean paramBoolean2) {
    return this.x ? a(0, e(), paramBoolean1, paramBoolean2) : a(e() - 1, -1, paramBoolean1, paramBoolean2);
  }
  
  private void a(int paramInt1, int paramInt2, boolean paramBoolean, RecyclerView.a0 parama0) {
    this.t.l = J();
    this.t.h = h(parama0);
    c c1 = this.t;
    c1.f = paramInt1;
    byte b1 = -1;
    if (paramInt1 == 1) {
      c1.h += this.u.c();
      View view = K();
      c c2 = this.t;
      if (!this.x)
        b1 = 1; 
      c2.e = b1;
      c c3 = this.t;
      paramInt1 = l(view);
      c2 = this.t;
      c3.d = paramInt1 + c2.e;
      c2.b = this.u.a(view);
      paramInt1 = this.u.a(view) - this.u.b();
    } else {
      View view = L();
      c c2 = this.t;
      c2.h += this.u.f();
      c2 = this.t;
      if (this.x)
        b1 = 1; 
      c2.e = b1;
      c2 = this.t;
      paramInt1 = l(view);
      c c3 = this.t;
      c2.d = paramInt1 + c3.e;
      c3.b = this.u.d(view);
      paramInt1 = -this.u.d(view) + this.u.f();
    } 
    c1 = this.t;
    c1.c = paramInt2;
    if (paramBoolean)
      c1.c -= paramInt1; 
    this.t.g = paramInt1;
  }
  
  private void a(a parama) {
    f(parama.b, parama.c);
  }
  
  private void a(RecyclerView.v paramv, int paramInt) {
    int i = e();
    if (paramInt < 0)
      return; 
    int j = this.u.a() - paramInt;
    if (this.x) {
      for (paramInt = 0; paramInt < i; paramInt++) {
        View view = c(paramInt);
        if (this.u.d(view) < j || this.u.f(view) < j) {
          a(paramv, 0, paramInt);
          return;
        } 
      } 
    } else {
      for (paramInt = i - 1; paramInt >= 0; paramInt--) {
        View view = c(paramInt);
        if (this.u.d(view) < j || this.u.f(view) < j) {
          a(paramv, i - 1, paramInt);
          return;
        } 
      } 
    } 
  }
  
  private void a(RecyclerView.v paramv, int paramInt1, int paramInt2) {
    if (paramInt1 == paramInt2)
      return; 
    if (paramInt2 > paramInt1) {
      while (--paramInt2 >= paramInt1) {
        a(paramInt2, paramv);
        paramInt2--;
      } 
    } else {
      while (paramInt1 > paramInt2) {
        a(paramInt1, paramv);
        paramInt1--;
      } 
    } 
  }
  
  private void a(RecyclerView.v paramv, c paramc) {
    if (!paramc.a || paramc.l)
      return; 
    if (paramc.f == -1) {
      a(paramv, paramc.g);
    } else {
      b(paramv, paramc.g);
    } 
  }
  
  private boolean a(RecyclerView.a0 parama0, a parama) {
    boolean bool = parama0.d();
    boolean bool1 = false;
    if (!bool) {
      int i = this.A;
      if (i != -1) {
        if (i < 0 || i >= parama0.a()) {
          this.A = -1;
          this.B = Integer.MIN_VALUE;
          return false;
        } 
        parama.b = this.A;
        d d1 = this.D;
        if (d1 != null && d1.a()) {
          parama.d = this.D.e;
          if (parama.d) {
            parama.c = this.u.b() - this.D.d;
          } else {
            parama.c = this.u.f() + this.D.d;
          } 
          return true;
        } 
        if (this.B == Integer.MIN_VALUE) {
          View view = b(this.A);
          if (view != null) {
            if (this.u.b(view) > this.u.g()) {
              parama.a();
              return true;
            } 
            if (this.u.d(view) - this.u.f() < 0) {
              parama.c = this.u.f();
              parama.d = false;
              return true;
            } 
            if (this.u.b() - this.u.a(view) < 0) {
              parama.c = this.u.b();
              parama.d = true;
              return true;
            } 
            if (parama.d) {
              i = this.u.a(view) + this.u.h();
            } else {
              i = this.u.d(view);
            } 
            parama.c = i;
          } else {
            if (e() > 0) {
              i = l(c(0));
              if (this.A < i) {
                bool = true;
              } else {
                bool = false;
              } 
              if (bool == this.x)
                bool1 = true; 
              parama.d = bool1;
            } 
            parama.a();
          } 
          return true;
        } 
        bool = this.x;
        parama.d = bool;
        if (bool) {
          parama.c = this.u.b() - this.B;
        } else {
          parama.c = this.u.f() + this.B;
        } 
        return true;
      } 
    } 
    return false;
  }
  
  private boolean a(RecyclerView.v paramv, RecyclerView.a0 parama0, a parama) {
    View view1;
    int j = e();
    int i = 0;
    if (j == 0)
      return false; 
    View view2 = g();
    if (view2 != null && parama.a(view2, parama0)) {
      parama.b(view2, l(view2));
      return true;
    } 
    if (this.v != this.y)
      return false; 
    if (parama.d) {
      view1 = l(paramv, parama0);
    } else {
      view1 = m((RecyclerView.v)view1, parama0);
    } 
    if (view1 != null) {
      parama.a(view1, l(view1));
      if (!parama0.d() && C()) {
        if (this.u.d(view1) >= this.u.b() || this.u.a(view1) < this.u.f())
          i = 1; 
        if (i) {
          if (parama.d) {
            i = this.u.b();
          } else {
            i = this.u.f();
          } 
          parama.c = i;
        } 
      } 
      return true;
    } 
    return false;
  }
  
  private int b(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0, boolean paramBoolean) {
    int i = paramInt - this.u.f();
    if (i > 0) {
      i = -c(i, paramv, parama0);
      if (paramBoolean) {
        paramInt = paramInt + i - this.u.f();
        if (paramInt > 0) {
          this.u.a(-paramInt);
          return i - paramInt;
        } 
      } 
      return i;
    } 
    return 0;
  }
  
  private View b(boolean paramBoolean1, boolean paramBoolean2) {
    return this.x ? a(e() - 1, -1, paramBoolean1, paramBoolean2) : a(0, e(), paramBoolean1, paramBoolean2);
  }
  
  private void b(a parama) {
    g(parama.b, parama.c);
  }
  
  private void b(RecyclerView.v paramv, int paramInt) {
    if (paramInt < 0)
      return; 
    int i = e();
    if (this.x) {
      for (int j = i - 1; j >= 0; j--) {
        View view = c(j);
        if (this.u.a(view) > paramInt || this.u.e(view) > paramInt) {
          a(paramv, i - 1, j);
          return;
        } 
      } 
    } else {
      for (byte b1 = 0; b1 < i; b1++) {
        View view = c(b1);
        if (this.u.a(view) > paramInt || this.u.e(view) > paramInt) {
          a(paramv, 0, b1);
          return;
        } 
      } 
    } 
  }
  
  private void b(RecyclerView.v paramv, RecyclerView.a0 parama0, int paramInt1, int paramInt2) {
    if (!parama0.e() || e() == 0 || parama0.d() || !C())
      return; 
    int j = 0;
    int i = 0;
    List<RecyclerView.d0> list = paramv.f();
    int m = list.size();
    int k = l(c(0));
    for (byte b1 = 0; b1 < m; b1++) {
      RecyclerView.d0 d0 = list.get(b1);
      if (!d0.p()) {
        boolean bool;
        int n = d0.i();
        byte b2 = 1;
        if (n < k) {
          bool = true;
        } else {
          bool = false;
        } 
        if (bool != this.x)
          b2 = -1; 
        if (b2 == -1) {
          j += this.u.b(d0.c);
        } else {
          i += this.u.b(d0.c);
        } 
      } 
    } 
    this.t.k = list;
    if (j > 0) {
      g(l(L()), paramInt1);
      c c1 = this.t;
      c1.h = j;
      c1.c = 0;
      c1.a();
      a(paramv, this.t, parama0, false);
    } 
    if (i > 0) {
      f(l(K()), paramInt2);
      c c1 = this.t;
      c1.h = i;
      c1.c = 0;
      c1.a();
      a(paramv, this.t, parama0, false);
    } 
    this.t.k = null;
  }
  
  private void b(RecyclerView.v paramv, RecyclerView.a0 parama0, a parama) {
    boolean bool;
    if (a(parama0, parama))
      return; 
    if (a(paramv, parama0, parama))
      return; 
    parama.a();
    if (this.y) {
      bool = parama0.a() - 1;
    } else {
      bool = false;
    } 
    parama.b = bool;
  }
  
  private View f(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return e(0, e());
  }
  
  private void f(int paramInt1, int paramInt2) {
    boolean bool;
    this.t.c = this.u.b() - paramInt2;
    c c1 = this.t;
    if (this.x) {
      bool = true;
    } else {
      bool = true;
    } 
    c1.e = bool;
    c1 = this.t;
    c1.d = paramInt1;
    c1.f = 1;
    c1.b = paramInt2;
    c1.g = Integer.MIN_VALUE;
  }
  
  private View g(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return a(paramv, parama0, 0, e(), parama0.a());
  }
  
  private void g(int paramInt1, int paramInt2) {
    this.t.c = paramInt2 - this.u.f();
    c c1 = this.t;
    c1.d = paramInt1;
    if (this.x) {
      paramInt1 = 1;
    } else {
      paramInt1 = -1;
    } 
    c1.e = paramInt1;
    c1 = this.t;
    c1.f = -1;
    c1.b = paramInt2;
    c1.g = Integer.MIN_VALUE;
  }
  
  private View h(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return e(e() - 1, -1);
  }
  
  private int i(RecyclerView.a0 parama0) {
    if (e() == 0)
      return 0; 
    E();
    return a1.a(parama0, this.u, b(this.z ^ true, true), a(this.z ^ true, true), this, this.z);
  }
  
  private View i(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return a(paramv, parama0, e() - 1, -1, parama0.a());
  }
  
  private int j(RecyclerView.a0 parama0) {
    if (e() == 0)
      return 0; 
    E();
    return a1.a(parama0, this.u, b(this.z ^ true, true), a(this.z ^ true, true), this, this.z, this.x);
  }
  
  private View j(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    View view;
    if (this.x) {
      view = f(paramv, parama0);
    } else {
      view = h((RecyclerView.v)view, parama0);
    } 
    return view;
  }
  
  private int k(RecyclerView.a0 parama0) {
    if (e() == 0)
      return 0; 
    E();
    return a1.b(parama0, this.u, b(this.z ^ true, true), a(this.z ^ true, true), this, this.z);
  }
  
  private View k(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    View view;
    if (this.x) {
      view = h(paramv, parama0);
    } else {
      view = f((RecyclerView.v)view, parama0);
    } 
    return view;
  }
  
  private View l(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    View view;
    if (this.x) {
      view = g(paramv, parama0);
    } else {
      view = i((RecyclerView.v)view, parama0);
    } 
    return view;
  }
  
  private View m(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    View view;
    if (this.x) {
      view = i(paramv, parama0);
    } else {
      view = g((RecyclerView.v)view, parama0);
    } 
    return view;
  }
  
  boolean A() {
    boolean bool;
    if (i() != 1073741824 && r() != 1073741824 && s()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean C() {
    boolean bool;
    if (this.D == null && this.v == this.y) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  c D() {
    return new c();
  }
  
  void E() {
    if (this.t == null)
      this.t = D(); 
  }
  
  public int F() {
    int i;
    View view = a(0, e(), false, true);
    if (view == null) {
      i = -1;
    } else {
      i = l(view);
    } 
    return i;
  }
  
  public int G() {
    int j = e();
    int i = -1;
    View view = a(j - 1, -1, false, true);
    if (view != null)
      i = l(view); 
    return i;
  }
  
  public int H() {
    return this.s;
  }
  
  protected boolean I() {
    int i = j();
    boolean bool = true;
    if (i != 1)
      bool = false; 
    return bool;
  }
  
  boolean J() {
    boolean bool;
    if (this.u.d() == 0 && this.u.a() == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int a(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return (this.s == 1) ? 0 : c(paramInt, paramv, parama0);
  }
  
  public int a(RecyclerView.a0 parama0) {
    return i(parama0);
  }
  
  int a(RecyclerView.v paramv, c paramc, RecyclerView.a0 parama0, boolean paramBoolean) {
    int k = paramc.c;
    int i = paramc.g;
    if (i != Integer.MIN_VALUE) {
      int m = paramc.c;
      if (m < 0)
        paramc.g = i + m; 
      a(paramv, paramc);
    } 
    int j = paramc.c + paramc.h;
    b b1 = this.F;
    while (true) {
      while (true)
        break; 
      if (paramBoolean) {
        j = i;
        if (b1.d)
          break; 
      } 
    } 
    return k - paramc.c;
  }
  
  View a(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    char c1;
    View view;
    E();
    char c2 = Character.MIN_VALUE;
    if (paramBoolean1) {
      c1 = '怃';
    } else {
      c1 = 'ŀ';
    } 
    if (paramBoolean2)
      c2 = 'ŀ'; 
    if (this.s == 0) {
      view = this.e.a(paramInt1, paramInt2, c1, c2);
    } else {
      view = this.f.a(paramInt1, paramInt2, c1, c2);
    } 
    return view;
  }
  
  View a(RecyclerView.v paramv, RecyclerView.a0 parama0, int paramInt1, int paramInt2, int paramInt3) {
    View view;
    RecyclerView.a0 a01;
    byte b1;
    E();
    parama0 = null;
    paramv = null;
    int j = this.u.f();
    int i = this.u.b();
    if (paramInt2 > paramInt1) {
      b1 = 1;
    } else {
      b1 = -1;
    } 
    while (paramInt1 != paramInt2) {
      View view2;
      View view1 = c(paramInt1);
      int k = l(view1);
      RecyclerView.a0 a02 = parama0;
      RecyclerView.v v1 = paramv;
      if (k >= 0) {
        a02 = parama0;
        v1 = paramv;
        if (k < paramInt3)
          if (((RecyclerView.p)view1.getLayoutParams()).c()) {
            a02 = parama0;
            v1 = paramv;
            if (parama0 == null) {
              View view3 = view1;
              v1 = paramv;
            } 
          } else if (this.u.d(view1) >= i || this.u.a(view1) < j) {
            a02 = parama0;
            v1 = paramv;
            if (paramv == null) {
              view2 = view1;
              a02 = parama0;
            } 
          } else {
            return view1;
          }  
      } 
      paramInt1 += b1;
      parama0 = a02;
      view = view2;
    } 
    if (view == null)
      a01 = parama0; 
    return (View)a01;
  }
  
  public View a(View paramView, int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    View view1;
    View view2;
    M();
    if (e() == 0)
      return null; 
    paramInt = i(paramInt);
    if (paramInt == Integer.MIN_VALUE)
      return null; 
    E();
    E();
    a(paramInt, (int)(this.u.g() * 0.33333334F), false, parama0);
    c c1 = this.t;
    c1.g = Integer.MIN_VALUE;
    c1.a = false;
    a(paramv, c1, parama0, true);
    if (paramInt == -1) {
      view1 = k(paramv, parama0);
    } else {
      view1 = j(paramv, parama0);
    } 
    if (paramInt == -1) {
      view2 = L();
    } else {
      view2 = K();
    } 
    return view2.hasFocusable() ? ((view1 == null) ? null : view2) : view1;
  }
  
  public void a(int paramInt1, int paramInt2, RecyclerView.a0 parama0, RecyclerView.o.c paramc) {
    if (this.s != 0)
      paramInt1 = paramInt2; 
    if (e() == 0 || paramInt1 == 0)
      return; 
    E();
    if (paramInt1 > 0) {
      paramInt2 = 1;
    } else {
      paramInt2 = -1;
    } 
    a(paramInt2, Math.abs(paramInt1), true, parama0);
    a(parama0, this.t, paramc);
  }
  
  public void a(int paramInt, RecyclerView.o.c paramc) {
    boolean bool;
    d d1 = this.D;
    byte b1 = -1;
    if (d1 != null && d1.a()) {
      d1 = this.D;
      bool = d1.e;
      i = d1.c;
    } else {
      M();
      bool = this.x;
      if (this.A == -1) {
        if (bool) {
          i = paramInt - 1;
        } else {
          i = 0;
        } 
      } else {
        i = this.A;
      } 
    } 
    if (!bool)
      b1 = 1; 
    int j = i;
    for (int i = 0; i < this.G && j >= 0 && j < paramInt; i++) {
      paramc.a(j, 0);
      j += b1;
    } 
  }
  
  public void a(Parcelable paramParcelable) {
    if (paramParcelable instanceof d) {
      this.D = (d)paramParcelable;
      y();
    } 
  }
  
  void a(RecyclerView.a0 parama0, c paramc, RecyclerView.o.c paramc1) {
    int i = paramc.d;
    if (i >= 0 && i < parama0.a())
      paramc1.a(i, Math.max(0, paramc.g)); 
  }
  
  void a(RecyclerView.v paramv, RecyclerView.a0 parama0, a parama, int paramInt) {}
  
  void a(RecyclerView.v paramv, RecyclerView.a0 parama0, c paramc, b paramb) {
    int i;
    int j;
    int k;
    int m;
    View view = paramc.a(paramv);
    if (view == null) {
      paramb.b = true;
      return;
    } 
    RecyclerView.p p = (RecyclerView.p)view.getLayoutParams();
    if (paramc.k == null) {
      boolean bool1;
      boolean bool2 = this.x;
      if (paramc.f == -1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool2 == bool1) {
        b(view);
      } else {
        b(view, 0);
      } 
    } else {
      boolean bool1;
      boolean bool2 = this.x;
      if (paramc.f == -1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool2 == bool1) {
        a(view);
      } else {
        a(view, 0);
      } 
    } 
    a(view, 0, 0);
    paramb.a = this.u.b(view);
    if (this.s == 1) {
      if (I()) {
        j = q() - o();
        i = j - this.u.c(view);
      } else {
        i = n();
        j = this.u.c(view) + i;
      } 
      if (paramc.f == -1) {
        m = paramc.b;
        int n = paramc.b;
        int i1 = paramb.a;
        k = j;
        j = n - i1;
      } else {
        m = paramc.b;
        int i1 = paramc.b;
        int n = paramb.a;
        k = j;
        j = m;
        m = i1 + n;
      } 
    } else {
      j = p();
      i = this.u.c(view) + j;
      if (paramc.f == -1) {
        k = paramc.b;
        int n = paramc.b;
        int i1 = paramb.a;
        m = i;
        i = n - i1;
      } else {
        int n = paramc.b;
        m = paramc.b;
        k = paramb.a;
        k = m + k;
        m = i;
        i = n;
      } 
    } 
    a(view, i, j, k, m);
    if (p.c() || p.b())
      paramb.c = true; 
    paramb.d = view.hasFocusable();
  }
  
  public void a(AccessibilityEvent paramAccessibilityEvent) {
    super.a(paramAccessibilityEvent);
    if (e() > 0) {
      paramAccessibilityEvent.setFromIndex(F());
      paramAccessibilityEvent.setToIndex(G());
    } 
  }
  
  public void a(String paramString) {
    if (this.D == null)
      super.a(paramString); 
  }
  
  public void a(boolean paramBoolean) {
    a((String)null);
    if (paramBoolean == this.w)
      return; 
    this.w = paramBoolean;
    y();
  }
  
  public boolean a() {
    boolean bool;
    if (this.s == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int b(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return (this.s == 0) ? 0 : c(paramInt, paramv, parama0);
  }
  
  public int b(RecyclerView.a0 parama0) {
    return j(parama0);
  }
  
  public View b(int paramInt) {
    int j = e();
    if (j == 0)
      return null; 
    int i = paramInt - l(c(0));
    if (i >= 0 && i < j) {
      View view = c(i);
      if (l(view) == paramInt)
        return view; 
    } 
    return super.b(paramInt);
  }
  
  public void b(RecyclerView paramRecyclerView, RecyclerView.v paramv) {
    super.b(paramRecyclerView, paramv);
    if (this.C) {
      b(paramv);
      paramv.a();
    } 
  }
  
  public void b(boolean paramBoolean) {
    a((String)null);
    if (this.y == paramBoolean)
      return; 
    this.y = paramBoolean;
    y();
  }
  
  public boolean b() {
    int i = this.s;
    boolean bool = true;
    if (i != 1)
      bool = false; 
    return bool;
  }
  
  int c(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    byte b1;
    if (e() == 0 || paramInt == 0)
      return 0; 
    this.t.a = true;
    E();
    if (paramInt > 0) {
      b1 = 1;
    } else {
      b1 = -1;
    } 
    int j = Math.abs(paramInt);
    a(b1, j, true, parama0);
    c c1 = this.t;
    int i = c1.g + a(paramv, c1, parama0, false);
    if (i < 0)
      return 0; 
    if (j > i)
      paramInt = b1 * i; 
    this.u.a(-paramInt);
    this.t.j = paramInt;
    return paramInt;
  }
  
  public int c(RecyclerView.a0 parama0) {
    return k(parama0);
  }
  
  public RecyclerView.p c() {
    return new RecyclerView.p(-2, -2);
  }
  
  public int d(RecyclerView.a0 parama0) {
    return i(parama0);
  }
  
  public int e(RecyclerView.a0 parama0) {
    return j(parama0);
  }
  
  View e(int paramInt1, int paramInt2) {
    char c1;
    char c2;
    View view;
    E();
    if (paramInt2 > paramInt1) {
      c1 = '\001';
    } else if (paramInt2 < paramInt1) {
      c1 = '￿';
    } else {
      c1 = Character.MIN_VALUE;
    } 
    if (!c1)
      return c(paramInt1); 
    if (this.u.d(c(paramInt1)) < this.u.f()) {
      c1 = '䄄';
      c2 = '䀄';
    } else {
      c1 = '၁';
      c2 = 'ခ';
    } 
    if (this.s == 0) {
      view = this.e.a(paramInt1, paramInt2, c1, c2);
    } else {
      view = this.f.a(paramInt1, paramInt2, c1, c2);
    } 
    return view;
  }
  
  public void e(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    c c1;
    d d1 = this.D;
    int k = -1;
    if ((d1 != null || this.A != -1) && parama0.a() == 0) {
      b(paramv);
      return;
    } 
    d1 = this.D;
    if (d1 != null && d1.a())
      this.A = this.D.c; 
    E();
    this.t.a = false;
    M();
    View view = g();
    if (!this.E.e || this.A != -1 || this.D != null) {
      this.E.b();
      a1 = this.E;
      a1.d = this.x ^ this.y;
      b(paramv, parama0, a1);
      this.E.e = true;
    } else if (a1 != null && (this.u.d((View)a1) >= this.u.b() || this.u.a((View)a1) <= this.u.f())) {
      this.E.b((View)a1, l((View)a1));
    } 
    int i = h(parama0);
    if (this.t.j >= 0) {
      j = 0;
    } else {
      j = i;
      i = 0;
    } 
    int m = j + this.u.f();
    int n = i + this.u.c();
    int j = n;
    i = m;
    if (parama0.d()) {
      int i1 = this.A;
      j = n;
      i = m;
      if (i1 != -1) {
        j = n;
        i = m;
        if (this.B != Integer.MIN_VALUE) {
          View view1 = b(i1);
          j = n;
          i = m;
          if (view1 != null) {
            if (this.x) {
              i = this.u.b() - this.u.a(view1) - this.B;
            } else {
              i = this.u.d(view1);
              j = this.u.f();
              i = this.B - i - j;
            } 
            if (i > 0) {
              i = m + i;
              j = n;
            } else {
              j = n - i;
              i = m;
            } 
          } 
        } 
      } 
    } 
    if (this.E.d) {
      if (this.x)
        k = 1; 
    } else if (!this.x) {
      k = 1;
    } 
    a(paramv, parama0, this.E, k);
    a(paramv);
    this.t.l = J();
    this.t.i = parama0.d();
    a a1 = this.E;
    if (a1.d) {
      b(a1);
      c1 = this.t;
      c1.h = i;
      a(paramv, c1, parama0, false);
      c1 = this.t;
      k = c1.b;
      n = c1.d;
      m = c1.c;
      i = j;
      if (m > 0)
        i = j + m; 
      a(this.E);
      c1 = this.t;
      c1.h = i;
      c1.d += c1.e;
      a(paramv, c1, parama0, false);
      c1 = this.t;
      m = c1.b;
      i = k;
      if (c1.c > 0) {
        i = c1.c;
        g(n, k);
        c1 = this.t;
        c1.h = i;
        a(paramv, c1, parama0, false);
        i = this.t.b;
      } 
      j = i;
      i = m;
    } else {
      a((a)c1);
      c1 = this.t;
      c1.h = j;
      a(paramv, c1, parama0, false);
      c1 = this.t;
      k = c1.b;
      n = c1.d;
      m = c1.c;
      j = i;
      if (m > 0)
        j = i + m; 
      b(this.E);
      c1 = this.t;
      c1.h = j;
      c1.d += c1.e;
      a(paramv, c1, parama0, false);
      c1 = this.t;
      m = c1.b;
      j = m;
      i = k;
      if (c1.c > 0) {
        i = c1.c;
        f(n, k);
        c1 = this.t;
        c1.h = i;
        a(paramv, c1, parama0, false);
        i = this.t.b;
        j = m;
      } 
    } 
    m = j;
    k = i;
    if (e() > 0)
      if ((this.x ^ this.y) != 0) {
        k = a(i, paramv, parama0, true);
        m = j + k;
        j = b(m, paramv, parama0, false);
        m += j;
        k = i + k + j;
      } else {
        k = b(j, paramv, parama0, true);
        n = i + k;
        i = a(n, paramv, parama0, false);
        m = j + k + i;
        k = n + i;
      }  
    b(paramv, parama0, m, k);
    if (!parama0.d()) {
      this.u.i();
    } else {
      this.E.b();
    } 
    this.v = this.y;
  }
  
  public int f(RecyclerView.a0 parama0) {
    return k(parama0);
  }
  
  public void g(RecyclerView.a0 parama0) {
    super.g(parama0);
    this.D = null;
    this.A = -1;
    this.B = Integer.MIN_VALUE;
    this.E.b();
  }
  
  protected int h(RecyclerView.a0 parama0) {
    return parama0.c() ? this.u.g() : 0;
  }
  
  public void h(int paramInt) {
    this.A = paramInt;
    this.B = Integer.MIN_VALUE;
    d d1 = this.D;
    if (d1 != null)
      d1.b(); 
    y();
  }
  
  int i(int paramInt) {
    int i = -1;
    boolean bool1 = true;
    boolean bool2 = true;
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 17) {
          if (paramInt != 33) {
            if (paramInt != 66) {
              if (paramInt != 130)
                return Integer.MIN_VALUE; 
              if (this.s == 1) {
                paramInt = bool2;
              } else {
                paramInt = Integer.MIN_VALUE;
              } 
              return paramInt;
            } 
            if (this.s == 0) {
              paramInt = bool1;
            } else {
              paramInt = Integer.MIN_VALUE;
            } 
            return paramInt;
          } 
          if (this.s != 1)
            i = Integer.MIN_VALUE; 
          return i;
        } 
        if (this.s != 0)
          i = Integer.MIN_VALUE; 
        return i;
      } 
      return (this.s == 1) ? 1 : (I() ? -1 : 1);
    } 
    return (this.s == 1) ? -1 : (I() ? 1 : -1);
  }
  
  public void j(int paramInt) {
    if (paramInt == 0 || paramInt == 1) {
      a((String)null);
      if (paramInt != this.s || this.u == null) {
        this.u = t0.a(this, paramInt);
        this.E.a = this.u;
        this.s = paramInt;
        y();
      } 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("invalid orientation:");
    stringBuilder.append(paramInt);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean u() {
    return true;
  }
  
  public Parcelable x() {
    d d1 = this.D;
    if (d1 != null)
      return new d(d1); 
    d1 = new d();
    if (e() > 0) {
      E();
      int i = this.v ^ this.x;
      d1.e = i;
      if (i != 0) {
        View view = K();
        d1.d = this.u.b() - this.u.a(view);
        d1.c = l(view);
      } else {
        View view = L();
        d1.c = l(view);
        d1.d = this.u.d(view) - this.u.f();
      } 
    } else {
      d1.b();
    } 
    return d1;
  }
  
  static class a {
    t0 a;
    
    int b;
    
    int c;
    
    boolean d;
    
    boolean e;
    
    a() {
      b();
    }
    
    void a() {
      int i;
      if (this.d) {
        i = this.a.b();
      } else {
        i = this.a.f();
      } 
      this.c = i;
    }
    
    public void a(View param1View, int param1Int) {
      if (this.d) {
        this.c = this.a.a(param1View) + this.a.h();
      } else {
        this.c = this.a.d(param1View);
      } 
      this.b = param1Int;
    }
    
    boolean a(View param1View, RecyclerView.a0 param1a0) {
      boolean bool;
      RecyclerView.p p = (RecyclerView.p)param1View.getLayoutParams();
      if (!p.c() && p.a() >= 0 && p.a() < param1a0.a()) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    void b() {
      this.b = -1;
      this.c = Integer.MIN_VALUE;
      this.d = false;
      this.e = false;
    }
    
    public void b(View param1View, int param1Int) {
      int i = this.a.h();
      if (i >= 0) {
        a(param1View, param1Int);
        return;
      } 
      this.b = param1Int;
      if (this.d) {
        param1Int = this.a.b() - i - this.a.a(param1View);
        this.c = this.a.b() - param1Int;
        if (param1Int > 0) {
          i = this.a.b(param1View);
          int k = this.c;
          int j = this.a.f();
          i = k - i - Math.min(this.a.d(param1View) - j, 0) + j;
          if (i < 0)
            this.c += Math.min(param1Int, -i); 
        } 
      } else {
        int j = this.a.d(param1View);
        param1Int = j - this.a.f();
        this.c = j;
        if (param1Int > 0) {
          int m = this.a.b(param1View);
          int k = this.a.b();
          int n = this.a.a(param1View);
          i = this.a.b() - Math.min(0, k - i - n) - m + j;
          if (i < 0)
            this.c -= Math.min(param1Int, -i); 
        } 
      } 
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("AnchorInfo{mPosition=");
      stringBuilder.append(this.b);
      stringBuilder.append(", mCoordinate=");
      stringBuilder.append(this.c);
      stringBuilder.append(", mLayoutFromEnd=");
      stringBuilder.append(this.d);
      stringBuilder.append(", mValid=");
      stringBuilder.append(this.e);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
  
  protected static class b {
    public int a;
    
    public boolean b;
    
    public boolean c;
    
    public boolean d;
    
    void a() {
      this.a = 0;
      this.b = false;
      this.c = false;
      this.d = false;
    }
  }
  
  static class c {
    boolean a = true;
    
    int b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    int g;
    
    int h = 0;
    
    boolean i;
    
    int j;
    
    List<RecyclerView.d0> k = null;
    
    boolean l;
    
    private View b() {
      int i = this.k.size();
      for (byte b = 0; b < i; b++) {
        View view = ((RecyclerView.d0)this.k.get(b)).c;
        RecyclerView.p p = (RecyclerView.p)view.getLayoutParams();
        if (!p.c() && this.d == p.a()) {
          a(view);
          return view;
        } 
      } 
      return null;
    }
    
    View a(RecyclerView.v param1v) {
      if (this.k != null)
        return b(); 
      View view = param1v.d(this.d);
      this.d += this.e;
      return view;
    }
    
    public void a() {
      a((View)null);
    }
    
    public void a(View param1View) {
      param1View = b(param1View);
      if (param1View == null) {
        this.d = -1;
      } else {
        this.d = ((RecyclerView.p)param1View.getLayoutParams()).a();
      } 
    }
    
    boolean a(RecyclerView.a0 param1a0) {
      boolean bool;
      int i = this.d;
      if (i >= 0 && i < param1a0.a()) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public View b(View param1View) {
      View view2;
      int j = this.k.size();
      View view1 = null;
      int i = Integer.MAX_VALUE;
      byte b = 0;
      while (true) {
        view2 = view1;
        if (b < j) {
          View view = ((RecyclerView.d0)this.k.get(b)).c;
          RecyclerView.p p = (RecyclerView.p)view.getLayoutParams();
          view2 = view1;
          int k = i;
          if (view != param1View)
            if (p.c()) {
              view2 = view1;
              k = i;
            } else {
              int m = (p.a() - this.d) * this.e;
              if (m < 0) {
                view2 = view1;
                k = i;
              } else {
                view2 = view1;
                k = i;
                if (m < i) {
                  view1 = view;
                  k = m;
                  view2 = view1;
                  if (m == 0) {
                    view2 = view1;
                    break;
                  } 
                } 
              } 
            }  
          b++;
          view1 = view2;
          i = k;
          continue;
        } 
        break;
      } 
      return view2;
    }
  }
  
  public static class d implements Parcelable {
    public static final Parcelable.Creator<d> CREATOR = new a();
    
    int c;
    
    int d;
    
    boolean e;
    
    public d() {}
    
    d(Parcel param1Parcel) {
      this.c = param1Parcel.readInt();
      this.d = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      this.e = bool;
    }
    
    public d(d param1d) {
      this.c = param1d.c;
      this.d = param1d.d;
      this.e = param1d.e;
    }
    
    boolean a() {
      boolean bool;
      if (this.c >= 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    void b() {
      this.c = -1;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeInt(this.c);
      param1Parcel.writeInt(this.d);
      param1Parcel.writeInt(this.e);
    }
    
    static final class a implements Parcelable.Creator<d> {
      public LinearLayoutManager.d createFromParcel(Parcel param2Parcel) {
        return new LinearLayoutManager.d(param2Parcel);
      }
      
      public LinearLayoutManager.d[] newArray(int param2Int) {
        return new LinearLayoutManager.d[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.Creator<d> {
    public LinearLayoutManager.d createFromParcel(Parcel param1Parcel) {
      return new LinearLayoutManager.d(param1Parcel);
    }
    
    public LinearLayoutManager.d[] newArray(int param1Int) {
      return new LinearLayoutManager.d[param1Int];
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\LinearLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */