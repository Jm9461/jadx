package android.support.v7.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Observable;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.support.v4.view.j;
import android.support.v4.view.s;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.FocusFinder;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RecyclerView extends ViewGroup implements s, j {
  private static final int[] B0 = new int[] { 16843830 };
  
  private static final int[] C0 = new int[] { 16842987 };
  
  static final boolean D0;
  
  static final boolean E0;
  
  static final boolean F0;
  
  static final boolean G0;
  
  private static final boolean H0;
  
  private static final boolean I0;
  
  private static final Class<?>[] J0;
  
  static final Interpolator K0 = new c();
  
  private boolean A;
  
  private final q1.b A0;
  
  private int B;
  
  boolean C;
  
  private final AccessibilityManager D;
  
  private List<q> E;
  
  boolean F;
  
  boolean G;
  
  private int H;
  
  private int I;
  
  private k J;
  
  private EdgeEffect K;
  
  private EdgeEffect L;
  
  private EdgeEffect M;
  
  private EdgeEffect N;
  
  l O;
  
  private int P;
  
  private int Q;
  
  private VelocityTracker R;
  
  private int S;
  
  private int T;
  
  private int U;
  
  private int V;
  
  private int W;
  
  private r a0;
  
  private final int b0;
  
  private final x c;
  
  private final int c0;
  
  final v d;
  
  private float d0;
  
  private y e;
  
  private float e0;
  
  d f;
  
  private boolean f0;
  
  d0 g;
  
  final c0 g0;
  
  final q1 h;
  
  m0 h0;
  
  boolean i;
  
  m0.b i0;
  
  final Runnable j;
  
  final a0 j0;
  
  final Rect k;
  
  private t k0;
  
  private final Rect l;
  
  private List<t> l0;
  
  final RectF m;
  
  boolean m0;
  
  g n;
  
  boolean n0;
  
  o o;
  
  private l.b o0;
  
  w p;
  
  boolean p0;
  
  final ArrayList<n> q;
  
  v0 q0;
  
  private final ArrayList<s> r;
  
  private j r0;
  
  private s s;
  
  private final int[] s0;
  
  boolean t;
  
  private android.support.v4.view.l t0;
  
  boolean u;
  
  private final int[] u0;
  
  boolean v;
  
  final int[] v0;
  
  boolean w;
  
  private final int[] w0;
  
  private int x;
  
  final int[] x0;
  
  boolean y;
  
  final List<d0> y0;
  
  boolean z;
  
  private Runnable z0;
  
  public RecyclerView(Context paramContext) {
    this(paramContext, null);
  }
  
  public RecyclerView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public RecyclerView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    m0.b b1;
    this.c = new x(this);
    this.d = new v(this);
    this.h = new q1();
    this.j = new a(this);
    this.k = new Rect();
    this.l = new Rect();
    this.m = new RectF();
    this.q = new ArrayList<n>();
    this.r = new ArrayList<s>();
    this.x = 0;
    this.F = false;
    this.G = false;
    this.H = 0;
    this.I = 0;
    this.J = new k();
    this.O = new g0();
    this.P = 0;
    this.Q = -1;
    this.d0 = Float.MIN_VALUE;
    this.e0 = Float.MIN_VALUE;
    this.f0 = true;
    this.g0 = new c0(this);
    if (G0) {
      b1 = new m0.b();
    } else {
      b1 = null;
    } 
    this.i0 = b1;
    this.j0 = new a0();
    this.m0 = false;
    this.n0 = false;
    this.o0 = new m(this);
    this.p0 = false;
    this.s0 = new int[2];
    this.u0 = new int[2];
    this.v0 = new int[2];
    this.w0 = new int[2];
    this.x0 = new int[2];
    this.y0 = new ArrayList<d0>();
    this.z0 = new b(this);
    this.A0 = new d(this);
    if (paramAttributeSet != null) {
      TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, C0, paramInt, 0);
      this.i = typedArray.getBoolean(0, true);
      typedArray.recycle();
    } else {
      this.i = true;
    } 
    setScrollContainer(true);
    setFocusableInTouchMode(true);
    ViewConfiguration viewConfiguration = ViewConfiguration.get(paramContext);
    this.W = viewConfiguration.getScaledTouchSlop();
    this.d0 = android.support.v4.view.v.b(viewConfiguration, paramContext);
    this.e0 = android.support.v4.view.v.c(viewConfiguration, paramContext);
    this.b0 = viewConfiguration.getScaledMinimumFlingVelocity();
    this.c0 = viewConfiguration.getScaledMaximumFlingVelocity();
    if (getOverScrollMode() == 2) {
      bool = true;
    } else {
      bool = false;
    } 
    setWillNotDraw(bool);
    this.O.a(this.o0);
    k();
    G();
    F();
    if (android.support.v4.view.u.i((View)this) == 0)
      android.support.v4.view.u.f((View)this, 1); 
    this.D = (AccessibilityManager)getContext().getSystemService("accessibility");
    setAccessibilityDelegateCompat(new v0(this));
    boolean bool1 = true;
    boolean bool = true;
    if (paramAttributeSet != null) {
      TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, a.b.h.e.b.RecyclerView, paramInt, 0);
      String str = typedArray.getString(a.b.h.e.b.RecyclerView_layoutManager);
      if (typedArray.getInt(a.b.h.e.b.RecyclerView_android_descendantFocusability, -1) == -1)
        setDescendantFocusability(262144); 
      this.v = typedArray.getBoolean(a.b.h.e.b.RecyclerView_fastScrollEnabled, false);
      if (this.v)
        a((StateListDrawable)typedArray.getDrawable(a.b.h.e.b.RecyclerView_fastScrollVerticalThumbDrawable), typedArray.getDrawable(a.b.h.e.b.RecyclerView_fastScrollVerticalTrackDrawable), (StateListDrawable)typedArray.getDrawable(a.b.h.e.b.RecyclerView_fastScrollHorizontalThumbDrawable), typedArray.getDrawable(a.b.h.e.b.RecyclerView_fastScrollHorizontalTrackDrawable)); 
      typedArray.recycle();
      a(paramContext, str, paramAttributeSet, paramInt, 0);
      if (Build.VERSION.SDK_INT >= 21) {
        TypedArray typedArray1 = paramContext.obtainStyledAttributes(paramAttributeSet, B0, paramInt, 0);
        bool = typedArray1.getBoolean(0, true);
        typedArray1.recycle();
      } 
    } else {
      setDescendantFocusability(262144);
      bool = bool1;
    } 
    setNestedScrollingEnabled(bool);
  }
  
  private void A() {
    a0 a01 = this.j0;
    boolean bool = true;
    a01.a(1);
    a(this.j0);
    this.j0.j = false;
    w();
    this.h.a();
    q();
    I();
    N();
    a01 = this.j0;
    if (!a01.k || !this.n0)
      bool = false; 
    a01.i = bool;
    this.n0 = false;
    this.m0 = false;
    a01 = this.j0;
    a01.h = a01.l;
    a01.f = this.n.a();
    a(this.s0);
    if (this.j0.k) {
      int i = this.g.a();
      for (byte b1 = 0; b1 < i; b1++) {
        d0 d01 = k(this.g.c(b1));
        if (!d01.x() && (!d01.n() || this.n.c())) {
          l.c c = this.O.a(this.j0, d01, l.e(d01), d01.k());
          this.h.c(d01, c);
          if (this.j0.i && d01.s() && !d01.p() && !d01.x() && !d01.n()) {
            long l1 = c(d01);
            this.h.a(l1, d01);
          } 
        } 
      } 
    } 
    if (this.j0.l) {
      v();
      a01 = this.j0;
      bool = a01.g;
      a01.g = false;
      this.o.e(this.d, a01);
      this.j0.g = bool;
      for (byte b1 = 0; b1 < this.g.a(); b1++) {
        d0 d01 = k(this.g.c(b1));
        if (!d01.x() && !this.h.c(d01)) {
          int m = l.e(d01);
          bool = d01.b(8192);
          int i = m;
          if (!bool)
            i = m | 0x1000; 
          l.c c = this.O.a(this.j0, d01, i, d01.k());
          if (bool) {
            a(d01, c);
          } else {
            this.h.a(d01, c);
          } 
        } 
      } 
      a();
    } else {
      a();
    } 
    r();
    c(false);
    this.j0.e = 2;
  }
  
  private void B() {
    boolean bool;
    w();
    q();
    this.j0.a(6);
    this.f.b();
    this.j0.f = this.n.a();
    a0 a01 = this.j0;
    a01.d = 0;
    a01.h = false;
    this.o.e(this.d, a01);
    a01 = this.j0;
    a01.g = false;
    this.e = null;
    if (a01.k && this.O != null) {
      bool = true;
    } else {
      bool = false;
    } 
    a01.k = bool;
    this.j0.e = 4;
    r();
    c(false);
  }
  
  private void C() {
    this.j0.a(4);
    w();
    q();
    a0 a01 = this.j0;
    a01.e = 1;
    if (a01.k) {
      for (int i = this.g.a() - 1; i >= 0; i--) {
        d0 d01 = k(this.g.c(i));
        if (!d01.x()) {
          long l1 = c(d01);
          l.c c = this.O.a(this.j0, d01);
          d0 d02 = this.h.a(l1);
          if (d02 != null && !d02.x()) {
            boolean bool1 = this.h.b(d02);
            boolean bool2 = this.h.b(d01);
            if (bool1 && d02 == d01) {
              this.h.b(d01, c);
            } else {
              l.c c1 = this.h.f(d02);
              this.h.b(d01, c);
              c = this.h.e(d01);
              if (c1 == null) {
                a(l1, d01, d02);
              } else {
                a(d02, d01, c1, c, bool1, bool2);
              } 
            } 
          } else {
            this.h.b(d01, c);
          } 
        } 
      } 
      this.h.a(this.A0);
    } 
    this.o.c(this.d);
    a01 = this.j0;
    a01.c = a01.f;
    this.F = false;
    this.G = false;
    a01.k = false;
    a01.l = false;
    this.o.h = false;
    ArrayList<d0> arrayList = this.d.b;
    if (arrayList != null)
      arrayList.clear(); 
    o o1 = this.o;
    if (o1.n) {
      o1.m = 0;
      o1.n = false;
      this.d.j();
    } 
    this.o.g(this.j0);
    r();
    c(false);
    this.h.a();
    int[] arrayOfInt = this.s0;
    if (k(arrayOfInt[0], arrayOfInt[1]))
      d(0, 0); 
    J();
    L();
  }
  
  private View D() {
    int i = this.j0.m;
    if (i == -1)
      i = 0; 
    int n = this.j0.a();
    for (int m = i; m < n; m++) {
      d0 d01 = c(m);
      if (d01 == null)
        break; 
      if (d01.c.hasFocusable())
        return d01.c; 
    } 
    for (i = Math.min(n, i) - 1; i >= 0; i--) {
      d0 d01 = c(i);
      if (d01 == null)
        return null; 
      if (d01.c.hasFocusable())
        return d01.c; 
    } 
    return null;
  }
  
  private boolean E() {
    int i = this.g.a();
    for (byte b1 = 0; b1 < i; b1++) {
      d0 d01 = k(this.g.c(b1));
      if (d01 != null && !d01.x() && d01.s())
        return true; 
    } 
    return false;
  }
  
  @SuppressLint({"InlinedApi"})
  private void F() {
    if (android.support.v4.view.u.j((View)this) == 0)
      android.support.v4.view.u.g((View)this, 8); 
  }
  
  private void G() {
    this.g = new d0(new e(this));
  }
  
  private boolean H() {
    boolean bool;
    if (this.O != null && this.o.C()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private void I() {
    boolean bool1;
    if (this.F) {
      this.f.f();
      if (this.G)
        this.o.d(this); 
    } 
    if (H()) {
      this.f.e();
    } else {
      this.f.b();
    } 
    boolean bool = this.m0;
    boolean bool2 = false;
    if (bool || this.n0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    a0 a01 = this.j0;
    if (this.w && this.O != null && (this.F || bool1 || this.o.h) && (!this.F || this.n.c())) {
      bool = true;
    } else {
      bool = false;
    } 
    a01.k = bool;
    a01 = this.j0;
    if (a01.k && bool1 && !this.F && H()) {
      bool = true;
    } else {
      bool = bool2;
    } 
    a01.l = bool;
  }
  
  private void J() {
    View view;
    if (!this.f0 || this.n == null || !hasFocus() || getDescendantFocusability() == 393216 || (getDescendantFocusability() == 131072 && isFocused()))
      return; 
    if (!isFocused()) {
      view = getFocusedChild();
      if (I0 && (view.getParent() == null || !view.hasFocus())) {
        if (this.g.a() == 0) {
          requestFocus();
          return;
        } 
      } else if (!this.g.c(view)) {
        return;
      } 
    } 
    d0 d02 = null;
    d0 d01 = d02;
    if (this.j0.n != -1L) {
      d01 = d02;
      if (this.n.c())
        d01 = a(this.j0.n); 
    } 
    d02 = null;
    if (d01 == null || this.g.c(d01.c) || !d01.c.hasFocusable()) {
      d01 = d02;
      if (this.g.a() > 0)
        view = D(); 
    } else {
      view = ((d0)view).c;
    } 
    if (view != null) {
      int i = this.j0.o;
      View view1 = view;
      if (i != -1L) {
        View view2 = view.findViewById(i);
        view1 = view;
        if (view2 != null) {
          view1 = view;
          if (view2.isFocusable())
            view1 = view2; 
        } 
      } 
      view1.requestFocus();
    } 
  }
  
  private void K() {
    boolean bool2 = false;
    EdgeEffect edgeEffect = this.K;
    if (edgeEffect != null) {
      edgeEffect.onRelease();
      bool2 = this.K.isFinished();
    } 
    edgeEffect = this.L;
    boolean bool1 = bool2;
    if (edgeEffect != null) {
      edgeEffect.onRelease();
      bool1 = bool2 | this.L.isFinished();
    } 
    edgeEffect = this.M;
    bool2 = bool1;
    if (edgeEffect != null) {
      edgeEffect.onRelease();
      bool2 = bool1 | this.M.isFinished();
    } 
    edgeEffect = this.N;
    bool1 = bool2;
    if (edgeEffect != null) {
      edgeEffect.onRelease();
      bool1 = bool2 | this.N.isFinished();
    } 
    if (bool1)
      android.support.v4.view.u.B((View)this); 
  }
  
  private void L() {
    a0 a01 = this.j0;
    a01.n = -1L;
    a01.m = -1;
    a01.o = -1;
  }
  
  private void M() {
    VelocityTracker velocityTracker = this.R;
    if (velocityTracker != null)
      velocityTracker.clear(); 
    a(0);
    K();
  }
  
  private void N() {
    d0 d01;
    View view2 = null;
    View view1 = view2;
    if (this.f0) {
      view1 = view2;
      if (hasFocus()) {
        view1 = view2;
        if (this.n != null)
          view1 = getFocusedChild(); 
      } 
    } 
    if (view1 == null) {
      view1 = null;
    } else {
      d01 = d(view1);
    } 
    if (d01 == null) {
      L();
    } else {
      int i;
      long l1;
      a0 a01 = this.j0;
      if (this.n.c()) {
        l1 = d01.g();
      } else {
        l1 = -1L;
      } 
      a01.n = l1;
      a01 = this.j0;
      if (this.F) {
        i = -1;
      } else if (d01.p()) {
        i = d01.f;
      } else {
        i = d01.f();
      } 
      a01.m = i;
      this.j0.o = l(d01.c);
    } 
  }
  
  private void O() {
    this.g0.b();
    o o1 = this.o;
    if (o1 != null)
      o1.B(); 
  }
  
  private String a(Context paramContext, String paramString) {
    if (paramString.charAt(0) == '.') {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(paramContext.getPackageName());
      stringBuilder1.append(paramString);
      return stringBuilder1.toString();
    } 
    if (paramString.contains("."))
      return paramString; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(RecyclerView.class.getPackage().getName());
    stringBuilder.append('.');
    stringBuilder.append(paramString);
    return stringBuilder.toString();
  }
  
  private void a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    boolean bool = false;
    if (paramFloat2 < 0.0F) {
      f();
      android.support.v4.widget.g.a(this.K, -paramFloat2 / getWidth(), 1.0F - paramFloat3 / getHeight());
      bool = true;
    } else if (paramFloat2 > 0.0F) {
      g();
      android.support.v4.widget.g.a(this.M, paramFloat2 / getWidth(), paramFloat3 / getHeight());
      bool = true;
    } 
    if (paramFloat4 < 0.0F) {
      h();
      android.support.v4.widget.g.a(this.L, -paramFloat4 / getHeight(), paramFloat1 / getWidth());
      bool = true;
    } else if (paramFloat4 > 0.0F) {
      e();
      android.support.v4.widget.g.a(this.N, paramFloat4 / getHeight(), 1.0F - paramFloat1 / getWidth());
      bool = true;
    } 
    if (bool || paramFloat2 != 0.0F || paramFloat4 != 0.0F)
      android.support.v4.view.u.B((View)this); 
  }
  
  private void a(long paramLong, d0 paramd01, d0 paramd02) {
    StringBuilder stringBuilder1;
    int i = this.g.a();
    for (byte b1 = 0; b1 < i; b1++) {
      d0 d01 = k(this.g.c(b1));
      if (d01 != paramd01 && c(d01) == paramLong) {
        g g1 = this.n;
        if (g1 != null && g1.c()) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Two different ViewHolders have the same stable ID. Stable IDs in your adapter MUST BE unique and SHOULD NOT change.\n ViewHolder 1:");
          stringBuilder.append(d01);
          stringBuilder.append(" \n View Holder 2:");
          stringBuilder.append(paramd01);
          stringBuilder.append(i());
          throw new IllegalStateException(stringBuilder.toString());
        } 
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Two different ViewHolders have the same change ID. This might happen due to inconsistent Adapter update events or if the LayoutManager lays out the same View multiple times.\n ViewHolder 1:");
        stringBuilder1.append(d01);
        stringBuilder1.append(" \n View Holder 2:");
        stringBuilder1.append(paramd01);
        stringBuilder1.append(i());
        throw new IllegalStateException(stringBuilder1.toString());
      } 
    } 
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("Problem while matching changed view holders with the newones. The pre-layout information for the change holder ");
    stringBuilder2.append(stringBuilder1);
    stringBuilder2.append(" cannot be found but it is necessary for ");
    stringBuilder2.append(paramd01);
    stringBuilder2.append(i());
    Log.e("RecyclerView", stringBuilder2.toString());
  }
  
  private void a(Context paramContext, String paramString, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    if (paramString != null) {
      paramString = paramString.trim();
      if (!paramString.isEmpty()) {
        String str = a(paramContext, paramString);
        try {
          StringBuilder stringBuilder;
          ClassLoader classLoader;
          if (isInEditMode()) {
            classLoader = getClass().getClassLoader();
          } else {
            classLoader = paramContext.getClassLoader();
          } 
          Class<? extends o> clazz = classLoader.loadClass(str).asSubclass(o.class);
          NoSuchMethodException noSuchMethodException2 = null;
          try {
            Constructor<? extends o> constructor = clazz.getConstructor(J0);
            Object[] arrayOfObject = { paramContext, paramAttributeSet, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) };
          } catch (NoSuchMethodException noSuchMethodException) {
            try {
              Constructor<? extends o> constructor = clazz.getConstructor(new Class[0]);
              noSuchMethodException = noSuchMethodException2;
              constructor.setAccessible(true);
              setLayoutManager(constructor.newInstance((Object[])noSuchMethodException));
            } catch (NoSuchMethodException noSuchMethodException1) {
              noSuchMethodException1.initCause(noSuchMethodException);
              IllegalStateException illegalStateException = new IllegalStateException();
              stringBuilder = new StringBuilder();
              this();
              stringBuilder.append(paramAttributeSet.getPositionDescription());
              stringBuilder.append(": Error creating LayoutManager ");
              stringBuilder.append(str);
              this(stringBuilder.toString(), noSuchMethodException1);
              throw illegalStateException;
            } 
          } 
          noSuchMethodException1.setAccessible(true);
          setLayoutManager(noSuchMethodException1.newInstance((Object[])stringBuilder));
        } catch (ClassNotFoundException classNotFoundException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramAttributeSet.getPositionDescription());
          stringBuilder.append(": Unable to find LayoutManager ");
          stringBuilder.append(str);
          throw new IllegalStateException(stringBuilder.toString(), classNotFoundException);
        } catch (InvocationTargetException invocationTargetException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramAttributeSet.getPositionDescription());
          stringBuilder.append(": Could not instantiate the LayoutManager: ");
          stringBuilder.append(str);
          throw new IllegalStateException(stringBuilder.toString(), invocationTargetException);
        } catch (InstantiationException instantiationException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramAttributeSet.getPositionDescription());
          stringBuilder.append(": Could not instantiate the LayoutManager: ");
          stringBuilder.append(str);
          throw new IllegalStateException(stringBuilder.toString(), instantiationException);
        } catch (IllegalAccessException illegalAccessException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramAttributeSet.getPositionDescription());
          stringBuilder.append(": Cannot access non-public constructor ");
          stringBuilder.append(str);
          throw new IllegalStateException(stringBuilder.toString(), illegalAccessException);
        } catch (ClassCastException classCastException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramAttributeSet.getPositionDescription());
          stringBuilder.append(": Class is not a LayoutManager ");
          stringBuilder.append(str);
          throw new IllegalStateException(stringBuilder.toString(), classCastException);
        } 
      } 
    } 
  }
  
  private void a(d0 paramd01, d0 paramd02, l.c paramc1, l.c paramc2, boolean paramBoolean1, boolean paramBoolean2) {
    paramd01.a(false);
    if (paramBoolean1)
      d(paramd01); 
    if (paramd01 != paramd02) {
      if (paramBoolean2)
        d(paramd02); 
      paramd01.j = paramd02;
      d(paramd01);
      this.d.c(paramd01);
      paramd02.a(false);
      paramd02.k = paramd01;
    } 
    if (this.O.a(paramd01, paramd02, paramc1, paramc2))
      s(); 
  }
  
  private void a(g paramg, boolean paramBoolean1, boolean paramBoolean2) {
    g g1 = this.n;
    if (g1 != null) {
      g1.b(this.c);
      this.n.b(this);
    } 
    if (!paramBoolean1 || paramBoolean2)
      t(); 
    this.f.f();
    g1 = this.n;
    this.n = paramg;
    if (paramg != null) {
      paramg.a(this.c);
      paramg.a(this);
    } 
    o o1 = this.o;
    if (o1 != null)
      o1.a(g1, this.n); 
    this.d.a(g1, this.n, paramBoolean1);
    this.j0.g = true;
  }
  
  static void a(View paramView, Rect paramRect) {
    p p = (p)paramView.getLayoutParams();
    Rect rect = p.b;
    paramRect.set(paramView.getLeft() - rect.left - p.leftMargin, paramView.getTop() - rect.top - p.topMargin, paramView.getRight() + rect.right + p.rightMargin, paramView.getBottom() + rect.bottom + p.bottomMargin);
  }
  
  private void a(View paramView1, View paramView2) {
    boolean bool;
    View view;
    if (paramView2 != null) {
      view = paramView2;
    } else {
      view = paramView1;
    } 
    this.k.set(0, 0, view.getWidth(), view.getHeight());
    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
    if (layoutParams instanceof p) {
      p p = (p)layoutParams;
      if (!p.c) {
        Rect rect2 = p.b;
        Rect rect1 = this.k;
        rect1.left -= rect2.left;
        rect1.right += rect2.right;
        rect1.top -= rect2.top;
        rect1.bottom += rect2.bottom;
      } 
    } 
    if (paramView2 != null) {
      offsetDescendantRectToMyCoords(paramView2, this.k);
      offsetRectIntoDescendantCoords(paramView1, this.k);
    } 
    o o1 = this.o;
    Rect rect = this.k;
    boolean bool1 = this.w;
    if (paramView2 == null) {
      bool = true;
    } else {
      bool = false;
    } 
    o1.a(this, paramView1, rect, bool1 ^ true, bool);
  }
  
  private void a(int[] paramArrayOfint) {
    int n = this.g.a();
    if (n == 0) {
      paramArrayOfint[0] = -1;
      paramArrayOfint[1] = -1;
      return;
    } 
    int i = Integer.MAX_VALUE;
    int m = Integer.MIN_VALUE;
    byte b1 = 0;
    while (b1 < n) {
      int i1;
      d0 d01 = k(this.g.c(b1));
      if (d01.x()) {
        i1 = m;
      } else {
        int i3 = d01.i();
        int i2 = i;
        if (i3 < i)
          i2 = i3; 
        i = i2;
        i1 = m;
        if (i3 > m) {
          i1 = i3;
          i = i2;
        } 
      } 
      b1++;
      m = i1;
    } 
    paramArrayOfint[0] = i;
    paramArrayOfint[1] = m;
  }
  
  private boolean a(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getAction();
    s s1 = this.s;
    if (s1 != null)
      if (i == 0) {
        this.s = null;
      } else {
        s1.a(this, paramMotionEvent);
        if (i == 3 || i == 1)
          this.s = null; 
        return true;
      }  
    if (i != 0) {
      int m = this.r.size();
      for (i = 0; i < m; i++) {
        s1 = this.r.get(i);
        if (s1.b(this, paramMotionEvent)) {
          this.s = s1;
          return true;
        } 
      } 
    } 
    return false;
  }
  
  private boolean a(View paramView1, View paramView2, int paramInt) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #13
    //   3: iconst_0
    //   4: istore #12
    //   6: iconst_0
    //   7: istore #14
    //   9: iconst_0
    //   10: istore #10
    //   12: iconst_0
    //   13: istore #11
    //   15: iconst_0
    //   16: istore #9
    //   18: aload_2
    //   19: ifnull -> 578
    //   22: aload_2
    //   23: aload_0
    //   24: if_acmpne -> 30
    //   27: goto -> 578
    //   30: aload_0
    //   31: aload_2
    //   32: invokevirtual c : (Landroid/view/View;)Landroid/view/View;
    //   35: ifnonnull -> 40
    //   38: iconst_0
    //   39: ireturn
    //   40: aload_1
    //   41: ifnonnull -> 46
    //   44: iconst_1
    //   45: ireturn
    //   46: aload_0
    //   47: aload_1
    //   48: invokevirtual c : (Landroid/view/View;)Landroid/view/View;
    //   51: ifnonnull -> 56
    //   54: iconst_1
    //   55: ireturn
    //   56: aload_0
    //   57: getfield k : Landroid/graphics/Rect;
    //   60: iconst_0
    //   61: iconst_0
    //   62: aload_1
    //   63: invokevirtual getWidth : ()I
    //   66: aload_1
    //   67: invokevirtual getHeight : ()I
    //   70: invokevirtual set : (IIII)V
    //   73: aload_0
    //   74: getfield l : Landroid/graphics/Rect;
    //   77: iconst_0
    //   78: iconst_0
    //   79: aload_2
    //   80: invokevirtual getWidth : ()I
    //   83: aload_2
    //   84: invokevirtual getHeight : ()I
    //   87: invokevirtual set : (IIII)V
    //   90: aload_0
    //   91: aload_1
    //   92: aload_0
    //   93: getfield k : Landroid/graphics/Rect;
    //   96: invokevirtual offsetDescendantRectToMyCoords : (Landroid/view/View;Landroid/graphics/Rect;)V
    //   99: aload_0
    //   100: aload_2
    //   101: aload_0
    //   102: getfield l : Landroid/graphics/Rect;
    //   105: invokevirtual offsetDescendantRectToMyCoords : (Landroid/view/View;Landroid/graphics/Rect;)V
    //   108: aload_0
    //   109: getfield o : Landroid/support/v7/widget/RecyclerView$o;
    //   112: invokevirtual j : ()I
    //   115: iconst_1
    //   116: if_icmpne -> 125
    //   119: iconst_m1
    //   120: istore #6
    //   122: goto -> 128
    //   125: iconst_1
    //   126: istore #6
    //   128: iconst_0
    //   129: istore #5
    //   131: aload_0
    //   132: getfield k : Landroid/graphics/Rect;
    //   135: astore_1
    //   136: aload_1
    //   137: getfield left : I
    //   140: istore #4
    //   142: aload_0
    //   143: getfield l : Landroid/graphics/Rect;
    //   146: getfield left : I
    //   149: istore #7
    //   151: iload #4
    //   153: iload #7
    //   155: if_icmplt -> 167
    //   158: aload_1
    //   159: getfield right : I
    //   162: iload #7
    //   164: if_icmpgt -> 190
    //   167: aload_0
    //   168: getfield k : Landroid/graphics/Rect;
    //   171: getfield right : I
    //   174: aload_0
    //   175: getfield l : Landroid/graphics/Rect;
    //   178: getfield right : I
    //   181: if_icmpge -> 190
    //   184: iconst_1
    //   185: istore #4
    //   187: goto -> 254
    //   190: aload_0
    //   191: getfield k : Landroid/graphics/Rect;
    //   194: astore_1
    //   195: aload_1
    //   196: getfield right : I
    //   199: istore #4
    //   201: aload_0
    //   202: getfield l : Landroid/graphics/Rect;
    //   205: getfield right : I
    //   208: istore #7
    //   210: iload #4
    //   212: iload #7
    //   214: if_icmpgt -> 230
    //   217: iload #5
    //   219: istore #4
    //   221: aload_1
    //   222: getfield left : I
    //   225: iload #7
    //   227: if_icmplt -> 254
    //   230: iload #5
    //   232: istore #4
    //   234: aload_0
    //   235: getfield k : Landroid/graphics/Rect;
    //   238: getfield left : I
    //   241: aload_0
    //   242: getfield l : Landroid/graphics/Rect;
    //   245: getfield left : I
    //   248: if_icmple -> 254
    //   251: iconst_m1
    //   252: istore #4
    //   254: iconst_0
    //   255: istore #7
    //   257: aload_0
    //   258: getfield k : Landroid/graphics/Rect;
    //   261: astore_1
    //   262: aload_1
    //   263: getfield top : I
    //   266: istore #8
    //   268: aload_0
    //   269: getfield l : Landroid/graphics/Rect;
    //   272: getfield top : I
    //   275: istore #5
    //   277: iload #8
    //   279: iload #5
    //   281: if_icmplt -> 293
    //   284: aload_1
    //   285: getfield bottom : I
    //   288: iload #5
    //   290: if_icmpgt -> 316
    //   293: aload_0
    //   294: getfield k : Landroid/graphics/Rect;
    //   297: getfield bottom : I
    //   300: aload_0
    //   301: getfield l : Landroid/graphics/Rect;
    //   304: getfield bottom : I
    //   307: if_icmpge -> 316
    //   310: iconst_1
    //   311: istore #5
    //   313: goto -> 380
    //   316: aload_0
    //   317: getfield k : Landroid/graphics/Rect;
    //   320: astore_1
    //   321: aload_1
    //   322: getfield bottom : I
    //   325: istore #5
    //   327: aload_0
    //   328: getfield l : Landroid/graphics/Rect;
    //   331: getfield bottom : I
    //   334: istore #8
    //   336: iload #5
    //   338: iload #8
    //   340: if_icmpgt -> 356
    //   343: iload #7
    //   345: istore #5
    //   347: aload_1
    //   348: getfield top : I
    //   351: iload #8
    //   353: if_icmplt -> 380
    //   356: iload #7
    //   358: istore #5
    //   360: aload_0
    //   361: getfield k : Landroid/graphics/Rect;
    //   364: getfield top : I
    //   367: aload_0
    //   368: getfield l : Landroid/graphics/Rect;
    //   371: getfield top : I
    //   374: if_icmple -> 380
    //   377: iconst_m1
    //   378: istore #5
    //   380: iload_3
    //   381: iconst_1
    //   382: if_icmpeq -> 546
    //   385: iload_3
    //   386: iconst_2
    //   387: if_icmpeq -> 514
    //   390: iload_3
    //   391: bipush #17
    //   393: if_icmpeq -> 499
    //   396: iload_3
    //   397: bipush #33
    //   399: if_icmpeq -> 484
    //   402: iload_3
    //   403: bipush #66
    //   405: if_icmpeq -> 469
    //   408: iload_3
    //   409: sipush #130
    //   412: if_icmpne -> 426
    //   415: iload #5
    //   417: ifle -> 423
    //   420: iconst_1
    //   421: istore #9
    //   423: iload #9
    //   425: ireturn
    //   426: new java/lang/StringBuilder
    //   429: dup
    //   430: invokespecial <init> : ()V
    //   433: astore_1
    //   434: aload_1
    //   435: ldc_w 'Invalid direction: '
    //   438: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   441: pop
    //   442: aload_1
    //   443: iload_3
    //   444: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   447: pop
    //   448: aload_1
    //   449: aload_0
    //   450: invokevirtual i : ()Ljava/lang/String;
    //   453: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   456: pop
    //   457: new java/lang/IllegalArgumentException
    //   460: dup
    //   461: aload_1
    //   462: invokevirtual toString : ()Ljava/lang/String;
    //   465: invokespecial <init> : (Ljava/lang/String;)V
    //   468: athrow
    //   469: iload #13
    //   471: istore #9
    //   473: iload #4
    //   475: ifle -> 481
    //   478: iconst_1
    //   479: istore #9
    //   481: iload #9
    //   483: ireturn
    //   484: iload #12
    //   486: istore #9
    //   488: iload #5
    //   490: ifge -> 496
    //   493: iconst_1
    //   494: istore #9
    //   496: iload #9
    //   498: ireturn
    //   499: iload #14
    //   501: istore #9
    //   503: iload #4
    //   505: ifge -> 511
    //   508: iconst_1
    //   509: istore #9
    //   511: iload #9
    //   513: ireturn
    //   514: iload #5
    //   516: ifgt -> 540
    //   519: iload #10
    //   521: istore #9
    //   523: iload #5
    //   525: ifne -> 543
    //   528: iload #10
    //   530: istore #9
    //   532: iload #4
    //   534: iload #6
    //   536: imul
    //   537: iflt -> 543
    //   540: iconst_1
    //   541: istore #9
    //   543: iload #9
    //   545: ireturn
    //   546: iload #5
    //   548: iflt -> 572
    //   551: iload #11
    //   553: istore #9
    //   555: iload #5
    //   557: ifne -> 575
    //   560: iload #11
    //   562: istore #9
    //   564: iload #4
    //   566: iload #6
    //   568: imul
    //   569: ifgt -> 575
    //   572: iconst_1
    //   573: istore #9
    //   575: iload #9
    //   577: ireturn
    //   578: iconst_0
    //   579: ireturn
  }
  
  private boolean b(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getAction();
    if (i == 3 || i == 0)
      this.s = null; 
    int m = this.r.size();
    for (byte b1 = 0; b1 < m; b1++) {
      s s1 = this.r.get(b1);
      if (s1.b(this, paramMotionEvent) && i != 3) {
        this.s = s1;
        return true;
      } 
    } 
    return false;
  }
  
  private void c(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(i) == this.Q) {
      if (i == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      this.Q = paramMotionEvent.getPointerId(i);
      int m = (int)(paramMotionEvent.getX(i) + 0.5F);
      this.U = m;
      this.S = m;
      i = (int)(paramMotionEvent.getY(i) + 0.5F);
      this.V = i;
      this.T = i;
    } 
  }
  
  private void d(d0 paramd0) {
    boolean bool;
    View view = paramd0.c;
    if (view.getParent() == this) {
      bool = true;
    } else {
      bool = false;
    } 
    this.d.c(e(view));
    if (paramd0.r()) {
      this.g.a(view, -1, view.getLayoutParams(), true);
    } else if (!bool) {
      this.g.a(view, true);
    } else {
      this.g.a(view);
    } 
  }
  
  static void e(d0 paramd0) {
    WeakReference<RecyclerView> weakReference = paramd0.d;
    if (weakReference != null) {
      View view = (View)weakReference.get();
      while (view != null) {
        if (view == paramd0.c)
          return; 
        ViewParent viewParent = view.getParent();
        if (viewParent instanceof View) {
          View view1 = (View)viewParent;
          continue;
        } 
        viewParent = null;
      } 
      paramd0.d = null;
    } 
  }
  
  private android.support.v4.view.l getScrollingChildHelper() {
    if (this.t0 == null)
      this.t0 = new android.support.v4.view.l((View)this); 
    return this.t0;
  }
  
  static RecyclerView j(View paramView) {
    if (!(paramView instanceof ViewGroup))
      return null; 
    if (paramView instanceof RecyclerView)
      return (RecyclerView)paramView; 
    ViewGroup viewGroup = (ViewGroup)paramView;
    int i = viewGroup.getChildCount();
    for (byte b1 = 0; b1 < i; b1++) {
      RecyclerView recyclerView = j(viewGroup.getChildAt(b1));
      if (recyclerView != null)
        return recyclerView; 
    } 
    return null;
  }
  
  static d0 k(View paramView) {
    return (paramView == null) ? null : ((p)paramView.getLayoutParams()).a;
  }
  
  private boolean k(int paramInt1, int paramInt2) {
    a(this.s0);
    int[] arrayOfInt = this.s0;
    boolean bool = false;
    if (arrayOfInt[0] != paramInt1 || arrayOfInt[1] != paramInt2)
      bool = true; 
    return bool;
  }
  
  private int l(View paramView) {
    int i = paramView.getId();
    while (!paramView.isFocused() && paramView instanceof ViewGroup && paramView.hasFocus()) {
      paramView = ((ViewGroup)paramView).getFocusedChild();
      if (paramView.getId() != -1)
        i = paramView.getId(); 
    } 
    return i;
  }
  
  private void y() {
    M();
    setScrollState(0);
  }
  
  private void z() {
    int i = this.B;
    this.B = 0;
    if (i != 0 && m()) {
      AccessibilityEvent accessibilityEvent = AccessibilityEvent.obtain();
      accessibilityEvent.setEventType(2048);
      android.support.v4.view.d0.a.a(accessibilityEvent, i);
      sendAccessibilityEventUnchecked(accessibilityEvent);
    } 
  }
  
  d0 a(int paramInt, boolean paramBoolean) {
    int i = this.g.b();
    Object object = null;
    byte b1 = 0;
    while (b1 < i) {
      d0 d01 = k(this.g.d(b1));
      Object object1 = object;
      if (d01 != null) {
        object1 = object;
        if (!d01.p()) {
          if (paramBoolean) {
            if (d01.e != paramInt) {
              object1 = object;
              continue;
            } 
          } else if (d01.i() != paramInt) {
            object1 = object;
            continue;
          } 
          if (this.g.c(d01.c)) {
            object1 = d01;
          } else {
            return d01;
          } 
        } 
      } 
      continue;
      b1++;
      object = SYNTHETIC_LOCAL_VARIABLE_5;
    } 
    return (d0)object;
  }
  
  public d0 a(long paramLong) {
    d0 d01;
    g g1 = this.n;
    if (g1 == null || !g1.c())
      return null; 
    int i = this.g.b();
    g g2 = null;
    byte b1 = 0;
    while (b1 < i) {
      d0 d02;
      d0 d03 = k(this.g.d(b1));
      g1 = g2;
      if (d03 != null) {
        g1 = g2;
        if (!d03.p()) {
          g1 = g2;
          if (d03.g() == paramLong)
            if (this.g.c(d03.c)) {
              d02 = d03;
            } else {
              return d03;
            }  
        } 
      } 
      b1++;
      d01 = d02;
    } 
    return d01;
  }
  
  void a() {
    int i = this.g.b();
    for (byte b1 = 0; b1 < i; b1++) {
      d0 d01 = k(this.g.d(b1));
      if (!d01.x())
        d01.a(); 
    } 
    this.d.b();
  }
  
  public void a(int paramInt) {
    getScrollingChildHelper().c(paramInt);
  }
  
  void a(int paramInt1, int paramInt2) {
    if (paramInt1 < 0) {
      f();
      this.K.onAbsorb(-paramInt1);
    } else if (paramInt1 > 0) {
      g();
      this.M.onAbsorb(paramInt1);
    } 
    if (paramInt2 < 0) {
      h();
      this.L.onAbsorb(-paramInt2);
    } else if (paramInt2 > 0) {
      e();
      this.N.onAbsorb(paramInt2);
    } 
    if (paramInt1 != 0 || paramInt2 != 0)
      android.support.v4.view.u.B((View)this); 
  }
  
  public void a(int paramInt1, int paramInt2, Interpolator paramInterpolator) {
    o o1 = this.o;
    if (o1 == null) {
      Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
      return;
    } 
    if (this.z)
      return; 
    if (!o1.a())
      paramInt1 = 0; 
    if (!this.o.b())
      paramInt2 = 0; 
    if (paramInt1 != 0 || paramInt2 != 0)
      this.g0.a(paramInt1, paramInt2, paramInterpolator); 
  }
  
  void a(int paramInt1, int paramInt2, Object paramObject) {
    int i = this.g.b();
    for (byte b1 = 0; b1 < i; b1++) {
      View view = this.g.d(b1);
      d0 d01 = k(view);
      if (d01 != null && !d01.x()) {
        int m = d01.e;
        if (m >= paramInt1 && m < paramInt1 + paramInt2) {
          d01.a(2);
          d01.a(paramObject);
          ((p)view.getLayoutParams()).c = true;
        } 
      } 
    } 
    this.d.c(paramInt1, paramInt2);
  }
  
  void a(int paramInt1, int paramInt2, boolean paramBoolean) {
    int i = this.g.b();
    for (byte b1 = 0; b1 < i; b1++) {
      d0 d01 = k(this.g.d(b1));
      if (d01 != null && !d01.x()) {
        int m = d01.e;
        if (m >= paramInt1 + paramInt2) {
          d01.a(-paramInt2, paramBoolean);
          this.j0.g = true;
        } else if (m >= paramInt1) {
          d01.a(paramInt1 - 1, -paramInt2, paramBoolean);
          this.j0.g = true;
        } 
      } 
    } 
    this.d.a(paramInt1, paramInt2, paramBoolean);
    requestLayout();
  }
  
  void a(int paramInt1, int paramInt2, int[] paramArrayOfint) {
    w();
    q();
    a.b.g.d.a.a("RV Scroll");
    a(this.j0);
    int i = 0;
    boolean bool = false;
    if (paramInt1 != 0)
      i = this.o.a(paramInt1, this.d, this.j0); 
    paramInt1 = bool;
    if (paramInt2 != 0)
      paramInt1 = this.o.b(paramInt2, this.d, this.j0); 
    a.b.g.d.a.a();
    u();
    r();
    c(false);
    if (paramArrayOfint != null) {
      paramArrayOfint[0] = i;
      paramArrayOfint[1] = paramInt1;
    } 
  }
  
  void a(StateListDrawable paramStateListDrawable1, Drawable paramDrawable1, StateListDrawable paramStateListDrawable2, Drawable paramDrawable2) {
    if (paramStateListDrawable1 != null && paramDrawable1 != null && paramStateListDrawable2 != null && paramDrawable2 != null) {
      Resources resources = getContext().getResources();
      new j0(this, paramStateListDrawable1, paramDrawable1, paramStateListDrawable2, paramDrawable2, resources.getDimensionPixelSize(a.b.h.e.a.fastscroll_default_thickness), resources.getDimensionPixelSize(a.b.h.e.a.fastscroll_minimum_range), resources.getDimensionPixelOffset(a.b.h.e.a.fastscroll_margin));
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Trying to set fast scroller without both required drawables.");
    stringBuilder.append(i());
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  final void a(a0 parama0) {
    if (getScrollState() == 2) {
      OverScroller overScroller = this.g0.e;
      parama0.p = overScroller.getFinalX() - overScroller.getCurrX();
      parama0.q = overScroller.getFinalY() - overScroller.getCurrY();
    } else {
      parama0.p = 0;
      parama0.q = 0;
    } 
  }
  
  void a(d0 paramd0, l.c paramc) {
    paramd0.a(0, 8192);
    if (this.j0.i && paramd0.s() && !paramd0.p() && !paramd0.x()) {
      long l1 = c(paramd0);
      this.h.a(l1, paramd0);
    } 
    this.h.c(paramd0, paramc);
  }
  
  void a(d0 paramd0, l.c paramc1, l.c paramc2) {
    paramd0.a(false);
    if (this.O.a(paramd0, paramc1, paramc2))
      s(); 
  }
  
  public void a(n paramn) {
    a(paramn, -1);
  }
  
  public void a(n paramn, int paramInt) {
    o o1 = this.o;
    if (o1 != null)
      o1.a("Cannot add item decoration during a scroll  or layout"); 
    if (this.q.isEmpty())
      setWillNotDraw(false); 
    if (paramInt < 0) {
      this.q.add(paramn);
    } else {
      this.q.add(paramInt, paramn);
    } 
    o();
    requestLayout();
  }
  
  public void a(s params) {
    this.r.add(params);
  }
  
  public void a(t paramt) {
    if (this.l0 == null)
      this.l0 = new ArrayList<t>(); 
    this.l0.add(paramt);
  }
  
  void a(View paramView) {
    d0 d01 = k(paramView);
    g(paramView);
    g<d0> g1 = this.n;
    if (g1 != null && d01 != null)
      g1.b(d01); 
    List<q> list = this.E;
    if (list != null)
      for (int i = list.size() - 1; i >= 0; i--)
        ((q)this.E.get(i)).a(paramView);  
  }
  
  void a(String paramString) {
    if (n()) {
      StringBuilder stringBuilder;
      if (paramString == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot call this method while RecyclerView is computing a layout or scrolling");
        stringBuilder.append(i());
        throw new IllegalStateException(stringBuilder.toString());
      } 
      throw new IllegalStateException(stringBuilder);
    } 
    if (this.I > 0) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("");
      stringBuilder.append(i());
      Log.w("RecyclerView", "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException(stringBuilder.toString()));
    } 
  }
  
  void a(boolean paramBoolean) {
    this.H--;
    if (this.H < 1) {
      this.H = 0;
      if (paramBoolean) {
        z();
        d();
      } 
    } 
  }
  
  public boolean a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint, int paramInt5) {
    return getScrollingChildHelper().a(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint, paramInt5);
  }
  
  boolean a(int paramInt1, int paramInt2, MotionEvent paramMotionEvent) {
    int[] arrayOfInt;
    boolean bool1;
    boolean bool2;
    boolean bool3;
    boolean bool4;
    b();
    g g1 = this.n;
    boolean bool5 = false;
    if (g1 != null) {
      a(paramInt1, paramInt2, this.x0);
      int[] arrayOfInt1 = this.x0;
      bool1 = arrayOfInt1[0];
      bool2 = arrayOfInt1[1];
      bool4 = paramInt1 - bool1;
      bool3 = paramInt2 - bool2;
    } else {
      bool4 = false;
      bool3 = false;
      bool1 = false;
      bool2 = false;
    } 
    if (!this.q.isEmpty())
      invalidate(); 
    if (a(bool1, bool2, bool4, bool3, this.u0, 0)) {
      paramInt1 = this.U;
      int[] arrayOfInt1 = this.u0;
      this.U = paramInt1 - arrayOfInt1[0];
      this.V -= arrayOfInt1[1];
      if (paramMotionEvent != null)
        paramMotionEvent.offsetLocation(arrayOfInt1[0], arrayOfInt1[1]); 
      arrayOfInt = this.w0;
      paramInt1 = arrayOfInt[0];
      arrayOfInt1 = this.u0;
      arrayOfInt[0] = paramInt1 + arrayOfInt1[0];
      arrayOfInt[1] = arrayOfInt[1] + arrayOfInt1[1];
    } else if (getOverScrollMode() != 2) {
      if (arrayOfInt != null && !android.support.v4.view.i.a((MotionEvent)arrayOfInt, 8194))
        a(arrayOfInt.getX(), bool4, arrayOfInt.getY(), bool3); 
      b(paramInt1, paramInt2);
    } 
    if (bool1 || bool2)
      d(bool1, bool2); 
    if (!awakenScrollBars())
      invalidate(); 
    if (bool1 || bool2)
      bool5 = true; 
    return bool5;
  }
  
  public boolean a(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt3) {
    return getScrollingChildHelper().a(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, paramInt3);
  }
  
  boolean a(d0 paramd0) {
    l l1 = this.O;
    return (l1 == null || l1.a(paramd0, paramd0.k()));
  }
  
  boolean a(d0 paramd0, int paramInt) {
    if (n()) {
      paramd0.s = paramInt;
      this.y0.add(paramd0);
      return false;
    } 
    android.support.v4.view.u.f(paramd0.c, paramInt);
    return true;
  }
  
  boolean a(AccessibilityEvent paramAccessibilityEvent) {
    if (n()) {
      int i = 0;
      if (paramAccessibilityEvent != null)
        i = android.support.v4.view.d0.a.a(paramAccessibilityEvent); 
      int m = i;
      if (i == 0)
        m = 0; 
      this.B |= m;
      return true;
    } 
    return false;
  }
  
  public void addFocusables(ArrayList<View> paramArrayList, int paramInt1, int paramInt2) {
    o o1 = this.o;
    if (o1 == null || !o1.a(this, paramArrayList, paramInt1, paramInt2))
      super.addFocusables(paramArrayList, paramInt1, paramInt2); 
  }
  
  int b(d0 paramd0) {
    return (paramd0.b(524) || !paramd0.m()) ? -1 : this.f.a(paramd0.e);
  }
  
  void b() {
    if (!this.w || this.F) {
      a.b.g.d.a.a("RV FullInvalidate");
      c();
      a.b.g.d.a.a();
      return;
    } 
    if (!this.f.c())
      return; 
    if (this.f.c(4) && !this.f.c(11)) {
      a.b.g.d.a.a("RV PartialInvalidate");
      w();
      q();
      this.f.e();
      if (!this.y)
        if (E()) {
          c();
        } else {
          this.f.a();
        }  
      c(true);
      r();
      a.b.g.d.a.a();
    } else if (this.f.c()) {
      a.b.g.d.a.a("RV FullInvalidate");
      c();
      a.b.g.d.a.a();
    } 
  }
  
  void b(int paramInt) {
    o o1 = this.o;
    if (o1 != null)
      o1.f(paramInt); 
    g(paramInt);
    t t1 = this.k0;
    if (t1 != null)
      t1.a(this, paramInt); 
    List<t> list = this.l0;
    if (list != null)
      for (int i = list.size() - 1; i >= 0; i--)
        ((t)this.l0.get(i)).a(this, paramInt);  
  }
  
  void b(int paramInt1, int paramInt2) {
    boolean bool2 = false;
    EdgeEffect edgeEffect = this.K;
    boolean bool1 = bool2;
    if (edgeEffect != null) {
      bool1 = bool2;
      if (!edgeEffect.isFinished()) {
        bool1 = bool2;
        if (paramInt1 > 0) {
          this.K.onRelease();
          bool1 = this.K.isFinished();
        } 
      } 
    } 
    edgeEffect = this.M;
    bool2 = bool1;
    if (edgeEffect != null) {
      bool2 = bool1;
      if (!edgeEffect.isFinished()) {
        bool2 = bool1;
        if (paramInt1 < 0) {
          this.M.onRelease();
          bool2 = bool1 | this.M.isFinished();
        } 
      } 
    } 
    edgeEffect = this.L;
    bool1 = bool2;
    if (edgeEffect != null) {
      bool1 = bool2;
      if (!edgeEffect.isFinished()) {
        bool1 = bool2;
        if (paramInt2 > 0) {
          this.L.onRelease();
          bool1 = bool2 | this.L.isFinished();
        } 
      } 
    } 
    edgeEffect = this.N;
    bool2 = bool1;
    if (edgeEffect != null) {
      bool2 = bool1;
      if (!edgeEffect.isFinished()) {
        bool2 = bool1;
        if (paramInt2 < 0) {
          this.N.onRelease();
          bool2 = bool1 | this.N.isFinished();
        } 
      } 
    } 
    if (bool2)
      android.support.v4.view.u.B((View)this); 
  }
  
  void b(d0 paramd0, l.c paramc1, l.c paramc2) {
    d(paramd0);
    paramd0.a(false);
    if (this.O.b(paramd0, paramc1, paramc2))
      s(); 
  }
  
  public void b(n paramn) {
    o o1 = this.o;
    if (o1 != null)
      o1.a("Cannot remove item decoration during a scroll  or layout"); 
    this.q.remove(paramn);
    if (this.q.isEmpty()) {
      boolean bool;
      if (getOverScrollMode() == 2) {
        bool = true;
      } else {
        bool = false;
      } 
      setWillNotDraw(bool);
    } 
    o();
    requestLayout();
  }
  
  public void b(s params) {
    this.r.remove(params);
    if (this.s == params)
      this.s = null; 
  }
  
  public void b(t paramt) {
    List<t> list = this.l0;
    if (list != null)
      list.remove(paramt); 
  }
  
  void b(View paramView) {
    d0 d01 = k(paramView);
    h(paramView);
    g<d0> g1 = this.n;
    if (g1 != null && d01 != null)
      g1.c(d01); 
    List<q> list = this.E;
    if (list != null)
      for (int i = list.size() - 1; i >= 0; i--)
        ((q)this.E.get(i)).b(paramView);  
  }
  
  void b(boolean paramBoolean) {
    this.G |= paramBoolean;
    this.F = true;
    p();
  }
  
  long c(d0 paramd0) {
    long l1;
    if (this.n.c()) {
      l1 = paramd0.g();
    } else {
      l1 = paramd0.e;
    } 
    return l1;
  }
  
  public d0 c(int paramInt) {
    if (this.F)
      return null; 
    int i = this.g.b();
    d0 d01 = null;
    byte b1 = 0;
    while (b1 < i) {
      d0 d03 = k(this.g.d(b1));
      d0 d02 = d01;
      if (d03 != null) {
        d02 = d01;
        if (!d03.p()) {
          d02 = d01;
          if (b(d03) == paramInt)
            if (this.g.c(d03.c)) {
              d02 = d03;
            } else {
              return d03;
            }  
        } 
      } 
      b1++;
      d01 = d02;
    } 
    return d01;
  }
  
  public View c(View paramView) {
    ViewParent viewParent;
    for (viewParent = paramView.getParent(); viewParent != null && viewParent != this && viewParent instanceof View; viewParent = paramView.getParent())
      paramView = (View)viewParent; 
    if (viewParent != this)
      paramView = null; 
    return paramView;
  }
  
  void c() {
    if (this.n == null) {
      Log.e("RecyclerView", "No adapter attached; skipping layout");
      return;
    } 
    if (this.o == null) {
      Log.e("RecyclerView", "No layout manager attached; skipping layout");
      return;
    } 
    a0 a01 = this.j0;
    a01.j = false;
    if (a01.e == 1) {
      A();
      this.o.e(this);
      B();
    } else if (this.f.d() || this.o.q() != getWidth() || this.o.h() != getHeight()) {
      this.o.e(this);
      B();
    } else {
      this.o.e(this);
    } 
    C();
  }
  
  void c(int paramInt1, int paramInt2) {
    paramInt1 = o.a(paramInt1, getPaddingLeft() + getPaddingRight(), android.support.v4.view.u.m((View)this));
    setMeasuredDimension(paramInt1, o.a(paramInt2, getPaddingTop() + getPaddingBottom(), android.support.v4.view.u.l((View)this)));
  }
  
  void c(boolean paramBoolean) {
    if (this.x < 1)
      this.x = 1; 
    if (!paramBoolean && !this.z)
      this.y = false; 
    if (this.x == 1) {
      if (paramBoolean && this.y && !this.z && this.o != null && this.n != null)
        c(); 
      if (!this.z)
        this.y = false; 
    } 
    this.x--;
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    boolean bool;
    if (paramLayoutParams instanceof p && this.o.a((p)paramLayoutParams)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int computeHorizontalScrollExtent() {
    o o1 = this.o;
    int i = 0;
    if (o1 == null)
      return 0; 
    if (o1.a())
      i = this.o.a(this.j0); 
    return i;
  }
  
  public int computeHorizontalScrollOffset() {
    o o1 = this.o;
    int i = 0;
    if (o1 == null)
      return 0; 
    if (o1.a())
      i = this.o.b(this.j0); 
    return i;
  }
  
  public int computeHorizontalScrollRange() {
    o o1 = this.o;
    int i = 0;
    if (o1 == null)
      return 0; 
    if (o1.a())
      i = this.o.c(this.j0); 
    return i;
  }
  
  public int computeVerticalScrollExtent() {
    o o1 = this.o;
    int i = 0;
    if (o1 == null)
      return 0; 
    if (o1.b())
      i = this.o.d(this.j0); 
    return i;
  }
  
  public int computeVerticalScrollOffset() {
    o o1 = this.o;
    int i = 0;
    if (o1 == null)
      return 0; 
    if (o1.b())
      i = this.o.e(this.j0); 
    return i;
  }
  
  public int computeVerticalScrollRange() {
    o o1 = this.o;
    int i = 0;
    if (o1 == null)
      return 0; 
    if (o1.b())
      i = this.o.f(this.j0); 
    return i;
  }
  
  public d0 d(View paramView) {
    d0 d01;
    paramView = c(paramView);
    if (paramView == null) {
      paramView = null;
    } else {
      d01 = e(paramView);
    } 
    return d01;
  }
  
  void d() {
    for (int i = this.y0.size() - 1; i >= 0; i--) {
      d0 d01 = this.y0.get(i);
      if (d01.c.getParent() == this && !d01.x()) {
        int m = d01.s;
        if (m != -1) {
          android.support.v4.view.u.f(d01.c, m);
          d01.s = -1;
        } 
      } 
    } 
    this.y0.clear();
  }
  
  void d(int paramInt1, int paramInt2) {
    this.I++;
    int m = getScrollX();
    int i = getScrollY();
    onScrollChanged(m, i, m, i);
    h(paramInt1, paramInt2);
    t t1 = this.k0;
    if (t1 != null)
      t1.a(this, paramInt1, paramInt2); 
    List<t> list = this.l0;
    if (list != null)
      for (i = list.size() - 1; i >= 0; i--)
        ((t)this.l0.get(i)).a(this, paramInt1, paramInt2);  
    this.I--;
  }
  
  public boolean d(int paramInt) {
    return getScrollingChildHelper().a(paramInt);
  }
  
  public boolean dispatchNestedFling(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return getScrollingChildHelper().a(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public boolean dispatchNestedPreFling(float paramFloat1, float paramFloat2) {
    return getScrollingChildHelper().a(paramFloat1, paramFloat2);
  }
  
  public boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    return getScrollingChildHelper().a(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2);
  }
  
  public boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    return getScrollingChildHelper().a(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint);
  }
  
  protected void dispatchRestoreInstanceState(SparseArray<Parcelable> paramSparseArray) {
    dispatchThawSelfOnly(paramSparseArray);
  }
  
  protected void dispatchSaveInstanceState(SparseArray<Parcelable> paramSparseArray) {
    dispatchFreezeSelfOnly(paramSparseArray);
  }
  
  public void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
    int m = this.q.size();
    int i;
    for (i = 0; i < m; i++)
      ((n)this.q.get(i)).b(paramCanvas, this, this.j0); 
    i = 0;
    EdgeEffect edgeEffect = this.K;
    boolean bool = true;
    m = i;
    if (edgeEffect != null) {
      m = i;
      if (!edgeEffect.isFinished()) {
        m = paramCanvas.save();
        if (this.i) {
          i = getPaddingBottom();
        } else {
          i = 0;
        } 
        paramCanvas.rotate(270.0F);
        paramCanvas.translate((-getHeight() + i), 0.0F);
        edgeEffect = this.K;
        if (edgeEffect != null && edgeEffect.draw(paramCanvas)) {
          i = 1;
        } else {
          i = 0;
        } 
        paramCanvas.restoreToCount(m);
        m = i;
      } 
    } 
    edgeEffect = this.L;
    i = m;
    if (edgeEffect != null) {
      i = m;
      if (!edgeEffect.isFinished()) {
        int n = paramCanvas.save();
        if (this.i)
          paramCanvas.translate(getPaddingLeft(), getPaddingTop()); 
        edgeEffect = this.L;
        if (edgeEffect != null && edgeEffect.draw(paramCanvas)) {
          i = 1;
        } else {
          i = 0;
        } 
        i = m | i;
        paramCanvas.restoreToCount(n);
      } 
    } 
    edgeEffect = this.M;
    m = i;
    if (edgeEffect != null) {
      m = i;
      if (!edgeEffect.isFinished()) {
        int n = paramCanvas.save();
        int i1 = getWidth();
        if (this.i) {
          m = getPaddingTop();
        } else {
          m = 0;
        } 
        paramCanvas.rotate(90.0F);
        paramCanvas.translate(-m, -i1);
        edgeEffect = this.M;
        if (edgeEffect != null && edgeEffect.draw(paramCanvas)) {
          m = 1;
        } else {
          m = 0;
        } 
        m = i | m;
        paramCanvas.restoreToCount(n);
      } 
    } 
    edgeEffect = this.N;
    i = m;
    if (edgeEffect != null) {
      i = m;
      if (!edgeEffect.isFinished()) {
        int n = paramCanvas.save();
        paramCanvas.rotate(180.0F);
        if (this.i) {
          paramCanvas.translate((-getWidth() + getPaddingRight()), (-getHeight() + getPaddingBottom()));
        } else {
          paramCanvas.translate(-getWidth(), -getHeight());
        } 
        edgeEffect = this.N;
        if (edgeEffect != null && edgeEffect.draw(paramCanvas)) {
          i = bool;
        } else {
          i = 0;
        } 
        i = m | i;
        paramCanvas.restoreToCount(n);
      } 
    } 
    m = i;
    if (i == 0) {
      m = i;
      if (this.O != null) {
        m = i;
        if (this.q.size() > 0) {
          m = i;
          if (this.O.g())
            m = 1; 
        } 
      } 
    } 
    if (m != 0)
      android.support.v4.view.u.B((View)this); 
  }
  
  public boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  public d0 e(View paramView) {
    ViewParent viewParent = paramView.getParent();
    if (viewParent == null || viewParent == this)
      return k(paramView); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a direct child of ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  void e() {
    if (this.N != null)
      return; 
    this.N = this.J.a(this, 3);
    if (this.i) {
      this.N.setSize(getMeasuredWidth() - getPaddingLeft() - getPaddingRight(), getMeasuredHeight() - getPaddingTop() - getPaddingBottom());
    } else {
      this.N.setSize(getMeasuredWidth(), getMeasuredHeight());
    } 
  }
  
  public void e(int paramInt) {
    int i = this.g.a();
    for (byte b1 = 0; b1 < i; b1++)
      this.g.c(b1).offsetLeftAndRight(paramInt); 
  }
  
  public boolean e(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield o : Landroid/support/v7/widget/RecyclerView$o;
    //   4: astore #8
    //   6: aload #8
    //   8: ifnonnull -> 23
    //   11: ldc_w 'RecyclerView'
    //   14: ldc_w 'Cannot fling without a LayoutManager set. Call setLayoutManager with a non-null argument.'
    //   17: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   20: pop
    //   21: iconst_0
    //   22: ireturn
    //   23: aload_0
    //   24: getfield z : Z
    //   27: ifeq -> 32
    //   30: iconst_0
    //   31: ireturn
    //   32: aload #8
    //   34: invokevirtual a : ()Z
    //   37: istore #7
    //   39: aload_0
    //   40: getfield o : Landroid/support/v7/widget/RecyclerView$o;
    //   43: invokevirtual b : ()Z
    //   46: istore #6
    //   48: iload #7
    //   50: ifeq -> 66
    //   53: iload_1
    //   54: istore_3
    //   55: iload_1
    //   56: invokestatic abs : (I)I
    //   59: aload_0
    //   60: getfield b0 : I
    //   63: if_icmpge -> 68
    //   66: iconst_0
    //   67: istore_3
    //   68: iload #6
    //   70: ifeq -> 87
    //   73: iload_2
    //   74: istore #4
    //   76: iload_2
    //   77: invokestatic abs : (I)I
    //   80: aload_0
    //   81: getfield b0 : I
    //   84: if_icmpge -> 90
    //   87: iconst_0
    //   88: istore #4
    //   90: iload_3
    //   91: ifne -> 101
    //   94: iload #4
    //   96: ifne -> 101
    //   99: iconst_0
    //   100: ireturn
    //   101: aload_0
    //   102: iload_3
    //   103: i2f
    //   104: iload #4
    //   106: i2f
    //   107: invokevirtual dispatchNestedPreFling : (FF)Z
    //   110: ifne -> 249
    //   113: iload #7
    //   115: ifne -> 132
    //   118: iload #6
    //   120: ifeq -> 126
    //   123: goto -> 132
    //   126: iconst_0
    //   127: istore #5
    //   129: goto -> 135
    //   132: iconst_1
    //   133: istore #5
    //   135: aload_0
    //   136: iload_3
    //   137: i2f
    //   138: iload #4
    //   140: i2f
    //   141: iload #5
    //   143: invokevirtual dispatchNestedFling : (FFZ)Z
    //   146: pop
    //   147: aload_0
    //   148: getfield a0 : Landroid/support/v7/widget/RecyclerView$r;
    //   151: astore #8
    //   153: aload #8
    //   155: ifnull -> 171
    //   158: aload #8
    //   160: iload_3
    //   161: iload #4
    //   163: invokevirtual a : (II)Z
    //   166: ifeq -> 171
    //   169: iconst_1
    //   170: ireturn
    //   171: iload #5
    //   173: ifeq -> 249
    //   176: iconst_0
    //   177: istore_1
    //   178: iload #7
    //   180: ifeq -> 187
    //   183: iconst_0
    //   184: iconst_1
    //   185: ior
    //   186: istore_1
    //   187: iload_1
    //   188: istore_2
    //   189: iload #6
    //   191: ifeq -> 198
    //   194: iload_1
    //   195: iconst_2
    //   196: ior
    //   197: istore_2
    //   198: aload_0
    //   199: iload_2
    //   200: iconst_1
    //   201: invokevirtual j : (II)Z
    //   204: pop
    //   205: aload_0
    //   206: getfield c0 : I
    //   209: istore_1
    //   210: iload_1
    //   211: ineg
    //   212: iload_3
    //   213: iload_1
    //   214: invokestatic min : (II)I
    //   217: invokestatic max : (II)I
    //   220: istore_1
    //   221: aload_0
    //   222: getfield c0 : I
    //   225: istore_2
    //   226: iload_2
    //   227: ineg
    //   228: iload #4
    //   230: iload_2
    //   231: invokestatic min : (II)I
    //   234: invokestatic max : (II)I
    //   237: istore_2
    //   238: aload_0
    //   239: getfield g0 : Landroid/support/v7/widget/RecyclerView$c0;
    //   242: iload_1
    //   243: iload_2
    //   244: invokevirtual a : (II)V
    //   247: iconst_1
    //   248: ireturn
    //   249: iconst_0
    //   250: ireturn
  }
  
  Rect f(View paramView) {
    p p = (p)paramView.getLayoutParams();
    if (!p.c)
      return p.b; 
    if (this.j0.d() && (p.b() || p.d()))
      return p.b; 
    Rect rect = p.b;
    rect.set(0, 0, 0, 0);
    int i = this.q.size();
    for (byte b1 = 0; b1 < i; b1++) {
      this.k.set(0, 0, 0, 0);
      ((n)this.q.get(b1)).a(this.k, paramView, this, this.j0);
      int m = rect.left;
      Rect rect1 = this.k;
      rect.left = m + rect1.left;
      rect.top += rect1.top;
      rect.right += rect1.right;
      rect.bottom += rect1.bottom;
    } 
    p.c = false;
    return rect;
  }
  
  void f() {
    if (this.K != null)
      return; 
    this.K = this.J.a(this, 0);
    if (this.i) {
      this.K.setSize(getMeasuredHeight() - getPaddingTop() - getPaddingBottom(), getMeasuredWidth() - getPaddingLeft() - getPaddingRight());
    } else {
      this.K.setSize(getMeasuredHeight(), getMeasuredWidth());
    } 
  }
  
  public void f(int paramInt) {
    int i = this.g.a();
    for (byte b1 = 0; b1 < i; b1++)
      this.g.c(b1).offsetTopAndBottom(paramInt); 
  }
  
  void f(int paramInt1, int paramInt2) {
    int i = this.g.b();
    for (byte b1 = 0; b1 < i; b1++) {
      d0 d01 = k(this.g.d(b1));
      if (d01 != null && !d01.x() && d01.e >= paramInt1) {
        d01.a(paramInt2, false);
        this.j0.g = true;
      } 
    } 
    this.d.a(paramInt1, paramInt2);
    requestLayout();
  }
  
  public View focusSearch(View paramView, int paramInt) {
    int i;
    int m;
    View view1;
    View view2 = this.o.d(paramView, paramInt);
    if (view2 != null)
      return view2; 
    g g1 = this.n;
    boolean bool = true;
    if (g1 != null && this.o != null && !n() && !this.z) {
      i = 1;
    } else {
      i = 0;
    } 
    FocusFinder focusFinder = FocusFinder.getInstance();
    if (i && (paramInt == 2 || paramInt == 1)) {
      int n = 0;
      i = paramInt;
      if (this.o.b()) {
        byte b1;
        if (paramInt == 2) {
          b1 = 130;
        } else {
          b1 = 33;
        } 
        if (focusFinder.findNextFocus(this, paramView, b1) == null) {
          i = 1;
        } else {
          i = 0;
        } 
        int i2 = i;
        n = i2;
        i = paramInt;
        if (H0) {
          i = b1;
          n = i2;
        } 
      } 
      int i1 = n;
      m = i;
      if (n == 0) {
        i1 = n;
        m = i;
        if (this.o.a()) {
          if (this.o.j() == 1) {
            paramInt = 1;
          } else {
            paramInt = 0;
          } 
          if (i == 2) {
            m = 1;
          } else {
            m = 0;
          } 
          if ((m ^ paramInt) != 0) {
            paramInt = 66;
          } else {
            paramInt = 17;
          } 
          if (focusFinder.findNextFocus(this, paramView, paramInt) == null) {
            m = bool;
          } else {
            m = 0;
          } 
          n = m;
          i1 = n;
          m = i;
          if (H0) {
            m = paramInt;
            i1 = n;
          } 
        } 
      } 
      if (i1 != 0) {
        b();
        if (c(paramView) == null)
          return null; 
        w();
        this.o.a(paramView, m, this.d, this.j0);
        c(false);
      } 
      view1 = focusFinder.findNextFocus(this, paramView, m);
    } else {
      View view = view1.findNextFocus(this, paramView, paramInt);
      view1 = view;
      m = paramInt;
      if (view == null) {
        view1 = view;
        m = paramInt;
        if (i != 0) {
          b();
          if (c(paramView) == null)
            return null; 
          w();
          view1 = this.o.a(paramView, paramInt, this.d, this.j0);
          c(false);
          m = paramInt;
        } 
      } 
    } 
    if (view1 != null && !view1.hasFocusable()) {
      if (getFocusedChild() == null)
        return super.focusSearch(paramView, m); 
      a(view1, (View)null);
      return paramView;
    } 
    if (a(paramView, view1, m)) {
      paramView = view1;
    } else {
      paramView = super.focusSearch(paramView, m);
    } 
    return paramView;
  }
  
  void g() {
    if (this.M != null)
      return; 
    this.M = this.J.a(this, 2);
    if (this.i) {
      this.M.setSize(getMeasuredHeight() - getPaddingTop() - getPaddingBottom(), getMeasuredWidth() - getPaddingLeft() - getPaddingRight());
    } else {
      this.M.setSize(getMeasuredHeight(), getMeasuredWidth());
    } 
  }
  
  public void g(int paramInt) {}
  
  void g(int paramInt1, int paramInt2) {
    int i;
    int m;
    boolean bool;
    int n = this.g.b();
    if (paramInt1 < paramInt2) {
      i = paramInt1;
      m = paramInt2;
      bool = true;
    } else {
      i = paramInt2;
      m = paramInt1;
      bool = true;
    } 
    for (byte b1 = 0; b1 < n; b1++) {
      d0 d01 = k(this.g.d(b1));
      if (d01 != null) {
        int i1 = d01.e;
        if (i1 >= i && i1 <= m) {
          if (i1 == paramInt1) {
            d01.a(paramInt2 - paramInt1, false);
          } else {
            d01.a(bool, false);
          } 
          this.j0.g = true;
        } 
      } 
    } 
    this.d.b(paramInt1, paramInt2);
    requestLayout();
  }
  
  public void g(View paramView) {}
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
    o o1 = this.o;
    if (o1 != null)
      return (ViewGroup.LayoutParams)o1.c(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("RecyclerView has no LayoutManager");
    stringBuilder.append(i());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    o o1 = this.o;
    if (o1 != null)
      return (ViewGroup.LayoutParams)o1.a(getContext(), paramAttributeSet); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("RecyclerView has no LayoutManager");
    stringBuilder.append(i());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    o o1 = this.o;
    if (o1 != null)
      return (ViewGroup.LayoutParams)o1.a(paramLayoutParams); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("RecyclerView has no LayoutManager");
    stringBuilder.append(i());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public g getAdapter() {
    return this.n;
  }
  
  public int getBaseline() {
    o o1 = this.o;
    return (o1 != null) ? o1.d() : super.getBaseline();
  }
  
  protected int getChildDrawingOrder(int paramInt1, int paramInt2) {
    j j1 = this.r0;
    return (j1 == null) ? super.getChildDrawingOrder(paramInt1, paramInt2) : j1.a(paramInt1, paramInt2);
  }
  
  public boolean getClipToPadding() {
    return this.i;
  }
  
  public v0 getCompatAccessibilityDelegate() {
    return this.q0;
  }
  
  public k getEdgeEffectFactory() {
    return this.J;
  }
  
  public l getItemAnimator() {
    return this.O;
  }
  
  public int getItemDecorationCount() {
    return this.q.size();
  }
  
  public o getLayoutManager() {
    return this.o;
  }
  
  public int getMaxFlingVelocity() {
    return this.c0;
  }
  
  public int getMinFlingVelocity() {
    return this.b0;
  }
  
  long getNanoTime() {
    return G0 ? System.nanoTime() : 0L;
  }
  
  public r getOnFlingListener() {
    return this.a0;
  }
  
  public boolean getPreserveFocusAfterLayout() {
    return this.f0;
  }
  
  public u getRecycledViewPool() {
    return this.d.d();
  }
  
  public int getScrollState() {
    return this.P;
  }
  
  void h() {
    if (this.L != null)
      return; 
    this.L = this.J.a(this, 1);
    if (this.i) {
      this.L.setSize(getMeasuredWidth() - getPaddingLeft() - getPaddingRight(), getMeasuredHeight() - getPaddingTop() - getPaddingBottom());
    } else {
      this.L.setSize(getMeasuredWidth(), getMeasuredHeight());
    } 
  }
  
  public void h(int paramInt) {
    if (this.z)
      return; 
    x();
    o o1 = this.o;
    if (o1 == null) {
      Log.e("RecyclerView", "Cannot scroll to position a LayoutManager set. Call setLayoutManager with a non-null argument.");
      return;
    } 
    o1.h(paramInt);
    awakenScrollBars();
  }
  
  public void h(int paramInt1, int paramInt2) {}
  
  public void h(View paramView) {}
  
  public boolean hasNestedScrollingParent() {
    return getScrollingChildHelper().a();
  }
  
  String i() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(" ");
    stringBuilder.append(toString());
    stringBuilder.append(", adapter:");
    stringBuilder.append(this.n);
    stringBuilder.append(", layout:");
    stringBuilder.append(this.o);
    stringBuilder.append(", context:");
    stringBuilder.append(getContext());
    return stringBuilder.toString();
  }
  
  public void i(int paramInt1, int paramInt2) {
    a(paramInt1, paramInt2, (Interpolator)null);
  }
  
  boolean i(View paramView) {
    w();
    boolean bool = this.g.e(paramView);
    if (bool) {
      d0 d01 = k(paramView);
      this.d.c(d01);
      this.d.b(d01);
    } 
    c(bool ^ true);
    return bool;
  }
  
  public boolean isAttachedToWindow() {
    return this.t;
  }
  
  public boolean isNestedScrollingEnabled() {
    return getScrollingChildHelper().b();
  }
  
  public boolean j() {
    return (!this.w || this.F || this.f.c());
  }
  
  public boolean j(int paramInt1, int paramInt2) {
    return getScrollingChildHelper().a(paramInt1, paramInt2);
  }
  
  void k() {
    this.f = new d(new f(this));
  }
  
  void l() {
    this.N = null;
    this.L = null;
    this.M = null;
    this.K = null;
  }
  
  boolean m() {
    boolean bool;
    AccessibilityManager accessibilityManager = this.D;
    if (accessibilityManager != null && accessibilityManager.isEnabled()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean n() {
    boolean bool;
    if (this.H > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  void o() {
    int i = this.g.b();
    for (byte b1 = 0; b1 < i; b1++)
      ((p)this.g.d(b1).getLayoutParams()).c = true; 
    this.d.g();
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.H = 0;
    boolean bool = true;
    this.t = true;
    if (!this.w || isLayoutRequested())
      bool = false; 
    this.w = bool;
    o o1 = this.o;
    if (o1 != null)
      o1.a(this); 
    this.p0 = false;
    if (G0) {
      this.h0 = m0.g.get();
      if (this.h0 == null) {
        this.h0 = new m0();
        Display display = android.support.v4.view.u.f((View)this);
        float f2 = 60.0F;
        float f1 = f2;
        if (!isInEditMode()) {
          f1 = f2;
          if (display != null) {
            float f = display.getRefreshRate();
            f1 = f2;
            if (f >= 30.0F)
              f1 = f; 
          } 
        } 
        m0 m01 = this.h0;
        m01.e = (long)(1.0E9F / f1);
        m0.g.set(m01);
      } 
      this.h0.a(this);
    } 
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    l l1 = this.O;
    if (l1 != null)
      l1.b(); 
    x();
    this.t = false;
    o o1 = this.o;
    if (o1 != null)
      o1.a(this, this.d); 
    this.y0.clear();
    removeCallbacks(this.z0);
    this.h.b();
    if (G0) {
      m0 m01 = this.h0;
      if (m01 != null) {
        m01.b(this);
        this.h0 = null;
      } 
    } 
  }
  
  public void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    int i = this.q.size();
    for (byte b1 = 0; b1 < i; b1++)
      ((n)this.q.get(b1)).a(paramCanvas, this, this.j0); 
  }
  
  public boolean onGenericMotionEvent(MotionEvent paramMotionEvent) {
    if (this.o == null)
      return false; 
    if (this.z)
      return false; 
    if (paramMotionEvent.getAction() == 8) {
      float f1;
      float f2;
      if ((paramMotionEvent.getSource() & 0x2) != 0) {
        if (this.o.b()) {
          f1 = -paramMotionEvent.getAxisValue(9);
        } else {
          f1 = 0.0F;
        } 
        if (this.o.a()) {
          f2 = paramMotionEvent.getAxisValue(10);
        } else {
          f2 = 0.0F;
        } 
      } else if ((paramMotionEvent.getSource() & 0x400000) != 0) {
        f2 = paramMotionEvent.getAxisValue(26);
        if (this.o.b()) {
          f1 = -f2;
          f2 = 0.0F;
        } else if (this.o.a()) {
          f1 = 0.0F;
        } else {
          f2 = 0.0F;
          f1 = 0.0F;
        } 
      } else {
        f1 = 0.0F;
        f2 = 0.0F;
      } 
      if (f1 != 0.0F || f2 != 0.0F)
        a((int)(this.d0 * f2), (int)(this.e0 * f1), paramMotionEvent); 
    } 
    return false;
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    StringBuilder stringBuilder;
    boolean bool1 = this.z;
    boolean bool = false;
    if (bool1)
      return false; 
    if (b(paramMotionEvent)) {
      y();
      return true;
    } 
    o o1 = this.o;
    if (o1 == null)
      return false; 
    boolean bool2 = o1.a();
    bool1 = this.o.b();
    if (this.R == null)
      this.R = VelocityTracker.obtain(); 
    this.R.addMovement(paramMotionEvent);
    int m = paramMotionEvent.getActionMasked();
    int i = paramMotionEvent.getActionIndex();
    if (m != 0) {
      if (m != 1) {
        if (m != 2) {
          if (m != 3) {
            if (m != 5) {
              if (m == 6)
                c(paramMotionEvent); 
            } else {
              this.Q = paramMotionEvent.getPointerId(i);
              m = (int)(paramMotionEvent.getX(i) + 0.5F);
              this.U = m;
              this.S = m;
              i = (int)(paramMotionEvent.getY(i) + 0.5F);
              this.V = i;
              this.T = i;
            } 
          } else {
            y();
          } 
        } else {
          i = paramMotionEvent.findPointerIndex(this.Q);
          if (i < 0) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Error processing scroll; pointer index for id ");
            stringBuilder.append(this.Q);
            stringBuilder.append(" not found. Did any MotionEvents get skipped?");
            Log.e("RecyclerView", stringBuilder.toString());
            return false;
          } 
          int i1 = (int)(stringBuilder.getX(i) + 0.5F);
          int n = (int)(stringBuilder.getY(i) + 0.5F);
          if (this.P != 1) {
            int i3 = this.S;
            int i2 = this.T;
            m = 0;
            i = m;
            if (bool2) {
              i = m;
              if (Math.abs(i1 - i3) > this.W) {
                this.U = i1;
                i = 1;
              } 
            } 
            m = i;
            if (bool1) {
              m = i;
              if (Math.abs(n - i2) > this.W) {
                this.V = n;
                m = 1;
              } 
            } 
            if (m != 0)
              setScrollState(1); 
          } 
        } 
      } else {
        this.R.clear();
        a(0);
      } 
    } else {
      if (this.A)
        this.A = false; 
      this.Q = stringBuilder.getPointerId(0);
      i = (int)(stringBuilder.getX() + 0.5F);
      this.U = i;
      this.S = i;
      i = (int)(stringBuilder.getY() + 0.5F);
      this.V = i;
      this.T = i;
      if (this.P == 2) {
        getParent().requestDisallowInterceptTouchEvent(true);
        setScrollState(1);
      } 
      int[] arrayOfInt = this.w0;
      arrayOfInt[1] = 0;
      arrayOfInt[0] = 0;
      i = 0;
      if (bool2)
        i = false | true; 
      m = i;
      if (bool1)
        m = i | 0x2; 
      j(m, 0);
    } 
    if (this.P == 1)
      bool = true; 
    return bool;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    a.b.g.d.a.a("RV OnLayout");
    c();
    a.b.g.d.a.a();
    this.w = true;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    o o1 = this.o;
    if (o1 == null) {
      c(paramInt1, paramInt2);
      return;
    } 
    boolean bool1 = o1.u();
    boolean bool = false;
    if (bool1) {
      int m = View.MeasureSpec.getMode(paramInt1);
      int i = View.MeasureSpec.getMode(paramInt2);
      this.o.a(this.d, this.j0, paramInt1, paramInt2);
      boolean bool2 = bool;
      if (m == 1073741824) {
        bool2 = bool;
        if (i == 1073741824)
          bool2 = true; 
      } 
      if (bool2 || this.n == null)
        return; 
      if (this.j0.e == 1)
        A(); 
      this.o.b(paramInt1, paramInt2);
      this.j0.j = true;
      B();
      this.o.d(paramInt1, paramInt2);
      if (this.o.A()) {
        this.o.b(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
        this.j0.j = true;
        B();
        this.o.d(paramInt1, paramInt2);
      } 
    } else {
      if (this.u) {
        this.o.a(this.d, this.j0, paramInt1, paramInt2);
        return;
      } 
      if (this.C) {
        w();
        q();
        I();
        r();
        a0 a01 = this.j0;
        if (a01.l) {
          a01.h = true;
        } else {
          this.f.b();
          this.j0.h = false;
        } 
        this.C = false;
        c(false);
      } else if (this.j0.l) {
        setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
        return;
      } 
      g g1 = this.n;
      if (g1 != null) {
        this.j0.f = g1.a();
      } else {
        this.j0.f = 0;
      } 
      w();
      this.o.a(this.d, this.j0, paramInt1, paramInt2);
      c(false);
      this.j0.h = false;
    } 
  }
  
  protected boolean onRequestFocusInDescendants(int paramInt, Rect paramRect) {
    return n() ? false : super.onRequestFocusInDescendants(paramInt, paramRect);
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof y)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    this.e = (y)paramParcelable;
    super.onRestoreInstanceState(this.e.a());
    o o1 = this.o;
    if (o1 != null) {
      Parcelable parcelable = this.e.e;
      if (parcelable != null)
        o1.a(parcelable); 
    } 
  }
  
  protected Parcelable onSaveInstanceState() {
    y y1 = new y(super.onSaveInstanceState());
    y y2 = this.e;
    if (y2 != null) {
      y1.a(y2);
    } else {
      o o1 = this.o;
      if (o1 != null) {
        y1.e = o1.x();
      } else {
        y1.e = null;
      } 
    } 
    return (Parcelable)y1;
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramInt1 != paramInt3 || paramInt2 != paramInt4)
      l(); 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int[] arrayOfInt1;
    boolean bool3 = this.z;
    boolean bool2 = false;
    if (bool3 || this.A)
      return false; 
    if (a(paramMotionEvent)) {
      y();
      return true;
    } 
    o o1 = this.o;
    if (o1 == null)
      return false; 
    boolean bool4 = o1.a();
    bool3 = this.o.b();
    if (this.R == null)
      this.R = VelocityTracker.obtain(); 
    boolean bool1 = false;
    MotionEvent motionEvent = MotionEvent.obtain(paramMotionEvent);
    int m = paramMotionEvent.getActionMasked();
    int i = paramMotionEvent.getActionIndex();
    if (m == 0) {
      int[] arrayOfInt = this.w0;
      arrayOfInt[1] = 0;
      arrayOfInt[0] = 0;
    } 
    int[] arrayOfInt2 = this.w0;
    motionEvent.offsetLocation(arrayOfInt2[0], arrayOfInt2[1]);
    if (m != 0) {
      if (m != 1) {
        if (m != 2) {
          if (m != 3) {
            if (m != 5) {
              if (m != 6) {
                i = bool1;
              } else {
                c(paramMotionEvent);
                i = bool1;
              } 
            } else {
              this.Q = paramMotionEvent.getPointerId(i);
              m = (int)(paramMotionEvent.getX(i) + 0.5F);
              this.U = m;
              this.S = m;
              i = (int)(paramMotionEvent.getY(i) + 0.5F);
              this.V = i;
              this.T = i;
              i = bool1;
            } 
          } else {
            y();
            i = bool1;
          } 
        } else {
          StringBuilder stringBuilder;
          i = paramMotionEvent.findPointerIndex(this.Q);
          if (i < 0) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Error processing scroll; pointer index for id ");
            stringBuilder.append(this.Q);
            stringBuilder.append(" not found. Did any MotionEvents get skipped?");
            Log.e("RecyclerView", stringBuilder.toString());
            return false;
          } 
          int i2 = (int)(stringBuilder.getX(i) + 0.5F);
          int i3 = (int)(stringBuilder.getY(i) + 0.5F);
          int i1 = this.U - i2;
          int n = this.V - i3;
          m = i1;
          i = n;
          if (a(i1, n, this.v0, this.u0, 0)) {
            arrayOfInt1 = this.v0;
            m = i1 - arrayOfInt1[0];
            i = n - arrayOfInt1[1];
            arrayOfInt1 = this.u0;
            motionEvent.offsetLocation(arrayOfInt1[0], arrayOfInt1[1]);
            arrayOfInt1 = this.w0;
            n = arrayOfInt1[0];
            arrayOfInt2 = this.u0;
            arrayOfInt1[0] = n + arrayOfInt2[0];
            arrayOfInt1[1] = arrayOfInt1[1] + arrayOfInt2[1];
          } 
          if (this.P != 1) {
            int i4 = 0;
            i1 = i4;
            n = m;
            if (bool4) {
              int i5 = Math.abs(m);
              int i6 = this.W;
              i1 = i4;
              n = m;
              if (i5 > i6) {
                if (m > 0) {
                  n = m - i6;
                } else {
                  n = m + i6;
                } 
                i1 = 1;
              } 
            } 
            i4 = i1;
            m = i;
            if (bool3) {
              int i5 = Math.abs(i);
              int i6 = this.W;
              i4 = i1;
              m = i;
              if (i5 > i6) {
                if (i > 0) {
                  m = i - i6;
                } else {
                  m = i + i6;
                } 
                i4 = 1;
              } 
            } 
            if (i4 != 0)
              setScrollState(1); 
            i = m;
            m = n;
          } 
          if (this.P == 1) {
            arrayOfInt1 = this.u0;
            this.U = i2 - arrayOfInt1[0];
            this.V = i3 - arrayOfInt1[1];
            if (bool4) {
              n = m;
            } else {
              n = 0;
            } 
            i1 = bool2;
            if (bool3)
              i1 = i; 
            if (a(n, i1, motionEvent))
              getParent().requestDisallowInterceptTouchEvent(true); 
            if (this.h0 != null && (m != 0 || i != 0))
              this.h0.a(this, m, i); 
          } 
          i = bool1;
        } 
      } else {
        float f1;
        float f2;
        this.R.addMovement(motionEvent);
        i = 1;
        this.R.computeCurrentVelocity(1000, this.c0);
        if (bool4) {
          f1 = -this.R.getXVelocity(this.Q);
        } else {
          f1 = 0.0F;
        } 
        if (bool3) {
          f2 = -this.R.getYVelocity(this.Q);
        } else {
          f2 = 0.0F;
        } 
        if ((f1 == 0.0F && f2 == 0.0F) || !e((int)f1, (int)f2))
          setScrollState(0); 
        M();
      } 
    } else {
      this.Q = arrayOfInt1.getPointerId(0);
      i = (int)(arrayOfInt1.getX() + 0.5F);
      this.U = i;
      this.S = i;
      i = (int)(arrayOfInt1.getY() + 0.5F);
      this.V = i;
      this.T = i;
      i = 0;
      if (bool4)
        i = false | true; 
      m = i;
      if (bool3)
        m = i | 0x2; 
      j(m, 0);
      i = bool1;
    } 
    if (i == 0)
      this.R.addMovement(motionEvent); 
    motionEvent.recycle();
    return true;
  }
  
  void p() {
    int i = this.g.b();
    for (byte b1 = 0; b1 < i; b1++) {
      d0 d01 = k(this.g.d(b1));
      if (d01 != null && !d01.x())
        d01.a(6); 
    } 
    o();
    this.d.h();
  }
  
  void q() {
    this.H++;
  }
  
  void r() {
    a(true);
  }
  
  protected void removeDetachedView(View paramView, boolean paramBoolean) {
    StringBuilder stringBuilder;
    d0 d01 = k(paramView);
    if (d01 != null)
      if (d01.r()) {
        d01.d();
      } else if (!d01.x()) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Called removeDetachedView with a view which is not flagged as tmp detached.");
        stringBuilder.append(d01);
        stringBuilder.append(i());
        throw new IllegalArgumentException(stringBuilder.toString());
      }  
    stringBuilder.clearAnimation();
    b((View)stringBuilder);
    super.removeDetachedView((View)stringBuilder, paramBoolean);
  }
  
  public void requestChildFocus(View paramView1, View paramView2) {
    if (!this.o.a(this, this.j0, paramView1, paramView2) && paramView2 != null)
      a(paramView1, paramView2); 
    super.requestChildFocus(paramView1, paramView2);
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    return this.o.a(this, paramView, paramRect, paramBoolean);
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    int i = this.r.size();
    for (byte b1 = 0; b1 < i; b1++)
      ((s)this.r.get(b1)).a(paramBoolean); 
    super.requestDisallowInterceptTouchEvent(paramBoolean);
  }
  
  public void requestLayout() {
    if (this.x == 0 && !this.z) {
      super.requestLayout();
    } else {
      this.y = true;
    } 
  }
  
  void s() {
    if (!this.p0 && this.t) {
      android.support.v4.view.u.a((View)this, this.z0);
      this.p0 = true;
    } 
  }
  
  public void scrollBy(int paramInt1, int paramInt2) {
    o o1 = this.o;
    if (o1 == null) {
      Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
      return;
    } 
    if (this.z)
      return; 
    boolean bool1 = o1.a();
    boolean bool2 = this.o.b();
    if (bool1 || bool2) {
      int i = 0;
      if (!bool1)
        paramInt1 = 0; 
      if (bool2)
        i = paramInt2; 
      a(paramInt1, i, (MotionEvent)null);
    } 
  }
  
  public void scrollTo(int paramInt1, int paramInt2) {
    Log.w("RecyclerView", "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
  }
  
  public void sendAccessibilityEventUnchecked(AccessibilityEvent paramAccessibilityEvent) {
    if (a(paramAccessibilityEvent))
      return; 
    super.sendAccessibilityEventUnchecked(paramAccessibilityEvent);
  }
  
  public void setAccessibilityDelegateCompat(v0 paramv0) {
    this.q0 = paramv0;
    android.support.v4.view.u.a((View)this, this.q0);
  }
  
  public void setAdapter(g paramg) {
    setLayoutFrozen(false);
    a(paramg, false, true);
    b(false);
    requestLayout();
  }
  
  public void setChildDrawingOrderCallback(j paramj) {
    boolean bool;
    if (paramj == this.r0)
      return; 
    this.r0 = paramj;
    if (this.r0 != null) {
      bool = true;
    } else {
      bool = false;
    } 
    setChildrenDrawingOrderEnabled(bool);
  }
  
  public void setClipToPadding(boolean paramBoolean) {
    if (paramBoolean != this.i)
      l(); 
    this.i = paramBoolean;
    super.setClipToPadding(paramBoolean);
    if (this.w)
      requestLayout(); 
  }
  
  public void setEdgeEffectFactory(k paramk) {
    a.b.g.g.m.a(paramk);
    this.J = paramk;
    l();
  }
  
  public void setHasFixedSize(boolean paramBoolean) {
    this.u = paramBoolean;
  }
  
  public void setItemAnimator(l paraml) {
    l l1 = this.O;
    if (l1 != null) {
      l1.b();
      this.O.a((l.b)null);
    } 
    this.O = paraml;
    paraml = this.O;
    if (paraml != null)
      paraml.a(this.o0); 
  }
  
  public void setItemViewCacheSize(int paramInt) {
    this.d.f(paramInt);
  }
  
  public void setLayoutFrozen(boolean paramBoolean) {
    if (paramBoolean != this.z) {
      a("Do not setLayoutFrozen in layout or scroll");
      if (!paramBoolean) {
        this.z = false;
        if (this.y && this.o != null && this.n != null)
          requestLayout(); 
        this.y = false;
      } else {
        long l1 = SystemClock.uptimeMillis();
        onTouchEvent(MotionEvent.obtain(l1, l1, 3, 0.0F, 0.0F, 0));
        this.z = true;
        this.A = true;
        x();
      } 
    } 
  }
  
  public void setLayoutManager(o paramo) {
    if (paramo == this.o)
      return; 
    x();
    if (this.o != null) {
      l l1 = this.O;
      if (l1 != null)
        l1.b(); 
      this.o.b(this.d);
      this.o.c(this.d);
      this.d.a();
      if (this.t)
        this.o.a(this, this.d); 
      this.o.f((RecyclerView)null);
      this.o = null;
    } else {
      this.d.a();
    } 
    this.g.c();
    this.o = paramo;
    if (paramo != null)
      if (paramo.b == null) {
        this.o.f(this);
        if (this.t)
          this.o.a(this); 
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("LayoutManager ");
        stringBuilder.append(paramo);
        stringBuilder.append(" is already attached to a RecyclerView:");
        stringBuilder.append(paramo.b.i());
        throw new IllegalArgumentException(stringBuilder.toString());
      }  
    this.d.j();
    requestLayout();
  }
  
  public void setNestedScrollingEnabled(boolean paramBoolean) {
    getScrollingChildHelper().a(paramBoolean);
  }
  
  public void setOnFlingListener(r paramr) {
    this.a0 = paramr;
  }
  
  @Deprecated
  public void setOnScrollListener(t paramt) {
    this.k0 = paramt;
  }
  
  public void setPreserveFocusAfterLayout(boolean paramBoolean) {
    this.f0 = paramBoolean;
  }
  
  public void setRecycledViewPool(u paramu) {
    this.d.a(paramu);
  }
  
  public void setRecyclerListener(w paramw) {
    this.p = paramw;
  }
  
  void setScrollState(int paramInt) {
    if (paramInt == this.P)
      return; 
    this.P = paramInt;
    if (paramInt != 2)
      O(); 
    b(paramInt);
  }
  
  public void setScrollingTouchSlop(int paramInt) {
    ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
    if (paramInt != 0)
      if (paramInt != 1) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("setScrollingTouchSlop(): bad argument constant ");
        stringBuilder.append(paramInt);
        stringBuilder.append("; using default value");
        Log.w("RecyclerView", stringBuilder.toString());
      } else {
        this.W = viewConfiguration.getScaledPagingTouchSlop();
        return;
      }  
    this.W = viewConfiguration.getScaledTouchSlop();
  }
  
  public void setViewCacheExtension(b0 paramb0) {
    this.d.a(paramb0);
  }
  
  public boolean startNestedScroll(int paramInt) {
    return getScrollingChildHelper().b(paramInt);
  }
  
  public void stopNestedScroll() {
    getScrollingChildHelper().c();
  }
  
  void t() {
    l l1 = this.O;
    if (l1 != null)
      l1.b(); 
    o o1 = this.o;
    if (o1 != null) {
      o1.b(this.d);
      this.o.c(this.d);
    } 
    this.d.a();
  }
  
  void u() {
    int i = this.g.a();
    for (byte b1 = 0; b1 < i; b1++) {
      View view = this.g.c(b1);
      d0 d01 = e(view);
      if (d01 != null) {
        d01 = d01.k;
        if (d01 != null) {
          View view1 = d01.c;
          int m = view.getLeft();
          int n = view.getTop();
          if (m != view1.getLeft() || n != view1.getTop())
            view1.layout(m, n, view1.getWidth() + m, view1.getHeight() + n); 
        } 
      } 
    } 
  }
  
  void v() {
    int i = this.g.b();
    for (byte b1 = 0; b1 < i; b1++) {
      d0 d01 = k(this.g.d(b1));
      if (!d01.x())
        d01.v(); 
    } 
  }
  
  void w() {
    this.x++;
    if (this.x == 1 && !this.z)
      this.y = false; 
  }
  
  public void x() {
    setScrollState(0);
    O();
  }
  
  static {
    boolean bool;
  }
  
  static {
    int i = Build.VERSION.SDK_INT;
    if (i == 18 || i == 19 || i == 20) {
      bool = true;
    } else {
      bool = false;
    } 
    D0 = bool;
    if (Build.VERSION.SDK_INT >= 23) {
      bool = true;
    } else {
      bool = false;
    } 
    E0 = bool;
    if (Build.VERSION.SDK_INT >= 16) {
      bool = true;
    } else {
      bool = false;
    } 
    F0 = bool;
    if (Build.VERSION.SDK_INT >= 21) {
      bool = true;
    } else {
      bool = false;
    } 
    G0 = bool;
    if (Build.VERSION.SDK_INT <= 15) {
      bool = true;
    } else {
      bool = false;
    } 
    H0 = bool;
    if (Build.VERSION.SDK_INT <= 15) {
      bool = true;
    } else {
      bool = false;
    } 
    I0 = bool;
    Class<int> clazz = int.class;
    J0 = new Class[] { Context.class, AttributeSet.class, clazz, clazz };
  }
  
  class a implements Runnable {
    final RecyclerView c;
    
    a(RecyclerView this$0) {}
    
    public void run() {
      RecyclerView recyclerView = this.c;
      if (!recyclerView.w || recyclerView.isLayoutRequested())
        return; 
      recyclerView = this.c;
      if (!recyclerView.t) {
        recyclerView.requestLayout();
        return;
      } 
      if (recyclerView.z) {
        recyclerView.y = true;
        return;
      } 
      recyclerView.b();
    }
  }
  
  public static class a0 {
    int a = -1;
    
    private SparseArray<Object> b;
    
    int c = 0;
    
    int d = 0;
    
    int e = 1;
    
    int f = 0;
    
    boolean g = false;
    
    boolean h = false;
    
    boolean i = false;
    
    boolean j = false;
    
    boolean k = false;
    
    boolean l = false;
    
    int m;
    
    long n;
    
    int o;
    
    int p;
    
    int q;
    
    public int a() {
      int i;
      if (this.h) {
        i = this.c - this.d;
      } else {
        i = this.f;
      } 
      return i;
    }
    
    void a(int param1Int) {
      if ((this.e & param1Int) != 0)
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Layout state should be one of ");
      stringBuilder.append(Integer.toBinaryString(param1Int));
      stringBuilder.append(" but it is ");
      stringBuilder.append(Integer.toBinaryString(this.e));
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    void a(RecyclerView.g param1g) {
      this.e = 1;
      this.f = param1g.a();
      this.h = false;
      this.i = false;
      this.j = false;
    }
    
    public int b() {
      return this.a;
    }
    
    public boolean c() {
      boolean bool;
      if (this.a != -1) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public boolean d() {
      return this.h;
    }
    
    public boolean e() {
      return this.l;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("State{mTargetPosition=");
      stringBuilder.append(this.a);
      stringBuilder.append(", mData=");
      stringBuilder.append(this.b);
      stringBuilder.append(", mItemCount=");
      stringBuilder.append(this.f);
      stringBuilder.append(", mIsMeasuring=");
      stringBuilder.append(this.j);
      stringBuilder.append(", mPreviousLayoutItemCount=");
      stringBuilder.append(this.c);
      stringBuilder.append(", mDeletedInvisibleItemCountSincePreviousLayout=");
      stringBuilder.append(this.d);
      stringBuilder.append(", mStructureChanged=");
      stringBuilder.append(this.g);
      stringBuilder.append(", mInPreLayout=");
      stringBuilder.append(this.h);
      stringBuilder.append(", mRunSimpleAnimations=");
      stringBuilder.append(this.k);
      stringBuilder.append(", mRunPredictiveAnimations=");
      stringBuilder.append(this.l);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
  
  class b implements Runnable {
    final RecyclerView c;
    
    b(RecyclerView this$0) {}
    
    public void run() {
      RecyclerView.l l = this.c.O;
      if (l != null)
        l.i(); 
      this.c.p0 = false;
    }
  }
  
  public static abstract class b0 {
    public abstract View a(RecyclerView.v param1v, int param1Int1, int param1Int2);
  }
  
  static final class c implements Interpolator {
    public float getInterpolation(float param1Float) {
      param1Float--;
      return param1Float * param1Float * param1Float * param1Float * param1Float + 1.0F;
    }
  }
  
  class c0 implements Runnable {
    private int c;
    
    private int d;
    
    OverScroller e;
    
    Interpolator f = RecyclerView.K0;
    
    private boolean g = false;
    
    private boolean h = false;
    
    final RecyclerView i;
    
    c0(RecyclerView this$0) {
      this.e = new OverScroller(this$0.getContext(), RecyclerView.K0);
    }
    
    private float a(float param1Float) {
      return (float)Math.sin(((param1Float - 0.5F) * 0.47123894F));
    }
    
    private int a(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      boolean bool;
      int i = Math.abs(param1Int1);
      int j = Math.abs(param1Int2);
      if (i > j) {
        bool = true;
      } else {
        bool = false;
      } 
      param1Int3 = (int)Math.sqrt((param1Int3 * param1Int3 + param1Int4 * param1Int4));
      param1Int2 = (int)Math.sqrt((param1Int1 * param1Int1 + param1Int2 * param1Int2));
      RecyclerView recyclerView = this.i;
      if (bool) {
        param1Int1 = recyclerView.getWidth();
      } else {
        param1Int1 = recyclerView.getHeight();
      } 
      param1Int4 = param1Int1 / 2;
      float f3 = Math.min(1.0F, param1Int2 * 1.0F / param1Int1);
      float f2 = param1Int4;
      float f1 = param1Int4;
      f3 = a(f3);
      if (param1Int3 > 0) {
        param1Int1 = Math.round(Math.abs((f2 + f1 * f3) / param1Int3) * 1000.0F) * 4;
      } else {
        if (bool) {
          param1Int2 = i;
        } else {
          param1Int2 = j;
        } 
        param1Int1 = (int)((param1Int2 / param1Int1 + 1.0F) * 300.0F);
      } 
      return Math.min(param1Int1, 2000);
    }
    
    private void c() {
      this.h = false;
      this.g = true;
    }
    
    private void d() {
      this.g = false;
      if (this.h)
        a(); 
    }
    
    void a() {
      if (this.g) {
        this.h = true;
      } else {
        this.i.removeCallbacks(this);
        android.support.v4.view.u.a((View)this.i, this);
      } 
    }
    
    public void a(int param1Int1, int param1Int2) {
      this.i.setScrollState(2);
      this.d = 0;
      this.c = 0;
      this.e.fling(0, 0, param1Int1, param1Int2, -2147483648, 2147483647, -2147483648, 2147483647);
      a();
    }
    
    public void a(int param1Int1, int param1Int2, int param1Int3, Interpolator param1Interpolator) {
      if (this.f != param1Interpolator) {
        this.f = param1Interpolator;
        this.e = new OverScroller(this.i.getContext(), param1Interpolator);
      } 
      this.i.setScrollState(2);
      this.d = 0;
      this.c = 0;
      this.e.startScroll(0, 0, param1Int1, param1Int2, param1Int3);
      if (Build.VERSION.SDK_INT < 23)
        this.e.computeScrollOffset(); 
      a();
    }
    
    public void a(int param1Int1, int param1Int2, Interpolator param1Interpolator) {
      int i = a(param1Int1, param1Int2, 0, 0);
      if (param1Interpolator == null)
        param1Interpolator = RecyclerView.K0; 
      a(param1Int1, param1Int2, i, param1Interpolator);
    }
    
    public void b() {
      this.i.removeCallbacks(this);
      this.e.abortAnimation();
    }
    
    public void run() {
      if (this.i.o == null) {
        b();
        return;
      } 
      c();
      this.i.b();
      OverScroller overScroller = this.e;
      RecyclerView.z z = this.i.o.g;
      if (overScroller.computeScrollOffset()) {
        int i1;
        int i2;
        int[] arrayOfInt = this.i.v0;
        int i3 = overScroller.getCurrX();
        int i4 = overScroller.getCurrY();
        int n = i3 - this.c;
        int i = i4 - this.d;
        int m = 0;
        this.c = i3;
        this.d = i4;
        int k = n;
        int j = i;
        if (this.i.a(n, i, arrayOfInt, (int[])null, 1)) {
          k = n - arrayOfInt[0];
          j = i - arrayOfInt[1];
        } 
        RecyclerView recyclerView = this.i;
        if (recyclerView.n != null) {
          recyclerView.a(k, j, recyclerView.x0);
          int[] arrayOfInt1 = this.i.x0;
          m = arrayOfInt1[0];
          i1 = arrayOfInt1[1];
          n = k - m;
          i2 = j - i1;
          if (z != null && !z.b() && z.c()) {
            i = this.i.j0.a();
            if (i == 0) {
              z.d();
            } else if (z.a() >= i) {
              z.a(i - 1);
              z.a(k - n, j - i2);
            } else {
              z.a(k - n, j - i2);
            } 
          } 
        } else {
          i1 = 0;
          n = 0;
          i2 = 0;
        } 
        if (!this.i.q.isEmpty())
          this.i.invalidate(); 
        if (this.i.getOverScrollMode() != 2)
          this.i.b(k, j); 
        if (!this.i.a(m, i1, n, i2, (int[])null, 1) && (n != 0 || i2)) {
          boolean bool;
          int i5 = (int)overScroller.getCurrVelocity();
          if (n != i3) {
            if (n < 0) {
              i = -i5;
            } else if (n > 0) {
              i = i5;
            } else {
              i = 0;
            } 
            bool = i;
          } else {
            bool = false;
          } 
          if (i2 != i4) {
            if (i2 < 0) {
              i = -i5;
            } else if (i2 > 0) {
              i = i5;
            } else {
              i = 0;
            } 
          } else {
            i = 0;
          } 
          if (this.i.getOverScrollMode() != 2)
            this.i.a(bool, i); 
          if ((bool || n == i3 || overScroller.getFinalX() == 0) && (i != 0 || i2 == i4 || overScroller.getFinalY() == 0))
            overScroller.abortAnimation(); 
        } 
        if (m != 0 || i1)
          this.i.d(m, i1); 
        if (!RecyclerView.a(this.i))
          this.i.invalidate(); 
        if (j != 0 && this.i.o.b() && i1 == j) {
          i = 1;
        } else {
          i = 0;
        } 
        if (k != 0 && this.i.o.a() && m == k) {
          m = 1;
        } else {
          m = 0;
        } 
        if ((k == 0 && j == 0) || m != 0 || i != 0) {
          i = 1;
        } else {
          i = 0;
        } 
        if (overScroller.isFinished() || (i == 0 && !this.i.d(1))) {
          this.i.setScrollState(0);
          if (RecyclerView.G0)
            this.i.i0.a(); 
          this.i.a(1);
        } else {
          a();
          RecyclerView recyclerView1 = this.i;
          m0 m0 = recyclerView1.h0;
          if (m0 != null)
            m0.a(recyclerView1, k, j); 
        } 
      } 
      if (z != null) {
        if (z.b())
          z.a(0, 0); 
        if (!this.h)
          z.d(); 
      } 
      d();
    }
  }
  
  class d implements q1.b {
    final RecyclerView a;
    
    d(RecyclerView this$0) {}
    
    public void a(RecyclerView.d0 param1d0) {
      RecyclerView recyclerView = this.a;
      recyclerView.o.a(param1d0.c, recyclerView.d);
    }
    
    public void a(RecyclerView.d0 param1d0, RecyclerView.l.c param1c1, RecyclerView.l.c param1c2) {
      this.a.a(param1d0, param1c1, param1c2);
    }
    
    public void b(RecyclerView.d0 param1d0, RecyclerView.l.c param1c1, RecyclerView.l.c param1c2) {
      param1d0.a(false);
      RecyclerView recyclerView = this.a;
      if (recyclerView.F) {
        if (recyclerView.O.a(param1d0, param1d0, param1c1, param1c2))
          this.a.s(); 
      } else if (recyclerView.O.c(param1d0, param1c1, param1c2)) {
        this.a.s();
      } 
    }
    
    public void c(RecyclerView.d0 param1d0, RecyclerView.l.c param1c1, RecyclerView.l.c param1c2) {
      this.a.d.c(param1d0);
      this.a.b(param1d0, param1c1, param1c2);
    }
  }
  
  public static abstract class d0 {
    private static final List<Object> u = Collections.emptyList();
    
    public final View c;
    
    WeakReference<RecyclerView> d;
    
    int e = -1;
    
    int f = -1;
    
    long g = -1L;
    
    int h = -1;
    
    int i = -1;
    
    d0 j = null;
    
    d0 k = null;
    
    int l;
    
    List<Object> m = null;
    
    List<Object> n = null;
    
    private int o = 0;
    
    RecyclerView.v p = null;
    
    boolean q = false;
    
    private int r = 0;
    
    int s = -1;
    
    RecyclerView t;
    
    public d0(View param1View) {
      if (param1View != null) {
        this.c = param1View;
        return;
      } 
      throw new IllegalArgumentException("itemView may not be null");
    }
    
    private void A() {
      if (this.m == null) {
        this.m = new ArrayList();
        this.n = Collections.unmodifiableList(this.m);
      } 
    }
    
    void a() {
      this.f = -1;
      this.i = -1;
    }
    
    void a(int param1Int) {
      this.l |= param1Int;
    }
    
    void a(int param1Int1, int param1Int2) {
      this.l = this.l & (param1Int2 ^ 0xFFFFFFFF) | param1Int1 & param1Int2;
    }
    
    void a(int param1Int1, int param1Int2, boolean param1Boolean) {
      a(8);
      a(param1Int2, param1Boolean);
      this.e = param1Int1;
    }
    
    void a(int param1Int, boolean param1Boolean) {
      if (this.f == -1)
        this.f = this.e; 
      if (this.i == -1)
        this.i = this.e; 
      if (param1Boolean)
        this.i += param1Int; 
      this.e += param1Int;
      if (this.c.getLayoutParams() != null)
        ((RecyclerView.p)this.c.getLayoutParams()).c = true; 
    }
    
    void a(RecyclerView.v param1v, boolean param1Boolean) {
      this.p = param1v;
      this.q = param1Boolean;
    }
    
    void a(RecyclerView param1RecyclerView) {
      int i = this.s;
      if (i != -1) {
        this.r = i;
      } else {
        this.r = android.support.v4.view.u.i(this.c);
      } 
      param1RecyclerView.a(this, 4);
    }
    
    void a(Object param1Object) {
      if (param1Object == null) {
        a(1024);
      } else if ((0x400 & this.l) == 0) {
        A();
        this.m.add(param1Object);
      } 
    }
    
    public final void a(boolean param1Boolean) {
      int i = this.o;
      if (param1Boolean) {
        i--;
      } else {
        i++;
      } 
      this.o = i;
      i = this.o;
      if (i < 0) {
        this.o = 0;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("isRecyclable decremented below 0: unmatched pair of setIsRecyable() calls for ");
        stringBuilder.append(this);
        Log.e("View", stringBuilder.toString());
      } else if (!param1Boolean && i == 1) {
        this.l |= 0x10;
      } else if (param1Boolean && this.o == 0) {
        this.l &= 0xFFFFFFEF;
      } 
    }
    
    void b() {
      List<Object> list = this.m;
      if (list != null)
        list.clear(); 
      this.l &= 0xFFFFFBFF;
    }
    
    void b(RecyclerView param1RecyclerView) {
      param1RecyclerView.a(this, this.r);
      this.r = 0;
    }
    
    boolean b(int param1Int) {
      boolean bool;
      if ((this.l & param1Int) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    void c() {
      this.l &= 0xFFFFFFDF;
    }
    
    void d() {
      this.l &= 0xFFFFFEFF;
    }
    
    boolean e() {
      boolean bool;
      if ((this.l & 0x10) == 0 && android.support.v4.view.u.w(this.c)) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public final int f() {
      RecyclerView recyclerView = this.t;
      return (recyclerView == null) ? -1 : recyclerView.b(this);
    }
    
    public final long g() {
      return this.g;
    }
    
    public final int h() {
      return this.h;
    }
    
    public final int i() {
      int j = this.i;
      int i = j;
      if (j == -1)
        i = this.e; 
      return i;
    }
    
    public final int j() {
      return this.f;
    }
    
    List<Object> k() {
      if ((this.l & 0x400) == 0) {
        List<Object> list = this.m;
        return (list == null || list.size() == 0) ? u : this.n;
      } 
      return u;
    }
    
    boolean l() {
      return ((this.l & 0x200) != 0 || n());
    }
    
    boolean m() {
      int i = this.l;
      boolean bool = true;
      if ((i & 0x1) == 0)
        bool = false; 
      return bool;
    }
    
    boolean n() {
      boolean bool;
      if ((this.l & 0x4) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public final boolean o() {
      boolean bool;
      if ((this.l & 0x10) == 0 && !android.support.v4.view.u.w(this.c)) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    boolean p() {
      boolean bool;
      if ((this.l & 0x8) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    boolean q() {
      boolean bool;
      if (this.p != null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    boolean r() {
      boolean bool;
      if ((this.l & 0x100) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    boolean s() {
      boolean bool;
      if ((this.l & 0x2) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    boolean t() {
      boolean bool;
      if ((this.l & 0x2) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public String toString() {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("ViewHolder{");
      stringBuilder1.append(Integer.toHexString(hashCode()));
      stringBuilder1.append(" position=");
      stringBuilder1.append(this.e);
      stringBuilder1.append(" id=");
      stringBuilder1.append(this.g);
      stringBuilder1.append(", oldPos=");
      stringBuilder1.append(this.f);
      stringBuilder1.append(", pLpos:");
      stringBuilder1.append(this.i);
      StringBuilder stringBuilder2 = new StringBuilder(stringBuilder1.toString());
      if (q()) {
        String str;
        stringBuilder2.append(" scrap ");
        if (this.q) {
          str = "[changeScrap]";
        } else {
          str = "[attachedScrap]";
        } 
        stringBuilder2.append(str);
      } 
      if (n())
        stringBuilder2.append(" invalid"); 
      if (!m())
        stringBuilder2.append(" unbound"); 
      if (t())
        stringBuilder2.append(" update"); 
      if (p())
        stringBuilder2.append(" removed"); 
      if (x())
        stringBuilder2.append(" ignored"); 
      if (r())
        stringBuilder2.append(" tmpDetached"); 
      if (!o()) {
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append(" not recyclable(");
        stringBuilder1.append(this.o);
        stringBuilder1.append(")");
        stringBuilder2.append(stringBuilder1.toString());
      } 
      if (l())
        stringBuilder2.append(" undefined adapter position"); 
      if (this.c.getParent() == null)
        stringBuilder2.append(" no parent"); 
      stringBuilder2.append("}");
      return stringBuilder2.toString();
    }
    
    void u() {
      this.l = 0;
      this.e = -1;
      this.f = -1;
      this.g = -1L;
      this.i = -1;
      this.o = 0;
      this.j = null;
      this.k = null;
      b();
      this.r = 0;
      this.s = -1;
      RecyclerView.e(this);
    }
    
    void v() {
      if (this.f == -1)
        this.f = this.e; 
    }
    
    boolean w() {
      boolean bool;
      if ((this.l & 0x10) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    boolean x() {
      boolean bool;
      if ((this.l & 0x80) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    void y() {
      this.p.c(this);
    }
    
    boolean z() {
      boolean bool;
      if ((this.l & 0x20) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
  }
  
  class e implements d0.b {
    final RecyclerView a;
    
    e(RecyclerView this$0) {}
    
    public View a(int param1Int) {
      return this.a.getChildAt(param1Int);
    }
    
    public void a() {
      int i = b();
      for (byte b1 = 0; b1 < i; b1++) {
        View view = a(b1);
        this.a.b(view);
        view.clearAnimation();
      } 
      this.a.removeAllViews();
    }
    
    public void a(View param1View) {
      RecyclerView.d0 d0 = RecyclerView.k(param1View);
      if (d0 != null)
        d0.a(this.a); 
    }
    
    public void a(View param1View, int param1Int) {
      this.a.addView(param1View, param1Int);
      this.a.a(param1View);
    }
    
    public void a(View param1View, int param1Int, ViewGroup.LayoutParams param1LayoutParams) {
      StringBuilder stringBuilder;
      RecyclerView.d0 d0 = RecyclerView.k(param1View);
      if (d0 != null)
        if (d0.r() || d0.x()) {
          d0.d();
        } else {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Called attach on a child which is not detached: ");
          stringBuilder.append(d0);
          stringBuilder.append(this.a.i());
          throw new IllegalArgumentException(stringBuilder.toString());
        }  
      RecyclerView.a(this.a, (View)stringBuilder, param1Int, param1LayoutParams);
    }
    
    public int b() {
      return this.a.getChildCount();
    }
    
    public RecyclerView.d0 b(View param1View) {
      return RecyclerView.k(param1View);
    }
    
    public void b(int param1Int) {
      View view = this.a.getChildAt(param1Int);
      if (view != null) {
        this.a.b(view);
        view.clearAnimation();
      } 
      this.a.removeViewAt(param1Int);
    }
    
    public void c(int param1Int) {
      View view = a(param1Int);
      if (view != null) {
        RecyclerView.d0 d0 = RecyclerView.k(view);
        if (d0 != null)
          if (!d0.r() || d0.x()) {
            d0.a(256);
          } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("called detach on an already detached child ");
            stringBuilder.append(d0);
            stringBuilder.append(this.a.i());
            throw new IllegalArgumentException(stringBuilder.toString());
          }  
      } 
      RecyclerView.a(this.a, param1Int);
    }
    
    public void c(View param1View) {
      RecyclerView.d0 d0 = RecyclerView.k(param1View);
      if (d0 != null)
        d0.b(this.a); 
    }
    
    public int d(View param1View) {
      return this.a.indexOfChild(param1View);
    }
  }
  
  class f implements d.a {
    final RecyclerView a;
    
    f(RecyclerView this$0) {}
    
    public RecyclerView.d0 a(int param1Int) {
      RecyclerView.d0 d0 = this.a.a(param1Int, true);
      return (d0 == null) ? null : (this.a.g.c(d0.c) ? null : d0);
    }
    
    public void a(int param1Int1, int param1Int2) {
      this.a.g(param1Int1, param1Int2);
      this.a.m0 = true;
    }
    
    public void a(int param1Int1, int param1Int2, Object param1Object) {
      this.a.a(param1Int1, param1Int2, param1Object);
      this.a.n0 = true;
    }
    
    public void a(d.b param1b) {
      c(param1b);
    }
    
    public void b(int param1Int1, int param1Int2) {
      this.a.a(param1Int1, param1Int2, true);
      RecyclerView recyclerView = this.a;
      recyclerView.m0 = true;
      RecyclerView.a0 a0 = recyclerView.j0;
      a0.d += param1Int2;
    }
    
    public void b(d.b param1b) {
      c(param1b);
    }
    
    public void c(int param1Int1, int param1Int2) {
      this.a.a(param1Int1, param1Int2, false);
      this.a.m0 = true;
    }
    
    void c(d.b param1b) {
      int i = param1b.a;
      if (i != 1) {
        if (i != 2) {
          if (i != 4) {
            if (i == 8) {
              RecyclerView recyclerView = this.a;
              recyclerView.o.a(recyclerView, param1b.b, param1b.d, 1);
            } 
          } else {
            RecyclerView recyclerView = this.a;
            recyclerView.o.a(recyclerView, param1b.b, param1b.d, param1b.c);
          } 
        } else {
          RecyclerView recyclerView = this.a;
          recyclerView.o.b(recyclerView, param1b.b, param1b.d);
        } 
      } else {
        RecyclerView recyclerView = this.a;
        recyclerView.o.a(recyclerView, param1b.b, param1b.d);
      } 
    }
    
    public void d(int param1Int1, int param1Int2) {
      this.a.f(param1Int1, param1Int2);
      this.a.m0 = true;
    }
  }
  
  public static abstract class g<VH extends d0> {
    private final RecyclerView.h a = new RecyclerView.h();
    
    private boolean b = false;
    
    public abstract int a();
    
    public long a(int param1Int) {
      return -1L;
    }
    
    public final VH a(ViewGroup param1ViewGroup, int param1Int) {
      try {
        a.b.g.d.a.a("RV CreateView");
        param1ViewGroup = (ViewGroup)b(param1ViewGroup, param1Int);
        if (((RecyclerView.d0)param1ViewGroup).c.getParent() == null) {
          ((RecyclerView.d0)param1ViewGroup).h = param1Int;
          return (VH)param1ViewGroup;
        } 
        IllegalStateException illegalStateException = new IllegalStateException();
        this("ViewHolder views must not be attached when created. Ensure that you are not passing 'true' to the attachToRoot parameter of LayoutInflater.inflate(..., boolean attachToRoot)");
        throw illegalStateException;
      } finally {
        a.b.g.d.a.a();
      } 
    }
    
    public final void a(VH param1VH, int param1Int) {
      ((RecyclerView.d0)param1VH).e = param1Int;
      if (c())
        ((RecyclerView.d0)param1VH).g = a(param1Int); 
      param1VH.a(1, 519);
      a.b.g.d.a.a("RV OnBindView");
      a(param1VH, param1Int, param1VH.k());
      param1VH.b();
      ViewGroup.LayoutParams layoutParams = ((RecyclerView.d0)param1VH).c.getLayoutParams();
      if (layoutParams instanceof RecyclerView.p)
        ((RecyclerView.p)layoutParams).c = true; 
      a.b.g.d.a.a();
    }
    
    public void a(VH param1VH, int param1Int, List<Object> param1List) {
      b(param1VH, param1Int);
    }
    
    public void a(RecyclerView.i param1i) {
      this.a.registerObserver(param1i);
    }
    
    public void a(RecyclerView param1RecyclerView) {}
    
    public void a(boolean param1Boolean) {
      if (!b()) {
        this.b = param1Boolean;
        return;
      } 
      throw new IllegalStateException("Cannot change whether this adapter has stable IDs while the adapter has registered observers.");
    }
    
    public boolean a(VH param1VH) {
      return false;
    }
    
    public int b(int param1Int) {
      return 0;
    }
    
    public abstract VH b(ViewGroup param1ViewGroup, int param1Int);
    
    public void b(VH param1VH) {}
    
    public abstract void b(VH param1VH, int param1Int);
    
    public void b(RecyclerView.i param1i) {
      this.a.unregisterObserver(param1i);
    }
    
    public void b(RecyclerView param1RecyclerView) {}
    
    public final boolean b() {
      return this.a.a();
    }
    
    public final void c(int param1Int) {
      this.a.a(param1Int, 1);
    }
    
    public void c(VH param1VH) {}
    
    public final boolean c() {
      return this.b;
    }
    
    public final void d() {
      this.a.b();
    }
    
    public void d(VH param1VH) {}
  }
  
  static class h extends Observable<i> {
    public void a(int param1Int1, int param1Int2) {
      a(param1Int1, param1Int2, null);
    }
    
    public void a(int param1Int1, int param1Int2, Object param1Object) {
      for (int i = this.mObservers.size() - 1; i >= 0; i--)
        ((RecyclerView.i)this.mObservers.get(i)).a(param1Int1, param1Int2, param1Object); 
    }
    
    public boolean a() {
      return this.mObservers.isEmpty() ^ true;
    }
    
    public void b() {
      for (int i = this.mObservers.size() - 1; i >= 0; i--)
        ((RecyclerView.i)this.mObservers.get(i)).a(); 
    }
  }
  
  public static abstract class i {
    public void a() {}
    
    public void a(int param1Int1, int param1Int2) {}
    
    public void a(int param1Int1, int param1Int2, Object param1Object) {
      a(param1Int1, param1Int2);
    }
  }
  
  public static interface j {
    int a(int param1Int1, int param1Int2);
  }
  
  public static class k {
    protected EdgeEffect a(RecyclerView param1RecyclerView, int param1Int) {
      return new EdgeEffect(param1RecyclerView.getContext());
    }
  }
  
  public static abstract class l {
    private b a = null;
    
    private ArrayList<a> b = new ArrayList<a>();
    
    private long c = 120L;
    
    private long d = 120L;
    
    private long e = 250L;
    
    private long f = 250L;
    
    static int e(RecyclerView.d0 param1d0) {
      int j = param1d0.l & 0xE;
      if (param1d0.n())
        return 4; 
      int i = j;
      if ((j & 0x4) == 0) {
        int k = param1d0.j();
        int m = param1d0.f();
        i = j;
        if (k != -1) {
          i = j;
          if (m != -1) {
            i = j;
            if (k != m)
              i = j | 0x800; 
          } 
        } 
      } 
      return i;
    }
    
    public c a(RecyclerView.a0 param1a0, RecyclerView.d0 param1d0) {
      c c = h();
      c.a(param1d0);
      return c;
    }
    
    public c a(RecyclerView.a0 param1a0, RecyclerView.d0 param1d0, int param1Int, List<Object> param1List) {
      c c = h();
      c.a(param1d0);
      return c;
    }
    
    public final void a() {
      int i = this.b.size();
      for (byte b1 = 0; b1 < i; b1++)
        ((a)this.b.get(b1)).a(); 
      this.b.clear();
    }
    
    void a(b param1b) {
      this.a = param1b;
    }
    
    public abstract boolean a(RecyclerView.d0 param1d0);
    
    public abstract boolean a(RecyclerView.d0 param1d01, RecyclerView.d0 param1d02, c param1c1, c param1c2);
    
    public abstract boolean a(RecyclerView.d0 param1d0, c param1c1, c param1c2);
    
    public boolean a(RecyclerView.d0 param1d0, List<Object> param1List) {
      return a(param1d0);
    }
    
    public abstract void b();
    
    public final void b(RecyclerView.d0 param1d0) {
      d(param1d0);
      b b1 = this.a;
      if (b1 != null)
        b1.a(param1d0); 
    }
    
    public abstract boolean b(RecyclerView.d0 param1d0, c param1c1, c param1c2);
    
    public long c() {
      return this.c;
    }
    
    public abstract void c(RecyclerView.d0 param1d0);
    
    public abstract boolean c(RecyclerView.d0 param1d0, c param1c1, c param1c2);
    
    public long d() {
      return this.f;
    }
    
    public void d(RecyclerView.d0 param1d0) {}
    
    public long e() {
      return this.e;
    }
    
    public long f() {
      return this.d;
    }
    
    public abstract boolean g();
    
    public c h() {
      return new c();
    }
    
    public abstract void i();
    
    public static interface a {
      void a();
    }
    
    static interface b {
      void a(RecyclerView.d0 param2d0);
    }
    
    public static class c {
      public int a;
      
      public int b;
      
      public c a(RecyclerView.d0 param2d0) {
        a(param2d0, 0);
        return this;
      }
      
      public c a(RecyclerView.d0 param2d0, int param2Int) {
        View view = param2d0.c;
        this.a = view.getLeft();
        this.b = view.getTop();
        view.getRight();
        view.getBottom();
        return this;
      }
    }
  }
  
  public static interface a {
    void a();
  }
  
  static interface b {
    void a(RecyclerView.d0 param1d0);
  }
  
  public static class c {
    public int a;
    
    public int b;
    
    public c a(RecyclerView.d0 param1d0) {
      a(param1d0, 0);
      return this;
    }
    
    public c a(RecyclerView.d0 param1d0, int param1Int) {
      View view = param1d0.c;
      this.a = view.getLeft();
      this.b = view.getTop();
      view.getRight();
      view.getBottom();
      return this;
    }
  }
  
  private class m implements l.b {
    final RecyclerView a;
    
    m(RecyclerView this$0) {}
    
    public void a(RecyclerView.d0 param1d0) {
      param1d0.a(true);
      if (param1d0.j != null && param1d0.k == null)
        param1d0.j = null; 
      param1d0.k = null;
      if (!param1d0.w() && !this.a.i(param1d0.c) && param1d0.r())
        this.a.removeDetachedView(param1d0.c, false); 
    }
  }
  
  public static abstract class n {
    @Deprecated
    public void a(Canvas param1Canvas, RecyclerView param1RecyclerView) {}
    
    public void a(Canvas param1Canvas, RecyclerView param1RecyclerView, RecyclerView.a0 param1a0) {
      a(param1Canvas, param1RecyclerView);
    }
    
    @Deprecated
    public void a(Rect param1Rect, int param1Int, RecyclerView param1RecyclerView) {
      param1Rect.set(0, 0, 0, 0);
    }
    
    public void a(Rect param1Rect, View param1View, RecyclerView param1RecyclerView, RecyclerView.a0 param1a0) {
      a(param1Rect, ((RecyclerView.p)param1View.getLayoutParams()).a(), param1RecyclerView);
    }
    
    @Deprecated
    public void b(Canvas param1Canvas, RecyclerView param1RecyclerView) {}
    
    public void b(Canvas param1Canvas, RecyclerView param1RecyclerView, RecyclerView.a0 param1a0) {
      b(param1Canvas, param1RecyclerView);
    }
  }
  
  public static abstract class o {
    d0 a;
    
    RecyclerView b;
    
    private final p1.b c = new a(this);
    
    private final p1.b d = new b(this);
    
    p1 e = new p1(this.c);
    
    p1 f = new p1(this.d);
    
    RecyclerView.z g;
    
    boolean h = false;
    
    boolean i = false;
    
    boolean j = false;
    
    private boolean k = true;
    
    private boolean l = true;
    
    int m;
    
    boolean n;
    
    private int o;
    
    private int p;
    
    private int q;
    
    private int r;
    
    public static int a(int param1Int1, int param1Int2, int param1Int3) {
      int i = View.MeasureSpec.getMode(param1Int1);
      param1Int1 = View.MeasureSpec.getSize(param1Int1);
      return (i != Integer.MIN_VALUE) ? ((i != 1073741824) ? Math.max(param1Int2, param1Int3) : param1Int1) : Math.min(param1Int1, Math.max(param1Int2, param1Int3));
    }
    
    public static int a(int param1Int1, int param1Int2, int param1Int3, int param1Int4, boolean param1Boolean) {
      int i = Math.max(0, param1Int1 - param1Int3);
      boolean bool2 = false;
      param1Int3 = 0;
      boolean bool1 = false;
      param1Int1 = 0;
      if (param1Boolean) {
        if (param1Int4 >= 0) {
          param1Int3 = param1Int4;
          param1Int1 = 1073741824;
        } else if (param1Int4 == -1) {
          if (param1Int2 != Integer.MIN_VALUE)
            if (param1Int2 != 0) {
              if (param1Int2 != 1073741824)
                return View.MeasureSpec.makeMeasureSpec(param1Int3, param1Int1); 
            } else {
              param1Int3 = 0;
              param1Int1 = 0;
              return View.MeasureSpec.makeMeasureSpec(param1Int3, param1Int1);
            }  
          param1Int3 = i;
          param1Int1 = param1Int2;
        } else {
          param1Int3 = bool2;
          param1Int1 = bool1;
          if (param1Int4 == -2) {
            param1Int3 = 0;
            param1Int1 = 0;
          } 
        } 
      } else if (param1Int4 >= 0) {
        param1Int3 = param1Int4;
        param1Int1 = 1073741824;
      } else if (param1Int4 == -1) {
        param1Int3 = i;
        param1Int1 = param1Int2;
      } else {
        param1Int3 = bool2;
        param1Int1 = bool1;
        if (param1Int4 == -2) {
          param1Int3 = i;
          if (param1Int2 == Integer.MIN_VALUE || param1Int2 == 1073741824) {
            param1Int1 = Integer.MIN_VALUE;
            return View.MeasureSpec.makeMeasureSpec(param1Int3, param1Int1);
          } 
          param1Int1 = 0;
        } 
      } 
      return View.MeasureSpec.makeMeasureSpec(param1Int3, param1Int1);
    }
    
    public static d a(Context param1Context, AttributeSet param1AttributeSet, int param1Int1, int param1Int2) {
      d d = new d();
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, a.b.h.e.b.RecyclerView, param1Int1, param1Int2);
      d.a = typedArray.getInt(a.b.h.e.b.RecyclerView_android_orientation, 1);
      d.b = typedArray.getInt(a.b.h.e.b.RecyclerView_spanCount, 1);
      d.c = typedArray.getBoolean(a.b.h.e.b.RecyclerView_reverseLayout, false);
      d.d = typedArray.getBoolean(a.b.h.e.b.RecyclerView_stackFromEnd, false);
      typedArray.recycle();
      return d;
    }
    
    private void a(int param1Int, View param1View) {
      this.a.a(param1Int);
    }
    
    private void a(RecyclerView.v param1v, int param1Int, View param1View) {
      RecyclerView.d0 d01 = RecyclerView.k(param1View);
      if (d01.x())
        return; 
      if (d01.n() && !d01.p() && !this.b.n.c()) {
        g(param1Int);
        param1v.b(d01);
      } else {
        a(param1Int);
        param1v.c(param1View);
        this.b.h.d(d01);
      } 
    }
    
    private void a(View param1View, int param1Int, boolean param1Boolean) {
      RecyclerView.d0 d01 = RecyclerView.k(param1View);
      if (param1Boolean || d01.p()) {
        this.b.h.a(d01);
      } else {
        this.b.h.g(d01);
      } 
      RecyclerView.p p = (RecyclerView.p)param1View.getLayoutParams();
      if (d01.z() || d01.q()) {
        if (d01.q()) {
          d01.y();
        } else {
          d01.c();
        } 
        this.a.a(param1View, param1Int, param1View.getLayoutParams(), false);
      } else if (param1View.getParent() == this.b) {
        int j = this.a.b(param1View);
        int i = param1Int;
        if (param1Int == -1)
          i = this.a.a(); 
        if (j != -1) {
          if (j != i)
            this.b.o.a(j, i); 
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Added View has RecyclerView as parent but view is not a real child. Unfiltered index:");
          stringBuilder.append(this.b.indexOfChild(param1View));
          stringBuilder.append(this.b.i());
          throw new IllegalStateException(stringBuilder.toString());
        } 
      } else {
        this.a.a(param1View, param1Int, false);
        p.c = true;
        RecyclerView.z z1 = this.g;
        if (z1 != null && z1.c())
          this.g.a(param1View); 
      } 
      if (p.d) {
        d01.c.invalidate();
        p.d = false;
      } 
    }
    
    private static boolean b(int param1Int1, int param1Int2, int param1Int3) {
      int i = View.MeasureSpec.getMode(param1Int2);
      param1Int2 = View.MeasureSpec.getSize(param1Int2);
      boolean bool2 = false;
      boolean bool1 = false;
      if (param1Int3 > 0 && param1Int1 != param1Int3)
        return false; 
      if (i != Integer.MIN_VALUE) {
        if (i != 0) {
          if (i != 1073741824)
            return false; 
          if (param1Int2 == param1Int1)
            bool1 = true; 
          return bool1;
        } 
        return true;
      } 
      bool1 = bool2;
      if (param1Int2 >= param1Int1)
        bool1 = true; 
      return bool1;
    }
    
    private int[] b(RecyclerView param1RecyclerView, View param1View, Rect param1Rect, boolean param1Boolean) {
      int i2 = n();
      int m = p();
      int i5 = q() - o();
      int i6 = h();
      int i1 = m();
      int i4 = param1View.getLeft() + param1Rect.left - param1View.getScrollX();
      int n = param1View.getTop() + param1Rect.top - param1View.getScrollY();
      int i3 = param1Rect.width() + i4;
      int i7 = param1Rect.height();
      int k = Math.min(0, i4 - i2);
      int j = Math.min(0, n - m);
      int i = Math.max(0, i3 - i5);
      i1 = Math.max(0, i7 + n - i6 - i1);
      if (j() == 1) {
        if (i == 0)
          i = Math.max(k, i3 - i5); 
      } else if (k != 0) {
        i = k;
      } else {
        i = Math.min(i4 - i2, i);
      } 
      if (j == 0)
        j = Math.min(n - m, i1); 
      return new int[] { i, j };
    }
    
    private boolean d(RecyclerView param1RecyclerView, int param1Int1, int param1Int2) {
      View view = param1RecyclerView.getFocusedChild();
      if (view == null)
        return false; 
      int k = n();
      int n = p();
      int i1 = q();
      int m = o();
      int j = h();
      int i = m();
      Rect rect = this.b.k;
      b(view, rect);
      return !(rect.left - param1Int1 >= i1 - m || rect.right - param1Int1 <= k || rect.top - param1Int2 >= j - i || rect.bottom - param1Int2 <= n);
    }
    
    boolean A() {
      return false;
    }
    
    void B() {
      RecyclerView.z z1 = this.g;
      if (z1 != null)
        z1.d(); 
    }
    
    public boolean C() {
      return false;
    }
    
    public int a(int param1Int, RecyclerView.v param1v, RecyclerView.a0 param1a0) {
      return 0;
    }
    
    public int a(RecyclerView.a0 param1a0) {
      return 0;
    }
    
    public int a(RecyclerView.v param1v, RecyclerView.a0 param1a0) {
      RecyclerView recyclerView = this.b;
      int i = 1;
      if (recyclerView == null || recyclerView.n == null)
        return 1; 
      if (a())
        i = this.b.n.a(); 
      return i;
    }
    
    public RecyclerView.p a(Context param1Context, AttributeSet param1AttributeSet) {
      return new RecyclerView.p(param1Context, param1AttributeSet);
    }
    
    public RecyclerView.p a(ViewGroup.LayoutParams param1LayoutParams) {
      return (param1LayoutParams instanceof RecyclerView.p) ? new RecyclerView.p((RecyclerView.p)param1LayoutParams) : ((param1LayoutParams instanceof ViewGroup.MarginLayoutParams) ? new RecyclerView.p((ViewGroup.MarginLayoutParams)param1LayoutParams) : new RecyclerView.p(param1LayoutParams));
    }
    
    public View a(View param1View, int param1Int, RecyclerView.v param1v, RecyclerView.a0 param1a0) {
      return null;
    }
    
    public void a(int param1Int) {
      a(param1Int, c(param1Int));
    }
    
    public void a(int param1Int1, int param1Int2) {
      View view = c(param1Int1);
      if (view != null) {
        a(param1Int1);
        c(view, param1Int2);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot move a child from non-existing index:");
      stringBuilder.append(param1Int1);
      stringBuilder.append(this.b.toString());
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public void a(int param1Int1, int param1Int2, RecyclerView.a0 param1a0, c param1c) {}
    
    public void a(int param1Int, c param1c) {}
    
    public void a(int param1Int, RecyclerView.v param1v) {
      View view = c(param1Int);
      g(param1Int);
      param1v.b(view);
    }
    
    public void a(Rect param1Rect, int param1Int1, int param1Int2) {
      int k = param1Rect.width();
      int i = n();
      int n = o();
      int j = param1Rect.height();
      int i1 = p();
      int m = m();
      c(a(param1Int1, k + i + n, l()), a(param1Int2, j + i1 + m, k()));
    }
    
    public void a(Parcelable param1Parcelable) {}
    
    void a(android.support.v4.view.d0.c param1c) {
      RecyclerView recyclerView = this.b;
      a(recyclerView.d, recyclerView.j0, param1c);
    }
    
    public void a(RecyclerView.g param1g1, RecyclerView.g param1g2) {}
    
    public void a(RecyclerView.v param1v) {
      for (int i = e() - 1; i >= 0; i--)
        a(param1v, i, c(i)); 
    }
    
    public void a(RecyclerView.v param1v, RecyclerView.a0 param1a0, int param1Int1, int param1Int2) {
      this.b.c(param1Int1, param1Int2);
    }
    
    public void a(RecyclerView.v param1v, RecyclerView.a0 param1a0, android.support.v4.view.d0.c param1c) {
      if (this.b.canScrollVertically(-1) || this.b.canScrollHorizontally(-1)) {
        param1c.a(8192);
        param1c.k(true);
      } 
      if (this.b.canScrollVertically(1) || this.b.canScrollHorizontally(1)) {
        param1c.a(4096);
        param1c.k(true);
      } 
      param1c.a(android.support.v4.view.d0.c.b.a(b(param1v, param1a0), a(param1v, param1a0), d(param1v, param1a0), c(param1v, param1a0)));
    }
    
    public void a(RecyclerView.v param1v, RecyclerView.a0 param1a0, View param1View, android.support.v4.view.d0.c param1c) {
      boolean bool1;
      boolean bool2;
      if (b()) {
        bool1 = l(param1View);
      } else {
        bool1 = false;
      } 
      if (a()) {
        bool2 = l(param1View);
      } else {
        bool2 = false;
      } 
      param1c.b(android.support.v4.view.d0.c.c.a(bool1, 1, bool2, 1, false, false));
    }
    
    public void a(RecyclerView.v param1v, RecyclerView.a0 param1a0, AccessibilityEvent param1AccessibilityEvent) {
      RecyclerView recyclerView = this.b;
      if (recyclerView == null || param1AccessibilityEvent == null)
        return; 
      boolean bool = true;
      if (!recyclerView.canScrollVertically(1) && !this.b.canScrollVertically(-1) && !this.b.canScrollHorizontally(-1) && !this.b.canScrollHorizontally(1))
        bool = false; 
      param1AccessibilityEvent.setScrollable(bool);
      RecyclerView.g g = this.b.n;
      if (g != null)
        param1AccessibilityEvent.setItemCount(g.a()); 
    }
    
    void a(RecyclerView param1RecyclerView) {
      this.i = true;
      b(param1RecyclerView);
    }
    
    public void a(RecyclerView param1RecyclerView, int param1Int1, int param1Int2) {}
    
    public void a(RecyclerView param1RecyclerView, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void a(RecyclerView param1RecyclerView, int param1Int1, int param1Int2, Object param1Object) {
      c(param1RecyclerView, param1Int1, param1Int2);
    }
    
    void a(RecyclerView param1RecyclerView, RecyclerView.v param1v) {
      this.i = false;
      b(param1RecyclerView, param1v);
    }
    
    public void a(View param1View) {
      a(param1View, -1);
    }
    
    public void a(View param1View, int param1Int) {
      a(param1View, param1Int, true);
    }
    
    public void a(View param1View, int param1Int1, int param1Int2) {
      RecyclerView.p p = (RecyclerView.p)param1View.getLayoutParams();
      Rect rect = this.b.f(param1View);
      int k = rect.left;
      int m = rect.right;
      int i = rect.top;
      int j = rect.bottom;
      param1Int1 = a(q(), r(), n() + o() + p.leftMargin + p.rightMargin + param1Int1 + k + m, p.width, a());
      param1Int2 = a(h(), i(), p() + m() + p.topMargin + p.bottomMargin + param1Int2 + i + j, p.height, b());
      if (a(param1View, param1Int1, param1Int2, p))
        param1View.measure(param1Int1, param1Int2); 
    }
    
    public void a(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      RecyclerView.p p = (RecyclerView.p)param1View.getLayoutParams();
      Rect rect = p.b;
      param1View.layout(rect.left + param1Int1 + p.leftMargin, rect.top + param1Int2 + p.topMargin, param1Int3 - rect.right - p.rightMargin, param1Int4 - rect.bottom - p.bottomMargin);
    }
    
    public void a(View param1View, int param1Int, RecyclerView.p param1p) {
      RecyclerView.d0 d01 = RecyclerView.k(param1View);
      if (d01.p()) {
        this.b.h.a(d01);
      } else {
        this.b.h.g(d01);
      } 
      this.a.a(param1View, param1Int, (ViewGroup.LayoutParams)param1p, d01.p());
    }
    
    public void a(View param1View, Rect param1Rect) {
      RecyclerView recyclerView = this.b;
      if (recyclerView == null) {
        param1Rect.set(0, 0, 0, 0);
        return;
      } 
      param1Rect.set(recyclerView.f(param1View));
    }
    
    void a(View param1View, android.support.v4.view.d0.c param1c) {
      RecyclerView.d0 d01 = RecyclerView.k(param1View);
      if (d01 != null && !d01.p() && !this.a.c(d01.c)) {
        RecyclerView recyclerView = this.b;
        a(recyclerView.d, recyclerView.j0, param1View, param1c);
      } 
    }
    
    public void a(View param1View, RecyclerView.v param1v) {
      o(param1View);
      param1v.b(param1View);
    }
    
    public void a(View param1View, boolean param1Boolean, Rect param1Rect) {
      if (param1Boolean) {
        Rect rect = ((RecyclerView.p)param1View.getLayoutParams()).b;
        param1Rect.set(-rect.left, -rect.top, param1View.getWidth() + rect.right, param1View.getHeight() + rect.bottom);
      } else {
        param1Rect.set(0, 0, param1View.getWidth(), param1View.getHeight());
      } 
      if (this.b != null) {
        Matrix matrix = param1View.getMatrix();
        if (matrix != null && !matrix.isIdentity()) {
          RectF rectF = this.b.m;
          rectF.set(param1Rect);
          matrix.mapRect(rectF);
          param1Rect.set((int)Math.floor(rectF.left), (int)Math.floor(rectF.top), (int)Math.ceil(rectF.right), (int)Math.ceil(rectF.bottom));
        } 
      } 
      param1Rect.offset(param1View.getLeft(), param1View.getTop());
    }
    
    public void a(AccessibilityEvent param1AccessibilityEvent) {
      RecyclerView recyclerView = this.b;
      a(recyclerView.d, recyclerView.j0, param1AccessibilityEvent);
    }
    
    public void a(String param1String) {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null)
        recyclerView.a(param1String); 
    }
    
    public boolean a() {
      return false;
    }
    
    boolean a(int param1Int, Bundle param1Bundle) {
      RecyclerView recyclerView = this.b;
      return a(recyclerView.d, recyclerView.j0, param1Int, param1Bundle);
    }
    
    public boolean a(RecyclerView.p param1p) {
      boolean bool;
      if (param1p != null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public boolean a(RecyclerView.v param1v, RecyclerView.a0 param1a0, int param1Int, Bundle param1Bundle) {
      RecyclerView recyclerView = this.b;
      if (recyclerView == null)
        return false; 
      boolean bool = false;
      int i = 0;
      byte b1 = 0;
      int j = 0;
      if (param1Int != 4096) {
        if (param1Int != 8192) {
          param1Int = i;
        } else {
          i = b1;
          if (recyclerView.canScrollVertically(-1))
            i = -(h() - p() - m()); 
          param1Int = i;
          if (this.b.canScrollHorizontally(-1)) {
            j = -(q() - n() - o());
            param1Int = i;
          } 
        } 
      } else {
        i = bool;
        if (recyclerView.canScrollVertically(1))
          i = h() - p() - m(); 
        param1Int = i;
        if (this.b.canScrollHorizontally(1)) {
          j = q() - n() - o();
          param1Int = i;
        } 
      } 
      if (param1Int == 0 && j == 0)
        return false; 
      this.b.i(j, param1Int);
      return true;
    }
    
    public boolean a(RecyclerView.v param1v, RecyclerView.a0 param1a0, View param1View, int param1Int, Bundle param1Bundle) {
      return false;
    }
    
    public boolean a(RecyclerView param1RecyclerView, RecyclerView.a0 param1a0, View param1View1, View param1View2) {
      return a(param1RecyclerView, param1View1, param1View2);
    }
    
    public boolean a(RecyclerView param1RecyclerView, View param1View, Rect param1Rect, boolean param1Boolean) {
      return a(param1RecyclerView, param1View, param1Rect, param1Boolean, false);
    }
    
    public boolean a(RecyclerView param1RecyclerView, View param1View, Rect param1Rect, boolean param1Boolean1, boolean param1Boolean2) {
      int[] arrayOfInt = b(param1RecyclerView, param1View, param1Rect, param1Boolean1);
      int i = arrayOfInt[0];
      int j = arrayOfInt[1];
      if ((!param1Boolean2 || d(param1RecyclerView, i, j)) && (i != 0 || j != 0)) {
        if (param1Boolean1) {
          param1RecyclerView.scrollBy(i, j);
        } else {
          param1RecyclerView.i(i, j);
        } 
        return true;
      } 
      return false;
    }
    
    @Deprecated
    public boolean a(RecyclerView param1RecyclerView, View param1View1, View param1View2) {
      return (w() || param1RecyclerView.n());
    }
    
    public boolean a(RecyclerView param1RecyclerView, ArrayList<View> param1ArrayList, int param1Int1, int param1Int2) {
      return false;
    }
    
    boolean a(View param1View, int param1Int1, int param1Int2, RecyclerView.p param1p) {
      return (param1View.isLayoutRequested() || !this.k || !b(param1View.getWidth(), param1Int1, param1p.width) || !b(param1View.getHeight(), param1Int2, param1p.height));
    }
    
    boolean a(View param1View, int param1Int, Bundle param1Bundle) {
      RecyclerView recyclerView = this.b;
      return a(recyclerView.d, recyclerView.j0, param1View, param1Int, param1Bundle);
    }
    
    public boolean a(View param1View, boolean param1Boolean1, boolean param1Boolean2) {
      param1Boolean2 = this.e.a(param1View, 24579);
      boolean bool = true;
      if (param1Boolean2 && this.f.a(param1View, 24579)) {
        param1Boolean2 = true;
      } else {
        param1Boolean2 = false;
      } 
      if (param1Boolean1)
        return param1Boolean2; 
      if (!param1Boolean2) {
        param1Boolean1 = bool;
      } else {
        param1Boolean1 = false;
      } 
      return param1Boolean1;
    }
    
    public boolean a(Runnable param1Runnable) {
      RecyclerView recyclerView = this.b;
      return (recyclerView != null) ? recyclerView.removeCallbacks(param1Runnable) : false;
    }
    
    public int b(int param1Int, RecyclerView.v param1v, RecyclerView.a0 param1a0) {
      return 0;
    }
    
    public int b(RecyclerView.a0 param1a0) {
      return 0;
    }
    
    public int b(RecyclerView.v param1v, RecyclerView.a0 param1a0) {
      RecyclerView recyclerView = this.b;
      int i = 1;
      if (recyclerView == null || recyclerView.n == null)
        return 1; 
      if (b())
        i = this.b.n.a(); 
      return i;
    }
    
    public View b(int param1Int) {
      int i = e();
      for (byte b1 = 0; b1 < i; b1++) {
        View view = c(b1);
        RecyclerView.d0 d01 = RecyclerView.k(view);
        if (d01 != null && d01.i() == param1Int && !d01.x() && (this.b.j0.d() || !d01.p()))
          return view; 
      } 
      return null;
    }
    
    void b(int param1Int1, int param1Int2) {
      this.q = View.MeasureSpec.getSize(param1Int1);
      this.o = View.MeasureSpec.getMode(param1Int1);
      if (this.o == 0 && !RecyclerView.E0)
        this.q = 0; 
      this.r = View.MeasureSpec.getSize(param1Int2);
      this.p = View.MeasureSpec.getMode(param1Int2);
      if (this.p == 0 && !RecyclerView.E0)
        this.r = 0; 
    }
    
    public void b(RecyclerView.v param1v) {
      for (int i = e() - 1; i >= 0; i--) {
        if (!RecyclerView.k(c(i)).x())
          a(i, param1v); 
      } 
    }
    
    public void b(RecyclerView param1RecyclerView) {}
    
    public void b(RecyclerView param1RecyclerView, int param1Int1, int param1Int2) {}
    
    public void b(RecyclerView param1RecyclerView, RecyclerView.v param1v) {
      c(param1RecyclerView);
    }
    
    public void b(View param1View) {
      b(param1View, -1);
    }
    
    public void b(View param1View, int param1Int) {
      a(param1View, param1Int, false);
    }
    
    public void b(View param1View, Rect param1Rect) {
      RecyclerView.a(param1View, param1Rect);
    }
    
    public boolean b() {
      return false;
    }
    
    boolean b(View param1View, int param1Int1, int param1Int2, RecyclerView.p param1p) {
      return (!this.k || !b(param1View.getMeasuredWidth(), param1Int1, param1p.width) || !b(param1View.getMeasuredHeight(), param1Int2, param1p.height));
    }
    
    public int c(RecyclerView.a0 param1a0) {
      return 0;
    }
    
    public int c(RecyclerView.v param1v, RecyclerView.a0 param1a0) {
      return 0;
    }
    
    public abstract RecyclerView.p c();
    
    public View c(int param1Int) {
      d0 d01 = this.a;
      if (d01 != null) {
        View view = d01.c(param1Int);
      } else {
        d01 = null;
      } 
      return (View)d01;
    }
    
    public View c(View param1View) {
      RecyclerView recyclerView = this.b;
      if (recyclerView == null)
        return null; 
      param1View = recyclerView.c(param1View);
      return (param1View == null) ? null : (this.a.c(param1View) ? null : param1View);
    }
    
    public void c(int param1Int1, int param1Int2) {
      RecyclerView.a(this.b, param1Int1, param1Int2);
    }
    
    void c(RecyclerView.v param1v) {
      int j = param1v.e();
      for (int i = j - 1; i >= 0; i--) {
        View view = param1v.c(i);
        RecyclerView.d0 d01 = RecyclerView.k(view);
        if (!d01.x()) {
          d01.a(false);
          if (d01.r())
            this.b.removeDetachedView(view, false); 
          RecyclerView.l l = this.b.O;
          if (l != null)
            l.c(d01); 
          d01.a(true);
          param1v.a(view);
        } 
      } 
      param1v.c();
      if (j > 0)
        this.b.invalidate(); 
    }
    
    @Deprecated
    public void c(RecyclerView param1RecyclerView) {}
    
    public void c(RecyclerView param1RecyclerView, int param1Int1, int param1Int2) {}
    
    public void c(View param1View, int param1Int) {
      a(param1View, param1Int, (RecyclerView.p)param1View.getLayoutParams());
    }
    
    public int d() {
      return -1;
    }
    
    public int d(RecyclerView.a0 param1a0) {
      return 0;
    }
    
    public int d(View param1View) {
      return ((RecyclerView.p)param1View.getLayoutParams()).b.bottom;
    }
    
    public View d(View param1View, int param1Int) {
      return null;
    }
    
    public void d(int param1Int) {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null)
        recyclerView.e(param1Int); 
    }
    
    void d(int param1Int1, int param1Int2) {
      int n = e();
      if (n == 0) {
        this.b.c(param1Int1, param1Int2);
        return;
      } 
      int m = Integer.MAX_VALUE;
      int j = Integer.MAX_VALUE;
      int k = Integer.MIN_VALUE;
      int i = Integer.MIN_VALUE;
      byte b1 = 0;
      while (b1 < n) {
        View view = c(b1);
        Rect rect = this.b.k;
        b(view, rect);
        int i1 = m;
        if (rect.left < m)
          i1 = rect.left; 
        int i2 = k;
        if (rect.right > k)
          i2 = rect.right; 
        k = j;
        if (rect.top < j)
          k = rect.top; 
        int i3 = i;
        if (rect.bottom > i)
          i3 = rect.bottom; 
        b1++;
        m = i1;
        j = k;
        k = i2;
        i = i3;
      } 
      this.b.k.set(m, j, k, i);
      a(this.b.k, param1Int1, param1Int2);
    }
    
    public void d(RecyclerView param1RecyclerView) {}
    
    public boolean d(RecyclerView.v param1v, RecyclerView.a0 param1a0) {
      return false;
    }
    
    public int e() {
      boolean bool;
      d0 d01 = this.a;
      if (d01 != null) {
        bool = d01.a();
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public int e(RecyclerView.a0 param1a0) {
      return 0;
    }
    
    public int e(View param1View) {
      return param1View.getBottom() + d(param1View);
    }
    
    public void e(int param1Int) {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null)
        recyclerView.f(param1Int); 
    }
    
    public void e(RecyclerView.v param1v, RecyclerView.a0 param1a0) {
      Log.e("RecyclerView", "You must override onLayoutChildren(Recycler recycler, State state) ");
    }
    
    void e(RecyclerView param1RecyclerView) {
      b(View.MeasureSpec.makeMeasureSpec(param1RecyclerView.getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(param1RecyclerView.getHeight(), 1073741824));
    }
    
    public int f(RecyclerView.a0 param1a0) {
      return 0;
    }
    
    public int f(View param1View) {
      return param1View.getLeft() - k(param1View);
    }
    
    public void f(int param1Int) {}
    
    void f(RecyclerView param1RecyclerView) {
      if (param1RecyclerView == null) {
        this.b = null;
        this.a = null;
        this.q = 0;
        this.r = 0;
      } else {
        this.b = param1RecyclerView;
        this.a = param1RecyclerView.g;
        this.q = param1RecyclerView.getWidth();
        this.r = param1RecyclerView.getHeight();
      } 
      this.o = 1073741824;
      this.p = 1073741824;
    }
    
    public boolean f() {
      boolean bool;
      RecyclerView recyclerView = this.b;
      if (recyclerView != null && recyclerView.i) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public int g(View param1View) {
      Rect rect = ((RecyclerView.p)param1View.getLayoutParams()).b;
      return param1View.getMeasuredHeight() + rect.top + rect.bottom;
    }
    
    public View g() {
      RecyclerView recyclerView = this.b;
      if (recyclerView == null)
        return null; 
      View view = recyclerView.getFocusedChild();
      return (view == null || this.a.c(view)) ? null : view;
    }
    
    public void g(int param1Int) {
      if (c(param1Int) != null)
        this.a.e(param1Int); 
    }
    
    public void g(RecyclerView.a0 param1a0) {}
    
    public int h() {
      return this.r;
    }
    
    public int h(View param1View) {
      Rect rect = ((RecyclerView.p)param1View.getLayoutParams()).b;
      return param1View.getMeasuredWidth() + rect.left + rect.right;
    }
    
    public void h(int param1Int) {}
    
    public int i() {
      return this.p;
    }
    
    public int i(View param1View) {
      return param1View.getRight() + m(param1View);
    }
    
    public int j() {
      return android.support.v4.view.u.k((View)this.b);
    }
    
    public int j(View param1View) {
      return param1View.getTop() - n(param1View);
    }
    
    public int k() {
      return android.support.v4.view.u.l((View)this.b);
    }
    
    public int k(View param1View) {
      return ((RecyclerView.p)param1View.getLayoutParams()).b.left;
    }
    
    public int l() {
      return android.support.v4.view.u.m((View)this.b);
    }
    
    public int l(View param1View) {
      return ((RecyclerView.p)param1View.getLayoutParams()).a();
    }
    
    public int m() {
      boolean bool;
      RecyclerView recyclerView = this.b;
      if (recyclerView != null) {
        bool = recyclerView.getPaddingBottom();
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public int m(View param1View) {
      return ((RecyclerView.p)param1View.getLayoutParams()).b.right;
    }
    
    public int n() {
      boolean bool;
      RecyclerView recyclerView = this.b;
      if (recyclerView != null) {
        bool = recyclerView.getPaddingLeft();
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public int n(View param1View) {
      return ((RecyclerView.p)param1View.getLayoutParams()).b.top;
    }
    
    public int o() {
      boolean bool;
      RecyclerView recyclerView = this.b;
      if (recyclerView != null) {
        bool = recyclerView.getPaddingRight();
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public void o(View param1View) {
      this.a.d(param1View);
    }
    
    public int p() {
      boolean bool;
      RecyclerView recyclerView = this.b;
      if (recyclerView != null) {
        bool = recyclerView.getPaddingTop();
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public int q() {
      return this.q;
    }
    
    public int r() {
      return this.o;
    }
    
    boolean s() {
      int i = e();
      for (byte b1 = 0; b1 < i; b1++) {
        ViewGroup.LayoutParams layoutParams = c(b1).getLayoutParams();
        if (layoutParams.width < 0 && layoutParams.height < 0)
          return true; 
      } 
      return false;
    }
    
    public boolean t() {
      return this.i;
    }
    
    public boolean u() {
      return this.j;
    }
    
    public final boolean v() {
      return this.l;
    }
    
    public boolean w() {
      boolean bool;
      RecyclerView.z z1 = this.g;
      if (z1 != null && z1.c()) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public Parcelable x() {
      return null;
    }
    
    public void y() {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null)
        recyclerView.requestLayout(); 
    }
    
    public void z() {
      this.h = true;
    }
    
    class a implements p1.b {
      final RecyclerView.o a;
      
      a(RecyclerView.o this$0) {}
      
      public int a() {
        return this.a.q() - this.a.o();
      }
      
      public int a(View param2View) {
        RecyclerView.p p = (RecyclerView.p)param2View.getLayoutParams();
        return this.a.i(param2View) + p.rightMargin;
      }
      
      public View a(int param2Int) {
        return this.a.c(param2Int);
      }
      
      public int b() {
        return this.a.n();
      }
      
      public int b(View param2View) {
        RecyclerView.p p = (RecyclerView.p)param2View.getLayoutParams();
        return this.a.f(param2View) - p.leftMargin;
      }
    }
    
    class b implements p1.b {
      final RecyclerView.o a;
      
      b(RecyclerView.o this$0) {}
      
      public int a() {
        return this.a.h() - this.a.m();
      }
      
      public int a(View param2View) {
        RecyclerView.p p = (RecyclerView.p)param2View.getLayoutParams();
        return this.a.e(param2View) + p.bottomMargin;
      }
      
      public View a(int param2Int) {
        return this.a.c(param2Int);
      }
      
      public int b() {
        return this.a.p();
      }
      
      public int b(View param2View) {
        RecyclerView.p p = (RecyclerView.p)param2View.getLayoutParams();
        return this.a.j(param2View) - p.topMargin;
      }
    }
    
    public static interface c {
      void a(int param2Int1, int param2Int2);
    }
    
    public static class d {
      public int a;
      
      public int b;
      
      public boolean c;
      
      public boolean d;
    }
  }
  
  class a implements p1.b {
    final RecyclerView.o a;
    
    a(RecyclerView this$0) {}
    
    public int a() {
      return this.a.q() - this.a.o();
    }
    
    public int a(View param1View) {
      RecyclerView.p p = (RecyclerView.p)param1View.getLayoutParams();
      return this.a.i(param1View) + p.rightMargin;
    }
    
    public View a(int param1Int) {
      return this.a.c(param1Int);
    }
    
    public int b() {
      return this.a.n();
    }
    
    public int b(View param1View) {
      RecyclerView.p p = (RecyclerView.p)param1View.getLayoutParams();
      return this.a.f(param1View) - p.leftMargin;
    }
  }
  
  class b implements p1.b {
    final RecyclerView.o a;
    
    b(RecyclerView this$0) {}
    
    public int a() {
      return this.a.h() - this.a.m();
    }
    
    public int a(View param1View) {
      RecyclerView.p p = (RecyclerView.p)param1View.getLayoutParams();
      return this.a.e(param1View) + p.bottomMargin;
    }
    
    public View a(int param1Int) {
      return this.a.c(param1Int);
    }
    
    public int b() {
      return this.a.p();
    }
    
    public int b(View param1View) {
      RecyclerView.p p = (RecyclerView.p)param1View.getLayoutParams();
      return this.a.j(param1View) - p.topMargin;
    }
  }
  
  public static interface c {
    void a(int param1Int1, int param1Int2);
  }
  
  public static class d {
    public int a;
    
    public int b;
    
    public boolean c;
    
    public boolean d;
  }
  
  public static class p extends ViewGroup.MarginLayoutParams {
    RecyclerView.d0 a;
    
    final Rect b = new Rect();
    
    boolean c = true;
    
    boolean d = false;
    
    public p(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public p(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public p(p param1p) {
      super((ViewGroup.LayoutParams)param1p);
    }
    
    public p(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public p(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public int a() {
      return this.a.i();
    }
    
    public boolean b() {
      return this.a.s();
    }
    
    public boolean c() {
      return this.a.p();
    }
    
    public boolean d() {
      return this.a.n();
    }
  }
  
  public static interface q {
    void a(View param1View);
    
    void b(View param1View);
  }
  
  public static abstract class r {
    public abstract boolean a(int param1Int1, int param1Int2);
  }
  
  public static interface s {
    void a(RecyclerView param1RecyclerView, MotionEvent param1MotionEvent);
    
    void a(boolean param1Boolean);
    
    boolean b(RecyclerView param1RecyclerView, MotionEvent param1MotionEvent);
  }
  
  public static abstract class t {
    public void a(RecyclerView param1RecyclerView, int param1Int) {}
    
    public void a(RecyclerView param1RecyclerView, int param1Int1, int param1Int2) {}
  }
  
  public static class u {
    SparseArray<a> a = new SparseArray();
    
    private int b = 0;
    
    private a b(int param1Int) {
      a a2 = (a)this.a.get(param1Int);
      a a1 = a2;
      if (a2 == null) {
        a1 = new a();
        this.a.put(param1Int, a1);
      } 
      return a1;
    }
    
    long a(long param1Long1, long param1Long2) {
      return (param1Long1 == 0L) ? param1Long2 : (param1Long1 / 4L * 3L + param1Long2 / 4L);
    }
    
    public RecyclerView.d0 a(int param1Int) {
      a a = (a)this.a.get(param1Int);
      if (a != null && !a.a.isEmpty()) {
        ArrayList<RecyclerView.d0> arrayList = a.a;
        return arrayList.remove(arrayList.size() - 1);
      } 
      return null;
    }
    
    void a() {
      this.b++;
    }
    
    void a(int param1Int, long param1Long) {
      a a = b(param1Int);
      a.d = a(a.d, param1Long);
    }
    
    public void a(RecyclerView.d0 param1d0) {
      int i = param1d0.h();
      ArrayList<RecyclerView.d0> arrayList = (b(i)).a;
      if (((a)this.a.get(i)).b <= arrayList.size())
        return; 
      param1d0.u();
      arrayList.add(param1d0);
    }
    
    void a(RecyclerView.g param1g1, RecyclerView.g param1g2, boolean param1Boolean) {
      if (param1g1 != null)
        c(); 
      if (!param1Boolean && this.b == 0)
        b(); 
      if (param1g2 != null)
        a(); 
    }
    
    boolean a(int param1Int, long param1Long1, long param1Long2) {
      long l = (b(param1Int)).d;
      return (l == 0L || param1Long1 + l < param1Long2);
    }
    
    public void b() {
      for (byte b = 0; b < this.a.size(); b++)
        ((a)this.a.valueAt(b)).a.clear(); 
    }
    
    void b(int param1Int, long param1Long) {
      a a = b(param1Int);
      a.c = a(a.c, param1Long);
    }
    
    boolean b(int param1Int, long param1Long1, long param1Long2) {
      long l = (b(param1Int)).c;
      return (l == 0L || param1Long1 + l < param1Long2);
    }
    
    void c() {
      this.b--;
    }
    
    static class a {
      final ArrayList<RecyclerView.d0> a = new ArrayList<RecyclerView.d0>();
      
      int b = 5;
      
      long c = 0L;
      
      long d = 0L;
    }
  }
  
  static class a {
    final ArrayList<RecyclerView.d0> a = new ArrayList<RecyclerView.d0>();
    
    int b = 5;
    
    long c = 0L;
    
    long d = 0L;
  }
  
  public final class v {
    final ArrayList<RecyclerView.d0> a = new ArrayList<RecyclerView.d0>();
    
    ArrayList<RecyclerView.d0> b = null;
    
    final ArrayList<RecyclerView.d0> c = new ArrayList<RecyclerView.d0>();
    
    private final List<RecyclerView.d0> d = Collections.unmodifiableList(this.a);
    
    private int e = 2;
    
    int f = 2;
    
    RecyclerView.u g;
    
    private RecyclerView.b0 h;
    
    final RecyclerView i;
    
    public v(RecyclerView this$0) {}
    
    private void a(ViewGroup param1ViewGroup, boolean param1Boolean) {
      int i;
      for (i = param1ViewGroup.getChildCount() - 1; i >= 0; i--) {
        View view = param1ViewGroup.getChildAt(i);
        if (view instanceof ViewGroup)
          a((ViewGroup)view, true); 
      } 
      if (!param1Boolean)
        return; 
      if (param1ViewGroup.getVisibility() == 4) {
        param1ViewGroup.setVisibility(0);
        param1ViewGroup.setVisibility(4);
      } else {
        i = param1ViewGroup.getVisibility();
        param1ViewGroup.setVisibility(4);
        param1ViewGroup.setVisibility(i);
      } 
    }
    
    private boolean a(RecyclerView.d0 param1d0, int param1Int1, int param1Int2, long param1Long) {
      param1d0.t = this.i;
      int i = param1d0.h();
      long l = this.i.getNanoTime();
      if (param1Long != Long.MAX_VALUE && !this.g.a(i, l, param1Long))
        return false; 
      this.i.n.a(param1d0, param1Int1);
      param1Long = this.i.getNanoTime();
      this.g.a(param1d0.h(), param1Long - l);
      e(param1d0);
      if (this.i.j0.d())
        param1d0.i = param1Int2; 
      return true;
    }
    
    private void e(RecyclerView.d0 param1d0) {
      if (this.i.m()) {
        View view = param1d0.c;
        if (android.support.v4.view.u.i(view) == 0)
          android.support.v4.view.u.f(view, 1); 
        if (!android.support.v4.view.u.t(view)) {
          param1d0.a(16384);
          android.support.v4.view.u.a(view, this.i.q0.b());
        } 
      } 
    }
    
    private void f(RecyclerView.d0 param1d0) {
      View view = param1d0.c;
      if (view instanceof ViewGroup)
        a((ViewGroup)view, false); 
    }
    
    public int a(int param1Int) {
      if (param1Int >= 0 && param1Int < this.i.j0.a())
        return !this.i.j0.d() ? param1Int : this.i.f.b(param1Int); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("invalid position ");
      stringBuilder.append(param1Int);
      stringBuilder.append(". State ");
      stringBuilder.append("item count is ");
      stringBuilder.append(this.i.j0.a());
      stringBuilder.append(this.i.i());
      throw new IndexOutOfBoundsException(stringBuilder.toString());
    }
    
    RecyclerView.d0 a(int param1Int, boolean param1Boolean) {
      int i = this.a.size();
      byte b;
      for (b = 0; b < i; b++) {
        RecyclerView.d0 d0 = this.a.get(b);
        if (!d0.z() && d0.i() == param1Int && !d0.n() && (this.i.j0.h || !d0.p())) {
          d0.a(32);
          return d0;
        } 
      } 
      if (!param1Boolean) {
        View view = this.i.g.b(param1Int);
        if (view != null) {
          RecyclerView.d0 d0 = RecyclerView.k(view);
          this.i.g.f(view);
          param1Int = this.i.g.b(view);
          if (param1Int != -1) {
            this.i.g.a(param1Int);
            c(view);
            d0.a(8224);
            return d0;
          } 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("layout index should not be -1 after unhiding a view:");
          stringBuilder.append(d0);
          stringBuilder.append(this.i.i());
          throw new IllegalStateException(stringBuilder.toString());
        } 
      } 
      i = this.c.size();
      for (b = 0; b < i; b++) {
        RecyclerView.d0 d0 = this.c.get(b);
        if (!d0.n() && d0.i() == param1Int) {
          if (!param1Boolean)
            this.c.remove(b); 
          return d0;
        } 
      } 
      return null;
    }
    
    RecyclerView.d0 a(int param1Int, boolean param1Boolean, long param1Long) {
      if (param1Int >= 0 && param1Int < this.i.j0.a()) {
        StringBuilder stringBuilder1;
        RecyclerView.p p;
        int j = 0;
        RecyclerView.d0 d02 = null;
        boolean bool1 = this.i.j0.d();
        boolean bool = true;
        if (bool1) {
          byte b;
          d02 = b(param1Int);
          if (d02 != null) {
            b = 1;
          } else {
            b = 0;
          } 
          j = b;
        } 
        int i = j;
        RecyclerView.d0 d01 = d02;
        if (d02 == null) {
          d02 = a(param1Int, param1Boolean);
          i = j;
          d01 = d02;
          if (d02 != null)
            if (!d(d02)) {
              if (!param1Boolean) {
                d02.a(4);
                if (d02.q()) {
                  this.i.removeDetachedView(d02.c, false);
                  d02.y();
                } else if (d02.z()) {
                  d02.c();
                } 
                b(d02);
              } 
              d01 = null;
              i = j;
            } else {
              i = 1;
              d01 = d02;
            }  
        } 
        if (d01 == null) {
          int k = this.i.f.b(param1Int);
          if (k >= 0 && k < this.i.n.a()) {
            int m = this.i.n.b(k);
            j = i;
            if (this.i.n.c()) {
              d02 = a(this.i.n.a(k), m, param1Boolean);
              j = i;
              d01 = d02;
              if (d02 != null) {
                d02.e = k;
                j = 1;
                d01 = d02;
              } 
            } 
            d02 = d01;
            if (d01 == null) {
              RecyclerView.b0 b01 = this.h;
              d02 = d01;
              if (b01 != null) {
                View view = b01.a(this, param1Int, m);
                d02 = d01;
                if (view != null) {
                  d02 = this.i.e(view);
                  if (d02 != null) {
                    if (d02.x()) {
                      stringBuilder1 = new StringBuilder();
                      stringBuilder1.append("getViewForPositionAndType returned a view that is ignored. You must call stopIgnoring before returning this view.");
                      stringBuilder1.append(this.i.i());
                      throw new IllegalArgumentException(stringBuilder1.toString());
                    } 
                  } else {
                    stringBuilder1 = new StringBuilder();
                    stringBuilder1.append("getViewForPositionAndType returned a view which does not have a ViewHolder");
                    stringBuilder1.append(this.i.i());
                    throw new IllegalArgumentException(stringBuilder1.toString());
                  } 
                } 
              } 
            } 
            d01 = d02;
            if (d02 == null) {
              d02 = d().a(m);
              d01 = d02;
              if (d02 != null) {
                d02.u();
                d01 = d02;
                if (RecyclerView.D0) {
                  f(d02);
                  d01 = d02;
                } 
              } 
            } 
            if (d01 == null) {
              long l2 = this.i.getNanoTime();
              if (param1Long != Long.MAX_VALUE && !this.g.b(m, l2, param1Long))
                return null; 
              RecyclerView recyclerView = this.i;
              recyclerView = recyclerView.n.a(recyclerView, m);
              if (RecyclerView.G0) {
                RecyclerView recyclerView1 = RecyclerView.j(((RecyclerView.d0)recyclerView).c);
                if (recyclerView1 != null)
                  ((RecyclerView.d0)recyclerView).d = new WeakReference<RecyclerView>(recyclerView1); 
              } 
              long l1 = this.i.getNanoTime();
              this.g.b(m, l1 - l2);
              i = j;
            } else {
              i = j;
            } 
          } else {
            stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Inconsistency detected. Invalid item position ");
            stringBuilder1.append(param1Int);
            stringBuilder1.append("(offset:");
            stringBuilder1.append(k);
            stringBuilder1.append(").");
            stringBuilder1.append("state:");
            stringBuilder1.append(this.i.j0.a());
            stringBuilder1.append(this.i.i());
            throw new IndexOutOfBoundsException(stringBuilder1.toString());
          } 
        } 
        if (i && !this.i.j0.d() && stringBuilder1.b(8192)) {
          stringBuilder1.a(0, 8192);
          if (this.i.j0.k) {
            j = RecyclerView.l.e((RecyclerView.d0)stringBuilder1);
            RecyclerView recyclerView = this.i;
            RecyclerView.l.c c = recyclerView.O.a(recyclerView.j0, (RecyclerView.d0)stringBuilder1, j | 0x1000, stringBuilder1.k());
            this.i.a((RecyclerView.d0)stringBuilder1, c);
          } 
        } 
        param1Boolean = false;
        if (this.i.j0.d() && stringBuilder1.m()) {
          ((RecyclerView.d0)stringBuilder1).i = param1Int;
        } else if (!stringBuilder1.m() || stringBuilder1.t() || stringBuilder1.n()) {
          param1Boolean = a((RecyclerView.d0)stringBuilder1, this.i.f.b(param1Int), param1Int, param1Long);
        } 
        ViewGroup.LayoutParams layoutParams = ((RecyclerView.d0)stringBuilder1).c.getLayoutParams();
        if (layoutParams == null) {
          p = (RecyclerView.p)this.i.generateDefaultLayoutParams();
          ((RecyclerView.d0)stringBuilder1).c.setLayoutParams((ViewGroup.LayoutParams)p);
        } else if (!this.i.checkLayoutParams((ViewGroup.LayoutParams)p)) {
          p = (RecyclerView.p)this.i.generateLayoutParams((ViewGroup.LayoutParams)p);
          ((RecyclerView.d0)stringBuilder1).c.setLayoutParams((ViewGroup.LayoutParams)p);
        } else {
          p = p;
        } 
        p.a = (RecyclerView.d0)stringBuilder1;
        if (i != 0 && param1Boolean) {
          param1Boolean = bool;
        } else {
          param1Boolean = false;
        } 
        p.d = param1Boolean;
        return (RecyclerView.d0)stringBuilder1;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid item position ");
      stringBuilder.append(param1Int);
      stringBuilder.append("(");
      stringBuilder.append(param1Int);
      stringBuilder.append("). Item count:");
      stringBuilder.append(this.i.j0.a());
      stringBuilder.append(this.i.i());
      throw new IndexOutOfBoundsException(stringBuilder.toString());
    }
    
    RecyclerView.d0 a(long param1Long, int param1Int, boolean param1Boolean) {
      int i;
      for (i = this.a.size() - 1; i >= 0; i--) {
        RecyclerView.d0 d0 = this.a.get(i);
        if (d0.g() == param1Long && !d0.z()) {
          if (param1Int == d0.h()) {
            d0.a(32);
            if (d0.p() && !this.i.j0.d())
              d0.a(2, 14); 
            return d0;
          } 
          if (!param1Boolean) {
            this.a.remove(i);
            this.i.removeDetachedView(d0.c, false);
            a(d0.c);
          } 
        } 
      } 
      for (i = this.c.size() - 1; i >= 0; i--) {
        RecyclerView.d0 d0 = this.c.get(i);
        if (d0.g() == param1Long) {
          if (param1Int == d0.h()) {
            if (!param1Boolean)
              this.c.remove(i); 
            return d0;
          } 
          if (!param1Boolean) {
            e(i);
            return null;
          } 
        } 
      } 
      return null;
    }
    
    public void a() {
      this.a.clear();
      i();
    }
    
    void a(int param1Int1, int param1Int2) {
      int i = this.c.size();
      for (byte b = 0; b < i; b++) {
        RecyclerView.d0 d0 = this.c.get(b);
        if (d0 != null && d0.e >= param1Int1)
          d0.a(param1Int2, true); 
      } 
    }
    
    void a(int param1Int1, int param1Int2, boolean param1Boolean) {
      for (int i = this.c.size() - 1; i >= 0; i--) {
        RecyclerView.d0 d0 = this.c.get(i);
        if (d0 != null) {
          int j = d0.e;
          if (j >= param1Int1 + param1Int2) {
            d0.a(-param1Int2, param1Boolean);
          } else if (j >= param1Int1) {
            d0.a(8);
            e(i);
          } 
        } 
      } 
    }
    
    void a(RecyclerView.b0 param1b0) {
      this.h = param1b0;
    }
    
    void a(RecyclerView.d0 param1d0) {
      RecyclerView.w w = this.i.p;
      if (w != null)
        w.a(param1d0); 
      RecyclerView.g<RecyclerView.d0> g = this.i.n;
      if (g != null)
        g.d(param1d0); 
      RecyclerView recyclerView = this.i;
      if (recyclerView.j0 != null)
        recyclerView.h.h(param1d0); 
    }
    
    void a(RecyclerView.d0 param1d0, boolean param1Boolean) {
      RecyclerView.e(param1d0);
      if (param1d0.b(16384)) {
        param1d0.a(0, 16384);
        android.support.v4.view.u.a(param1d0.c, null);
      } 
      if (param1Boolean)
        a(param1d0); 
      param1d0.t = null;
      d().a(param1d0);
    }
    
    void a(RecyclerView.g param1g1, RecyclerView.g param1g2, boolean param1Boolean) {
      a();
      d().a(param1g1, param1g2, param1Boolean);
    }
    
    void a(RecyclerView.u param1u) {
      RecyclerView.u u1 = this.g;
      if (u1 != null)
        u1.c(); 
      this.g = param1u;
      if (this.g != null && this.i.getAdapter() != null)
        this.g.a(); 
    }
    
    void a(View param1View) {
      RecyclerView.d0 d0 = RecyclerView.k(param1View);
      d0.p = null;
      d0.q = false;
      d0.c();
      b(d0);
    }
    
    RecyclerView.d0 b(int param1Int) {
      ArrayList<RecyclerView.d0> arrayList = this.b;
      if (arrayList != null) {
        int i = arrayList.size();
        if (i != 0) {
          for (byte b = 0; b < i; b++) {
            RecyclerView.d0 d0 = this.b.get(b);
            if (!d0.z() && d0.i() == param1Int) {
              d0.a(32);
              return d0;
            } 
          } 
          if (this.i.n.c()) {
            param1Int = this.i.f.b(param1Int);
            if (param1Int > 0 && param1Int < this.i.n.a()) {
              long l = this.i.n.a(param1Int);
              for (param1Int = 0; param1Int < i; param1Int++) {
                RecyclerView.d0 d0 = this.b.get(param1Int);
                if (!d0.z() && d0.g() == l) {
                  d0.a(32);
                  return d0;
                } 
              } 
            } 
          } 
          return null;
        } 
      } 
      return null;
    }
    
    View b(int param1Int, boolean param1Boolean) {
      return (a(param1Int, param1Boolean, Long.MAX_VALUE)).c;
    }
    
    void b() {
      int i = this.c.size();
      byte b;
      for (b = 0; b < i; b++)
        ((RecyclerView.d0)this.c.get(b)).a(); 
      i = this.a.size();
      for (b = 0; b < i; b++)
        ((RecyclerView.d0)this.a.get(b)).a(); 
      ArrayList<RecyclerView.d0> arrayList = this.b;
      if (arrayList != null) {
        i = arrayList.size();
        for (b = 0; b < i; b++)
          ((RecyclerView.d0)this.b.get(b)).a(); 
      } 
    }
    
    void b(int param1Int1, int param1Int2) {
      int i;
      boolean bool;
      int j;
      if (param1Int1 < param1Int2) {
        i = param1Int1;
        j = param1Int2;
        bool = true;
      } else {
        i = param1Int2;
        j = param1Int1;
        bool = true;
      } 
      int k = this.c.size();
      for (byte b = 0; b < k; b++) {
        RecyclerView.d0 d0 = this.c.get(b);
        if (d0 != null) {
          int m = d0.e;
          if (m >= i && m <= j)
            if (m == param1Int1) {
              d0.a(param1Int2 - param1Int1, false);
            } else {
              d0.a(bool, false);
            }  
        } 
      } 
    }
    
    void b(RecyclerView.d0 param1d0) {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual q : ()Z
      //   4: istore #8
      //   6: iconst_0
      //   7: istore #7
      //   9: iload #8
      //   11: ifne -> 404
      //   14: aload_1
      //   15: getfield c : Landroid/view/View;
      //   18: invokevirtual getParent : ()Landroid/view/ViewParent;
      //   21: ifnull -> 27
      //   24: goto -> 404
      //   27: aload_1
      //   28: invokevirtual r : ()Z
      //   31: ifne -> 353
      //   34: aload_1
      //   35: invokevirtual x : ()Z
      //   38: ifne -> 313
      //   41: aload_1
      //   42: invokevirtual e : ()Z
      //   45: istore #7
      //   47: aload_0
      //   48: getfield i : Landroid/support/v7/widget/RecyclerView;
      //   51: getfield n : Landroid/support/v7/widget/RecyclerView$g;
      //   54: astore #9
      //   56: aload #9
      //   58: ifnull -> 80
      //   61: iload #7
      //   63: ifeq -> 80
      //   66: aload #9
      //   68: aload_1
      //   69: invokevirtual a : (Landroid/support/v7/widget/RecyclerView$d0;)Z
      //   72: ifeq -> 80
      //   75: iconst_1
      //   76: istore_2
      //   77: goto -> 82
      //   80: iconst_0
      //   81: istore_2
      //   82: iconst_0
      //   83: istore_3
      //   84: iconst_0
      //   85: istore #6
      //   87: iconst_0
      //   88: istore #5
      //   90: iload_2
      //   91: ifne -> 105
      //   94: iload #5
      //   96: istore #4
      //   98: aload_1
      //   99: invokevirtual o : ()Z
      //   102: ifeq -> 282
      //   105: iload #6
      //   107: istore_2
      //   108: aload_0
      //   109: getfield f : I
      //   112: ifle -> 261
      //   115: iload #6
      //   117: istore_2
      //   118: aload_1
      //   119: sipush #526
      //   122: invokevirtual b : (I)Z
      //   125: ifne -> 261
      //   128: aload_0
      //   129: getfield c : Ljava/util/ArrayList;
      //   132: invokevirtual size : ()I
      //   135: istore_3
      //   136: iload_3
      //   137: istore_2
      //   138: iload_3
      //   139: aload_0
      //   140: getfield f : I
      //   143: if_icmplt -> 161
      //   146: iload_3
      //   147: istore_2
      //   148: iload_3
      //   149: ifle -> 161
      //   152: aload_0
      //   153: iconst_0
      //   154: invokevirtual e : (I)V
      //   157: iload_3
      //   158: iconst_1
      //   159: isub
      //   160: istore_2
      //   161: iload_2
      //   162: istore_3
      //   163: iload_3
      //   164: istore #4
      //   166: getstatic android/support/v7/widget/RecyclerView.G0 : Z
      //   169: ifeq -> 249
      //   172: iload_3
      //   173: istore #4
      //   175: iload_2
      //   176: ifle -> 249
      //   179: iload_3
      //   180: istore #4
      //   182: aload_0
      //   183: getfield i : Landroid/support/v7/widget/RecyclerView;
      //   186: getfield i0 : Landroid/support/v7/widget/m0$b;
      //   189: aload_1
      //   190: getfield e : I
      //   193: invokevirtual a : (I)Z
      //   196: ifne -> 249
      //   199: iinc #2, -1
      //   202: iload_2
      //   203: iflt -> 244
      //   206: aload_0
      //   207: getfield c : Ljava/util/ArrayList;
      //   210: iload_2
      //   211: invokevirtual get : (I)Ljava/lang/Object;
      //   214: checkcast android/support/v7/widget/RecyclerView$d0
      //   217: getfield e : I
      //   220: istore_3
      //   221: aload_0
      //   222: getfield i : Landroid/support/v7/widget/RecyclerView;
      //   225: getfield i0 : Landroid/support/v7/widget/m0$b;
      //   228: iload_3
      //   229: invokevirtual a : (I)Z
      //   232: ifne -> 238
      //   235: goto -> 244
      //   238: iinc #2, -1
      //   241: goto -> 202
      //   244: iload_2
      //   245: iconst_1
      //   246: iadd
      //   247: istore #4
      //   249: aload_0
      //   250: getfield c : Ljava/util/ArrayList;
      //   253: iload #4
      //   255: aload_1
      //   256: invokevirtual add : (ILjava/lang/Object;)V
      //   259: iconst_1
      //   260: istore_2
      //   261: iload_2
      //   262: istore_3
      //   263: iload #5
      //   265: istore #4
      //   267: iload_2
      //   268: ifne -> 282
      //   271: aload_0
      //   272: aload_1
      //   273: iconst_1
      //   274: invokevirtual a : (Landroid/support/v7/widget/RecyclerView$d0;Z)V
      //   277: iconst_1
      //   278: istore #4
      //   280: iload_2
      //   281: istore_3
      //   282: aload_0
      //   283: getfield i : Landroid/support/v7/widget/RecyclerView;
      //   286: getfield h : Landroid/support/v7/widget/q1;
      //   289: aload_1
      //   290: invokevirtual h : (Landroid/support/v7/widget/RecyclerView$d0;)V
      //   293: iload_3
      //   294: ifne -> 312
      //   297: iload #4
      //   299: ifne -> 312
      //   302: iload #7
      //   304: ifeq -> 312
      //   307: aload_1
      //   308: aconst_null
      //   309: putfield t : Landroid/support/v7/widget/RecyclerView;
      //   312: return
      //   313: new java/lang/StringBuilder
      //   316: dup
      //   317: invokespecial <init> : ()V
      //   320: astore_1
      //   321: aload_1
      //   322: ldc_w 'Trying to recycle an ignored view holder. You should first call stopIgnoringView(view) before calling recycle.'
      //   325: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   328: pop
      //   329: aload_1
      //   330: aload_0
      //   331: getfield i : Landroid/support/v7/widget/RecyclerView;
      //   334: invokevirtual i : ()Ljava/lang/String;
      //   337: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   340: pop
      //   341: new java/lang/IllegalArgumentException
      //   344: dup
      //   345: aload_1
      //   346: invokevirtual toString : ()Ljava/lang/String;
      //   349: invokespecial <init> : (Ljava/lang/String;)V
      //   352: athrow
      //   353: new java/lang/StringBuilder
      //   356: dup
      //   357: invokespecial <init> : ()V
      //   360: astore #9
      //   362: aload #9
      //   364: ldc_w 'Tmp detached view should be removed from RecyclerView before it can be recycled: '
      //   367: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   370: pop
      //   371: aload #9
      //   373: aload_1
      //   374: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   377: pop
      //   378: aload #9
      //   380: aload_0
      //   381: getfield i : Landroid/support/v7/widget/RecyclerView;
      //   384: invokevirtual i : ()Ljava/lang/String;
      //   387: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   390: pop
      //   391: new java/lang/IllegalArgumentException
      //   394: dup
      //   395: aload #9
      //   397: invokevirtual toString : ()Ljava/lang/String;
      //   400: invokespecial <init> : (Ljava/lang/String;)V
      //   403: athrow
      //   404: new java/lang/StringBuilder
      //   407: dup
      //   408: invokespecial <init> : ()V
      //   411: astore #9
      //   413: aload #9
      //   415: ldc_w 'Scrapped or attached views may not be recycled. isScrap:'
      //   418: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   421: pop
      //   422: aload #9
      //   424: aload_1
      //   425: invokevirtual q : ()Z
      //   428: invokevirtual append : (Z)Ljava/lang/StringBuilder;
      //   431: pop
      //   432: aload #9
      //   434: ldc_w ' isAttached:'
      //   437: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   440: pop
      //   441: aload_1
      //   442: getfield c : Landroid/view/View;
      //   445: invokevirtual getParent : ()Landroid/view/ViewParent;
      //   448: ifnull -> 454
      //   451: iconst_1
      //   452: istore #7
      //   454: aload #9
      //   456: iload #7
      //   458: invokevirtual append : (Z)Ljava/lang/StringBuilder;
      //   461: pop
      //   462: aload #9
      //   464: aload_0
      //   465: getfield i : Landroid/support/v7/widget/RecyclerView;
      //   468: invokevirtual i : ()Ljava/lang/String;
      //   471: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   474: pop
      //   475: new java/lang/IllegalArgumentException
      //   478: dup
      //   479: aload #9
      //   481: invokevirtual toString : ()Ljava/lang/String;
      //   484: invokespecial <init> : (Ljava/lang/String;)V
      //   487: astore_1
      //   488: goto -> 493
      //   491: aload_1
      //   492: athrow
      //   493: goto -> 491
    }
    
    public void b(View param1View) {
      RecyclerView.d0 d0 = RecyclerView.k(param1View);
      if (d0.r())
        this.i.removeDetachedView(param1View, false); 
      if (d0.q()) {
        d0.y();
      } else if (d0.z()) {
        d0.c();
      } 
      b(d0);
    }
    
    View c(int param1Int) {
      return ((RecyclerView.d0)this.a.get(param1Int)).c;
    }
    
    void c() {
      this.a.clear();
      ArrayList<RecyclerView.d0> arrayList = this.b;
      if (arrayList != null)
        arrayList.clear(); 
    }
    
    void c(int param1Int1, int param1Int2) {
      for (int i = this.c.size() - 1; i >= 0; i--) {
        RecyclerView.d0 d0 = this.c.get(i);
        if (d0 != null) {
          int j = d0.e;
          if (j >= param1Int1 && j < param1Int1 + param1Int2) {
            d0.a(2);
            e(i);
          } 
        } 
      } 
    }
    
    void c(RecyclerView.d0 param1d0) {
      if (param1d0.q) {
        this.b.remove(param1d0);
      } else {
        this.a.remove(param1d0);
      } 
      param1d0.p = null;
      param1d0.q = false;
      param1d0.c();
    }
    
    void c(View param1View) {
      StringBuilder stringBuilder;
      RecyclerView.d0 d0 = RecyclerView.k(param1View);
      if (d0.b(12) || !d0.s() || this.i.a(d0)) {
        if (!d0.n() || d0.p() || this.i.n.c()) {
          d0.a(this, false);
          this.a.add(d0);
          return;
        } 
        stringBuilder = new StringBuilder();
        stringBuilder.append("Called scrap view with an invalid view. Invalid views cannot be reused from scrap, they should rebound from recycler pool.");
        stringBuilder.append(this.i.i());
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
      if (this.b == null)
        this.b = new ArrayList<RecyclerView.d0>(); 
      stringBuilder.a(this, true);
      this.b.add(stringBuilder);
    }
    
    RecyclerView.u d() {
      if (this.g == null)
        this.g = new RecyclerView.u(); 
      return this.g;
    }
    
    public View d(int param1Int) {
      return b(param1Int, false);
    }
    
    boolean d(RecyclerView.d0 param1d0) {
      if (param1d0.p())
        return this.i.j0.d(); 
      int i = param1d0.e;
      if (i >= 0 && i < this.i.n.a()) {
        boolean bool1 = this.i.j0.d();
        boolean bool = false;
        if (!bool1 && this.i.n.b(param1d0.e) != param1d0.h())
          return false; 
        if (this.i.n.c()) {
          if (param1d0.g() == this.i.n.a(param1d0.e))
            bool = true; 
          return bool;
        } 
        return true;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Inconsistency detected. Invalid view holder adapter position");
      stringBuilder.append(param1d0);
      stringBuilder.append(this.i.i());
      throw new IndexOutOfBoundsException(stringBuilder.toString());
    }
    
    int e() {
      return this.a.size();
    }
    
    void e(int param1Int) {
      a(this.c.get(param1Int), true);
      this.c.remove(param1Int);
    }
    
    public List<RecyclerView.d0> f() {
      return this.d;
    }
    
    public void f(int param1Int) {
      this.e = param1Int;
      j();
    }
    
    void g() {
      int i = this.c.size();
      for (byte b = 0; b < i; b++) {
        RecyclerView.p p = (RecyclerView.p)((RecyclerView.d0)this.c.get(b)).c.getLayoutParams();
        if (p != null)
          p.c = true; 
      } 
    }
    
    void h() {
      int i = this.c.size();
      for (byte b = 0; b < i; b++) {
        RecyclerView.d0 d0 = this.c.get(b);
        if (d0 != null) {
          d0.a(6);
          d0.a((Object)null);
        } 
      } 
      RecyclerView.g g = this.i.n;
      if (g == null || !g.c())
        i(); 
    }
    
    void i() {
      for (int i = this.c.size() - 1; i >= 0; i--)
        e(i); 
      this.c.clear();
      if (RecyclerView.G0)
        this.i.i0.a(); 
    }
    
    void j() {
      RecyclerView.o o = this.i.o;
      if (o != null) {
        i = o.m;
      } else {
        i = 0;
      } 
      this.f = this.e + i;
      for (int i = this.c.size() - 1; i >= 0 && this.c.size() > this.f; i--)
        e(i); 
    }
  }
  
  public static interface w {
    void a(RecyclerView.d0 param1d0);
  }
  
  private class x extends i {
    final RecyclerView a;
    
    x(RecyclerView this$0) {}
    
    public void a() {
      this.a.a((String)null);
      RecyclerView recyclerView = this.a;
      recyclerView.j0.g = true;
      recyclerView.b(true);
      if (!this.a.f.c())
        this.a.requestLayout(); 
    }
    
    public void a(int param1Int1, int param1Int2, Object param1Object) {
      this.a.a((String)null);
      if (this.a.f.a(param1Int1, param1Int2, param1Object))
        b(); 
    }
    
    void b() {
      if (RecyclerView.F0) {
        RecyclerView recyclerView1 = this.a;
        if (recyclerView1.u && recyclerView1.t) {
          android.support.v4.view.u.a((View)recyclerView1, recyclerView1.j);
          return;
        } 
      } 
      RecyclerView recyclerView = this.a;
      recyclerView.C = true;
      recyclerView.requestLayout();
    }
  }
  
  public static class y extends android.support.v4.view.a {
    public static final Parcelable.Creator<y> CREATOR = (Parcelable.Creator<y>)new a();
    
    Parcelable e;
    
    y(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      if (param1ClassLoader == null)
        param1ClassLoader = RecyclerView.o.class.getClassLoader(); 
      this.e = param1Parcel.readParcelable(param1ClassLoader);
    }
    
    y(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    void a(y param1y) {
      this.e = param1y.e;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeParcelable(this.e, 0);
    }
    
    static final class a implements Parcelable.ClassLoaderCreator<y> {
      public RecyclerView.y createFromParcel(Parcel param2Parcel) {
        return new RecyclerView.y(param2Parcel, null);
      }
      
      public RecyclerView.y createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new RecyclerView.y(param2Parcel, param2ClassLoader);
      }
      
      public RecyclerView.y[] newArray(int param2Int) {
        return new RecyclerView.y[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.ClassLoaderCreator<y> {
    public RecyclerView.y createFromParcel(Parcel param1Parcel) {
      return new RecyclerView.y(param1Parcel, null);
    }
    
    public RecyclerView.y createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new RecyclerView.y(param1Parcel, param1ClassLoader);
    }
    
    public RecyclerView.y[] newArray(int param1Int) {
      return new RecyclerView.y[param1Int];
    }
  }
  
  public static abstract class z {
    public abstract int a();
    
    public abstract void a(int param1Int);
    
    abstract void a(int param1Int1, int param1Int2);
    
    protected abstract void a(View param1View);
    
    public abstract boolean b();
    
    public abstract boolean c();
    
    protected final void d() {
      throw null;
    }
    
    public static interface a {}
  }
  
  public static interface a {}
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\RecyclerView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */