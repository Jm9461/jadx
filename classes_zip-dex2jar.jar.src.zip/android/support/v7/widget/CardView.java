package android.support.v7.widget;

import a.b.h.b.b;
import a.b.h.b.d;
import a.b.h.b.e;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;

public class CardView extends FrameLayout {
  private static final int[] j = new int[] { 16842801 };
  
  private static final c0 k;
  
  private boolean c;
  
  private boolean d;
  
  int e;
  
  int f;
  
  final Rect g;
  
  final Rect h;
  
  private final b0 i;
  
  static {
    int i = Build.VERSION.SDK_INT;
    if (i >= 21) {
      k = new z();
    } else if (i >= 17) {
      k = new y();
    } else {
      k = new a0();
    } 
    k.a();
  }
  
  public CardView(Context paramContext) {
    this(paramContext, null);
  }
  
  public CardView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.b.h.b.a.cardViewStyle);
  }
  
  public CardView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    ColorStateList colorStateList;
    this.g = new Rect();
    this.h = new Rect();
    this.i = new a(this);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, e.CardView, paramInt, d.CardView);
    if (typedArray.hasValue(e.CardView_cardBackgroundColor)) {
      colorStateList = typedArray.getColorStateList(e.CardView_cardBackgroundColor);
    } else {
      TypedArray typedArray1 = getContext().obtainStyledAttributes(j);
      paramInt = typedArray1.getColor(0, 0);
      typedArray1.recycle();
      float[] arrayOfFloat = new float[3];
      Color.colorToHSV(paramInt, arrayOfFloat);
      if (arrayOfFloat[2] > 0.5F) {
        paramInt = getResources().getColor(b.cardview_light_background);
      } else {
        paramInt = getResources().getColor(b.cardview_dark_background);
      } 
      colorStateList = ColorStateList.valueOf(paramInt);
    } 
    float f3 = typedArray.getDimension(e.CardView_cardCornerRadius, 0.0F);
    float f2 = typedArray.getDimension(e.CardView_cardElevation, 0.0F);
    float f1 = typedArray.getDimension(e.CardView_cardMaxElevation, 0.0F);
    this.c = typedArray.getBoolean(e.CardView_cardUseCompatPadding, false);
    this.d = typedArray.getBoolean(e.CardView_cardPreventCornerOverlap, true);
    paramInt = typedArray.getDimensionPixelSize(e.CardView_contentPadding, 0);
    this.g.left = typedArray.getDimensionPixelSize(e.CardView_contentPaddingLeft, paramInt);
    this.g.top = typedArray.getDimensionPixelSize(e.CardView_contentPaddingTop, paramInt);
    this.g.right = typedArray.getDimensionPixelSize(e.CardView_contentPaddingRight, paramInt);
    this.g.bottom = typedArray.getDimensionPixelSize(e.CardView_contentPaddingBottom, paramInt);
    if (f2 > f1)
      f1 = f2; 
    this.e = typedArray.getDimensionPixelSize(e.CardView_android_minWidth, 0);
    this.f = typedArray.getDimensionPixelSize(e.CardView_android_minHeight, 0);
    typedArray.recycle();
    k.a(this.i, paramContext, colorStateList, f3, f2, f1);
  }
  
  public ColorStateList getCardBackgroundColor() {
    return k.e(this.i);
  }
  
  public float getCardElevation() {
    return k.d(this.i);
  }
  
  public int getContentPaddingBottom() {
    return this.g.bottom;
  }
  
  public int getContentPaddingLeft() {
    return this.g.left;
  }
  
  public int getContentPaddingRight() {
    return this.g.right;
  }
  
  public int getContentPaddingTop() {
    return this.g.top;
  }
  
  public float getMaxCardElevation() {
    return k.h(this.i);
  }
  
  public boolean getPreventCornerOverlap() {
    return this.d;
  }
  
  public float getRadius() {
    return k.g(this.i);
  }
  
  public boolean getUseCompatPadding() {
    return this.c;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (!(k instanceof z)) {
      int i = View.MeasureSpec.getMode(paramInt1);
      if (i == Integer.MIN_VALUE || i == 1073741824) {
        int j = (int)Math.ceil(k.b(this.i));
        paramInt1 = View.MeasureSpec.makeMeasureSpec(Math.max(j, View.MeasureSpec.getSize(paramInt1)), i);
      } 
      i = View.MeasureSpec.getMode(paramInt2);
      if (i == Integer.MIN_VALUE || i == 1073741824) {
        int j = (int)Math.ceil(k.a(this.i));
        paramInt2 = View.MeasureSpec.makeMeasureSpec(Math.max(j, View.MeasureSpec.getSize(paramInt2)), i);
      } 
      super.onMeasure(paramInt1, paramInt2);
    } else {
      super.onMeasure(paramInt1, paramInt2);
    } 
  }
  
  public void setCardBackgroundColor(int paramInt) {
    k.a(this.i, ColorStateList.valueOf(paramInt));
  }
  
  public void setCardBackgroundColor(ColorStateList paramColorStateList) {
    k.a(this.i, paramColorStateList);
  }
  
  public void setCardElevation(float paramFloat) {
    k.b(this.i, paramFloat);
  }
  
  public void setMaxCardElevation(float paramFloat) {
    k.c(this.i, paramFloat);
  }
  
  public void setMinimumHeight(int paramInt) {
    this.f = paramInt;
    super.setMinimumHeight(paramInt);
  }
  
  public void setMinimumWidth(int paramInt) {
    this.e = paramInt;
    super.setMinimumWidth(paramInt);
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public void setPaddingRelative(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public void setPreventCornerOverlap(boolean paramBoolean) {
    if (paramBoolean != this.d) {
      this.d = paramBoolean;
      k.f(this.i);
    } 
  }
  
  public void setRadius(float paramFloat) {
    k.a(this.i, paramFloat);
  }
  
  public void setUseCompatPadding(boolean paramBoolean) {
    if (this.c != paramBoolean) {
      this.c = paramBoolean;
      k.c(this.i);
    } 
  }
  
  class a implements b0 {
    private Drawable a;
    
    final CardView b;
    
    a(CardView this$0) {}
    
    public View a() {
      return (View)this.b;
    }
    
    public void a(int param1Int1, int param1Int2) {
      CardView cardView = this.b;
      if (param1Int1 > cardView.e)
        CardView.a(cardView, param1Int1); 
      cardView = this.b;
      if (param1Int2 > cardView.f)
        CardView.b(cardView, param1Int2); 
    }
    
    public void a(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.b.h.set(param1Int1, param1Int2, param1Int3, param1Int4);
      CardView cardView = this.b;
      Rect rect = cardView.g;
      CardView.a(cardView, rect.left + param1Int1, rect.top + param1Int2, rect.right + param1Int3, rect.bottom + param1Int4);
    }
    
    public void a(Drawable param1Drawable) {
      this.a = param1Drawable;
      this.b.setBackgroundDrawable(param1Drawable);
    }
    
    public boolean b() {
      return this.b.getUseCompatPadding();
    }
    
    public Drawable c() {
      return this.a;
    }
    
    public boolean d() {
      return this.b.getPreventCornerOverlap();
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\CardView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */