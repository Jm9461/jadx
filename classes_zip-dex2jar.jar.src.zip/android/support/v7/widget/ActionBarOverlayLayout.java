package android.support.v7.widget;

import a.b.h.a.f;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v4.view.n;
import android.support.v4.view.o;
import android.support.v4.view.u;
import android.support.v7.view.menu.p;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.widget.OverScroller;

public class ActionBarOverlayLayout extends ViewGroup implements e0, n {
  static final int[] D = new int[] { a.b.h.a.a.actionBarSize, 16842841 };
  
  private final Runnable A = new b(this);
  
  private final Runnable B = new c(this);
  
  private final o C;
  
  private int c;
  
  private int d = 0;
  
  private ContentFrameLayout e;
  
  ActionBarContainer f;
  
  private f0 g;
  
  private Drawable h;
  
  private boolean i;
  
  private boolean j;
  
  private boolean k;
  
  private boolean l;
  
  boolean m;
  
  private int n;
  
  private int o;
  
  private final Rect p = new Rect();
  
  private final Rect q = new Rect();
  
  private final Rect r = new Rect();
  
  private final Rect s = new Rect();
  
  private final Rect t = new Rect();
  
  private final Rect u = new Rect();
  
  private final Rect v = new Rect();
  
  private d w;
  
  private OverScroller x;
  
  ViewPropertyAnimator y;
  
  final AnimatorListenerAdapter z = new a(this);
  
  public ActionBarOverlayLayout(Context paramContext) {
    this(paramContext, null);
  }
  
  public ActionBarOverlayLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    a(paramContext);
    this.C = new o(this);
  }
  
  private f0 a(View paramView) {
    if (paramView instanceof f0)
      return (f0)paramView; 
    if (paramView instanceof Toolbar)
      return ((Toolbar)paramView).getWrapper(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can't make a decor toolbar out of ");
    stringBuilder.append(paramView.getClass().getSimpleName());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void a(Context paramContext) {
    TypedArray typedArray = getContext().getTheme().obtainStyledAttributes(D);
    boolean bool2 = false;
    this.c = typedArray.getDimensionPixelSize(0, 0);
    this.h = typedArray.getDrawable(1);
    if (this.h == null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    setWillNotDraw(bool1);
    typedArray.recycle();
    boolean bool1 = bool2;
    if ((paramContext.getApplicationInfo()).targetSdkVersion < 19)
      bool1 = true; 
    this.i = bool1;
    this.x = new OverScroller(paramContext);
  }
  
  private boolean a(float paramFloat1, float paramFloat2) {
    boolean bool;
    this.x.fling(0, 0, 0, (int)paramFloat2, 0, 0, -2147483648, 2147483647);
    if (this.x.getFinalY() > this.f.getHeight()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private boolean a(View paramView, Rect paramRect, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    boolean bool2 = false;
    e e = (e)paramView.getLayoutParams();
    boolean bool1 = bool2;
    if (paramBoolean1) {
      int i = e.leftMargin;
      int j = paramRect.left;
      bool1 = bool2;
      if (i != j) {
        bool1 = true;
        e.leftMargin = j;
      } 
    } 
    paramBoolean1 = bool1;
    if (paramBoolean2) {
      int i = e.topMargin;
      int j = paramRect.top;
      paramBoolean1 = bool1;
      if (i != j) {
        paramBoolean1 = true;
        e.topMargin = j;
      } 
    } 
    paramBoolean2 = paramBoolean1;
    if (paramBoolean4) {
      int j = e.rightMargin;
      int i = paramRect.right;
      paramBoolean2 = paramBoolean1;
      if (j != i) {
        paramBoolean2 = true;
        e.rightMargin = i;
      } 
    } 
    paramBoolean1 = paramBoolean2;
    if (paramBoolean3) {
      int i = e.bottomMargin;
      int j = paramRect.bottom;
      paramBoolean1 = paramBoolean2;
      if (i != j) {
        paramBoolean1 = true;
        e.bottomMargin = j;
      } 
    } 
    return paramBoolean1;
  }
  
  private void k() {
    h();
    this.B.run();
  }
  
  private void l() {
    h();
    postDelayed(this.B, 600L);
  }
  
  private void m() {
    h();
    postDelayed(this.A, 600L);
  }
  
  private void n() {
    h();
    this.A.run();
  }
  
  public void a(int paramInt) {
    j();
    if (paramInt != 2) {
      if (paramInt != 5) {
        if (paramInt == 109)
          setOverlayMode(true); 
      } else {
        this.g.o();
      } 
    } else {
      this.g.m();
    } 
  }
  
  public void a(Menu paramMenu, p.a parama) {
    j();
    this.g.a(paramMenu, parama);
  }
  
  public boolean a() {
    j();
    return this.g.a();
  }
  
  public boolean b() {
    j();
    return this.g.b();
  }
  
  public boolean c() {
    j();
    return this.g.c();
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof e;
  }
  
  public boolean d() {
    j();
    return this.g.d();
  }
  
  public void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
    if (this.h != null && !this.i) {
      byte b;
      if (this.f.getVisibility() == 0) {
        b = (int)(this.f.getBottom() + this.f.getTranslationY() + 0.5F);
      } else {
        b = 0;
      } 
      this.h.setBounds(0, b, getWidth(), this.h.getIntrinsicHeight() + b);
      this.h.draw(paramCanvas);
    } 
  }
  
  public void e() {
    j();
    this.g.e();
  }
  
  public boolean f() {
    j();
    return this.g.f();
  }
  
  protected boolean fitSystemWindows(Rect paramRect) {
    j();
    if ((u.r((View)this) & 0x100) != 0);
    boolean bool = a((View)this.f, paramRect, true, true, false, true);
    this.s.set(paramRect);
    r1.a((View)this, this.s, this.p);
    if (!this.t.equals(this.s)) {
      bool = true;
      this.t.set(this.s);
    } 
    if (!this.q.equals(this.p)) {
      bool = true;
      this.q.set(this.p);
    } 
    if (bool)
      requestLayout(); 
    return true;
  }
  
  public void g() {
    j();
    this.g.g();
  }
  
  protected e generateDefaultLayoutParams() {
    return new e(-1, -1);
  }
  
  public e generateLayoutParams(AttributeSet paramAttributeSet) {
    return new e(getContext(), paramAttributeSet);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new e(paramLayoutParams);
  }
  
  public int getActionBarHideOffset() {
    boolean bool;
    ActionBarContainer actionBarContainer = this.f;
    if (actionBarContainer != null) {
      bool = -((int)actionBarContainer.getTranslationY());
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int getNestedScrollAxes() {
    return this.C.a();
  }
  
  public CharSequence getTitle() {
    j();
    return this.g.getTitle();
  }
  
  void h() {
    removeCallbacks(this.A);
    removeCallbacks(this.B);
    ViewPropertyAnimator viewPropertyAnimator = this.y;
    if (viewPropertyAnimator != null)
      viewPropertyAnimator.cancel(); 
  }
  
  public boolean i() {
    return this.j;
  }
  
  void j() {
    if (this.e == null) {
      this.e = (ContentFrameLayout)findViewById(f.action_bar_activity_content);
      this.f = (ActionBarContainer)findViewById(f.action_bar_container);
      this.g = a(findViewById(f.action_bar));
    } 
  }
  
  protected void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    a(getContext());
    u.C((View)this);
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    h();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt3 = getChildCount();
    paramInt4 = getPaddingLeft();
    getPaddingRight();
    paramInt2 = getPaddingTop();
    getPaddingBottom();
    for (paramInt1 = 0; paramInt1 < paramInt3; paramInt1++) {
      View view = getChildAt(paramInt1);
      if (view.getVisibility() != 8) {
        e e = (e)view.getLayoutParams();
        int m = view.getMeasuredWidth();
        int j = view.getMeasuredHeight();
        int i = e.leftMargin + paramInt4;
        int k = e.topMargin + paramInt2;
        view.layout(i, k, i + m, k + j);
      } 
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    j();
    int i = 0;
    measureChildWithMargins((View)this.f, paramInt1, 0, paramInt2, 0);
    e e = (e)this.f.getLayoutParams();
    int i2 = Math.max(0, this.f.getMeasuredWidth() + e.leftMargin + e.rightMargin);
    int i1 = Math.max(0, this.f.getMeasuredHeight() + e.topMargin + e.bottomMargin);
    int m = View.combineMeasuredStates(0, this.f.getMeasuredState());
    if ((u.r((View)this) & 0x100) != 0) {
      j = 1;
    } else {
      j = 0;
    } 
    if (j) {
      int i3 = this.c;
      i = i3;
      if (this.k) {
        i = i3;
        if (this.f.getTabContainer() != null)
          i = i3 + this.c; 
      } 
    } else if (this.f.getVisibility() != 8) {
      i = this.f.getMeasuredHeight();
    } 
    this.r.set(this.p);
    this.u.set(this.s);
    if (!this.j && !j) {
      Rect rect = this.r;
      rect.top += i;
      rect.bottom += 0;
    } else {
      Rect rect = this.u;
      rect.top += i;
      rect.bottom += 0;
    } 
    a((View)this.e, this.r, true, true, true, true);
    if (!this.v.equals(this.u)) {
      this.v.set(this.u);
      this.e.a(this.u);
    } 
    measureChildWithMargins((View)this.e, paramInt1, 0, paramInt2, 0);
    e = (e)this.e.getLayoutParams();
    i = Math.max(i2, this.e.getMeasuredWidth() + e.leftMargin + e.rightMargin);
    i2 = Math.max(i1, this.e.getMeasuredHeight() + e.topMargin + e.bottomMargin);
    int j = View.combineMeasuredStates(m, this.e.getMeasuredState());
    i1 = getPaddingLeft();
    int k = getPaddingRight();
    m = Math.max(i2 + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight());
    i = Math.max(i + i1 + k, getSuggestedMinimumWidth());
    setMeasuredDimension(View.resolveSizeAndState(i, paramInt1, j), View.resolveSizeAndState(m, paramInt2, j << 16));
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    if (!this.l || !paramBoolean)
      return false; 
    if (a(paramFloat1, paramFloat2)) {
      k();
    } else {
      n();
    } 
    this.m = true;
    return true;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return false;
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {}
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.n += paramInt2;
    setActionBarHideOffset(this.n);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    this.C.a(paramView1, paramView2, paramInt);
    this.n = getActionBarHideOffset();
    h();
    d d1 = this.w;
    if (d1 != null)
      d1.b(); 
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return ((paramInt & 0x2) == 0 || this.f.getVisibility() != 0) ? false : this.l;
  }
  
  public void onStopNestedScroll(View paramView) {
    if (this.l && !this.m)
      if (this.n <= this.f.getHeight()) {
        m();
      } else {
        l();
      }  
    d d1 = this.w;
    if (d1 != null)
      d1.d(); 
  }
  
  public void onWindowSystemUiVisibilityChanged(int paramInt) {
    boolean bool1;
    boolean bool2;
    if (Build.VERSION.SDK_INT >= 16)
      super.onWindowSystemUiVisibilityChanged(paramInt); 
    j();
    int i = this.o;
    this.o = paramInt;
    boolean bool3 = true;
    if ((paramInt & 0x4) == 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if ((paramInt & 0x100) != 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    d d1 = this.w;
    if (d1 != null) {
      if (bool2)
        bool3 = false; 
      d1.a(bool3);
      if (bool1 || !bool2) {
        this.w.a();
      } else {
        this.w.c();
      } 
    } 
    if (((i ^ paramInt) & 0x100) != 0 && this.w != null)
      u.C((View)this); 
  }
  
  protected void onWindowVisibilityChanged(int paramInt) {
    super.onWindowVisibilityChanged(paramInt);
    this.d = paramInt;
    d d1 = this.w;
    if (d1 != null)
      d1.a(paramInt); 
  }
  
  public void setActionBarHideOffset(int paramInt) {
    h();
    paramInt = Math.max(0, Math.min(paramInt, this.f.getHeight()));
    this.f.setTranslationY(-paramInt);
  }
  
  public void setActionBarVisibilityCallback(d paramd) {
    this.w = paramd;
    if (getWindowToken() != null) {
      this.w.a(this.d);
      if (this.o != 0) {
        onWindowSystemUiVisibilityChanged(this.o);
        u.C((View)this);
      } 
    } 
  }
  
  public void setHasNonEmbeddedTabs(boolean paramBoolean) {
    this.k = paramBoolean;
  }
  
  public void setHideOnContentScrollEnabled(boolean paramBoolean) {
    if (paramBoolean != this.l) {
      this.l = paramBoolean;
      if (!paramBoolean) {
        h();
        setActionBarHideOffset(0);
      } 
    } 
  }
  
  public void setIcon(int paramInt) {
    j();
    this.g.setIcon(paramInt);
  }
  
  public void setIcon(Drawable paramDrawable) {
    j();
    this.g.setIcon(paramDrawable);
  }
  
  public void setLogo(int paramInt) {
    j();
    this.g.b(paramInt);
  }
  
  public void setOverlayMode(boolean paramBoolean) {
    this.j = paramBoolean;
    if (paramBoolean && (getContext().getApplicationInfo()).targetSdkVersion < 19) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    this.i = paramBoolean;
  }
  
  public void setShowingForActionMode(boolean paramBoolean) {}
  
  public void setUiOptions(int paramInt) {}
  
  public void setWindowCallback(Window.Callback paramCallback) {
    j();
    this.g.setWindowCallback(paramCallback);
  }
  
  public void setWindowTitle(CharSequence paramCharSequence) {
    j();
    this.g.setWindowTitle(paramCharSequence);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  class a extends AnimatorListenerAdapter {
    final ActionBarOverlayLayout a;
    
    a(ActionBarOverlayLayout this$0) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      ActionBarOverlayLayout actionBarOverlayLayout = this.a;
      actionBarOverlayLayout.y = null;
      actionBarOverlayLayout.m = false;
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      ActionBarOverlayLayout actionBarOverlayLayout = this.a;
      actionBarOverlayLayout.y = null;
      actionBarOverlayLayout.m = false;
    }
  }
  
  class b implements Runnable {
    final ActionBarOverlayLayout c;
    
    b(ActionBarOverlayLayout this$0) {}
    
    public void run() {
      this.c.h();
      ActionBarOverlayLayout actionBarOverlayLayout = this.c;
      actionBarOverlayLayout.y = actionBarOverlayLayout.f.animate().translationY(0.0F).setListener((Animator.AnimatorListener)this.c.z);
    }
  }
  
  class c implements Runnable {
    final ActionBarOverlayLayout c;
    
    c(ActionBarOverlayLayout this$0) {}
    
    public void run() {
      this.c.h();
      ActionBarOverlayLayout actionBarOverlayLayout = this.c;
      actionBarOverlayLayout.y = actionBarOverlayLayout.f.animate().translationY(-this.c.f.getHeight()).setListener((Animator.AnimatorListener)this.c.z);
    }
  }
  
  public static interface d {
    void a();
    
    void a(int param1Int);
    
    void a(boolean param1Boolean);
    
    void b();
    
    void c();
    
    void d();
  }
  
  public static class e extends ViewGroup.MarginLayoutParams {
    public e(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public e(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public e(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\ActionBarOverlayLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */