package android.support.v7.widget;

import android.content.Context;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;

public class StaggeredGridLayoutManager extends RecyclerView.o implements RecyclerView.z.a {
  boolean A = false;
  
  private BitSet B;
  
  int C = -1;
  
  int D = Integer.MIN_VALUE;
  
  d E = new d();
  
  private int F = 2;
  
  private boolean G;
  
  private boolean H;
  
  private e I;
  
  private int J;
  
  private final Rect K = new Rect();
  
  private final b L = new b(this);
  
  private boolean M = false;
  
  private boolean N = true;
  
  private int[] O;
  
  private final Runnable P = new a(this);
  
  private int s = -1;
  
  f[] t;
  
  t0 u;
  
  t0 v;
  
  private int w;
  
  private int x;
  
  private final n0 y;
  
  boolean z = false;
  
  public StaggeredGridLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    RecyclerView.o.d d1 = RecyclerView.o.a(paramContext, paramAttributeSet, paramInt1, paramInt2);
    i(d1.a);
    j(d1.b);
    c(d1.c);
    this.y = new n0();
    M();
  }
  
  private void M() {
    this.u = t0.a(this, this.w);
    this.v = t0.a(this, 1 - this.w);
  }
  
  private void N() {
    if (this.v.d() == 1073741824)
      return; 
    float f1 = 0.0F;
    int k = e();
    int i;
    for (i = 0; i < k; i++) {
      View view = c(i);
      float f2 = this.v.b(view);
      if (f2 >= f1) {
        float f3 = f2;
        if (((c)view.getLayoutParams()).f())
          f3 = 1.0F * f2 / this.s; 
        f1 = Math.max(f1, f3);
      } 
    } 
    int m = this.x;
    int j = Math.round(this.s * f1);
    i = j;
    if (this.v.d() == Integer.MIN_VALUE)
      i = Math.min(j, this.v.g()); 
    k(i);
    if (this.x == m)
      return; 
    for (i = 0; i < k; i++) {
      View view = c(i);
      c c = (c)view.getLayoutParams();
      if (!c.f)
        if (L() && this.w == 1) {
          j = this.s;
          int n = c.e.e;
          view.offsetLeftAndRight(-(j - 1 - n) * this.x - -(j - 1 - n) * m);
        } else {
          int n = c.e.e;
          j = this.x * n;
          n *= m;
          if (this.w == 1) {
            view.offsetLeftAndRight(j - n);
          } else {
            view.offsetTopAndBottom(j - n);
          } 
        }  
    } 
  }
  
  private void O() {
    if (this.w == 1 || !L()) {
      this.A = this.z;
      return;
    } 
    this.A = this.z ^ true;
  }
  
  private int a(RecyclerView.v paramv, n0 paramn0, RecyclerView.a0 parama0) {
    int i;
    this.B.set(0, this.s, true);
    if (this.y.i) {
      if (paramn0.e == 1) {
        i = Integer.MAX_VALUE;
      } else {
        i = Integer.MIN_VALUE;
      } 
    } else if (paramn0.e == 1) {
      i = paramn0.g + paramn0.b;
    } else {
      i = paramn0.f - paramn0.b;
    } 
    e(paramn0.e, i);
    if (this.A) {
      k = this.u.b();
    } else {
      k = this.u.f();
    } 
    int j;
    for (j = 0; paramn0.a(parama0) && (this.y.i || !this.B.isEmpty()); j = 1) {
      int m;
      int n;
      int i1;
      f f1;
      View view = paramn0.a(paramv);
      c c = (c)view.getLayoutParams();
      int i2 = c.a();
      j = this.E.d(i2);
      if (j == -1) {
        i1 = 1;
      } else {
        i1 = 0;
      } 
      if (i1) {
        if (c.f) {
          f1 = this.t[0];
        } else {
          f1 = a(paramn0);
        } 
        this.E.a(i2, f1);
      } else {
        f1 = this.t[j];
      } 
      c.e = f1;
      if (paramn0.e == 1) {
        b(view);
      } else {
        b(view, 0);
      } 
      a(view, c, false);
      if (paramn0.e == 1) {
        if (c.f) {
          j = r(k);
        } else {
          j = f1.a(k);
        } 
        n = this.u.b(view);
        if (i1 && c.f) {
          d.a a1 = n(j);
          a1.d = -1;
          a1.c = i2;
          this.E.a(a1);
        } 
        m = j;
        n += j;
      } else {
        if (c.f) {
          j = u(k);
        } else {
          j = f1.b(k);
        } 
        m = this.u.b(view);
        if (i1 && c.f) {
          d.a a1 = o(j);
          a1.d = 1;
          a1.c = i2;
          this.E.a(a1);
        } 
        n = j;
        m = j - m;
      } 
      if (c.f && paramn0.d == -1)
        if (i1) {
          this.M = true;
        } else {
          if (paramn0.e == 1) {
            j = D() ^ true;
          } else {
            j = E() ^ true;
          } 
          if (j != 0) {
            d.a a1 = this.E.c(i2);
            if (a1 != null)
              a1.f = true; 
            this.M = true;
          } 
        }  
      a(view, c, paramn0);
      if (L() && this.w == 1) {
        if (c.f) {
          j = this.v.b();
        } else {
          j = this.v.b() - (this.s - 1 - f1.e) * this.x;
        } 
        i2 = this.v.b(view);
        i1 = j;
        j -= i2;
        i2 = i1;
      } else {
        if (c.f) {
          j = this.v.f();
        } else {
          j = f1.e * this.x + this.v.f();
        } 
        i2 = this.v.b(view);
        i1 = j;
        i2 += j;
        j = i1;
      } 
      if (this.w == 1) {
        a(view, j, m, i2, n);
      } else {
        a(view, m, j, n, i2);
      } 
      if (c.f) {
        e(this.y.e, i);
      } else {
        a(f1, this.y.e, i);
      } 
      a(paramv, this.y);
      if (this.y.h && view.hasFocusable())
        if (c.f) {
          this.B.clear();
        } else {
          this.B.set(f1.e, false);
        }  
    } 
    int k = 0;
    if (j == 0)
      a(paramv, this.y); 
    if (this.y.e == -1) {
      i = u(this.u.f());
      i = this.u.f() - i;
    } else {
      i = r(this.u.b()) - this.u.b();
    } 
    j = k;
    if (i > 0)
      j = Math.min(paramn0.b, i); 
    return j;
  }
  
  private f a(n0 paramn0) {
    f f1;
    int i;
    int j;
    byte b1;
    if (v(paramn0.e)) {
      i = this.s - 1;
      j = -1;
      b1 = -1;
    } else {
      i = 0;
      j = this.s;
      b1 = 1;
    } 
    if (paramn0.e == 1) {
      paramn0 = null;
      int n = Integer.MAX_VALUE;
      int i1 = this.u.f();
      while (i != j) {
        f f2 = this.t[i];
        int i3 = f2.a(i1);
        int i2 = n;
        if (i3 < n) {
          f1 = f2;
          i2 = i3;
        } 
        i += b1;
        n = i2;
      } 
      return f1;
    } 
    paramn0 = null;
    int k = Integer.MIN_VALUE;
    int m = this.u.b();
    while (i != j) {
      f f2 = this.t[i];
      int i1 = f2.b(m);
      int n = k;
      if (i1 > k) {
        f1 = f2;
        n = i1;
      } 
      i += b1;
      k = n;
    } 
    return f1;
  }
  
  private void a(RecyclerView.v paramv, int paramInt) {
    int i = e() - 1;
    while (i >= 0) {
      View view = c(i);
      if (this.u.d(view) >= paramInt && this.u.f(view) >= paramInt) {
        c c = (c)view.getLayoutParams();
        if (c.f) {
          byte b1;
          for (b1 = 0; b1 < this.s; b1++) {
            if ((this.t[b1]).a.size() == 1)
              return; 
          } 
          for (b1 = 0; b1 < this.s; b1++)
            this.t[b1].j(); 
        } else {
          if (c.e.a.size() == 1)
            return; 
          c.e.j();
        } 
        a(view, paramv);
        i--;
        continue;
      } 
      return;
    } 
  }
  
  private void a(RecyclerView.v paramv, RecyclerView.a0 parama0, boolean paramBoolean) {
    int i = r(-2147483648);
    if (i == Integer.MIN_VALUE)
      return; 
    i = this.u.b() - i;
    if (i > 0) {
      i -= -c(-i, paramv, parama0);
      if (paramBoolean && i > 0)
        this.u.a(i); 
      return;
    } 
  }
  
  private void a(RecyclerView.v paramv, n0 paramn0) {
    if (!paramn0.a || paramn0.i)
      return; 
    if (paramn0.b == 0) {
      if (paramn0.e == -1) {
        a(paramv, paramn0.g);
      } else {
        b(paramv, paramn0.f);
      } 
    } else if (paramn0.e == -1) {
      int i = paramn0.f;
      i -= s(i);
      if (i < 0) {
        i = paramn0.g;
      } else {
        i = paramn0.g - Math.min(i, paramn0.b);
      } 
      a(paramv, i);
    } else {
      int i = t(paramn0.g) - paramn0.g;
      if (i < 0) {
        i = paramn0.f;
      } else {
        i = paramn0.f + Math.min(i, paramn0.b);
      } 
      b(paramv, i);
    } 
  }
  
  private void a(b paramb) {
    e e1 = this.I;
    int i = e1.e;
    if (i > 0)
      if (i == this.s) {
        for (byte b1 = 0; b1 < this.s; b1++) {
          this.t[b1].c();
          e1 = this.I;
          int j = e1.f[b1];
          i = j;
          if (j != Integer.MIN_VALUE)
            if (e1.k) {
              i = j + this.u.b();
            } else {
              i = j + this.u.f();
            }  
          this.t[b1].d(i);
        } 
      } else {
        e1.b();
        e1 = this.I;
        e1.c = e1.d;
      }  
    e1 = this.I;
    this.H = e1.l;
    c(e1.j);
    O();
    e1 = this.I;
    i = e1.c;
    if (i != -1) {
      this.C = i;
      paramb.c = e1.k;
    } else {
      paramb.c = this.A;
    } 
    e1 = this.I;
    if (e1.g > 1) {
      d d1 = this.E;
      d1.a = e1.h;
      d1.b = e1.i;
    } 
  }
  
  private void a(f paramf, int paramInt1, int paramInt2) {
    int i = paramf.f();
    if (paramInt1 == -1) {
      if (paramf.h() + i <= paramInt2)
        this.B.set(paramf.e, false); 
    } else if (paramf.g() - i >= paramInt2) {
      this.B.set(paramf.e, false);
    } 
  }
  
  private void a(View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    a(paramView, this.K);
    c c = (c)paramView.getLayoutParams();
    int i = c.leftMargin;
    Rect rect = this.K;
    paramInt1 = c(paramInt1, i + rect.left, c.rightMargin + rect.right);
    i = c.topMargin;
    rect = this.K;
    paramInt2 = c(paramInt2, i + rect.top, c.bottomMargin + rect.bottom);
    if (paramBoolean) {
      paramBoolean = b(paramView, paramInt1, paramInt2, c);
    } else {
      paramBoolean = a(paramView, paramInt1, paramInt2, c);
    } 
    if (paramBoolean)
      paramView.measure(paramInt1, paramInt2); 
  }
  
  private void a(View paramView, c paramc, n0 paramn0) {
    if (paramn0.e == 1) {
      if (paramc.f) {
        p(paramView);
      } else {
        paramc.e.a(paramView);
      } 
    } else if (paramc.f) {
      q(paramView);
    } else {
      paramc.e.c(paramView);
    } 
  }
  
  private void a(View paramView, c paramc, boolean paramBoolean) {
    if (paramc.f) {
      if (this.w == 1) {
        a(paramView, this.J, RecyclerView.o.a(h(), i(), p() + m(), paramc.height, true), paramBoolean);
      } else {
        a(paramView, RecyclerView.o.a(q(), r(), n() + o(), paramc.width, true), this.J, paramBoolean);
      } 
    } else if (this.w == 1) {
      a(paramView, RecyclerView.o.a(this.x, r(), 0, paramc.width, false), RecyclerView.o.a(h(), i(), p() + m(), paramc.height, true), paramBoolean);
    } else {
      a(paramView, RecyclerView.o.a(q(), r(), n() + o(), paramc.width, true), RecyclerView.o.a(this.x, i(), 0, paramc.height, false), paramBoolean);
    } 
  }
  
  private boolean a(f paramf) {
    if (this.A) {
      if (paramf.g() < this.u.b()) {
        ArrayList<View> arrayList = paramf.a;
        return (paramf.b((View)arrayList.get(arrayList.size() - 1))).f ^ true;
      } 
    } else if (paramf.h() > this.u.f()) {
      return (paramf.b((View)paramf.a.get(0))).f ^ true;
    } 
    return false;
  }
  
  private void b(int paramInt1, int paramInt2, int paramInt3) {
    int i;
    int j;
    int k;
    if (this.A) {
      k = I();
    } else {
      k = H();
    } 
    if (paramInt3 == 8) {
      if (paramInt1 < paramInt2) {
        j = paramInt2 + 1;
        i = paramInt1;
      } else {
        j = paramInt1 + 1;
        i = paramInt2;
      } 
    } else {
      i = paramInt1;
      j = paramInt1 + paramInt2;
    } 
    this.E.e(i);
    if (paramInt3 != 1) {
      if (paramInt3 != 2) {
        if (paramInt3 == 8) {
          this.E.b(paramInt1, 1);
          this.E.a(paramInt2, 1);
        } 
      } else {
        this.E.b(paramInt1, paramInt2);
      } 
    } else {
      this.E.a(paramInt1, paramInt2);
    } 
    if (j <= k)
      return; 
    if (this.A) {
      paramInt1 = H();
    } else {
      paramInt1 = I();
    } 
    if (i <= paramInt1)
      y(); 
  }
  
  private void b(int paramInt, RecyclerView.a0 parama0) {
    boolean bool1;
    n0 n02 = this.y;
    boolean bool2 = false;
    n02.b = 0;
    n02.c = paramInt;
    byte b1 = 0;
    byte b2 = 0;
    int j = b1;
    int i = b2;
    if (w()) {
      int k = parama0.b();
      j = b1;
      i = b2;
      if (k != -1) {
        boolean bool = this.A;
        if (k < paramInt) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (bool == bool1) {
          i = this.u.g();
          j = b1;
        } else {
          j = this.u.g();
          i = b2;
        } 
      } 
    } 
    if (f()) {
      this.y.f = this.u.f() - j;
      this.y.g = this.u.b() + i;
    } else {
      this.y.g = this.u.a() + i;
      this.y.f = -j;
    } 
    n0 n01 = this.y;
    n01.h = false;
    n01.a = true;
    if (this.u.d() == 0 && this.u.a() == 0) {
      bool1 = true;
    } else {
      bool1 = bool2;
    } 
    n01.i = bool1;
  }
  
  private void b(RecyclerView.v paramv, int paramInt) {
    while (e() > 0) {
      View view = c(0);
      if (this.u.a(view) <= paramInt && this.u.e(view) <= paramInt) {
        c c = (c)view.getLayoutParams();
        if (c.f) {
          byte b1;
          for (b1 = 0; b1 < this.s; b1++) {
            if ((this.t[b1]).a.size() == 1)
              return; 
          } 
          for (b1 = 0; b1 < this.s; b1++)
            this.t[b1].k(); 
        } else {
          if (c.e.a.size() == 1)
            return; 
          c.e.k();
        } 
        a(view, paramv);
        continue;
      } 
      return;
    } 
  }
  
  private void b(RecyclerView.v paramv, RecyclerView.a0 parama0, boolean paramBoolean) {
    int i = u(2147483647);
    if (i == Integer.MAX_VALUE)
      return; 
    i -= this.u.f();
    if (i > 0) {
      i -= c(i, paramv, parama0);
      if (paramBoolean && i > 0)
        this.u.a(-i); 
      return;
    } 
  }
  
  private int c(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt2 == 0 && paramInt3 == 0)
      return paramInt1; 
    int i = View.MeasureSpec.getMode(paramInt1);
    return (i == Integer.MIN_VALUE || i == 1073741824) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, View.MeasureSpec.getSize(paramInt1) - paramInt2 - paramInt3), i) : paramInt1;
  }
  
  private void c(RecyclerView.v paramv, RecyclerView.a0 parama0, boolean paramBoolean) {
    b b2 = this.L;
    if ((this.I != null || this.C != -1) && parama0.a() == 0) {
      b(paramv);
      b2.b();
      return;
    } 
    boolean bool = b2.e;
    boolean bool1 = true;
    if (!bool || this.C != -1 || this.I != null) {
      b1 = 1;
    } else {
      b1 = 0;
    } 
    if (b1) {
      b2.b();
      if (this.I != null) {
        a(b2);
      } else {
        O();
        b2.c = this.A;
      } 
      b(parama0, b2);
      b2.e = true;
    } 
    if (this.I == null && this.C == -1 && (b2.c != this.G || L() != this.H)) {
      this.E.a();
      b2.d = true;
    } 
    if (e() > 0) {
      e e1 = this.I;
      if (e1 == null || e1.e < 1)
        if (b2.d) {
          for (b1 = 0; b1 < this.s; b1++) {
            this.t[b1].c();
            int i = b2.b;
            if (i != Integer.MIN_VALUE)
              this.t[b1].d(i); 
          } 
        } else if (b1 != 0 || this.L.f == null) {
          for (b1 = 0; b1 < this.s; b1++)
            this.t[b1].a(this.A, b2.b); 
          this.L.a(this.t);
        } else {
          for (b1 = 0; b1 < this.s; b1++) {
            f f1 = this.t[b1];
            f1.c();
            f1.d(this.L.f[b1]);
          } 
        }  
    } 
    a(paramv);
    this.y.a = false;
    this.M = false;
    k(this.v.g());
    b(b2.a, parama0);
    if (b2.c) {
      w(-1);
      a(paramv, this.y, parama0);
      w(1);
      n0 n01 = this.y;
      n01.c = b2.a + n01.d;
      a(paramv, n01, parama0);
    } else {
      w(1);
      a(paramv, this.y, parama0);
      w(-1);
      n0 n01 = this.y;
      n01.c = b2.a + n01.d;
      a(paramv, n01, parama0);
    } 
    N();
    if (e() > 0)
      if (this.A) {
        a(paramv, parama0, true);
        b(paramv, parama0, false);
      } else {
        b(paramv, parama0, true);
        a(paramv, parama0, false);
      }  
    boolean bool2 = false;
    byte b1 = bool2;
    if (paramBoolean) {
      b1 = bool2;
      if (!parama0.d()) {
        if (this.F == 0 || e() <= 0 || (!this.M && J() == null))
          bool1 = false; 
        b1 = bool2;
        if (bool1) {
          a(this.P);
          b1 = bool2;
          if (F())
            b1 = 1; 
        } 
      } 
    } 
    if (parama0.d())
      this.L.b(); 
    this.G = b2.c;
    this.H = L();
    if (b1 != 0) {
      this.L.b();
      c(paramv, parama0, false);
    } 
  }
  
  private boolean c(RecyclerView.a0 parama0, b paramb) {
    int i;
    if (this.G) {
      i = q(parama0.a());
    } else {
      i = p(parama0.a());
    } 
    paramb.a = i;
    paramb.b = Integer.MIN_VALUE;
    return true;
  }
  
  private void e(int paramInt1, int paramInt2) {
    for (byte b1 = 0; b1 < this.s; b1++) {
      if (!(this.t[b1]).a.isEmpty())
        a(this.t[b1], paramInt1, paramInt2); 
    } 
  }
  
  private int h(RecyclerView.a0 parama0) {
    return (e() == 0) ? 0 : a1.a(parama0, this.u, b(this.N ^ true), a(this.N ^ true), this, this.N);
  }
  
  private int i(RecyclerView.a0 parama0) {
    return (e() == 0) ? 0 : a1.a(parama0, this.u, b(this.N ^ true), a(this.N ^ true), this, this.N, this.A);
  }
  
  private int j(RecyclerView.a0 parama0) {
    return (e() == 0) ? 0 : a1.b(parama0, this.u, b(this.N ^ true), a(this.N ^ true), this, this.N);
  }
  
  private int l(int paramInt) {
    boolean bool;
    int i = e();
    byte b1 = -1;
    if (i == 0) {
      if (this.A)
        b1 = 1; 
      return b1;
    } 
    if (paramInt < H()) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool == this.A)
      b1 = 1; 
    return b1;
  }
  
  private int m(int paramInt) {
    int i = -1;
    boolean bool2 = true;
    boolean bool1 = true;
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 17) {
          if (paramInt != 33) {
            if (paramInt != 66) {
              if (paramInt != 130)
                return Integer.MIN_VALUE; 
              if (this.w == 1) {
                paramInt = bool1;
              } else {
                paramInt = Integer.MIN_VALUE;
              } 
              return paramInt;
            } 
            if (this.w == 0) {
              paramInt = bool2;
            } else {
              paramInt = Integer.MIN_VALUE;
            } 
            return paramInt;
          } 
          if (this.w != 1)
            i = Integer.MIN_VALUE; 
          return i;
        } 
        if (this.w != 0)
          i = Integer.MIN_VALUE; 
        return i;
      } 
      return (this.w == 1) ? 1 : (L() ? -1 : 1);
    } 
    return (this.w == 1) ? -1 : (L() ? 1 : -1);
  }
  
  private d.a n(int paramInt) {
    d.a a1 = new d.a();
    a1.e = new int[this.s];
    for (byte b1 = 0; b1 < this.s; b1++)
      a1.e[b1] = paramInt - this.t[b1].a(paramInt); 
    return a1;
  }
  
  private d.a o(int paramInt) {
    d.a a1 = new d.a();
    a1.e = new int[this.s];
    for (byte b1 = 0; b1 < this.s; b1++)
      a1.e[b1] = this.t[b1].b(paramInt) - paramInt; 
    return a1;
  }
  
  private int p(int paramInt) {
    int i = e();
    for (byte b1 = 0; b1 < i; b1++) {
      int j = l(c(b1));
      if (j >= 0 && j < paramInt)
        return j; 
    } 
    return 0;
  }
  
  private void p(View paramView) {
    for (int i = this.s - 1; i >= 0; i--)
      this.t[i].a(paramView); 
  }
  
  private int q(int paramInt) {
    for (int i = e() - 1; i >= 0; i--) {
      int j = l(c(i));
      if (j >= 0 && j < paramInt)
        return j; 
    } 
    return 0;
  }
  
  private void q(View paramView) {
    for (int i = this.s - 1; i >= 0; i--)
      this.t[i].c(paramView); 
  }
  
  private int r(int paramInt) {
    int i = this.t[0].a(paramInt);
    byte b1 = 1;
    while (b1 < this.s) {
      int k = this.t[b1].a(paramInt);
      int j = i;
      if (k > i)
        j = k; 
      b1++;
      i = j;
    } 
    return i;
  }
  
  private int s(int paramInt) {
    int i = this.t[0].b(paramInt);
    byte b1 = 1;
    while (b1 < this.s) {
      int k = this.t[b1].b(paramInt);
      int j = i;
      if (k > i)
        j = k; 
      b1++;
      i = j;
    } 
    return i;
  }
  
  private int t(int paramInt) {
    int i = this.t[0].a(paramInt);
    byte b1 = 1;
    while (b1 < this.s) {
      int k = this.t[b1].a(paramInt);
      int j = i;
      if (k < i)
        j = k; 
      b1++;
      i = j;
    } 
    return i;
  }
  
  private int u(int paramInt) {
    int i = this.t[0].b(paramInt);
    byte b1 = 1;
    while (b1 < this.s) {
      int k = this.t[b1].b(paramInt);
      int j = i;
      if (k < i)
        j = k; 
      b1++;
      i = j;
    } 
    return i;
  }
  
  private boolean v(int paramInt) {
    boolean bool;
    int i = this.w;
    boolean bool1 = true;
    boolean bool2 = true;
    if (i == 0) {
      if (paramInt == -1) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool != this.A) {
        bool = bool2;
      } else {
        bool = false;
      } 
      return bool;
    } 
    if (paramInt == -1) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool == this.A) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool == L()) {
      bool = bool1;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private void w(int paramInt) {
    boolean bool1;
    n0 n01 = this.y;
    n01.e = paramInt;
    boolean bool2 = this.A;
    boolean bool = true;
    if (paramInt == -1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool2 == bool1) {
      paramInt = bool;
    } else {
      paramInt = -1;
    } 
    n01.d = paramInt;
  }
  
  public boolean C() {
    boolean bool;
    if (this.I == null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  boolean D() {
    int i = this.t[0].a(-2147483648);
    for (byte b1 = 1; b1 < this.s; b1++) {
      if (this.t[b1].a(-2147483648) != i)
        return false; 
    } 
    return true;
  }
  
  boolean E() {
    int i = this.t[0].b(-2147483648);
    for (byte b1 = 1; b1 < this.s; b1++) {
      if (this.t[b1].b(-2147483648) != i)
        return false; 
    } 
    return true;
  }
  
  boolean F() {
    int i;
    int j;
    byte b1;
    if (e() == 0 || this.F == 0 || !t())
      return false; 
    if (this.A) {
      i = I();
      j = H();
    } else {
      i = H();
      j = I();
    } 
    if (i == 0 && J() != null) {
      this.E.a();
      z();
      y();
      return true;
    } 
    if (!this.M)
      return false; 
    if (this.A) {
      b1 = -1;
    } else {
      b1 = 1;
    } 
    d.a a1 = this.E.a(i, j + 1, b1, true);
    if (a1 == null) {
      this.M = false;
      this.E.b(j + 1);
      return false;
    } 
    d.a a2 = this.E.a(i, a1.c, b1 * -1, true);
    if (a2 == null) {
      this.E.b(a1.c);
    } else {
      this.E.b(a2.c + 1);
    } 
    z();
    y();
    return true;
  }
  
  int G() {
    int i;
    View view;
    if (this.A) {
      view = a(true);
    } else {
      view = b(true);
    } 
    if (view == null) {
      i = -1;
    } else {
      i = l(view);
    } 
    return i;
  }
  
  int H() {
    int j = e();
    int i = 0;
    if (j != 0)
      i = l(c(0)); 
    return i;
  }
  
  int I() {
    int i = e();
    if (i == 0) {
      i = 0;
    } else {
      i = l(c(i - 1));
    } 
    return i;
  }
  
  View J() {
    int k;
    int i = e() - 1;
    BitSet bitSet = new BitSet(this.s);
    bitSet.set(0, this.s, true);
    int j = this.w;
    byte b1 = -1;
    if (j == 1 && L()) {
      j = 1;
    } else {
      j = -1;
    } 
    if (this.A) {
      k = 0 - 1;
    } else {
      boolean bool = false;
      k = i + 1;
      i = bool;
    } 
    if (i < k)
      b1 = 1; 
    int m;
    for (m = i; m != k; m += b1) {
      View view = c(m);
      c c = (c)view.getLayoutParams();
      if (bitSet.get(c.e.e)) {
        if (a(c.e))
          return view; 
        bitSet.clear(c.e.e);
      } 
      if (!c.f && m + b1 != k) {
        View view1 = c(m + b1);
        i = 0;
        int n = 0;
        if (this.A) {
          int i2 = this.u.a(view);
          int i1 = this.u.a(view1);
          if (i2 < i1)
            return view; 
          i = n;
          if (i2 == i1)
            i = 1; 
        } else {
          int i1 = this.u.d(view);
          n = this.u.d(view1);
          if (i1 > n)
            return view; 
          if (i1 == n)
            i = 1; 
        } 
        if (i != 0) {
          c c1 = (c)view1.getLayoutParams();
          if (c.e.e - c1.e.e < 0) {
            i = 1;
          } else {
            i = 0;
          } 
          if (j < 0) {
            n = 1;
          } else {
            n = 0;
          } 
          if (i != n)
            return view; 
        } 
      } 
    } 
    return null;
  }
  
  public void K() {
    this.E.a();
    y();
  }
  
  boolean L() {
    int i = j();
    boolean bool = true;
    if (i != 1)
      bool = false; 
    return bool;
  }
  
  public int a(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return c(paramInt, paramv, parama0);
  }
  
  public int a(RecyclerView.a0 parama0) {
    return h(parama0);
  }
  
  public int a(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return (this.w == 1) ? this.s : super.a(paramv, parama0);
  }
  
  public RecyclerView.p a(Context paramContext, AttributeSet paramAttributeSet) {
    return new c(paramContext, paramAttributeSet);
  }
  
  public RecyclerView.p a(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new c((ViewGroup.MarginLayoutParams)paramLayoutParams) : new c(paramLayoutParams);
  }
  
  public View a(View paramView, int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    int i;
    if (e() == 0)
      return null; 
    paramView = c(paramView);
    if (paramView == null)
      return null; 
    O();
    int k = m(paramInt);
    if (k == Integer.MIN_VALUE)
      return null; 
    c c = (c)paramView.getLayoutParams();
    boolean bool1 = c.f;
    f f1 = c.e;
    if (k == 1) {
      paramInt = I();
    } else {
      paramInt = H();
    } 
    b(paramInt, parama0);
    w(k);
    n0 n01 = this.y;
    n01.c = n01.d + paramInt;
    n01.b = (int)(this.u.g() * 0.33333334F);
    n01 = this.y;
    n01.h = true;
    int j = 0;
    n01.a = false;
    a(paramv, n01, parama0);
    this.G = this.A;
    if (!bool1) {
      View view = f1.a(paramInt, k);
      if (view != null && view != paramView)
        return view; 
    } 
    if (v(k)) {
      for (i = this.s - 1; i >= 0; i--) {
        View view = this.t[i].a(paramInt, k);
        if (view != null && view != paramView)
          return view; 
      } 
    } else {
      for (i = 0; i < this.s; i++) {
        View view = this.t[i].a(paramInt, k);
        if (view != null && view != paramView)
          return view; 
      } 
    } 
    boolean bool2 = this.z;
    if (k == -1) {
      i = 1;
    } else {
      i = 0;
    } 
    paramInt = j;
    if ((bool2 ^ true) == i)
      paramInt = 1; 
    if (!bool1) {
      if (paramInt != 0) {
        i = f1.d();
      } else {
        i = f1.e();
      } 
      View view = b(i);
      if (view != null && view != paramView)
        return view; 
    } 
    if (v(k)) {
      for (i = this.s - 1; i >= 0; i--) {
        if (i != f1.e) {
          if (paramInt != 0) {
            j = this.t[i].d();
          } else {
            j = this.t[i].e();
          } 
          View view = b(j);
          if (view != null && view != paramView)
            return view; 
        } 
      } 
    } else {
      for (i = 0; i < this.s; i++) {
        if (paramInt != 0) {
          j = this.t[i].d();
        } else {
          j = this.t[i].e();
        } 
        View view = b(j);
        if (view != null && view != paramView)
          return view; 
      } 
    } 
    return null;
  }
  
  View a(boolean paramBoolean) {
    int j = this.u.f();
    int k = this.u.b();
    View view = null;
    int i = e() - 1;
    while (i >= 0) {
      View view2 = c(i);
      int m = this.u.d(view2);
      int n = this.u.a(view2);
      View view1 = view;
      if (n > j)
        if (m >= k) {
          view1 = view;
        } else {
          if (n <= k || !paramBoolean)
            return view2; 
          view1 = view;
          if (view == null)
            view1 = view2; 
        }  
      i--;
      view = view1;
    } 
    return view;
  }
  
  public void a(int paramInt1, int paramInt2, RecyclerView.a0 parama0, RecyclerView.o.c paramc) {
    if (this.w == 0)
      paramInt2 = paramInt1; 
    if (e() == 0 || paramInt2 == 0)
      return; 
    a(paramInt2, parama0);
    int[] arrayOfInt = this.O;
    if (arrayOfInt == null || arrayOfInt.length < this.s)
      this.O = new int[this.s]; 
    paramInt1 = 0;
    paramInt2 = 0;
    while (paramInt2 < this.s) {
      int j;
      n0 n01 = this.y;
      if (n01.d == -1) {
        int k = n01.f;
        j = k - this.t[paramInt2].b(k);
      } else {
        j = this.t[paramInt2].a(n01.g) - this.y.g;
      } 
      int i = paramInt1;
      if (j >= 0) {
        this.O[paramInt1] = j;
        i = paramInt1 + 1;
      } 
      paramInt2++;
      paramInt1 = i;
    } 
    Arrays.sort(this.O, 0, paramInt1);
    for (paramInt2 = 0; paramInt2 < paramInt1 && this.y.a(parama0); paramInt2++) {
      paramc.a(this.y.c, this.O[paramInt2]);
      n0 n01 = this.y;
      n01.c += n01.d;
    } 
  }
  
  void a(int paramInt, RecyclerView.a0 parama0) {
    int i;
    byte b1;
    if (paramInt > 0) {
      b1 = 1;
      i = I();
    } else {
      b1 = -1;
      i = H();
    } 
    this.y.a = true;
    b(i, parama0);
    w(b1);
    n0 n01 = this.y;
    n01.c = n01.d + i;
    n01.b = Math.abs(paramInt);
  }
  
  public void a(Rect paramRect, int paramInt1, int paramInt2) {
    int j = n() + o();
    int i = p() + m();
    if (this.w == 1) {
      i = RecyclerView.o.a(paramInt2, paramRect.height() + i, k());
      paramInt2 = RecyclerView.o.a(paramInt1, this.x * this.s + j, l());
      paramInt1 = i;
    } else {
      paramInt1 = RecyclerView.o.a(paramInt1, paramRect.width() + j, l());
      i = RecyclerView.o.a(paramInt2, this.x * this.s + i, k());
      paramInt2 = paramInt1;
      paramInt1 = i;
    } 
    c(paramInt2, paramInt1);
  }
  
  public void a(Parcelable paramParcelable) {
    if (paramParcelable instanceof e) {
      this.I = (e)paramParcelable;
      y();
    } 
  }
  
  public void a(RecyclerView.v paramv, RecyclerView.a0 parama0, View paramView, android.support.v4.view.d0.c paramc) {
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (!(layoutParams instanceof c)) {
      a(paramView, paramc);
      return;
    } 
    c c1 = (c)layoutParams;
    if (this.w == 0) {
      boolean bool;
      int i = c1.e();
      if (c1.f) {
        bool = this.s;
      } else {
        bool = true;
      } 
      paramc.b(android.support.v4.view.d0.c.c.a(i, bool, -1, -1, c1.f, false));
    } else {
      boolean bool;
      int i = c1.e();
      if (c1.f) {
        bool = this.s;
      } else {
        bool = true;
      } 
      paramc.b(android.support.v4.view.d0.c.c.a(-1, -1, i, bool, c1.f, false));
    } 
  }
  
  public void a(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    b(paramInt1, paramInt2, 1);
  }
  
  public void a(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, int paramInt3) {
    b(paramInt1, paramInt2, 8);
  }
  
  public void a(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, Object paramObject) {
    b(paramInt1, paramInt2, 4);
  }
  
  public void a(AccessibilityEvent paramAccessibilityEvent) {
    super.a(paramAccessibilityEvent);
    if (e() > 0) {
      View view2 = b(false);
      View view1 = a(false);
      if (view2 == null || view1 == null)
        return; 
      int i = l(view2);
      int j = l(view1);
      if (i < j) {
        paramAccessibilityEvent.setFromIndex(i);
        paramAccessibilityEvent.setToIndex(j);
      } else {
        paramAccessibilityEvent.setFromIndex(j);
        paramAccessibilityEvent.setToIndex(i);
      } 
    } 
  }
  
  public void a(String paramString) {
    if (this.I == null)
      super.a(paramString); 
  }
  
  public boolean a() {
    boolean bool;
    if (this.w == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  boolean a(RecyclerView.a0 parama0, b paramb) {
    boolean bool1 = parama0.d();
    boolean bool = false;
    if (!bool1) {
      int i = this.C;
      if (i == -1)
        return false; 
      if (i < 0 || i >= parama0.a()) {
        this.C = -1;
        this.D = Integer.MIN_VALUE;
        return false;
      } 
      e e1 = this.I;
      if (e1 == null || e1.c == -1 || e1.e < 1) {
        View view = b(this.C);
        if (view != null) {
          if (this.A) {
            i = I();
          } else {
            i = H();
          } 
          paramb.a = i;
          if (this.D != Integer.MIN_VALUE) {
            if (paramb.c) {
              paramb.b = this.u.b() - this.D - this.u.a(view);
            } else {
              paramb.b = this.u.f() + this.D - this.u.d(view);
            } 
            return true;
          } 
          if (this.u.b(view) > this.u.g()) {
            if (paramb.c) {
              i = this.u.b();
            } else {
              i = this.u.f();
            } 
            paramb.b = i;
            return true;
          } 
          i = this.u.d(view) - this.u.f();
          if (i < 0) {
            paramb.b = -i;
            return true;
          } 
          i = this.u.b() - this.u.a(view);
          if (i < 0) {
            paramb.b = i;
            return true;
          } 
          paramb.b = Integer.MIN_VALUE;
        } else {
          paramb.a = this.C;
          i = this.D;
          if (i == Integer.MIN_VALUE) {
            if (l(paramb.a) == 1)
              bool = true; 
            paramb.c = bool;
            paramb.a();
          } else {
            paramb.a(i);
          } 
          paramb.d = true;
        } 
        return true;
      } 
      paramb.b = Integer.MIN_VALUE;
      paramb.a = this.C;
      return true;
    } 
    return false;
  }
  
  public boolean a(RecyclerView.p paramp) {
    return paramp instanceof c;
  }
  
  public int b(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return c(paramInt, paramv, parama0);
  }
  
  public int b(RecyclerView.a0 parama0) {
    return i(parama0);
  }
  
  public int b(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return (this.w == 0) ? this.s : super.b(paramv, parama0);
  }
  
  View b(boolean paramBoolean) {
    int k = this.u.f();
    int i = this.u.b();
    int j = e();
    View view = null;
    byte b1 = 0;
    while (b1 < j) {
      View view2 = c(b1);
      int m = this.u.d(view2);
      View view1 = view;
      if (this.u.a(view2) > k)
        if (m >= i) {
          view1 = view;
        } else {
          if (m >= k || !paramBoolean)
            return view2; 
          view1 = view;
          if (view == null)
            view1 = view2; 
        }  
      b1++;
      view = view1;
    } 
    return view;
  }
  
  void b(RecyclerView.a0 parama0, b paramb) {
    if (a(parama0, paramb))
      return; 
    if (c(parama0, paramb))
      return; 
    paramb.a();
    paramb.a = 0;
  }
  
  public void b(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    b(paramInt1, paramInt2, 2);
  }
  
  public void b(RecyclerView paramRecyclerView, RecyclerView.v paramv) {
    super.b(paramRecyclerView, paramv);
    a(this.P);
    for (byte b1 = 0; b1 < this.s; b1++)
      this.t[b1].c(); 
    paramRecyclerView.requestLayout();
  }
  
  public boolean b() {
    int i = this.w;
    boolean bool = true;
    if (i != 1)
      bool = false; 
    return bool;
  }
  
  int c(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    if (e() == 0 || paramInt == 0)
      return 0; 
    a(paramInt, parama0);
    int i = a(paramv, this.y, parama0);
    if (this.y.b >= i)
      if (paramInt < 0) {
        paramInt = -i;
      } else {
        paramInt = i;
      }  
    this.u.a(-paramInt);
    this.G = this.A;
    n0 n01 = this.y;
    n01.b = 0;
    a(paramv, n01);
    return paramInt;
  }
  
  public int c(RecyclerView.a0 parama0) {
    return j(parama0);
  }
  
  public RecyclerView.p c() {
    return (this.w == 0) ? new c(-2, -1) : new c(-1, -2);
  }
  
  public void c(boolean paramBoolean) {
    a((String)null);
    e e1 = this.I;
    if (e1 != null && e1.j != paramBoolean)
      e1.j = paramBoolean; 
    this.z = paramBoolean;
    y();
  }
  
  public int d(RecyclerView.a0 parama0) {
    return h(parama0);
  }
  
  public void d(int paramInt) {
    super.d(paramInt);
    for (byte b1 = 0; b1 < this.s; b1++)
      this.t[b1].c(paramInt); 
  }
  
  public void d(RecyclerView paramRecyclerView) {
    this.E.a();
    y();
  }
  
  public int e(RecyclerView.a0 parama0) {
    return i(parama0);
  }
  
  public void e(int paramInt) {
    super.e(paramInt);
    for (byte b1 = 0; b1 < this.s; b1++)
      this.t[b1].c(paramInt); 
  }
  
  public void e(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    c(paramv, parama0, true);
  }
  
  public int f(RecyclerView.a0 parama0) {
    return j(parama0);
  }
  
  public void f(int paramInt) {
    if (paramInt == 0)
      F(); 
  }
  
  public void g(RecyclerView.a0 parama0) {
    super.g(parama0);
    this.C = -1;
    this.D = Integer.MIN_VALUE;
    this.I = null;
    this.L.b();
  }
  
  public void h(int paramInt) {
    e e1 = this.I;
    if (e1 != null && e1.c != paramInt)
      e1.a(); 
    this.C = paramInt;
    this.D = Integer.MIN_VALUE;
    y();
  }
  
  public void i(int paramInt) {
    if (paramInt == 0 || paramInt == 1) {
      a((String)null);
      if (paramInt == this.w)
        return; 
      this.w = paramInt;
      t0 t01 = this.u;
      this.u = this.v;
      this.v = t01;
      y();
      return;
    } 
    throw new IllegalArgumentException("invalid orientation.");
  }
  
  public void j(int paramInt) {
    a((String)null);
    if (paramInt != this.s) {
      K();
      this.s = paramInt;
      this.B = new BitSet(this.s);
      this.t = new f[this.s];
      for (paramInt = 0; paramInt < this.s; paramInt++)
        this.t[paramInt] = new f(this, paramInt); 
      y();
    } 
  }
  
  void k(int paramInt) {
    this.x = paramInt / this.s;
    this.J = View.MeasureSpec.makeMeasureSpec(paramInt, this.v.d());
  }
  
  public boolean u() {
    boolean bool;
    if (this.F != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public Parcelable x() {
    // Byte code:
    //   0: aload_0
    //   1: getfield I : Landroid/support/v7/widget/StaggeredGridLayoutManager$e;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnull -> 21
    //   11: new android/support/v7/widget/StaggeredGridLayoutManager$e
    //   14: dup
    //   15: aload #4
    //   17: invokespecial <init> : (Landroid/support/v7/widget/StaggeredGridLayoutManager$e;)V
    //   20: areturn
    //   21: new android/support/v7/widget/StaggeredGridLayoutManager$e
    //   24: dup
    //   25: invokespecial <init> : ()V
    //   28: astore #6
    //   30: aload #6
    //   32: aload_0
    //   33: getfield z : Z
    //   36: putfield j : Z
    //   39: aload #6
    //   41: aload_0
    //   42: getfield G : Z
    //   45: putfield k : Z
    //   48: aload #6
    //   50: aload_0
    //   51: getfield H : Z
    //   54: putfield l : Z
    //   57: aload_0
    //   58: getfield E : Landroid/support/v7/widget/StaggeredGridLayoutManager$d;
    //   61: astore #4
    //   63: aload #4
    //   65: ifnull -> 111
    //   68: aload #4
    //   70: getfield a : [I
    //   73: astore #5
    //   75: aload #5
    //   77: ifnull -> 111
    //   80: aload #6
    //   82: aload #5
    //   84: putfield h : [I
    //   87: aload #6
    //   89: aload #6
    //   91: getfield h : [I
    //   94: arraylength
    //   95: putfield g : I
    //   98: aload #6
    //   100: aload #4
    //   102: getfield b : Ljava/util/List;
    //   105: putfield i : Ljava/util/List;
    //   108: goto -> 117
    //   111: aload #6
    //   113: iconst_0
    //   114: putfield g : I
    //   117: aload_0
    //   118: invokevirtual e : ()I
    //   121: ifle -> 275
    //   124: aload_0
    //   125: getfield G : Z
    //   128: ifeq -> 139
    //   131: aload_0
    //   132: invokevirtual I : ()I
    //   135: istore_1
    //   136: goto -> 144
    //   139: aload_0
    //   140: invokevirtual H : ()I
    //   143: istore_1
    //   144: aload #6
    //   146: iload_1
    //   147: putfield c : I
    //   150: aload #6
    //   152: aload_0
    //   153: invokevirtual G : ()I
    //   156: putfield d : I
    //   159: aload_0
    //   160: getfield s : I
    //   163: istore_1
    //   164: aload #6
    //   166: iload_1
    //   167: putfield e : I
    //   170: aload #6
    //   172: iload_1
    //   173: newarray int
    //   175: putfield f : [I
    //   178: iconst_0
    //   179: istore_2
    //   180: iload_2
    //   181: aload_0
    //   182: getfield s : I
    //   185: if_icmpge -> 272
    //   188: aload_0
    //   189: getfield G : Z
    //   192: ifeq -> 228
    //   195: aload_0
    //   196: getfield t : [Landroid/support/v7/widget/StaggeredGridLayoutManager$f;
    //   199: iload_2
    //   200: aaload
    //   201: ldc -2147483648
    //   203: invokevirtual a : (I)I
    //   206: istore_3
    //   207: iload_3
    //   208: istore_1
    //   209: iload_3
    //   210: ldc -2147483648
    //   212: if_icmpeq -> 258
    //   215: iload_3
    //   216: aload_0
    //   217: getfield u : Landroid/support/v7/widget/t0;
    //   220: invokevirtual b : ()I
    //   223: isub
    //   224: istore_1
    //   225: goto -> 258
    //   228: aload_0
    //   229: getfield t : [Landroid/support/v7/widget/StaggeredGridLayoutManager$f;
    //   232: iload_2
    //   233: aaload
    //   234: ldc -2147483648
    //   236: invokevirtual b : (I)I
    //   239: istore_3
    //   240: iload_3
    //   241: istore_1
    //   242: iload_3
    //   243: ldc -2147483648
    //   245: if_icmpeq -> 258
    //   248: iload_3
    //   249: aload_0
    //   250: getfield u : Landroid/support/v7/widget/t0;
    //   253: invokevirtual f : ()I
    //   256: isub
    //   257: istore_1
    //   258: aload #6
    //   260: getfield f : [I
    //   263: iload_2
    //   264: iload_1
    //   265: iastore
    //   266: iinc #2, 1
    //   269: goto -> 180
    //   272: goto -> 293
    //   275: aload #6
    //   277: iconst_m1
    //   278: putfield c : I
    //   281: aload #6
    //   283: iconst_m1
    //   284: putfield d : I
    //   287: aload #6
    //   289: iconst_0
    //   290: putfield e : I
    //   293: aload #6
    //   295: areturn
  }
  
  class a implements Runnable {
    final StaggeredGridLayoutManager c;
    
    a(StaggeredGridLayoutManager this$0) {}
    
    public void run() {
      this.c.F();
    }
  }
  
  class b {
    int a;
    
    int b;
    
    boolean c;
    
    boolean d;
    
    boolean e;
    
    int[] f;
    
    final StaggeredGridLayoutManager g;
    
    b(StaggeredGridLayoutManager this$0) {
      b();
    }
    
    void a() {
      int i;
      if (this.c) {
        i = this.g.u.b();
      } else {
        i = this.g.u.f();
      } 
      this.b = i;
    }
    
    void a(int param1Int) {
      if (this.c) {
        this.b = this.g.u.b() - param1Int;
      } else {
        this.b = this.g.u.f() + param1Int;
      } 
    }
    
    void a(StaggeredGridLayoutManager.f[] param1ArrayOff) {
      int i = param1ArrayOff.length;
      int[] arrayOfInt = this.f;
      if (arrayOfInt == null || arrayOfInt.length < i)
        this.f = new int[this.g.t.length]; 
      for (byte b1 = 0; b1 < i; b1++)
        this.f[b1] = param1ArrayOff[b1].b(-2147483648); 
    }
    
    void b() {
      this.a = -1;
      this.b = Integer.MIN_VALUE;
      this.c = false;
      this.d = false;
      this.e = false;
      int[] arrayOfInt = this.f;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
    }
  }
  
  public static class c extends RecyclerView.p {
    StaggeredGridLayoutManager.f e;
    
    boolean f;
    
    public c(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public c(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public c(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public c(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public final int e() {
      StaggeredGridLayoutManager.f f1 = this.e;
      return (f1 == null) ? -1 : f1.e;
    }
    
    public boolean f() {
      return this.f;
    }
  }
  
  static class d {
    int[] a;
    
    List<a> b;
    
    private void c(int param1Int1, int param1Int2) {
      List<a> list = this.b;
      if (list == null)
        return; 
      for (int i = list.size() - 1; i >= 0; i--) {
        a a = this.b.get(i);
        int j = a.c;
        if (j >= param1Int1)
          a.c = j + param1Int2; 
      } 
    }
    
    private void d(int param1Int1, int param1Int2) {
      List<a> list = this.b;
      if (list == null)
        return; 
      for (int i = list.size() - 1; i >= 0; i--) {
        a a = this.b.get(i);
        int j = a.c;
        if (j >= param1Int1)
          if (j < param1Int1 + param1Int2) {
            this.b.remove(i);
          } else {
            a.c = j - param1Int2;
          }  
      } 
    }
    
    private int g(int param1Int) {
      byte b1;
      if (this.b == null)
        return -1; 
      a a = c(param1Int);
      if (a != null)
        this.b.remove(a); 
      byte b2 = -1;
      int i = this.b.size();
      byte b = 0;
      while (true) {
        b1 = b2;
        if (b < i) {
          if (((a)this.b.get(b)).c >= param1Int) {
            b1 = b;
            break;
          } 
          b++;
          continue;
        } 
        break;
      } 
      if (b1 != -1) {
        a = this.b.get(b1);
        this.b.remove(b1);
        return a.c;
      } 
      return -1;
    }
    
    public a a(int param1Int1, int param1Int2, int param1Int3, boolean param1Boolean) {
      List<a> list = this.b;
      if (list == null)
        return null; 
      int i = list.size();
      for (byte b = 0; b < i; b++) {
        a a = this.b.get(b);
        int j = a.c;
        if (j >= param1Int2)
          return null; 
        if (j >= param1Int1 && (param1Int3 == 0 || a.d == param1Int3 || (param1Boolean && a.f)))
          return a; 
      } 
      return null;
    }
    
    void a() {
      int[] arrayOfInt = this.a;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
      this.b = null;
    }
    
    void a(int param1Int) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt == null) {
        this.a = new int[Math.max(param1Int, 10) + 1];
        Arrays.fill(this.a, -1);
      } else if (param1Int >= arrayOfInt.length) {
        int[] arrayOfInt1 = this.a;
        this.a = new int[f(param1Int)];
        System.arraycopy(arrayOfInt1, 0, this.a, 0, arrayOfInt1.length);
        arrayOfInt = this.a;
        Arrays.fill(arrayOfInt, arrayOfInt1.length, arrayOfInt.length, -1);
      } 
    }
    
    void a(int param1Int1, int param1Int2) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt == null || param1Int1 >= arrayOfInt.length)
        return; 
      a(param1Int1 + param1Int2);
      arrayOfInt = this.a;
      System.arraycopy(arrayOfInt, param1Int1, arrayOfInt, param1Int1 + param1Int2, arrayOfInt.length - param1Int1 - param1Int2);
      Arrays.fill(this.a, param1Int1, param1Int1 + param1Int2, -1);
      c(param1Int1, param1Int2);
    }
    
    void a(int param1Int, StaggeredGridLayoutManager.f param1f) {
      a(param1Int);
      this.a[param1Int] = param1f.e;
    }
    
    public void a(a param1a) {
      if (this.b == null)
        this.b = new ArrayList<a>(); 
      int i = this.b.size();
      for (byte b = 0; b < i; b++) {
        a a1 = this.b.get(b);
        if (a1.c == param1a.c)
          this.b.remove(b); 
        if (a1.c >= param1a.c) {
          this.b.add(b, param1a);
          return;
        } 
      } 
      this.b.add(param1a);
    }
    
    int b(int param1Int) {
      List<a> list = this.b;
      if (list != null)
        for (int i = list.size() - 1; i >= 0; i--) {
          if (((a)this.b.get(i)).c >= param1Int)
            this.b.remove(i); 
        }  
      return e(param1Int);
    }
    
    void b(int param1Int1, int param1Int2) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt == null || param1Int1 >= arrayOfInt.length)
        return; 
      a(param1Int1 + param1Int2);
      arrayOfInt = this.a;
      System.arraycopy(arrayOfInt, param1Int1 + param1Int2, arrayOfInt, param1Int1, arrayOfInt.length - param1Int1 - param1Int2);
      arrayOfInt = this.a;
      Arrays.fill(arrayOfInt, arrayOfInt.length - param1Int2, arrayOfInt.length, -1);
      d(param1Int1, param1Int2);
    }
    
    public a c(int param1Int) {
      List<a> list = this.b;
      if (list == null)
        return null; 
      for (int i = list.size() - 1; i >= 0; i--) {
        a a = this.b.get(i);
        if (a.c == param1Int)
          return a; 
      } 
      return null;
    }
    
    int d(int param1Int) {
      int[] arrayOfInt = this.a;
      return (arrayOfInt == null || param1Int >= arrayOfInt.length) ? -1 : arrayOfInt[param1Int];
    }
    
    int e(int param1Int) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt == null)
        return -1; 
      if (param1Int >= arrayOfInt.length)
        return -1; 
      int i = g(param1Int);
      if (i == -1) {
        arrayOfInt = this.a;
        Arrays.fill(arrayOfInt, param1Int, arrayOfInt.length, -1);
        return this.a.length;
      } 
      Arrays.fill(this.a, param1Int, i + 1, -1);
      return i + 1;
    }
    
    int f(int param1Int) {
      int i;
      for (i = this.a.length; i <= param1Int; i *= 2);
      return i;
    }
    
    static class a implements Parcelable {
      public static final Parcelable.Creator<a> CREATOR = new a();
      
      int c;
      
      int d;
      
      int[] e;
      
      boolean f;
      
      a() {}
      
      a(Parcel param2Parcel) {
        this.c = param2Parcel.readInt();
        this.d = param2Parcel.readInt();
        int i = param2Parcel.readInt();
        boolean bool = true;
        if (i != 1)
          bool = false; 
        this.f = bool;
        i = param2Parcel.readInt();
        if (i > 0) {
          this.e = new int[i];
          param2Parcel.readIntArray(this.e);
        } 
      }
      
      int a(int param2Int) {
        int[] arrayOfInt = this.e;
        if (arrayOfInt == null) {
          param2Int = 0;
        } else {
          param2Int = arrayOfInt[param2Int];
        } 
        return param2Int;
      }
      
      public int describeContents() {
        return 0;
      }
      
      public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FullSpanItem{mPosition=");
        stringBuilder.append(this.c);
        stringBuilder.append(", mGapDir=");
        stringBuilder.append(this.d);
        stringBuilder.append(", mHasUnwantedGapAfter=");
        stringBuilder.append(this.f);
        stringBuilder.append(", mGapPerSpan=");
        stringBuilder.append(Arrays.toString(this.e));
        stringBuilder.append('}');
        return stringBuilder.toString();
      }
      
      public void writeToParcel(Parcel param2Parcel, int param2Int) {
        param2Parcel.writeInt(this.c);
        param2Parcel.writeInt(this.d);
        param2Parcel.writeInt(this.f);
        int[] arrayOfInt = this.e;
        if (arrayOfInt != null && arrayOfInt.length > 0) {
          param2Parcel.writeInt(arrayOfInt.length);
          param2Parcel.writeIntArray(this.e);
        } else {
          param2Parcel.writeInt(0);
        } 
      }
      
      static final class a implements Parcelable.Creator<a> {
        public StaggeredGridLayoutManager.d.a createFromParcel(Parcel param3Parcel) {
          return new StaggeredGridLayoutManager.d.a(param3Parcel);
        }
        
        public StaggeredGridLayoutManager.d.a[] newArray(int param3Int) {
          return new StaggeredGridLayoutManager.d.a[param3Int];
        }
      }
    }
    
    static final class a implements Parcelable.Creator<a> {
      public StaggeredGridLayoutManager.d.a createFromParcel(Parcel param2Parcel) {
        return new StaggeredGridLayoutManager.d.a(param2Parcel);
      }
      
      public StaggeredGridLayoutManager.d.a[] newArray(int param2Int) {
        return new StaggeredGridLayoutManager.d.a[param2Int];
      }
    }
  }
  
  static class a implements Parcelable {
    public static final Parcelable.Creator<a> CREATOR = new a();
    
    int c;
    
    int d;
    
    int[] e;
    
    boolean f;
    
    a() {}
    
    a(Parcel param1Parcel) {
      this.c = param1Parcel.readInt();
      this.d = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      this.f = bool;
      i = param1Parcel.readInt();
      if (i > 0) {
        this.e = new int[i];
        param1Parcel.readIntArray(this.e);
      } 
    }
    
    int a(int param1Int) {
      int[] arrayOfInt = this.e;
      if (arrayOfInt == null) {
        param1Int = 0;
      } else {
        param1Int = arrayOfInt[param1Int];
      } 
      return param1Int;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("FullSpanItem{mPosition=");
      stringBuilder.append(this.c);
      stringBuilder.append(", mGapDir=");
      stringBuilder.append(this.d);
      stringBuilder.append(", mHasUnwantedGapAfter=");
      stringBuilder.append(this.f);
      stringBuilder.append(", mGapPerSpan=");
      stringBuilder.append(Arrays.toString(this.e));
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeInt(this.c);
      param1Parcel.writeInt(this.d);
      param1Parcel.writeInt(this.f);
      int[] arrayOfInt = this.e;
      if (arrayOfInt != null && arrayOfInt.length > 0) {
        param1Parcel.writeInt(arrayOfInt.length);
        param1Parcel.writeIntArray(this.e);
      } else {
        param1Parcel.writeInt(0);
      } 
    }
    
    static final class a implements Parcelable.Creator<a> {
      public StaggeredGridLayoutManager.d.a createFromParcel(Parcel param3Parcel) {
        return new StaggeredGridLayoutManager.d.a(param3Parcel);
      }
      
      public StaggeredGridLayoutManager.d.a[] newArray(int param3Int) {
        return new StaggeredGridLayoutManager.d.a[param3Int];
      }
    }
  }
  
  static final class a implements Parcelable.Creator<d.a> {
    public StaggeredGridLayoutManager.d.a createFromParcel(Parcel param1Parcel) {
      return new StaggeredGridLayoutManager.d.a(param1Parcel);
    }
    
    public StaggeredGridLayoutManager.d.a[] newArray(int param1Int) {
      return new StaggeredGridLayoutManager.d.a[param1Int];
    }
  }
  
  public static class e implements Parcelable {
    public static final Parcelable.Creator<e> CREATOR = new a();
    
    int c;
    
    int d;
    
    int e;
    
    int[] f;
    
    int g;
    
    int[] h;
    
    List<StaggeredGridLayoutManager.d.a> i;
    
    boolean j;
    
    boolean k;
    
    boolean l;
    
    public e() {}
    
    e(Parcel param1Parcel) {
      this.c = param1Parcel.readInt();
      this.d = param1Parcel.readInt();
      this.e = param1Parcel.readInt();
      int i = this.e;
      if (i > 0) {
        this.f = new int[i];
        param1Parcel.readIntArray(this.f);
      } 
      this.g = param1Parcel.readInt();
      i = this.g;
      if (i > 0) {
        this.h = new int[i];
        param1Parcel.readIntArray(this.h);
      } 
      i = param1Parcel.readInt();
      boolean bool2 = false;
      if (i == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.j = bool1;
      if (param1Parcel.readInt() == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.k = bool1;
      boolean bool1 = bool2;
      if (param1Parcel.readInt() == 1)
        bool1 = true; 
      this.l = bool1;
      this.i = param1Parcel.readArrayList(StaggeredGridLayoutManager.d.a.class.getClassLoader());
    }
    
    public e(e param1e) {
      this.e = param1e.e;
      this.c = param1e.c;
      this.d = param1e.d;
      this.f = param1e.f;
      this.g = param1e.g;
      this.h = param1e.h;
      this.j = param1e.j;
      this.k = param1e.k;
      this.l = param1e.l;
      this.i = param1e.i;
    }
    
    void a() {
      this.f = null;
      this.e = 0;
      this.c = -1;
      this.d = -1;
    }
    
    void b() {
      this.f = null;
      this.e = 0;
      this.g = 0;
      this.h = null;
      this.i = null;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeInt(this.c);
      param1Parcel.writeInt(this.d);
      param1Parcel.writeInt(this.e);
      if (this.e > 0)
        param1Parcel.writeIntArray(this.f); 
      param1Parcel.writeInt(this.g);
      if (this.g > 0)
        param1Parcel.writeIntArray(this.h); 
      param1Parcel.writeInt(this.j);
      param1Parcel.writeInt(this.k);
      param1Parcel.writeInt(this.l);
      param1Parcel.writeList(this.i);
    }
    
    static final class a implements Parcelable.Creator<e> {
      public StaggeredGridLayoutManager.e createFromParcel(Parcel param2Parcel) {
        return new StaggeredGridLayoutManager.e(param2Parcel);
      }
      
      public StaggeredGridLayoutManager.e[] newArray(int param2Int) {
        return new StaggeredGridLayoutManager.e[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.Creator<e> {
    public StaggeredGridLayoutManager.e createFromParcel(Parcel param1Parcel) {
      return new StaggeredGridLayoutManager.e(param1Parcel);
    }
    
    public StaggeredGridLayoutManager.e[] newArray(int param1Int) {
      return new StaggeredGridLayoutManager.e[param1Int];
    }
  }
  
  class f {
    ArrayList<View> a = new ArrayList<View>();
    
    int b = Integer.MIN_VALUE;
    
    int c = Integer.MIN_VALUE;
    
    int d = 0;
    
    final int e;
    
    final StaggeredGridLayoutManager f;
    
    f(StaggeredGridLayoutManager this$0, int param1Int) {
      this.e = param1Int;
    }
    
    int a(int param1Int) {
      int i = this.c;
      if (i != Integer.MIN_VALUE)
        return i; 
      if (this.a.size() == 0)
        return param1Int; 
      a();
      return this.c;
    }
    
    int a(int param1Int1, int param1Int2, boolean param1Boolean) {
      return a(param1Int1, param1Int2, false, false, param1Boolean);
    }
    
    int a(int param1Int1, int param1Int2, boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3) {
      byte b;
      int j = this.f.u.f();
      int i = this.f.u.b();
      if (param1Int2 > param1Int1) {
        b = 1;
      } else {
        b = -1;
      } 
      while (param1Int1 != param1Int2) {
        boolean bool1;
        View view = this.a.get(param1Int1);
        int k = this.f.u.d(view);
        int m = this.f.u.a(view);
        boolean bool2 = false;
        if (param1Boolean3 ? (k <= i) : (k < i)) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (param1Boolean3 ? (m >= j) : (m > j))
          bool2 = true; 
        if (bool1 && bool2)
          if (param1Boolean1 && param1Boolean2) {
            if (k >= j && m <= i)
              return this.f.l(view); 
          } else {
            if (param1Boolean2)
              return this.f.l(view); 
            if (k < j || m > i)
              return this.f.l(view); 
          }  
        param1Int1 += b;
      } 
      return -1;
    }
    
    public View a(int param1Int1, int param1Int2) {
      // Byte code:
      //   0: aconst_null
      //   1: astore #4
      //   3: aconst_null
      //   4: astore #5
      //   6: iload_2
      //   7: iconst_m1
      //   8: if_icmpne -> 121
      //   11: aload_0
      //   12: getfield a : Ljava/util/ArrayList;
      //   15: invokevirtual size : ()I
      //   18: istore_3
      //   19: iconst_0
      //   20: istore_2
      //   21: aload #5
      //   23: astore #4
      //   25: iload_2
      //   26: iload_3
      //   27: if_icmpge -> 114
      //   30: aload_0
      //   31: getfield a : Ljava/util/ArrayList;
      //   34: iload_2
      //   35: invokevirtual get : (I)Ljava/lang/Object;
      //   38: checkcast android/view/View
      //   41: astore #5
      //   43: aload_0
      //   44: getfield f : Landroid/support/v7/widget/StaggeredGridLayoutManager;
      //   47: astore #6
      //   49: aload #6
      //   51: getfield z : Z
      //   54: ifeq -> 68
      //   57: aload #6
      //   59: aload #5
      //   61: invokevirtual l : (Landroid/view/View;)I
      //   64: iload_1
      //   65: if_icmple -> 114
      //   68: aload_0
      //   69: getfield f : Landroid/support/v7/widget/StaggeredGridLayoutManager;
      //   72: astore #6
      //   74: aload #6
      //   76: getfield z : Z
      //   79: ifne -> 96
      //   82: aload #6
      //   84: aload #5
      //   86: invokevirtual l : (Landroid/view/View;)I
      //   89: iload_1
      //   90: if_icmplt -> 96
      //   93: goto -> 114
      //   96: aload #5
      //   98: invokevirtual hasFocusable : ()Z
      //   101: ifeq -> 114
      //   104: aload #5
      //   106: astore #4
      //   108: iinc #2, 1
      //   111: goto -> 25
      //   114: aload #4
      //   116: astore #5
      //   118: goto -> 235
      //   121: aload_0
      //   122: getfield a : Ljava/util/ArrayList;
      //   125: invokevirtual size : ()I
      //   128: iconst_1
      //   129: isub
      //   130: istore_2
      //   131: aload #4
      //   133: astore #5
      //   135: iload_2
      //   136: iflt -> 235
      //   139: aload_0
      //   140: getfield a : Ljava/util/ArrayList;
      //   143: iload_2
      //   144: invokevirtual get : (I)Ljava/lang/Object;
      //   147: checkcast android/view/View
      //   150: astore #6
      //   152: aload_0
      //   153: getfield f : Landroid/support/v7/widget/StaggeredGridLayoutManager;
      //   156: astore #7
      //   158: aload #7
      //   160: getfield z : Z
      //   163: ifeq -> 181
      //   166: aload #4
      //   168: astore #5
      //   170: aload #7
      //   172: aload #6
      //   174: invokevirtual l : (Landroid/view/View;)I
      //   177: iload_1
      //   178: if_icmpge -> 235
      //   181: aload_0
      //   182: getfield f : Landroid/support/v7/widget/StaggeredGridLayoutManager;
      //   185: astore #5
      //   187: aload #5
      //   189: getfield z : Z
      //   192: ifne -> 213
      //   195: aload #5
      //   197: aload #6
      //   199: invokevirtual l : (Landroid/view/View;)I
      //   202: iload_1
      //   203: if_icmpgt -> 213
      //   206: aload #4
      //   208: astore #5
      //   210: goto -> 235
      //   213: aload #4
      //   215: astore #5
      //   217: aload #6
      //   219: invokevirtual hasFocusable : ()Z
      //   222: ifeq -> 235
      //   225: aload #6
      //   227: astore #4
      //   229: iinc #2, -1
      //   232: goto -> 131
      //   235: aload #5
      //   237: areturn
    }
    
    void a() {
      ArrayList<View> arrayList = this.a;
      View view = arrayList.get(arrayList.size() - 1);
      StaggeredGridLayoutManager.c c = b(view);
      this.c = this.f.u.a(view);
      if (c.f) {
        StaggeredGridLayoutManager.d.a a = this.f.E.c(c.a());
        if (a != null && a.d == 1)
          this.c += a.a(this.e); 
      } 
    }
    
    void a(View param1View) {
      StaggeredGridLayoutManager.c c = b(param1View);
      c.e = this;
      this.a.add(param1View);
      this.c = Integer.MIN_VALUE;
      if (this.a.size() == 1)
        this.b = Integer.MIN_VALUE; 
      if (c.c() || c.b())
        this.d += this.f.u.b(param1View); 
    }
    
    void a(boolean param1Boolean, int param1Int) {
      int i;
      if (param1Boolean) {
        i = a(-2147483648);
      } else {
        i = b(-2147483648);
      } 
      c();
      if (i == Integer.MIN_VALUE)
        return; 
      if ((param1Boolean && i < this.f.u.b()) || (!param1Boolean && i > this.f.u.f()))
        return; 
      int j = i;
      if (param1Int != Integer.MIN_VALUE)
        j = i + param1Int; 
      this.c = j;
      this.b = j;
    }
    
    int b(int param1Int) {
      int i = this.b;
      if (i != Integer.MIN_VALUE)
        return i; 
      if (this.a.size() == 0)
        return param1Int; 
      b();
      return this.b;
    }
    
    StaggeredGridLayoutManager.c b(View param1View) {
      return (StaggeredGridLayoutManager.c)param1View.getLayoutParams();
    }
    
    void b() {
      View view = this.a.get(0);
      StaggeredGridLayoutManager.c c = b(view);
      this.b = this.f.u.d(view);
      if (c.f) {
        StaggeredGridLayoutManager.d.a a = this.f.E.c(c.a());
        if (a != null && a.d == -1)
          this.b -= a.a(this.e); 
      } 
    }
    
    void c() {
      this.a.clear();
      i();
      this.d = 0;
    }
    
    void c(int param1Int) {
      int i = this.b;
      if (i != Integer.MIN_VALUE)
        this.b = i + param1Int; 
      i = this.c;
      if (i != Integer.MIN_VALUE)
        this.c = i + param1Int; 
    }
    
    void c(View param1View) {
      StaggeredGridLayoutManager.c c = b(param1View);
      c.e = this;
      this.a.add(0, param1View);
      this.b = Integer.MIN_VALUE;
      if (this.a.size() == 1)
        this.c = Integer.MIN_VALUE; 
      if (c.c() || c.b())
        this.d += this.f.u.b(param1View); 
    }
    
    public int d() {
      int i;
      if (this.f.z) {
        i = a(this.a.size() - 1, -1, true);
      } else {
        i = a(0, this.a.size(), true);
      } 
      return i;
    }
    
    void d(int param1Int) {
      this.b = param1Int;
      this.c = param1Int;
    }
    
    public int e() {
      int i;
      if (this.f.z) {
        i = a(0, this.a.size(), true);
      } else {
        i = a(this.a.size() - 1, -1, true);
      } 
      return i;
    }
    
    public int f() {
      return this.d;
    }
    
    int g() {
      int i = this.c;
      if (i != Integer.MIN_VALUE)
        return i; 
      a();
      return this.c;
    }
    
    int h() {
      int i = this.b;
      if (i != Integer.MIN_VALUE)
        return i; 
      b();
      return this.b;
    }
    
    void i() {
      this.b = Integer.MIN_VALUE;
      this.c = Integer.MIN_VALUE;
    }
    
    void j() {
      int i = this.a.size();
      View view = this.a.remove(i - 1);
      StaggeredGridLayoutManager.c c = b(view);
      c.e = null;
      if (c.c() || c.b())
        this.d -= this.f.u.b(view); 
      if (i == 1)
        this.b = Integer.MIN_VALUE; 
      this.c = Integer.MIN_VALUE;
    }
    
    void k() {
      View view = this.a.remove(0);
      StaggeredGridLayoutManager.c c = b(view);
      c.e = null;
      if (this.a.size() == 0)
        this.c = Integer.MIN_VALUE; 
      if (c.c() || c.b())
        this.d -= this.f.u.b(view); 
      this.b = Integer.MIN_VALUE;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\StaggeredGridLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */