package android.support.v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

class a0 implements c0 {
  final RectF a = new RectF();
  
  private y0 a(Context paramContext, ColorStateList paramColorStateList, float paramFloat1, float paramFloat2, float paramFloat3) {
    return new y0(paramContext.getResources(), paramColorStateList, paramFloat1, paramFloat2, paramFloat3);
  }
  
  private y0 j(b0 paramb0) {
    return (y0)paramb0.c();
  }
  
  public float a(b0 paramb0) {
    return j(paramb0).d();
  }
  
  public void a() {
    y0.r = new a(this);
  }
  
  public void a(b0 paramb0, float paramFloat) {
    j(paramb0).a(paramFloat);
    i(paramb0);
  }
  
  public void a(b0 paramb0, Context paramContext, ColorStateList paramColorStateList, float paramFloat1, float paramFloat2, float paramFloat3) {
    y0 y0 = a(paramContext, paramColorStateList, paramFloat1, paramFloat2, paramFloat3);
    y0.a(paramb0.d());
    paramb0.a(y0);
    i(paramb0);
  }
  
  public void a(b0 paramb0, ColorStateList paramColorStateList) {
    j(paramb0).a(paramColorStateList);
  }
  
  public float b(b0 paramb0) {
    return j(paramb0).e();
  }
  
  public void b(b0 paramb0, float paramFloat) {
    j(paramb0).c(paramFloat);
  }
  
  public void c(b0 paramb0) {}
  
  public void c(b0 paramb0, float paramFloat) {
    j(paramb0).b(paramFloat);
    i(paramb0);
  }
  
  public float d(b0 paramb0) {
    return j(paramb0).f();
  }
  
  public ColorStateList e(b0 paramb0) {
    return j(paramb0).a();
  }
  
  public void f(b0 paramb0) {
    j(paramb0).a(paramb0.d());
    i(paramb0);
  }
  
  public float g(b0 paramb0) {
    return j(paramb0).b();
  }
  
  public float h(b0 paramb0) {
    return j(paramb0).c();
  }
  
  public void i(b0 paramb0) {
    Rect rect = new Rect();
    j(paramb0).a(rect);
    paramb0.a((int)Math.ceil(b(paramb0)), (int)Math.ceil(a(paramb0)));
    paramb0.a(rect.left, rect.top, rect.right, rect.bottom);
  }
  
  class a implements y0.a {
    final a0 a;
    
    a(a0 this$0) {}
    
    public void a(Canvas param1Canvas, RectF param1RectF, float param1Float, Paint param1Paint) {
      float f3 = param1Float * 2.0F;
      float f2 = param1RectF.width() - f3 - 1.0F;
      float f1 = param1RectF.height();
      if (param1Float >= 1.0F) {
        float f = param1Float + 0.5F;
        this.a.a.set(-f, -f, f, f);
        int i = param1Canvas.save();
        param1Canvas.translate(param1RectF.left + f, param1RectF.top + f);
        param1Canvas.drawArc(this.a.a, 180.0F, 90.0F, true, param1Paint);
        param1Canvas.translate(f2, 0.0F);
        param1Canvas.rotate(90.0F);
        param1Canvas.drawArc(this.a.a, 180.0F, 90.0F, true, param1Paint);
        param1Canvas.translate(f1 - f3 - 1.0F, 0.0F);
        param1Canvas.rotate(90.0F);
        param1Canvas.drawArc(this.a.a, 180.0F, 90.0F, true, param1Paint);
        param1Canvas.translate(f2, 0.0F);
        param1Canvas.rotate(90.0F);
        param1Canvas.drawArc(this.a.a, 180.0F, 90.0F, true, param1Paint);
        param1Canvas.restoreToCount(i);
        f1 = param1RectF.left;
        f2 = param1RectF.top;
        param1Canvas.drawRect(f1 + f - 1.0F, f2, param1RectF.right - f + 1.0F, f2 + f, param1Paint);
        f1 = param1RectF.left;
        f2 = param1RectF.bottom;
        param1Canvas.drawRect(f1 + f - 1.0F, f2 - f, param1RectF.right - f + 1.0F, f2, param1Paint);
      } 
      param1Canvas.drawRect(param1RectF.left, param1RectF.top + param1Float, param1RectF.right, param1RectF.bottom - param1Float, param1Paint);
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */