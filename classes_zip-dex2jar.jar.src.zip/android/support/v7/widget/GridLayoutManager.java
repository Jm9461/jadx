package android.support.v7.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.Arrays;

public class GridLayoutManager extends LinearLayoutManager {
  boolean H = false;
  
  int I = -1;
  
  int[] J;
  
  View[] K;
  
  final SparseIntArray L = new SparseIntArray();
  
  final SparseIntArray M = new SparseIntArray();
  
  c N = new a();
  
  final Rect O = new Rect();
  
  public GridLayoutManager(Context paramContext, int paramInt) {
    super(paramContext);
    k(paramInt);
  }
  
  public GridLayoutManager(Context paramContext, int paramInt1, int paramInt2, boolean paramBoolean) {
    super(paramContext, paramInt2, paramBoolean);
    k(paramInt1);
  }
  
  public GridLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    k((RecyclerView.o.a(paramContext, paramAttributeSet, paramInt1, paramInt2)).b);
  }
  
  private void K() {
    int i = e();
    for (byte b = 0; b < i; b++) {
      b b1 = (b)c(b).getLayoutParams();
      int j = b1.a();
      this.L.put(j, b1.f());
      this.M.put(j, b1.e());
    } 
  }
  
  private void L() {
    this.L.clear();
    this.M.clear();
  }
  
  private void M() {
    View[] arrayOfView = this.K;
    if (arrayOfView == null || arrayOfView.length != this.I)
      this.K = new View[this.I]; 
  }
  
  private void N() {
    int i;
    if (H() == 1) {
      i = q() - o() - n();
    } else {
      i = h() - m() - p();
    } 
    l(i);
  }
  
  private int a(RecyclerView.v paramv, RecyclerView.a0 parama0, int paramInt) {
    if (!parama0.d())
      return this.N.b(paramInt, this.I); 
    int i = paramv.a(paramInt);
    if (i == -1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot find span size for pre layout position. ");
      stringBuilder.append(paramInt);
      Log.w("GridLayoutManager", stringBuilder.toString());
      return 0;
    } 
    return this.N.b(i, this.I);
  }
  
  private void a(float paramFloat, int paramInt) {
    l(Math.max(Math.round(this.I * paramFloat), paramInt));
  }
  
  private void a(RecyclerView.v paramv, RecyclerView.a0 parama0, int paramInt1, int paramInt2, boolean paramBoolean) {
    byte b;
    if (paramBoolean) {
      boolean bool = false;
      b = paramInt1;
      paramInt2 = 1;
      paramInt1 = bool;
    } else {
      paramInt1--;
      b = -1;
      paramInt2 = -1;
    } 
    int i = 0;
    while (paramInt1 != b) {
      View view = this.K[paramInt1];
      b b1 = (b)view.getLayoutParams();
      b1.f = c(paramv, parama0, l(view));
      b1.e = i;
      i += b1.f;
      paramInt1 += paramInt2;
    } 
  }
  
  private void a(View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    RecyclerView.p p = (RecyclerView.p)paramView.getLayoutParams();
    if (paramBoolean) {
      paramBoolean = b(paramView, paramInt1, paramInt2, p);
    } else {
      paramBoolean = a(paramView, paramInt1, paramInt2, p);
    } 
    if (paramBoolean)
      paramView.measure(paramInt1, paramInt2); 
  }
  
  private void a(View paramView, int paramInt, boolean paramBoolean) {
    b b = (b)paramView.getLayoutParams();
    Rect rect = b.b;
    int j = rect.top + rect.bottom + b.topMargin + b.bottomMargin;
    int i = rect.left + rect.right + b.leftMargin + b.rightMargin;
    int k = f(b.e, b.f);
    if (this.s == 1) {
      i = RecyclerView.o.a(k, paramInt, i, b.width, false);
      paramInt = RecyclerView.o.a(this.u.g(), i(), j, b.height, true);
    } else {
      paramInt = RecyclerView.o.a(k, paramInt, j, b.height, false);
      i = RecyclerView.o.a(this.u.g(), r(), i, b.width, true);
    } 
    a(paramView, i, paramInt, paramBoolean);
  }
  
  static int[] a(int[] paramArrayOfint, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: ifnull -> 25
    //   4: aload_0
    //   5: arraylength
    //   6: iload_1
    //   7: iconst_1
    //   8: iadd
    //   9: if_icmpne -> 25
    //   12: aload_0
    //   13: astore #10
    //   15: aload_0
    //   16: aload_0
    //   17: arraylength
    //   18: iconst_1
    //   19: isub
    //   20: iaload
    //   21: iload_2
    //   22: if_icmpeq -> 32
    //   25: iload_1
    //   26: iconst_1
    //   27: iadd
    //   28: newarray int
    //   30: astore #10
    //   32: aload #10
    //   34: iconst_0
    //   35: iconst_0
    //   36: iastore
    //   37: iload_2
    //   38: iload_1
    //   39: idiv
    //   40: istore #7
    //   42: iload_2
    //   43: iload_1
    //   44: irem
    //   45: istore #9
    //   47: iconst_0
    //   48: istore #4
    //   50: iconst_0
    //   51: istore_2
    //   52: iconst_1
    //   53: istore_3
    //   54: iload_3
    //   55: iload_1
    //   56: if_icmpgt -> 127
    //   59: iload #7
    //   61: istore #6
    //   63: iload_2
    //   64: iload #9
    //   66: iadd
    //   67: istore #8
    //   69: iload #8
    //   71: istore_2
    //   72: iload #6
    //   74: istore #5
    //   76: iload #8
    //   78: ifle -> 108
    //   81: iload #8
    //   83: istore_2
    //   84: iload #6
    //   86: istore #5
    //   88: iload_1
    //   89: iload #8
    //   91: isub
    //   92: iload #9
    //   94: if_icmpge -> 108
    //   97: iload #6
    //   99: iconst_1
    //   100: iadd
    //   101: istore #5
    //   103: iload #8
    //   105: iload_1
    //   106: isub
    //   107: istore_2
    //   108: iload #4
    //   110: iload #5
    //   112: iadd
    //   113: istore #4
    //   115: aload #10
    //   117: iload_3
    //   118: iload #4
    //   120: iastore
    //   121: iinc #3, 1
    //   124: goto -> 54
    //   127: aload #10
    //   129: areturn
  }
  
  private int b(RecyclerView.v paramv, RecyclerView.a0 parama0, int paramInt) {
    if (!parama0.d())
      return this.N.a(paramInt, this.I); 
    int i = this.M.get(paramInt, -1);
    if (i != -1)
      return i; 
    i = paramv.a(paramInt);
    if (i == -1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:");
      stringBuilder.append(paramInt);
      Log.w("GridLayoutManager", stringBuilder.toString());
      return 0;
    } 
    return this.N.a(i, this.I);
  }
  
  private void b(RecyclerView.v paramv, RecyclerView.a0 parama0, LinearLayoutManager.a parama, int paramInt) {
    int i;
    if (paramInt == 1) {
      i = 1;
    } else {
      i = 0;
    } 
    paramInt = b(paramv, parama0, parama.b);
    if (i) {
      while (paramInt > 0) {
        paramInt = parama.b;
        if (paramInt > 0) {
          parama.b = paramInt - 1;
          paramInt = b(paramv, parama0, parama.b);
        } 
      } 
    } else {
      int j = parama0.a();
      i = parama.b;
      while (i < j - 1) {
        int k = b(paramv, parama0, i + 1);
        if (k > paramInt) {
          i++;
          paramInt = k;
        } 
      } 
      parama.b = i;
    } 
  }
  
  private int c(RecyclerView.v paramv, RecyclerView.a0 parama0, int paramInt) {
    if (!parama0.d())
      return this.N.a(paramInt); 
    int i = this.L.get(paramInt, -1);
    if (i != -1)
      return i; 
    i = paramv.a(paramInt);
    if (i == -1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:");
      stringBuilder.append(paramInt);
      Log.w("GridLayoutManager", stringBuilder.toString());
      return 1;
    } 
    return this.N.a(i);
  }
  
  private void l(int paramInt) {
    this.J = a(this.J, this.I, paramInt);
  }
  
  public boolean C() {
    boolean bool;
    if (this.D == null && !this.H) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int a(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    N();
    M();
    return super.a(paramInt, paramv, parama0);
  }
  
  public int a(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return (this.s == 1) ? this.I : ((parama0.a() < 1) ? 0 : (a(paramv, parama0, parama0.a() - 1) + 1));
  }
  
  public RecyclerView.p a(Context paramContext, AttributeSet paramAttributeSet) {
    return new b(paramContext, paramAttributeSet);
  }
  
  public RecyclerView.p a(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new b((ViewGroup.MarginLayoutParams)paramLayoutParams) : new b(paramLayoutParams);
  }
  
  View a(RecyclerView.v paramv, RecyclerView.a0 parama0, int paramInt1, int paramInt2, int paramInt3) {
    byte b;
    E();
    View view2 = null;
    View view1 = null;
    int i = this.u.f();
    int j = this.u.b();
    if (paramInt2 > paramInt1) {
      b = 1;
    } else {
      b = -1;
    } 
    while (paramInt1 != paramInt2) {
      View view4 = c(paramInt1);
      int k = l(view4);
      View view5 = view2;
      View view3 = view1;
      if (k >= 0) {
        view5 = view2;
        view3 = view1;
        if (k < paramInt3)
          if (b(paramv, parama0, k) != 0) {
            view5 = view2;
            view3 = view1;
          } else if (((RecyclerView.p)view4.getLayoutParams()).c()) {
            view5 = view2;
            view3 = view1;
            if (view2 == null) {
              view5 = view4;
              view3 = view1;
            } 
          } else if (this.u.d(view4) >= j || this.u.a(view4) < i) {
            view5 = view2;
            view3 = view1;
            if (view1 == null) {
              view3 = view4;
              view5 = view2;
            } 
          } else {
            return view4;
          }  
      } 
      paramInt1 += b;
      view2 = view5;
      view1 = view3;
    } 
    if (view1 == null)
      view1 = view2; 
    return view1;
  }
  
  public View a(View paramView, int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual c : (Landroid/view/View;)Landroid/view/View;
    //   5: astore #24
    //   7: aload #24
    //   9: ifnonnull -> 14
    //   12: aconst_null
    //   13: areturn
    //   14: aload #24
    //   16: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   19: checkcast android/support/v7/widget/GridLayoutManager$b
    //   22: astore #23
    //   24: aload #23
    //   26: getfield e : I
    //   29: istore #17
    //   31: aload #23
    //   33: getfield e : I
    //   36: aload #23
    //   38: getfield f : I
    //   41: iadd
    //   42: istore #18
    //   44: aload_0
    //   45: aload_1
    //   46: iload_2
    //   47: aload_3
    //   48: aload #4
    //   50: invokespecial a : (Landroid/view/View;ILandroid/support/v7/widget/RecyclerView$v;Landroid/support/v7/widget/RecyclerView$a0;)Landroid/view/View;
    //   53: ifnonnull -> 58
    //   56: aconst_null
    //   57: areturn
    //   58: aload_0
    //   59: iload_2
    //   60: invokevirtual i : (I)I
    //   63: iconst_1
    //   64: if_icmpne -> 73
    //   67: iconst_1
    //   68: istore #22
    //   70: goto -> 76
    //   73: iconst_0
    //   74: istore #22
    //   76: iload #22
    //   78: aload_0
    //   79: getfield x : Z
    //   82: if_icmpeq -> 90
    //   85: iconst_1
    //   86: istore_2
    //   87: goto -> 92
    //   90: iconst_0
    //   91: istore_2
    //   92: iload_2
    //   93: ifeq -> 112
    //   96: aload_0
    //   97: invokevirtual e : ()I
    //   100: iconst_1
    //   101: isub
    //   102: istore_2
    //   103: iconst_m1
    //   104: istore #8
    //   106: iconst_m1
    //   107: istore #7
    //   109: goto -> 123
    //   112: iconst_0
    //   113: istore_2
    //   114: iconst_1
    //   115: istore #8
    //   117: aload_0
    //   118: invokevirtual e : ()I
    //   121: istore #7
    //   123: aload_0
    //   124: getfield s : I
    //   127: iconst_1
    //   128: if_icmpne -> 144
    //   131: aload_0
    //   132: invokevirtual I : ()Z
    //   135: ifeq -> 144
    //   138: iconst_1
    //   139: istore #9
    //   141: goto -> 147
    //   144: iconst_0
    //   145: istore #9
    //   147: aconst_null
    //   148: astore #23
    //   150: aconst_null
    //   151: astore_1
    //   152: aload_0
    //   153: aload_3
    //   154: aload #4
    //   156: iload_2
    //   157: invokespecial a : (Landroid/support/v7/widget/RecyclerView$v;Landroid/support/v7/widget/RecyclerView$a0;I)I
    //   160: istore #11
    //   162: iload_2
    //   163: istore #12
    //   165: iconst_m1
    //   166: istore #5
    //   168: iconst_0
    //   169: istore #6
    //   171: iconst_m1
    //   172: istore #14
    //   174: iconst_0
    //   175: istore #13
    //   177: iload_2
    //   178: istore #10
    //   180: iload #12
    //   182: iload #7
    //   184: if_icmpeq -> 582
    //   187: aload_0
    //   188: aload_3
    //   189: aload #4
    //   191: iload #12
    //   193: invokespecial a : (Landroid/support/v7/widget/RecyclerView$v;Landroid/support/v7/widget/RecyclerView$a0;I)I
    //   196: istore_2
    //   197: aload_0
    //   198: iload #12
    //   200: invokevirtual c : (I)Landroid/view/View;
    //   203: astore #25
    //   205: aload #25
    //   207: aload #24
    //   209: if_acmpne -> 215
    //   212: goto -> 582
    //   215: aload #25
    //   217: invokevirtual hasFocusable : ()Z
    //   220: ifeq -> 240
    //   223: iload_2
    //   224: iload #11
    //   226: if_icmpeq -> 240
    //   229: aload #23
    //   231: ifnull -> 237
    //   234: goto -> 582
    //   237: goto -> 566
    //   240: aload #25
    //   242: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   245: checkcast android/support/v7/widget/GridLayoutManager$b
    //   248: astore #26
    //   250: aload #26
    //   252: getfield e : I
    //   255: istore #19
    //   257: aload #26
    //   259: getfield e : I
    //   262: aload #26
    //   264: getfield f : I
    //   267: iadd
    //   268: istore #20
    //   270: aload #25
    //   272: invokevirtual hasFocusable : ()Z
    //   275: ifeq -> 295
    //   278: iload #19
    //   280: iload #17
    //   282: if_icmpne -> 295
    //   285: iload #20
    //   287: iload #18
    //   289: if_icmpne -> 295
    //   292: aload #25
    //   294: areturn
    //   295: aload #25
    //   297: invokevirtual hasFocusable : ()Z
    //   300: ifeq -> 308
    //   303: aload #23
    //   305: ifnull -> 320
    //   308: aload #25
    //   310: invokevirtual hasFocusable : ()Z
    //   313: ifne -> 325
    //   316: aload_1
    //   317: ifnonnull -> 325
    //   320: iconst_1
    //   321: istore_2
    //   322: goto -> 481
    //   325: iload #19
    //   327: iload #17
    //   329: invokestatic max : (II)I
    //   332: istore #15
    //   334: iload #20
    //   336: iload #18
    //   338: invokestatic min : (II)I
    //   341: istore_2
    //   342: iconst_0
    //   343: istore #16
    //   345: iload_2
    //   346: iload #15
    //   348: isub
    //   349: istore #21
    //   351: aload #25
    //   353: invokevirtual hasFocusable : ()Z
    //   356: ifeq -> 409
    //   359: iload #21
    //   361: iload #6
    //   363: if_icmple -> 371
    //   366: iconst_1
    //   367: istore_2
    //   368: goto -> 481
    //   371: iload #21
    //   373: iload #6
    //   375: if_icmpne -> 403
    //   378: iload #19
    //   380: iload #5
    //   382: if_icmple -> 390
    //   385: iconst_1
    //   386: istore_2
    //   387: goto -> 392
    //   390: iconst_0
    //   391: istore_2
    //   392: iload #9
    //   394: iload_2
    //   395: if_icmpne -> 403
    //   398: iconst_1
    //   399: istore_2
    //   400: goto -> 481
    //   403: iload #16
    //   405: istore_2
    //   406: goto -> 481
    //   409: aload #23
    //   411: ifnonnull -> 478
    //   414: iconst_0
    //   415: istore #15
    //   417: iload #16
    //   419: istore_2
    //   420: aload_0
    //   421: aload #25
    //   423: iconst_0
    //   424: iconst_1
    //   425: invokevirtual a : (Landroid/view/View;ZZ)Z
    //   428: ifeq -> 481
    //   431: iload #21
    //   433: iload #13
    //   435: if_icmple -> 443
    //   438: iconst_1
    //   439: istore_2
    //   440: goto -> 481
    //   443: iload #16
    //   445: istore_2
    //   446: iload #21
    //   448: iload #13
    //   450: if_icmpne -> 481
    //   453: iload #19
    //   455: iload #14
    //   457: if_icmple -> 463
    //   460: iconst_1
    //   461: istore #15
    //   463: iload #16
    //   465: istore_2
    //   466: iload #9
    //   468: iload #15
    //   470: if_icmpne -> 481
    //   473: iconst_1
    //   474: istore_2
    //   475: goto -> 481
    //   478: iload #16
    //   480: istore_2
    //   481: iload #6
    //   483: istore #15
    //   485: iload_2
    //   486: ifeq -> 566
    //   489: aload #25
    //   491: invokevirtual hasFocusable : ()Z
    //   494: ifeq -> 527
    //   497: aload #26
    //   499: getfield e : I
    //   502: istore #5
    //   504: iload #20
    //   506: iload #18
    //   508: invokestatic min : (II)I
    //   511: iload #19
    //   513: iload #17
    //   515: invokestatic max : (II)I
    //   518: isub
    //   519: istore_2
    //   520: aload #25
    //   522: astore #23
    //   524: goto -> 569
    //   527: aload #26
    //   529: getfield e : I
    //   532: istore #14
    //   534: iload #20
    //   536: iload #18
    //   538: invokestatic min : (II)I
    //   541: istore_2
    //   542: iload #19
    //   544: iload #17
    //   546: invokestatic max : (II)I
    //   549: istore #6
    //   551: aload #25
    //   553: astore_1
    //   554: iload_2
    //   555: iload #6
    //   557: isub
    //   558: istore #13
    //   560: iload #15
    //   562: istore_2
    //   563: goto -> 569
    //   566: iload #6
    //   568: istore_2
    //   569: iload #12
    //   571: iload #8
    //   573: iadd
    //   574: istore #12
    //   576: iload_2
    //   577: istore #6
    //   579: goto -> 180
    //   582: aload #23
    //   584: ifnull -> 593
    //   587: aload #23
    //   589: astore_1
    //   590: goto -> 593
    //   593: aload_1
    //   594: areturn
  }
  
  public void a(Rect paramRect, int paramInt1, int paramInt2) {
    int[] arrayOfInt;
    if (this.J == null)
      super.a(paramRect, paramInt1, paramInt2); 
    int i = n() + o();
    int j = p() + m();
    if (this.s == 1) {
      paramInt2 = RecyclerView.o.a(paramInt2, paramRect.height() + j, k());
      arrayOfInt = this.J;
      paramInt1 = RecyclerView.o.a(paramInt1, arrayOfInt[arrayOfInt.length - 1] + i, l());
    } else {
      paramInt1 = RecyclerView.o.a(paramInt1, arrayOfInt.width() + i, l());
      arrayOfInt = this.J;
      paramInt2 = RecyclerView.o.a(paramInt2, arrayOfInt[arrayOfInt.length - 1] + j, k());
    } 
    c(paramInt1, paramInt2);
  }
  
  void a(RecyclerView.a0 parama0, LinearLayoutManager.c paramc, RecyclerView.o.c paramc1) {
    int i = this.I;
    for (byte b = 0; b < this.I && paramc.a(parama0) && i > 0; b++) {
      int j = paramc.d;
      paramc1.a(j, Math.max(0, paramc.g));
      i -= this.N.a(j);
      paramc.d += paramc.e;
    } 
  }
  
  void a(RecyclerView.v paramv, RecyclerView.a0 parama0, LinearLayoutManager.a parama, int paramInt) {
    super.a(paramv, parama0, parama, paramInt);
    N();
    if (parama0.a() > 0 && !parama0.d())
      b(paramv, parama0, parama, paramInt); 
    M();
  }
  
  void a(RecyclerView.v paramv, RecyclerView.a0 parama0, LinearLayoutManager.c paramc, LinearLayoutManager.b paramb) {
    StringBuilder stringBuilder;
    byte b1;
    int n;
    boolean bool;
    int i2 = this.u.e();
    if (i2 != 1073741824) {
      m = 1;
    } else {
      m = 0;
    } 
    if (e() > 0) {
      n = this.J[this.I];
    } else {
      n = 0;
    } 
    if (m)
      N(); 
    if (paramc.e == 1) {
      bool = true;
    } else {
      bool = false;
    } 
    int i = this.I;
    if (!bool) {
      i = b(paramv, parama0, paramc.d) + c(paramv, parama0, paramc.d);
      b1 = 0;
      j = 0;
    } else {
      b1 = 0;
      j = 0;
    } 
    while (true) {
      int i3 = i;
      if (b1 < this.I) {
        i3 = i;
        if (paramc.a(parama0)) {
          i3 = i;
          if (i > 0) {
            int i4 = paramc.d;
            i3 = c(paramv, parama0, i4);
            if (i3 <= this.I) {
              i -= i3;
              if (i < 0) {
                i3 = i;
                break;
              } 
              View view = paramc.a(paramv);
              if (view == null) {
                i3 = i;
                break;
              } 
              j += i3;
              this.K[b1] = view;
              b1++;
              continue;
            } 
            stringBuilder = new StringBuilder();
            stringBuilder.append("Item at position ");
            stringBuilder.append(i4);
            stringBuilder.append(" requires ");
            stringBuilder.append(i3);
            stringBuilder.append(" spans but GridLayoutManager has only ");
            stringBuilder.append(this.I);
            stringBuilder.append(" spans.");
            throw new IllegalArgumentException(stringBuilder.toString());
          } 
        } 
      } 
      break;
    } 
    if (b1 == 0) {
      paramb.b = true;
      return;
    } 
    a((RecyclerView.v)stringBuilder, parama0, b1, j, bool);
    int i1 = 0;
    i = 0;
    float f;
    for (f = 0.0F; i1 < b1; f = f1) {
      View view = this.K[i1];
      if (paramc.k == null) {
        if (bool) {
          b(view);
        } else {
          b(view, 0);
        } 
      } else if (bool) {
        a(view);
      } else {
        a(view, 0);
      } 
      a(view, this.O);
      a(view, i2, false);
      int i3 = this.u.b(view);
      j = i;
      if (i3 > i)
        j = i3; 
      b b2 = (b)view.getLayoutParams();
      float f2 = this.u.c(view) * 1.0F / b2.f;
      float f1 = f;
      if (f2 > f)
        f1 = f2; 
      i1++;
      i = j;
    } 
    if (m) {
      a(f, n);
      i = 0;
      j = 0;
      while (j < b1) {
        View view = this.K[j];
        a(view, 1073741824, true);
        n = this.u.b(view);
        m = i;
        if (n > i)
          m = n; 
        j++;
        i = m;
      } 
      n = i;
    } else {
      n = i;
    } 
    int j = 0;
    i = i2;
    while (j < b1) {
      View view = this.K[j];
      if (this.u.b(view) != n) {
        b b2 = (b)view.getLayoutParams();
        Rect rect = b2.b;
        m = rect.top + rect.bottom + b2.topMargin + b2.bottomMargin;
        i1 = rect.left + rect.right + b2.leftMargin + b2.rightMargin;
        i2 = f(b2.e, b2.f);
        if (this.s == 1) {
          i1 = RecyclerView.o.a(i2, 1073741824, i1, b2.width, false);
          m = View.MeasureSpec.makeMeasureSpec(n - m, 1073741824);
        } else {
          i1 = View.MeasureSpec.makeMeasureSpec(n - i1, 1073741824);
          m = RecyclerView.o.a(i2, 1073741824, m, b2.height, false);
        } 
        a(view, i1, m, true);
      } 
      j++;
    } 
    paramb.a = n;
    j = 0;
    int m = 0;
    int k = 0;
    i = 0;
    if (this.s == 1) {
      if (paramc.f == -1) {
        i = paramc.b;
        k = i - n;
      } else {
        k = paramc.b;
        i = k + n;
      } 
    } else if (paramc.f == -1) {
      m = paramc.b;
      j = m - n;
    } else {
      j = paramc.b;
      m = j + n;
    } 
    for (i1 = 0; i1 < b1; i1 = i2) {
      View view = this.K[i1];
      b b2 = (b)view.getLayoutParams();
      if (this.s == 1) {
        if (I()) {
          j = n() + this.J[this.I - b2.e];
          i2 = j - this.u.c(view);
          m = k;
          k = i2;
        } else {
          m = n() + this.J[b2.e];
          i2 = this.u.c(view);
          j = m;
          i2 += m;
          m = k;
          k = j;
          j = i2;
        } 
      } else {
        k = j;
        j = m;
        i = p() + this.J[b2.e];
        i2 = this.u.c(view);
        m = i;
        i = i2 + i;
      } 
      a(view, k, m, j, i);
      if (b2.c() || b2.b())
        paramb.c = true; 
      paramb.d |= view.hasFocusable();
      i2 = i1 + 1;
      i1 = m;
      m = j;
      j = k;
      k = i1;
    } 
    Arrays.fill((Object[])this.K, (Object)null);
  }
  
  public void a(RecyclerView.v paramv, RecyclerView.a0 parama0, View paramView, android.support.v4.view.d0.c paramc) {
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (!(layoutParams instanceof b)) {
      a(paramView, paramc);
      return;
    } 
    b b = (b)layoutParams;
    int i = a(paramv, parama0, b.a());
    if (this.s == 0) {
      boolean bool;
      int k = b.e();
      int j = b.f();
      if (this.I > 1 && b.f() == this.I) {
        bool = true;
      } else {
        bool = false;
      } 
      paramc.b(android.support.v4.view.d0.c.c.a(k, j, i, 1, bool, false));
    } else {
      boolean bool;
      int j = b.e();
      int k = b.f();
      if (this.I > 1 && b.f() == this.I) {
        bool = true;
      } else {
        bool = false;
      } 
      paramc.b(android.support.v4.view.d0.c.c.a(i, 1, j, k, bool, false));
    } 
  }
  
  public void a(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    this.N.a();
  }
  
  public void a(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, int paramInt3) {
    this.N.a();
  }
  
  public void a(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, Object paramObject) {
    this.N.a();
  }
  
  public boolean a(RecyclerView.p paramp) {
    return paramp instanceof b;
  }
  
  public int b(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    N();
    M();
    return super.b(paramInt, paramv, parama0);
  }
  
  public int b(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return (this.s == 0) ? this.I : ((parama0.a() < 1) ? 0 : (a(paramv, parama0, parama0.a() - 1) + 1));
  }
  
  public void b(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    this.N.a();
  }
  
  public void b(boolean paramBoolean) {
    if (!paramBoolean) {
      super.b(false);
      return;
    } 
    throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
  }
  
  public RecyclerView.p c() {
    return (this.s == 0) ? new b(-2, -1) : new b(-1, -2);
  }
  
  public void d(RecyclerView paramRecyclerView) {
    this.N.a();
  }
  
  public void e(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    if (parama0.d())
      K(); 
    super.e(paramv, parama0);
    L();
  }
  
  int f(int paramInt1, int paramInt2) {
    if (this.s == 1 && I()) {
      int[] arrayOfInt1 = this.J;
      int i = this.I;
      return arrayOfInt1[i - paramInt1] - arrayOfInt1[i - paramInt1 - paramInt2];
    } 
    int[] arrayOfInt = this.J;
    return arrayOfInt[paramInt1 + paramInt2] - arrayOfInt[paramInt1];
  }
  
  public void g(RecyclerView.a0 parama0) {
    super.g(parama0);
    this.H = false;
  }
  
  public void k(int paramInt) {
    if (paramInt == this.I)
      return; 
    this.H = true;
    if (paramInt >= 1) {
      this.I = paramInt;
      this.N.a();
      y();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Span count should be at least 1. Provided ");
    stringBuilder.append(paramInt);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public static final class a extends c {
    public int a(int param1Int) {
      return 1;
    }
    
    public int c(int param1Int1, int param1Int2) {
      return param1Int1 % param1Int2;
    }
  }
  
  public static class b extends RecyclerView.p {
    int e = -1;
    
    int f = 0;
    
    public b(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public b(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public b(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public b(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public int e() {
      return this.e;
    }
    
    public int f() {
      return this.f;
    }
  }
  
  public static abstract class c {
    final SparseIntArray a = new SparseIntArray();
    
    private boolean b = false;
    
    public abstract int a(int param1Int);
    
    int a(int param1Int1, int param1Int2) {
      if (!this.b)
        return c(param1Int1, param1Int2); 
      int i = this.a.get(param1Int1, -1);
      if (i != -1)
        return i; 
      param1Int2 = c(param1Int1, param1Int2);
      this.a.put(param1Int1, param1Int2);
      return param1Int2;
    }
    
    public void a() {
      this.a.clear();
    }
    
    public int b(int param1Int1, int param1Int2) {
      int i = 0;
      int j = 0;
      int k = a(param1Int1);
      byte b = 0;
      while (b < param1Int1) {
        int m;
        int n = a(b);
        int i1 = i + n;
        if (i1 == param1Int2) {
          i = 0;
          m = j + 1;
        } else {
          i = i1;
          m = j;
          if (i1 > param1Int2) {
            i = n;
            m = j + 1;
          } 
        } 
        b++;
        j = m;
      } 
      param1Int1 = j;
      if (i + k > param1Int2)
        param1Int1 = j + 1; 
      return param1Int1;
    }
    
    public abstract int c(int param1Int1, int param1Int2);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\GridLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */