package android.support.v7.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

public class b1 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
  Runnable c;
  
  private c d;
  
  o0 e;
  
  private Spinner f;
  
  private boolean g;
  
  int h;
  
  int i;
  
  private int j;
  
  private int k;
  
  static {
    new DecelerateInterpolator();
  }
  
  private Spinner a() {
    v v = new v(getContext(), null, a.b.h.a.a.actionDropDownStyle);
    v.setLayoutParams((ViewGroup.LayoutParams)new o0.a(-2, -1));
    v.setOnItemSelectedListener(this);
    return v;
  }
  
  private boolean b() {
    boolean bool;
    Spinner spinner = this.f;
    if (spinner != null && spinner.getParent() == this) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private void c() {
    if (b())
      return; 
    if (this.f == null)
      this.f = a(); 
    removeView((View)this.e);
    addView((View)this.f, new ViewGroup.LayoutParams(-2, -1));
    if (this.f.getAdapter() == null)
      this.f.setAdapter((SpinnerAdapter)new b(this)); 
    Runnable runnable = this.c;
    if (runnable != null) {
      removeCallbacks(runnable);
      this.c = null;
    } 
    this.f.setSelection(this.k);
  }
  
  private boolean d() {
    if (!b())
      return false; 
    removeView((View)this.f);
    addView((View)this.e, new ViewGroup.LayoutParams(-2, -1));
    setTabSelected(this.f.getSelectedItemPosition());
    return false;
  }
  
  d a(android.support.v7.app.a.c paramc, boolean paramBoolean) {
    d d = new d(this, getContext(), paramc, paramBoolean);
    if (paramBoolean) {
      d.setBackgroundDrawable(null);
      d.setLayoutParams((ViewGroup.LayoutParams)new AbsListView.LayoutParams(-1, this.j));
    } else {
      d.setFocusable(true);
      if (this.d == null)
        this.d = new c(this); 
      d.setOnClickListener(this.d);
    } 
    return d;
  }
  
  public void a(int paramInt) {
    View view = this.e.getChildAt(paramInt);
    Runnable runnable = this.c;
    if (runnable != null)
      removeCallbacks(runnable); 
    this.c = new a(this, view);
    post(this.c);
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    Runnable runnable = this.c;
    if (runnable != null)
      post(runnable); 
  }
  
  protected void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    a.b.h.f.a a = a.b.h.f.a.a(getContext());
    setContentHeight(a.e());
    this.i = a.d();
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    Runnable runnable = this.c;
    if (runnable != null)
      removeCallbacks(runnable); 
  }
  
  public void onItemSelected(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    ((d)paramView).a().e();
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    boolean bool;
    int i = View.MeasureSpec.getMode(paramInt1);
    paramInt2 = 1;
    if (i == 1073741824) {
      bool = true;
    } else {
      bool = false;
    } 
    setFillViewport(bool);
    int j = this.e.getChildCount();
    if (j > 1 && (i == 1073741824 || i == Integer.MIN_VALUE)) {
      if (j > 2) {
        this.h = (int)(View.MeasureSpec.getSize(paramInt1) * 0.4F);
      } else {
        this.h = View.MeasureSpec.getSize(paramInt1) / 2;
      } 
      this.h = Math.min(this.h, this.i);
    } else {
      this.h = -1;
    } 
    i = View.MeasureSpec.makeMeasureSpec(this.j, 1073741824);
    if (bool || !this.g)
      paramInt2 = 0; 
    if (paramInt2 != 0) {
      this.e.measure(0, i);
      if (this.e.getMeasuredWidth() > View.MeasureSpec.getSize(paramInt1)) {
        c();
      } else {
        d();
      } 
    } else {
      d();
    } 
    paramInt2 = getMeasuredWidth();
    super.onMeasure(paramInt1, i);
    paramInt1 = getMeasuredWidth();
    if (bool && paramInt2 != paramInt1)
      setTabSelected(this.k); 
  }
  
  public void onNothingSelected(AdapterView<?> paramAdapterView) {}
  
  public void setAllowCollapse(boolean paramBoolean) {
    this.g = paramBoolean;
  }
  
  public void setContentHeight(int paramInt) {
    this.j = paramInt;
    requestLayout();
  }
  
  public void setTabSelected(int paramInt) {
    this.k = paramInt;
    int i = this.e.getChildCount();
    for (byte b = 0; b < i; b++) {
      boolean bool;
      View view = this.e.getChildAt(b);
      if (b == paramInt) {
        bool = true;
      } else {
        bool = false;
      } 
      view.setSelected(bool);
      if (bool)
        a(paramInt); 
    } 
    Spinner spinner = this.f;
    if (spinner != null && paramInt >= 0)
      spinner.setSelection(paramInt); 
  }
  
  class a implements Runnable {
    final View c;
    
    final b1 d;
    
    a(b1 this$0, View param1View) {}
    
    public void run() {
      int i = this.c.getLeft();
      int j = (this.d.getWidth() - this.c.getWidth()) / 2;
      this.d.smoothScrollTo(i - j, 0);
      this.d.c = null;
    }
  }
  
  private class b extends BaseAdapter {
    final b1 c;
    
    b(b1 this$0) {}
    
    public int getCount() {
      return this.c.e.getChildCount();
    }
    
    public Object getItem(int param1Int) {
      return ((b1.d)this.c.e.getChildAt(param1Int)).a();
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      b1.d d;
      if (param1View == null) {
        d = this.c.a((android.support.v7.app.a.c)getItem(param1Int), true);
      } else {
        d.a((android.support.v7.app.a.c)getItem(param1Int));
      } 
      return (View)d;
    }
  }
  
  private class c implements View.OnClickListener {
    final b1 c;
    
    c(b1 this$0) {}
    
    public void onClick(View param1View) {
      ((b1.d)param1View).a().e();
      int i = this.c.e.getChildCount();
      for (byte b = 0; b < i; b++) {
        boolean bool;
        View view = this.c.e.getChildAt(b);
        if (view == param1View) {
          bool = true;
        } else {
          bool = false;
        } 
        view.setSelected(bool);
      } 
    }
  }
  
  private class d extends LinearLayout {
    private final int[] c = new int[] { 16842964 };
    
    private android.support.v7.app.a.c d;
    
    private TextView e;
    
    private ImageView f;
    
    private View g;
    
    final b1 h;
    
    public d(b1 this$0, Context param1Context, android.support.v7.app.a.c param1c, boolean param1Boolean) {
      super(param1Context, null, a.b.h.a.a.actionBarTabStyle);
      this.d = param1c;
      j1 j1 = j1.a(param1Context, null, this.c, a.b.h.a.a.actionBarTabStyle, 0);
      if (j1.g(0))
        setBackgroundDrawable(j1.b(0)); 
      j1.a();
      if (param1Boolean)
        setGravity(8388627); 
      b();
    }
    
    public android.support.v7.app.a.c a() {
      return this.d;
    }
    
    public void a(android.support.v7.app.a.c param1c) {
      this.d = param1c;
      b();
    }
    
    public void b() {
      android.support.v7.app.a.c c1 = this.d;
      View view = c1.b();
      ViewParent viewParent = null;
      if (view != null) {
        viewParent = view.getParent();
        if (viewParent != this) {
          if (viewParent != null)
            ((ViewGroup)viewParent).removeView(view); 
          addView(view);
        } 
        this.g = view;
        TextView textView = this.e;
        if (textView != null)
          textView.setVisibility(8); 
        ImageView imageView = this.f;
        if (imageView != null) {
          imageView.setVisibility(8);
          this.f.setImageDrawable(null);
        } 
      } else {
        CharSequence charSequence1;
        view = this.g;
        if (view != null) {
          removeView(view);
          this.g = null;
        } 
        Drawable drawable = c1.c();
        CharSequence charSequence2 = c1.d();
        if (drawable != null) {
          if (this.f == null) {
            o o = new o(getContext());
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 16;
            o.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            addView((View)o, 0);
            this.f = o;
          } 
          this.f.setImageDrawable(drawable);
          this.f.setVisibility(0);
        } else {
          ImageView imageView1 = this.f;
          if (imageView1 != null) {
            imageView1.setVisibility(8);
            this.f.setImageDrawable(null);
          } 
        } 
        int i = TextUtils.isEmpty(charSequence2) ^ true;
        if (i != 0) {
          if (this.e == null) {
            AppCompatTextView appCompatTextView = new AppCompatTextView(getContext(), null, a.b.h.a.a.actionBarTabTextStyle);
            appCompatTextView.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 16;
            appCompatTextView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            addView((View)appCompatTextView);
            this.e = appCompatTextView;
          } 
          this.e.setText(charSequence2);
          this.e.setVisibility(0);
        } else {
          TextView textView = this.e;
          if (textView != null) {
            textView.setVisibility(8);
            this.e.setText(null);
          } 
        } 
        ImageView imageView = this.f;
        if (imageView != null)
          imageView.setContentDescription(c1.a()); 
        if (i == 0)
          charSequence1 = c1.a(); 
        l1.a((View)this, charSequence1);
      } 
    }
    
    public void onInitializeAccessibilityEvent(AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName(android.support.v7.app.a.c.class.getName());
    }
    
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo param1AccessibilityNodeInfo) {
      super.onInitializeAccessibilityNodeInfo(param1AccessibilityNodeInfo);
      param1AccessibilityNodeInfo.setClassName(android.support.v7.app.a.c.class.getName());
    }
    
    public void onMeasure(int param1Int1, int param1Int2) {
      super.onMeasure(param1Int1, param1Int2);
      if (this.h.h > 0) {
        int i = getMeasuredWidth();
        param1Int1 = this.h.h;
        if (i > param1Int1)
          super.onMeasure(View.MeasureSpec.makeMeasureSpec(param1Int1, 1073741824), param1Int2); 
      } 
    }
    
    public void setSelected(boolean param1Boolean) {
      boolean bool;
      if (isSelected() != param1Boolean) {
        bool = true;
      } else {
        bool = false;
      } 
      super.setSelected(param1Boolean);
      if (bool && param1Boolean)
        sendAccessibilityEvent(4); 
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\b1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */