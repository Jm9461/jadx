package android.support.v7.widget;

import a.b.h.a.j;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v4.view.u;
import android.util.AttributeSet;
import android.view.View;

class f {
  private final View a;
  
  private final j b;
  
  private int c = -1;
  
  private h1 d;
  
  private h1 e;
  
  private h1 f;
  
  f(View paramView) {
    this.a = paramView;
    this.b = j.a();
  }
  
  private boolean b(Drawable paramDrawable) {
    if (this.f == null)
      this.f = new h1(); 
    h1 h11 = this.f;
    h11.a();
    ColorStateList colorStateList = u.c(this.a);
    if (colorStateList != null) {
      h11.d = true;
      h11.a = colorStateList;
    } 
    PorterDuff.Mode mode = u.d(this.a);
    if (mode != null) {
      h11.c = true;
      h11.b = mode;
    } 
    if (h11.d || h11.c) {
      j.a(paramDrawable, h11, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  private boolean d() {
    int i = Build.VERSION.SDK_INT;
    boolean bool = true;
    if (i > 21) {
      if (this.d == null)
        bool = false; 
      return bool;
    } 
    return (i == 21);
  }
  
  void a() {
    Drawable drawable = this.a.getBackground();
    if (drawable != null) {
      if (d() && b(drawable))
        return; 
      h1 h11 = this.e;
      if (h11 != null) {
        j.a(drawable, h11, this.a.getDrawableState());
      } else {
        h11 = this.d;
        if (h11 != null)
          j.a(drawable, h11, this.a.getDrawableState()); 
      } 
    } 
  }
  
  void a(int paramInt) {
    this.c = paramInt;
    j j1 = this.b;
    if (j1 != null) {
      ColorStateList colorStateList = j1.b(this.a.getContext(), paramInt);
    } else {
      j1 = null;
    } 
    a((ColorStateList)j1);
    a();
  }
  
  void a(ColorStateList paramColorStateList) {
    if (paramColorStateList != null) {
      if (this.d == null)
        this.d = new h1(); 
      h1 h11 = this.d;
      h11.a = paramColorStateList;
      h11.d = true;
    } else {
      this.d = null;
    } 
    a();
  }
  
  void a(PorterDuff.Mode paramMode) {
    if (this.e == null)
      this.e = new h1(); 
    h1 h11 = this.e;
    h11.b = paramMode;
    h11.c = true;
    a();
  }
  
  void a(Drawable paramDrawable) {
    this.c = -1;
    a((ColorStateList)null);
    a();
  }
  
  void a(AttributeSet paramAttributeSet, int paramInt) {
    j1 j1 = j1.a(this.a.getContext(), paramAttributeSet, j.ViewBackgroundHelper, paramInt, 0);
    try {
      if (j1.g(j.ViewBackgroundHelper_android_background)) {
        this.c = j1.g(j.ViewBackgroundHelper_android_background, -1);
        ColorStateList colorStateList = this.b.b(this.a.getContext(), this.c);
        if (colorStateList != null)
          a(colorStateList); 
      } 
      if (j1.g(j.ViewBackgroundHelper_backgroundTint))
        u.a(this.a, j1.a(j.ViewBackgroundHelper_backgroundTint)); 
      if (j1.g(j.ViewBackgroundHelper_backgroundTintMode))
        u.a(this.a, h0.a(j1.d(j.ViewBackgroundHelper_backgroundTintMode, -1), null)); 
      return;
    } finally {
      j1.a();
    } 
  }
  
  ColorStateList b() {
    h1 h11 = this.e;
    if (h11 != null) {
      ColorStateList colorStateList = h11.a;
    } else {
      h11 = null;
    } 
    return (ColorStateList)h11;
  }
  
  void b(ColorStateList paramColorStateList) {
    if (this.e == null)
      this.e = new h1(); 
    h1 h11 = this.e;
    h11.a = paramColorStateList;
    h11.d = true;
    a();
  }
  
  PorterDuff.Mode c() {
    h1 h11 = this.e;
    if (h11 != null) {
      PorterDuff.Mode mode = h11.b;
    } else {
      h11 = null;
    } 
    return (PorterDuff.Mode)h11;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */