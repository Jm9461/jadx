package android.support.v7.widget;

import a.b.g.f.b;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v4.view.t;
import android.support.v4.widget.b;
import android.support.v4.widget.p;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class AppCompatTextView extends TextView implements t, b {
  private final f c = new f((View)this);
  
  private final w d;
  
  private Future<b> e;
  
  public AppCompatTextView(Context paramContext) {
    this(paramContext, null);
  }
  
  public AppCompatTextView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16842884);
  }
  
  public AppCompatTextView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(g1.b(paramContext), paramAttributeSet, paramInt);
    this.c.a(paramAttributeSet, paramInt);
    this.d = new w(this);
    this.d.a(paramAttributeSet, paramInt);
    this.d.a();
  }
  
  private void d() {
    Future<b> future = this.e;
    if (future != null)
      try {
        this.e = null;
        p.a(this, future.get());
      } catch (InterruptedException interruptedException) {
      
      } catch (ExecutionException executionException) {} 
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    f f1 = this.c;
    if (f1 != null)
      f1.a(); 
    w w1 = this.d;
    if (w1 != null)
      w1.a(); 
  }
  
  public int getAutoSizeMaxTextSize() {
    if (b.a)
      return super.getAutoSizeMaxTextSize(); 
    w w1 = this.d;
    return (w1 != null) ? w1.c() : -1;
  }
  
  public int getAutoSizeMinTextSize() {
    if (b.a)
      return super.getAutoSizeMinTextSize(); 
    w w1 = this.d;
    return (w1 != null) ? w1.d() : -1;
  }
  
  public int getAutoSizeStepGranularity() {
    if (b.a)
      return super.getAutoSizeStepGranularity(); 
    w w1 = this.d;
    return (w1 != null) ? w1.e() : -1;
  }
  
  public int[] getAutoSizeTextAvailableSizes() {
    if (b.a)
      return super.getAutoSizeTextAvailableSizes(); 
    w w1 = this.d;
    return (w1 != null) ? w1.f() : new int[0];
  }
  
  public int getAutoSizeTextType() {
    boolean bool1 = b.a;
    boolean bool = false;
    if (bool1) {
      if (super.getAutoSizeTextType() == 1)
        bool = true; 
      return bool;
    } 
    w w1 = this.d;
    return (w1 != null) ? w1.g() : 0;
  }
  
  public int getFirstBaselineToTopHeight() {
    return p.b(this);
  }
  
  public int getLastBaselineToBottomHeight() {
    return p.c(this);
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    f f1 = this.c;
    if (f1 != null) {
      ColorStateList colorStateList = f1.b();
    } else {
      f1 = null;
    } 
    return (ColorStateList)f1;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    f f1 = this.c;
    if (f1 != null) {
      PorterDuff.Mode mode = f1.c();
    } else {
      f1 = null;
    } 
    return (PorterDuff.Mode)f1;
  }
  
  public CharSequence getText() {
    d();
    return super.getText();
  }
  
  public b.a getTextMetricsParamsCompat() {
    return p.f(this);
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = super.onCreateInputConnection(paramEditorInfo);
    l.a(inputConnection, paramEditorInfo, (View)this);
    return inputConnection;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    w w1 = this.d;
    if (w1 != null)
      w1.a(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    d();
    super.onMeasure(paramInt1, paramInt2);
  }
  
  protected void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    w w1 = this.d;
    if (w1 != null && !b.a && w1.h())
      this.d.b(); 
  }
  
  public void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (b.a) {
      super.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
    } else {
      w w1 = this.d;
      if (w1 != null)
        w1.a(paramInt1, paramInt2, paramInt3, paramInt4); 
    } 
  }
  
  public void setAutoSizeTextTypeUniformWithPresetSizes(int[] paramArrayOfint, int paramInt) {
    if (b.a) {
      super.setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfint, paramInt);
    } else {
      w w1 = this.d;
      if (w1 != null)
        w1.a(paramArrayOfint, paramInt); 
    } 
  }
  
  public void setAutoSizeTextTypeWithDefaults(int paramInt) {
    if (b.a) {
      super.setAutoSizeTextTypeWithDefaults(paramInt);
    } else {
      w w1 = this.d;
      if (w1 != null)
        w1.a(paramInt); 
    } 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    f f1 = this.c;
    if (f1 != null)
      f1.a(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    f f1 = this.c;
    if (f1 != null)
      f1.a(paramInt); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(p.a(this, paramCallback));
  }
  
  public void setFirstBaselineToTopHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      super.setFirstBaselineToTopHeight(paramInt);
    } else {
      p.a(this, paramInt);
    } 
  }
  
  public void setLastBaselineToBottomHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      super.setLastBaselineToBottomHeight(paramInt);
    } else {
      p.b(this, paramInt);
    } 
  }
  
  public void setLineHeight(int paramInt) {
    p.c(this, paramInt);
  }
  
  public void setPrecomputedText(b paramb) {
    p.a(this, paramb);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    f f1 = this.c;
    if (f1 != null)
      f1.b(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    f f1 = this.c;
    if (f1 != null)
      f1.a(paramMode); 
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    w w1 = this.d;
    if (w1 != null)
      w1.a(paramContext, paramInt); 
  }
  
  public void setTextFuture(Future<b> paramFuture) {
    this.e = paramFuture;
    requestLayout();
  }
  
  public void setTextMetricsParamsCompat(b.a parama) {
    p.a(this, parama);
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    if (b.a) {
      super.setTextSize(paramInt, paramFloat);
    } else {
      w w1 = this.d;
      if (w1 != null)
        w1.a(paramInt, paramFloat); 
    } 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\AppCompatTextView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */