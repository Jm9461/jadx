package android.support.v7.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.view.y;
import android.support.v7.view.menu.h;
import android.support.v7.view.menu.p;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;

public interface f0 {
  y a(int paramInt, long paramLong);
  
  void a(int paramInt);
  
  void a(Drawable paramDrawable);
  
  void a(p.a parama, h.a parama1);
  
  void a(b1 paramb1);
  
  void a(Menu paramMenu, p.a parama);
  
  void a(boolean paramBoolean);
  
  boolean a();
  
  void b(int paramInt);
  
  void b(Drawable paramDrawable);
  
  void b(boolean paramBoolean);
  
  boolean b();
  
  void c(int paramInt);
  
  boolean c();
  
  void collapseActionView();
  
  void d(int paramInt);
  
  boolean d();
  
  void e();
  
  boolean f();
  
  void g();
  
  CharSequence getTitle();
  
  int h();
  
  Menu i();
  
  ViewGroup j();
  
  Context k();
  
  int l();
  
  void m();
  
  boolean n();
  
  void o();
  
  void setIcon(int paramInt);
  
  void setIcon(Drawable paramDrawable);
  
  void setTitle(CharSequence paramCharSequence);
  
  void setWindowCallback(Window.Callback paramCallback);
  
  void setWindowTitle(CharSequence paramCharSequence);
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */