package android.support.v7.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.view.c;
import android.support.v7.view.menu.ActionMenuItemView;
import android.support.v7.view.menu.b;
import android.support.v7.view.menu.h;
import android.support.v7.view.menu.k;
import android.support.v7.view.menu.n;
import android.support.v7.view.menu.o;
import android.support.v7.view.menu.p;
import android.support.v7.view.menu.q;
import android.support.v7.view.menu.t;
import android.support.v7.view.menu.v;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.util.ArrayList;

class c extends b implements c.a {
  e A;
  
  a B;
  
  c C;
  
  private b D;
  
  final f E = new f(this);
  
  int F;
  
  d l;
  
  private Drawable m;
  
  private boolean n;
  
  private boolean o;
  
  private boolean p;
  
  private int q;
  
  private int r;
  
  private int s;
  
  private boolean t;
  
  private boolean u;
  
  private boolean v;
  
  private boolean w;
  
  private int x;
  
  private final SparseBooleanArray y = new SparseBooleanArray();
  
  private View z;
  
  public c(Context paramContext) {
    super(paramContext, a.b.h.a.g.abc_action_menu_layout, a.b.h.a.g.abc_action_menu_item_layout);
  }
  
  private View a(MenuItem paramMenuItem) {
    ViewGroup viewGroup = (ViewGroup)this.j;
    if (viewGroup == null)
      return null; 
    int i = viewGroup.getChildCount();
    for (byte b1 = 0; b1 < i; b1++) {
      View view = viewGroup.getChildAt(b1);
      if (view instanceof q.a && ((q.a)view).getItemData() == paramMenuItem)
        return view; 
    } 
    return null;
  }
  
  public View a(k paramk, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramk.getActionView();
    if (view == null || paramk.f())
      view = super.a(paramk, paramView, paramViewGroup); 
    if (paramk.isActionViewExpanded()) {
      bool = true;
    } else {
      bool = false;
    } 
    view.setVisibility(bool);
    ActionMenuView actionMenuView = (ActionMenuView)paramViewGroup;
    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
    if (!actionMenuView.checkLayoutParams(layoutParams))
      view.setLayoutParams((ViewGroup.LayoutParams)actionMenuView.generateLayoutParams(layoutParams)); 
    return view;
  }
  
  public void a(Context paramContext, h paramh) {
    super.a(paramContext, paramh);
    Resources resources = paramContext.getResources();
    a.b.h.f.a a1 = a.b.h.f.a.a(paramContext);
    if (!this.p)
      this.o = a1.g(); 
    if (!this.v)
      this.q = a1.b(); 
    if (!this.t)
      this.s = a1.c(); 
    int i = this.q;
    if (this.o) {
      if (this.l == null) {
        this.l = new d(this, this.c);
        if (this.n) {
          this.l.setImageDrawable(this.m);
          this.m = null;
          this.n = false;
        } 
        int j = View.MeasureSpec.makeMeasureSpec(0, 0);
        this.l.measure(j, j);
      } 
      i -= this.l.getMeasuredWidth();
    } else {
      this.l = null;
    } 
    this.r = i;
    this.x = (int)((resources.getDisplayMetrics()).density * 56.0F);
    this.z = null;
  }
  
  public void a(Configuration paramConfiguration) {
    if (!this.t)
      this.s = a.b.h.f.a.a(this.d).c(); 
    h h = this.e;
    if (h != null)
      h.b(true); 
  }
  
  public void a(Drawable paramDrawable) {
    d d1 = this.l;
    if (d1 != null) {
      d1.setImageDrawable(paramDrawable);
    } else {
      this.n = true;
      this.m = paramDrawable;
    } 
  }
  
  public void a(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof g))
      return; 
    int i = ((g)paramParcelable).c;
    if (i > 0) {
      MenuItem menuItem = this.e.findItem(i);
      if (menuItem != null)
        a((v)menuItem.getSubMenu()); 
    } 
  }
  
  public void a(h paramh, boolean paramBoolean) {
    e();
    super.a(paramh, paramBoolean);
  }
  
  public void a(k paramk, q.a parama) {
    parama.a(paramk, 0);
    ActionMenuView actionMenuView = (ActionMenuView)this.j;
    ActionMenuItemView actionMenuItemView = (ActionMenuItemView)parama;
    actionMenuItemView.setItemInvoker(actionMenuView);
    if (this.D == null)
      this.D = new b(this); 
    actionMenuItemView.setPopupCallback(this.D);
  }
  
  public void a(ActionMenuView paramActionMenuView) {
    this.j = paramActionMenuView;
    paramActionMenuView.a(this.e);
  }
  
  public void a(boolean paramBoolean) {
    super.a(paramBoolean);
    ((View)this.j).requestLayout();
    h<k> h = this.e;
    if (h != null) {
      ArrayList<k> arrayList = h.c();
      int k = arrayList.size();
      for (byte b1 = 0; b1 < k; b1++) {
        c c1 = ((k)arrayList.get(b1)).a();
        if (c1 != null)
          c1.a(this); 
      } 
    } 
    h = this.e;
    if (h != null) {
      ArrayList arrayList = h.j();
    } else {
      h = null;
    } 
    int j = 0;
    int i = j;
    if (this.o) {
      i = j;
      if (h != null) {
        j = h.size();
        i = 0;
        if (j == 1) {
          i = ((k)h.get(0)).isActionViewExpanded() ^ true;
        } else if (j > 0) {
          i = 1;
        } 
      } 
    } 
    if (i != 0) {
      if (this.l == null)
        this.l = new d(this, this.c); 
      ViewGroup viewGroup = (ViewGroup)this.l.getParent();
      if (viewGroup != this.j) {
        if (viewGroup != null)
          viewGroup.removeView((View)this.l); 
        viewGroup = (ActionMenuView)this.j;
        viewGroup.addView((View)this.l, (ViewGroup.LayoutParams)viewGroup.e());
      } 
    } else {
      d d1 = this.l;
      if (d1 != null) {
        ViewParent viewParent = d1.getParent();
        q q = this.j;
        if (viewParent == q)
          ((ViewGroup)q).removeView((View)this.l); 
      } 
    } 
    ((ActionMenuView)this.j).setOverflowReserved(this.o);
  }
  
  public boolean a(int paramInt, k paramk) {
    return paramk.h();
  }
  
  public boolean a(v paramv) {
    boolean bool1;
    if (!paramv.hasVisibleItems())
      return false; 
    v v1;
    for (v1 = paramv; v1.t() != this.e; v1 = (v)v1.t());
    View view = a(v1.getItem());
    if (view == null)
      return false; 
    this.F = paramv.getItem().getItemId();
    boolean bool2 = false;
    int i = paramv.size();
    byte b1 = 0;
    while (true) {
      bool1 = bool2;
      if (b1 < i) {
        MenuItem menuItem = paramv.getItem(b1);
        if (menuItem.isVisible() && menuItem.getIcon() != null) {
          bool1 = true;
          break;
        } 
        b1++;
        continue;
      } 
      break;
    } 
    this.B = new a(this, this.d, paramv, view);
    this.B.a(bool1);
    this.B.e();
    super.a(paramv);
    return true;
  }
  
  public boolean a(ViewGroup paramViewGroup, int paramInt) {
    return (paramViewGroup.getChildAt(paramInt) == this.l) ? false : super.a(paramViewGroup, paramInt);
  }
  
  public q b(ViewGroup paramViewGroup) {
    q q2 = this.j;
    q q1 = super.b(paramViewGroup);
    if (q2 != q1)
      ((ActionMenuView)q1).setPresenter(this); 
    return q1;
  }
  
  public void b(boolean paramBoolean) {
    this.w = paramBoolean;
  }
  
  public boolean b() {
    // Byte code:
    //   0: aload_0
    //   1: getfield e : Landroid/support/v7/view/menu/h;
    //   4: astore #15
    //   6: aload #15
    //   8: ifnull -> 27
    //   11: aload #15
    //   13: invokevirtual n : ()Ljava/util/ArrayList;
    //   16: astore #15
    //   18: aload #15
    //   20: invokevirtual size : ()I
    //   23: istore_3
    //   24: goto -> 32
    //   27: aconst_null
    //   28: astore #15
    //   30: iconst_0
    //   31: istore_3
    //   32: aload_0
    //   33: getfield s : I
    //   36: istore_1
    //   37: aload_0
    //   38: getfield r : I
    //   41: istore #9
    //   43: iconst_0
    //   44: iconst_0
    //   45: invokestatic makeMeasureSpec : (II)I
    //   48: istore #11
    //   50: aload_0
    //   51: getfield j : Landroid/support/v7/view/menu/q;
    //   54: checkcast android/view/ViewGroup
    //   57: astore #16
    //   59: iconst_0
    //   60: istore #4
    //   62: iconst_0
    //   63: istore #6
    //   65: iconst_0
    //   66: istore #8
    //   68: iconst_0
    //   69: istore #5
    //   71: iconst_0
    //   72: istore_2
    //   73: iload_2
    //   74: iload_3
    //   75: if_icmpge -> 153
    //   78: aload #15
    //   80: iload_2
    //   81: invokevirtual get : (I)Ljava/lang/Object;
    //   84: checkcast android/support/v7/view/menu/k
    //   87: astore #17
    //   89: aload #17
    //   91: invokevirtual k : ()Z
    //   94: ifeq -> 103
    //   97: iinc #4, 1
    //   100: goto -> 120
    //   103: aload #17
    //   105: invokevirtual j : ()Z
    //   108: ifeq -> 117
    //   111: iinc #6, 1
    //   114: goto -> 120
    //   117: iconst_1
    //   118: istore #5
    //   120: iload_1
    //   121: istore #7
    //   123: aload_0
    //   124: getfield w : Z
    //   127: ifeq -> 144
    //   130: iload_1
    //   131: istore #7
    //   133: aload #17
    //   135: invokevirtual isActionViewExpanded : ()Z
    //   138: ifeq -> 144
    //   141: iconst_0
    //   142: istore #7
    //   144: iinc #2, 1
    //   147: iload #7
    //   149: istore_1
    //   150: goto -> 73
    //   153: iload_1
    //   154: istore_2
    //   155: aload_0
    //   156: getfield o : Z
    //   159: ifeq -> 182
    //   162: iload #5
    //   164: ifne -> 178
    //   167: iload_1
    //   168: istore_2
    //   169: iload #4
    //   171: iload #6
    //   173: iadd
    //   174: iload_1
    //   175: if_icmple -> 182
    //   178: iload_1
    //   179: iconst_1
    //   180: isub
    //   181: istore_2
    //   182: iload_2
    //   183: iload #4
    //   185: isub
    //   186: istore #5
    //   188: aload_0
    //   189: getfield y : Landroid/util/SparseBooleanArray;
    //   192: astore #17
    //   194: aload #17
    //   196: invokevirtual clear : ()V
    //   199: iconst_0
    //   200: istore #6
    //   202: iconst_0
    //   203: istore_2
    //   204: aload_0
    //   205: getfield u : Z
    //   208: ifeq -> 231
    //   211: aload_0
    //   212: getfield x : I
    //   215: istore_1
    //   216: iload #9
    //   218: iload_1
    //   219: idiv
    //   220: istore_2
    //   221: iload_1
    //   222: iload #9
    //   224: iload_1
    //   225: irem
    //   226: iload_2
    //   227: idiv
    //   228: iadd
    //   229: istore #6
    //   231: iconst_0
    //   232: istore #7
    //   234: iload #8
    //   236: istore_1
    //   237: iload #4
    //   239: istore #8
    //   241: iload #9
    //   243: istore #4
    //   245: iload_3
    //   246: istore #9
    //   248: iload #7
    //   250: iload #9
    //   252: if_icmpge -> 770
    //   255: aload #15
    //   257: iload #7
    //   259: invokevirtual get : (I)Ljava/lang/Object;
    //   262: checkcast android/support/v7/view/menu/k
    //   265: astore #18
    //   267: aload #18
    //   269: invokevirtual k : ()Z
    //   272: ifeq -> 393
    //   275: aload_0
    //   276: aload #18
    //   278: aload_0
    //   279: getfield z : Landroid/view/View;
    //   282: aload #16
    //   284: invokevirtual a : (Landroid/support/v7/view/menu/k;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   287: astore #19
    //   289: aload_0
    //   290: getfield z : Landroid/view/View;
    //   293: ifnonnull -> 302
    //   296: aload_0
    //   297: aload #19
    //   299: putfield z : Landroid/view/View;
    //   302: aload_0
    //   303: getfield u : Z
    //   306: ifeq -> 326
    //   309: iload_2
    //   310: aload #19
    //   312: iload #6
    //   314: iload_2
    //   315: iload #11
    //   317: iconst_0
    //   318: invokestatic a : (Landroid/view/View;IIII)I
    //   321: isub
    //   322: istore_2
    //   323: goto -> 335
    //   326: aload #19
    //   328: iload #11
    //   330: iload #11
    //   332: invokevirtual measure : (II)V
    //   335: aload #19
    //   337: invokevirtual getMeasuredWidth : ()I
    //   340: istore #10
    //   342: iload #4
    //   344: iload #10
    //   346: isub
    //   347: istore #4
    //   349: iload_1
    //   350: istore_3
    //   351: iload_1
    //   352: ifne -> 358
    //   355: iload #10
    //   357: istore_3
    //   358: aload #18
    //   360: invokevirtual getGroupId : ()I
    //   363: istore_1
    //   364: iload_1
    //   365: ifeq -> 378
    //   368: aload #17
    //   370: iload_1
    //   371: iconst_1
    //   372: invokevirtual put : (IZ)V
    //   375: goto -> 378
    //   378: aload #18
    //   380: iconst_1
    //   381: invokevirtual d : (Z)V
    //   384: iload #5
    //   386: istore #10
    //   388: iload_3
    //   389: istore_1
    //   390: goto -> 760
    //   393: aload #18
    //   395: invokevirtual j : ()Z
    //   398: ifeq -> 750
    //   401: aload #18
    //   403: invokevirtual getGroupId : ()I
    //   406: istore #12
    //   408: aload #17
    //   410: iload #12
    //   412: invokevirtual get : (I)Z
    //   415: istore #14
    //   417: iload #5
    //   419: ifgt -> 433
    //   422: iload #14
    //   424: ifeq -> 430
    //   427: goto -> 433
    //   430: goto -> 455
    //   433: iload #4
    //   435: ifle -> 455
    //   438: aload_0
    //   439: getfield u : Z
    //   442: ifeq -> 449
    //   445: iload_2
    //   446: ifle -> 455
    //   449: iconst_1
    //   450: istore #13
    //   452: goto -> 458
    //   455: iconst_0
    //   456: istore #13
    //   458: iload #5
    //   460: istore_3
    //   461: iload #13
    //   463: ifeq -> 615
    //   466: aload_0
    //   467: aload #18
    //   469: aload_0
    //   470: getfield z : Landroid/view/View;
    //   473: aload #16
    //   475: invokevirtual a : (Landroid/support/v7/view/menu/k;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   478: astore #19
    //   480: aload_0
    //   481: getfield z : Landroid/view/View;
    //   484: ifnonnull -> 493
    //   487: aload_0
    //   488: aload #19
    //   490: putfield z : Landroid/view/View;
    //   493: aload_0
    //   494: getfield u : Z
    //   497: ifeq -> 529
    //   500: aload #19
    //   502: iload #6
    //   504: iload_2
    //   505: iload #11
    //   507: iconst_0
    //   508: invokestatic a : (Landroid/view/View;IIII)I
    //   511: istore #5
    //   513: iload_2
    //   514: iload #5
    //   516: isub
    //   517: istore_2
    //   518: iload #5
    //   520: ifne -> 526
    //   523: iconst_0
    //   524: istore #13
    //   526: goto -> 538
    //   529: aload #19
    //   531: iload #11
    //   533: iload #11
    //   535: invokevirtual measure : (II)V
    //   538: aload #19
    //   540: invokevirtual getMeasuredWidth : ()I
    //   543: istore #10
    //   545: iload #4
    //   547: iload #10
    //   549: isub
    //   550: istore #4
    //   552: iload_1
    //   553: istore #5
    //   555: iload_1
    //   556: ifne -> 563
    //   559: iload #10
    //   561: istore #5
    //   563: aload_0
    //   564: getfield u : Z
    //   567: ifeq -> 591
    //   570: iload #4
    //   572: iflt -> 580
    //   575: iconst_1
    //   576: istore_1
    //   577: goto -> 582
    //   580: iconst_0
    //   581: istore_1
    //   582: iload #13
    //   584: iload_1
    //   585: iand
    //   586: istore #13
    //   588: goto -> 618
    //   591: iload #4
    //   593: iload #5
    //   595: iadd
    //   596: ifle -> 604
    //   599: iconst_1
    //   600: istore_1
    //   601: goto -> 606
    //   604: iconst_0
    //   605: istore_1
    //   606: iload #13
    //   608: iload_1
    //   609: iand
    //   610: istore #13
    //   612: goto -> 618
    //   615: iload_1
    //   616: istore #5
    //   618: iload #13
    //   620: ifeq -> 641
    //   623: iload #12
    //   625: ifeq -> 641
    //   628: aload #17
    //   630: iload #12
    //   632: iconst_1
    //   633: invokevirtual put : (IZ)V
    //   636: iload_3
    //   637: istore_1
    //   638: goto -> 723
    //   641: iload #14
    //   643: ifeq -> 721
    //   646: aload #17
    //   648: iload #12
    //   650: iconst_0
    //   651: invokevirtual put : (IZ)V
    //   654: iconst_0
    //   655: istore #10
    //   657: iload_3
    //   658: istore_1
    //   659: iload #10
    //   661: iload #7
    //   663: if_icmpge -> 718
    //   666: aload #15
    //   668: iload #10
    //   670: invokevirtual get : (I)Ljava/lang/Object;
    //   673: checkcast android/support/v7/view/menu/k
    //   676: astore #19
    //   678: iload_1
    //   679: istore_3
    //   680: aload #19
    //   682: invokevirtual getGroupId : ()I
    //   685: iload #12
    //   687: if_icmpne -> 710
    //   690: iload_1
    //   691: istore_3
    //   692: aload #19
    //   694: invokevirtual h : ()Z
    //   697: ifeq -> 704
    //   700: iload_1
    //   701: iconst_1
    //   702: iadd
    //   703: istore_3
    //   704: aload #19
    //   706: iconst_0
    //   707: invokevirtual d : (Z)V
    //   710: iinc #10, 1
    //   713: iload_3
    //   714: istore_1
    //   715: goto -> 659
    //   718: goto -> 723
    //   721: iload_3
    //   722: istore_1
    //   723: iload_1
    //   724: istore_3
    //   725: iload #13
    //   727: ifeq -> 734
    //   730: iload_1
    //   731: iconst_1
    //   732: isub
    //   733: istore_3
    //   734: aload #18
    //   736: iload #13
    //   738: invokevirtual d : (Z)V
    //   741: iload_3
    //   742: istore #10
    //   744: iload #5
    //   746: istore_1
    //   747: goto -> 760
    //   750: aload #18
    //   752: iconst_0
    //   753: invokevirtual d : (Z)V
    //   756: iload #5
    //   758: istore #10
    //   760: iinc #7, 1
    //   763: iload #10
    //   765: istore #5
    //   767: goto -> 248
    //   770: iconst_1
    //   771: ireturn
  }
  
  public Parcelable c() {
    g g = new g();
    g.c = this.F;
    return g;
  }
  
  public void c(boolean paramBoolean) {
    this.o = paramBoolean;
    this.p = true;
  }
  
  public boolean e() {
    return g() | h();
  }
  
  public Drawable f() {
    d d1 = this.l;
    return (d1 != null) ? d1.getDrawable() : (this.n ? this.m : null);
  }
  
  public boolean g() {
    c c1 = this.C;
    if (c1 != null) {
      q q = this.j;
      if (q != null) {
        ((View)q).removeCallbacks(c1);
        this.C = null;
        return true;
      } 
    } 
    e e1 = this.A;
    if (e1 != null) {
      e1.a();
      return true;
    } 
    return false;
  }
  
  public boolean h() {
    a a1 = this.B;
    if (a1 != null) {
      a1.a();
      return true;
    } 
    return false;
  }
  
  public boolean i() {
    return (this.C != null || j());
  }
  
  public boolean j() {
    boolean bool;
    e e1 = this.A;
    if (e1 != null && e1.c()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean k() {
    if (this.o && !j()) {
      h h = this.e;
      if (h != null && this.j != null && this.C == null && !h.j().isEmpty()) {
        this.C = new c(this, new e(this, this.d, this.e, (View)this.l, true));
        ((View)this.j).post(this.C);
        super.a(null);
        return true;
      } 
    } 
    return false;
  }
  
  private class a extends o {
    final c m;
    
    public a(c this$0, Context param1Context, v param1v, View param1View) {
      super(param1Context, (h)param1v, param1View, false, a.b.h.a.a.actionOverflowMenuStyle);
      if (!((k)param1v.getItem()).h()) {
        View view;
        c.d d2 = this$0.l;
        c.d d1 = d2;
        if (d2 == null)
          view = (View)c.c(this$0); 
        a(view);
      } 
      a(this$0.E);
    }
    
    protected void d() {
      c c1 = this.m;
      c1.B = null;
      c1.F = 0;
      super.d();
    }
  }
  
  private class b extends ActionMenuItemView.b {
    final c a;
    
    b(c this$0) {}
    
    public t a() {
      c.a a = this.a.B;
      if (a != null) {
        n n = a.b();
      } else {
        a = null;
      } 
      return (t)a;
    }
  }
  
  private class c implements Runnable {
    private c.e c;
    
    final c d;
    
    public c(c this$0, c.e param1e) {
      this.c = param1e;
    }
    
    public void run() {
      if (c.d(this.d) != null)
        c.e(this.d).a(); 
      View view = (View)c.f(this.d);
      if (view != null && view.getWindowToken() != null && this.c.f())
        this.d.A = this.c; 
      this.d.C = null;
    }
  }
  
  private class d extends o implements ActionMenuView.a {
    final c e;
    
    public d(c this$0, Context param1Context) {
      super(param1Context, null, a.b.h.a.a.actionOverflowButtonStyle);
      setClickable(true);
      setFocusable(true);
      setVisibility(0);
      setEnabled(true);
      l1.a((View)this, getContentDescription());
      setOnTouchListener(new a(this, (View)this, this$0));
    }
    
    public boolean b() {
      return false;
    }
    
    public boolean c() {
      return false;
    }
    
    public boolean performClick() {
      if (super.performClick())
        return true; 
      playSoundEffect(0);
      this.e.k();
      return true;
    }
    
    protected boolean setFrame(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      boolean bool = super.setFrame(param1Int1, param1Int2, param1Int3, param1Int4);
      Drawable drawable2 = getDrawable();
      Drawable drawable1 = getBackground();
      if (drawable2 != null && drawable1 != null) {
        int j = getWidth();
        param1Int2 = getHeight();
        param1Int1 = Math.max(j, param1Int2) / 2;
        int k = getPaddingLeft();
        int i = getPaddingRight();
        param1Int4 = getPaddingTop();
        param1Int3 = getPaddingBottom();
        i = (j + k - i) / 2;
        param1Int2 = (param1Int2 + param1Int4 - param1Int3) / 2;
        android.support.v4.graphics.drawable.a.a(drawable1, i - param1Int1, param1Int2 - param1Int1, i + param1Int1, param1Int2 + param1Int1);
      } 
      return bool;
    }
    
    class a extends l0 {
      final c.d l;
      
      a(c.d this$0, View param2View, c param2c) {
        super(param2View);
      }
      
      public t a() {
        c.e e = this.l.e.A;
        return (t)((e == null) ? null : e.b());
      }
      
      public boolean b() {
        this.l.e.k();
        return true;
      }
      
      public boolean c() {
        c c = this.l.e;
        if (c.C != null)
          return false; 
        c.g();
        return true;
      }
    }
  }
  
  class a extends l0 {
    final c.d l;
    
    a(c this$0, View param1View, c param1c) {
      super(param1View);
    }
    
    public t a() {
      c.e e = this.l.e.A;
      return (t)((e == null) ? null : e.b());
    }
    
    public boolean b() {
      this.l.e.k();
      return true;
    }
    
    public boolean c() {
      c c = this.l.e;
      if (c.C != null)
        return false; 
      c.g();
      return true;
    }
  }
  
  private class e extends o {
    final c m;
    
    public e(c this$0, Context param1Context, h param1h, View param1View, boolean param1Boolean) {
      super(param1Context, param1h, param1View, param1Boolean, a.b.h.a.a.actionOverflowMenuStyle);
      a(8388613);
      a(this$0.E);
    }
    
    protected void d() {
      if (c.a(this.m) != null)
        c.b(this.m).close(); 
      this.m.A = null;
      super.d();
    }
  }
  
  private class f implements p.a {
    final c c;
    
    f(c this$0) {}
    
    public void a(h param1h, boolean param1Boolean) {
      if (param1h instanceof v)
        param1h.m().a(false); 
      p.a a1 = this.c.d();
      if (a1 != null)
        a1.a(param1h, param1Boolean); 
    }
    
    public boolean a(h param1h) {
      boolean bool = false;
      if (param1h == null)
        return false; 
      this.c.F = ((v)param1h).getItem().getItemId();
      p.a a1 = this.c.d();
      if (a1 != null)
        bool = a1.a(param1h); 
      return bool;
    }
  }
  
  private static class g implements Parcelable {
    public static final Parcelable.Creator<g> CREATOR = new a();
    
    public int c;
    
    g() {}
    
    g(Parcel param1Parcel) {
      this.c = param1Parcel.readInt();
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeInt(this.c);
    }
    
    static final class a implements Parcelable.Creator<g> {
      public c.g createFromParcel(Parcel param2Parcel) {
        return new c.g(param2Parcel);
      }
      
      public c.g[] newArray(int param2Int) {
        return new c.g[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.Creator<g> {
    public c.g createFromParcel(Parcel param1Parcel) {
      return new c.g(param1Parcel);
    }
    
    public c.g[] newArray(int param1Int) {
      return new c.g[param1Int];
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */