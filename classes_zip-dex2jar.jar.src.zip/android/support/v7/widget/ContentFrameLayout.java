package android.support.v7.widget;

import android.content.Context;
import android.graphics.Rect;
import android.support.v4.view.u;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.widget.FrameLayout;

public class ContentFrameLayout extends FrameLayout {
  private TypedValue c;
  
  private TypedValue d;
  
  private TypedValue e;
  
  private TypedValue f;
  
  private TypedValue g;
  
  private TypedValue h;
  
  private final Rect i = new Rect();
  
  private a j;
  
  public ContentFrameLayout(Context paramContext) {
    this(paramContext, null);
  }
  
  public ContentFrameLayout(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public ContentFrameLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  public void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.i.set(paramInt1, paramInt2, paramInt3, paramInt4);
    if (u.y((View)this))
      requestLayout(); 
  }
  
  public void a(Rect paramRect) {
    fitSystemWindows(paramRect);
  }
  
  public TypedValue getFixedHeightMajor() {
    if (this.g == null)
      this.g = new TypedValue(); 
    return this.g;
  }
  
  public TypedValue getFixedHeightMinor() {
    if (this.h == null)
      this.h = new TypedValue(); 
    return this.h;
  }
  
  public TypedValue getFixedWidthMajor() {
    if (this.e == null)
      this.e = new TypedValue(); 
    return this.e;
  }
  
  public TypedValue getFixedWidthMinor() {
    if (this.f == null)
      this.f = new TypedValue(); 
    return this.f;
  }
  
  public TypedValue getMinWidthMajor() {
    if (this.c == null)
      this.c = new TypedValue(); 
    return this.c;
  }
  
  public TypedValue getMinWidthMinor() {
    if (this.d == null)
      this.d = new TypedValue(); 
    return this.d;
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    a a1 = this.j;
    if (a1 != null)
      a1.a(); 
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    a a1 = this.j;
    if (a1 != null)
      a1.onDetachedFromWindow(); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int j;
    DisplayMetrics displayMetrics = getContext().getResources().getDisplayMetrics();
    if (displayMetrics.widthPixels < displayMetrics.heightPixels) {
      j = 1;
    } else {
      j = 0;
    } 
    int i1 = View.MeasureSpec.getMode(paramInt1);
    int i2 = View.MeasureSpec.getMode(paramInt2);
    int n = 0;
    int k = n;
    int m = paramInt1;
    if (i1 == Integer.MIN_VALUE) {
      TypedValue typedValue;
      if (j) {
        typedValue = this.f;
      } else {
        typedValue = this.e;
      } 
      k = n;
      m = paramInt1;
      if (typedValue != null) {
        int i3 = typedValue.type;
        k = n;
        m = paramInt1;
        if (i3 != 0) {
          int i4 = 0;
          if (i3 == 5) {
            i4 = (int)typedValue.getDimension(displayMetrics);
          } else if (i3 == 6) {
            i4 = displayMetrics.widthPixels;
            i4 = (int)typedValue.getFraction(i4, i4);
          } 
          k = n;
          m = paramInt1;
          if (i4 > 0) {
            Rect rect = this.i;
            k = rect.left;
            m = rect.right;
            paramInt1 = View.MeasureSpec.getSize(paramInt1);
            m = View.MeasureSpec.makeMeasureSpec(Math.min(i4 - k + m, paramInt1), 1073741824);
            k = 1;
          } 
        } 
      } 
    } 
    int i = paramInt2;
    if (i2 == Integer.MIN_VALUE) {
      TypedValue typedValue;
      if (j) {
        typedValue = this.g;
      } else {
        typedValue = this.h;
      } 
      i = paramInt2;
      if (typedValue != null) {
        n = typedValue.type;
        i = paramInt2;
        if (n != 0) {
          paramInt1 = 0;
          if (n == 5) {
            paramInt1 = (int)typedValue.getDimension(displayMetrics);
          } else if (n == 6) {
            paramInt1 = displayMetrics.heightPixels;
            paramInt1 = (int)typedValue.getFraction(paramInt1, paramInt1);
          } 
          i = paramInt2;
          if (paramInt1 > 0) {
            Rect rect = this.i;
            i = rect.top;
            n = rect.bottom;
            paramInt2 = View.MeasureSpec.getSize(paramInt2);
            i = View.MeasureSpec.makeMeasureSpec(Math.min(paramInt1 - i + n, paramInt2), 1073741824);
          } 
        } 
      } 
    } 
    super.onMeasure(m, i);
    i2 = getMeasuredWidth();
    m = 0;
    n = View.MeasureSpec.makeMeasureSpec(i2, 1073741824);
    paramInt2 = m;
    paramInt1 = n;
    if (k == 0) {
      paramInt2 = m;
      paramInt1 = n;
      if (i1 == Integer.MIN_VALUE) {
        TypedValue typedValue;
        if (j) {
          typedValue = this.d;
        } else {
          typedValue = this.c;
        } 
        paramInt2 = m;
        paramInt1 = n;
        if (typedValue != null) {
          j = typedValue.type;
          paramInt2 = m;
          paramInt1 = n;
          if (j != 0) {
            paramInt1 = 0;
            if (j == 5) {
              paramInt1 = (int)typedValue.getDimension(displayMetrics);
            } else if (j == 6) {
              paramInt1 = displayMetrics.widthPixels;
              paramInt1 = (int)typedValue.getFraction(paramInt1, paramInt1);
            } 
            j = paramInt1;
            if (paramInt1 > 0) {
              Rect rect = this.i;
              j = paramInt1 - rect.left + rect.right;
            } 
            paramInt2 = m;
            paramInt1 = n;
            if (i2 < j) {
              paramInt1 = View.MeasureSpec.makeMeasureSpec(j, 1073741824);
              paramInt2 = 1;
            } 
          } 
        } 
      } 
    } 
    if (paramInt2 != 0)
      super.onMeasure(paramInt1, i); 
  }
  
  public void setAttachListener(a parama) {
    this.j = parama;
  }
  
  public static interface a {
    void a();
    
    void onDetachedFromWindow();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\ContentFrameLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */