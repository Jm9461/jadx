package android.support.v7.widget;

import android.content.res.Resources;
import android.widget.SpinnerAdapter;

public interface f1 extends SpinnerAdapter {
  Resources.Theme getDropDownViewTheme();
  
  void setDropDownViewTheme(Resources.Theme paramTheme);
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v7\widget\f1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */