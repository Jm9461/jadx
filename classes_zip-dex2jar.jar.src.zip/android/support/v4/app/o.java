package android.support.v4.app;

import android.arch.lifecycle.p;
import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

final class o implements Parcelable {
  public static final Parcelable.Creator<o> CREATOR = new a();
  
  final String c;
  
  final int d;
  
  final boolean e;
  
  final int f;
  
  final int g;
  
  final String h;
  
  final boolean i;
  
  final boolean j;
  
  final Bundle k;
  
  final boolean l;
  
  Bundle m;
  
  f n;
  
  o(Parcel paramParcel) {
    boolean bool1;
    this.c = paramParcel.readString();
    this.d = paramParcel.readInt();
    int i = paramParcel.readInt();
    boolean bool2 = true;
    if (i != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.e = bool1;
    this.f = paramParcel.readInt();
    this.g = paramParcel.readInt();
    this.h = paramParcel.readString();
    if (paramParcel.readInt() != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.i = bool1;
    if (paramParcel.readInt() != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.j = bool1;
    this.k = paramParcel.readBundle();
    if (paramParcel.readInt() != 0) {
      bool1 = bool2;
    } else {
      bool1 = false;
    } 
    this.l = bool1;
    this.m = paramParcel.readBundle();
  }
  
  o(f paramf) {
    this.c = paramf.getClass().getName();
    this.d = paramf.g;
    this.e = paramf.o;
    this.f = paramf.z;
    this.g = paramf.A;
    this.h = paramf.B;
    this.i = paramf.E;
    this.j = paramf.D;
    this.k = paramf.i;
    this.l = paramf.C;
  }
  
  public f a(j paramj, h paramh, f paramf, m paramm, p paramp) {
    if (this.n == null) {
      Context context = paramj.c();
      Bundle bundle2 = this.k;
      if (bundle2 != null)
        bundle2.setClassLoader(context.getClassLoader()); 
      if (paramh != null) {
        this.n = paramh.a(context, this.c, this.k);
      } else {
        this.n = f.a(context, this.c, this.k);
      } 
      Bundle bundle1 = this.m;
      if (bundle1 != null) {
        bundle1.setClassLoader(context.getClassLoader());
        this.n.d = this.m;
      } 
      this.n.a(this.d, paramf);
      f f2 = this.n;
      f2.o = this.e;
      f2.q = true;
      f2.z = this.f;
      f2.A = this.g;
      f2.B = this.h;
      f2.E = this.i;
      f2.D = this.j;
      f2.C = this.l;
      f2.t = paramj.d;
      if (l.G) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Instantiated fragment ");
        stringBuilder.append(this.n);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
    } 
    f f1 = this.n;
    f1.w = paramm;
    f1.x = paramp;
    return f1;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeString(this.c);
    paramParcel.writeInt(this.d);
    paramParcel.writeInt(this.e);
    paramParcel.writeInt(this.f);
    paramParcel.writeInt(this.g);
    paramParcel.writeString(this.h);
    paramParcel.writeInt(this.i);
    paramParcel.writeInt(this.j);
    paramParcel.writeBundle(this.k);
    paramParcel.writeInt(this.l);
    paramParcel.writeBundle(this.m);
  }
  
  static final class a implements Parcelable.Creator<o> {
    public o createFromParcel(Parcel param1Parcel) {
      return new o(param1Parcel);
    }
    
    public o[] newArray(int param1Int) {
      return new o[param1Int];
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */