package android.support.v4.app;

public abstract class q {
  public abstract int a();
  
  public abstract q a(int paramInt, f paramf);
  
  public abstract q a(int paramInt, f paramf, String paramString);
  
  public abstract q a(f paramf);
  
  public abstract q a(f paramf, String paramString);
  
  public abstract int b();
  
  public abstract q b(int paramInt, f paramf);
  
  public abstract void c();
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */