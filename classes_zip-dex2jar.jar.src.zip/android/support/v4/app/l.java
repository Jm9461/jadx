package android.support.v4.app;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.support.v4.view.u;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.Transformation;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

final class l extends k implements LayoutInflater.Factory2 {
  static boolean G = false;
  
  static Field H = null;
  
  static final Interpolator I = (Interpolator)new DecelerateInterpolator(2.5F);
  
  static final Interpolator J = (Interpolator)new DecelerateInterpolator(1.5F);
  
  ArrayList<f> A;
  
  Bundle B = null;
  
  SparseArray<Parcelable> C = null;
  
  ArrayList<n> D;
  
  m E;
  
  Runnable F = new a(this);
  
  ArrayList<l> c;
  
  boolean d;
  
  int e = 0;
  
  final ArrayList<f> f = new ArrayList<f>();
  
  SparseArray<f> g;
  
  ArrayList<c> h;
  
  ArrayList<f> i;
  
  ArrayList<c> j;
  
  ArrayList<Integer> k;
  
  ArrayList<k.c> l;
  
  private final CopyOnWriteArrayList<j> m = new CopyOnWriteArrayList<j>();
  
  int n = 0;
  
  j o;
  
  h p;
  
  f q;
  
  f r;
  
  boolean s;
  
  boolean t;
  
  boolean u;
  
  boolean v;
  
  String w;
  
  boolean x;
  
  ArrayList<c> y;
  
  ArrayList<Boolean> z;
  
  static {
    new AccelerateInterpolator(2.5F);
    new AccelerateInterpolator(1.5F);
  }
  
  private void A() {
    this.d = false;
    this.z.clear();
    this.y.clear();
  }
  
  private void B() {
    int i;
    SparseArray<f> sparseArray = this.g;
    if (sparseArray == null) {
      i = 0;
    } else {
      i = sparseArray.size();
    } 
    for (byte b = 0; b < i; b++) {
      f f1 = (f)this.g.valueAt(b);
      if (f1 != null)
        if (f1.g() != null) {
          int n = f1.z();
          View view = f1.g();
          Animation animation = view.getAnimation();
          if (animation != null) {
            animation.cancel();
            view.clearAnimation();
          } 
          f1.a((View)null);
          a(f1, n, 0, 0, false);
        } else if (f1.h() != null) {
          f1.h().end();
        }  
    } 
  }
  
  private void C() {
    if (this.D != null)
      while (!this.D.isEmpty())
        ((n)this.D.remove(0)).d();  
  }
  
  private int a(ArrayList<c> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, a.b.g.g.b<f> paramb) {
    int n = paramInt2;
    int i = paramInt2 - 1;
    while (i >= paramInt1) {
      boolean bool;
      c c = paramArrayList.get(i);
      boolean bool1 = ((Boolean)paramArrayList1.get(i)).booleanValue();
      if (c.g() && !c.a(paramArrayList, i + 1, paramInt2)) {
        bool = true;
      } else {
        bool = false;
      } 
      int i1 = n;
      if (bool) {
        if (this.D == null)
          this.D = new ArrayList<n>(); 
        n n1 = new n(c, bool1);
        this.D.add(n1);
        c.a(n1);
        if (bool1) {
          c.e();
        } else {
          c.b(false);
        } 
        i1 = n - 1;
        if (i != i1) {
          paramArrayList.remove(i);
          paramArrayList.add(i1, c);
        } 
        a(paramb);
      } 
      i--;
      n = i1;
    } 
    return n;
  }
  
  static g a(Context paramContext, float paramFloat1, float paramFloat2) {
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat1, paramFloat2);
    alphaAnimation.setInterpolator(J);
    alphaAnimation.setDuration(220L);
    return new g((Animation)alphaAnimation);
  }
  
  static g a(Context paramContext, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    AnimationSet animationSet = new AnimationSet(false);
    ScaleAnimation scaleAnimation = new ScaleAnimation(paramFloat1, paramFloat2, paramFloat1, paramFloat2, 1, 0.5F, 1, 0.5F);
    scaleAnimation.setInterpolator(I);
    scaleAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)scaleAnimation);
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat3, paramFloat4);
    alphaAnimation.setInterpolator(J);
    alphaAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)alphaAnimation);
    return new g((Animation)animationSet);
  }
  
  private static Animation.AnimationListener a(Animation paramAnimation) {
    IllegalAccessException illegalAccessException2 = null;
    NoSuchFieldException noSuchFieldException = null;
    try {
      if (H == null) {
        H = Animation.class.getDeclaredField("mListener");
        H.setAccessible(true);
      } 
      Animation.AnimationListener animationListener = (Animation.AnimationListener)H.get(paramAnimation);
    } catch (NoSuchFieldException noSuchFieldException1) {
      Log.e("FragmentManager", "No field with the name mListener is found in Animation class", noSuchFieldException1);
      noSuchFieldException1 = noSuchFieldException;
    } catch (IllegalAccessException illegalAccessException1) {
      Log.e("FragmentManager", "Cannot access Animation's mListener field", illegalAccessException1);
      illegalAccessException1 = illegalAccessException2;
    } 
    return (Animation.AnimationListener)illegalAccessException1;
  }
  
  private void a(a.b.g.g.b<f> paramb) {
    int i = this.n;
    if (i < 1)
      return; 
    int n = Math.min(i, 3);
    int i1 = this.f.size();
    for (i = 0; i < i1; i++) {
      f f1 = this.f.get(i);
      if (f1.c < n) {
        a(f1, n, f1.q(), f1.r(), false);
        if (f1.K != null && !f1.C && f1.P)
          paramb.add(f1); 
      } 
    } 
  }
  
  private void a(f paramf, g paramg, int paramInt) {
    View view = paramf.K;
    ViewGroup viewGroup = paramf.J;
    viewGroup.startViewTransition(view);
    paramf.d(paramInt);
    Animation animation = paramg.a;
    if (animation != null) {
      i i = new i(animation, viewGroup, view);
      paramf.a(paramf.K);
      i.setAnimationListener(new b(this, a((Animation)i), viewGroup, paramf));
      a(view, paramg);
      paramf.K.startAnimation((Animation)i);
    } else {
      Animator animator = paramg.b;
      paramf.a(paramg.b);
      animator.addListener((Animator.AnimatorListener)new c(this, viewGroup, view, paramf));
      animator.setTarget(paramf.K);
      a(paramf.K, paramg);
      animator.start();
    } 
  }
  
  private static void a(m paramm) {
    if (paramm == null)
      return; 
    List<f> list1 = paramm.b();
    if (list1 != null) {
      Iterator<f> iterator = list1.iterator();
      while (iterator.hasNext())
        ((f)iterator.next()).F = true; 
    } 
    List<m> list = paramm.a();
    if (list != null) {
      Iterator<m> iterator = list.iterator();
      while (iterator.hasNext())
        a(iterator.next()); 
    } 
  }
  
  private static void a(View paramView, g paramg) {
    if (paramView == null || paramg == null)
      return; 
    if (b(paramView, paramg)) {
      Animator animator = paramg.b;
      if (animator != null) {
        animator.addListener((Animator.AnimatorListener)new h(paramView));
      } else {
        Animation.AnimationListener animationListener = a(paramg.a);
        paramView.setLayerType(2, null);
        paramg.a.setAnimationListener(new e(paramView, animationListener));
      } 
    } 
  }
  
  private void a(RuntimeException paramRuntimeException) {
    Log.e("FragmentManager", paramRuntimeException.getMessage());
    Log.e("FragmentManager", "Activity state:");
    PrintWriter printWriter = new PrintWriter((Writer)new a.b.g.g.e("FragmentManager"));
    j j1 = this.o;
    if (j1 != null) {
      try {
        j1.a("  ", (FileDescriptor)null, printWriter, new String[0]);
      } catch (Exception exception) {
        Log.e("FragmentManager", "Failed dumping state", exception);
      } 
    } else {
      try {
        a("  ", (FileDescriptor)null, (PrintWriter)exception, new String[0]);
      } catch (Exception exception1) {
        Log.e("FragmentManager", "Failed dumping state", exception1);
      } 
    } 
    throw paramRuntimeException;
  }
  
  private void a(ArrayList<c> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: getfield D : Ljava/util/ArrayList;
    //   4: astore #7
    //   6: aload #7
    //   8: ifnonnull -> 17
    //   11: iconst_0
    //   12: istore #4
    //   14: goto -> 24
    //   17: aload #7
    //   19: invokevirtual size : ()I
    //   22: istore #4
    //   24: iconst_0
    //   25: istore_3
    //   26: iload_3
    //   27: iload #4
    //   29: if_icmpge -> 233
    //   32: aload_0
    //   33: getfield D : Ljava/util/ArrayList;
    //   36: iload_3
    //   37: invokevirtual get : (I)Ljava/lang/Object;
    //   40: checkcast android/support/v4/app/l$n
    //   43: astore #7
    //   45: aload_1
    //   46: ifnull -> 104
    //   49: aload #7
    //   51: getfield a : Z
    //   54: ifne -> 104
    //   57: aload_1
    //   58: aload #7
    //   60: getfield b : Landroid/support/v4/app/c;
    //   63: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   66: istore #5
    //   68: iload #5
    //   70: iconst_m1
    //   71: if_icmpeq -> 104
    //   74: aload_2
    //   75: iload #5
    //   77: invokevirtual get : (I)Ljava/lang/Object;
    //   80: checkcast java/lang/Boolean
    //   83: invokevirtual booleanValue : ()Z
    //   86: ifeq -> 104
    //   89: aload #7
    //   91: invokevirtual c : ()V
    //   94: iload #4
    //   96: istore #5
    //   98: iload_3
    //   99: istore #6
    //   101: goto -> 221
    //   104: aload #7
    //   106: invokevirtual e : ()Z
    //   109: ifne -> 147
    //   112: iload #4
    //   114: istore #5
    //   116: iload_3
    //   117: istore #6
    //   119: aload_1
    //   120: ifnull -> 221
    //   123: iload #4
    //   125: istore #5
    //   127: iload_3
    //   128: istore #6
    //   130: aload #7
    //   132: getfield b : Landroid/support/v4/app/c;
    //   135: aload_1
    //   136: iconst_0
    //   137: aload_1
    //   138: invokevirtual size : ()I
    //   141: invokevirtual a : (Ljava/util/ArrayList;II)Z
    //   144: ifeq -> 221
    //   147: aload_0
    //   148: getfield D : Ljava/util/ArrayList;
    //   151: iload_3
    //   152: invokevirtual remove : (I)Ljava/lang/Object;
    //   155: pop
    //   156: iload_3
    //   157: iconst_1
    //   158: isub
    //   159: istore #6
    //   161: iload #4
    //   163: iconst_1
    //   164: isub
    //   165: istore #5
    //   167: aload_1
    //   168: ifnull -> 216
    //   171: aload #7
    //   173: getfield a : Z
    //   176: ifne -> 216
    //   179: aload_1
    //   180: aload #7
    //   182: getfield b : Landroid/support/v4/app/c;
    //   185: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   188: istore_3
    //   189: iload_3
    //   190: iconst_m1
    //   191: if_icmpeq -> 216
    //   194: aload_2
    //   195: iload_3
    //   196: invokevirtual get : (I)Ljava/lang/Object;
    //   199: checkcast java/lang/Boolean
    //   202: invokevirtual booleanValue : ()Z
    //   205: ifeq -> 216
    //   208: aload #7
    //   210: invokevirtual c : ()V
    //   213: goto -> 221
    //   216: aload #7
    //   218: invokevirtual d : ()V
    //   221: iload #6
    //   223: iconst_1
    //   224: iadd
    //   225: istore_3
    //   226: iload #5
    //   228: istore #4
    //   230: goto -> 26
    //   233: return
  }
  
  private static void a(ArrayList<c> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    while (paramInt1 < paramInt2) {
      c c = paramArrayList.get(paramInt1);
      boolean bool1 = ((Boolean)paramArrayList1.get(paramInt1)).booleanValue();
      boolean bool = true;
      if (bool1) {
        c.a(-1);
        if (paramInt1 != paramInt2 - 1)
          bool = false; 
        c.b(bool);
      } else {
        c.a(1);
        c.e();
      } 
      paramInt1++;
    } 
  }
  
  static boolean a(Animator paramAnimator) {
    PropertyValuesHolder[] arrayOfPropertyValuesHolder;
    if (paramAnimator == null)
      return false; 
    if (paramAnimator instanceof ValueAnimator) {
      arrayOfPropertyValuesHolder = ((ValueAnimator)paramAnimator).getValues();
      for (byte b = 0; b < arrayOfPropertyValuesHolder.length; b++) {
        if ("alpha".equals(arrayOfPropertyValuesHolder[b].getPropertyName()))
          return true; 
      } 
    } else if (arrayOfPropertyValuesHolder instanceof AnimatorSet) {
      ArrayList<Animator> arrayList = ((AnimatorSet)arrayOfPropertyValuesHolder).getChildAnimations();
      for (byte b = 0; b < arrayList.size(); b++) {
        if (a(arrayList.get(b)))
          return true; 
      } 
    } 
    return false;
  }
  
  static boolean a(g paramg) {
    List list;
    Animation animation = paramg.a;
    if (animation instanceof AlphaAnimation)
      return true; 
    if (animation instanceof AnimationSet) {
      list = ((AnimationSet)animation).getAnimations();
      for (byte b = 0; b < list.size(); b++) {
        if (list.get(b) instanceof AlphaAnimation)
          return true; 
      } 
      return false;
    } 
    return a(((g)list).b);
  }
  
  private boolean a(String paramString, int paramInt1, int paramInt2) {
    o();
    c(true);
    f f1 = this.r;
    if (f1 != null && paramInt1 < 0 && paramString == null) {
      k k1 = f1.S();
      if (k1 != null && k1.d())
        return true; 
    } 
    boolean bool = a(this.y, this.z, paramString, paramInt1, paramInt2);
    if (bool) {
      this.d = true;
      try {
        c(this.y, this.z);
      } finally {
        A();
      } 
    } 
    n();
    y();
    return bool;
  }
  
  public static int b(int paramInt, boolean paramBoolean) {
    byte b = -1;
    if (paramInt != 4097) {
      if (paramInt != 4099) {
        if (paramInt != 8194) {
          paramInt = b;
        } else if (paramBoolean) {
          paramInt = 3;
        } else {
          paramInt = 4;
        } 
      } else if (paramBoolean) {
        paramInt = 5;
      } else {
        paramInt = 6;
      } 
    } else if (paramBoolean) {
      paramInt = 1;
    } else {
      paramInt = 2;
    } 
    return paramInt;
  }
  
  private void b(a.b.g.g.b<f> paramb) {
    int i = paramb.size();
    for (byte b1 = 0; b1 < i; b1++) {
      f f1 = (f)paramb.c(b1);
      if (!f1.m) {
        View view = f1.A();
        f1.R = view.getAlpha();
        view.setAlpha(0.0F);
      } 
    } 
  }
  
  private void b(ArrayList<c> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    boolean bool1 = ((c)paramArrayList.get(paramInt1)).s;
    ArrayList<f> arrayList = this.A;
    if (arrayList == null) {
      this.A = new ArrayList<f>();
    } else {
      arrayList.clear();
    } 
    this.A.addAll(this.f);
    f f1 = q();
    int i = paramInt1;
    boolean bool = false;
    while (true) {
      boolean bool2 = true;
      if (i < paramInt2) {
        c c = paramArrayList.get(i);
        if (!((Boolean)paramArrayList1.get(i)).booleanValue()) {
          f1 = c.a(this.A, f1);
        } else {
          f1 = c.b(this.A, f1);
        } 
        boolean bool3 = bool2;
        if (!bool)
          if (c.i) {
            bool3 = bool2;
          } else {
            bool3 = false;
          }  
        i++;
        bool = bool3;
        continue;
      } 
      this.A.clear();
      if (!bool1)
        r.a(this, paramArrayList, paramArrayList1, paramInt1, paramInt2, false); 
      a(paramArrayList, paramArrayList1, paramInt1, paramInt2);
      int n = paramInt2;
      if (bool1) {
        a.b.g.g.b<f> b = new a.b.g.g.b();
        a(b);
        n = a(paramArrayList, paramArrayList1, paramInt1, paramInt2, b);
        b(b);
      } 
      if (n != paramInt1 && bool1) {
        r.a(this, paramArrayList, paramArrayList1, paramInt1, n, true);
        a(this.n, true);
      } 
      while (paramInt1 < paramInt2) {
        c c = paramArrayList.get(paramInt1);
        if (((Boolean)paramArrayList1.get(paramInt1)).booleanValue()) {
          n = c.l;
          if (n >= 0) {
            b(n);
            c.l = -1;
          } 
        } 
        c.h();
        paramInt1++;
      } 
      if (bool)
        s(); 
      return;
    } 
  }
  
  static boolean b(View paramView, g paramg) {
    boolean bool = false;
    if (paramView == null || paramg == null)
      return false; 
    if (Build.VERSION.SDK_INT >= 19 && paramView.getLayerType() == 0 && u.v(paramView) && a(paramg))
      bool = true; 
    return bool;
  }
  
  private boolean b(ArrayList<c> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #5
    //   3: aload_0
    //   4: monitorenter
    //   5: aload_0
    //   6: getfield c : Ljava/util/ArrayList;
    //   9: ifnull -> 97
    //   12: aload_0
    //   13: getfield c : Ljava/util/ArrayList;
    //   16: invokevirtual size : ()I
    //   19: ifne -> 25
    //   22: goto -> 97
    //   25: aload_0
    //   26: getfield c : Ljava/util/ArrayList;
    //   29: invokevirtual size : ()I
    //   32: istore #4
    //   34: iconst_0
    //   35: istore_3
    //   36: iload_3
    //   37: iload #4
    //   39: if_icmpge -> 71
    //   42: iload #5
    //   44: aload_0
    //   45: getfield c : Ljava/util/ArrayList;
    //   48: iload_3
    //   49: invokevirtual get : (I)Ljava/lang/Object;
    //   52: checkcast android/support/v4/app/l$l
    //   55: aload_1
    //   56: aload_2
    //   57: invokeinterface a : (Ljava/util/ArrayList;Ljava/util/ArrayList;)Z
    //   62: ior
    //   63: istore #5
    //   65: iinc #3, 1
    //   68: goto -> 36
    //   71: aload_0
    //   72: getfield c : Ljava/util/ArrayList;
    //   75: invokevirtual clear : ()V
    //   78: aload_0
    //   79: getfield o : Landroid/support/v4/app/j;
    //   82: invokevirtual e : ()Landroid/os/Handler;
    //   85: aload_0
    //   86: getfield F : Ljava/lang/Runnable;
    //   89: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   92: aload_0
    //   93: monitorexit
    //   94: iload #5
    //   96: ireturn
    //   97: aload_0
    //   98: monitorexit
    //   99: iconst_0
    //   100: ireturn
    //   101: astore_1
    //   102: aload_0
    //   103: monitorexit
    //   104: goto -> 109
    //   107: aload_1
    //   108: athrow
    //   109: goto -> 107
    // Exception table:
    //   from	to	target	type
    //   5	22	101	finally
    //   25	34	101	finally
    //   42	65	101	finally
    //   71	94	101	finally
    //   97	99	101	finally
    //   102	104	101	finally
  }
  
  private void c(ArrayList<c> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (paramArrayList == null || paramArrayList.isEmpty())
      return; 
    if (paramArrayList1 != null && paramArrayList.size() == paramArrayList1.size()) {
      a(paramArrayList, paramArrayList1);
      int i1 = paramArrayList.size();
      int n = 0;
      int i = 0;
      while (i < i1) {
        int i3 = n;
        int i2 = i;
        if (!((c)paramArrayList.get(i)).s) {
          if (n != i)
            b(paramArrayList, paramArrayList1, n, i); 
          i3 = i + 1;
          i2 = i3;
          if (((Boolean)paramArrayList1.get(i)).booleanValue())
            while (true) {
              i2 = i3;
              if (i3 < i1) {
                i2 = i3;
                if (((Boolean)paramArrayList1.get(i3)).booleanValue()) {
                  i2 = i3;
                  if (!((c)paramArrayList.get(i3)).s) {
                    i3++;
                    continue;
                  } 
                } 
              } 
              break;
            }  
          b(paramArrayList, paramArrayList1, i, i2);
          i3 = i2;
          i2--;
        } 
        i = i2 + 1;
        n = i3;
      } 
      if (n != i1)
        b(paramArrayList, paramArrayList1, n, i1); 
      return;
    } 
    throw new IllegalStateException("Internal error with the back stack records");
  }
  
  private void c(boolean paramBoolean) {
    if (!this.d) {
      if (this.o != null) {
        if (Looper.myLooper() == this.o.e().getLooper()) {
          if (!paramBoolean)
            z(); 
          if (this.y == null) {
            this.y = new ArrayList<c>();
            this.z = new ArrayList<Boolean>();
          } 
          this.d = true;
          try {
            a((ArrayList<c>)null, (ArrayList<Boolean>)null);
            return;
          } finally {
            this.d = false;
          } 
        } 
        throw new IllegalStateException("Must be called from main thread of fragment host");
      } 
      throw new IllegalStateException("Fragment host has been destroyed");
    } 
    throw new IllegalStateException("FragmentManager is already executing transactions");
  }
  
  private void d(int paramInt) {
    try {
      this.d = true;
      a(paramInt, false);
      this.d = false;
      return;
    } finally {
      this.d = false;
    } 
  }
  
  public static int e(int paramInt) {
    boolean bool = false;
    if (paramInt != 4097) {
      if (paramInt != 4099) {
        if (paramInt != 8194) {
          paramInt = bool;
        } else {
          paramInt = 4097;
        } 
      } else {
        paramInt = 4099;
      } 
    } else {
      paramInt = 8194;
    } 
    return paramInt;
  }
  
  private f q(f paramf) {
    ViewGroup viewGroup = paramf.J;
    View view = paramf.K;
    if (viewGroup == null || view == null)
      return null; 
    for (int i = this.f.indexOf(paramf) - 1; i >= 0; i--) {
      paramf = this.f.get(i);
      if (paramf.J == viewGroup && paramf.K != null)
        return paramf; 
    } 
    return null;
  }
  
  private void y() {
    SparseArray<f> sparseArray = this.g;
    if (sparseArray != null)
      for (int i = sparseArray.size() - 1; i >= 0; i--) {
        if (this.g.valueAt(i) == null) {
          sparseArray = this.g;
          sparseArray.delete(sparseArray.keyAt(i));
        } 
      }  
  }
  
  private void z() {
    if (!c()) {
      if (this.w == null)
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Can not perform this action inside of ");
      stringBuilder.append(this.w);
      throw new IllegalStateException(stringBuilder.toString());
    } 
    throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
  }
  
  public f.g a(f paramf) {
    f.g g;
    int i = paramf.g;
    f f1 = null;
    if (i >= 0) {
      if (paramf.c > 0) {
        Bundle bundle = m(paramf);
        paramf = f1;
        if (bundle != null)
          g = new f.g(bundle); 
        return g;
      } 
      return null;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(g);
    stringBuilder.append(" is not currently in the FragmentManager");
    a(new IllegalStateException(stringBuilder.toString()));
    throw null;
  }
  
  public f a(int paramInt) {
    int i;
    for (i = this.f.size() - 1; i >= 0; i--) {
      f f1 = this.f.get(i);
      if (f1 != null && f1.z == paramInt)
        return f1; 
    } 
    SparseArray<f> sparseArray = this.g;
    if (sparseArray != null)
      for (i = sparseArray.size() - 1; i >= 0; i--) {
        f f1 = (f)this.g.valueAt(i);
        if (f1 != null && f1.z == paramInt)
          return f1; 
      }  
    return null;
  }
  
  public f a(Bundle paramBundle, String paramString) {
    int i = paramBundle.getInt(paramString, -1);
    if (i == -1)
      return null; 
    f f1 = (f)this.g.get(i);
    if (f1 != null)
      return f1; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment no longer exists for key ");
    stringBuilder.append(paramString);
    stringBuilder.append(": index ");
    stringBuilder.append(i);
    a(new IllegalStateException(stringBuilder.toString()));
    throw null;
  }
  
  public f a(String paramString) {
    if (paramString != null)
      for (int i = this.f.size() - 1; i >= 0; i--) {
        f f1 = this.f.get(i);
        if (f1 != null && paramString.equals(f1.B))
          return f1; 
      }  
    SparseArray<f> sparseArray = this.g;
    if (sparseArray != null && paramString != null)
      for (int i = sparseArray.size() - 1; i >= 0; i--) {
        f f1 = (f)this.g.valueAt(i);
        if (f1 != null && paramString.equals(f1.B))
          return f1; 
      }  
    return null;
  }
  
  g a(f paramf, int paramInt1, boolean paramBoolean, int paramInt2) {
    int i = paramf.q();
    Animation animation = paramf.a(paramInt1, paramBoolean, i);
    if (animation != null)
      return new g(animation); 
    Animator animator = paramf.b(paramInt1, paramBoolean, i);
    if (animator != null)
      return new g(animator); 
    if (i != 0) {
      boolean bool = "anim".equals(this.o.c().getResources().getResourceTypeName(i));
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool)
        try {
          Animation animation1 = AnimationUtils.loadAnimation(this.o.c(), i);
          if (animation1 != null)
            return new g(animation1); 
          bool1 = true;
        } catch (android.content.res.Resources.NotFoundException notFoundException) {
          throw notFoundException;
        } catch (RuntimeException runtimeException) {
          bool1 = bool2;
        }  
      if (!bool1)
        try {
          animator = AnimatorInflater.loadAnimator(this.o.c(), i);
          if (animator != null)
            return new g(animator); 
        } catch (RuntimeException runtimeException) {
          Animation animation1;
          if (!bool) {
            animation1 = AnimationUtils.loadAnimation(this.o.c(), i);
            if (animation1 != null)
              return new g(animation1); 
          } else {
            throw animation1;
          } 
        }  
    } 
    if (paramInt1 == 0)
      return null; 
    paramInt1 = b(paramInt1, paramBoolean);
    if (paramInt1 < 0)
      return null; 
    switch (paramInt1) {
      default:
        paramInt1 = paramInt2;
        if (paramInt2 == 0) {
          paramInt1 = paramInt2;
          if (this.o.h())
            paramInt1 = this.o.g(); 
        } 
        break;
      case 6:
        return a(this.o.c(), 1.0F, 0.0F);
      case 5:
        return a(this.o.c(), 0.0F, 1.0F);
      case 4:
        return a(this.o.c(), 1.0F, 1.075F, 1.0F, 0.0F);
      case 3:
        return a(this.o.c(), 0.975F, 1.0F, 0.0F, 1.0F);
      case 2:
        return a(this.o.c(), 1.0F, 0.975F, 1.0F, 0.0F);
      case 1:
        return a(this.o.c(), 1.125F, 1.0F, 0.0F, 1.0F);
    } 
    return (g)((paramInt1 == 0) ? null : null);
  }
  
  public q a() {
    return new c(this);
  }
  
  public void a(int paramInt1, int paramInt2) {
    if (paramInt1 >= 0) {
      a(new m(this, null, paramInt1, paramInt2), false);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void a(int paramInt, c paramc) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield j : Ljava/util/ArrayList;
    //   6: ifnonnull -> 25
    //   9: new java/util/ArrayList
    //   12: astore #5
    //   14: aload #5
    //   16: invokespecial <init> : ()V
    //   19: aload_0
    //   20: aload #5
    //   22: putfield j : Ljava/util/ArrayList;
    //   25: aload_0
    //   26: getfield j : Ljava/util/ArrayList;
    //   29: invokevirtual size : ()I
    //   32: istore #4
    //   34: iload #4
    //   36: istore_3
    //   37: iload_1
    //   38: iload #4
    //   40: if_icmpge -> 116
    //   43: getstatic android/support/v4/app/l.G : Z
    //   46: ifeq -> 103
    //   49: new java/lang/StringBuilder
    //   52: astore #5
    //   54: aload #5
    //   56: invokespecial <init> : ()V
    //   59: aload #5
    //   61: ldc_w 'Setting back stack index '
    //   64: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   67: pop
    //   68: aload #5
    //   70: iload_1
    //   71: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   74: pop
    //   75: aload #5
    //   77: ldc_w ' to '
    //   80: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   83: pop
    //   84: aload #5
    //   86: aload_2
    //   87: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   90: pop
    //   91: ldc_w 'FragmentManager'
    //   94: aload #5
    //   96: invokevirtual toString : ()Ljava/lang/String;
    //   99: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   102: pop
    //   103: aload_0
    //   104: getfield j : Ljava/util/ArrayList;
    //   107: iload_1
    //   108: aload_2
    //   109: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   112: pop
    //   113: goto -> 284
    //   116: iload_3
    //   117: iload_1
    //   118: if_icmpge -> 215
    //   121: aload_0
    //   122: getfield j : Ljava/util/ArrayList;
    //   125: aconst_null
    //   126: invokevirtual add : (Ljava/lang/Object;)Z
    //   129: pop
    //   130: aload_0
    //   131: getfield k : Ljava/util/ArrayList;
    //   134: ifnonnull -> 153
    //   137: new java/util/ArrayList
    //   140: astore #5
    //   142: aload #5
    //   144: invokespecial <init> : ()V
    //   147: aload_0
    //   148: aload #5
    //   150: putfield k : Ljava/util/ArrayList;
    //   153: getstatic android/support/v4/app/l.G : Z
    //   156: ifeq -> 197
    //   159: new java/lang/StringBuilder
    //   162: astore #5
    //   164: aload #5
    //   166: invokespecial <init> : ()V
    //   169: aload #5
    //   171: ldc_w 'Adding available back stack index '
    //   174: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   177: pop
    //   178: aload #5
    //   180: iload_3
    //   181: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   184: pop
    //   185: ldc_w 'FragmentManager'
    //   188: aload #5
    //   190: invokevirtual toString : ()Ljava/lang/String;
    //   193: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   196: pop
    //   197: aload_0
    //   198: getfield k : Ljava/util/ArrayList;
    //   201: iload_3
    //   202: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   205: invokevirtual add : (Ljava/lang/Object;)Z
    //   208: pop
    //   209: iinc #3, 1
    //   212: goto -> 116
    //   215: getstatic android/support/v4/app/l.G : Z
    //   218: ifeq -> 275
    //   221: new java/lang/StringBuilder
    //   224: astore #5
    //   226: aload #5
    //   228: invokespecial <init> : ()V
    //   231: aload #5
    //   233: ldc_w 'Adding back stack index '
    //   236: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   239: pop
    //   240: aload #5
    //   242: iload_1
    //   243: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   246: pop
    //   247: aload #5
    //   249: ldc_w ' with '
    //   252: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   255: pop
    //   256: aload #5
    //   258: aload_2
    //   259: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   262: pop
    //   263: ldc_w 'FragmentManager'
    //   266: aload #5
    //   268: invokevirtual toString : ()Ljava/lang/String;
    //   271: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   274: pop
    //   275: aload_0
    //   276: getfield j : Ljava/util/ArrayList;
    //   279: aload_2
    //   280: invokevirtual add : (Ljava/lang/Object;)Z
    //   283: pop
    //   284: aload_0
    //   285: monitorexit
    //   286: return
    //   287: astore_2
    //   288: aload_0
    //   289: monitorexit
    //   290: goto -> 295
    //   293: aload_2
    //   294: athrow
    //   295: goto -> 293
    // Exception table:
    //   from	to	target	type
    //   2	25	287	finally
    //   25	34	287	finally
    //   43	103	287	finally
    //   103	113	287	finally
    //   121	153	287	finally
    //   153	197	287	finally
    //   197	209	287	finally
    //   215	275	287	finally
    //   275	284	287	finally
    //   284	286	287	finally
    //   288	290	287	finally
  }
  
  void a(int paramInt, boolean paramBoolean) {
    if (this.o != null || paramInt == 0) {
      if (!paramBoolean && paramInt == this.n)
        return; 
      this.n = paramInt;
      if (this.g != null) {
        int i = this.f.size();
        for (paramInt = 0; paramInt < i; paramInt++)
          i(this.f.get(paramInt)); 
        i = this.g.size();
        for (paramInt = 0; paramInt < i; paramInt++) {
          f f1 = (f)this.g.valueAt(paramInt);
          if (f1 != null && (f1.n || f1.D) && !f1.P)
            i(f1); 
        } 
        x();
        if (this.s) {
          j j1 = this.o;
          if (j1 != null && this.n == 4) {
            j1.i();
            this.s = false;
          } 
        } 
      } 
      return;
    } 
    throw new IllegalStateException("No activity");
  }
  
  public void a(Configuration paramConfiguration) {
    for (byte b = 0; b < this.f.size(); b++) {
      f f1 = this.f.get(b);
      if (f1 != null)
        f1.a(paramConfiguration); 
    } 
  }
  
  public void a(Bundle paramBundle, String paramString, f paramf) {
    int i = paramf.g;
    if (i >= 0) {
      paramBundle.putInt(paramString, i);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramf);
    stringBuilder.append(" is not currently in the FragmentManager");
    a(new IllegalStateException(stringBuilder.toString()));
    throw null;
  }
  
  void a(Parcelable<m> paramParcelable, m paramm) {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull -> 5
    //   4: return
    //   5: aload_1
    //   6: checkcast android/support/v4/app/n
    //   9: astore #9
    //   11: aload #9
    //   13: getfield c : [Landroid/support/v4/app/o;
    //   16: ifnonnull -> 20
    //   19: return
    //   20: aload_2
    //   21: ifnull -> 330
    //   24: aload_2
    //   25: invokevirtual b : ()Ljava/util/List;
    //   28: astore #8
    //   30: aload_2
    //   31: invokevirtual a : ()Ljava/util/List;
    //   34: astore_1
    //   35: aload_2
    //   36: invokevirtual c : ()Ljava/util/List;
    //   39: astore #6
    //   41: aload #8
    //   43: ifnull -> 57
    //   46: aload #8
    //   48: invokeinterface size : ()I
    //   53: istore_3
    //   54: goto -> 59
    //   57: iconst_0
    //   58: istore_3
    //   59: iconst_0
    //   60: istore #4
    //   62: iload #4
    //   64: iload_3
    //   65: if_icmpge -> 327
    //   68: aload #8
    //   70: iload #4
    //   72: invokeinterface get : (I)Ljava/lang/Object;
    //   77: checkcast android/support/v4/app/f
    //   80: astore #7
    //   82: getstatic android/support/v4/app/l.G : Z
    //   85: ifeq -> 126
    //   88: new java/lang/StringBuilder
    //   91: dup
    //   92: invokespecial <init> : ()V
    //   95: astore #10
    //   97: aload #10
    //   99: ldc_w 'restoreAllState: re-attaching retained '
    //   102: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   105: pop
    //   106: aload #10
    //   108: aload #7
    //   110: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   113: pop
    //   114: ldc_w 'FragmentManager'
    //   117: aload #10
    //   119: invokevirtual toString : ()Ljava/lang/String;
    //   122: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   125: pop
    //   126: iconst_0
    //   127: istore #5
    //   129: aload #9
    //   131: getfield c : [Landroid/support/v4/app/o;
    //   134: astore #10
    //   136: iload #5
    //   138: aload #10
    //   140: arraylength
    //   141: if_icmpge -> 166
    //   144: aload #10
    //   146: iload #5
    //   148: aaload
    //   149: getfield d : I
    //   152: aload #7
    //   154: getfield g : I
    //   157: if_icmpeq -> 166
    //   160: iinc #5, 1
    //   163: goto -> 129
    //   166: aload #9
    //   168: getfield c : [Landroid/support/v4/app/o;
    //   171: astore #10
    //   173: iload #5
    //   175: aload #10
    //   177: arraylength
    //   178: if_icmpeq -> 284
    //   181: aload #10
    //   183: iload #5
    //   185: aaload
    //   186: astore #10
    //   188: aload #10
    //   190: aload #7
    //   192: putfield n : Landroid/support/v4/app/f;
    //   195: aload #7
    //   197: aconst_null
    //   198: putfield e : Landroid/util/SparseArray;
    //   201: aload #7
    //   203: iconst_0
    //   204: putfield s : I
    //   207: aload #7
    //   209: iconst_0
    //   210: putfield p : Z
    //   213: aload #7
    //   215: iconst_0
    //   216: putfield m : Z
    //   219: aload #7
    //   221: aconst_null
    //   222: putfield j : Landroid/support/v4/app/f;
    //   225: aload #10
    //   227: getfield m : Landroid/os/Bundle;
    //   230: astore #11
    //   232: aload #11
    //   234: ifnull -> 278
    //   237: aload #11
    //   239: aload_0
    //   240: getfield o : Landroid/support/v4/app/j;
    //   243: invokevirtual c : ()Landroid/content/Context;
    //   246: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   249: invokevirtual setClassLoader : (Ljava/lang/ClassLoader;)V
    //   252: aload #7
    //   254: aload #10
    //   256: getfield m : Landroid/os/Bundle;
    //   259: ldc_w 'android:view_state'
    //   262: invokevirtual getSparseParcelableArray : (Ljava/lang/String;)Landroid/util/SparseArray;
    //   265: putfield e : Landroid/util/SparseArray;
    //   268: aload #7
    //   270: aload #10
    //   272: getfield m : Landroid/os/Bundle;
    //   275: putfield d : Landroid/os/Bundle;
    //   278: iinc #4, 1
    //   281: goto -> 62
    //   284: new java/lang/StringBuilder
    //   287: dup
    //   288: invokespecial <init> : ()V
    //   291: astore_1
    //   292: aload_1
    //   293: ldc_w 'Could not find active fragment with index '
    //   296: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   299: pop
    //   300: aload_1
    //   301: aload #7
    //   303: getfield g : I
    //   306: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   309: pop
    //   310: aload_0
    //   311: new java/lang/IllegalStateException
    //   314: dup
    //   315: aload_1
    //   316: invokevirtual toString : ()Ljava/lang/String;
    //   319: invokespecial <init> : (Ljava/lang/String;)V
    //   322: invokespecial a : (Ljava/lang/RuntimeException;)V
    //   325: aconst_null
    //   326: athrow
    //   327: goto -> 335
    //   330: aconst_null
    //   331: astore #6
    //   333: aconst_null
    //   334: astore_1
    //   335: aload_0
    //   336: new android/util/SparseArray
    //   339: dup
    //   340: aload #9
    //   342: getfield c : [Landroid/support/v4/app/o;
    //   345: arraylength
    //   346: invokespecial <init> : (I)V
    //   349: putfield g : Landroid/util/SparseArray;
    //   352: iconst_0
    //   353: istore_3
    //   354: aload #9
    //   356: getfield c : [Landroid/support/v4/app/o;
    //   359: astore #7
    //   361: iload_3
    //   362: aload #7
    //   364: arraylength
    //   365: if_icmpge -> 560
    //   368: aload #7
    //   370: iload_3
    //   371: aaload
    //   372: astore #10
    //   374: aload #10
    //   376: ifnull -> 554
    //   379: aconst_null
    //   380: astore #8
    //   382: aload #8
    //   384: astore #7
    //   386: aload_1
    //   387: ifnull -> 416
    //   390: aload #8
    //   392: astore #7
    //   394: iload_3
    //   395: aload_1
    //   396: invokeinterface size : ()I
    //   401: if_icmpge -> 416
    //   404: aload_1
    //   405: iload_3
    //   406: invokeinterface get : (I)Ljava/lang/Object;
    //   411: checkcast android/support/v4/app/m
    //   414: astore #7
    //   416: aload #6
    //   418: ifnull -> 448
    //   421: iload_3
    //   422: aload #6
    //   424: invokeinterface size : ()I
    //   429: if_icmpge -> 448
    //   432: aload #6
    //   434: iload_3
    //   435: invokeinterface get : (I)Ljava/lang/Object;
    //   440: checkcast android/arch/lifecycle/p
    //   443: astore #8
    //   445: goto -> 451
    //   448: aconst_null
    //   449: astore #8
    //   451: aload #10
    //   453: aload_0
    //   454: getfield o : Landroid/support/v4/app/j;
    //   457: aload_0
    //   458: getfield p : Landroid/support/v4/app/h;
    //   461: aload_0
    //   462: getfield q : Landroid/support/v4/app/f;
    //   465: aload #7
    //   467: aload #8
    //   469: invokevirtual a : (Landroid/support/v4/app/j;Landroid/support/v4/app/h;Landroid/support/v4/app/f;Landroid/support/v4/app/m;Landroid/arch/lifecycle/p;)Landroid/support/v4/app/f;
    //   472: astore #8
    //   474: getstatic android/support/v4/app/l.G : Z
    //   477: ifeq -> 534
    //   480: new java/lang/StringBuilder
    //   483: dup
    //   484: invokespecial <init> : ()V
    //   487: astore #7
    //   489: aload #7
    //   491: ldc_w 'restoreAllState: active #'
    //   494: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   497: pop
    //   498: aload #7
    //   500: iload_3
    //   501: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   504: pop
    //   505: aload #7
    //   507: ldc_w ': '
    //   510: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   513: pop
    //   514: aload #7
    //   516: aload #8
    //   518: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   521: pop
    //   522: ldc_w 'FragmentManager'
    //   525: aload #7
    //   527: invokevirtual toString : ()Ljava/lang/String;
    //   530: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   533: pop
    //   534: aload_0
    //   535: getfield g : Landroid/util/SparseArray;
    //   538: aload #8
    //   540: getfield g : I
    //   543: aload #8
    //   545: invokevirtual put : (ILjava/lang/Object;)V
    //   548: aload #10
    //   550: aconst_null
    //   551: putfield n : Landroid/support/v4/app/f;
    //   554: iinc #3, 1
    //   557: goto -> 354
    //   560: aload_2
    //   561: ifnull -> 702
    //   564: aload_2
    //   565: invokevirtual b : ()Ljava/util/List;
    //   568: astore_1
    //   569: aload_1
    //   570: ifnull -> 583
    //   573: aload_1
    //   574: invokeinterface size : ()I
    //   579: istore_3
    //   580: goto -> 585
    //   583: iconst_0
    //   584: istore_3
    //   585: iconst_0
    //   586: istore #4
    //   588: iload #4
    //   590: iload_3
    //   591: if_icmpge -> 702
    //   594: aload_1
    //   595: iload #4
    //   597: invokeinterface get : (I)Ljava/lang/Object;
    //   602: checkcast android/support/v4/app/f
    //   605: astore #6
    //   607: aload #6
    //   609: getfield k : I
    //   612: istore #5
    //   614: iload #5
    //   616: iflt -> 696
    //   619: aload #6
    //   621: aload_0
    //   622: getfield g : Landroid/util/SparseArray;
    //   625: iload #5
    //   627: invokevirtual get : (I)Ljava/lang/Object;
    //   630: checkcast android/support/v4/app/f
    //   633: putfield j : Landroid/support/v4/app/f;
    //   636: aload #6
    //   638: getfield j : Landroid/support/v4/app/f;
    //   641: ifnonnull -> 696
    //   644: new java/lang/StringBuilder
    //   647: dup
    //   648: invokespecial <init> : ()V
    //   651: astore_2
    //   652: aload_2
    //   653: ldc_w 'Re-attaching retained fragment '
    //   656: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   659: pop
    //   660: aload_2
    //   661: aload #6
    //   663: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   666: pop
    //   667: aload_2
    //   668: ldc_w ' target no longer exists: '
    //   671: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   674: pop
    //   675: aload_2
    //   676: aload #6
    //   678: getfield k : I
    //   681: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   684: pop
    //   685: ldc_w 'FragmentManager'
    //   688: aload_2
    //   689: invokevirtual toString : ()Ljava/lang/String;
    //   692: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   695: pop
    //   696: iinc #4, 1
    //   699: goto -> 588
    //   702: aload_0
    //   703: getfield f : Ljava/util/ArrayList;
    //   706: invokevirtual clear : ()V
    //   709: aload #9
    //   711: getfield d : [I
    //   714: ifnull -> 903
    //   717: iconst_0
    //   718: istore_3
    //   719: aload #9
    //   721: getfield d : [I
    //   724: astore_1
    //   725: iload_3
    //   726: aload_1
    //   727: arraylength
    //   728: if_icmpge -> 903
    //   731: aload_0
    //   732: getfield g : Landroid/util/SparseArray;
    //   735: aload_1
    //   736: iload_3
    //   737: iaload
    //   738: invokevirtual get : (I)Ljava/lang/Object;
    //   741: checkcast android/support/v4/app/f
    //   744: astore_1
    //   745: aload_1
    //   746: ifnull -> 858
    //   749: aload_1
    //   750: iconst_1
    //   751: putfield m : Z
    //   754: getstatic android/support/v4/app/l.G : Z
    //   757: ifeq -> 807
    //   760: new java/lang/StringBuilder
    //   763: dup
    //   764: invokespecial <init> : ()V
    //   767: astore_2
    //   768: aload_2
    //   769: ldc_w 'restoreAllState: added #'
    //   772: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   775: pop
    //   776: aload_2
    //   777: iload_3
    //   778: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   781: pop
    //   782: aload_2
    //   783: ldc_w ': '
    //   786: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   789: pop
    //   790: aload_2
    //   791: aload_1
    //   792: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   795: pop
    //   796: ldc_w 'FragmentManager'
    //   799: aload_2
    //   800: invokevirtual toString : ()Ljava/lang/String;
    //   803: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   806: pop
    //   807: aload_0
    //   808: getfield f : Ljava/util/ArrayList;
    //   811: aload_1
    //   812: invokevirtual contains : (Ljava/lang/Object;)Z
    //   815: ifne -> 847
    //   818: aload_0
    //   819: getfield f : Ljava/util/ArrayList;
    //   822: astore_2
    //   823: aload_2
    //   824: monitorenter
    //   825: aload_0
    //   826: getfield f : Ljava/util/ArrayList;
    //   829: aload_1
    //   830: invokevirtual add : (Ljava/lang/Object;)Z
    //   833: pop
    //   834: aload_2
    //   835: monitorexit
    //   836: iinc #3, 1
    //   839: goto -> 719
    //   842: astore_1
    //   843: aload_2
    //   844: monitorexit
    //   845: aload_1
    //   846: athrow
    //   847: new java/lang/IllegalStateException
    //   850: dup
    //   851: ldc_w 'Already added!'
    //   854: invokespecial <init> : (Ljava/lang/String;)V
    //   857: athrow
    //   858: new java/lang/StringBuilder
    //   861: dup
    //   862: invokespecial <init> : ()V
    //   865: astore_1
    //   866: aload_1
    //   867: ldc_w 'No instantiated fragment for index #'
    //   870: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   873: pop
    //   874: aload_1
    //   875: aload #9
    //   877: getfield d : [I
    //   880: iload_3
    //   881: iaload
    //   882: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   885: pop
    //   886: aload_0
    //   887: new java/lang/IllegalStateException
    //   890: dup
    //   891: aload_1
    //   892: invokevirtual toString : ()Ljava/lang/String;
    //   895: invokespecial <init> : (Ljava/lang/String;)V
    //   898: invokespecial a : (Ljava/lang/RuntimeException;)V
    //   901: aconst_null
    //   902: athrow
    //   903: aload #9
    //   905: getfield e : [Landroid/support/v4/app/d;
    //   908: astore_1
    //   909: aload_1
    //   910: ifnull -> 1085
    //   913: aload_0
    //   914: new java/util/ArrayList
    //   917: dup
    //   918: aload_1
    //   919: arraylength
    //   920: invokespecial <init> : (I)V
    //   923: putfield h : Ljava/util/ArrayList;
    //   926: iconst_0
    //   927: istore_3
    //   928: aload #9
    //   930: getfield e : [Landroid/support/v4/app/d;
    //   933: astore_1
    //   934: iload_3
    //   935: aload_1
    //   936: arraylength
    //   937: if_icmpge -> 1082
    //   940: aload_1
    //   941: iload_3
    //   942: aaload
    //   943: aload_0
    //   944: invokevirtual a : (Landroid/support/v4/app/l;)Landroid/support/v4/app/c;
    //   947: astore_1
    //   948: getstatic android/support/v4/app/l.G : Z
    //   951: ifeq -> 1049
    //   954: new java/lang/StringBuilder
    //   957: dup
    //   958: invokespecial <init> : ()V
    //   961: astore_2
    //   962: aload_2
    //   963: ldc_w 'restoreAllState: back stack #'
    //   966: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   969: pop
    //   970: aload_2
    //   971: iload_3
    //   972: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   975: pop
    //   976: aload_2
    //   977: ldc_w ' (index '
    //   980: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   983: pop
    //   984: aload_2
    //   985: aload_1
    //   986: getfield l : I
    //   989: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   992: pop
    //   993: aload_2
    //   994: ldc_w '): '
    //   997: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1000: pop
    //   1001: aload_2
    //   1002: aload_1
    //   1003: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1006: pop
    //   1007: ldc_w 'FragmentManager'
    //   1010: aload_2
    //   1011: invokevirtual toString : ()Ljava/lang/String;
    //   1014: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1017: pop
    //   1018: new java/io/PrintWriter
    //   1021: dup
    //   1022: new a/b/g/g/e
    //   1025: dup
    //   1026: ldc_w 'FragmentManager'
    //   1029: invokespecial <init> : (Ljava/lang/String;)V
    //   1032: invokespecial <init> : (Ljava/io/Writer;)V
    //   1035: astore_2
    //   1036: aload_1
    //   1037: ldc_w '  '
    //   1040: aload_2
    //   1041: iconst_0
    //   1042: invokevirtual a : (Ljava/lang/String;Ljava/io/PrintWriter;Z)V
    //   1045: aload_2
    //   1046: invokevirtual close : ()V
    //   1049: aload_0
    //   1050: getfield h : Ljava/util/ArrayList;
    //   1053: aload_1
    //   1054: invokevirtual add : (Ljava/lang/Object;)Z
    //   1057: pop
    //   1058: aload_1
    //   1059: getfield l : I
    //   1062: istore #4
    //   1064: iload #4
    //   1066: iflt -> 1076
    //   1069: aload_0
    //   1070: iload #4
    //   1072: aload_1
    //   1073: invokevirtual a : (ILandroid/support/v4/app/c;)V
    //   1076: iinc #3, 1
    //   1079: goto -> 928
    //   1082: goto -> 1090
    //   1085: aload_0
    //   1086: aconst_null
    //   1087: putfield h : Ljava/util/ArrayList;
    //   1090: aload #9
    //   1092: getfield f : I
    //   1095: istore_3
    //   1096: iload_3
    //   1097: iflt -> 1115
    //   1100: aload_0
    //   1101: aload_0
    //   1102: getfield g : Landroid/util/SparseArray;
    //   1105: iload_3
    //   1106: invokevirtual get : (I)Ljava/lang/Object;
    //   1109: checkcast android/support/v4/app/f
    //   1112: putfield r : Landroid/support/v4/app/f;
    //   1115: aload_0
    //   1116: aload #9
    //   1118: getfield g : I
    //   1121: putfield e : I
    //   1124: return
    // Exception table:
    //   from	to	target	type
    //   825	836	842	finally
    //   843	845	842	finally
  }
  
  void a(c paramc) {
    if (this.h == null)
      this.h = new ArrayList<c>(); 
    this.h.add(paramc);
  }
  
  void a(c paramc, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    if (paramBoolean1) {
      paramc.b(paramBoolean3);
    } else {
      paramc.e();
    } 
    ArrayList<c> arrayList = new ArrayList(1);
    ArrayList<Boolean> arrayList1 = new ArrayList(1);
    arrayList.add(paramc);
    arrayList1.add(Boolean.valueOf(paramBoolean1));
    if (paramBoolean2)
      r.a(this, arrayList, arrayList1, 0, 1, true); 
    if (paramBoolean3)
      a(this.n, true); 
    SparseArray<f> sparseArray = this.g;
    if (sparseArray != null) {
      int i = sparseArray.size();
      for (byte b = 0; b < i; b++) {
        f f1 = (f)this.g.valueAt(b);
        if (f1 != null && f1.K != null && f1.P && paramc.b(f1.A)) {
          float f2 = f1.R;
          if (f2 > 0.0F)
            f1.K.setAlpha(f2); 
          if (paramBoolean3) {
            f1.R = 0.0F;
          } else {
            f1.R = -1.0F;
            f1.P = false;
          } 
        } 
      } 
    } 
  }
  
  void a(f paramf, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: getfield m : Z
    //   4: istore #9
    //   6: iconst_1
    //   7: istore #8
    //   9: iload #9
    //   11: ifeq -> 27
    //   14: aload_1
    //   15: getfield D : Z
    //   18: ifeq -> 24
    //   21: goto -> 27
    //   24: goto -> 41
    //   27: iload_2
    //   28: istore #6
    //   30: iload #6
    //   32: istore_2
    //   33: iload #6
    //   35: iconst_1
    //   36: if_icmple -> 41
    //   39: iconst_1
    //   40: istore_2
    //   41: iload_2
    //   42: istore #6
    //   44: aload_1
    //   45: getfield n : Z
    //   48: ifeq -> 90
    //   51: aload_1
    //   52: getfield c : I
    //   55: istore #7
    //   57: iload_2
    //   58: istore #6
    //   60: iload_2
    //   61: iload #7
    //   63: if_icmple -> 90
    //   66: iload #7
    //   68: ifne -> 84
    //   71: aload_1
    //   72: invokevirtual G : ()Z
    //   75: ifeq -> 84
    //   78: iconst_1
    //   79: istore #6
    //   81: goto -> 90
    //   84: aload_1
    //   85: getfield c : I
    //   88: istore #6
    //   90: iload #6
    //   92: istore_2
    //   93: aload_1
    //   94: getfield M : Z
    //   97: ifeq -> 122
    //   100: iload #6
    //   102: istore_2
    //   103: aload_1
    //   104: getfield c : I
    //   107: iconst_3
    //   108: if_icmpge -> 122
    //   111: iload #6
    //   113: istore_2
    //   114: iload #6
    //   116: iconst_2
    //   117: if_icmple -> 122
    //   120: iconst_2
    //   121: istore_2
    //   122: aload_1
    //   123: getfield c : I
    //   126: istore #6
    //   128: iload #6
    //   130: iload_2
    //   131: if_icmpgt -> 1379
    //   134: aload_1
    //   135: getfield o : Z
    //   138: ifeq -> 149
    //   141: aload_1
    //   142: getfield p : Z
    //   145: ifne -> 149
    //   148: return
    //   149: aload_1
    //   150: invokevirtual g : ()Landroid/view/View;
    //   153: ifnonnull -> 163
    //   156: aload_1
    //   157: invokevirtual h : ()Landroid/animation/Animator;
    //   160: ifnull -> 185
    //   163: aload_1
    //   164: aconst_null
    //   165: invokevirtual a : (Landroid/view/View;)V
    //   168: aload_1
    //   169: aconst_null
    //   170: invokevirtual a : (Landroid/animation/Animator;)V
    //   173: aload_0
    //   174: aload_1
    //   175: aload_1
    //   176: invokevirtual z : ()I
    //   179: iconst_0
    //   180: iconst_0
    //   181: iconst_1
    //   182: invokevirtual a : (Landroid/support/v4/app/f;IIIZ)V
    //   185: aload_1
    //   186: getfield c : I
    //   189: istore #6
    //   191: iload #6
    //   193: ifeq -> 224
    //   196: iload_2
    //   197: istore_3
    //   198: iload #6
    //   200: iconst_1
    //   201: if_icmpeq -> 779
    //   204: iload_2
    //   205: istore #4
    //   207: iload #6
    //   209: iconst_2
    //   210: if_icmpeq -> 1237
    //   213: iload_2
    //   214: istore_3
    //   215: iload #6
    //   217: iconst_3
    //   218: if_icmpeq -> 1302
    //   221: goto -> 1374
    //   224: iload_2
    //   225: istore_3
    //   226: iload_2
    //   227: ifle -> 779
    //   230: getstatic android/support/v4/app/l.G : Z
    //   233: ifeq -> 273
    //   236: new java/lang/StringBuilder
    //   239: dup
    //   240: invokespecial <init> : ()V
    //   243: astore #10
    //   245: aload #10
    //   247: ldc_w 'moveto CREATED: '
    //   250: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   253: pop
    //   254: aload #10
    //   256: aload_1
    //   257: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   260: pop
    //   261: ldc_w 'FragmentManager'
    //   264: aload #10
    //   266: invokevirtual toString : ()Ljava/lang/String;
    //   269: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   272: pop
    //   273: aload_1
    //   274: getfield d : Landroid/os/Bundle;
    //   277: astore #10
    //   279: iload_2
    //   280: istore_3
    //   281: aload #10
    //   283: ifnull -> 418
    //   286: aload #10
    //   288: aload_0
    //   289: getfield o : Landroid/support/v4/app/j;
    //   292: invokevirtual c : ()Landroid/content/Context;
    //   295: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   298: invokevirtual setClassLoader : (Ljava/lang/ClassLoader;)V
    //   301: aload_1
    //   302: aload_1
    //   303: getfield d : Landroid/os/Bundle;
    //   306: ldc_w 'android:view_state'
    //   309: invokevirtual getSparseParcelableArray : (Ljava/lang/String;)Landroid/util/SparseArray;
    //   312: putfield e : Landroid/util/SparseArray;
    //   315: aload_1
    //   316: aload_0
    //   317: aload_1
    //   318: getfield d : Landroid/os/Bundle;
    //   321: ldc_w 'android:target_state'
    //   324: invokevirtual a : (Landroid/os/Bundle;Ljava/lang/String;)Landroid/support/v4/app/f;
    //   327: putfield j : Landroid/support/v4/app/f;
    //   330: aload_1
    //   331: getfield j : Landroid/support/v4/app/f;
    //   334: ifnull -> 352
    //   337: aload_1
    //   338: aload_1
    //   339: getfield d : Landroid/os/Bundle;
    //   342: ldc_w 'android:target_req_state'
    //   345: iconst_0
    //   346: invokevirtual getInt : (Ljava/lang/String;I)I
    //   349: putfield l : I
    //   352: aload_1
    //   353: getfield f : Ljava/lang/Boolean;
    //   356: astore #10
    //   358: aload #10
    //   360: ifnull -> 380
    //   363: aload_1
    //   364: aload #10
    //   366: invokevirtual booleanValue : ()Z
    //   369: putfield N : Z
    //   372: aload_1
    //   373: aconst_null
    //   374: putfield f : Ljava/lang/Boolean;
    //   377: goto -> 395
    //   380: aload_1
    //   381: aload_1
    //   382: getfield d : Landroid/os/Bundle;
    //   385: ldc_w 'android:user_visible_hint'
    //   388: iconst_1
    //   389: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   392: putfield N : Z
    //   395: iload_2
    //   396: istore_3
    //   397: aload_1
    //   398: getfield N : Z
    //   401: ifne -> 418
    //   404: aload_1
    //   405: iconst_1
    //   406: putfield M : Z
    //   409: iload_2
    //   410: istore_3
    //   411: iload_2
    //   412: iconst_2
    //   413: if_icmple -> 418
    //   416: iconst_2
    //   417: istore_3
    //   418: aload_0
    //   419: getfield o : Landroid/support/v4/app/j;
    //   422: astore #10
    //   424: aload_1
    //   425: aload #10
    //   427: putfield u : Landroid/support/v4/app/j;
    //   430: aload_0
    //   431: getfield q : Landroid/support/v4/app/f;
    //   434: astore #11
    //   436: aload_1
    //   437: aload #11
    //   439: putfield y : Landroid/support/v4/app/f;
    //   442: aload #11
    //   444: ifnull -> 457
    //   447: aload #11
    //   449: getfield v : Landroid/support/v4/app/l;
    //   452: astore #10
    //   454: goto -> 464
    //   457: aload #10
    //   459: invokevirtual d : ()Landroid/support/v4/app/l;
    //   462: astore #10
    //   464: aload_1
    //   465: aload #10
    //   467: putfield t : Landroid/support/v4/app/l;
    //   470: aload_1
    //   471: getfield j : Landroid/support/v4/app/f;
    //   474: astore #10
    //   476: aload #10
    //   478: ifnull -> 596
    //   481: aload_0
    //   482: getfield g : Landroid/util/SparseArray;
    //   485: aload #10
    //   487: getfield g : I
    //   490: invokevirtual get : (I)Ljava/lang/Object;
    //   493: astore #10
    //   495: aload_1
    //   496: getfield j : Landroid/support/v4/app/f;
    //   499: astore #11
    //   501: aload #10
    //   503: aload #11
    //   505: if_acmpne -> 530
    //   508: aload #11
    //   510: getfield c : I
    //   513: iconst_1
    //   514: if_icmpge -> 596
    //   517: aload_0
    //   518: aload #11
    //   520: iconst_1
    //   521: iconst_0
    //   522: iconst_0
    //   523: iconst_1
    //   524: invokevirtual a : (Landroid/support/v4/app/f;IIIZ)V
    //   527: goto -> 596
    //   530: new java/lang/StringBuilder
    //   533: dup
    //   534: invokespecial <init> : ()V
    //   537: astore #10
    //   539: aload #10
    //   541: ldc_w 'Fragment '
    //   544: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   547: pop
    //   548: aload #10
    //   550: aload_1
    //   551: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   554: pop
    //   555: aload #10
    //   557: ldc_w ' declared target fragment '
    //   560: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   563: pop
    //   564: aload #10
    //   566: aload_1
    //   567: getfield j : Landroid/support/v4/app/f;
    //   570: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   573: pop
    //   574: aload #10
    //   576: ldc_w ' that does not belong to this FragmentManager!'
    //   579: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   582: pop
    //   583: new java/lang/IllegalStateException
    //   586: dup
    //   587: aload #10
    //   589: invokevirtual toString : ()Ljava/lang/String;
    //   592: invokespecial <init> : (Ljava/lang/String;)V
    //   595: athrow
    //   596: aload_0
    //   597: aload_1
    //   598: aload_0
    //   599: getfield o : Landroid/support/v4/app/j;
    //   602: invokevirtual c : ()Landroid/content/Context;
    //   605: iconst_0
    //   606: invokevirtual b : (Landroid/support/v4/app/f;Landroid/content/Context;Z)V
    //   609: aload_1
    //   610: iconst_0
    //   611: putfield I : Z
    //   614: aload_1
    //   615: aload_0
    //   616: getfield o : Landroid/support/v4/app/j;
    //   619: invokevirtual c : ()Landroid/content/Context;
    //   622: invokevirtual a : (Landroid/content/Context;)V
    //   625: aload_1
    //   626: getfield I : Z
    //   629: ifeq -> 732
    //   632: aload_1
    //   633: getfield y : Landroid/support/v4/app/f;
    //   636: astore #10
    //   638: aload #10
    //   640: ifnonnull -> 654
    //   643: aload_0
    //   644: getfield o : Landroid/support/v4/app/j;
    //   647: aload_1
    //   648: invokevirtual a : (Landroid/support/v4/app/f;)V
    //   651: goto -> 660
    //   654: aload #10
    //   656: aload_1
    //   657: invokevirtual a : (Landroid/support/v4/app/f;)V
    //   660: aload_0
    //   661: aload_1
    //   662: aload_0
    //   663: getfield o : Landroid/support/v4/app/j;
    //   666: invokevirtual c : ()Landroid/content/Context;
    //   669: iconst_0
    //   670: invokevirtual a : (Landroid/support/v4/app/f;Landroid/content/Context;Z)V
    //   673: aload_1
    //   674: getfield T : Z
    //   677: ifne -> 711
    //   680: aload_0
    //   681: aload_1
    //   682: aload_1
    //   683: getfield d : Landroid/os/Bundle;
    //   686: iconst_0
    //   687: invokevirtual c : (Landroid/support/v4/app/f;Landroid/os/Bundle;Z)V
    //   690: aload_1
    //   691: aload_1
    //   692: getfield d : Landroid/os/Bundle;
    //   695: invokevirtual h : (Landroid/os/Bundle;)V
    //   698: aload_0
    //   699: aload_1
    //   700: aload_1
    //   701: getfield d : Landroid/os/Bundle;
    //   704: iconst_0
    //   705: invokevirtual b : (Landroid/support/v4/app/f;Landroid/os/Bundle;Z)V
    //   708: goto -> 724
    //   711: aload_1
    //   712: aload_1
    //   713: getfield d : Landroid/os/Bundle;
    //   716: invokevirtual k : (Landroid/os/Bundle;)V
    //   719: aload_1
    //   720: iconst_1
    //   721: putfield c : I
    //   724: aload_1
    //   725: iconst_0
    //   726: putfield F : Z
    //   729: goto -> 779
    //   732: new java/lang/StringBuilder
    //   735: dup
    //   736: invokespecial <init> : ()V
    //   739: astore #10
    //   741: aload #10
    //   743: ldc_w 'Fragment '
    //   746: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   749: pop
    //   750: aload #10
    //   752: aload_1
    //   753: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   756: pop
    //   757: aload #10
    //   759: ldc_w ' did not call through to super.onAttach()'
    //   762: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   765: pop
    //   766: new android/support/v4/app/d0
    //   769: dup
    //   770: aload #10
    //   772: invokevirtual toString : ()Ljava/lang/String;
    //   775: invokespecial <init> : (Ljava/lang/String;)V
    //   778: athrow
    //   779: aload_0
    //   780: aload_1
    //   781: invokevirtual e : (Landroid/support/v4/app/f;)V
    //   784: iload_3
    //   785: istore #4
    //   787: iload_3
    //   788: iconst_1
    //   789: if_icmple -> 1237
    //   792: getstatic android/support/v4/app/l.G : Z
    //   795: ifeq -> 835
    //   798: new java/lang/StringBuilder
    //   801: dup
    //   802: invokespecial <init> : ()V
    //   805: astore #10
    //   807: aload #10
    //   809: ldc_w 'moveto ACTIVITY_CREATED: '
    //   812: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   815: pop
    //   816: aload #10
    //   818: aload_1
    //   819: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   822: pop
    //   823: ldc_w 'FragmentManager'
    //   826: aload #10
    //   828: invokevirtual toString : ()Ljava/lang/String;
    //   831: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   834: pop
    //   835: aload_1
    //   836: getfield o : Z
    //   839: ifne -> 1196
    //   842: aconst_null
    //   843: astore #10
    //   845: aload_1
    //   846: getfield A : I
    //   849: istore_2
    //   850: iload_2
    //   851: ifeq -> 1052
    //   854: iload_2
    //   855: iconst_m1
    //   856: if_icmpeq -> 1000
    //   859: aload_0
    //   860: getfield p : Landroid/support/v4/app/h;
    //   863: iload_2
    //   864: invokevirtual a : (I)Landroid/view/View;
    //   867: checkcast android/view/ViewGroup
    //   870: astore #11
    //   872: aload #11
    //   874: astore #10
    //   876: aload #11
    //   878: ifnonnull -> 1052
    //   881: aload_1
    //   882: getfield q : Z
    //   885: ifeq -> 895
    //   888: aload #11
    //   890: astore #10
    //   892: goto -> 1052
    //   895: aload_1
    //   896: invokevirtual v : ()Landroid/content/res/Resources;
    //   899: aload_1
    //   900: getfield A : I
    //   903: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   906: astore #10
    //   908: goto -> 918
    //   911: astore #10
    //   913: ldc_w 'unknown'
    //   916: astore #10
    //   918: new java/lang/StringBuilder
    //   921: dup
    //   922: invokespecial <init> : ()V
    //   925: astore #11
    //   927: aload #11
    //   929: ldc_w 'No view found for id 0x'
    //   932: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   935: pop
    //   936: aload #11
    //   938: aload_1
    //   939: getfield A : I
    //   942: invokestatic toHexString : (I)Ljava/lang/String;
    //   945: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   948: pop
    //   949: aload #11
    //   951: ldc_w ' ('
    //   954: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   957: pop
    //   958: aload #11
    //   960: aload #10
    //   962: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   965: pop
    //   966: aload #11
    //   968: ldc_w ') for fragment '
    //   971: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   974: pop
    //   975: aload #11
    //   977: aload_1
    //   978: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   981: pop
    //   982: aload_0
    //   983: new java/lang/IllegalArgumentException
    //   986: dup
    //   987: aload #11
    //   989: invokevirtual toString : ()Ljava/lang/String;
    //   992: invokespecial <init> : (Ljava/lang/String;)V
    //   995: invokespecial a : (Ljava/lang/RuntimeException;)V
    //   998: aconst_null
    //   999: athrow
    //   1000: new java/lang/StringBuilder
    //   1003: dup
    //   1004: invokespecial <init> : ()V
    //   1007: astore #10
    //   1009: aload #10
    //   1011: ldc_w 'Cannot create fragment '
    //   1014: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1017: pop
    //   1018: aload #10
    //   1020: aload_1
    //   1021: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1024: pop
    //   1025: aload #10
    //   1027: ldc_w ' for a container view with no id'
    //   1030: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1033: pop
    //   1034: aload_0
    //   1035: new java/lang/IllegalArgumentException
    //   1038: dup
    //   1039: aload #10
    //   1041: invokevirtual toString : ()Ljava/lang/String;
    //   1044: invokespecial <init> : (Ljava/lang/String;)V
    //   1047: invokespecial a : (Ljava/lang/RuntimeException;)V
    //   1050: aconst_null
    //   1051: athrow
    //   1052: aload_1
    //   1053: aload #10
    //   1055: putfield J : Landroid/view/ViewGroup;
    //   1058: aload_1
    //   1059: aload_1
    //   1060: aload_1
    //   1061: getfield d : Landroid/os/Bundle;
    //   1064: invokevirtual i : (Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    //   1067: aload #10
    //   1069: aload_1
    //   1070: getfield d : Landroid/os/Bundle;
    //   1073: invokevirtual b : (Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V
    //   1076: aload_1
    //   1077: getfield K : Landroid/view/View;
    //   1080: astore #11
    //   1082: aload #11
    //   1084: ifnull -> 1191
    //   1087: aload_1
    //   1088: aload #11
    //   1090: putfield L : Landroid/view/View;
    //   1093: aload #11
    //   1095: iconst_0
    //   1096: invokevirtual setSaveFromParentEnabled : (Z)V
    //   1099: aload #10
    //   1101: ifnull -> 1113
    //   1104: aload #10
    //   1106: aload_1
    //   1107: getfield K : Landroid/view/View;
    //   1110: invokevirtual addView : (Landroid/view/View;)V
    //   1113: aload_1
    //   1114: getfield C : Z
    //   1117: ifeq -> 1129
    //   1120: aload_1
    //   1121: getfield K : Landroid/view/View;
    //   1124: bipush #8
    //   1126: invokevirtual setVisibility : (I)V
    //   1129: aload_1
    //   1130: aload_1
    //   1131: getfield K : Landroid/view/View;
    //   1134: aload_1
    //   1135: getfield d : Landroid/os/Bundle;
    //   1138: invokevirtual a : (Landroid/view/View;Landroid/os/Bundle;)V
    //   1141: aload_0
    //   1142: aload_1
    //   1143: aload_1
    //   1144: getfield K : Landroid/view/View;
    //   1147: aload_1
    //   1148: getfield d : Landroid/os/Bundle;
    //   1151: iconst_0
    //   1152: invokevirtual a : (Landroid/support/v4/app/f;Landroid/view/View;Landroid/os/Bundle;Z)V
    //   1155: aload_1
    //   1156: getfield K : Landroid/view/View;
    //   1159: invokevirtual getVisibility : ()I
    //   1162: ifne -> 1179
    //   1165: aload_1
    //   1166: getfield J : Landroid/view/ViewGroup;
    //   1169: ifnull -> 1179
    //   1172: iload #8
    //   1174: istore #5
    //   1176: goto -> 1182
    //   1179: iconst_0
    //   1180: istore #5
    //   1182: aload_1
    //   1183: iload #5
    //   1185: putfield P : Z
    //   1188: goto -> 1196
    //   1191: aload_1
    //   1192: aconst_null
    //   1193: putfield L : Landroid/view/View;
    //   1196: aload_1
    //   1197: aload_1
    //   1198: getfield d : Landroid/os/Bundle;
    //   1201: invokevirtual g : (Landroid/os/Bundle;)V
    //   1204: aload_0
    //   1205: aload_1
    //   1206: aload_1
    //   1207: getfield d : Landroid/os/Bundle;
    //   1210: iconst_0
    //   1211: invokevirtual a : (Landroid/support/v4/app/f;Landroid/os/Bundle;Z)V
    //   1214: aload_1
    //   1215: getfield K : Landroid/view/View;
    //   1218: ifnull -> 1229
    //   1221: aload_1
    //   1222: aload_1
    //   1223: getfield d : Landroid/os/Bundle;
    //   1226: invokevirtual l : (Landroid/os/Bundle;)V
    //   1229: aload_1
    //   1230: aconst_null
    //   1231: putfield d : Landroid/os/Bundle;
    //   1234: iload_3
    //   1235: istore #4
    //   1237: iload #4
    //   1239: istore_3
    //   1240: iload #4
    //   1242: iconst_2
    //   1243: if_icmple -> 1302
    //   1246: getstatic android/support/v4/app/l.G : Z
    //   1249: ifeq -> 1289
    //   1252: new java/lang/StringBuilder
    //   1255: dup
    //   1256: invokespecial <init> : ()V
    //   1259: astore #10
    //   1261: aload #10
    //   1263: ldc_w 'moveto STARTED: '
    //   1266: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1269: pop
    //   1270: aload #10
    //   1272: aload_1
    //   1273: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1276: pop
    //   1277: ldc_w 'FragmentManager'
    //   1280: aload #10
    //   1282: invokevirtual toString : ()Ljava/lang/String;
    //   1285: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1288: pop
    //   1289: aload_1
    //   1290: invokevirtual Z : ()V
    //   1293: aload_0
    //   1294: aload_1
    //   1295: iconst_0
    //   1296: invokevirtual f : (Landroid/support/v4/app/f;Z)V
    //   1299: iload #4
    //   1301: istore_3
    //   1302: iload_3
    //   1303: istore_2
    //   1304: iload_3
    //   1305: iconst_3
    //   1306: if_icmple -> 1374
    //   1309: getstatic android/support/v4/app/l.G : Z
    //   1312: ifeq -> 1352
    //   1315: new java/lang/StringBuilder
    //   1318: dup
    //   1319: invokespecial <init> : ()V
    //   1322: astore #10
    //   1324: aload #10
    //   1326: ldc_w 'moveto RESUMED: '
    //   1329: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1332: pop
    //   1333: aload #10
    //   1335: aload_1
    //   1336: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1339: pop
    //   1340: ldc_w 'FragmentManager'
    //   1343: aload #10
    //   1345: invokevirtual toString : ()Ljava/lang/String;
    //   1348: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1351: pop
    //   1352: aload_1
    //   1353: invokevirtual Y : ()V
    //   1356: aload_0
    //   1357: aload_1
    //   1358: iconst_0
    //   1359: invokevirtual e : (Landroid/support/v4/app/f;Z)V
    //   1362: aload_1
    //   1363: aconst_null
    //   1364: putfield d : Landroid/os/Bundle;
    //   1367: aload_1
    //   1368: aconst_null
    //   1369: putfield e : Landroid/util/SparseArray;
    //   1372: iload_3
    //   1373: istore_2
    //   1374: iload_2
    //   1375: istore_3
    //   1376: goto -> 1992
    //   1379: iload #6
    //   1381: iload_2
    //   1382: if_icmple -> 1990
    //   1385: iload #6
    //   1387: iconst_1
    //   1388: if_icmpeq -> 1778
    //   1391: iload #6
    //   1393: iconst_2
    //   1394: if_icmpeq -> 1530
    //   1397: iload #6
    //   1399: iconst_3
    //   1400: if_icmpeq -> 1472
    //   1403: iload #6
    //   1405: iconst_4
    //   1406: if_icmpeq -> 1414
    //   1409: iload_2
    //   1410: istore_3
    //   1411: goto -> 1992
    //   1414: iload_2
    //   1415: iconst_4
    //   1416: if_icmpge -> 1472
    //   1419: getstatic android/support/v4/app/l.G : Z
    //   1422: ifeq -> 1462
    //   1425: new java/lang/StringBuilder
    //   1428: dup
    //   1429: invokespecial <init> : ()V
    //   1432: astore #10
    //   1434: aload #10
    //   1436: ldc_w 'movefrom RESUMED: '
    //   1439: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1442: pop
    //   1443: aload #10
    //   1445: aload_1
    //   1446: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1449: pop
    //   1450: ldc_w 'FragmentManager'
    //   1453: aload #10
    //   1455: invokevirtual toString : ()Ljava/lang/String;
    //   1458: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1461: pop
    //   1462: aload_1
    //   1463: invokevirtual X : ()V
    //   1466: aload_0
    //   1467: aload_1
    //   1468: iconst_0
    //   1469: invokevirtual d : (Landroid/support/v4/app/f;Z)V
    //   1472: iload_2
    //   1473: iconst_3
    //   1474: if_icmpge -> 1530
    //   1477: getstatic android/support/v4/app/l.G : Z
    //   1480: ifeq -> 1520
    //   1483: new java/lang/StringBuilder
    //   1486: dup
    //   1487: invokespecial <init> : ()V
    //   1490: astore #10
    //   1492: aload #10
    //   1494: ldc_w 'movefrom STARTED: '
    //   1497: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1500: pop
    //   1501: aload #10
    //   1503: aload_1
    //   1504: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1507: pop
    //   1508: ldc_w 'FragmentManager'
    //   1511: aload #10
    //   1513: invokevirtual toString : ()Ljava/lang/String;
    //   1516: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1519: pop
    //   1520: aload_1
    //   1521: invokevirtual a0 : ()V
    //   1524: aload_0
    //   1525: aload_1
    //   1526: iconst_0
    //   1527: invokevirtual g : (Landroid/support/v4/app/f;Z)V
    //   1530: iload_2
    //   1531: iconst_2
    //   1532: if_icmpge -> 1775
    //   1535: getstatic android/support/v4/app/l.G : Z
    //   1538: ifeq -> 1578
    //   1541: new java/lang/StringBuilder
    //   1544: dup
    //   1545: invokespecial <init> : ()V
    //   1548: astore #10
    //   1550: aload #10
    //   1552: ldc_w 'movefrom ACTIVITY_CREATED: '
    //   1555: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1558: pop
    //   1559: aload #10
    //   1561: aload_1
    //   1562: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1565: pop
    //   1566: ldc_w 'FragmentManager'
    //   1569: aload #10
    //   1571: invokevirtual toString : ()Ljava/lang/String;
    //   1574: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1577: pop
    //   1578: aload_1
    //   1579: getfield K : Landroid/view/View;
    //   1582: ifnull -> 1608
    //   1585: aload_0
    //   1586: getfield o : Landroid/support/v4/app/j;
    //   1589: aload_1
    //   1590: invokevirtual b : (Landroid/support/v4/app/f;)Z
    //   1593: ifeq -> 1608
    //   1596: aload_1
    //   1597: getfield e : Landroid/util/SparseArray;
    //   1600: ifnonnull -> 1608
    //   1603: aload_0
    //   1604: aload_1
    //   1605: invokevirtual n : (Landroid/support/v4/app/f;)V
    //   1608: aload_1
    //   1609: invokevirtual U : ()V
    //   1612: aload_0
    //   1613: aload_1
    //   1614: iconst_0
    //   1615: invokevirtual h : (Landroid/support/v4/app/f;Z)V
    //   1618: aload_1
    //   1619: getfield K : Landroid/view/View;
    //   1622: astore #10
    //   1624: aload #10
    //   1626: ifnull -> 1739
    //   1629: aload_1
    //   1630: getfield J : Landroid/view/ViewGroup;
    //   1633: astore #11
    //   1635: aload #11
    //   1637: ifnull -> 1739
    //   1640: aload #11
    //   1642: aload #10
    //   1644: invokevirtual endViewTransition : (Landroid/view/View;)V
    //   1647: aload_1
    //   1648: getfield K : Landroid/view/View;
    //   1651: invokevirtual clearAnimation : ()V
    //   1654: aconst_null
    //   1655: astore #10
    //   1657: aload_0
    //   1658: getfield n : I
    //   1661: ifle -> 1707
    //   1664: aload_0
    //   1665: getfield v : Z
    //   1668: ifne -> 1707
    //   1671: aload_1
    //   1672: getfield K : Landroid/view/View;
    //   1675: invokevirtual getVisibility : ()I
    //   1678: ifne -> 1704
    //   1681: aload_1
    //   1682: getfield R : F
    //   1685: fconst_0
    //   1686: fcmpl
    //   1687: iflt -> 1704
    //   1690: aload_0
    //   1691: aload_1
    //   1692: iload_3
    //   1693: iconst_0
    //   1694: iload #4
    //   1696: invokevirtual a : (Landroid/support/v4/app/f;IZI)Landroid/support/v4/app/l$g;
    //   1699: astore #10
    //   1701: goto -> 1707
    //   1704: goto -> 1707
    //   1707: aload_1
    //   1708: fconst_0
    //   1709: putfield R : F
    //   1712: aload #10
    //   1714: ifnull -> 1725
    //   1717: aload_0
    //   1718: aload_1
    //   1719: aload #10
    //   1721: iload_2
    //   1722: invokespecial a : (Landroid/support/v4/app/f;Landroid/support/v4/app/l$g;I)V
    //   1725: aload_1
    //   1726: getfield J : Landroid/view/ViewGroup;
    //   1729: aload_1
    //   1730: getfield K : Landroid/view/View;
    //   1733: invokevirtual removeView : (Landroid/view/View;)V
    //   1736: goto -> 1739
    //   1739: aload_1
    //   1740: aconst_null
    //   1741: putfield J : Landroid/view/ViewGroup;
    //   1744: aload_1
    //   1745: aconst_null
    //   1746: putfield K : Landroid/view/View;
    //   1749: aload_1
    //   1750: aconst_null
    //   1751: putfield W : Landroid/arch/lifecycle/e;
    //   1754: aload_1
    //   1755: getfield X : Landroid/arch/lifecycle/j;
    //   1758: aconst_null
    //   1759: invokevirtual a : (Ljava/lang/Object;)V
    //   1762: aload_1
    //   1763: aconst_null
    //   1764: putfield L : Landroid/view/View;
    //   1767: aload_1
    //   1768: iconst_0
    //   1769: putfield p : Z
    //   1772: goto -> 1778
    //   1775: goto -> 1778
    //   1778: iload_2
    //   1779: istore_3
    //   1780: iload_2
    //   1781: iconst_1
    //   1782: if_icmpge -> 1992
    //   1785: aload_0
    //   1786: getfield v : Z
    //   1789: ifeq -> 1841
    //   1792: aload_1
    //   1793: invokevirtual g : ()Landroid/view/View;
    //   1796: ifnull -> 1818
    //   1799: aload_1
    //   1800: invokevirtual g : ()Landroid/view/View;
    //   1803: astore #10
    //   1805: aload_1
    //   1806: aconst_null
    //   1807: invokevirtual a : (Landroid/view/View;)V
    //   1810: aload #10
    //   1812: invokevirtual clearAnimation : ()V
    //   1815: goto -> 1841
    //   1818: aload_1
    //   1819: invokevirtual h : ()Landroid/animation/Animator;
    //   1822: ifnull -> 1841
    //   1825: aload_1
    //   1826: invokevirtual h : ()Landroid/animation/Animator;
    //   1829: astore #10
    //   1831: aload_1
    //   1832: aconst_null
    //   1833: invokevirtual a : (Landroid/animation/Animator;)V
    //   1836: aload #10
    //   1838: invokevirtual cancel : ()V
    //   1841: aload_1
    //   1842: invokevirtual g : ()Landroid/view/View;
    //   1845: ifnonnull -> 1980
    //   1848: aload_1
    //   1849: invokevirtual h : ()Landroid/animation/Animator;
    //   1852: ifnull -> 1858
    //   1855: goto -> 1980
    //   1858: getstatic android/support/v4/app/l.G : Z
    //   1861: ifeq -> 1901
    //   1864: new java/lang/StringBuilder
    //   1867: dup
    //   1868: invokespecial <init> : ()V
    //   1871: astore #10
    //   1873: aload #10
    //   1875: ldc_w 'movefrom CREATED: '
    //   1878: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1881: pop
    //   1882: aload #10
    //   1884: aload_1
    //   1885: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1888: pop
    //   1889: ldc_w 'FragmentManager'
    //   1892: aload #10
    //   1894: invokevirtual toString : ()Ljava/lang/String;
    //   1897: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1900: pop
    //   1901: aload_1
    //   1902: getfield F : Z
    //   1905: ifne -> 1921
    //   1908: aload_1
    //   1909: invokevirtual T : ()V
    //   1912: aload_0
    //   1913: aload_1
    //   1914: iconst_0
    //   1915: invokevirtual b : (Landroid/support/v4/app/f;Z)V
    //   1918: goto -> 1926
    //   1921: aload_1
    //   1922: iconst_0
    //   1923: putfield c : I
    //   1926: aload_1
    //   1927: invokevirtual V : ()V
    //   1930: aload_0
    //   1931: aload_1
    //   1932: iconst_0
    //   1933: invokevirtual c : (Landroid/support/v4/app/f;Z)V
    //   1936: iload_2
    //   1937: istore_3
    //   1938: iload #5
    //   1940: ifne -> 1992
    //   1943: aload_1
    //   1944: getfield F : Z
    //   1947: ifne -> 1960
    //   1950: aload_0
    //   1951: aload_1
    //   1952: invokevirtual h : (Landroid/support/v4/app/f;)V
    //   1955: iload_2
    //   1956: istore_3
    //   1957: goto -> 1992
    //   1960: aload_1
    //   1961: aconst_null
    //   1962: putfield u : Landroid/support/v4/app/j;
    //   1965: aload_1
    //   1966: aconst_null
    //   1967: putfield y : Landroid/support/v4/app/f;
    //   1970: aload_1
    //   1971: aconst_null
    //   1972: putfield t : Landroid/support/v4/app/l;
    //   1975: iload_2
    //   1976: istore_3
    //   1977: goto -> 1992
    //   1980: aload_1
    //   1981: iload_2
    //   1982: invokevirtual d : (I)V
    //   1985: iconst_1
    //   1986: istore_3
    //   1987: goto -> 1992
    //   1990: iload_2
    //   1991: istore_3
    //   1992: aload_1
    //   1993: getfield c : I
    //   1996: iload_3
    //   1997: if_icmpeq -> 2086
    //   2000: new java/lang/StringBuilder
    //   2003: dup
    //   2004: invokespecial <init> : ()V
    //   2007: astore #10
    //   2009: aload #10
    //   2011: ldc_w 'moveToState: Fragment state for '
    //   2014: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2017: pop
    //   2018: aload #10
    //   2020: aload_1
    //   2021: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2024: pop
    //   2025: aload #10
    //   2027: ldc_w ' not updated inline; '
    //   2030: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2033: pop
    //   2034: aload #10
    //   2036: ldc_w 'expected state '
    //   2039: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2042: pop
    //   2043: aload #10
    //   2045: iload_3
    //   2046: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2049: pop
    //   2050: aload #10
    //   2052: ldc_w ' found '
    //   2055: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2058: pop
    //   2059: aload #10
    //   2061: aload_1
    //   2062: getfield c : I
    //   2065: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2068: pop
    //   2069: ldc_w 'FragmentManager'
    //   2072: aload #10
    //   2074: invokevirtual toString : ()Ljava/lang/String;
    //   2077: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   2080: pop
    //   2081: aload_1
    //   2082: iload_3
    //   2083: putfield c : I
    //   2086: return
    // Exception table:
    //   from	to	target	type
    //   895	908	911	android/content/res/Resources$NotFoundException
  }
  
  void a(f paramf, Context paramContext, boolean paramBoolean) {
    f f1 = this.q;
    if (f1 != null) {
      k k1 = f1.p();
      if (k1 instanceof l)
        ((l)k1).a(paramf, paramContext, true); 
    } 
    for (j j1 : this.m) {
      if (!paramBoolean || j1.b)
        j1.a.a(this, paramf, paramContext); 
    } 
  }
  
  void a(f paramf, Bundle paramBundle, boolean paramBoolean) {
    f f1 = this.q;
    if (f1 != null) {
      k k1 = f1.p();
      if (k1 instanceof l)
        ((l)k1).a(paramf, paramBundle, true); 
    } 
    for (j j1 : this.m) {
      if (!paramBoolean || j1.b)
        j1.a.a(this, paramf, paramBundle); 
    } 
  }
  
  void a(f paramf, View paramView, Bundle paramBundle, boolean paramBoolean) {
    f f1 = this.q;
    if (f1 != null) {
      k k1 = f1.p();
      if (k1 instanceof l)
        ((l)k1).a(paramf, paramView, paramBundle, true); 
    } 
    for (j j1 : this.m) {
      if (!paramBoolean || j1.b)
        j1.a.a(this, paramf, paramView, paramBundle); 
    } 
  }
  
  public void a(f paramf, boolean paramBoolean) {
    if (G) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("add: ");
      stringBuilder.append(paramf);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    g(paramf);
    if (!paramf.D)
      if (!this.f.contains(paramf)) {
        synchronized (this.f) {
          this.f.add(paramf);
          paramf.m = true;
          paramf.n = false;
          if (paramf.K == null)
            paramf.Q = false; 
          if (paramf.G && paramf.H)
            this.s = true; 
          if (paramBoolean)
            j(paramf); 
        } 
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment already added: ");
        stringBuilder.append(paramf);
        throw new IllegalStateException(stringBuilder.toString());
      }  
  }
  
  public void a(j paramj, h paramh, f paramf) {
    if (this.o == null) {
      this.o = paramj;
      this.p = paramh;
      this.q = paramf;
      return;
    } 
    throw new IllegalStateException("Already attached");
  }
  
  public void a(l paraml, boolean paramBoolean) {
    // Byte code:
    //   0: iload_2
    //   1: ifne -> 8
    //   4: aload_0
    //   5: invokespecial z : ()V
    //   8: aload_0
    //   9: monitorenter
    //   10: aload_0
    //   11: getfield v : Z
    //   14: ifne -> 63
    //   17: aload_0
    //   18: getfield o : Landroid/support/v4/app/j;
    //   21: ifnonnull -> 27
    //   24: goto -> 63
    //   27: aload_0
    //   28: getfield c : Ljava/util/ArrayList;
    //   31: ifnonnull -> 47
    //   34: new java/util/ArrayList
    //   37: astore_3
    //   38: aload_3
    //   39: invokespecial <init> : ()V
    //   42: aload_0
    //   43: aload_3
    //   44: putfield c : Ljava/util/ArrayList;
    //   47: aload_0
    //   48: getfield c : Ljava/util/ArrayList;
    //   51: aload_1
    //   52: invokevirtual add : (Ljava/lang/Object;)Z
    //   55: pop
    //   56: aload_0
    //   57: invokevirtual w : ()V
    //   60: aload_0
    //   61: monitorexit
    //   62: return
    //   63: iload_2
    //   64: ifeq -> 70
    //   67: aload_0
    //   68: monitorexit
    //   69: return
    //   70: new java/lang/IllegalStateException
    //   73: astore_1
    //   74: aload_1
    //   75: ldc_w 'Activity has been destroyed'
    //   78: invokespecial <init> : (Ljava/lang/String;)V
    //   81: aload_1
    //   82: athrow
    //   83: astore_1
    //   84: aload_0
    //   85: monitorexit
    //   86: aload_1
    //   87: athrow
    // Exception table:
    //   from	to	target	type
    //   10	24	83	finally
    //   27	47	83	finally
    //   47	62	83	finally
    //   67	69	83	finally
    //   70	83	83	finally
    //   84	86	83	finally
  }
  
  public void a(Menu paramMenu) {
    if (this.n < 1)
      return; 
    for (byte b = 0; b < this.f.size(); b++) {
      f f1 = this.f.get(b);
      if (f1 != null)
        f1.c(paramMenu); 
    } 
  }
  
  public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #7
    //   9: aload #7
    //   11: aload_1
    //   12: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   15: pop
    //   16: aload #7
    //   18: ldc_w '    '
    //   21: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   24: pop
    //   25: aload #7
    //   27: invokevirtual toString : ()Ljava/lang/String;
    //   30: astore #7
    //   32: aload_0
    //   33: getfield g : Landroid/util/SparseArray;
    //   36: astore #8
    //   38: aload #8
    //   40: ifnull -> 162
    //   43: aload #8
    //   45: invokevirtual size : ()I
    //   48: istore #6
    //   50: iload #6
    //   52: ifle -> 162
    //   55: aload_3
    //   56: aload_1
    //   57: invokevirtual print : (Ljava/lang/String;)V
    //   60: aload_3
    //   61: ldc_w 'Active Fragments in '
    //   64: invokevirtual print : (Ljava/lang/String;)V
    //   67: aload_3
    //   68: aload_0
    //   69: invokestatic identityHashCode : (Ljava/lang/Object;)I
    //   72: invokestatic toHexString : (I)Ljava/lang/String;
    //   75: invokevirtual print : (Ljava/lang/String;)V
    //   78: aload_3
    //   79: ldc_w ':'
    //   82: invokevirtual println : (Ljava/lang/String;)V
    //   85: iconst_0
    //   86: istore #5
    //   88: iload #5
    //   90: iload #6
    //   92: if_icmpge -> 162
    //   95: aload_0
    //   96: getfield g : Landroid/util/SparseArray;
    //   99: iload #5
    //   101: invokevirtual valueAt : (I)Ljava/lang/Object;
    //   104: checkcast android/support/v4/app/f
    //   107: astore #8
    //   109: aload_3
    //   110: aload_1
    //   111: invokevirtual print : (Ljava/lang/String;)V
    //   114: aload_3
    //   115: ldc_w '  #'
    //   118: invokevirtual print : (Ljava/lang/String;)V
    //   121: aload_3
    //   122: iload #5
    //   124: invokevirtual print : (I)V
    //   127: aload_3
    //   128: ldc_w ': '
    //   131: invokevirtual print : (Ljava/lang/String;)V
    //   134: aload_3
    //   135: aload #8
    //   137: invokevirtual println : (Ljava/lang/Object;)V
    //   140: aload #8
    //   142: ifnull -> 156
    //   145: aload #8
    //   147: aload #7
    //   149: aload_2
    //   150: aload_3
    //   151: aload #4
    //   153: invokevirtual a : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   156: iinc #5, 1
    //   159: goto -> 88
    //   162: aload_0
    //   163: getfield f : Ljava/util/ArrayList;
    //   166: invokevirtual size : ()I
    //   169: istore #6
    //   171: iload #6
    //   173: ifle -> 252
    //   176: aload_3
    //   177: aload_1
    //   178: invokevirtual print : (Ljava/lang/String;)V
    //   181: aload_3
    //   182: ldc_w 'Added Fragments:'
    //   185: invokevirtual println : (Ljava/lang/String;)V
    //   188: iconst_0
    //   189: istore #5
    //   191: iload #5
    //   193: iload #6
    //   195: if_icmpge -> 252
    //   198: aload_0
    //   199: getfield f : Ljava/util/ArrayList;
    //   202: iload #5
    //   204: invokevirtual get : (I)Ljava/lang/Object;
    //   207: checkcast android/support/v4/app/f
    //   210: astore #8
    //   212: aload_3
    //   213: aload_1
    //   214: invokevirtual print : (Ljava/lang/String;)V
    //   217: aload_3
    //   218: ldc_w '  #'
    //   221: invokevirtual print : (Ljava/lang/String;)V
    //   224: aload_3
    //   225: iload #5
    //   227: invokevirtual print : (I)V
    //   230: aload_3
    //   231: ldc_w ': '
    //   234: invokevirtual print : (Ljava/lang/String;)V
    //   237: aload_3
    //   238: aload #8
    //   240: invokevirtual toString : ()Ljava/lang/String;
    //   243: invokevirtual println : (Ljava/lang/String;)V
    //   246: iinc #5, 1
    //   249: goto -> 191
    //   252: aload_0
    //   253: getfield i : Ljava/util/ArrayList;
    //   256: astore #8
    //   258: aload #8
    //   260: ifnull -> 351
    //   263: aload #8
    //   265: invokevirtual size : ()I
    //   268: istore #6
    //   270: iload #6
    //   272: ifle -> 351
    //   275: aload_3
    //   276: aload_1
    //   277: invokevirtual print : (Ljava/lang/String;)V
    //   280: aload_3
    //   281: ldc_w 'Fragments Created Menus:'
    //   284: invokevirtual println : (Ljava/lang/String;)V
    //   287: iconst_0
    //   288: istore #5
    //   290: iload #5
    //   292: iload #6
    //   294: if_icmpge -> 351
    //   297: aload_0
    //   298: getfield i : Ljava/util/ArrayList;
    //   301: iload #5
    //   303: invokevirtual get : (I)Ljava/lang/Object;
    //   306: checkcast android/support/v4/app/f
    //   309: astore #8
    //   311: aload_3
    //   312: aload_1
    //   313: invokevirtual print : (Ljava/lang/String;)V
    //   316: aload_3
    //   317: ldc_w '  #'
    //   320: invokevirtual print : (Ljava/lang/String;)V
    //   323: aload_3
    //   324: iload #5
    //   326: invokevirtual print : (I)V
    //   329: aload_3
    //   330: ldc_w ': '
    //   333: invokevirtual print : (Ljava/lang/String;)V
    //   336: aload_3
    //   337: aload #8
    //   339: invokevirtual toString : ()Ljava/lang/String;
    //   342: invokevirtual println : (Ljava/lang/String;)V
    //   345: iinc #5, 1
    //   348: goto -> 290
    //   351: aload_0
    //   352: getfield h : Ljava/util/ArrayList;
    //   355: astore #8
    //   357: aload #8
    //   359: ifnull -> 461
    //   362: aload #8
    //   364: invokevirtual size : ()I
    //   367: istore #6
    //   369: iload #6
    //   371: ifle -> 461
    //   374: aload_3
    //   375: aload_1
    //   376: invokevirtual print : (Ljava/lang/String;)V
    //   379: aload_3
    //   380: ldc_w 'Back Stack:'
    //   383: invokevirtual println : (Ljava/lang/String;)V
    //   386: iconst_0
    //   387: istore #5
    //   389: iload #5
    //   391: iload #6
    //   393: if_icmpge -> 461
    //   396: aload_0
    //   397: getfield h : Ljava/util/ArrayList;
    //   400: iload #5
    //   402: invokevirtual get : (I)Ljava/lang/Object;
    //   405: checkcast android/support/v4/app/c
    //   408: astore #8
    //   410: aload_3
    //   411: aload_1
    //   412: invokevirtual print : (Ljava/lang/String;)V
    //   415: aload_3
    //   416: ldc_w '  #'
    //   419: invokevirtual print : (Ljava/lang/String;)V
    //   422: aload_3
    //   423: iload #5
    //   425: invokevirtual print : (I)V
    //   428: aload_3
    //   429: ldc_w ': '
    //   432: invokevirtual print : (Ljava/lang/String;)V
    //   435: aload_3
    //   436: aload #8
    //   438: invokevirtual toString : ()Ljava/lang/String;
    //   441: invokevirtual println : (Ljava/lang/String;)V
    //   444: aload #8
    //   446: aload #7
    //   448: aload_2
    //   449: aload_3
    //   450: aload #4
    //   452: invokevirtual a : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   455: iinc #5, 1
    //   458: goto -> 389
    //   461: aload_0
    //   462: monitorenter
    //   463: aload_0
    //   464: getfield j : Ljava/util/ArrayList;
    //   467: ifnull -> 555
    //   470: aload_0
    //   471: getfield j : Ljava/util/ArrayList;
    //   474: invokevirtual size : ()I
    //   477: istore #6
    //   479: iload #6
    //   481: ifle -> 555
    //   484: aload_3
    //   485: aload_1
    //   486: invokevirtual print : (Ljava/lang/String;)V
    //   489: aload_3
    //   490: ldc_w 'Back Stack Indices:'
    //   493: invokevirtual println : (Ljava/lang/String;)V
    //   496: iconst_0
    //   497: istore #5
    //   499: iload #5
    //   501: iload #6
    //   503: if_icmpge -> 555
    //   506: aload_0
    //   507: getfield j : Ljava/util/ArrayList;
    //   510: iload #5
    //   512: invokevirtual get : (I)Ljava/lang/Object;
    //   515: checkcast android/support/v4/app/c
    //   518: astore_2
    //   519: aload_3
    //   520: aload_1
    //   521: invokevirtual print : (Ljava/lang/String;)V
    //   524: aload_3
    //   525: ldc_w '  #'
    //   528: invokevirtual print : (Ljava/lang/String;)V
    //   531: aload_3
    //   532: iload #5
    //   534: invokevirtual print : (I)V
    //   537: aload_3
    //   538: ldc_w ': '
    //   541: invokevirtual print : (Ljava/lang/String;)V
    //   544: aload_3
    //   545: aload_2
    //   546: invokevirtual println : (Ljava/lang/Object;)V
    //   549: iinc #5, 1
    //   552: goto -> 499
    //   555: aload_0
    //   556: getfield k : Ljava/util/ArrayList;
    //   559: ifnull -> 598
    //   562: aload_0
    //   563: getfield k : Ljava/util/ArrayList;
    //   566: invokevirtual size : ()I
    //   569: ifle -> 598
    //   572: aload_3
    //   573: aload_1
    //   574: invokevirtual print : (Ljava/lang/String;)V
    //   577: aload_3
    //   578: ldc_w 'mAvailBackStackIndices: '
    //   581: invokevirtual print : (Ljava/lang/String;)V
    //   584: aload_3
    //   585: aload_0
    //   586: getfield k : Ljava/util/ArrayList;
    //   589: invokevirtual toArray : ()[Ljava/lang/Object;
    //   592: invokestatic toString : ([Ljava/lang/Object;)Ljava/lang/String;
    //   595: invokevirtual println : (Ljava/lang/String;)V
    //   598: aload_0
    //   599: monitorexit
    //   600: aload_0
    //   601: getfield c : Ljava/util/ArrayList;
    //   604: astore_2
    //   605: aload_2
    //   606: ifnull -> 691
    //   609: aload_2
    //   610: invokevirtual size : ()I
    //   613: istore #6
    //   615: iload #6
    //   617: ifle -> 691
    //   620: aload_3
    //   621: aload_1
    //   622: invokevirtual print : (Ljava/lang/String;)V
    //   625: aload_3
    //   626: ldc_w 'Pending Actions:'
    //   629: invokevirtual println : (Ljava/lang/String;)V
    //   632: iconst_0
    //   633: istore #5
    //   635: iload #5
    //   637: iload #6
    //   639: if_icmpge -> 691
    //   642: aload_0
    //   643: getfield c : Ljava/util/ArrayList;
    //   646: iload #5
    //   648: invokevirtual get : (I)Ljava/lang/Object;
    //   651: checkcast android/support/v4/app/l$l
    //   654: astore_2
    //   655: aload_3
    //   656: aload_1
    //   657: invokevirtual print : (Ljava/lang/String;)V
    //   660: aload_3
    //   661: ldc_w '  #'
    //   664: invokevirtual print : (Ljava/lang/String;)V
    //   667: aload_3
    //   668: iload #5
    //   670: invokevirtual print : (I)V
    //   673: aload_3
    //   674: ldc_w ': '
    //   677: invokevirtual print : (Ljava/lang/String;)V
    //   680: aload_3
    //   681: aload_2
    //   682: invokevirtual println : (Ljava/lang/Object;)V
    //   685: iinc #5, 1
    //   688: goto -> 635
    //   691: aload_3
    //   692: aload_1
    //   693: invokevirtual print : (Ljava/lang/String;)V
    //   696: aload_3
    //   697: ldc_w 'FragmentManager misc state:'
    //   700: invokevirtual println : (Ljava/lang/String;)V
    //   703: aload_3
    //   704: aload_1
    //   705: invokevirtual print : (Ljava/lang/String;)V
    //   708: aload_3
    //   709: ldc_w '  mHost='
    //   712: invokevirtual print : (Ljava/lang/String;)V
    //   715: aload_3
    //   716: aload_0
    //   717: getfield o : Landroid/support/v4/app/j;
    //   720: invokevirtual println : (Ljava/lang/Object;)V
    //   723: aload_3
    //   724: aload_1
    //   725: invokevirtual print : (Ljava/lang/String;)V
    //   728: aload_3
    //   729: ldc_w '  mContainer='
    //   732: invokevirtual print : (Ljava/lang/String;)V
    //   735: aload_3
    //   736: aload_0
    //   737: getfield p : Landroid/support/v4/app/h;
    //   740: invokevirtual println : (Ljava/lang/Object;)V
    //   743: aload_0
    //   744: getfield q : Landroid/support/v4/app/f;
    //   747: ifnull -> 770
    //   750: aload_3
    //   751: aload_1
    //   752: invokevirtual print : (Ljava/lang/String;)V
    //   755: aload_3
    //   756: ldc_w '  mParent='
    //   759: invokevirtual print : (Ljava/lang/String;)V
    //   762: aload_3
    //   763: aload_0
    //   764: getfield q : Landroid/support/v4/app/f;
    //   767: invokevirtual println : (Ljava/lang/Object;)V
    //   770: aload_3
    //   771: aload_1
    //   772: invokevirtual print : (Ljava/lang/String;)V
    //   775: aload_3
    //   776: ldc_w '  mCurState='
    //   779: invokevirtual print : (Ljava/lang/String;)V
    //   782: aload_3
    //   783: aload_0
    //   784: getfield n : I
    //   787: invokevirtual print : (I)V
    //   790: aload_3
    //   791: ldc_w ' mStateSaved='
    //   794: invokevirtual print : (Ljava/lang/String;)V
    //   797: aload_3
    //   798: aload_0
    //   799: getfield t : Z
    //   802: invokevirtual print : (Z)V
    //   805: aload_3
    //   806: ldc_w ' mStopped='
    //   809: invokevirtual print : (Ljava/lang/String;)V
    //   812: aload_3
    //   813: aload_0
    //   814: getfield u : Z
    //   817: invokevirtual print : (Z)V
    //   820: aload_3
    //   821: ldc_w ' mDestroyed='
    //   824: invokevirtual print : (Ljava/lang/String;)V
    //   827: aload_3
    //   828: aload_0
    //   829: getfield v : Z
    //   832: invokevirtual println : (Z)V
    //   835: aload_0
    //   836: getfield s : Z
    //   839: ifeq -> 862
    //   842: aload_3
    //   843: aload_1
    //   844: invokevirtual print : (Ljava/lang/String;)V
    //   847: aload_3
    //   848: ldc_w '  mNeedMenuInvalidate='
    //   851: invokevirtual print : (Ljava/lang/String;)V
    //   854: aload_3
    //   855: aload_0
    //   856: getfield s : Z
    //   859: invokevirtual println : (Z)V
    //   862: aload_0
    //   863: getfield w : Ljava/lang/String;
    //   866: ifnull -> 889
    //   869: aload_3
    //   870: aload_1
    //   871: invokevirtual print : (Ljava/lang/String;)V
    //   874: aload_3
    //   875: ldc_w '  mNoTransactionsBecause='
    //   878: invokevirtual print : (Ljava/lang/String;)V
    //   881: aload_3
    //   882: aload_0
    //   883: getfield w : Ljava/lang/String;
    //   886: invokevirtual println : (Ljava/lang/String;)V
    //   889: return
    //   890: astore_1
    //   891: aload_0
    //   892: monitorexit
    //   893: goto -> 898
    //   896: aload_1
    //   897: athrow
    //   898: goto -> 896
    // Exception table:
    //   from	to	target	type
    //   463	479	890	finally
    //   484	496	890	finally
    //   506	549	890	finally
    //   555	598	890	finally
    //   598	600	890	finally
    //   891	893	890	finally
  }
  
  public void a(boolean paramBoolean) {
    for (int i = this.f.size() - 1; i >= 0; i--) {
      f f1 = this.f.get(i);
      if (f1 != null)
        f1.d(paramBoolean); 
    } 
  }
  
  public boolean a(Menu paramMenu, MenuInflater paramMenuInflater) {
    if (this.n < 1)
      return false; 
    boolean bool = false;
    ArrayList<f> arrayList = null;
    byte b = 0;
    while (b < this.f.size()) {
      f f1 = this.f.get(b);
      boolean bool1 = bool;
      ArrayList<f> arrayList1 = arrayList;
      if (f1 != null) {
        bool1 = bool;
        arrayList1 = arrayList;
        if (f1.b(paramMenu, paramMenuInflater)) {
          bool1 = true;
          arrayList1 = arrayList;
          if (arrayList == null)
            arrayList1 = new ArrayList(); 
          arrayList1.add(f1);
        } 
      } 
      b++;
      bool = bool1;
      arrayList = arrayList1;
    } 
    if (this.i != null)
      for (b = 0; b < this.i.size(); b++) {
        f f1 = this.i.get(b);
        if (arrayList == null || !arrayList.contains(f1))
          f1.L(); 
      }  
    this.i = arrayList;
    return bool;
  }
  
  public boolean a(MenuItem paramMenuItem) {
    if (this.n < 1)
      return false; 
    for (byte b = 0; b < this.f.size(); b++) {
      f f1 = this.f.get(b);
      if (f1 != null && f1.c(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  boolean a(ArrayList<c> paramArrayList, ArrayList<Boolean> paramArrayList1, String paramString, int paramInt1, int paramInt2) {
    ArrayList<c> arrayList = this.h;
    if (arrayList == null)
      return false; 
    if (paramString == null && paramInt1 < 0 && (paramInt2 & 0x1) == 0) {
      paramInt1 = arrayList.size() - 1;
      if (paramInt1 < 0)
        return false; 
      paramArrayList.add(this.h.remove(paramInt1));
      paramArrayList1.add(Boolean.valueOf(true));
    } else {
      int i = -1;
      if (paramString != null || paramInt1 >= 0) {
        int n;
        for (n = this.h.size() - 1; n >= 0; n--) {
          c c = this.h.get(n);
          if ((paramString != null && paramString.equals(c.f())) || (paramInt1 >= 0 && paramInt1 == c.l))
            break; 
        } 
        if (n < 0)
          return false; 
        i = n;
        if ((paramInt2 & 0x1) != 0)
          for (paramInt2 = n - 1;; paramInt2--) {
            i = paramInt2;
            if (paramInt2 >= 0) {
              c c = this.h.get(paramInt2);
              if (paramString == null || !paramString.equals(c.f())) {
                i = paramInt2;
                if (paramInt1 >= 0) {
                  i = paramInt2;
                  if (paramInt1 == c.l)
                    continue; 
                } 
                break;
              } 
              continue;
            } 
            break;
          }  
      } 
      if (i == this.h.size() - 1)
        return false; 
      for (paramInt1 = this.h.size() - 1; paramInt1 > i; paramInt1--) {
        paramArrayList.add(this.h.remove(paramInt1));
        paramArrayList1.add(Boolean.valueOf(true));
      } 
    } 
    return true;
  }
  
  public int b(c paramc) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield k : Ljava/util/ArrayList;
    //   6: ifnull -> 112
    //   9: aload_0
    //   10: getfield k : Ljava/util/ArrayList;
    //   13: invokevirtual size : ()I
    //   16: ifgt -> 22
    //   19: goto -> 112
    //   22: aload_0
    //   23: getfield k : Ljava/util/ArrayList;
    //   26: aload_0
    //   27: getfield k : Ljava/util/ArrayList;
    //   30: invokevirtual size : ()I
    //   33: iconst_1
    //   34: isub
    //   35: invokevirtual remove : (I)Ljava/lang/Object;
    //   38: checkcast java/lang/Integer
    //   41: invokevirtual intValue : ()I
    //   44: istore_2
    //   45: getstatic android/support/v4/app/l.G : Z
    //   48: ifeq -> 98
    //   51: new java/lang/StringBuilder
    //   54: astore_3
    //   55: aload_3
    //   56: invokespecial <init> : ()V
    //   59: aload_3
    //   60: ldc_w 'Adding back stack index '
    //   63: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   66: pop
    //   67: aload_3
    //   68: iload_2
    //   69: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   72: pop
    //   73: aload_3
    //   74: ldc_w ' with '
    //   77: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   80: pop
    //   81: aload_3
    //   82: aload_1
    //   83: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   86: pop
    //   87: ldc_w 'FragmentManager'
    //   90: aload_3
    //   91: invokevirtual toString : ()Ljava/lang/String;
    //   94: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   97: pop
    //   98: aload_0
    //   99: getfield j : Ljava/util/ArrayList;
    //   102: iload_2
    //   103: aload_1
    //   104: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   107: pop
    //   108: aload_0
    //   109: monitorexit
    //   110: iload_2
    //   111: ireturn
    //   112: aload_0
    //   113: getfield j : Ljava/util/ArrayList;
    //   116: ifnonnull -> 132
    //   119: new java/util/ArrayList
    //   122: astore_3
    //   123: aload_3
    //   124: invokespecial <init> : ()V
    //   127: aload_0
    //   128: aload_3
    //   129: putfield j : Ljava/util/ArrayList;
    //   132: aload_0
    //   133: getfield j : Ljava/util/ArrayList;
    //   136: invokevirtual size : ()I
    //   139: istore_2
    //   140: getstatic android/support/v4/app/l.G : Z
    //   143: ifeq -> 193
    //   146: new java/lang/StringBuilder
    //   149: astore_3
    //   150: aload_3
    //   151: invokespecial <init> : ()V
    //   154: aload_3
    //   155: ldc_w 'Setting back stack index '
    //   158: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   161: pop
    //   162: aload_3
    //   163: iload_2
    //   164: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   167: pop
    //   168: aload_3
    //   169: ldc_w ' to '
    //   172: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   175: pop
    //   176: aload_3
    //   177: aload_1
    //   178: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   181: pop
    //   182: ldc_w 'FragmentManager'
    //   185: aload_3
    //   186: invokevirtual toString : ()Ljava/lang/String;
    //   189: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   192: pop
    //   193: aload_0
    //   194: getfield j : Ljava/util/ArrayList;
    //   197: aload_1
    //   198: invokevirtual add : (Ljava/lang/Object;)Z
    //   201: pop
    //   202: aload_0
    //   203: monitorexit
    //   204: iload_2
    //   205: ireturn
    //   206: astore_1
    //   207: aload_0
    //   208: monitorexit
    //   209: aload_1
    //   210: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	206	finally
    //   22	98	206	finally
    //   98	110	206	finally
    //   112	132	206	finally
    //   132	193	206	finally
    //   193	204	206	finally
    //   207	209	206	finally
  }
  
  public f b(String paramString) {
    SparseArray<f> sparseArray = this.g;
    if (sparseArray != null && paramString != null)
      for (int i = sparseArray.size() - 1; i >= 0; i--) {
        f f1 = (f)this.g.valueAt(i);
        if (f1 != null) {
          f1 = f1.a(paramString);
          if (f1 != null)
            return f1; 
        } 
      }  
    return null;
  }
  
  public List<f> b() {
    if (this.f.isEmpty())
      return Collections.emptyList(); 
    synchronized (this.f) {
      return (List)this.f.clone();
    } 
  }
  
  public void b(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield j : Ljava/util/ArrayList;
    //   6: iload_1
    //   7: aconst_null
    //   8: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   11: pop
    //   12: aload_0
    //   13: getfield k : Ljava/util/ArrayList;
    //   16: ifnonnull -> 32
    //   19: new java/util/ArrayList
    //   22: astore_2
    //   23: aload_2
    //   24: invokespecial <init> : ()V
    //   27: aload_0
    //   28: aload_2
    //   29: putfield k : Ljava/util/ArrayList;
    //   32: getstatic android/support/v4/app/l.G : Z
    //   35: ifeq -> 71
    //   38: new java/lang/StringBuilder
    //   41: astore_2
    //   42: aload_2
    //   43: invokespecial <init> : ()V
    //   46: aload_2
    //   47: ldc_w 'Freeing back stack index '
    //   50: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   53: pop
    //   54: aload_2
    //   55: iload_1
    //   56: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   59: pop
    //   60: ldc_w 'FragmentManager'
    //   63: aload_2
    //   64: invokevirtual toString : ()Ljava/lang/String;
    //   67: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   70: pop
    //   71: aload_0
    //   72: getfield k : Ljava/util/ArrayList;
    //   75: iload_1
    //   76: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   79: invokevirtual add : (Ljava/lang/Object;)Z
    //   82: pop
    //   83: aload_0
    //   84: monitorexit
    //   85: return
    //   86: astore_2
    //   87: aload_0
    //   88: monitorexit
    //   89: aload_2
    //   90: athrow
    // Exception table:
    //   from	to	target	type
    //   2	32	86	finally
    //   32	71	86	finally
    //   71	85	86	finally
    //   87	89	86	finally
  }
  
  public void b(f paramf) {
    if (G) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("attach: ");
      stringBuilder.append(paramf);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramf.D) {
      paramf.D = false;
      if (!paramf.m)
        if (!this.f.contains(paramf)) {
          if (G) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("add from attach: ");
            stringBuilder.append(paramf);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          synchronized (this.f) {
            this.f.add(paramf);
            paramf.m = true;
            if (paramf.G && paramf.H)
              this.s = true; 
          } 
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Fragment already added: ");
          stringBuilder.append(paramf);
          throw new IllegalStateException(stringBuilder.toString());
        }  
    } 
  }
  
  void b(f paramf, Context paramContext, boolean paramBoolean) {
    f f1 = this.q;
    if (f1 != null) {
      k k1 = f1.p();
      if (k1 instanceof l)
        ((l)k1).b(paramf, paramContext, true); 
    } 
    for (j j1 : this.m) {
      if (!paramBoolean || j1.b)
        j1.a.b(this, paramf, paramContext); 
    } 
  }
  
  void b(f paramf, Bundle paramBundle, boolean paramBoolean) {
    f f1 = this.q;
    if (f1 != null) {
      k k1 = f1.p();
      if (k1 instanceof l)
        ((l)k1).b(paramf, paramBundle, true); 
    } 
    for (j j1 : this.m) {
      if (!paramBoolean || j1.b)
        j1.a.b(this, paramf, paramBundle); 
    } 
  }
  
  void b(f paramf, boolean paramBoolean) {
    f f1 = this.q;
    if (f1 != null) {
      k k1 = f1.p();
      if (k1 instanceof l)
        ((l)k1).b(paramf, true); 
    } 
    for (j j1 : this.m) {
      if (!paramBoolean || j1.b)
        j1.a.a(this, paramf); 
    } 
  }
  
  public void b(l paraml, boolean paramBoolean) {
    if (paramBoolean && (this.o == null || this.v))
      return; 
    c(paramBoolean);
    if (paraml.a(this.y, this.z)) {
      this.d = true;
      try {
        c(this.y, this.z);
      } finally {
        A();
      } 
    } 
    n();
    y();
  }
  
  public void b(boolean paramBoolean) {
    for (int i = this.f.size() - 1; i >= 0; i--) {
      f f1 = this.f.get(i);
      if (f1 != null)
        f1.e(paramBoolean); 
    } 
  }
  
  public boolean b(Menu paramMenu) {
    if (this.n < 1)
      return false; 
    boolean bool = false;
    byte b = 0;
    while (b < this.f.size()) {
      f f1 = this.f.get(b);
      boolean bool1 = bool;
      if (f1 != null) {
        bool1 = bool;
        if (f1.d(paramMenu))
          bool1 = true; 
      } 
      b++;
      bool = bool1;
    } 
    return bool;
  }
  
  public boolean b(MenuItem paramMenuItem) {
    if (this.n < 1)
      return false; 
    for (byte b = 0; b < this.f.size(); b++) {
      f f1 = this.f.get(b);
      if (f1 != null && f1.d(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  void c(f paramf) {
    // Byte code:
    //   0: aload_1
    //   1: getfield K : Landroid/view/View;
    //   4: ifnull -> 213
    //   7: aload_0
    //   8: aload_1
    //   9: aload_1
    //   10: invokevirtual r : ()I
    //   13: aload_1
    //   14: getfield C : Z
    //   17: iconst_1
    //   18: ixor
    //   19: aload_1
    //   20: invokevirtual s : ()I
    //   23: invokevirtual a : (Landroid/support/v4/app/f;IZI)Landroid/support/v4/app/l$g;
    //   26: astore_3
    //   27: aload_3
    //   28: ifnull -> 141
    //   31: aload_3
    //   32: getfield b : Landroid/animation/Animator;
    //   35: astore #4
    //   37: aload #4
    //   39: ifnull -> 141
    //   42: aload #4
    //   44: aload_1
    //   45: getfield K : Landroid/view/View;
    //   48: invokevirtual setTarget : (Ljava/lang/Object;)V
    //   51: aload_1
    //   52: getfield C : Z
    //   55: ifeq -> 115
    //   58: aload_1
    //   59: invokevirtual F : ()Z
    //   62: ifeq -> 73
    //   65: aload_1
    //   66: iconst_0
    //   67: invokevirtual f : (Z)V
    //   70: goto -> 123
    //   73: aload_1
    //   74: getfield J : Landroid/view/ViewGroup;
    //   77: astore #4
    //   79: aload_1
    //   80: getfield K : Landroid/view/View;
    //   83: astore #5
    //   85: aload #4
    //   87: aload #5
    //   89: invokevirtual startViewTransition : (Landroid/view/View;)V
    //   92: aload_3
    //   93: getfield b : Landroid/animation/Animator;
    //   96: new android/support/v4/app/l$d
    //   99: dup
    //   100: aload_0
    //   101: aload #4
    //   103: aload #5
    //   105: aload_1
    //   106: invokespecial <init> : (Landroid/support/v4/app/l;Landroid/view/ViewGroup;Landroid/view/View;Landroid/support/v4/app/f;)V
    //   109: invokevirtual addListener : (Landroid/animation/Animator$AnimatorListener;)V
    //   112: goto -> 123
    //   115: aload_1
    //   116: getfield K : Landroid/view/View;
    //   119: iconst_0
    //   120: invokevirtual setVisibility : (I)V
    //   123: aload_1
    //   124: getfield K : Landroid/view/View;
    //   127: aload_3
    //   128: invokestatic a : (Landroid/view/View;Landroid/support/v4/app/l$g;)V
    //   131: aload_3
    //   132: getfield b : Landroid/animation/Animator;
    //   135: invokevirtual start : ()V
    //   138: goto -> 213
    //   141: aload_3
    //   142: ifnull -> 171
    //   145: aload_1
    //   146: getfield K : Landroid/view/View;
    //   149: aload_3
    //   150: invokestatic a : (Landroid/view/View;Landroid/support/v4/app/l$g;)V
    //   153: aload_1
    //   154: getfield K : Landroid/view/View;
    //   157: aload_3
    //   158: getfield a : Landroid/view/animation/Animation;
    //   161: invokevirtual startAnimation : (Landroid/view/animation/Animation;)V
    //   164: aload_3
    //   165: getfield a : Landroid/view/animation/Animation;
    //   168: invokevirtual start : ()V
    //   171: aload_1
    //   172: getfield C : Z
    //   175: ifeq -> 191
    //   178: aload_1
    //   179: invokevirtual F : ()Z
    //   182: ifne -> 191
    //   185: bipush #8
    //   187: istore_2
    //   188: goto -> 193
    //   191: iconst_0
    //   192: istore_2
    //   193: aload_1
    //   194: getfield K : Landroid/view/View;
    //   197: iload_2
    //   198: invokevirtual setVisibility : (I)V
    //   201: aload_1
    //   202: invokevirtual F : ()Z
    //   205: ifeq -> 213
    //   208: aload_1
    //   209: iconst_0
    //   210: invokevirtual f : (Z)V
    //   213: aload_1
    //   214: getfield m : Z
    //   217: ifeq -> 239
    //   220: aload_1
    //   221: getfield G : Z
    //   224: ifeq -> 239
    //   227: aload_1
    //   228: getfield H : Z
    //   231: ifeq -> 239
    //   234: aload_0
    //   235: iconst_1
    //   236: putfield s : Z
    //   239: aload_1
    //   240: iconst_0
    //   241: putfield Q : Z
    //   244: aload_1
    //   245: aload_1
    //   246: getfield C : Z
    //   249: invokevirtual a : (Z)V
    //   252: return
  }
  
  void c(f paramf, Bundle paramBundle, boolean paramBoolean) {
    f f1 = this.q;
    if (f1 != null) {
      k k1 = f1.p();
      if (k1 instanceof l)
        ((l)k1).c(paramf, paramBundle, true); 
    } 
    for (j j1 : this.m) {
      if (!paramBoolean || j1.b)
        j1.a.c(this, paramf, paramBundle); 
    } 
  }
  
  void c(f paramf, boolean paramBoolean) {
    f f1 = this.q;
    if (f1 != null) {
      k k1 = f1.p();
      if (k1 instanceof l)
        ((l)k1).c(paramf, true); 
    } 
    for (j j1 : this.m) {
      if (!paramBoolean || j1.b)
        j1.a.b(this, paramf); 
    } 
  }
  
  public boolean c() {
    return (this.t || this.u);
  }
  
  boolean c(int paramInt) {
    boolean bool;
    if (this.n >= paramInt) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void d(f paramf) {
    if (G) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("detach: ");
      stringBuilder.append(paramf);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramf.D) {
      paramf.D = true;
      if (paramf.m) {
        if (G) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("remove from detach: ");
          stringBuilder.append(paramf);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        synchronized (this.f) {
          this.f.remove(paramf);
          if (paramf.G && paramf.H)
            this.s = true; 
          paramf.m = false;
        } 
      } 
    } 
  }
  
  void d(f paramf, Bundle paramBundle, boolean paramBoolean) {
    f f1 = this.q;
    if (f1 != null) {
      k k1 = f1.p();
      if (k1 instanceof l)
        ((l)k1).d(paramf, paramBundle, true); 
    } 
    for (j j1 : this.m) {
      if (!paramBoolean || j1.b)
        j1.a.d(this, paramf, paramBundle); 
    } 
  }
  
  void d(f paramf, boolean paramBoolean) {
    f f1 = this.q;
    if (f1 != null) {
      k k1 = f1.p();
      if (k1 instanceof l)
        ((l)k1).d(paramf, true); 
    } 
    for (j j1 : this.m) {
      if (!paramBoolean || j1.b)
        j1.a.c(this, paramf); 
    } 
  }
  
  public boolean d() {
    z();
    return a((String)null, -1, 0);
  }
  
  public void e() {
    this.t = false;
    this.u = false;
    d(2);
  }
  
  void e(f paramf) {
    if (paramf.o && !paramf.r) {
      paramf.b(paramf.i(paramf.d), (ViewGroup)null, paramf.d);
      View view = paramf.K;
      if (view != null) {
        paramf.L = view;
        view.setSaveFromParentEnabled(false);
        if (paramf.C)
          paramf.K.setVisibility(8); 
        paramf.a(paramf.K, paramf.d);
        a(paramf, paramf.K, paramf.d, false);
      } else {
        paramf.L = null;
      } 
    } 
  }
  
  void e(f paramf, boolean paramBoolean) {
    f f1 = this.q;
    if (f1 != null) {
      k k1 = f1.p();
      if (k1 instanceof l)
        ((l)k1).e(paramf, true); 
    } 
    for (j j1 : this.m) {
      if (!paramBoolean || j1.b)
        j1.a.d(this, paramf); 
    } 
  }
  
  public void f() {
    this.t = false;
    this.u = false;
    d(1);
  }
  
  public void f(f paramf) {
    if (G) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("hide: ");
      stringBuilder.append(paramf);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramf.C) {
      paramf.C = true;
      paramf.Q = true ^ paramf.Q;
    } 
  }
  
  void f(f paramf, boolean paramBoolean) {
    f f1 = this.q;
    if (f1 != null) {
      k k1 = f1.p();
      if (k1 instanceof l)
        ((l)k1).f(paramf, true); 
    } 
    for (j j1 : this.m) {
      if (!paramBoolean || j1.b)
        j1.a.e(this, paramf); 
    } 
  }
  
  public void g() {
    this.v = true;
    o();
    d(0);
    this.o = null;
    this.p = null;
    this.q = null;
  }
  
  void g(f paramf) {
    if (paramf.g >= 0)
      return; 
    int i = this.e;
    this.e = i + 1;
    paramf.a(i, this.q);
    if (this.g == null)
      this.g = new SparseArray(); 
    this.g.put(paramf.g, paramf);
    if (G) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Allocated fragment index ");
      stringBuilder.append(paramf);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  void g(f paramf, boolean paramBoolean) {
    f f1 = this.q;
    if (f1 != null) {
      k k1 = f1.p();
      if (k1 instanceof l)
        ((l)k1).g(paramf, true); 
    } 
    for (j j1 : this.m) {
      if (!paramBoolean || j1.b)
        j1.a.f(this, paramf); 
    } 
  }
  
  public void h() {
    d(1);
  }
  
  void h(f paramf) {
    if (paramf.g < 0)
      return; 
    if (G) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Freeing fragment index ");
      stringBuilder.append(paramf);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    this.g.put(paramf.g, null);
    paramf.B();
  }
  
  void h(f paramf, boolean paramBoolean) {
    f f1 = this.q;
    if (f1 != null) {
      k k1 = f1.p();
      if (k1 instanceof l)
        ((l)k1).h(paramf, true); 
    } 
    for (j j1 : this.m) {
      if (!paramBoolean || j1.b)
        j1.a.g(this, paramf); 
    } 
  }
  
  public void i() {
    for (byte b = 0; b < this.f.size(); b++) {
      f f1 = this.f.get(b);
      if (f1 != null)
        f1.W(); 
    } 
  }
  
  void i(f paramf) {
    if (paramf == null)
      return; 
    int n = this.n;
    int i = n;
    if (paramf.n)
      if (paramf.G()) {
        i = Math.min(n, 1);
      } else {
        i = Math.min(n, 0);
      }  
    a(paramf, i, paramf.r(), paramf.s(), false);
    if (paramf.K != null) {
      f f1 = q(paramf);
      if (f1 != null) {
        View view = f1.K;
        ViewGroup viewGroup = paramf.J;
        n = viewGroup.indexOfChild(view);
        i = viewGroup.indexOfChild(paramf.K);
        if (i < n) {
          viewGroup.removeViewAt(i);
          viewGroup.addView(paramf.K, n);
        } 
      } 
      if (paramf.P && paramf.J != null) {
        float f2 = paramf.R;
        if (f2 > 0.0F)
          paramf.K.setAlpha(f2); 
        paramf.R = 0.0F;
        paramf.P = false;
        g g = a(paramf, paramf.r(), true, paramf.s());
        if (g != null) {
          a(paramf.K, g);
          Animation animation = g.a;
          if (animation != null) {
            paramf.K.startAnimation(animation);
          } else {
            g.b.setTarget(paramf.K);
            g.b.start();
          } 
        } 
      } 
    } 
    if (paramf.Q)
      c(paramf); 
  }
  
  public void j() {
    d(3);
  }
  
  void j(f paramf) {
    a(paramf, this.n, 0, 0, false);
  }
  
  public void k() {
    this.t = false;
    this.u = false;
    d(4);
  }
  
  public void k(f paramf) {
    if (paramf.M) {
      if (this.d) {
        this.x = true;
        return;
      } 
      paramf.M = false;
      a(paramf, this.n, 0, 0, false);
    } 
  }
  
  public void l() {
    this.t = false;
    this.u = false;
    d(3);
  }
  
  public void l(f paramf) {
    if (G) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("remove: ");
      stringBuilder.append(paramf);
      stringBuilder.append(" nesting=");
      stringBuilder.append(paramf.s);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    boolean bool = paramf.G();
    if (!paramf.D || (bool ^ true) != 0)
      synchronized (this.f) {
        this.f.remove(paramf);
        if (paramf.G && paramf.H)
          this.s = true; 
        paramf.m = false;
        paramf.n = true;
        return;
      }  
  }
  
  Bundle m(f paramf) {
    Bundle bundle2 = null;
    if (this.B == null)
      this.B = new Bundle(); 
    paramf.j(this.B);
    d(paramf, this.B, false);
    if (!this.B.isEmpty()) {
      bundle2 = this.B;
      this.B = null;
    } 
    if (paramf.K != null)
      n(paramf); 
    Bundle bundle1 = bundle2;
    if (paramf.e != null) {
      bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle1.putSparseParcelableArray("android:view_state", paramf.e);
    } 
    bundle2 = bundle1;
    if (!paramf.N) {
      bundle2 = bundle1;
      if (bundle1 == null)
        bundle2 = new Bundle(); 
      bundle2.putBoolean("android:user_visible_hint", paramf.N);
    } 
    return bundle2;
  }
  
  public void m() {
    this.u = true;
    d(2);
  }
  
  void n() {
    if (this.x) {
      this.x = false;
      x();
    } 
  }
  
  void n(f paramf) {
    if (paramf.L == null)
      return; 
    SparseArray<Parcelable> sparseArray = this.C;
    if (sparseArray == null) {
      this.C = new SparseArray();
    } else {
      sparseArray.clear();
    } 
    paramf.L.saveHierarchyState(this.C);
    if (this.C.size() > 0) {
      paramf.e = this.C;
      this.C = null;
    } 
  }
  
  public void o(f paramf) {
    if (paramf == null || (this.g.get(paramf.g) == paramf && (paramf.u == null || paramf.p() == this))) {
      this.r = paramf;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramf);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean o() {
    c(true);
    boolean bool = false;
    while (b(this.y, this.z)) {
      this.d = true;
      try {
        c(this.y, this.z);
        A();
      } finally {
        A();
      } 
    } 
    n();
    y();
    return bool;
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    if (!"fragment".equals(paramString))
      return null; 
    String str1 = paramAttributeSet.getAttributeValue(null, "class");
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, k.a);
    int i = 0;
    if (str1 == null)
      str1 = typedArray.getString(0); 
    int n = typedArray.getResourceId(1, -1);
    String str2 = typedArray.getString(2);
    typedArray.recycle();
    if (!f.a(this.o.c(), str1))
      return null; 
    if (paramView != null)
      i = paramView.getId(); 
    if (i != -1 || n != -1 || str2 != null) {
      f f2;
      if (n != -1) {
        f f3 = a(n);
      } else {
        paramView = null;
      } 
      View view2 = paramView;
      if (paramView == null) {
        view2 = paramView;
        if (str2 != null)
          f2 = a(str2); 
      } 
      f f1 = f2;
      if (f2 == null) {
        f1 = f2;
        if (i != -1)
          f1 = a(i); 
      } 
      if (G) {
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("onCreateView: id=0x");
        stringBuilder2.append(Integer.toHexString(n));
        stringBuilder2.append(" fname=");
        stringBuilder2.append(str1);
        stringBuilder2.append(" existing=");
        stringBuilder2.append(f1);
        Log.v("FragmentManager", stringBuilder2.toString());
      } 
      if (f1 == null) {
        int i1;
        f1 = this.p.a(paramContext, str1, null);
        f1.o = true;
        if (n != 0) {
          i1 = n;
        } else {
          i1 = i;
        } 
        f1.z = i1;
        f1.A = i;
        f1.B = str2;
        f1.p = true;
        f1.t = this;
        j j1 = this.o;
        f1.u = j1;
        f1.a(j1.c(), paramAttributeSet, f1.d);
        a(f1, true);
      } else if (!f1.p) {
        f1.p = true;
        j j1 = this.o;
        f1.u = j1;
        if (!f1.F)
          f1.a(j1.c(), paramAttributeSet, f1.d); 
      } else {
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append(paramAttributeSet.getPositionDescription());
        stringBuilder1.append(": Duplicate id 0x");
        stringBuilder1.append(Integer.toHexString(n));
        stringBuilder1.append(", tag ");
        stringBuilder1.append(str2);
        stringBuilder1.append(", or parent id 0x");
        stringBuilder1.append(Integer.toHexString(i));
        stringBuilder1.append(" with another fragment for ");
        stringBuilder1.append(str1);
        throw new IllegalArgumentException(stringBuilder1.toString());
      } 
      if (this.n < 1 && ((f)stringBuilder1).o) {
        a((f)stringBuilder1, 1, 0, 0, false);
      } else {
        j((f)stringBuilder1);
      } 
      View view1 = ((f)stringBuilder1).K;
      if (view1 != null) {
        if (n != 0)
          view1.setId(n); 
        if (((f)stringBuilder1).K.getTag() == null)
          ((f)stringBuilder1).K.setTag(str2); 
        return ((f)stringBuilder1).K;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Fragment ");
      stringBuilder1.append(str1);
      stringBuilder1.append(" did not create a view.");
      throw new IllegalStateException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramAttributeSet.getPositionDescription());
    stringBuilder.append(": Must specify unique android:id, android:tag, or have a parent with an id for ");
    stringBuilder.append(str1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  LayoutInflater.Factory2 p() {
    return this;
  }
  
  public void p(f paramf) {
    if (G) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("show: ");
      stringBuilder.append(paramf);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramf.C) {
      paramf.C = false;
      paramf.Q ^= 0x1;
    } 
  }
  
  public f q() {
    return this.r;
  }
  
  public void r() {
    this.E = null;
    this.t = false;
    this.u = false;
    int i = this.f.size();
    for (byte b = 0; b < i; b++) {
      f f1 = this.f.get(b);
      if (f1 != null)
        f1.J(); 
    } 
  }
  
  void s() {
    if (this.l != null)
      for (byte b = 0; b < this.l.size(); b++)
        ((k.c)this.l.get(b)).a();  
  }
  
  m t() {
    a(this.E);
    return this.E;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    f f1 = this.q;
    if (f1 != null) {
      a.b.g.g.d.a(f1, stringBuilder);
    } else {
      a.b.g.g.d.a(this.o, stringBuilder);
    } 
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  Parcelable u() {
    StringBuilder stringBuilder1;
    StringBuilder stringBuilder2;
    C();
    B();
    o();
    this.t = true;
    this.E = null;
    SparseArray<f> sparseArray = this.g;
    if (sparseArray == null || sparseArray.size() <= 0)
      return null; 
    int n = this.g.size();
    o[] arrayOfO = new o[n];
    int i = 0;
    byte b;
    for (b = 0; b < n; b++) {
      f f2 = (f)this.g.valueAt(b);
      if (f2 != null)
        if (f2.g >= 0) {
          boolean bool = true;
          o o = new o(f2);
          arrayOfO[b] = o;
          if (f2.c > 0 && o.m == null) {
            o.m = m(f2);
            f f3 = f2.j;
            if (f3 != null)
              if (f3.g >= 0) {
                if (o.m == null)
                  o.m = new Bundle(); 
                a(o.m, "android:target_state", f2.j);
                i = f2.l;
                if (i != 0)
                  o.m.putInt("android:target_req_state", i); 
              } else {
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Failure saving state: ");
                stringBuilder2.append(f2);
                stringBuilder2.append(" has target not in fragment manager: ");
                stringBuilder2.append(f2.j);
                a(new IllegalStateException(stringBuilder2.toString()));
                throw null;
              }  
          } else {
            ((o)stringBuilder2).m = f2.d;
          } 
          i = bool;
          if (G) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Saved state of ");
            stringBuilder.append(f2);
            stringBuilder.append(": ");
            stringBuilder.append(((o)stringBuilder2).m);
            Log.v("FragmentManager", stringBuilder.toString());
            i = bool;
          } 
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Failure saving state: active ");
          stringBuilder2.append(f2);
          stringBuilder2.append(" has cleared index: ");
          stringBuilder2.append(f2.g);
          a(new IllegalStateException(stringBuilder2.toString()));
          throw null;
        }  
    } 
    if (i == 0) {
      if (G)
        Log.v("FragmentManager", "saveAllState: no fragments!"); 
      return null;
    } 
    sparseArray = null;
    d[] arrayOfD2 = null;
    i = this.f.size();
    if (i > 0) {
      int[] arrayOfInt = new int[i];
      b = 0;
      while (true) {
        int[] arrayOfInt1 = arrayOfInt;
        if (b < i) {
          arrayOfInt[b] = ((f)this.f.get(b)).g;
          if (arrayOfInt[b] >= 0) {
            if (G) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("saveAllState: adding fragment #");
              stringBuilder.append(b);
              stringBuilder.append(": ");
              stringBuilder.append(this.f.get(b));
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            b++;
            continue;
          } 
          stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Failure saving state: active ");
          stringBuilder1.append(this.f.get(b));
          stringBuilder1.append(" has cleared index: ");
          stringBuilder1.append(arrayOfInt[b]);
          a(new IllegalStateException(stringBuilder1.toString()));
          throw null;
        } 
        break;
      } 
    } 
    ArrayList<c> arrayList = this.h;
    d[] arrayOfD1 = arrayOfD2;
    if (arrayList != null) {
      i = arrayList.size();
      arrayOfD1 = arrayOfD2;
      if (i > 0) {
        arrayOfD2 = new d[i];
        b = 0;
        while (true) {
          arrayOfD1 = arrayOfD2;
          if (b < i) {
            arrayOfD2[b] = new d(this.h.get(b));
            if (G) {
              stringBuilder2 = new StringBuilder();
              stringBuilder2.append("saveAllState: adding back stack #");
              stringBuilder2.append(b);
              stringBuilder2.append(": ");
              stringBuilder2.append(this.h.get(b));
              Log.v("FragmentManager", stringBuilder2.toString());
            } 
            b++;
            continue;
          } 
          break;
        } 
      } 
    } 
    n n1 = new n();
    n1.c = arrayOfO;
    n1.d = (int[])stringBuilder1;
    n1.e = (d[])stringBuilder2;
    f f1 = this.r;
    if (f1 != null)
      n1.f = f1.g; 
    n1.g = this.e;
    v();
    return n1;
  }
  
  void v() {
    ArrayList<f> arrayList4 = null;
    ArrayList<f> arrayList1 = null;
    ArrayList<f> arrayList5 = null;
    ArrayList<f> arrayList3 = null;
    ArrayList<f> arrayList6 = null;
    ArrayList<f> arrayList2 = null;
    if (this.g != null) {
      byte b = 0;
      while (true) {
        arrayList4 = arrayList1;
        arrayList5 = arrayList3;
        arrayList6 = arrayList2;
        if (b < this.g.size()) {
          f f1 = (f)this.g.valueAt(b);
          arrayList5 = arrayList1;
          arrayList6 = arrayList3;
          ArrayList<f> arrayList = arrayList2;
          if (f1 != null) {
            m m1;
            arrayList4 = arrayList1;
            if (f1.E) {
              byte b1;
              arrayList5 = arrayList1;
              if (arrayList1 == null)
                arrayList5 = new ArrayList(); 
              arrayList5.add(f1);
              f f2 = f1.j;
              if (f2 != null) {
                b1 = f2.g;
              } else {
                b1 = -1;
              } 
              f1.k = b1;
              arrayList4 = arrayList5;
              if (G) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("retainNonConfig: keeping retained ");
                stringBuilder.append(f1);
                Log.v("FragmentManager", stringBuilder.toString());
                arrayList4 = arrayList5;
              } 
            } 
            l l1 = f1.v;
            if (l1 != null) {
              l1.v();
              m1 = f1.v.E;
            } else {
              m1 = f1.w;
            } 
            ArrayList<f> arrayList7 = arrayList3;
            if (arrayList3 == null) {
              arrayList7 = arrayList3;
              if (m1 != null) {
                arrayList3 = new ArrayList<f>(this.g.size());
                byte b1 = 0;
                while (true) {
                  arrayList7 = arrayList3;
                  if (b1 < b) {
                    arrayList3.add(null);
                    b1++;
                    continue;
                  } 
                  break;
                } 
              } 
            } 
            if (arrayList7 != null)
              arrayList7.add(m1); 
            arrayList3 = arrayList2;
            if (arrayList2 == null) {
              arrayList3 = arrayList2;
              if (f1.x != null) {
                arrayList2 = new ArrayList<f>(this.g.size());
                byte b1 = 0;
                while (true) {
                  arrayList3 = arrayList2;
                  if (b1 < b) {
                    arrayList2.add(null);
                    b1++;
                    continue;
                  } 
                  break;
                } 
              } 
            } 
            arrayList5 = arrayList4;
            arrayList6 = arrayList7;
            arrayList = arrayList3;
            if (arrayList3 != null) {
              arrayList3.add(f1.x);
              arrayList = arrayList3;
              arrayList6 = arrayList7;
              arrayList5 = arrayList4;
            } 
          } 
          b++;
          arrayList1 = arrayList5;
          arrayList3 = arrayList6;
          arrayList2 = arrayList;
          continue;
        } 
        break;
      } 
    } 
    if (arrayList4 == null && arrayList5 == null && arrayList6 == null) {
      this.E = null;
    } else {
      this.E = new m(arrayList4, (List)arrayList5, (List)arrayList6);
    } 
  }
  
  void w() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield D : Ljava/util/ArrayList;
    //   6: astore #4
    //   8: iconst_0
    //   9: istore_3
    //   10: aload #4
    //   12: ifnull -> 30
    //   15: aload_0
    //   16: getfield D : Ljava/util/ArrayList;
    //   19: invokevirtual isEmpty : ()Z
    //   22: ifne -> 30
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_3
    //   33: istore_2
    //   34: aload_0
    //   35: getfield c : Ljava/util/ArrayList;
    //   38: ifnull -> 56
    //   41: iload_3
    //   42: istore_2
    //   43: aload_0
    //   44: getfield c : Ljava/util/ArrayList;
    //   47: invokevirtual size : ()I
    //   50: iconst_1
    //   51: if_icmpne -> 56
    //   54: iconst_1
    //   55: istore_2
    //   56: iload_1
    //   57: ifne -> 64
    //   60: iload_2
    //   61: ifeq -> 93
    //   64: aload_0
    //   65: getfield o : Landroid/support/v4/app/j;
    //   68: invokevirtual e : ()Landroid/os/Handler;
    //   71: aload_0
    //   72: getfield F : Ljava/lang/Runnable;
    //   75: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   78: aload_0
    //   79: getfield o : Landroid/support/v4/app/j;
    //   82: invokevirtual e : ()Landroid/os/Handler;
    //   85: aload_0
    //   86: getfield F : Ljava/lang/Runnable;
    //   89: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   92: pop
    //   93: aload_0
    //   94: monitorexit
    //   95: return
    //   96: astore #4
    //   98: aload_0
    //   99: monitorexit
    //   100: aload #4
    //   102: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	96	finally
    //   15	25	96	finally
    //   34	41	96	finally
    //   43	54	96	finally
    //   64	93	96	finally
    //   93	95	96	finally
    //   98	100	96	finally
  }
  
  void x() {
    if (this.g == null)
      return; 
    for (byte b = 0; b < this.g.size(); b++) {
      f f1 = (f)this.g.valueAt(b);
      if (f1 != null)
        k(f1); 
    } 
  }
  
  class a implements Runnable {
    final l c;
    
    a(l this$0) {}
    
    public void run() {
      this.c.o();
    }
  }
  
  class b extends f {
    final ViewGroup b;
    
    final f c;
    
    final l d;
    
    b(l this$0, Animation.AnimationListener param1AnimationListener, ViewGroup param1ViewGroup, f param1f) {
      super(param1AnimationListener);
    }
    
    public void onAnimationEnd(Animation param1Animation) {
      super.onAnimationEnd(param1Animation);
      this.b.post(new a(this));
    }
    
    class a implements Runnable {
      final l.b c;
      
      a(l.b this$0) {}
      
      public void run() {
        if (this.c.c.g() != null) {
          this.c.c.a((View)null);
          l.b b1 = this.c;
          l l = b1.d;
          f f = b1.c;
          l.a(f, f.z(), 0, 0, false);
        } 
      }
    }
  }
  
  class a implements Runnable {
    final l.b c;
    
    a(l this$0) {}
    
    public void run() {
      if (this.c.c.g() != null) {
        this.c.c.a((View)null);
        l.b b1 = this.c;
        l l = b1.d;
        f f = b1.c;
        l.a(f, f.z(), 0, 0, false);
      } 
    }
  }
  
  class c extends AnimatorListenerAdapter {
    final ViewGroup a;
    
    final View b;
    
    final f c;
    
    final l d;
    
    c(l this$0, ViewGroup param1ViewGroup, View param1View, f param1f) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.endViewTransition(this.b);
      param1Animator = this.c.h();
      this.c.a((Animator)null);
      if (param1Animator != null && this.a.indexOfChild(this.b) < 0) {
        l l1 = this.d;
        f f1 = this.c;
        l1.a(f1, f1.z(), 0, 0, false);
      } 
    }
  }
  
  class d extends AnimatorListenerAdapter {
    final ViewGroup a;
    
    final View b;
    
    final f c;
    
    d(l this$0, ViewGroup param1ViewGroup, View param1View, f param1f) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.endViewTransition(this.b);
      param1Animator.removeListener((Animator.AnimatorListener)this);
      View view = this.c.K;
      if (view != null)
        view.setVisibility(8); 
    }
  }
  
  private static class e extends f {
    View b;
    
    e(View param1View, Animation.AnimationListener param1AnimationListener) {
      super(param1AnimationListener);
      this.b = param1View;
    }
    
    public void onAnimationEnd(Animation param1Animation) {
      if (u.x(this.b) || Build.VERSION.SDK_INT >= 24) {
        this.b.post(new a(this));
      } else {
        this.b.setLayerType(0, null);
      } 
      super.onAnimationEnd(param1Animation);
    }
    
    class a implements Runnable {
      final l.e c;
      
      a(l.e this$0) {}
      
      public void run() {
        this.c.b.setLayerType(0, null);
      }
    }
  }
  
  class a implements Runnable {
    final l.e c;
    
    a(l this$0) {}
    
    public void run() {
      this.c.b.setLayerType(0, null);
    }
  }
  
  private static class f implements Animation.AnimationListener {
    private final Animation.AnimationListener a;
    
    f(Animation.AnimationListener param1AnimationListener) {
      this.a = param1AnimationListener;
    }
    
    public void onAnimationEnd(Animation param1Animation) {
      Animation.AnimationListener animationListener = this.a;
      if (animationListener != null)
        animationListener.onAnimationEnd(param1Animation); 
    }
    
    public void onAnimationRepeat(Animation param1Animation) {
      Animation.AnimationListener animationListener = this.a;
      if (animationListener != null)
        animationListener.onAnimationRepeat(param1Animation); 
    }
    
    public void onAnimationStart(Animation param1Animation) {
      Animation.AnimationListener animationListener = this.a;
      if (animationListener != null)
        animationListener.onAnimationStart(param1Animation); 
    }
  }
  
  private static class g {
    public final Animation a = null;
    
    public final Animator b;
    
    g(Animator param1Animator) {
      this.b = param1Animator;
      if (param1Animator != null)
        return; 
      throw new IllegalStateException("Animator cannot be null");
    }
    
    g(Animation param1Animation) {
      this.b = null;
      if (param1Animation != null)
        return; 
      throw new IllegalStateException("Animation cannot be null");
    }
  }
  
  private static class h extends AnimatorListenerAdapter {
    View a;
    
    h(View param1View) {
      this.a = param1View;
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.setLayerType(0, null);
      param1Animator.removeListener((Animator.AnimatorListener)this);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.a.setLayerType(2, null);
    }
  }
  
  private static class i extends AnimationSet implements Runnable {
    private final ViewGroup c;
    
    private final View d;
    
    private boolean e;
    
    private boolean f;
    
    private boolean g = true;
    
    i(Animation param1Animation, ViewGroup param1ViewGroup, View param1View) {
      super(false);
      this.c = param1ViewGroup;
      this.d = param1View;
      addAnimation(param1Animation);
      this.c.post(this);
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation) {
      this.g = true;
      if (this.e)
        return true ^ this.f; 
      if (!super.getTransformation(param1Long, param1Transformation)) {
        this.e = true;
        a0.a((View)this.c, this);
      } 
      return true;
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation, float param1Float) {
      this.g = true;
      if (this.e)
        return true ^ this.f; 
      if (!super.getTransformation(param1Long, param1Transformation, param1Float)) {
        this.e = true;
        a0.a((View)this.c, this);
      } 
      return true;
    }
    
    public void run() {
      if (!this.e && this.g) {
        this.g = false;
        this.c.post(this);
      } else {
        this.c.endViewTransition(this.d);
        this.f = true;
      } 
    }
  }
  
  private static final class j {
    final k.b a;
    
    final boolean b;
  }
  
  static class k {
    public static final int[] a = new int[] { 16842755, 16842960, 16842961 };
  }
  
  static interface l {
    boolean a(ArrayList<c> param1ArrayList, ArrayList<Boolean> param1ArrayList1);
  }
  
  private class m implements l {
    final String a;
    
    final int b;
    
    final int c;
    
    final l d;
    
    m(l this$0, String param1String, int param1Int1, int param1Int2) {
      this.a = param1String;
      this.b = param1Int1;
      this.c = param1Int2;
    }
    
    public boolean a(ArrayList<c> param1ArrayList, ArrayList<Boolean> param1ArrayList1) {
      f f = this.d.r;
      if (f != null && this.b < 0 && this.a == null) {
        k k = f.S();
        if (k != null && k.d())
          return false; 
      } 
      return this.d.a(param1ArrayList, param1ArrayList1, this.a, this.b, this.c);
    }
  }
  
  static class n implements f.f {
    final boolean a;
    
    final c b;
    
    private int c;
    
    n(c param1c, boolean param1Boolean) {
      this.a = param1Boolean;
      this.b = param1c;
    }
    
    public void a() {
      this.c--;
      if (this.c != 0)
        return; 
      this.b.a.w();
    }
    
    public void b() {
      this.c++;
    }
    
    public void c() {
      c c1 = this.b;
      c1.a.a(c1, this.a, false, false);
    }
    
    public void d() {
      int i = this.c;
      boolean bool = false;
      if (i > 0) {
        i = 1;
      } else {
        i = 0;
      } 
      l l = this.b.a;
      int j = l.f.size();
      for (byte b = 0; b < j; b++) {
        f f1 = l.f.get(b);
        f1.a((f.f)null);
        if (i != 0 && f1.H())
          f1.c0(); 
      } 
      c c1 = this.b;
      l = c1.a;
      boolean bool1 = this.a;
      if (i == 0)
        bool = true; 
      l.a(c1, bool1, bool, true);
    }
    
    public boolean e() {
      boolean bool;
      if (this.c == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */