package android.support.v4.app;

import a.b.g.g.m;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class j<E> extends h {
  private final Activity a;
  
  private final Context b;
  
  private final Handler c;
  
  final l d = new l();
  
  j(Activity paramActivity, Context paramContext, Handler paramHandler, int paramInt) {
    this.a = paramActivity;
    m.a(paramContext, "context == null");
    this.b = paramContext;
    m.a(paramHandler, "handler == null");
    this.c = paramHandler;
  }
  
  j(g paramg) {
    this(paramg, (Context)paramg, paramg.d, 0);
  }
  
  abstract void a(f paramf);
  
  public abstract void a(f paramf, Intent paramIntent, int paramInt, Bundle paramBundle);
  
  public abstract void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);
  
  Activity b() {
    return this.a;
  }
  
  public abstract boolean b(f paramf);
  
  Context c() {
    return this.b;
  }
  
  l d() {
    return this.d;
  }
  
  Handler e() {
    return this.c;
  }
  
  public abstract LayoutInflater f();
  
  public abstract int g();
  
  public abstract boolean h();
  
  public abstract void i();
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */