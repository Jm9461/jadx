package android.support.v4.app;

import android.graphics.Rect;
import android.support.v4.view.u;
import android.support.v4.view.w;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public abstract class t {
  static String a(Map<String, String> paramMap, String paramString) {
    for (Map.Entry<String, String> entry : paramMap.entrySet()) {
      if (paramString.equals(entry.getValue()))
        return (String)entry.getKey(); 
    } 
    return null;
  }
  
  protected static void a(List<View> paramList, View paramView) {
    int j = paramList.size();
    if (a(paramList, paramView, j))
      return; 
    paramList.add(paramView);
    for (int i = j; i < paramList.size(); i++) {
      paramView = paramList.get(i);
      if (paramView instanceof ViewGroup) {
        ViewGroup viewGroup = (ViewGroup)paramView;
        int k = viewGroup.getChildCount();
        for (byte b = 0; b < k; b++) {
          paramView = viewGroup.getChildAt(b);
          if (!a(paramList, paramView, j))
            paramList.add(paramView); 
        } 
      } 
    } 
  }
  
  protected static boolean a(List paramList) {
    return (paramList == null || paramList.isEmpty());
  }
  
  private static boolean a(List<View> paramList, View paramView, int paramInt) {
    for (byte b = 0; b < paramInt; b++) {
      if (paramList.get(b) == paramView)
        return true; 
    } 
    return false;
  }
  
  public abstract Object a(Object paramObject1, Object paramObject2, Object paramObject3);
  
  ArrayList<String> a(ArrayList<View> paramArrayList) {
    ArrayList<String> arrayList = new ArrayList();
    int i = paramArrayList.size();
    for (byte b = 0; b < i; b++) {
      View view = paramArrayList.get(b);
      arrayList.add(u.q(view));
      u.a(view, null);
    } 
    return arrayList;
  }
  
  protected void a(View paramView, Rect paramRect) {
    int[] arrayOfInt = new int[2];
    paramView.getLocationOnScreen(arrayOfInt);
    paramRect.set(arrayOfInt[0], arrayOfInt[1], arrayOfInt[0] + paramView.getWidth(), arrayOfInt[1] + paramView.getHeight());
  }
  
  void a(View paramView, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2, ArrayList<String> paramArrayList, Map<String, String> paramMap) {
    int i = paramArrayList2.size();
    ArrayList<String> arrayList = new ArrayList();
    for (byte b = 0; b < i; b++) {
      View view = paramArrayList1.get(b);
      String str = u.q(view);
      arrayList.add(str);
      if (str != null) {
        u.a(view, null);
        String str1 = paramMap.get(str);
        for (byte b1 = 0; b1 < i; b1++) {
          if (str1.equals(paramArrayList.get(b1))) {
            u.a(paramArrayList2.get(b1), str);
            break;
          } 
        } 
      } 
    } 
    a0.a(paramView, new a(this, i, paramArrayList2, paramArrayList, paramArrayList1, arrayList));
  }
  
  void a(View paramView, ArrayList<View> paramArrayList, Map<String, String> paramMap) {
    a0.a(paramView, new b(this, paramArrayList, paramMap));
  }
  
  public abstract void a(ViewGroup paramViewGroup, Object paramObject);
  
  void a(ViewGroup paramViewGroup, ArrayList<View> paramArrayList, Map<String, String> paramMap) {
    a0.a((View)paramViewGroup, new c(this, paramArrayList, paramMap));
  }
  
  public abstract void a(Object paramObject, Rect paramRect);
  
  public abstract void a(Object paramObject, View paramView);
  
  public abstract void a(Object paramObject, View paramView, ArrayList<View> paramArrayList);
  
  public abstract void a(Object paramObject1, Object paramObject2, ArrayList<View> paramArrayList1, Object paramObject3, ArrayList<View> paramArrayList2, Object paramObject4, ArrayList<View> paramArrayList3);
  
  public abstract void a(Object paramObject, ArrayList<View> paramArrayList);
  
  public abstract void a(Object paramObject, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2);
  
  void a(ArrayList<View> paramArrayList, View paramView) {
    if (paramView.getVisibility() == 0) {
      ViewGroup viewGroup;
      if (paramView instanceof ViewGroup) {
        viewGroup = (ViewGroup)paramView;
        if (w.a(viewGroup)) {
          paramArrayList.add(viewGroup);
        } else {
          int i = viewGroup.getChildCount();
          for (byte b = 0; b < i; b++)
            a(paramArrayList, viewGroup.getChildAt(b)); 
        } 
      } else {
        paramArrayList.add(viewGroup);
      } 
    } 
  }
  
  void a(Map<String, View> paramMap, View paramView) {
    if (paramView.getVisibility() == 0) {
      String str = u.q(paramView);
      if (str != null)
        paramMap.put(str, paramView); 
      if (paramView instanceof ViewGroup) {
        ViewGroup viewGroup = (ViewGroup)paramView;
        int i = viewGroup.getChildCount();
        for (byte b = 0; b < i; b++)
          a(paramMap, viewGroup.getChildAt(b)); 
      } 
    } 
  }
  
  public abstract boolean a(Object paramObject);
  
  public abstract Object b(Object paramObject);
  
  public abstract Object b(Object paramObject1, Object paramObject2, Object paramObject3);
  
  public abstract void b(Object paramObject, View paramView);
  
  public abstract void b(Object paramObject, View paramView, ArrayList<View> paramArrayList);
  
  public abstract void b(Object paramObject, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2);
  
  public abstract Object c(Object paramObject);
  
  public abstract void c(Object paramObject, View paramView);
  
  class a implements Runnable {
    final int c;
    
    final ArrayList d;
    
    final ArrayList e;
    
    final ArrayList f;
    
    final ArrayList g;
    
    a(t this$0, int param1Int, ArrayList param1ArrayList1, ArrayList param1ArrayList2, ArrayList param1ArrayList3, ArrayList param1ArrayList4) {}
    
    public void run() {
      for (byte b = 0; b < this.c; b++) {
        u.a(this.d.get(b), this.e.get(b));
        u.a(this.f.get(b), this.g.get(b));
      } 
    }
  }
  
  class b implements Runnable {
    final ArrayList c;
    
    final Map d;
    
    b(t this$0, ArrayList param1ArrayList, Map param1Map) {}
    
    public void run() {
      int i = this.c.size();
      for (byte b1 = 0; b1 < i; b1++) {
        View view = this.c.get(b1);
        String str = u.q(view);
        if (str != null)
          u.a(view, t.a(this.d, str)); 
      } 
    }
  }
  
  class c implements Runnable {
    final ArrayList c;
    
    final Map d;
    
    c(t this$0, ArrayList param1ArrayList, Map param1Map) {}
    
    public void run() {
      int i = this.c.size();
      for (byte b = 0; b < i; b++) {
        View view = this.c.get(b);
        String str = u.q(view);
        u.a(view, (String)this.d.get(str));
      } 
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */