package android.support.v4.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.content.a;

public class a extends a {
  private static c c;
  
  public static c a() {
    return c;
  }
  
  public static void a(Activity paramActivity) {
    if (Build.VERSION.SDK_INT >= 16) {
      paramActivity.finishAffinity();
    } else {
      paramActivity.finish();
    } 
  }
  
  public static void a(Activity paramActivity, Intent paramIntent, int paramInt, Bundle paramBundle) {
    if (Build.VERSION.SDK_INT >= 16) {
      paramActivity.startActivityForResult(paramIntent, paramInt, paramBundle);
    } else {
      paramActivity.startActivityForResult(paramIntent, paramInt);
    } 
  }
  
  public static void a(Activity paramActivity, String[] paramArrayOfString, int paramInt) {
    c c1 = c;
    if (c1 != null && c1.a(paramActivity, paramArrayOfString, paramInt))
      return; 
    if (Build.VERSION.SDK_INT >= 23) {
      if (paramActivity instanceof d)
        ((d)paramActivity).a(paramInt); 
      paramActivity.requestPermissions(paramArrayOfString, paramInt);
    } else if (paramActivity instanceof b) {
      (new Handler(Looper.getMainLooper())).post(new a(paramArrayOfString, paramActivity, paramInt));
    } 
  }
  
  static final class a implements Runnable {
    final String[] c;
    
    final Activity d;
    
    final int e;
    
    a(String[] param1ArrayOfString, Activity param1Activity, int param1Int) {}
    
    public void run() {
      int[] arrayOfInt = new int[this.c.length];
      PackageManager packageManager = this.d.getPackageManager();
      String str = this.d.getPackageName();
      int i = this.c.length;
      for (byte b = 0; b < i; b++)
        arrayOfInt[b] = packageManager.checkPermission(this.c[b], str); 
      ((a.b)this.d).onRequestPermissionsResult(this.e, this.c, arrayOfInt);
    }
  }
  
  public static interface b {
    void onRequestPermissionsResult(int param1Int, String[] param1ArrayOfString, int[] param1ArrayOfint);
  }
  
  public static interface c {
    boolean a(Activity param1Activity, int param1Int1, int param1Int2, Intent param1Intent);
    
    boolean a(Activity param1Activity, String[] param1ArrayOfString, int param1Int);
  }
  
  public static interface d {
    void a(int param1Int);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */