package android.support.v4.app;

import android.app.RemoteInput;

public final class b0 {
  static RemoteInput a(b0 paramb0) {
    RemoteInput.Builder builder = new RemoteInput.Builder();
    paramb0.a();
    throw null;
  }
  
  static RemoteInput[] a(b0[] paramArrayOfb0) {
    if (paramArrayOfb0 == null)
      return null; 
    RemoteInput[] arrayOfRemoteInput = new RemoteInput[paramArrayOfb0.length];
    if (paramArrayOfb0.length >= 0)
      return arrayOfRemoteInput; 
    a(paramArrayOfb0[0]);
    throw null;
  }
  
  public String a() {
    throw null;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */