package android.support.v4.app;

import android.arch.lifecycle.p;
import java.util.List;

public class m {
  private final List<f> a;
  
  private final List<m> b;
  
  private final List<p> c;
  
  m(List<f> paramList, List<m> paramList1, List<p> paramList2) {
    this.a = paramList;
    this.b = paramList1;
    this.c = paramList2;
  }
  
  List<m> a() {
    return this.b;
  }
  
  List<f> b() {
    return this.a;
  }
  
  List<p> c() {
    return this.c;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */