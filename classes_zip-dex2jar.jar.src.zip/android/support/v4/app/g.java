package android.support.v4.app;

import a.b.g.g.o;
import android.arch.lifecycle.p;
import android.arch.lifecycle.q;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class g extends e0 implements q, a.b, a.d {
  final Handler d = new a(this);
  
  final i e = i.a(new b(this));
  
  private p f;
  
  boolean g;
  
  boolean h;
  
  boolean i = true;
  
  boolean j;
  
  boolean k;
  
  boolean l;
  
  int m;
  
  o<String> n;
  
  private static boolean a(k paramk, android.arch.lifecycle.c.b paramb) {
    boolean bool = false;
    for (f f : paramk.b()) {
      if (f == null)
        continue; 
      boolean bool1 = bool;
      if (f.a().a().a(android.arch.lifecycle.c.b.f)) {
        f.U.a(paramb);
        bool1 = true;
      } 
      k k1 = f.S();
      bool = bool1;
      if (k1 != null)
        bool = bool1 | a(k1, paramb); 
    } 
    return bool;
  }
  
  private int b(f paramf) {
    if (this.n.b() < 65534) {
      while (this.n.c(this.m) >= 0)
        this.m = (this.m + 1) % 65534; 
      int j = this.m;
      this.n.c(j, paramf.h);
      this.m = (this.m + 1) % 65534;
      return j;
    } 
    IllegalStateException illegalStateException = new IllegalStateException("Too many pending Fragment activity results.");
    throw illegalStateException;
  }
  
  static void b(int paramInt) {
    if ((0xFFFF0000 & paramInt) == 0)
      return; 
    throw new IllegalArgumentException("Can only use lower 16 bits for requestCode");
  }
  
  private void i() {
    do {
    
    } while (a(e(), android.arch.lifecycle.c.b.e));
  }
  
  public android.arch.lifecycle.c a() {
    return super.a();
  }
  
  final View a(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return this.e.a(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public final void a(int paramInt) {
    if (!this.j && paramInt != -1)
      b(paramInt); 
  }
  
  public void a(f paramf) {}
  
  public void a(f paramf, Intent paramIntent, int paramInt, Bundle paramBundle) {
    this.l = true;
    if (paramInt == -1)
      try {
        a.a(this, paramIntent, -1, paramBundle);
        return;
      } finally {
        this.l = false;
      }  
    b(paramInt);
    a.a(this, paramIntent, (b(paramf) + 1 << 16) + (0xFFFF & paramInt), paramBundle);
    this.l = false;
  }
  
  protected boolean a(View paramView, Menu paramMenu) {
    return super.onPreparePanel(0, paramView, paramMenu);
  }
  
  public p b() {
    if (getApplication() != null) {
      if (this.f == null) {
        c c = (c)getLastNonConfigurationInstance();
        if (c != null)
          this.f = c.a; 
        if (this.f == null)
          this.f = new p(); 
      } 
      return this.f;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    super.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("Local FragmentActivity ");
    paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this)));
    paramPrintWriter.println(" State:");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("  ");
    String str = stringBuilder.toString();
    paramPrintWriter.print(str);
    paramPrintWriter.print("mCreated=");
    paramPrintWriter.print(this.g);
    paramPrintWriter.print(" mResumed=");
    paramPrintWriter.print(this.h);
    paramPrintWriter.print(" mStopped=");
    paramPrintWriter.print(this.i);
    if (getApplication() != null)
      u.<g>a(this).a(str, paramFileDescriptor, paramPrintWriter, paramArrayOfString); 
    this.e.j().a(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  public k e() {
    return this.e.j();
  }
  
  protected void f() {
    this.e.f();
  }
  
  public Object g() {
    return null;
  }
  
  @Deprecated
  public void h() {
    invalidateOptionsMenu();
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    StringBuilder stringBuilder;
    this.e.k();
    int j = paramInt1 >> 16;
    if (j != 0) {
      String str = (String)this.n.b(--j);
      this.n.e(j);
      if (str == null) {
        Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
        return;
      } 
      f f = this.e.a(str);
      if (f == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Activity result no fragment exists for who: ");
        stringBuilder.append(str);
        Log.w("FragmentActivity", stringBuilder.toString());
      } else {
        f.a(0xFFFF & paramInt1, paramInt2, (Intent)stringBuilder);
      } 
      return;
    } 
    a.c c = a.a();
    if (c != null && c.a(this, paramInt1, paramInt2, (Intent)stringBuilder))
      return; 
    super.onActivityResult(paramInt1, paramInt2, (Intent)stringBuilder);
  }
  
  public void onBackPressed() {
    k k = this.e.j();
    boolean bool = k.c();
    if (bool && Build.VERSION.SDK_INT <= 25)
      return; 
    if (bool || !k.d())
      super.onBackPressed(); 
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    this.e.k();
    this.e.a(paramConfiguration);
  }
  
  protected void onCreate(Bundle paramBundle) {
    i i1 = this.e;
    m m = null;
    i1.a((f)null);
    super.onCreate(paramBundle);
    c c = (c)getLastNonConfigurationInstance();
    if (c != null) {
      p p1 = c.a;
      if (p1 != null && this.f == null)
        this.f = p1; 
    } 
    if (paramBundle != null) {
      Parcelable parcelable = paramBundle.getParcelable("android:support:fragments");
      i i2 = this.e;
      if (c != null)
        m = c.b; 
      i2.a(parcelable, m);
      if (paramBundle.containsKey("android:support:next_request_index")) {
        this.m = paramBundle.getInt("android:support:next_request_index");
        int[] arrayOfInt = paramBundle.getIntArray("android:support:request_indicies");
        String[] arrayOfString = paramBundle.getStringArray("android:support:request_fragment_who");
        if (arrayOfInt == null || arrayOfString == null || arrayOfInt.length != arrayOfString.length) {
          Log.w("FragmentActivity", "Invalid requestCode mapping in savedInstanceState.");
        } else {
          this.n = new o(arrayOfInt.length);
          for (byte b1 = 0; b1 < arrayOfInt.length; b1++)
            this.n.c(arrayOfInt[b1], arrayOfString[b1]); 
        } 
      } 
    } 
    if (this.n == null) {
      this.n = new o();
      this.m = 0;
    } 
    this.e.b();
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    return (paramInt == 0) ? (super.onCreatePanelMenu(paramInt, paramMenu) | this.e.a(paramMenu, getMenuInflater())) : super.onCreatePanelMenu(paramInt, paramMenu);
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = a(paramView, paramString, paramContext, paramAttributeSet);
    return (view == null) ? super.onCreateView(paramView, paramString, paramContext, paramAttributeSet) : view;
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = a((View)null, paramString, paramContext, paramAttributeSet);
    return (view == null) ? super.onCreateView(paramString, paramContext, paramAttributeSet) : view;
  }
  
  protected void onDestroy() {
    super.onDestroy();
    if (this.f != null && !isChangingConfigurations())
      this.f.a(); 
    this.e.c();
  }
  
  public void onLowMemory() {
    super.onLowMemory();
    this.e.d();
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem) ? true : ((paramInt != 0) ? ((paramInt != 6) ? false : this.e.a(paramMenuItem)) : this.e.b(paramMenuItem));
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean) {
    this.e.a(paramBoolean);
  }
  
  protected void onNewIntent(Intent paramIntent) {
    super.onNewIntent(paramIntent);
    this.e.k();
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    if (paramInt == 0)
      this.e.a(paramMenu); 
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  protected void onPause() {
    super.onPause();
    this.h = false;
    if (this.d.hasMessages(2)) {
      this.d.removeMessages(2);
      f();
    } 
    this.e.e();
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean) {
    this.e.b(paramBoolean);
  }
  
  protected void onPostResume() {
    super.onPostResume();
    this.d.removeMessages(2);
    f();
    this.e.i();
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    return (paramInt == 0 && paramMenu != null) ? (a(paramView, paramMenu) | this.e.b(paramMenu)) : super.onPreparePanel(paramInt, paramView, paramMenu);
  }
  
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    this.e.k();
    int j = paramInt >> 16 & 0xFFFF;
    if (j != 0) {
      StringBuilder stringBuilder;
      String str = (String)this.n.b(--j);
      this.n.e(j);
      if (str == null) {
        Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
        return;
      } 
      f f = this.e.a(str);
      if (f == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Activity result no fragment exists for who: ");
        stringBuilder.append(str);
        Log.w("FragmentActivity", stringBuilder.toString());
      } else {
        f.a(0xFFFF & paramInt, (String[])stringBuilder, paramArrayOfint);
      } 
    } 
  }
  
  protected void onResume() {
    super.onResume();
    this.d.sendEmptyMessage(2);
    this.h = true;
    this.e.i();
  }
  
  public final Object onRetainNonConfigurationInstance() {
    Object object = g();
    m m = this.e.l();
    if (m == null && this.f == null && object == null)
      return null; 
    object = new c();
    ((c)object).a = this.f;
    ((c)object).b = m;
    return object;
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    i();
    Parcelable parcelable = this.e.m();
    if (parcelable != null)
      paramBundle.putParcelable("android:support:fragments", parcelable); 
    if (this.n.b() > 0) {
      paramBundle.putInt("android:support:next_request_index", this.m);
      int[] arrayOfInt = new int[this.n.b()];
      String[] arrayOfString = new String[this.n.b()];
      for (byte b1 = 0; b1 < this.n.b(); b1++) {
        arrayOfInt[b1] = this.n.d(b1);
        arrayOfString[b1] = (String)this.n.f(b1);
      } 
      paramBundle.putIntArray("android:support:request_indicies", arrayOfInt);
      paramBundle.putStringArray("android:support:request_fragment_who", arrayOfString);
    } 
  }
  
  protected void onStart() {
    super.onStart();
    this.i = false;
    if (!this.g) {
      this.g = true;
      this.e.a();
    } 
    this.e.k();
    this.e.i();
    this.e.g();
  }
  
  public void onStateNotSaved() {
    this.e.k();
  }
  
  protected void onStop() {
    super.onStop();
    this.i = true;
    i();
    this.e.h();
  }
  
  public void startActivityForResult(Intent paramIntent, int paramInt) {
    if (!this.l && paramInt != -1)
      b(paramInt); 
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  public void startActivityForResult(Intent paramIntent, int paramInt, Bundle paramBundle) {
    if (!this.l && paramInt != -1)
      b(paramInt); 
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) {
    if (!this.k && paramInt1 != -1)
      b(paramInt1); 
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) {
    if (!this.k && paramInt1 != -1)
      b(paramInt1); 
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  class a extends Handler {
    final g a;
    
    a(g this$0) {}
    
    public void handleMessage(Message param1Message) {
      if (param1Message.what != 2) {
        super.handleMessage(param1Message);
      } else {
        this.a.f();
        this.a.e.i();
      } 
    }
  }
  
  class b extends j<g> {
    final g e;
    
    public b(g this$0) {
      super(this$0);
    }
    
    public View a(int param1Int) {
      return this.e.findViewById(param1Int);
    }
    
    public void a(f param1f) {
      this.e.a(param1f);
    }
    
    public void a(f param1f, Intent param1Intent, int param1Int, Bundle param1Bundle) {
      this.e.a(param1f, param1Intent, param1Int, param1Bundle);
    }
    
    public void a(String param1String, FileDescriptor param1FileDescriptor, PrintWriter param1PrintWriter, String[] param1ArrayOfString) {
      this.e.dump(param1String, param1FileDescriptor, param1PrintWriter, param1ArrayOfString);
    }
    
    public boolean a() {
      boolean bool;
      Window window = this.e.getWindow();
      if (window != null && window.peekDecorView() != null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public boolean b(f param1f) {
      return this.e.isFinishing() ^ true;
    }
    
    public LayoutInflater f() {
      return this.e.getLayoutInflater().cloneInContext((Context)this.e);
    }
    
    public int g() {
      int i;
      Window window = this.e.getWindow();
      if (window == null) {
        i = 0;
      } else {
        i = (window.getAttributes()).windowAnimations;
      } 
      return i;
    }
    
    public boolean h() {
      boolean bool;
      if (this.e.getWindow() != null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public void i() {
      this.e.h();
    }
  }
  
  static final class c {
    p a;
    
    m b;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */