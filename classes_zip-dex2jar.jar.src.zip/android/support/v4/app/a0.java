package android.support.v4.app;

import android.view.View;
import android.view.ViewTreeObserver;

class a0 implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {
  private final View c;
  
  private ViewTreeObserver d;
  
  private final Runnable e;
  
  private a0(View paramView, Runnable paramRunnable) {
    this.c = paramView;
    this.d = paramView.getViewTreeObserver();
    this.e = paramRunnable;
  }
  
  public static a0 a(View paramView, Runnable paramRunnable) {
    a0 a01 = new a0(paramView, paramRunnable);
    paramView.getViewTreeObserver().addOnPreDrawListener(a01);
    paramView.addOnAttachStateChangeListener(a01);
    return a01;
  }
  
  public void a() {
    if (this.d.isAlive()) {
      this.d.removeOnPreDrawListener(this);
    } else {
      this.c.getViewTreeObserver().removeOnPreDrawListener(this);
    } 
    this.c.removeOnAttachStateChangeListener(this);
  }
  
  public boolean onPreDraw() {
    a();
    this.e.run();
    return true;
  }
  
  public void onViewAttachedToWindow(View paramView) {
    this.d = paramView.getViewTreeObserver();
  }
  
  public void onViewDetachedFromWindow(View paramView) {
    a();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */