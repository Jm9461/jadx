package android.support.v4.app;

import a.b.g.g.d;
import a.b.g.g.o;
import android.arch.lifecycle.e;
import android.arch.lifecycle.j;
import android.arch.lifecycle.k;
import android.arch.lifecycle.n;
import android.arch.lifecycle.o;
import android.arch.lifecycle.p;
import android.os.Bundle;
import android.util.Log;
import java.io.FileDescriptor;
import java.io.PrintWriter;

class LoaderManagerImpl extends u {
  static boolean c = false;
  
  private final e a;
  
  private final LoaderViewModel b;
  
  LoaderManagerImpl(e parame, p paramp) {
    this.a = parame;
    this.b = LoaderViewModel.a(paramp);
  }
  
  public void a() {
    this.b.b();
  }
  
  @Deprecated
  public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    this.b.a(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("LoaderManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    d.a(this.a, stringBuilder);
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  static class LoaderViewModel extends n {
    private static final o.a b = new a();
    
    private o<LoaderManagerImpl.a> a = new o();
    
    static LoaderViewModel a(p param1p) {
      return (LoaderViewModel)(new o(param1p, b)).a(LoaderViewModel.class);
    }
    
    protected void a() {
      super.a();
      if (this.a.b() >= 0) {
        this.a.a();
        return;
      } 
      ((LoaderManagerImpl.a)this.a.f(0)).a(true);
      throw null;
    }
    
    public void a(String param1String, FileDescriptor param1FileDescriptor, PrintWriter param1PrintWriter, String[] param1ArrayOfString) {
      if (this.a.b() > 0) {
        param1PrintWriter.print(param1String);
        param1PrintWriter.println("Loaders:");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(param1String);
        stringBuilder.append("    ");
        String str = stringBuilder.toString();
        if (this.a.b() < 0) {
          LoaderManagerImpl.a a1 = (LoaderManagerImpl.a)this.a.f(0);
          param1PrintWriter.print(param1String);
          param1PrintWriter.print("  #");
          param1PrintWriter.print(this.a.d(0));
          param1PrintWriter.print(": ");
          param1PrintWriter.println(a1.toString());
          a1.a(str, param1FileDescriptor, param1PrintWriter, param1ArrayOfString);
          throw null;
        } 
      } 
    }
    
    void b() {
      int i = this.a.b();
      for (byte b = 0; b < i; b++)
        ((LoaderManagerImpl.a)this.a.f(b)).d(); 
    }
    
    static final class a implements o.a {
      public <T extends n> T a(Class<T> param2Class) {
        return (T)new LoaderManagerImpl.LoaderViewModel();
      }
    }
  }
  
  static final class a implements o.a {
    public <T extends n> T a(Class<T> param1Class) {
      return (T)new LoaderManagerImpl.LoaderViewModel();
    }
  }
  
  public static class a<D> extends j<D> implements android.support.v4.content.b.a<D> {
    private final int j;
    
    private final Bundle k;
    
    private final android.support.v4.content.b<D> l;
    
    private e m;
    
    private LoaderManagerImpl.b<D> n;
    
    private android.support.v4.content.b<D> o;
    
    android.support.v4.content.b<D> a(boolean param1Boolean) {
      if (LoaderManagerImpl.c) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("  Destroying: ");
        stringBuilder.append(this);
        Log.v("LoaderManager", stringBuilder.toString());
      } 
      this.l.a();
      throw null;
    }
    
    protected void a() {
      if (LoaderManagerImpl.c) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("  Starting: ");
        stringBuilder.append(this);
        Log.v("LoaderManager", stringBuilder.toString());
      } 
      this.l.c();
      throw null;
    }
    
    public void a(k<? super D> param1k) {
      super.a(param1k);
      this.m = null;
      this.n = null;
    }
    
    public void a(D param1D) {
      super.a(param1D);
      android.support.v4.content.b<D> b1 = this.o;
      if (b1 == null)
        return; 
      b1.b();
      throw null;
    }
    
    public void a(String param1String, FileDescriptor param1FileDescriptor, PrintWriter param1PrintWriter, String[] param1ArrayOfString) {
      param1PrintWriter.print(param1String);
      param1PrintWriter.print("mId=");
      param1PrintWriter.print(this.j);
      param1PrintWriter.print(" mArgs=");
      param1PrintWriter.println(this.k);
      param1PrintWriter.print(param1String);
      param1PrintWriter.print("mLoader=");
      param1PrintWriter.println(this.l);
      android.support.v4.content.b<D> b1 = this.l;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(param1String);
      stringBuilder.append("  ");
      b1.a(stringBuilder.toString(), param1FileDescriptor, param1PrintWriter, param1ArrayOfString);
      throw null;
    }
    
    protected void b() {
      if (LoaderManagerImpl.c) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("  Stopping: ");
        stringBuilder.append(this);
        Log.v("LoaderManager", stringBuilder.toString());
      } 
      this.l.d();
      throw null;
    }
    
    void d() {
      e e1 = this.m;
      LoaderManagerImpl.b<D> b1 = this.n;
      if (e1 != null && b1 != null) {
        super.a(b1);
        a(e1, b1);
      } 
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder(64);
      stringBuilder.append("LoaderInfo{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" #");
      stringBuilder.append(this.j);
      stringBuilder.append(" : ");
      d.a(this.l, stringBuilder);
      stringBuilder.append("}}");
      return stringBuilder.toString();
    }
  }
  
  static class b<D> implements k<D> {}
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\LoaderManagerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */