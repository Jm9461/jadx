package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable;

final class n implements Parcelable {
  public static final Parcelable.Creator<n> CREATOR = new a();
  
  o[] c;
  
  int[] d;
  
  d[] e;
  
  int f = -1;
  
  int g;
  
  public n() {}
  
  public n(Parcel paramParcel) {
    this.c = (o[])paramParcel.createTypedArray(o.CREATOR);
    this.d = paramParcel.createIntArray();
    this.e = (d[])paramParcel.createTypedArray(d.CREATOR);
    this.f = paramParcel.readInt();
    this.g = paramParcel.readInt();
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeTypedArray((Parcelable[])this.c, paramInt);
    paramParcel.writeIntArray(this.d);
    paramParcel.writeTypedArray((Parcelable[])this.e, paramInt);
    paramParcel.writeInt(this.f);
    paramParcel.writeInt(this.g);
  }
  
  static final class a implements Parcelable.Creator<n> {
    public n createFromParcel(Parcel param1Parcel) {
      return new n(param1Parcel);
    }
    
    public n[] newArray(int param1Int) {
      return new n[param1Int];
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */