package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;

final class d implements Parcelable {
  public static final Parcelable.Creator<d> CREATOR = new a();
  
  final int[] c;
  
  final int d;
  
  final int e;
  
  final String f;
  
  final int g;
  
  final int h;
  
  final CharSequence i;
  
  final int j;
  
  final CharSequence k;
  
  final ArrayList<String> l;
  
  final ArrayList<String> m;
  
  final boolean n;
  
  public d(Parcel paramParcel) {
    boolean bool;
    this.c = paramParcel.createIntArray();
    this.d = paramParcel.readInt();
    this.e = paramParcel.readInt();
    this.f = paramParcel.readString();
    this.g = paramParcel.readInt();
    this.h = paramParcel.readInt();
    this.i = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.j = paramParcel.readInt();
    this.k = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.l = paramParcel.createStringArrayList();
    this.m = paramParcel.createStringArrayList();
    if (paramParcel.readInt() != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.n = bool;
  }
  
  public d(c paramc) {
    int i = paramc.b.size();
    this.c = new int[i * 6];
    if (paramc.i) {
      int j = 0;
      for (byte b = 0; b < i; b++) {
        c.a a = paramc.b.get(b);
        int[] arrayOfInt = this.c;
        int m = j + 1;
        arrayOfInt[j] = a.a;
        int k = m + 1;
        f f = a.b;
        if (f != null) {
          j = f.g;
        } else {
          j = -1;
        } 
        arrayOfInt[m] = j;
        arrayOfInt = this.c;
        j = k + 1;
        arrayOfInt[k] = a.c;
        m = j + 1;
        arrayOfInt[j] = a.d;
        k = m + 1;
        arrayOfInt[m] = a.e;
        j = k + 1;
        arrayOfInt[k] = a.f;
      } 
      this.d = paramc.g;
      this.e = paramc.h;
      this.f = paramc.j;
      this.g = paramc.l;
      this.h = paramc.m;
      this.i = paramc.n;
      this.j = paramc.o;
      this.k = paramc.p;
      this.l = paramc.q;
      this.m = paramc.r;
      this.n = paramc.s;
      return;
    } 
    IllegalStateException illegalStateException = new IllegalStateException("Not on back stack");
    throw illegalStateException;
  }
  
  public c a(l paraml) {
    c c = new c(paraml);
    int i = 0;
    byte b = 0;
    while (i < this.c.length) {
      c.a a = new c.a();
      int[] arrayOfInt = this.c;
      int j = i + 1;
      a.a = arrayOfInt[i];
      if (l.G) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Instantiate ");
        stringBuilder.append(c);
        stringBuilder.append(" op #");
        stringBuilder.append(b);
        stringBuilder.append(" base fragment #");
        stringBuilder.append(this.c[j]);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      arrayOfInt = this.c;
      i = j + 1;
      j = arrayOfInt[j];
      if (j >= 0) {
        a.b = (f)paraml.g.get(j);
      } else {
        a.b = null;
      } 
      arrayOfInt = this.c;
      j = i + 1;
      a.c = arrayOfInt[i];
      i = j + 1;
      a.d = arrayOfInt[j];
      j = i + 1;
      a.e = arrayOfInt[i];
      a.f = arrayOfInt[j];
      c.c = a.c;
      c.d = a.d;
      c.e = a.e;
      c.f = a.f;
      c.a(a);
      b++;
      i = j + 1;
    } 
    c.g = this.d;
    c.h = this.e;
    c.j = this.f;
    c.l = this.g;
    c.i = true;
    c.m = this.h;
    c.n = this.i;
    c.o = this.j;
    c.p = this.k;
    c.q = this.l;
    c.r = this.m;
    c.s = this.n;
    c.a(1);
    return c;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeIntArray(this.c);
    paramParcel.writeInt(this.d);
    paramParcel.writeInt(this.e);
    paramParcel.writeString(this.f);
    paramParcel.writeInt(this.g);
    paramParcel.writeInt(this.h);
    TextUtils.writeToParcel(this.i, paramParcel, 0);
    paramParcel.writeInt(this.j);
    TextUtils.writeToParcel(this.k, paramParcel, 0);
    paramParcel.writeStringList(this.l);
    paramParcel.writeStringList(this.m);
    paramParcel.writeInt(this.n);
  }
  
  static final class a implements Parcelable.Creator<d> {
    public d createFromParcel(Parcel param1Parcel) {
      return new d(param1Parcel);
    }
    
    public d[] newArray(int param1Int) {
      return new d[param1Int];
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\app\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */