package android.support.v4.view;

import android.view.View;
import android.view.ViewParent;

public class l {
  private ViewParent a;
  
  private ViewParent b;
  
  private final View c;
  
  private boolean d;
  
  private int[] e;
  
  public l(View paramView) {
    this.c = paramView;
  }
  
  private void a(int paramInt, ViewParent paramViewParent) {
    if (paramInt != 0) {
      if (paramInt == 1)
        this.b = paramViewParent; 
    } else {
      this.a = paramViewParent;
    } 
  }
  
  private ViewParent d(int paramInt) {
    return (paramInt != 0) ? ((paramInt != 1) ? null : this.b) : this.a;
  }
  
  public void a(boolean paramBoolean) {
    if (this.d)
      u.D(this.c); 
    this.d = paramBoolean;
  }
  
  public boolean a() {
    return a(0);
  }
  
  public boolean a(float paramFloat1, float paramFloat2) {
    if (b()) {
      ViewParent viewParent = d(0);
      if (viewParent != null)
        return x.a(viewParent, this.c, paramFloat1, paramFloat2); 
    } 
    return false;
  }
  
  public boolean a(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    if (b()) {
      ViewParent viewParent = d(0);
      if (viewParent != null)
        return x.a(viewParent, this.c, paramFloat1, paramFloat2, paramBoolean); 
    } 
    return false;
  }
  
  public boolean a(int paramInt) {
    boolean bool;
    if (d(paramInt) != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean a(int paramInt1, int paramInt2) {
    if (a(paramInt2))
      return true; 
    if (b()) {
      ViewParent viewParent = this.c.getParent();
      View view = this.c;
      while (viewParent != null) {
        if (x.b(viewParent, view, this.c, paramInt1, paramInt2)) {
          a(paramInt2, viewParent);
          x.a(viewParent, view, this.c, paramInt1, paramInt2);
          return true;
        } 
        if (viewParent instanceof View)
          view = (View)viewParent; 
        viewParent = viewParent.getParent();
      } 
    } 
    return false;
  }
  
  public boolean a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    return a(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint, 0);
  }
  
  public boolean a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint, int paramInt5) {
    if (b()) {
      ViewParent viewParent = d(paramInt5);
      if (viewParent == null)
        return false; 
      if (paramInt1 != 0 || paramInt2 != 0 || paramInt3 != 0 || paramInt4 != 0) {
        byte b1;
        byte b2;
        if (paramArrayOfint != null) {
          this.c.getLocationInWindow(paramArrayOfint);
          b1 = paramArrayOfint[0];
          int i = paramArrayOfint[1];
          b2 = b1;
          b1 = i;
        } else {
          b2 = 0;
          b1 = 0;
        } 
        x.a(viewParent, this.c, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
        if (paramArrayOfint != null) {
          this.c.getLocationInWindow(paramArrayOfint);
          paramArrayOfint[0] = paramArrayOfint[0] - b2;
          paramArrayOfint[1] = paramArrayOfint[1] - b1;
        } 
        return true;
      } 
      if (paramArrayOfint != null) {
        paramArrayOfint[0] = 0;
        paramArrayOfint[1] = 0;
      } 
    } 
    return false;
  }
  
  public boolean a(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    return a(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, 0);
  }
  
  public boolean a(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt3) {
    if (b()) {
      ViewParent viewParent = d(paramInt3);
      if (viewParent == null)
        return false; 
      boolean bool = true;
      if (paramInt1 != 0 || paramInt2 != 0) {
        byte b1;
        byte b2;
        if (paramArrayOfint2 != null) {
          this.c.getLocationInWindow(paramArrayOfint2);
          b1 = paramArrayOfint2[0];
          b2 = paramArrayOfint2[1];
        } else {
          b1 = 0;
          b2 = 0;
        } 
        if (paramArrayOfint1 == null) {
          if (this.e == null)
            this.e = new int[2]; 
          paramArrayOfint1 = this.e;
        } 
        paramArrayOfint1[0] = 0;
        paramArrayOfint1[1] = 0;
        x.a(viewParent, this.c, paramInt1, paramInt2, paramArrayOfint1, paramInt3);
        if (paramArrayOfint2 != null) {
          this.c.getLocationInWindow(paramArrayOfint2);
          paramArrayOfint2[0] = paramArrayOfint2[0] - b1;
          paramArrayOfint2[1] = paramArrayOfint2[1] - b2;
        } 
        boolean bool1 = bool;
        if (paramArrayOfint1[0] == 0)
          if (paramArrayOfint1[1] != 0) {
            bool1 = bool;
          } else {
            bool1 = false;
          }  
        return bool1;
      } 
      if (paramArrayOfint2 != null) {
        paramArrayOfint2[0] = 0;
        paramArrayOfint2[1] = 0;
      } 
    } 
    return false;
  }
  
  public boolean b() {
    return this.d;
  }
  
  public boolean b(int paramInt) {
    return a(paramInt, 0);
  }
  
  public void c() {
    c(0);
  }
  
  public void c(int paramInt) {
    ViewParent viewParent = d(paramInt);
    if (viewParent != null) {
      x.a(viewParent, this.c, paramInt);
      a(paramInt, (ViewParent)null);
    } 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\view\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */