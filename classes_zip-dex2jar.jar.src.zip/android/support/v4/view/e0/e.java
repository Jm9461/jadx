package android.support.v4.view.e0;

import android.graphics.Path;
import android.graphics.PathMeasure;
import android.view.animation.Interpolator;

class e implements Interpolator {
  private final float[] a;
  
  private final float[] b;
  
  e(Path paramPath) {
    PathMeasure pathMeasure = new PathMeasure(paramPath, false);
    float f = pathMeasure.getLength();
    int i = (int)(f / 0.002F) + 1;
    this.a = new float[i];
    this.b = new float[i];
    float[] arrayOfFloat = new float[2];
    for (byte b = 0; b < i; b++) {
      pathMeasure.getPosTan(b * f / (i - 1), arrayOfFloat, null);
      this.a[b] = arrayOfFloat[0];
      this.b[b] = arrayOfFloat[1];
    } 
  }
  
  public float getInterpolation(float paramFloat) {
    if (paramFloat <= 0.0F)
      return 0.0F; 
    if (paramFloat >= 1.0F)
      return 1.0F; 
    int i = 0;
    int j = this.a.length - 1;
    while (j - i > 1) {
      int k = (i + j) / 2;
      if (paramFloat < this.a[k]) {
        j = k;
        continue;
      } 
      i = k;
    } 
    float[] arrayOfFloat = this.a;
    float f = arrayOfFloat[j] - arrayOfFloat[i];
    if (f == 0.0F)
      return this.b[i]; 
    f = (paramFloat - arrayOfFloat[i]) / f;
    arrayOfFloat = this.b;
    paramFloat = arrayOfFloat[i];
    return (arrayOfFloat[j] - paramFloat) * f + paramFloat;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\view\e0\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */