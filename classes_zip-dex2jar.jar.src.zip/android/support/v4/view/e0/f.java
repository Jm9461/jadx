package android.support.v4.view.e0;

import android.graphics.Path;
import android.os.Build;
import android.view.animation.Interpolator;
import android.view.animation.PathInterpolator;

public final class f {
  public static Interpolator a(Path paramPath) {
    return (Interpolator)((Build.VERSION.SDK_INT >= 21) ? new PathInterpolator(paramPath) : new e(paramPath));
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\view\e0\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */