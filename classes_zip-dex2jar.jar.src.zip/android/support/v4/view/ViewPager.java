package android.support.v4.view;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.view.d0.c;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.Scroller;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ViewPager extends ViewGroup {
  static final int[] h0 = new int[] { 16842931 };
  
  private static final Comparator<f> i0 = new a();
  
  private static final Interpolator j0 = new b();
  
  private static final n k0 = new n();
  
  private boolean A;
  
  private int B;
  
  private int C;
  
  private int D;
  
  private float E;
  
  private float F;
  
  private float G;
  
  private float H;
  
  private int I = -1;
  
  private VelocityTracker J;
  
  private int K;
  
  private int L;
  
  private int M;
  
  private int N;
  
  private boolean O;
  
  private EdgeEffect P;
  
  private EdgeEffect Q;
  
  private boolean R = true;
  
  private boolean S;
  
  private int T;
  
  private List<j> U;
  
  private j V;
  
  private j W;
  
  private List<i> a0;
  
  private k b0;
  
  private int c;
  
  private int c0;
  
  private final ArrayList<f> d = new ArrayList<f>();
  
  private int d0;
  
  private final f e = new f();
  
  private ArrayList<View> e0;
  
  private final Rect f = new Rect();
  
  private final Runnable f0 = new c(this);
  
  q g;
  
  private int g0 = 0;
  
  int h;
  
  private int i = -1;
  
  private Parcelable j = null;
  
  private ClassLoader k = null;
  
  private Scroller l;
  
  private boolean m;
  
  private l n;
  
  private int o;
  
  private Drawable p;
  
  private int q;
  
  private int r;
  
  private float s = -3.4028235E38F;
  
  private float t = Float.MAX_VALUE;
  
  private int u;
  
  private boolean v;
  
  private boolean w;
  
  private boolean x;
  
  private int y = 1;
  
  private boolean z;
  
  public ViewPager(Context paramContext) {
    super(paramContext);
    b();
  }
  
  public ViewPager(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    b();
  }
  
  private int a(int paramInt1, float paramFloat, int paramInt2, int paramInt3) {
    if (Math.abs(paramInt3) > this.M && Math.abs(paramInt2) > this.K) {
      if (paramInt2 <= 0)
        paramInt1++; 
    } else {
      float f1;
      if (paramInt1 >= this.h) {
        f1 = 0.4F;
      } else {
        f1 = 0.6F;
      } 
      paramInt1 += (int)(paramFloat + f1);
    } 
    paramInt2 = paramInt1;
    if (this.d.size() > 0) {
      f f1 = this.d.get(0);
      ArrayList<f> arrayList = this.d;
      f f2 = arrayList.get(arrayList.size() - 1);
      paramInt2 = Math.max(f1.b, Math.min(paramInt1, f2.b));
    } 
    return paramInt2;
  }
  
  private Rect a(Rect paramRect, View paramView) {
    Rect rect = paramRect;
    if (paramRect == null)
      rect = new Rect(); 
    if (paramView == null) {
      rect.set(0, 0, 0, 0);
      return rect;
    } 
    rect.left = paramView.getLeft();
    rect.right = paramView.getRight();
    rect.top = paramView.getTop();
    rect.bottom = paramView.getBottom();
    ViewParent viewParent = paramView.getParent();
    while (viewParent instanceof ViewGroup && viewParent != this) {
      ViewGroup viewGroup = (ViewGroup)viewParent;
      rect.left += viewGroup.getLeft();
      rect.right += viewGroup.getRight();
      rect.top += viewGroup.getTop();
      rect.bottom += viewGroup.getBottom();
      ViewParent viewParent1 = viewGroup.getParent();
    } 
    return rect;
  }
  
  private void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramInt2 > 0 && !this.d.isEmpty()) {
      if (!this.l.isFinished()) {
        this.l.setFinalX(getCurrentItem() * getClientWidth());
      } else {
        int m = getPaddingLeft();
        int i1 = getPaddingRight();
        int i = getPaddingLeft();
        int i2 = getPaddingRight();
        float f1 = getScrollX() / (paramInt2 - i - i2 + paramInt4);
        scrollTo((int)((paramInt1 - m - i1 + paramInt3) * f1), getScrollY());
      } 
    } else {
      float f1;
      f f2 = b(this.h);
      if (f2 != null) {
        f1 = Math.min(f2.e, this.t);
      } else {
        f1 = 0.0F;
      } 
      paramInt1 = (int)((paramInt1 - getPaddingLeft() - getPaddingRight()) * f1);
      if (paramInt1 != getScrollX()) {
        a(false);
        scrollTo(paramInt1, getScrollY());
      } 
    } 
  }
  
  private void a(int paramInt1, boolean paramBoolean1, int paramInt2, boolean paramBoolean2) {
    f f1 = b(paramInt1);
    int i = 0;
    if (f1 != null)
      i = (int)(getClientWidth() * Math.max(this.s, Math.min(f1.e, this.t))); 
    if (paramBoolean1) {
      a(i, 0, paramInt2);
      if (paramBoolean2)
        d(paramInt1); 
    } else {
      if (paramBoolean2)
        d(paramInt1); 
      a(false);
      scrollTo(i, 0);
      f(i);
    } 
  }
  
  private void a(f paramf1, int paramInt, f paramf2) {
    float f2;
    int i2 = this.g.a();
    int i = getClientWidth();
    if (i > 0) {
      f2 = this.o / i;
    } else {
      f2 = 0.0F;
    } 
    if (paramf2 != null) {
      i = paramf2.b;
      int i3 = paramf1.b;
      if (i < i3) {
        i3 = 0;
        f1 = paramf2.e + paramf2.d + f2;
        while (++i <= paramf1.b && i3 < this.d.size()) {
          float f4;
          int i4;
          paramf2 = this.d.get(i3);
          while (true) {
            f4 = f1;
            i4 = i;
            if (i > paramf2.b) {
              f4 = f1;
              i4 = i;
              if (i3 < this.d.size() - 1) {
                paramf2 = this.d.get(++i3);
                continue;
              } 
            } 
            break;
          } 
          while (i4 < paramf2.b) {
            f4 += this.g.b(i4) + f2;
            i4++;
          } 
          paramf2.e = f4;
          f1 = f4 + paramf2.d + f2;
          i = i4 + 1;
        } 
      } else if (i > i3) {
        i3 = this.d.size() - 1;
        f1 = paramf2.e;
        while (--i >= paramf1.b && i3 >= 0) {
          float f4;
          int i4;
          paramf2 = this.d.get(i3);
          while (true) {
            f4 = f1;
            i4 = i;
            if (i < paramf2.b) {
              f4 = f1;
              i4 = i;
              if (i3 > 0) {
                paramf2 = this.d.get(--i3);
                continue;
              } 
            } 
            break;
          } 
          while (i4 > paramf2.b) {
            f4 -= this.g.b(i4) + f2;
            i4--;
          } 
          f1 = f4 - paramf2.d + f2;
          paramf2.e = f1;
          i = i4 - 1;
        } 
      } 
    } 
    int i1 = this.d.size();
    float f3 = paramf1.e;
    int m = paramf1.b;
    i = m - 1;
    if (m == 0) {
      f1 = paramf1.e;
    } else {
      f1 = -3.4028235E38F;
    } 
    this.s = f1;
    if (paramf1.b == i2 - 1) {
      f1 = paramf1.e + paramf1.d - 1.0F;
    } else {
      f1 = Float.MAX_VALUE;
    } 
    this.t = f1;
    m = paramInt - 1;
    float f1 = f3;
    while (m >= 0) {
      paramf2 = this.d.get(m);
      while (true) {
        int i3 = paramf2.b;
        if (i > i3) {
          f1 -= this.g.b(i) + f2;
          i--;
          continue;
        } 
        f1 -= paramf2.d + f2;
        paramf2.e = f1;
        if (i3 == 0)
          this.s = f1; 
        break;
      } 
      m--;
      i--;
    } 
    f1 = paramf1.e + paramf1.d + f2;
    m = paramf1.b + 1;
    i = paramInt + 1;
    for (paramInt = m; i < i1; paramInt++) {
      paramf1 = this.d.get(i);
      while (true) {
        m = paramf1.b;
        if (paramInt < m) {
          f1 += this.g.b(paramInt) + f2;
          paramInt++;
          continue;
        } 
        if (m == i2 - 1)
          this.t = paramf1.d + f1 - 1.0F; 
        break;
      } 
      paramf1.e = f1;
      f1 += paramf1.d + f2;
      i++;
    } 
  }
  
  private void a(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(i) == this.I) {
      if (i == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      this.E = paramMotionEvent.getX(i);
      this.I = paramMotionEvent.getPointerId(i);
      VelocityTracker velocityTracker = this.J;
      if (velocityTracker != null)
        velocityTracker.clear(); 
    } 
  }
  
  private void a(boolean paramBoolean) {
    boolean bool;
    if (this.g0 == 2) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      setScrollingCacheEnabled(false);
      if ((true ^ this.l.isFinished()) != 0) {
        this.l.abortAnimation();
        int i = getScrollX();
        int m = getScrollY();
        int i2 = this.l.getCurrX();
        int i1 = this.l.getCurrY();
        if (i != i2 || m != i1) {
          scrollTo(i2, i1);
          if (i2 != i)
            f(i2); 
        } 
      } 
    } 
    this.x = false;
    for (byte b = 0; b < this.d.size(); b++) {
      f f1 = this.d.get(b);
      if (f1.c) {
        bool = true;
        f1.c = false;
      } 
    } 
    if (bool)
      if (paramBoolean) {
        u.a((View)this, this.f0);
      } else {
        this.f0.run();
      }  
  }
  
  private boolean a(float paramFloat1, float paramFloat2) {
    boolean bool;
    if ((paramFloat1 < this.C && paramFloat2 > 0.0F) || (paramFloat1 > (getWidth() - this.C) && paramFloat2 < 0.0F)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private void b(int paramInt1, float paramFloat, int paramInt2) {
    j j2 = this.V;
    if (j2 != null)
      j2.a(paramInt1, paramFloat, paramInt2); 
    List<j> list = this.U;
    if (list != null) {
      byte b = 0;
      int i = list.size();
      while (b < i) {
        j j3 = this.U.get(b);
        if (j3 != null)
          j3.a(paramInt1, paramFloat, paramInt2); 
        b++;
      } 
    } 
    j j1 = this.W;
    if (j1 != null)
      j1.a(paramInt1, paramFloat, paramInt2); 
  }
  
  private void b(boolean paramBoolean) {
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      boolean bool;
      if (paramBoolean) {
        bool = this.c0;
      } else {
        bool = false;
      } 
      getChildAt(b).setLayerType(bool, null);
    } 
  }
  
  private boolean b(float paramFloat) {
    boolean bool4 = false;
    boolean bool5 = false;
    boolean bool3 = false;
    float f1 = this.E;
    this.E = paramFloat;
    float f2 = getScrollX() + f1 - paramFloat;
    int i = getClientWidth();
    paramFloat = i * this.s;
    f1 = i * this.t;
    boolean bool1 = true;
    boolean bool2 = true;
    f f3 = this.d.get(0);
    ArrayList<f> arrayList = this.d;
    f f4 = arrayList.get(arrayList.size() - 1);
    if (f3.b != 0) {
      bool1 = false;
      paramFloat = f3.e * i;
    } 
    if (f4.b != this.g.a() - 1) {
      bool2 = false;
      f1 = f4.e * i;
    } 
    if (f2 < paramFloat) {
      if (bool1) {
        this.P.onPull(Math.abs(paramFloat - f2) / i);
        bool3 = true;
      } 
    } else {
      bool3 = bool5;
      paramFloat = f2;
      if (f2 > f1) {
        bool3 = bool4;
        if (bool2) {
          this.Q.onPull(Math.abs(f2 - f1) / i);
          bool3 = true;
        } 
        paramFloat = f1;
      } 
    } 
    this.E += paramFloat - (int)paramFloat;
    scrollTo((int)paramFloat, getScrollY());
    f((int)paramFloat);
    return bool3;
  }
  
  private void c(boolean paramBoolean) {
    ViewParent viewParent = getParent();
    if (viewParent != null)
      viewParent.requestDisallowInterceptTouchEvent(paramBoolean); 
  }
  
  private static boolean c(View paramView) {
    boolean bool;
    if (paramView.getClass().getAnnotation(e.class) != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private void d(int paramInt) {
    j j2 = this.V;
    if (j2 != null)
      j2.b(paramInt); 
    List<j> list = this.U;
    if (list != null) {
      byte b = 0;
      int i = list.size();
      while (b < i) {
        j j3 = this.U.get(b);
        if (j3 != null)
          j3.b(paramInt); 
        b++;
      } 
    } 
    j j1 = this.W;
    if (j1 != null)
      j1.b(paramInt); 
  }
  
  private void e(int paramInt) {
    j j2 = this.V;
    if (j2 != null)
      j2.a(paramInt); 
    List<j> list = this.U;
    if (list != null) {
      byte b = 0;
      int i = list.size();
      while (b < i) {
        j j3 = this.U.get(b);
        if (j3 != null)
          j3.a(paramInt); 
        b++;
      } 
    } 
    j j1 = this.W;
    if (j1 != null)
      j1.a(paramInt); 
  }
  
  private void f() {
    this.z = false;
    this.A = false;
    VelocityTracker velocityTracker = this.J;
    if (velocityTracker != null) {
      velocityTracker.recycle();
      this.J = null;
    } 
  }
  
  private boolean f(int paramInt) {
    if (this.d.size() == 0) {
      if (this.R)
        return false; 
      this.S = false;
      a(0, 0.0F, 0);
      if (this.S)
        return false; 
      throw new IllegalStateException("onPageScrolled did not call superclass implementation");
    } 
    f f2 = g();
    int i1 = getClientWidth();
    int m = this.o;
    float f1 = m / i1;
    int i = f2.b;
    f1 = (paramInt / i1 - f2.e) / (f2.d + f1);
    paramInt = (int)((i1 + m) * f1);
    this.S = false;
    a(i, f1, paramInt);
    if (this.S)
      return true; 
    throw new IllegalStateException("onPageScrolled did not call superclass implementation");
  }
  
  private f g() {
    float f1;
    int i = getClientWidth();
    float f2 = 0.0F;
    if (i > 0) {
      f1 = getScrollX() / i;
    } else {
      f1 = 0.0F;
    } 
    if (i > 0)
      f2 = this.o / i; 
    int m = -1;
    float f4 = 0.0F;
    float f3 = 0.0F;
    boolean bool = true;
    f f5 = null;
    i = 0;
    while (i < this.d.size()) {
      f f7 = this.d.get(i);
      int i1 = i;
      f f6 = f7;
      if (!bool) {
        i1 = i;
        f6 = f7;
        if (f7.b != m + 1) {
          f6 = this.e;
          f6.e = f4 + f3 + f2;
          f6.b = m + 1;
          f6.d = this.g.b(f6.b);
          i1 = i - 1;
        } 
      } 
      f4 = f6.e;
      f3 = f6.d;
      if (bool || f1 >= f4) {
        if (f1 < f3 + f4 + f2 || i1 == this.d.size() - 1)
          return f6; 
        bool = false;
        m = f6.b;
        f3 = f6.d;
        i = i1 + 1;
        f5 = f6;
        continue;
      } 
      return f5;
    } 
    return f5;
  }
  
  private int getClientWidth() {
    return getMeasuredWidth() - getPaddingLeft() - getPaddingRight();
  }
  
  private void h() {
    for (int i = 0; i < getChildCount(); i = m + 1) {
      int m = i;
      if (!((g)getChildAt(i).getLayoutParams()).a) {
        removeViewAt(i);
        m = i - 1;
      } 
    } 
  }
  
  private boolean i() {
    this.I = -1;
    f();
    this.P.onRelease();
    this.Q.onRelease();
    return (this.P.isFinished() || this.Q.isFinished());
  }
  
  private void j() {
    if (this.d0 != 0) {
      ArrayList<View> arrayList = this.e0;
      if (arrayList == null) {
        this.e0 = new ArrayList<View>();
      } else {
        arrayList.clear();
      } 
      int i = getChildCount();
      for (byte b = 0; b < i; b++) {
        View view = getChildAt(b);
        this.e0.add(view);
      } 
      Collections.sort(this.e0, k0);
    } 
  }
  
  private void setScrollingCacheEnabled(boolean paramBoolean) {
    if (this.w != paramBoolean)
      this.w = paramBoolean; 
  }
  
  float a(float paramFloat) {
    return (float)Math.sin(((paramFloat - 0.5F) * 0.47123894F));
  }
  
  f a(int paramInt1, int paramInt2) {
    f f1 = new f();
    f1.b = paramInt1;
    f1.a = this.g.a(this, paramInt1);
    f1.d = this.g.b(paramInt1);
    if (paramInt2 < 0 || paramInt2 >= this.d.size()) {
      this.d.add(f1);
      return f1;
    } 
    this.d.add(paramInt2, f1);
    return f1;
  }
  
  f a(View paramView) {
    while (true) {
      ViewParent viewParent = paramView.getParent();
      if (viewParent != this) {
        if (viewParent != null) {
          if (!(viewParent instanceof View))
            return null; 
          paramView = (View)viewParent;
          continue;
        } 
        continue;
      } 
      return b(paramView);
    } 
  }
  
  void a() {
    byte b;
    int i2 = this.g.a();
    this.c = i2;
    if (this.d.size() < this.y * 2 + 1 && this.d.size() < i2) {
      b = 1;
    } else {
      b = 0;
    } 
    int i = this.h;
    int m = 0;
    int i1 = 0;
    while (i1 < this.d.size()) {
      int i3;
      int i4;
      int i5;
      f f1 = this.d.get(i1);
      int i6 = this.g.a(f1.a);
      if (i6 == -1) {
        i3 = i;
        i4 = m;
        i5 = i1;
      } else if (i6 == -2) {
        this.d.remove(i1);
        i6 = i1 - 1;
        i1 = m;
        if (!m) {
          this.g.b(this);
          i1 = 1;
        } 
        this.g.a(this, f1.b, f1.a);
        b = 1;
        m = this.h;
        i3 = i;
        i4 = i1;
        i5 = i6;
        if (m == f1.b) {
          i3 = Math.max(0, Math.min(m, i2 - 1));
          b = 1;
          i4 = i1;
          i5 = i6;
        } 
      } else {
        int i7 = f1.b;
        i3 = i;
        i4 = m;
        i5 = i1;
        if (i7 != i6) {
          if (i7 == this.h)
            i = i6; 
          f1.b = i6;
          b = 1;
          i5 = i1;
          i4 = m;
          i3 = i;
        } 
      } 
      i1 = i5 + 1;
      i = i3;
      m = i4;
    } 
    if (m != 0)
      this.g.a(this); 
    Collections.sort(this.d, i0);
    if (b) {
      m = getChildCount();
      for (b = 0; b < m; b++) {
        g g = (g)getChildAt(b).getLayoutParams();
        if (!g.a)
          g.c = 0.0F; 
      } 
      a(i, false, true);
      requestLayout();
    } 
  }
  
  protected void a(int paramInt1, float paramFloat, int paramInt2) {
    if (this.T > 0) {
      int i2 = getScrollX();
      int i = getPaddingLeft();
      int m = getPaddingRight();
      int i1 = getWidth();
      int i3 = getChildCount();
      byte b = 0;
      while (b < i3) {
        int i4;
        int i5;
        View view = getChildAt(b);
        g g = (g)view.getLayoutParams();
        if (!g.a) {
          i5 = i;
          i4 = m;
        } else {
          i4 = g.b & 0x7;
          if (i4 != 1) {
            if (i4 != 3) {
              if (i4 != 5) {
                i4 = i;
              } else {
                i4 = i1 - m - view.getMeasuredWidth();
                m += view.getMeasuredWidth();
              } 
            } else {
              i4 = i;
              i += view.getWidth();
            } 
          } else {
            i4 = Math.max((i1 - view.getMeasuredWidth()) / 2, i);
          } 
          int i6 = i4 + i2 - view.getLeft();
          i5 = i;
          i4 = m;
          if (i6 != 0) {
            view.offsetLeftAndRight(i6);
            i4 = m;
            i5 = i;
          } 
        } 
        b++;
        i = i5;
        m = i4;
      } 
    } 
    b(paramInt1, paramFloat, paramInt2);
    if (this.b0 != null) {
      int i = getScrollX();
      paramInt2 = getChildCount();
      for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
        View view = getChildAt(paramInt1);
        if (!((g)view.getLayoutParams()).a) {
          paramFloat = (view.getLeft() - i) / getClientWidth();
          this.b0.a(view, paramFloat);
        } 
      } 
    } 
    this.S = true;
  }
  
  void a(int paramInt1, int paramInt2, int paramInt3) {
    int i;
    if (getChildCount() == 0) {
      setScrollingCacheEnabled(false);
      return;
    } 
    Scroller scroller = this.l;
    if (scroller != null && !scroller.isFinished()) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i) {
      if (this.m) {
        i = this.l.getCurrX();
      } else {
        i = this.l.getStartX();
      } 
      this.l.abortAnimation();
      setScrollingCacheEnabled(false);
    } else {
      i = getScrollX();
    } 
    int m = getScrollY();
    int i1 = paramInt1 - i;
    paramInt2 -= m;
    if (i1 == 0 && paramInt2 == 0) {
      a(false);
      e();
      setScrollState(0);
      return;
    } 
    setScrollingCacheEnabled(true);
    setScrollState(2);
    paramInt1 = getClientWidth();
    int i2 = paramInt1 / 2;
    float f3 = Math.min(1.0F, Math.abs(i1) * 1.0F / paramInt1);
    float f1 = i2;
    float f2 = i2;
    f3 = a(f3);
    paramInt3 = Math.abs(paramInt3);
    if (paramInt3 > 0) {
      paramInt1 = Math.round(Math.abs((f1 + f2 * f3) / paramInt3) * 1000.0F) * 4;
    } else {
      f1 = paramInt1;
      f2 = this.g.b(this.h);
      paramInt1 = (int)((1.0F + Math.abs(i1) / (this.o + f1 * f2)) * 100.0F);
    } 
    paramInt1 = Math.min(paramInt1, 600);
    this.m = false;
    this.l.startScroll(i, m, i1, paramInt2, paramInt1);
    u.B((View)this);
  }
  
  public void a(int paramInt, boolean paramBoolean) {
    this.x = false;
    a(paramInt, paramBoolean, false);
  }
  
  void a(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    a(paramInt, paramBoolean1, paramBoolean2, 0);
  }
  
  void a(int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2) {
    int i;
    q q1 = this.g;
    if (q1 == null || q1.a() <= 0) {
      setScrollingCacheEnabled(false);
      return;
    } 
    if (!paramBoolean2 && this.h == paramInt1 && this.d.size() != 0) {
      setScrollingCacheEnabled(false);
      return;
    } 
    paramBoolean2 = true;
    if (paramInt1 < 0) {
      i = 0;
    } else {
      i = paramInt1;
      if (paramInt1 >= this.g.a())
        i = this.g.a() - 1; 
    } 
    paramInt1 = this.y;
    int m = this.h;
    if (i > m + paramInt1 || i < m - paramInt1)
      for (paramInt1 = 0; paramInt1 < this.d.size(); paramInt1++)
        ((f)this.d.get(paramInt1)).c = true;  
    if (this.h == i)
      paramBoolean2 = false; 
    if (this.R) {
      this.h = i;
      if (paramBoolean2)
        d(i); 
      requestLayout();
    } else {
      c(i);
      a(i, paramBoolean1, paramInt2, paramBoolean2);
    } 
  }
  
  public void a(i parami) {
    if (this.a0 == null)
      this.a0 = new ArrayList<i>(); 
    this.a0.add(parami);
  }
  
  public void a(j paramj) {
    if (this.U == null)
      this.U = new ArrayList<j>(); 
    this.U.add(paramj);
  }
  
  public boolean a(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual findFocus : ()Landroid/view/View;
    //   4: astore #7
    //   6: aload #7
    //   8: aload_0
    //   9: if_acmpne -> 18
    //   12: aconst_null
    //   13: astore #6
    //   15: goto -> 194
    //   18: aload #7
    //   20: astore #6
    //   22: aload #7
    //   24: ifnull -> 194
    //   27: iconst_0
    //   28: istore_3
    //   29: aload #7
    //   31: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   34: astore #6
    //   36: iload_3
    //   37: istore_2
    //   38: aload #6
    //   40: instanceof android/view/ViewGroup
    //   43: ifeq -> 69
    //   46: aload #6
    //   48: aload_0
    //   49: if_acmpne -> 57
    //   52: iconst_1
    //   53: istore_2
    //   54: goto -> 69
    //   57: aload #6
    //   59: invokeinterface getParent : ()Landroid/view/ViewParent;
    //   64: astore #6
    //   66: goto -> 36
    //   69: aload #7
    //   71: astore #6
    //   73: iload_2
    //   74: ifne -> 194
    //   77: new java/lang/StringBuilder
    //   80: dup
    //   81: invokespecial <init> : ()V
    //   84: astore #8
    //   86: aload #8
    //   88: aload #7
    //   90: invokevirtual getClass : ()Ljava/lang/Class;
    //   93: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   96: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   99: pop
    //   100: aload #7
    //   102: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   105: astore #6
    //   107: aload #6
    //   109: instanceof android/view/ViewGroup
    //   112: ifeq -> 150
    //   115: aload #8
    //   117: ldc_w ' => '
    //   120: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   123: pop
    //   124: aload #8
    //   126: aload #6
    //   128: invokevirtual getClass : ()Ljava/lang/Class;
    //   131: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   134: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   137: pop
    //   138: aload #6
    //   140: invokeinterface getParent : ()Landroid/view/ViewParent;
    //   145: astore #6
    //   147: goto -> 107
    //   150: new java/lang/StringBuilder
    //   153: dup
    //   154: invokespecial <init> : ()V
    //   157: astore #6
    //   159: aload #6
    //   161: ldc_w 'arrowScroll tried to find focus based on non-child current focused view '
    //   164: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   167: pop
    //   168: aload #6
    //   170: aload #8
    //   172: invokevirtual toString : ()Ljava/lang/String;
    //   175: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   178: pop
    //   179: ldc_w 'ViewPager'
    //   182: aload #6
    //   184: invokevirtual toString : ()Ljava/lang/String;
    //   187: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   190: pop
    //   191: aconst_null
    //   192: astore #6
    //   194: iconst_0
    //   195: istore #5
    //   197: iconst_0
    //   198: istore #4
    //   200: invokestatic getInstance : ()Landroid/view/FocusFinder;
    //   203: aload_0
    //   204: aload #6
    //   206: iload_1
    //   207: invokevirtual findNextFocus : (Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;
    //   210: astore #7
    //   212: aload #7
    //   214: ifnull -> 350
    //   217: aload #7
    //   219: aload #6
    //   221: if_acmpeq -> 350
    //   224: iload_1
    //   225: bipush #17
    //   227: if_icmpne -> 287
    //   230: aload_0
    //   231: aload_0
    //   232: getfield f : Landroid/graphics/Rect;
    //   235: aload #7
    //   237: invokespecial a : (Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    //   240: getfield left : I
    //   243: istore_2
    //   244: aload_0
    //   245: aload_0
    //   246: getfield f : Landroid/graphics/Rect;
    //   249: aload #6
    //   251: invokespecial a : (Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    //   254: getfield left : I
    //   257: istore_3
    //   258: aload #6
    //   260: ifnull -> 277
    //   263: iload_2
    //   264: iload_3
    //   265: if_icmplt -> 277
    //   268: aload_0
    //   269: invokevirtual c : ()Z
    //   272: istore #4
    //   274: goto -> 284
    //   277: aload #7
    //   279: invokevirtual requestFocus : ()Z
    //   282: istore #4
    //   284: goto -> 394
    //   287: iload_1
    //   288: bipush #66
    //   290: if_icmpne -> 284
    //   293: aload_0
    //   294: aload_0
    //   295: getfield f : Landroid/graphics/Rect;
    //   298: aload #7
    //   300: invokespecial a : (Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    //   303: getfield left : I
    //   306: istore_2
    //   307: aload_0
    //   308: aload_0
    //   309: getfield f : Landroid/graphics/Rect;
    //   312: aload #6
    //   314: invokespecial a : (Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    //   317: getfield left : I
    //   320: istore_3
    //   321: aload #6
    //   323: ifnull -> 340
    //   326: iload_2
    //   327: iload_3
    //   328: if_icmpgt -> 340
    //   331: aload_0
    //   332: invokevirtual d : ()Z
    //   335: istore #4
    //   337: goto -> 347
    //   340: aload #7
    //   342: invokevirtual requestFocus : ()Z
    //   345: istore #4
    //   347: goto -> 394
    //   350: iload_1
    //   351: bipush #17
    //   353: if_icmpeq -> 388
    //   356: iload_1
    //   357: iconst_1
    //   358: if_icmpne -> 364
    //   361: goto -> 388
    //   364: iload_1
    //   365: bipush #66
    //   367: if_icmpeq -> 379
    //   370: iload #5
    //   372: istore #4
    //   374: iload_1
    //   375: iconst_2
    //   376: if_icmpne -> 394
    //   379: aload_0
    //   380: invokevirtual d : ()Z
    //   383: istore #4
    //   385: goto -> 394
    //   388: aload_0
    //   389: invokevirtual c : ()Z
    //   392: istore #4
    //   394: iload #4
    //   396: ifeq -> 407
    //   399: aload_0
    //   400: iload_1
    //   401: invokestatic getContantForFocusDirection : (I)I
    //   404: invokevirtual playSoundEffect : (I)V
    //   407: iload #4
    //   409: ireturn
  }
  
  public boolean a(KeyEvent paramKeyEvent) {
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (paramKeyEvent.getAction() == 0) {
      int i = paramKeyEvent.getKeyCode();
      if (i != 21) {
        if (i != 22) {
          if (i != 61) {
            bool1 = bool2;
          } else if (paramKeyEvent.hasNoModifiers()) {
            bool1 = a(2);
          } else {
            bool1 = bool2;
            if (paramKeyEvent.hasModifiers(1))
              bool1 = a(1); 
          } 
        } else if (paramKeyEvent.hasModifiers(2)) {
          bool1 = d();
        } else {
          bool1 = a(66);
        } 
      } else if (paramKeyEvent.hasModifiers(2)) {
        bool1 = c();
      } else {
        bool1 = a(17);
      } 
    } 
    return bool1;
  }
  
  protected boolean a(View paramView, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3) {
    boolean bool1 = paramView instanceof ViewGroup;
    boolean bool = true;
    if (bool1) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      int i1 = paramView.getScrollX();
      int m = paramView.getScrollY();
      for (int i = viewGroup.getChildCount() - 1; i >= 0; i--) {
        View view = viewGroup.getChildAt(i);
        if (paramInt2 + i1 >= view.getLeft() && paramInt2 + i1 < view.getRight() && paramInt3 + m >= view.getTop() && paramInt3 + m < view.getBottom() && a(view, true, paramInt1, paramInt2 + i1 - view.getLeft(), paramInt3 + m - view.getTop()))
          return true; 
      } 
    } 
    if (paramBoolean && paramView.canScrollHorizontally(-paramInt1)) {
      paramBoolean = bool;
    } else {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public void addFocusables(ArrayList<View> paramArrayList, int paramInt1, int paramInt2) {
    int i = paramArrayList.size();
    int m = getDescendantFocusability();
    if (m != 393216)
      for (byte b = 0; b < getChildCount(); b++) {
        View view = getChildAt(b);
        if (view.getVisibility() == 0) {
          f f1 = b(view);
          if (f1 != null && f1.b == this.h)
            view.addFocusables(paramArrayList, paramInt1, paramInt2); 
        } 
      }  
    if (m != 262144 || i == paramArrayList.size()) {
      if (!isFocusable())
        return; 
      if ((paramInt2 & 0x1) == 1 && isInTouchMode() && !isFocusableInTouchMode())
        return; 
      if (paramArrayList != null)
        paramArrayList.add(this); 
    } 
  }
  
  public void addTouchables(ArrayList<View> paramArrayList) {
    for (byte b = 0; b < getChildCount(); b++) {
      View view = getChildAt(b);
      if (view.getVisibility() == 0) {
        f f1 = b(view);
        if (f1 != null && f1.b == this.h)
          view.addTouchables(paramArrayList); 
      } 
    } 
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    ViewGroup.LayoutParams layoutParams = paramLayoutParams;
    if (!checkLayoutParams(paramLayoutParams))
      layoutParams = generateLayoutParams(paramLayoutParams); 
    paramLayoutParams = layoutParams;
    ((g)paramLayoutParams).a |= c(paramView);
    if (this.v) {
      if (paramLayoutParams == null || !((g)paramLayoutParams).a) {
        ((g)paramLayoutParams).d = true;
        addViewInLayout(paramView, paramInt, layoutParams);
        return;
      } 
      throw new IllegalStateException("Cannot add pager decor view during layout");
    } 
    super.addView(paramView, paramInt, layoutParams);
  }
  
  f b(int paramInt) {
    for (byte b = 0; b < this.d.size(); b++) {
      f f1 = this.d.get(b);
      if (f1.b == paramInt)
        return f1; 
    } 
    return null;
  }
  
  f b(View paramView) {
    for (byte b = 0; b < this.d.size(); b++) {
      f f1 = this.d.get(b);
      if (this.g.a(paramView, f1.a))
        return f1; 
    } 
    return null;
  }
  
  void b() {
    setWillNotDraw(false);
    setDescendantFocusability(262144);
    setFocusable(true);
    Context context = getContext();
    this.l = new Scroller(context, j0);
    ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
    float f1 = (context.getResources().getDisplayMetrics()).density;
    this.D = viewConfiguration.getScaledPagingTouchSlop();
    this.K = (int)(400.0F * f1);
    this.L = viewConfiguration.getScaledMaximumFlingVelocity();
    this.P = new EdgeEffect(context);
    this.Q = new EdgeEffect(context);
    this.M = (int)(25.0F * f1);
    this.N = (int)(2.0F * f1);
    this.B = (int)(16.0F * f1);
    u.a((View)this, new h(this));
    if (u.i((View)this) == 0)
      u.f((View)this, 1); 
    u.a((View)this, new d(this));
  }
  
  public void b(i parami) {
    List<i> list = this.a0;
    if (list != null)
      list.remove(parami); 
  }
  
  public void b(j paramj) {
    List<j> list = this.U;
    if (list != null)
      list.remove(paramj); 
  }
  
  void c(int paramInt) {
    String str;
    f f1;
    int i = this.h;
    if (i != paramInt) {
      f1 = b(i);
      this.h = paramInt;
    } else {
      f1 = null;
    } 
    if (this.g == null) {
      j();
      return;
    } 
    if (this.x) {
      j();
      return;
    } 
    if (getWindowToken() == null)
      return; 
    this.g.b(this);
    int m = this.y;
    int i1 = Math.max(0, this.h - m);
    int i2 = this.g.a();
    int i3 = Math.min(i2 - 1, this.h + m);
    if (i2 == this.c) {
      f f2;
      f f3 = null;
      paramInt = 0;
      while (true) {
        f2 = f3;
        if (paramInt < this.d.size()) {
          f f4 = this.d.get(paramInt);
          i = f4.b;
          int i4 = this.h;
          if (i >= i4) {
            f2 = f3;
            if (i == i4)
              f2 = f4; 
            break;
          } 
          paramInt++;
          continue;
        } 
        break;
      } 
      f3 = f2;
      if (f2 == null) {
        f3 = f2;
        if (i2 > 0)
          f3 = a(this.h, paramInt); 
      } 
      if (f3 != null) {
        float f5;
        float f6 = 0.0F;
        int i6 = paramInt - 1;
        if (i6 >= 0) {
          f2 = this.d.get(i6);
        } else {
          f2 = null;
        } 
        int i7 = getClientWidth();
        if (i7 <= 0) {
          f5 = 0.0F;
        } else {
          float f8 = f3.d;
          f5 = getPaddingLeft() / i7 + 2.0F - f8;
        } 
        int i5 = this.h - 1;
        f f7 = f2;
        int i4 = paramInt;
        while (i5 >= 0) {
          float f8;
          if (f6 >= f5 && i5 < i1) {
            if (f7 == null)
              break; 
            paramInt = i4;
            f8 = f6;
            i = i6;
            f2 = f7;
            if (i5 == f7.b) {
              paramInt = i4;
              f8 = f6;
              i = i6;
              f2 = f7;
              if (!f7.c) {
                this.d.remove(i6);
                this.g.a(this, i5, f7.a);
                i = i6 - 1;
                paramInt = i4 - 1;
                if (i >= 0) {
                  f2 = this.d.get(i);
                } else {
                  f2 = null;
                } 
                f8 = f6;
              } 
            } 
          } else if (f7 != null && i5 == f7.b) {
            f8 = f6 + f7.d;
            i = i6 - 1;
            if (i >= 0) {
              f2 = this.d.get(i);
            } else {
              f2 = null;
            } 
            paramInt = i4;
          } else {
            f8 = f6 + (a(i5, i6 + 1)).d;
            paramInt = i4 + 1;
            if (i6 >= 0) {
              f2 = this.d.get(i6);
            } else {
              f2 = null;
            } 
            i = i6;
          } 
          i5--;
          i4 = paramInt;
          f6 = f8;
          i6 = i;
          f7 = f2;
        } 
        float f4 = f3.d;
        paramInt = i4 + 1;
        if (f4 < 2.0F) {
          if (paramInt < this.d.size()) {
            f2 = this.d.get(paramInt);
          } else {
            f2 = null;
          } 
          if (i7 <= 0) {
            f5 = 0.0F;
          } else {
            f5 = getPaddingRight() / i7 + 2.0F;
          } 
          i = this.h + 1;
          i5 = i1;
          i6 = m;
          while (i < i2) {
            if (f4 >= f5 && i > i3) {
              if (f2 == null)
                break; 
              if (i == f2.b && !f2.c) {
                this.d.remove(paramInt);
                this.g.a(this, i, f2.a);
                if (paramInt < this.d.size()) {
                  f2 = this.d.get(paramInt);
                } else {
                  f2 = null;
                } 
              } 
            } else if (f2 != null && i == f2.b) {
              f4 += f2.d;
              if (++paramInt < this.d.size()) {
                f2 = this.d.get(paramInt);
              } else {
                f2 = null;
              } 
            } else {
              f2 = a(i, paramInt);
              paramInt++;
              f4 += f2.d;
              if (paramInt < this.d.size()) {
                f2 = this.d.get(paramInt);
              } else {
                f2 = null;
              } 
            } 
            i++;
          } 
        } 
        a(f3, i4, f1);
        this.g.b(this, this.h, f3.a);
      } 
      this.g.a(this);
      i = getChildCount();
      for (paramInt = 0; paramInt < i; paramInt++) {
        View view = getChildAt(paramInt);
        g g = (g)view.getLayoutParams();
        g.f = paramInt;
        if (!g.a && g.c == 0.0F) {
          f f4 = b(view);
          if (f4 != null) {
            g.c = f4.d;
            g.e = f4.b;
          } 
        } 
      } 
      j();
      if (hasFocus()) {
        View view = findFocus();
        if (view != null) {
          f f4 = a(view);
        } else {
          view = null;
        } 
        if (view == null || ((f)view).b != this.h)
          for (paramInt = 0; paramInt < getChildCount(); paramInt++) {
            view = getChildAt(paramInt);
            f1 = b(view);
            if (f1 != null && f1.b == this.h && view.requestFocus(2))
              break; 
          }  
      } 
      return;
    } 
    try {
      str = getResources().getResourceName(getId());
    } catch (android.content.res.Resources.NotFoundException notFoundException) {
      str = Integer.toHexString(getId());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("The application's PagerAdapter changed the adapter's contents without calling PagerAdapter#notifyDataSetChanged! Expected adapter item count: ");
    stringBuilder.append(this.c);
    stringBuilder.append(", found: ");
    stringBuilder.append(i2);
    stringBuilder.append(" Pager id: ");
    stringBuilder.append(str);
    stringBuilder.append(" Pager class: ");
    stringBuilder.append(getClass());
    stringBuilder.append(" Problematic adapter: ");
    stringBuilder.append(this.g.getClass());
    IllegalStateException illegalStateException = new IllegalStateException(stringBuilder.toString());
    throw illegalStateException;
  }
  
  boolean c() {
    int i = this.h;
    if (i > 0) {
      a(i - 1, true);
      return true;
    } 
    return false;
  }
  
  public boolean canScrollHorizontally(int paramInt) {
    q q1 = this.g;
    boolean bool2 = false;
    boolean bool1 = false;
    if (q1 == null)
      return false; 
    int m = getClientWidth();
    int i = getScrollX();
    if (paramInt < 0) {
      if (i > (int)(m * this.s))
        bool1 = true; 
      return bool1;
    } 
    if (paramInt > 0) {
      bool1 = bool2;
      if (i < (int)(m * this.t))
        bool1 = true; 
      return bool1;
    } 
    return false;
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    boolean bool;
    if (paramLayoutParams instanceof g && super.checkLayoutParams(paramLayoutParams)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void computeScroll() {
    this.m = true;
    if (!this.l.isFinished() && this.l.computeScrollOffset()) {
      int i2 = getScrollX();
      int i1 = getScrollY();
      int m = this.l.getCurrX();
      int i = this.l.getCurrY();
      if (i2 != m || i1 != i) {
        scrollTo(m, i);
        if (!f(m)) {
          this.l.abortAnimation();
          scrollTo(0, i);
        } 
      } 
      u.B((View)this);
      return;
    } 
    a(true);
  }
  
  boolean d() {
    q q1 = this.g;
    if (q1 != null && this.h < q1.a() - 1) {
      a(this.h + 1, true);
      return true;
    } 
    return false;
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return (super.dispatchKeyEvent(paramKeyEvent) || a(paramKeyEvent));
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    if (paramAccessibilityEvent.getEventType() == 4096)
      return super.dispatchPopulateAccessibilityEvent(paramAccessibilityEvent); 
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      if (view.getVisibility() == 0) {
        f f1 = b(view);
        if (f1 != null && f1.b == this.h && view.dispatchPopulateAccessibilityEvent(paramAccessibilityEvent))
          return true; 
      } 
    } 
    return false;
  }
  
  public void draw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial draw : (Landroid/graphics/Canvas;)V
    //   5: iconst_0
    //   6: istore_3
    //   7: iconst_0
    //   8: istore_2
    //   9: aload_0
    //   10: invokevirtual getOverScrollMode : ()I
    //   13: istore #4
    //   15: iload #4
    //   17: ifeq -> 66
    //   20: iload #4
    //   22: iconst_1
    //   23: if_icmpne -> 49
    //   26: aload_0
    //   27: getfield g : Landroid/support/v4/view/q;
    //   30: astore #8
    //   32: aload #8
    //   34: ifnull -> 49
    //   37: aload #8
    //   39: invokevirtual a : ()I
    //   42: iconst_1
    //   43: if_icmple -> 49
    //   46: goto -> 66
    //   49: aload_0
    //   50: getfield P : Landroid/widget/EdgeEffect;
    //   53: invokevirtual finish : ()V
    //   56: aload_0
    //   57: getfield Q : Landroid/widget/EdgeEffect;
    //   60: invokevirtual finish : ()V
    //   63: goto -> 257
    //   66: aload_0
    //   67: getfield P : Landroid/widget/EdgeEffect;
    //   70: invokevirtual isFinished : ()Z
    //   73: ifne -> 155
    //   76: aload_1
    //   77: invokevirtual save : ()I
    //   80: istore_3
    //   81: aload_0
    //   82: invokevirtual getHeight : ()I
    //   85: aload_0
    //   86: invokevirtual getPaddingTop : ()I
    //   89: isub
    //   90: aload_0
    //   91: invokevirtual getPaddingBottom : ()I
    //   94: isub
    //   95: istore #4
    //   97: aload_0
    //   98: invokevirtual getWidth : ()I
    //   101: istore_2
    //   102: aload_1
    //   103: ldc_w 270.0
    //   106: invokevirtual rotate : (F)V
    //   109: aload_1
    //   110: iload #4
    //   112: ineg
    //   113: aload_0
    //   114: invokevirtual getPaddingTop : ()I
    //   117: iadd
    //   118: i2f
    //   119: aload_0
    //   120: getfield s : F
    //   123: iload_2
    //   124: i2f
    //   125: fmul
    //   126: invokevirtual translate : (FF)V
    //   129: aload_0
    //   130: getfield P : Landroid/widget/EdgeEffect;
    //   133: iload #4
    //   135: iload_2
    //   136: invokevirtual setSize : (II)V
    //   139: iconst_0
    //   140: aload_0
    //   141: getfield P : Landroid/widget/EdgeEffect;
    //   144: aload_1
    //   145: invokevirtual draw : (Landroid/graphics/Canvas;)Z
    //   148: ior
    //   149: istore_2
    //   150: aload_1
    //   151: iload_3
    //   152: invokevirtual restoreToCount : (I)V
    //   155: iload_2
    //   156: istore_3
    //   157: aload_0
    //   158: getfield Q : Landroid/widget/EdgeEffect;
    //   161: invokevirtual isFinished : ()Z
    //   164: ifne -> 257
    //   167: aload_1
    //   168: invokevirtual save : ()I
    //   171: istore #4
    //   173: aload_0
    //   174: invokevirtual getWidth : ()I
    //   177: istore #7
    //   179: aload_0
    //   180: invokevirtual getHeight : ()I
    //   183: istore #5
    //   185: aload_0
    //   186: invokevirtual getPaddingTop : ()I
    //   189: istore_3
    //   190: aload_0
    //   191: invokevirtual getPaddingBottom : ()I
    //   194: istore #6
    //   196: aload_1
    //   197: ldc_w 90.0
    //   200: invokevirtual rotate : (F)V
    //   203: aload_1
    //   204: aload_0
    //   205: invokevirtual getPaddingTop : ()I
    //   208: ineg
    //   209: i2f
    //   210: aload_0
    //   211: getfield t : F
    //   214: fconst_1
    //   215: fadd
    //   216: fneg
    //   217: iload #7
    //   219: i2f
    //   220: fmul
    //   221: invokevirtual translate : (FF)V
    //   224: aload_0
    //   225: getfield Q : Landroid/widget/EdgeEffect;
    //   228: iload #5
    //   230: iload_3
    //   231: isub
    //   232: iload #6
    //   234: isub
    //   235: iload #7
    //   237: invokevirtual setSize : (II)V
    //   240: iload_2
    //   241: aload_0
    //   242: getfield Q : Landroid/widget/EdgeEffect;
    //   245: aload_1
    //   246: invokevirtual draw : (Landroid/graphics/Canvas;)Z
    //   249: ior
    //   250: istore_3
    //   251: aload_1
    //   252: iload #4
    //   254: invokevirtual restoreToCount : (I)V
    //   257: iload_3
    //   258: ifeq -> 265
    //   261: aload_0
    //   262: invokestatic B : (Landroid/view/View;)V
    //   265: return
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    Drawable drawable = this.p;
    if (drawable != null && drawable.isStateful())
      drawable.setState(getDrawableState()); 
  }
  
  void e() {
    c(this.h);
  }
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return new g();
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new g(getContext(), paramAttributeSet);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return generateDefaultLayoutParams();
  }
  
  public q getAdapter() {
    return this.g;
  }
  
  protected int getChildDrawingOrder(int paramInt1, int paramInt2) {
    if (this.d0 == 2) {
      paramInt1 = paramInt1 - 1 - paramInt2;
    } else {
      paramInt1 = paramInt2;
    } 
    return ((g)((View)this.e0.get(paramInt1)).getLayoutParams()).f;
  }
  
  public int getCurrentItem() {
    return this.h;
  }
  
  public int getOffscreenPageLimit() {
    return this.y;
  }
  
  public int getPageMargin() {
    return this.o;
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.R = true;
  }
  
  protected void onDetachedFromWindow() {
    removeCallbacks(this.f0);
    Scroller scroller = this.l;
    if (scroller != null && !scroller.isFinished())
      this.l.abortAnimation(); 
    super.onDetachedFromWindow();
  }
  
  protected void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.o > 0 && this.p != null && this.d.size() > 0 && this.g != null) {
      int i2 = getScrollX();
      int i1 = getWidth();
      float f2 = this.o / i1;
      byte b = 0;
      f f3 = this.d.get(0);
      float f1 = f3.e;
      int m = this.d.size();
      int i = f3.b;
      int i3 = ((f)this.d.get(m - 1)).b;
      while (i < i3) {
        float f4;
        f f5;
        while (i > f3.b && b < m) {
          ArrayList<f> arrayList = this.d;
          f5 = arrayList.get(++b);
        } 
        if (i == f5.b) {
          f1 = f5.e;
          float f6 = f5.d;
          f4 = (f1 + f6) * i1;
          f1 = f1 + f6 + f2;
        } else {
          float f6 = this.g.b(i);
          f4 = i1 * (f1 + f6);
          f1 += f6 + f2;
        } 
        if (this.o + f4 > i2) {
          this.p.setBounds(Math.round(f4), this.q, Math.round(this.o + f4), this.r);
          this.p.draw(paramCanvas);
        } 
        if (f4 > (i2 + i1))
          break; 
        i++;
      } 
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getAction() & 0xFF;
    if (i == 3 || i == 1) {
      i();
      return false;
    } 
    if (i != 0) {
      if (this.z)
        return true; 
      if (this.A)
        return false; 
    } 
    if (i != 0) {
      if (i != 2) {
        if (i == 6)
          a(paramMotionEvent); 
      } else {
        i = this.I;
        if (i != -1) {
          i = paramMotionEvent.findPointerIndex(i);
          float f3 = paramMotionEvent.getX(i);
          float f1 = f3 - this.E;
          float f4 = Math.abs(f1);
          float f2 = paramMotionEvent.getY(i);
          float f5 = Math.abs(f2 - this.H);
          if (f1 != 0.0F && !a(this.E, f1) && a((View)this, false, (int)f1, (int)f3, (int)f2)) {
            this.E = f3;
            this.F = f2;
            this.A = true;
            return false;
          } 
          if (f4 > this.D && 0.5F * f4 > f5) {
            this.z = true;
            c(true);
            setScrollState(1);
            if (f1 > 0.0F) {
              f1 = this.G + this.D;
            } else {
              f1 = this.G - this.D;
            } 
            this.E = f1;
            this.F = f2;
            setScrollingCacheEnabled(true);
          } else if (f5 > this.D) {
            this.A = true;
          } 
          if (this.z && b(f3))
            u.B((View)this); 
        } 
      } 
    } else {
      float f1 = paramMotionEvent.getX();
      this.G = f1;
      this.E = f1;
      f1 = paramMotionEvent.getY();
      this.H = f1;
      this.F = f1;
      this.I = paramMotionEvent.getPointerId(0);
      this.A = false;
      this.m = true;
      this.l.computeScrollOffset();
      if (this.g0 == 2 && Math.abs(this.l.getFinalX() - this.l.getCurrX()) > this.N) {
        this.l.abortAnimation();
        this.x = false;
        e();
        this.z = true;
        c(true);
        setScrollState(1);
      } else {
        a(false);
        this.z = false;
      } 
    } 
    if (this.J == null)
      this.J = VelocityTracker.obtain(); 
    this.J.addMovement(paramMotionEvent);
    return this.z;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i2 = getChildCount();
    int i3 = paramInt3 - paramInt1;
    int i4 = paramInt4 - paramInt2;
    paramInt1 = getPaddingLeft();
    paramInt2 = getPaddingTop();
    int i = getPaddingRight();
    paramInt4 = getPaddingBottom();
    int i5 = getScrollX();
    int m = 0;
    int i1 = 0;
    while (i1 < i2) {
      View view = getChildAt(i1);
      paramInt3 = paramInt1;
      int i6 = paramInt2;
      int i7 = i;
      int i8 = paramInt4;
      int i9 = m;
      if (view.getVisibility() != 8) {
        g g = (g)view.getLayoutParams();
        if (g.a) {
          i6 = g.b;
          paramInt3 = i6 & 0x7;
          i7 = i6 & 0x70;
          if (paramInt3 != 1) {
            if (paramInt3 != 3) {
              if (paramInt3 != 5) {
                paramInt3 = paramInt1;
                i6 = paramInt1;
              } else {
                paramInt3 = i3 - i - view.getMeasuredWidth();
                i += view.getMeasuredWidth();
                i6 = paramInt1;
              } 
            } else {
              paramInt3 = paramInt1;
              i6 = paramInt1 + view.getMeasuredWidth();
            } 
          } else {
            paramInt3 = Math.max((i3 - view.getMeasuredWidth()) / 2, paramInt1);
            i6 = paramInt1;
          } 
          if (i7 != 16) {
            if (i7 != 48) {
              if (i7 != 80) {
                paramInt1 = paramInt2;
              } else {
                paramInt1 = i4 - paramInt4 - view.getMeasuredHeight();
                paramInt4 += view.getMeasuredHeight();
              } 
            } else {
              paramInt1 = paramInt2;
              paramInt2 += view.getMeasuredHeight();
            } 
          } else {
            paramInt1 = Math.max((i4 - view.getMeasuredHeight()) / 2, paramInt2);
          } 
          paramInt3 += i5;
          view.layout(paramInt3, paramInt1, view.getMeasuredWidth() + paramInt3, paramInt1 + view.getMeasuredHeight());
          i9 = m + 1;
          paramInt3 = i6;
          i6 = paramInt2;
          i7 = i;
          i8 = paramInt4;
        } else {
          i9 = m;
          i8 = paramInt4;
          i7 = i;
          i6 = paramInt2;
          paramInt3 = paramInt1;
        } 
      } 
      i1++;
      paramInt1 = paramInt3;
      paramInt2 = i6;
      i = i7;
      paramInt4 = i8;
      m = i9;
    } 
    i1 = i3 - paramInt1 - i;
    byte b = 0;
    paramInt3 = i3;
    i = i2;
    while (b < i) {
      View view = getChildAt(b);
      if (view.getVisibility() != 8) {
        g g = (g)view.getLayoutParams();
        if (!g.a) {
          f f1 = b(view);
          if (f1 != null) {
            int i6 = paramInt1 + (int)(i1 * f1.e);
            if (g.d) {
              g.d = false;
              view.measure(View.MeasureSpec.makeMeasureSpec((int)(i1 * g.c), 1073741824), View.MeasureSpec.makeMeasureSpec(i4 - paramInt2 - paramInt4, 1073741824));
            } 
            view.layout(i6, paramInt2, view.getMeasuredWidth() + i6, view.getMeasuredHeight() + paramInt2);
          } 
        } 
      } 
      b++;
    } 
    this.q = paramInt2;
    this.r = i4 - paramInt4;
    this.T = m;
    if (this.R)
      a(this.h, false, 0, false); 
    this.R = false;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    setMeasuredDimension(ViewGroup.getDefaultSize(0, paramInt1), ViewGroup.getDefaultSize(0, paramInt2));
    int m = getMeasuredWidth();
    int i1 = m / 10;
    this.C = Math.min(i1, this.B);
    paramInt1 = m - getPaddingLeft() - getPaddingRight();
    paramInt2 = getMeasuredHeight() - getPaddingTop() - getPaddingBottom();
    int i2 = getChildCount();
    byte b = 0;
    while (b < i2) {
      int i3;
      int i4;
      View view = getChildAt(b);
      if (view.getVisibility() != 8) {
        g g = (g)view.getLayoutParams();
        if (g != null && g.a) {
          boolean bool;
          int i7;
          i4 = g.b;
          i3 = i4 & 0x7;
          int i6 = i4 & 0x70;
          int i5 = Integer.MIN_VALUE;
          i4 = Integer.MIN_VALUE;
          if (i6 == 48 || i6 == 80) {
            i6 = 1;
          } else {
            i6 = 0;
          } 
          if (i3 == 3 || i3 == 5) {
            bool = true;
          } else {
            bool = false;
          } 
          if (i6 != 0) {
            i3 = 1073741824;
          } else {
            i3 = i5;
            if (bool) {
              i4 = 1073741824;
              i3 = i5;
            } 
          } 
          i5 = g.width;
          if (i5 != -2) {
            i7 = 1073741824;
            if (i5 != -1) {
              i3 = g.width;
            } else {
              i3 = paramInt1;
            } 
          } else {
            i5 = paramInt1;
            i7 = i3;
            i3 = i5;
          } 
          i5 = g.height;
          if (i5 != -2) {
            if (i5 != -1) {
              i4 = g.height;
              i5 = 1073741824;
            } else {
              i5 = 1073741824;
              i4 = paramInt2;
            } 
          } else {
            i5 = i4;
            i4 = paramInt2;
          } 
          view.measure(View.MeasureSpec.makeMeasureSpec(i3, i7), View.MeasureSpec.makeMeasureSpec(i4, i5));
          if (i6 != 0) {
            i4 = paramInt2 - view.getMeasuredHeight();
            i3 = paramInt1;
          } else {
            i3 = paramInt1;
            i4 = paramInt2;
            if (bool) {
              i3 = paramInt1 - view.getMeasuredWidth();
              i4 = paramInt2;
            } 
          } 
        } else {
          i3 = paramInt1;
          i4 = paramInt2;
        } 
      } else {
        i4 = paramInt2;
        i3 = paramInt1;
      } 
      b++;
      paramInt1 = i3;
      paramInt2 = i4;
    } 
    View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
    this.u = View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824);
    this.v = true;
    e();
    this.v = false;
    int i = getChildCount();
    for (paramInt2 = 0; paramInt2 < i; paramInt2++) {
      View view = getChildAt(paramInt2);
      if (view.getVisibility() != 8) {
        g g = (g)view.getLayoutParams();
        if (g == null || !g.a)
          view.measure(View.MeasureSpec.makeMeasureSpec((int)(paramInt1 * g.c), 1073741824), this.u); 
      } 
    } 
  }
  
  protected boolean onRequestFocusInDescendants(int paramInt, Rect paramRect) {
    int i;
    byte b;
    int m = getChildCount();
    if ((paramInt & 0x2) != 0) {
      i = 0;
      b = 1;
    } else {
      i = m - 1;
      b = -1;
      m = -1;
    } 
    while (i != m) {
      View view = getChildAt(i);
      if (view.getVisibility() == 0) {
        f f1 = b(view);
        if (f1 != null && f1.b == this.h && view.requestFocus(paramInt, paramRect))
          return true; 
      } 
      i += b;
    } 
    return false;
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof m)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    m m = (m)paramParcelable;
    super.onRestoreInstanceState(m.a());
    q q1 = this.g;
    if (q1 != null) {
      q1.a(m.f, m.g);
      a(m.e, false, true);
    } else {
      this.i = m.e;
      this.j = m.f;
      this.k = m.g;
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    m m = new m(super.onSaveInstanceState());
    m.e = this.h;
    q q1 = this.g;
    if (q1 != null)
      m.f = q1.c(); 
    return m;
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramInt1 != paramInt3) {
      paramInt2 = this.o;
      a(paramInt1, paramInt3, paramInt2, paramInt2);
    } 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield O : Z
    //   4: ifeq -> 9
    //   7: iconst_1
    //   8: ireturn
    //   9: aload_1
    //   10: invokevirtual getAction : ()I
    //   13: ifne -> 25
    //   16: aload_1
    //   17: invokevirtual getEdgeFlags : ()I
    //   20: ifeq -> 25
    //   23: iconst_0
    //   24: ireturn
    //   25: aload_0
    //   26: getfield g : Landroid/support/v4/view/q;
    //   29: astore #10
    //   31: aload #10
    //   33: ifnull -> 620
    //   36: aload #10
    //   38: invokevirtual a : ()I
    //   41: ifne -> 47
    //   44: goto -> 620
    //   47: aload_0
    //   48: getfield J : Landroid/view/VelocityTracker;
    //   51: ifnonnull -> 61
    //   54: aload_0
    //   55: invokestatic obtain : ()Landroid/view/VelocityTracker;
    //   58: putfield J : Landroid/view/VelocityTracker;
    //   61: aload_0
    //   62: getfield J : Landroid/view/VelocityTracker;
    //   65: aload_1
    //   66: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   69: aload_1
    //   70: invokevirtual getAction : ()I
    //   73: istore #6
    //   75: iconst_0
    //   76: istore #9
    //   78: iload #6
    //   80: sipush #255
    //   83: iand
    //   84: istore #6
    //   86: iload #6
    //   88: ifeq -> 554
    //   91: iload #6
    //   93: iconst_1
    //   94: if_icmpeq -> 413
    //   97: iload #6
    //   99: iconst_2
    //   100: if_icmpeq -> 208
    //   103: iload #6
    //   105: iconst_3
    //   106: if_icmpeq -> 178
    //   109: iload #6
    //   111: iconst_5
    //   112: if_icmpeq -> 149
    //   115: iload #6
    //   117: bipush #6
    //   119: if_icmpeq -> 125
    //   122: goto -> 609
    //   125: aload_0
    //   126: aload_1
    //   127: invokespecial a : (Landroid/view/MotionEvent;)V
    //   130: aload_0
    //   131: aload_1
    //   132: aload_1
    //   133: aload_0
    //   134: getfield I : I
    //   137: invokevirtual findPointerIndex : (I)I
    //   140: invokevirtual getX : (I)F
    //   143: putfield E : F
    //   146: goto -> 609
    //   149: aload_1
    //   150: invokevirtual getActionIndex : ()I
    //   153: istore #6
    //   155: aload_0
    //   156: aload_1
    //   157: iload #6
    //   159: invokevirtual getX : (I)F
    //   162: putfield E : F
    //   165: aload_0
    //   166: aload_1
    //   167: iload #6
    //   169: invokevirtual getPointerId : (I)I
    //   172: putfield I : I
    //   175: goto -> 609
    //   178: aload_0
    //   179: getfield z : Z
    //   182: ifeq -> 205
    //   185: aload_0
    //   186: aload_0
    //   187: getfield h : I
    //   190: iconst_1
    //   191: iconst_0
    //   192: iconst_0
    //   193: invokespecial a : (IZIZ)V
    //   196: aload_0
    //   197: invokespecial i : ()Z
    //   200: istore #9
    //   202: goto -> 609
    //   205: goto -> 609
    //   208: aload_0
    //   209: getfield z : Z
    //   212: ifne -> 380
    //   215: aload_1
    //   216: aload_0
    //   217: getfield I : I
    //   220: invokevirtual findPointerIndex : (I)I
    //   223: istore #6
    //   225: iload #6
    //   227: iconst_m1
    //   228: if_icmpne -> 240
    //   231: aload_0
    //   232: invokespecial i : ()Z
    //   235: istore #9
    //   237: goto -> 609
    //   240: aload_1
    //   241: iload #6
    //   243: invokevirtual getX : (I)F
    //   246: fstore_2
    //   247: fload_2
    //   248: aload_0
    //   249: getfield E : F
    //   252: fsub
    //   253: invokestatic abs : (F)F
    //   256: fstore #4
    //   258: aload_1
    //   259: iload #6
    //   261: invokevirtual getY : (I)F
    //   264: fstore_3
    //   265: fload_3
    //   266: aload_0
    //   267: getfield F : F
    //   270: fsub
    //   271: invokestatic abs : (F)F
    //   274: fstore #5
    //   276: fload #4
    //   278: aload_0
    //   279: getfield D : I
    //   282: i2f
    //   283: fcmpl
    //   284: ifle -> 380
    //   287: fload #4
    //   289: fload #5
    //   291: fcmpl
    //   292: ifle -> 380
    //   295: aload_0
    //   296: iconst_1
    //   297: putfield z : Z
    //   300: aload_0
    //   301: iconst_1
    //   302: invokespecial c : (Z)V
    //   305: aload_0
    //   306: getfield G : F
    //   309: fstore #4
    //   311: fload_2
    //   312: fload #4
    //   314: fsub
    //   315: fconst_0
    //   316: fcmpl
    //   317: ifle -> 332
    //   320: fload #4
    //   322: aload_0
    //   323: getfield D : I
    //   326: i2f
    //   327: fadd
    //   328: fstore_2
    //   329: goto -> 341
    //   332: fload #4
    //   334: aload_0
    //   335: getfield D : I
    //   338: i2f
    //   339: fsub
    //   340: fstore_2
    //   341: aload_0
    //   342: fload_2
    //   343: putfield E : F
    //   346: aload_0
    //   347: fload_3
    //   348: putfield F : F
    //   351: aload_0
    //   352: iconst_1
    //   353: invokevirtual setScrollState : (I)V
    //   356: aload_0
    //   357: iconst_1
    //   358: invokespecial setScrollingCacheEnabled : (Z)V
    //   361: aload_0
    //   362: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   365: astore #10
    //   367: aload #10
    //   369: ifnull -> 380
    //   372: aload #10
    //   374: iconst_1
    //   375: invokeinterface requestDisallowInterceptTouchEvent : (Z)V
    //   380: aload_0
    //   381: getfield z : Z
    //   384: ifeq -> 410
    //   387: iconst_0
    //   388: aload_0
    //   389: aload_1
    //   390: aload_1
    //   391: aload_0
    //   392: getfield I : I
    //   395: invokevirtual findPointerIndex : (I)I
    //   398: invokevirtual getX : (I)F
    //   401: invokespecial b : (F)Z
    //   404: ior
    //   405: istore #9
    //   407: goto -> 609
    //   410: goto -> 609
    //   413: aload_0
    //   414: getfield z : Z
    //   417: ifeq -> 551
    //   420: aload_0
    //   421: getfield J : Landroid/view/VelocityTracker;
    //   424: astore #10
    //   426: aload #10
    //   428: sipush #1000
    //   431: aload_0
    //   432: getfield L : I
    //   435: i2f
    //   436: invokevirtual computeCurrentVelocity : (IF)V
    //   439: aload #10
    //   441: aload_0
    //   442: getfield I : I
    //   445: invokevirtual getXVelocity : (I)F
    //   448: f2i
    //   449: istore #7
    //   451: aload_0
    //   452: iconst_1
    //   453: putfield x : Z
    //   456: aload_0
    //   457: invokespecial getClientWidth : ()I
    //   460: istore #8
    //   462: aload_0
    //   463: invokevirtual getScrollX : ()I
    //   466: istore #6
    //   468: aload_0
    //   469: invokespecial g : ()Landroid/support/v4/view/ViewPager$f;
    //   472: astore #10
    //   474: aload_0
    //   475: getfield o : I
    //   478: i2f
    //   479: iload #8
    //   481: i2f
    //   482: fdiv
    //   483: fstore_2
    //   484: aload_0
    //   485: aload_0
    //   486: aload #10
    //   488: getfield b : I
    //   491: iload #6
    //   493: i2f
    //   494: iload #8
    //   496: i2f
    //   497: fdiv
    //   498: aload #10
    //   500: getfield e : F
    //   503: fsub
    //   504: aload #10
    //   506: getfield d : F
    //   509: fload_2
    //   510: fadd
    //   511: fdiv
    //   512: iload #7
    //   514: aload_1
    //   515: aload_1
    //   516: aload_0
    //   517: getfield I : I
    //   520: invokevirtual findPointerIndex : (I)I
    //   523: invokevirtual getX : (I)F
    //   526: aload_0
    //   527: getfield G : F
    //   530: fsub
    //   531: f2i
    //   532: invokespecial a : (IFII)I
    //   535: iconst_1
    //   536: iconst_1
    //   537: iload #7
    //   539: invokevirtual a : (IZZI)V
    //   542: aload_0
    //   543: invokespecial i : ()Z
    //   546: istore #9
    //   548: goto -> 609
    //   551: goto -> 609
    //   554: aload_0
    //   555: getfield l : Landroid/widget/Scroller;
    //   558: invokevirtual abortAnimation : ()V
    //   561: aload_0
    //   562: iconst_0
    //   563: putfield x : Z
    //   566: aload_0
    //   567: invokevirtual e : ()V
    //   570: aload_1
    //   571: invokevirtual getX : ()F
    //   574: fstore_2
    //   575: aload_0
    //   576: fload_2
    //   577: putfield G : F
    //   580: aload_0
    //   581: fload_2
    //   582: putfield E : F
    //   585: aload_1
    //   586: invokevirtual getY : ()F
    //   589: fstore_2
    //   590: aload_0
    //   591: fload_2
    //   592: putfield H : F
    //   595: aload_0
    //   596: fload_2
    //   597: putfield F : F
    //   600: aload_0
    //   601: aload_1
    //   602: iconst_0
    //   603: invokevirtual getPointerId : (I)I
    //   606: putfield I : I
    //   609: iload #9
    //   611: ifeq -> 618
    //   614: aload_0
    //   615: invokestatic B : (Landroid/view/View;)V
    //   618: iconst_1
    //   619: ireturn
    //   620: iconst_0
    //   621: ireturn
  }
  
  public void removeView(View paramView) {
    if (this.v) {
      removeViewInLayout(paramView);
    } else {
      super.removeView(paramView);
    } 
  }
  
  public void setAdapter(q paramq) {
    q q1 = this.g;
    if (q1 != null) {
      q1.b((DataSetObserver)null);
      this.g.b(this);
      for (byte b = 0; b < this.d.size(); b++) {
        f f1 = this.d.get(b);
        this.g.a(this, f1.b, f1.a);
      } 
      this.g.a(this);
      this.d.clear();
      h();
      this.h = 0;
      scrollTo(0, 0);
    } 
    q1 = this.g;
    this.g = paramq;
    this.c = 0;
    if (this.g != null) {
      if (this.n == null)
        this.n = new l(this); 
      this.g.b(this.n);
      this.x = false;
      boolean bool = this.R;
      this.R = true;
      this.c = this.g.a();
      if (this.i >= 0) {
        this.g.a(this.j, this.k);
        a(this.i, false, true);
        this.i = -1;
        this.j = null;
        this.k = null;
      } else if (!bool) {
        e();
      } else {
        requestLayout();
      } 
    } 
    List<i> list = this.a0;
    if (list != null && !list.isEmpty()) {
      byte b = 0;
      int i = this.a0.size();
      while (b < i) {
        ((i)this.a0.get(b)).a(this, q1, paramq);
        b++;
      } 
    } 
  }
  
  public void setCurrentItem(int paramInt) {
    this.x = false;
    a(paramInt, this.R ^ true, false);
  }
  
  public void setOffscreenPageLimit(int paramInt) {
    int i = paramInt;
    if (paramInt < 1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Requested offscreen page limit ");
      stringBuilder.append(paramInt);
      stringBuilder.append(" too small; defaulting to ");
      stringBuilder.append(1);
      Log.w("ViewPager", stringBuilder.toString());
      i = 1;
    } 
    if (i != this.y) {
      this.y = i;
      e();
    } 
  }
  
  @Deprecated
  public void setOnPageChangeListener(j paramj) {
    this.V = paramj;
  }
  
  public void setPageMargin(int paramInt) {
    int i = this.o;
    this.o = paramInt;
    int m = getWidth();
    a(m, m, paramInt, i);
    requestLayout();
  }
  
  public void setPageMarginDrawable(int paramInt) {
    setPageMarginDrawable(android.support.v4.content.a.c(getContext(), paramInt));
  }
  
  public void setPageMarginDrawable(Drawable paramDrawable) {
    boolean bool;
    this.p = paramDrawable;
    if (paramDrawable != null)
      refreshDrawableState(); 
    if (paramDrawable == null) {
      bool = true;
    } else {
      bool = false;
    } 
    setWillNotDraw(bool);
    invalidate();
  }
  
  void setScrollState(int paramInt) {
    if (this.g0 == paramInt)
      return; 
    this.g0 = paramInt;
    if (this.b0 != null) {
      boolean bool;
      if (paramInt != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      b(bool);
    } 
    e(paramInt);
  }
  
  protected boolean verifyDrawable(Drawable paramDrawable) {
    return (super.verifyDrawable(paramDrawable) || paramDrawable == this.p);
  }
  
  static final class a implements Comparator<f> {
    public int a(ViewPager.f param1f1, ViewPager.f param1f2) {
      return param1f1.b - param1f2.b;
    }
  }
  
  static final class b implements Interpolator {
    public float getInterpolation(float param1Float) {
      param1Float--;
      return param1Float * param1Float * param1Float * param1Float * param1Float + 1.0F;
    }
  }
  
  class c implements Runnable {
    final ViewPager c;
    
    c(ViewPager this$0) {}
    
    public void run() {
      this.c.setScrollState(0);
      this.c.e();
    }
  }
  
  class d implements p {
    private final Rect a = new Rect();
    
    final ViewPager b;
    
    d(ViewPager this$0) {}
    
    public c0 a(View param1View, c0 param1c0) {
      c0 c01 = u.b(param1View, param1c0);
      if (c01.g())
        return c01; 
      Rect rect = this.a;
      rect.left = c01.c();
      rect.top = c01.e();
      rect.right = c01.d();
      rect.bottom = c01.b();
      byte b = 0;
      int i = this.b.getChildCount();
      while (b < i) {
        param1c0 = u.a(this.b.getChildAt(b), c01);
        rect.left = Math.min(param1c0.c(), rect.left);
        rect.top = Math.min(param1c0.e(), rect.top);
        rect.right = Math.min(param1c0.d(), rect.right);
        rect.bottom = Math.min(param1c0.b(), rect.bottom);
        b++;
      } 
      return c01.a(rect.left, rect.top, rect.right, rect.bottom);
    }
  }
  
  @Inherited
  @Retention(RetentionPolicy.RUNTIME)
  @Target({ElementType.TYPE})
  public static @interface e {}
  
  static class f {
    Object a;
    
    int b;
    
    boolean c;
    
    float d;
    
    float e;
  }
  
  public static class g extends ViewGroup.LayoutParams {
    public boolean a;
    
    public int b;
    
    float c = 0.0F;
    
    boolean d;
    
    int e;
    
    int f;
    
    public g() {
      super(-1, -1);
    }
    
    public g(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, ViewPager.h0);
      this.b = typedArray.getInteger(0, 48);
      typedArray.recycle();
    }
  }
  
  class h extends b {
    final ViewPager c;
    
    h(ViewPager this$0) {}
    
    private boolean b() {
      q q = this.c.g;
      boolean bool = true;
      if (q == null || q.a() <= 1)
        bool = false; 
      return bool;
    }
    
    public void a(View param1View, c param1c) {
      super.a(param1View, param1c);
      param1c.a(ViewPager.class.getName());
      param1c.k(b());
      if (this.c.canScrollHorizontally(1))
        param1c.a(4096); 
      if (this.c.canScrollHorizontally(-1))
        param1c.a(8192); 
    }
    
    public boolean a(View param1View, int param1Int, Bundle param1Bundle) {
      if (super.a(param1View, param1Int, param1Bundle))
        return true; 
      if (param1Int != 4096) {
        if (param1Int != 8192)
          return false; 
        if (this.c.canScrollHorizontally(-1)) {
          ViewPager viewPager = this.c;
          viewPager.setCurrentItem(viewPager.h - 1);
          return true;
        } 
        return false;
      } 
      if (this.c.canScrollHorizontally(1)) {
        ViewPager viewPager = this.c;
        viewPager.setCurrentItem(viewPager.h + 1);
        return true;
      } 
      return false;
    }
    
    public void b(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      super.b(param1View, param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName(ViewPager.class.getName());
      param1AccessibilityEvent.setScrollable(b());
      if (param1AccessibilityEvent.getEventType() == 4096) {
        q q = this.c.g;
        if (q != null) {
          param1AccessibilityEvent.setItemCount(q.a());
          param1AccessibilityEvent.setFromIndex(this.c.h);
          param1AccessibilityEvent.setToIndex(this.c.h);
        } 
      } 
    }
  }
  
  public static interface i {
    void a(ViewPager param1ViewPager, q param1q1, q param1q2);
  }
  
  public static interface j {
    void a(int param1Int);
    
    void a(int param1Int1, float param1Float, int param1Int2);
    
    void b(int param1Int);
  }
  
  public static interface k {
    void a(View param1View, float param1Float);
  }
  
  private class l extends DataSetObserver {
    final ViewPager a;
    
    l(ViewPager this$0) {}
    
    public void onChanged() {
      this.a.a();
    }
    
    public void onInvalidated() {
      this.a.a();
    }
  }
  
  public static class m extends a {
    public static final Parcelable.Creator<m> CREATOR = (Parcelable.Creator<m>)new a();
    
    int e;
    
    Parcelable f;
    
    ClassLoader g;
    
    m(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      ClassLoader classLoader = param1ClassLoader;
      if (param1ClassLoader == null)
        classLoader = getClass().getClassLoader(); 
      this.e = param1Parcel.readInt();
      this.f = param1Parcel.readParcelable(classLoader);
      this.g = classLoader;
    }
    
    public m(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("FragmentPager.SavedState{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" position=");
      stringBuilder.append(this.e);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.e);
      param1Parcel.writeParcelable(this.f, param1Int);
    }
    
    static final class a implements Parcelable.ClassLoaderCreator<m> {
      public ViewPager.m createFromParcel(Parcel param2Parcel) {
        return new ViewPager.m(param2Parcel, null);
      }
      
      public ViewPager.m createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new ViewPager.m(param2Parcel, param2ClassLoader);
      }
      
      public ViewPager.m[] newArray(int param2Int) {
        return new ViewPager.m[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.ClassLoaderCreator<m> {
    public ViewPager.m createFromParcel(Parcel param1Parcel) {
      return new ViewPager.m(param1Parcel, null);
    }
    
    public ViewPager.m createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new ViewPager.m(param1Parcel, param1ClassLoader);
    }
    
    public ViewPager.m[] newArray(int param1Int) {
      return new ViewPager.m[param1Int];
    }
  }
  
  static class n implements Comparator<View> {
    public int a(View param1View1, View param1View2) {
      ViewPager.g g1 = (ViewPager.g)param1View1.getLayoutParams();
      ViewPager.g g2 = (ViewPager.g)param1View2.getLayoutParams();
      boolean bool = g1.a;
      if (bool != g2.a) {
        byte b;
        if (bool) {
          b = 1;
        } else {
          b = -1;
        } 
        return b;
      } 
      return g1.e - g2.e;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\view\ViewPager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */