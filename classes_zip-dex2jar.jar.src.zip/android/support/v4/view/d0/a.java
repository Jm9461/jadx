package android.support.v4.view.d0;

import android.os.Build;
import android.view.accessibility.AccessibilityEvent;

public final class a {
  public static int a(AccessibilityEvent paramAccessibilityEvent) {
    return (Build.VERSION.SDK_INT >= 19) ? paramAccessibilityEvent.getContentChangeTypes() : 0;
  }
  
  public static void a(AccessibilityEvent paramAccessibilityEvent, int paramInt) {
    if (Build.VERSION.SDK_INT >= 19)
      paramAccessibilityEvent.setContentChangeTypes(paramInt); 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\view\d0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */