package android.support.v4.view;

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.view.d0.c;
import android.util.SparseArray;
import android.view.Display;
import android.view.KeyEvent;
import android.view.PointerIcon;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowInsets;
import android.view.WindowManager;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class u {
  private static Field a;
  
  private static boolean b;
  
  private static Field c;
  
  private static boolean d;
  
  private static WeakHashMap<View, String> e;
  
  private static WeakHashMap<View, y> f = null;
  
  private static Field g;
  
  private static boolean h = false;
  
  private static ThreadLocal<Rect> i;
  
  public static boolean A(View paramView) {
    return (Build.VERSION.SDK_INT >= 17) ? paramView.isPaddingRelative() : false;
  }
  
  public static void B(View paramView) {
    if (Build.VERSION.SDK_INT >= 16) {
      paramView.postInvalidateOnAnimation();
    } else {
      paramView.postInvalidate();
    } 
  }
  
  public static void C(View paramView) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 20) {
      paramView.requestApplyInsets();
    } else if (i >= 16) {
      paramView.requestFitSystemWindows();
    } 
  }
  
  public static void D(View paramView) {
    if (Build.VERSION.SDK_INT >= 21) {
      paramView.stopNestedScroll();
    } else if (paramView instanceof k) {
      ((k)paramView).stopNestedScroll();
    } 
  }
  
  private static void E(View paramView) {
    float f = paramView.getTranslationY();
    paramView.setTranslationY(1.0F + f);
    paramView.setTranslationY(f);
  }
  
  private static Rect a() {
    if (i == null)
      i = new ThreadLocal<Rect>(); 
    Rect rect2 = i.get();
    Rect rect1 = rect2;
    if (rect2 == null) {
      rect1 = new Rect();
      i.set(rect1);
    } 
    rect1.setEmpty();
    return rect1;
  }
  
  public static c0 a(View paramView, c0 paramc0) {
    WindowInsets windowInsets;
    if (Build.VERSION.SDK_INT >= 21) {
      windowInsets = (WindowInsets)c0.a(paramc0);
      WindowInsets windowInsets2 = paramView.dispatchApplyWindowInsets(windowInsets);
      WindowInsets windowInsets1 = windowInsets;
      if (windowInsets2 != windowInsets)
        windowInsets1 = new WindowInsets(windowInsets2); 
      return c0.a(windowInsets1);
    } 
    return (c0)windowInsets;
  }
  
  public static y a(View paramView) {
    if (f == null)
      f = new WeakHashMap<View, y>(); 
    y y2 = f.get(paramView);
    y y1 = y2;
    if (y2 == null) {
      y1 = new y(paramView);
      f.put(paramView, y1);
    } 
    return y1;
  }
  
  public static void a(View paramView, float paramFloat) {
    if (Build.VERSION.SDK_INT >= 21)
      paramView.setElevation(paramFloat); 
  }
  
  private static void a(View paramView, int paramInt) {
    paramView.offsetLeftAndRight(paramInt);
    if (paramView.getVisibility() == 0) {
      E(paramView);
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View)
        E((View)viewParent); 
    } 
  }
  
  public static void a(View paramView, int paramInt1, int paramInt2) {
    if (Build.VERSION.SDK_INT >= 23)
      paramView.setScrollIndicators(paramInt1, paramInt2); 
  }
  
  public static void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (Build.VERSION.SDK_INT >= 17) {
      paramView.setPaddingRelative(paramInt1, paramInt2, paramInt3, paramInt4);
    } else {
      paramView.setPadding(paramInt1, paramInt2, paramInt3, paramInt4);
    } 
  }
  
  public static void a(View paramView, ColorStateList paramColorStateList) {
    Drawable drawable;
    if (Build.VERSION.SDK_INT >= 21) {
      paramView.setBackgroundTintList(paramColorStateList);
      if (Build.VERSION.SDK_INT == 21) {
        boolean bool;
        drawable = paramView.getBackground();
        if (paramView.getBackgroundTintList() != null || paramView.getBackgroundTintMode() != null) {
          bool = true;
        } else {
          bool = false;
        } 
        if (drawable != null && bool) {
          if (drawable.isStateful())
            drawable.setState(paramView.getDrawableState()); 
          paramView.setBackground(drawable);
        } 
      } 
    } else if (paramView instanceof t) {
      ((t)paramView).setSupportBackgroundTintList((ColorStateList)drawable);
    } 
  }
  
  public static void a(View paramView, PorterDuff.Mode paramMode) {
    Drawable drawable;
    if (Build.VERSION.SDK_INT >= 21) {
      paramView.setBackgroundTintMode(paramMode);
      if (Build.VERSION.SDK_INT == 21) {
        boolean bool;
        drawable = paramView.getBackground();
        if (paramView.getBackgroundTintList() != null || paramView.getBackgroundTintMode() != null) {
          bool = true;
        } else {
          bool = false;
        } 
        if (drawable != null && bool) {
          if (drawable.isStateful())
            drawable.setState(paramView.getDrawableState()); 
          paramView.setBackground(drawable);
        } 
      } 
    } else if (paramView instanceof t) {
      ((t)paramView).setSupportBackgroundTintMode((PorterDuff.Mode)drawable);
    } 
  }
  
  public static void a(View paramView, Rect paramRect) {
    if (Build.VERSION.SDK_INT >= 18)
      paramView.setClipBounds(paramRect); 
  }
  
  public static void a(View paramView, Drawable paramDrawable) {
    if (Build.VERSION.SDK_INT >= 16) {
      paramView.setBackground(paramDrawable);
    } else {
      paramView.setBackgroundDrawable(paramDrawable);
    } 
  }
  
  public static void a(View paramView, b paramb) {
    View.AccessibilityDelegate accessibilityDelegate;
    if (paramb == null) {
      paramb = null;
    } else {
      accessibilityDelegate = paramb.a();
    } 
    paramView.setAccessibilityDelegate(accessibilityDelegate);
  }
  
  public static void a(View paramView, c paramc) {
    paramView.onInitializeAccessibilityNodeInfo(paramc.v());
  }
  
  public static void a(View paramView, p paramp) {
    if (Build.VERSION.SDK_INT >= 21) {
      if (paramp == null) {
        paramView.setOnApplyWindowInsetsListener(null);
        return;
      } 
      paramView.setOnApplyWindowInsetsListener(new a(paramp));
    } 
  }
  
  public static void a(View paramView, r paramr) {
    if (Build.VERSION.SDK_INT >= 24) {
      if (paramr != null) {
        Object object = paramr.a();
      } else {
        paramr = null;
      } 
      paramView.setPointerIcon((PointerIcon)paramr);
    } 
  }
  
  public static void a(View paramView, Runnable paramRunnable) {
    if (Build.VERSION.SDK_INT >= 16) {
      paramView.postOnAnimation(paramRunnable);
    } else {
      paramView.postDelayed(paramRunnable, ValueAnimator.getFrameDelay());
    } 
  }
  
  public static void a(View paramView, Runnable paramRunnable, long paramLong) {
    if (Build.VERSION.SDK_INT >= 16) {
      paramView.postOnAnimationDelayed(paramRunnable, paramLong);
    } else {
      paramView.postDelayed(paramRunnable, ValueAnimator.getFrameDelay() + paramLong);
    } 
  }
  
  public static void a(View paramView, String paramString) {
    if (Build.VERSION.SDK_INT >= 21) {
      paramView.setTransitionName(paramString);
    } else {
      if (e == null)
        e = new WeakHashMap<View, String>(); 
      e.put(paramView, paramString);
    } 
  }
  
  @Deprecated
  public static void a(View paramView, boolean paramBoolean) {
    paramView.setFitsSystemWindows(paramBoolean);
  }
  
  public static boolean a(View paramView, int paramInt, Bundle paramBundle) {
    return (Build.VERSION.SDK_INT >= 16) ? paramView.performAccessibilityAction(paramInt, paramBundle) : false;
  }
  
  static boolean a(View paramView, KeyEvent paramKeyEvent) {
    return (Build.VERSION.SDK_INT >= 28) ? false : c.a(paramView).a(paramView, paramKeyEvent);
  }
  
  public static int b(View paramView) {
    return (Build.VERSION.SDK_INT >= 19) ? paramView.getAccessibilityLiveRegion() : 0;
  }
  
  public static c0 b(View paramView, c0 paramc0) {
    WindowInsets windowInsets;
    if (Build.VERSION.SDK_INT >= 21) {
      windowInsets = (WindowInsets)c0.a(paramc0);
      WindowInsets windowInsets2 = paramView.onApplyWindowInsets(windowInsets);
      WindowInsets windowInsets1 = windowInsets;
      if (windowInsets2 != windowInsets)
        windowInsets1 = new WindowInsets(windowInsets2); 
      return c0.a(windowInsets1);
    } 
    return (c0)windowInsets;
  }
  
  private static void b(View paramView, int paramInt) {
    paramView.offsetTopAndBottom(paramInt);
    if (paramView.getVisibility() == 0) {
      E(paramView);
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View)
        E((View)viewParent); 
    } 
  }
  
  public static void b(View paramView, boolean paramBoolean) {
    if (Build.VERSION.SDK_INT >= 16)
      paramView.setHasTransientState(paramBoolean); 
  }
  
  static boolean b(View paramView, KeyEvent paramKeyEvent) {
    return (Build.VERSION.SDK_INT >= 28) ? false : c.a(paramView).a(paramKeyEvent);
  }
  
  public static ColorStateList c(View paramView) {
    if (Build.VERSION.SDK_INT >= 21)
      return paramView.getBackgroundTintList(); 
    if (paramView instanceof t) {
      ColorStateList colorStateList = ((t)paramView).getSupportBackgroundTintList();
    } else {
      paramView = null;
    } 
    return (ColorStateList)paramView;
  }
  
  public static void c(View paramView, int paramInt) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 23) {
      paramView.offsetLeftAndRight(paramInt);
    } else if (i >= 21) {
      Rect rect = a();
      i = 0;
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View) {
        View view = (View)viewParent;
        rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        i = rect.intersects(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom()) ^ true;
      } 
      a(paramView, paramInt);
      if (i != 0 && rect.intersect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom()))
        ((View)viewParent).invalidate(rect); 
    } else {
      a(paramView, paramInt);
    } 
  }
  
  public static PorterDuff.Mode d(View paramView) {
    if (Build.VERSION.SDK_INT >= 21)
      return paramView.getBackgroundTintMode(); 
    if (paramView instanceof t) {
      PorterDuff.Mode mode = ((t)paramView).getSupportBackgroundTintMode();
    } else {
      paramView = null;
    } 
    return (PorterDuff.Mode)paramView;
  }
  
  public static void d(View paramView, int paramInt) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 23) {
      paramView.offsetTopAndBottom(paramInt);
    } else if (i >= 21) {
      Rect rect = a();
      i = 0;
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View) {
        View view = (View)viewParent;
        rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        i = rect.intersects(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom()) ^ true;
      } 
      b(paramView, paramInt);
      if (i != 0 && rect.intersect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom()))
        ((View)viewParent).invalidate(rect); 
    } else {
      b(paramView, paramInt);
    } 
  }
  
  public static Rect e(View paramView) {
    return (Build.VERSION.SDK_INT >= 18) ? paramView.getClipBounds() : null;
  }
  
  public static void e(View paramView, int paramInt) {
    if (Build.VERSION.SDK_INT >= 19)
      paramView.setAccessibilityLiveRegion(paramInt); 
  }
  
  public static Display f(View paramView) {
    return (Build.VERSION.SDK_INT >= 17) ? paramView.getDisplay() : (x(paramView) ? ((WindowManager)paramView.getContext().getSystemService("window")).getDefaultDisplay() : null);
  }
  
  public static void f(View paramView, int paramInt) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 19) {
      paramView.setImportantForAccessibility(paramInt);
    } else if (i >= 16) {
      i = paramInt;
      if (paramInt == 4)
        i = 2; 
      paramView.setImportantForAccessibility(i);
    } 
  }
  
  public static float g(View paramView) {
    return (Build.VERSION.SDK_INT >= 21) ? paramView.getElevation() : 0.0F;
  }
  
  public static void g(View paramView, int paramInt) {
    if (Build.VERSION.SDK_INT >= 26)
      paramView.setImportantForAutofill(paramInt); 
  }
  
  public static void h(View paramView, int paramInt) {
    if (paramView instanceof j) {
      ((j)paramView).a(paramInt);
    } else if (paramInt == 0) {
      D(paramView);
    } 
  }
  
  public static boolean h(View paramView) {
    return (Build.VERSION.SDK_INT >= 16) ? paramView.getFitsSystemWindows() : false;
  }
  
  public static int i(View paramView) {
    return (Build.VERSION.SDK_INT >= 16) ? paramView.getImportantForAccessibility() : 0;
  }
  
  @SuppressLint({"InlinedApi"})
  public static int j(View paramView) {
    return (Build.VERSION.SDK_INT >= 26) ? paramView.getImportantForAutofill() : 0;
  }
  
  public static int k(View paramView) {
    return (Build.VERSION.SDK_INT >= 17) ? paramView.getLayoutDirection() : 0;
  }
  
  public static int l(View paramView) {
    if (Build.VERSION.SDK_INT >= 16)
      return paramView.getMinimumHeight(); 
    if (!d) {
      try {
        c = View.class.getDeclaredField("mMinHeight");
        c.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {}
      d = true;
    } 
    Field field = c;
    if (field != null)
      try {
        return ((Integer)field.get(paramView)).intValue();
      } catch (Exception exception) {} 
    return 0;
  }
  
  public static int m(View paramView) {
    if (Build.VERSION.SDK_INT >= 16)
      return paramView.getMinimumWidth(); 
    if (!b) {
      try {
        a = View.class.getDeclaredField("mMinWidth");
        a.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {}
      b = true;
    } 
    Field field = a;
    if (field != null)
      try {
        return ((Integer)field.get(paramView)).intValue();
      } catch (Exception exception) {} 
    return 0;
  }
  
  public static int n(View paramView) {
    return (Build.VERSION.SDK_INT >= 17) ? paramView.getPaddingEnd() : paramView.getPaddingRight();
  }
  
  public static int o(View paramView) {
    return (Build.VERSION.SDK_INT >= 17) ? paramView.getPaddingStart() : paramView.getPaddingLeft();
  }
  
  public static ViewParent p(View paramView) {
    return (Build.VERSION.SDK_INT >= 16) ? paramView.getParentForAccessibility() : paramView.getParent();
  }
  
  public static String q(View paramView) {
    if (Build.VERSION.SDK_INT >= 21)
      return paramView.getTransitionName(); 
    WeakHashMap<View, String> weakHashMap = e;
    return (weakHashMap == null) ? null : weakHashMap.get(paramView);
  }
  
  public static int r(View paramView) {
    return (Build.VERSION.SDK_INT >= 16) ? paramView.getWindowSystemUiVisibility() : 0;
  }
  
  public static float s(View paramView) {
    return (Build.VERSION.SDK_INT >= 21) ? paramView.getZ() : 0.0F;
  }
  
  public static boolean t(View paramView) {
    boolean bool1 = h;
    boolean bool = false;
    if (bool1)
      return false; 
    if (g == null)
      try {
        g = View.class.getDeclaredField("mAccessibilityDelegate");
        g.setAccessible(true);
      } finally {
        paramView = null;
        h = true;
      }  
    try {
      return bool;
    } finally {
      paramView = null;
      h = true;
    } 
  }
  
  public static boolean u(View paramView) {
    return (Build.VERSION.SDK_INT >= 15) ? paramView.hasOnClickListeners() : false;
  }
  
  public static boolean v(View paramView) {
    return (Build.VERSION.SDK_INT >= 16) ? paramView.hasOverlappingRendering() : true;
  }
  
  public static boolean w(View paramView) {
    return (Build.VERSION.SDK_INT >= 16) ? paramView.hasTransientState() : false;
  }
  
  public static boolean x(View paramView) {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 19)
      return paramView.isAttachedToWindow(); 
    if (paramView.getWindowToken() != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public static boolean y(View paramView) {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 19)
      return paramView.isLaidOut(); 
    if (paramView.getWidth() > 0 && paramView.getHeight() > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public static boolean z(View paramView) {
    return (Build.VERSION.SDK_INT >= 21) ? paramView.isNestedScrollingEnabled() : ((paramView instanceof k) ? ((k)paramView).isNestedScrollingEnabled() : false);
  }
  
  static {
    new AtomicInteger(1);
  }
  
  static final class a implements View.OnApplyWindowInsetsListener {
    final p a;
    
    a(p param1p) {}
    
    public WindowInsets onApplyWindowInsets(View param1View, WindowInsets param1WindowInsets) {
      c0 c0 = c0.a(param1WindowInsets);
      return (WindowInsets)c0.a(this.a.a(param1View, c0));
    }
  }
  
  public static interface b {
    boolean a(View param1View, KeyEvent param1KeyEvent);
  }
  
  static class c {
    private static final ArrayList<WeakReference<View>> d = new ArrayList<WeakReference<View>>();
    
    private WeakHashMap<View, Boolean> a = null;
    
    private SparseArray<WeakReference<View>> b = null;
    
    private WeakReference<KeyEvent> c = null;
    
    static c a(View param1View) {
      c c2 = (c)param1View.getTag(a.b.a.c.tag_unhandled_key_event_manager);
      c c1 = c2;
      if (c2 == null) {
        c1 = new c();
        param1View.setTag(a.b.a.c.tag_unhandled_key_event_manager, c1);
      } 
      return c1;
    }
    
    private SparseArray<WeakReference<View>> a() {
      if (this.b == null)
        this.b = new SparseArray(); 
      return this.b;
    }
    
    private View b(View param1View, KeyEvent param1KeyEvent) {
      WeakHashMap<View, Boolean> weakHashMap = this.a;
      if (weakHashMap == null || !weakHashMap.containsKey(param1View))
        return null; 
      if (param1View instanceof ViewGroup) {
        ViewGroup viewGroup = (ViewGroup)param1View;
        for (int i = viewGroup.getChildCount() - 1; i >= 0; i--) {
          View view = b(viewGroup.getChildAt(i), param1KeyEvent);
          if (view != null)
            return view; 
        } 
      } 
      return c(param1View, param1KeyEvent) ? param1View : null;
    }
    
    private void b() {
      null = this.a;
      if (null != null)
        null.clear(); 
      if (d.isEmpty())
        return; 
      synchronized (d) {
        if (this.a == null) {
          null = new WeakHashMap<View, Boolean>();
          this();
          this.a = null;
        } 
        for (int i = d.size() - 1; i >= 0; i--) {
          View view = ((WeakReference<View>)d.get(i)).get();
          if (view == null) {
            d.remove(i);
          } else {
            this.a.put(view, Boolean.TRUE);
            for (ViewParent viewParent = view.getParent(); viewParent instanceof View; viewParent = viewParent.getParent())
              this.a.put((View)viewParent, Boolean.TRUE); 
          } 
        } 
        return;
      } 
    }
    
    private boolean c(View param1View, KeyEvent param1KeyEvent) {
      ArrayList<u.b> arrayList = (ArrayList)param1View.getTag(a.b.a.c.tag_unhandled_key_listeners);
      if (arrayList != null)
        for (int i = arrayList.size() - 1; i >= 0; i--) {
          if (((u.b)arrayList.get(i)).a(param1View, param1KeyEvent))
            return true; 
        }  
      return false;
    }
    
    boolean a(KeyEvent param1KeyEvent) {
      WeakReference<KeyEvent> weakReference1 = this.c;
      if (weakReference1 != null && weakReference1.get() == param1KeyEvent)
        return false; 
      this.c = new WeakReference<KeyEvent>(param1KeyEvent);
      WeakReference<KeyEvent> weakReference2 = null;
      SparseArray<WeakReference<View>> sparseArray = a();
      weakReference1 = weakReference2;
      if (param1KeyEvent.getAction() == 1) {
        int i = sparseArray.indexOfKey(param1KeyEvent.getKeyCode());
        weakReference1 = weakReference2;
        if (i >= 0) {
          weakReference1 = (WeakReference<KeyEvent>)sparseArray.valueAt(i);
          sparseArray.removeAt(i);
        } 
      } 
      weakReference2 = weakReference1;
      if (weakReference1 == null)
        weakReference2 = (WeakReference<KeyEvent>)sparseArray.get(param1KeyEvent.getKeyCode()); 
      if (weakReference2 != null) {
        View view = (View)weakReference2.get();
        if (view != null && u.x(view))
          c(view, param1KeyEvent); 
        return true;
      } 
      return false;
    }
    
    boolean a(View param1View, KeyEvent param1KeyEvent) {
      boolean bool;
      if (param1KeyEvent.getAction() == 0)
        b(); 
      param1View = b(param1View, param1KeyEvent);
      if (param1KeyEvent.getAction() == 0) {
        int i = param1KeyEvent.getKeyCode();
        if (param1View != null && !KeyEvent.isModifierKey(i))
          a().put(i, new WeakReference<View>(param1View)); 
      } 
      if (param1View != null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\vie\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */