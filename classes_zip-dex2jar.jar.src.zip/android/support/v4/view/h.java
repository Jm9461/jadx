package android.support.v4.view;

import a.b.g.b.a.b;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Build;
import android.util.Log;
import android.view.MenuItem;

public final class h {
  public static MenuItem a(MenuItem paramMenuItem, c paramc) {
    if (paramMenuItem instanceof b)
      return (MenuItem)((b)paramMenuItem).a(paramc); 
    Log.w("MenuItemCompat", "setActionProvider: item does not implement SupportMenuItem; ignoring");
    return paramMenuItem;
  }
  
  public static void a(MenuItem paramMenuItem, char paramChar, int paramInt) {
    if (paramMenuItem instanceof b) {
      ((b)paramMenuItem).setAlphabeticShortcut(paramChar, paramInt);
    } else if (Build.VERSION.SDK_INT >= 26) {
      paramMenuItem.setAlphabeticShortcut(paramChar, paramInt);
    } 
  }
  
  public static void a(MenuItem paramMenuItem, ColorStateList paramColorStateList) {
    if (paramMenuItem instanceof b) {
      ((b)paramMenuItem).setIconTintList(paramColorStateList);
    } else if (Build.VERSION.SDK_INT >= 26) {
      paramMenuItem.setIconTintList(paramColorStateList);
    } 
  }
  
  public static void a(MenuItem paramMenuItem, PorterDuff.Mode paramMode) {
    if (paramMenuItem instanceof b) {
      ((b)paramMenuItem).setIconTintMode(paramMode);
    } else if (Build.VERSION.SDK_INT >= 26) {
      paramMenuItem.setIconTintMode(paramMode);
    } 
  }
  
  public static void a(MenuItem paramMenuItem, CharSequence paramCharSequence) {
    if (paramMenuItem instanceof b) {
      ((b)paramMenuItem).setContentDescription(paramCharSequence);
    } else if (Build.VERSION.SDK_INT >= 26) {
      paramMenuItem.setContentDescription(paramCharSequence);
    } 
  }
  
  public static void b(MenuItem paramMenuItem, char paramChar, int paramInt) {
    if (paramMenuItem instanceof b) {
      ((b)paramMenuItem).setNumericShortcut(paramChar, paramInt);
    } else if (Build.VERSION.SDK_INT >= 26) {
      paramMenuItem.setNumericShortcut(paramChar, paramInt);
    } 
  }
  
  public static void b(MenuItem paramMenuItem, CharSequence paramCharSequence) {
    if (paramMenuItem instanceof b) {
      ((b)paramMenuItem).setTooltipText(paramCharSequence);
    } else if (Build.VERSION.SDK_INT >= 26) {
      paramMenuItem.setTooltipText(paramCharSequence);
    } 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\view\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */