package android.support.v4.view;

import android.content.Context;
import android.os.Build;
import android.view.PointerIcon;

public final class r {
  private Object a;
  
  private r(Object paramObject) {
    this.a = paramObject;
  }
  
  public static r a(Context paramContext, int paramInt) {
    return (Build.VERSION.SDK_INT >= 24) ? new r(PointerIcon.getSystemIcon(paramContext, paramInt)) : new r(null);
  }
  
  public Object a() {
    return this.a;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\view\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */