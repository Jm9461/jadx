package android.support.v4.view;

import android.os.Build;
import android.view.WindowInsets;

public class c0 {
  private final Object a;
  
  private c0(Object paramObject) {
    this.a = paramObject;
  }
  
  static c0 a(Object paramObject) {
    if (paramObject == null) {
      paramObject = null;
    } else {
      paramObject = new c0(paramObject);
    } 
    return (c0)paramObject;
  }
  
  static Object a(c0 paramc0) {
    Object object;
    if (paramc0 == null) {
      paramc0 = null;
    } else {
      object = paramc0.a;
    } 
    return object;
  }
  
  public c0 a() {
    return (Build.VERSION.SDK_INT >= 20) ? new c0(((WindowInsets)this.a).consumeSystemWindowInsets()) : null;
  }
  
  public c0 a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return (Build.VERSION.SDK_INT >= 20) ? new c0(((WindowInsets)this.a).replaceSystemWindowInsets(paramInt1, paramInt2, paramInt3, paramInt4)) : null;
  }
  
  public int b() {
    return (Build.VERSION.SDK_INT >= 20) ? ((WindowInsets)this.a).getSystemWindowInsetBottom() : 0;
  }
  
  public int c() {
    return (Build.VERSION.SDK_INT >= 20) ? ((WindowInsets)this.a).getSystemWindowInsetLeft() : 0;
  }
  
  public int d() {
    return (Build.VERSION.SDK_INT >= 20) ? ((WindowInsets)this.a).getSystemWindowInsetRight() : 0;
  }
  
  public int e() {
    return (Build.VERSION.SDK_INT >= 20) ? ((WindowInsets)this.a).getSystemWindowInsetTop() : 0;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = true;
    if (this == paramObject)
      return true; 
    if (paramObject == null || getClass() != paramObject.getClass())
      return false; 
    c0 c01 = (c0)paramObject;
    paramObject = this.a;
    if (paramObject == null) {
      if (c01.a != null)
        bool = false; 
    } else {
      bool = paramObject.equals(c01.a);
    } 
    return bool;
  }
  
  public boolean f() {
    return (Build.VERSION.SDK_INT >= 20) ? ((WindowInsets)this.a).hasSystemWindowInsets() : false;
  }
  
  public boolean g() {
    return (Build.VERSION.SDK_INT >= 21) ? ((WindowInsets)this.a).isConsumed() : false;
  }
  
  public int hashCode() {
    int i;
    Object object = this.a;
    if (object == null) {
      i = 0;
    } else {
      i = object.hashCode();
    } 
    return i;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\view\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */