package android.support.v4.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.support.v4.view.u;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import java.util.ArrayList;
import java.util.List;

public class DrawerLayout extends ViewGroup {
  private static final int[] M = new int[] { 16843828 };
  
  static final int[] N = new int[] { 16842931 };
  
  static final boolean O;
  
  private static final boolean P;
  
  private Drawable A;
  
  private CharSequence B;
  
  private CharSequence C;
  
  private Object D;
  
  private boolean E;
  
  private Drawable F = null;
  
  private Drawable G = null;
  
  private Drawable H = null;
  
  private Drawable I = null;
  
  private final ArrayList<View> J;
  
  private Rect K;
  
  private Matrix L;
  
  private final c c = new c();
  
  private float d;
  
  private int e;
  
  private int f = -1728053248;
  
  private float g;
  
  private Paint h = new Paint();
  
  private final s i;
  
  private final s j;
  
  private final g k;
  
  private final g l;
  
  private int m;
  
  private boolean n;
  
  private boolean o = true;
  
  private int p = 3;
  
  private int q = 3;
  
  private int r = 3;
  
  private int s = 3;
  
  private boolean t;
  
  private d u;
  
  private List<d> v;
  
  private float w;
  
  private float x;
  
  private Drawable y;
  
  private Drawable z;
  
  static {
    if (Build.VERSION.SDK_INT >= 19) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    O = bool1;
    if (Build.VERSION.SDK_INT >= 21) {
      bool1 = bool2;
    } else {
      bool1 = false;
    } 
    P = bool1;
  }
  
  public DrawerLayout(Context paramContext) {
    this(paramContext, null);
  }
  
  public DrawerLayout(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public DrawerLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    setDescendantFocusability(262144);
    float f2 = (getResources().getDisplayMetrics()).density;
    this.e = (int)(64.0F * f2 + 0.5F);
    float f1 = 400.0F * f2;
    this.k = new g(this, 3);
    this.l = new g(this, 5);
    this.i = s.a(this, 1.0F, this.k);
    this.i.d(1);
    this.i.a(f1);
    this.k.a(this.i);
    this.j = s.a(this, 1.0F, this.l);
    this.j.d(2);
    this.j.a(f1);
    this.l.a(this.j);
    setFocusableInTouchMode(true);
    u.f((View)this, 1);
    u.a((View)this, new b(this));
    setMotionEventSplittingEnabled(false);
    if (u.h((View)this))
      if (Build.VERSION.SDK_INT >= 21) {
        setOnApplyWindowInsetsListener(new a(this));
        setSystemUiVisibility(1280);
        TypedArray typedArray = paramContext.obtainStyledAttributes(M);
        try {
          this.y = typedArray.getDrawable(0);
        } finally {
          typedArray.recycle();
        } 
      } else {
        this.y = null;
      }  
    this.d = 10.0F * f2;
    this.J = new ArrayList<View>();
  }
  
  private boolean a(float paramFloat1, float paramFloat2, View paramView) {
    if (this.K == null)
      this.K = new Rect(); 
    paramView.getHitRect(this.K);
    return this.K.contains((int)paramFloat1, (int)paramFloat2);
  }
  
  private boolean a(Drawable paramDrawable, int paramInt) {
    if (paramDrawable == null || !android.support.v4.graphics.drawable.a.f(paramDrawable))
      return false; 
    android.support.v4.graphics.drawable.a.a(paramDrawable, paramInt);
    return true;
  }
  
  private boolean a(MotionEvent paramMotionEvent, View paramView) {
    boolean bool;
    if (!paramView.getMatrix().isIdentity()) {
      paramMotionEvent = b(paramMotionEvent, paramView);
      bool = paramView.dispatchGenericMotionEvent(paramMotionEvent);
      paramMotionEvent.recycle();
    } else {
      float f1 = (getScrollX() - paramView.getLeft());
      float f2 = (getScrollY() - paramView.getTop());
      paramMotionEvent.offsetLocation(f1, f2);
      bool = paramView.dispatchGenericMotionEvent(paramMotionEvent);
      paramMotionEvent.offsetLocation(-f1, -f2);
    } 
    return bool;
  }
  
  private MotionEvent b(MotionEvent paramMotionEvent, View paramView) {
    float f2 = (getScrollX() - paramView.getLeft());
    float f1 = (getScrollY() - paramView.getTop());
    paramMotionEvent = MotionEvent.obtain(paramMotionEvent);
    paramMotionEvent.offsetLocation(f2, f1);
    Matrix matrix = paramView.getMatrix();
    if (!matrix.isIdentity()) {
      if (this.L == null)
        this.L = new Matrix(); 
      matrix.invert(this.L);
      paramMotionEvent.transform(this.L);
    } 
    return paramMotionEvent;
  }
  
  private void c(View paramView, boolean paramBoolean) {
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      if ((!paramBoolean && !i(view)) || (paramBoolean && view == paramView)) {
        u.f(view, 1);
      } else {
        u.f(view, 4);
      } 
    } 
  }
  
  private boolean e() {
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      if (((e)getChildAt(b).getLayoutParams()).c)
        return true; 
    } 
    return false;
  }
  
  private boolean f() {
    boolean bool;
    if (d() != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private Drawable g() {
    int i = u.k((View)this);
    if (i == 0) {
      Drawable drawable = this.F;
      if (drawable != null) {
        a(drawable, i);
        return this.F;
      } 
    } else {
      Drawable drawable = this.G;
      if (drawable != null) {
        a(drawable, i);
        return this.G;
      } 
    } 
    return this.H;
  }
  
  private Drawable h() {
    int i = u.k((View)this);
    if (i == 0) {
      Drawable drawable = this.G;
      if (drawable != null) {
        a(drawable, i);
        return this.G;
      } 
    } else {
      Drawable drawable = this.F;
      if (drawable != null) {
        a(drawable, i);
        return this.F;
      } 
    } 
    return this.I;
  }
  
  static String h(int paramInt) {
    return ((paramInt & 0x3) == 3) ? "LEFT" : (((paramInt & 0x5) == 5) ? "RIGHT" : Integer.toHexString(paramInt));
  }
  
  private void i() {
    if (P)
      return; 
    this.z = g();
    this.A = h();
  }
  
  private static boolean l(View paramView) {
    Drawable drawable = paramView.getBackground();
    boolean bool = false;
    if (drawable != null) {
      if (drawable.getOpacity() == -1)
        bool = true; 
      return bool;
    } 
    return false;
  }
  
  static boolean m(View paramView) {
    boolean bool;
    if (u.i(paramView) != 4 && u.i(paramView) != 2) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  void a() {
    if (!this.t) {
      long l = SystemClock.uptimeMillis();
      MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
      int i = getChildCount();
      for (byte b = 0; b < i; b++)
        getChildAt(b).dispatchTouchEvent(motionEvent); 
      motionEvent.recycle();
      this.t = true;
    } 
  }
  
  public void a(int paramInt) {
    a(paramInt, true);
  }
  
  public void a(int paramInt1, int paramInt2) {
    int i = android.support.v4.view.d.a(paramInt2, u.k((View)this));
    if (paramInt2 != 3) {
      if (paramInt2 != 5) {
        if (paramInt2 != 8388611) {
          if (paramInt2 == 8388613)
            this.s = paramInt1; 
        } else {
          this.r = paramInt1;
        } 
      } else {
        this.q = paramInt1;
      } 
    } else {
      this.p = paramInt1;
    } 
    if (paramInt1 != 0) {
      s s1;
      if (i == 3) {
        s1 = this.i;
      } else {
        s1 = this.j;
      } 
      s1.a();
    } 
    if (paramInt1 != 1) {
      if (paramInt1 == 2) {
        View view = b(i);
        if (view != null)
          k(view); 
      } 
    } else {
      View view = b(i);
      if (view != null)
        a(view); 
    } 
  }
  
  void a(int paramInt1, int paramInt2, View paramView) {
    paramInt1 = this.i.e();
    int i = this.j.e();
    if (paramInt1 == 1 || i == 1) {
      paramInt1 = 1;
    } else if (paramInt1 == 2 || i == 2) {
      paramInt1 = 2;
    } else {
      paramInt1 = 0;
    } 
    if (paramView != null && paramInt2 == 0) {
      float f = ((e)paramView.getLayoutParams()).b;
      if (f == 0.0F) {
        b(paramView);
      } else if (f == 1.0F) {
        c(paramView);
      } 
    } 
    if (paramInt1 != this.m) {
      this.m = paramInt1;
      List<d> list = this.v;
      if (list != null)
        for (paramInt2 = list.size() - 1; paramInt2 >= 0; paramInt2--)
          ((d)this.v.get(paramInt2)).a(paramInt1);  
    } 
  }
  
  public void a(int paramInt, boolean paramBoolean) {
    View view = b(paramInt);
    if (view != null) {
      a(view, paramBoolean);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("No drawer view found with gravity ");
    stringBuilder.append(h(paramInt));
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void a(d paramd) {
    if (paramd == null)
      return; 
    if (this.v == null)
      this.v = new ArrayList<d>(); 
    this.v.add(paramd);
  }
  
  public void a(View paramView) {
    a(paramView, true);
  }
  
  void a(View paramView, float paramFloat) {
    List<d> list = this.v;
    if (list != null)
      for (int i = list.size() - 1; i >= 0; i--)
        ((d)this.v.get(i)).a(paramView, paramFloat);  
  }
  
  public void a(View paramView, boolean paramBoolean) {
    if (i(paramView)) {
      e e = (e)paramView.getLayoutParams();
      if (this.o) {
        e.b = 0.0F;
        e.d = 0;
      } else if (paramBoolean) {
        e.d = 0x4 | e.d;
        if (a(paramView, 3)) {
          this.i.b(paramView, -paramView.getWidth(), paramView.getTop());
        } else {
          this.j.b(paramView, getWidth(), paramView.getTop());
        } 
      } else {
        b(paramView, 0.0F);
        a(e.a, 0, paramView);
        paramView.setVisibility(4);
      } 
      invalidate();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a sliding drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void a(Object paramObject, boolean paramBoolean) {
    this.D = paramObject;
    this.E = paramBoolean;
    if (!paramBoolean && getBackground() == null) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    setWillNotDraw(paramBoolean);
    requestLayout();
  }
  
  void a(boolean paramBoolean) {
    boolean bool;
    byte b1 = 0;
    int i = getChildCount();
    byte b2 = 0;
    while (b2 < i) {
      boolean bool1;
      View view = getChildAt(b2);
      e e = (e)view.getLayoutParams();
      int j = b1;
      if (i(view))
        if (paramBoolean && !e.c) {
          j = b1;
        } else {
          boolean bool2;
          j = view.getWidth();
          if (a(view, 3)) {
            bool2 = b1 | this.i.b(view, -j, view.getTop());
          } else {
            bool2 |= this.j.b(view, getWidth(), view.getTop());
          } 
          e.c = false;
          bool1 = bool2;
        }  
      b2++;
      bool = bool1;
    } 
    this.k.b();
    this.l.b();
    if (bool)
      invalidate(); 
  }
  
  boolean a(View paramView, int paramInt) {
    boolean bool;
    if ((e(paramView) & paramInt) == paramInt) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void addFocusables(ArrayList<View> paramArrayList, int paramInt1, int paramInt2) {
    if (getDescendantFocusability() == 393216)
      return; 
    int j = getChildCount();
    int i = 0;
    byte b;
    for (b = 0; b < j; b++) {
      View view = getChildAt(b);
      if (i(view)) {
        if (h(view)) {
          i = 1;
          view.addFocusables(paramArrayList, paramInt1, paramInt2);
        } 
      } else {
        this.J.add(view);
      } 
    } 
    if (!i) {
      i = this.J.size();
      for (b = 0; b < i; b++) {
        View view = this.J.get(b);
        if (view.getVisibility() == 0)
          view.addFocusables(paramArrayList, paramInt1, paramInt2); 
      } 
    } 
    this.J.clear();
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    super.addView(paramView, paramInt, paramLayoutParams);
    if (c() != null || i(paramView)) {
      u.f(paramView, 4);
    } else {
      u.f(paramView, 1);
    } 
    if (!O)
      u.a(paramView, this.c); 
  }
  
  View b(int paramInt) {
    int j = android.support.v4.view.d.a(paramInt, u.k((View)this));
    int i = getChildCount();
    for (paramInt = 0; paramInt < i; paramInt++) {
      View view = getChildAt(paramInt);
      if ((e(view) & 0x7) == (j & 0x7))
        return view; 
    } 
    return null;
  }
  
  public void b() {
    a(false);
  }
  
  public void b(int paramInt, boolean paramBoolean) {
    View view = b(paramInt);
    if (view != null) {
      b(view, paramBoolean);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("No drawer view found with gravity ");
    stringBuilder.append(h(paramInt));
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void b(d paramd) {
    if (paramd == null)
      return; 
    List<d> list = this.v;
    if (list == null)
      return; 
    list.remove(paramd);
  }
  
  void b(View paramView) {
    e e = (e)paramView.getLayoutParams();
    if ((e.d & 0x1) == 1) {
      e.d = 0;
      List<d> list = this.v;
      if (list != null)
        for (int i = list.size() - 1; i >= 0; i--)
          ((d)this.v.get(i)).b(paramView);  
      c(paramView, false);
      if (hasWindowFocus()) {
        paramView = getRootView();
        if (paramView != null)
          paramView.sendAccessibilityEvent(32); 
      } 
    } 
  }
  
  void b(View paramView, float paramFloat) {
    float f = f(paramView);
    int i = paramView.getWidth();
    int j = (int)(i * f);
    i = (int)(i * paramFloat) - j;
    if (!a(paramView, 3))
      i = -i; 
    paramView.offsetLeftAndRight(i);
    c(paramView, paramFloat);
  }
  
  public void b(View paramView, boolean paramBoolean) {
    if (i(paramView)) {
      e e = (e)paramView.getLayoutParams();
      if (this.o) {
        e.b = 1.0F;
        e.d = 1;
        c(paramView, true);
      } else if (paramBoolean) {
        e.d |= 0x2;
        if (a(paramView, 3)) {
          this.i.b(paramView, 0, paramView.getTop());
        } else {
          this.j.b(paramView, getWidth() - paramView.getWidth(), paramView.getTop());
        } 
      } else {
        b(paramView, 1.0F);
        a(e.a, 0, paramView);
        paramView.setVisibility(0);
      } 
      invalidate();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a sliding drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public int c(int paramInt) {
    int i = u.k((View)this);
    if (paramInt != 3) {
      if (paramInt != 5) {
        if (paramInt != 8388611) {
          if (paramInt == 8388613) {
            paramInt = this.s;
            if (paramInt != 3)
              return paramInt; 
            if (i == 0) {
              paramInt = this.q;
            } else {
              paramInt = this.p;
            } 
            if (paramInt != 3)
              return paramInt; 
          } 
        } else {
          paramInt = this.r;
          if (paramInt != 3)
            return paramInt; 
          if (i == 0) {
            paramInt = this.p;
          } else {
            paramInt = this.q;
          } 
          if (paramInt != 3)
            return paramInt; 
        } 
      } else {
        paramInt = this.q;
        if (paramInt != 3)
          return paramInt; 
        if (i == 0) {
          paramInt = this.s;
        } else {
          paramInt = this.r;
        } 
        if (paramInt != 3)
          return paramInt; 
      } 
    } else {
      paramInt = this.p;
      if (paramInt != 3)
        return paramInt; 
      if (i == 0) {
        paramInt = this.r;
      } else {
        paramInt = this.s;
      } 
      if (paramInt != 3)
        return paramInt; 
    } 
    return 0;
  }
  
  View c() {
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      if ((((e)view.getLayoutParams()).d & 0x1) == 1)
        return view; 
    } 
    return null;
  }
  
  void c(View paramView) {
    e e = (e)paramView.getLayoutParams();
    if ((e.d & 0x1) == 0) {
      e.d = 1;
      List<d> list = this.v;
      if (list != null)
        for (int i = list.size() - 1; i >= 0; i--)
          ((d)this.v.get(i)).a(paramView);  
      c(paramView, true);
      if (hasWindowFocus())
        sendAccessibilityEvent(32); 
    } 
  }
  
  void c(View paramView, float paramFloat) {
    e e = (e)paramView.getLayoutParams();
    if (paramFloat == e.b)
      return; 
    e.b = paramFloat;
    a(paramView, paramFloat);
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    boolean bool;
    if (paramLayoutParams instanceof e && super.checkLayoutParams(paramLayoutParams)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void computeScroll() {
    int i = getChildCount();
    float f = 0.0F;
    for (byte b = 0; b < i; b++)
      f = Math.max(f, ((e)getChildAt(b).getLayoutParams()).b); 
    this.g = f;
    boolean bool2 = this.i.a(true);
    boolean bool1 = this.j.a(true);
    if (bool2 || bool1)
      u.B((View)this); 
  }
  
  public int d(View paramView) {
    if (i(paramView))
      return c(((e)paramView.getLayoutParams()).a); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  View d() {
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      if (i(view) && j(view))
        return view; 
    } 
    return null;
  }
  
  public CharSequence d(int paramInt) {
    paramInt = android.support.v4.view.d.a(paramInt, u.k((View)this));
    return (paramInt == 3) ? this.B : ((paramInt == 5) ? this.C : null);
  }
  
  public boolean dispatchGenericMotionEvent(MotionEvent paramMotionEvent) {
    if ((paramMotionEvent.getSource() & 0x2) == 0 || paramMotionEvent.getAction() == 10 || this.g <= 0.0F)
      return super.dispatchGenericMotionEvent(paramMotionEvent); 
    int i = getChildCount();
    if (i != 0) {
      float f1 = paramMotionEvent.getX();
      float f2 = paramMotionEvent.getY();
      while (--i >= 0) {
        View view = getChildAt(i);
        if (a(f1, f2, view) && !g(view) && a(paramMotionEvent, view))
          return true; 
        i--;
      } 
    } 
    return false;
  }
  
  protected boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    int m = getHeight();
    boolean bool1 = g(paramView);
    int i = 0;
    int j = getWidth();
    int k = paramCanvas.save();
    if (bool1) {
      int n = getChildCount();
      byte b = 0;
      while (b < n) {
        View view = getChildAt(b);
        int i2 = i;
        int i1 = j;
        if (view != paramView) {
          i2 = i;
          i1 = j;
          if (view.getVisibility() == 0) {
            i2 = i;
            i1 = j;
            if (l(view)) {
              i2 = i;
              i1 = j;
              if (i(view))
                if (view.getHeight() < m) {
                  i2 = i;
                  i1 = j;
                } else if (a(view, 3)) {
                  i2 = view.getRight();
                  i1 = i;
                  if (i2 > i)
                    i1 = i2; 
                  i2 = i1;
                  i1 = j;
                } else {
                  int i3 = view.getLeft();
                  i2 = i;
                  i1 = j;
                  if (i3 < j) {
                    i1 = i3;
                    i2 = i;
                  } 
                }  
            } 
          } 
        } 
        b++;
        i = i2;
        j = i1;
      } 
      paramCanvas.clipRect(i, 0, j, getHeight());
    } else {
      i = 0;
    } 
    boolean bool2 = super.drawChild(paramCanvas, paramView, paramLong);
    paramCanvas.restoreToCount(k);
    float f = this.g;
    if (f > 0.0F && bool1) {
      int i1 = this.f;
      int n = (int)(((0xFF000000 & i1) >>> 24) * f);
      this.h.setColor(n << 24 | i1 & 0xFFFFFF);
      paramCanvas.drawRect(i, 0.0F, j, getHeight(), this.h);
    } else if (this.z != null && a(paramView, 3)) {
      j = this.z.getIntrinsicWidth();
      int n = paramView.getRight();
      i = this.i.c();
      f = Math.max(0.0F, Math.min(n / i, 1.0F));
      this.z.setBounds(n, paramView.getTop(), n + j, paramView.getBottom());
      this.z.setAlpha((int)(255.0F * f));
      this.z.draw(paramCanvas);
    } else if (this.A != null && a(paramView, 5)) {
      j = this.A.getIntrinsicWidth();
      int n = paramView.getLeft();
      int i1 = getWidth();
      i = this.j.c();
      f = Math.max(0.0F, Math.min((i1 - n) / i, 1.0F));
      this.A.setBounds(n - j, paramView.getTop(), n, paramView.getBottom());
      this.A.setAlpha((int)(255.0F * f));
      this.A.draw(paramCanvas);
    } 
    return bool2;
  }
  
  int e(View paramView) {
    return android.support.v4.view.d.a(((e)paramView.getLayoutParams()).a, u.k((View)this));
  }
  
  public boolean e(int paramInt) {
    View view = b(paramInt);
    return (view != null) ? h(view) : false;
  }
  
  float f(View paramView) {
    return ((e)paramView.getLayoutParams()).b;
  }
  
  public boolean f(int paramInt) {
    View view = b(paramInt);
    return (view != null) ? j(view) : false;
  }
  
  public void g(int paramInt) {
    b(paramInt, true);
  }
  
  boolean g(View paramView) {
    boolean bool;
    if (((e)paramView.getLayoutParams()).a == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new e(-1, -1);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new e(getContext(), paramAttributeSet);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    e e;
    if (paramLayoutParams instanceof e) {
      e = new e((e)paramLayoutParams);
    } else if (e instanceof ViewGroup.MarginLayoutParams) {
      e = new e(e);
    } else {
      e = new e((ViewGroup.LayoutParams)e);
    } 
    return (ViewGroup.LayoutParams)e;
  }
  
  public float getDrawerElevation() {
    return P ? this.d : 0.0F;
  }
  
  public Drawable getStatusBarBackgroundDrawable() {
    return this.y;
  }
  
  public boolean h(View paramView) {
    if (i(paramView)) {
      int i = ((e)paramView.getLayoutParams()).d;
      boolean bool = true;
      if ((i & 0x1) != 1)
        bool = false; 
      return bool;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  boolean i(View paramView) {
    int i = ((e)paramView.getLayoutParams()).a;
    i = android.support.v4.view.d.a(i, u.k(paramView));
    return ((i & 0x3) != 0) ? true : (((i & 0x5) != 0));
  }
  
  public boolean j(View paramView) {
    if (i(paramView)) {
      boolean bool;
      if (((e)paramView.getLayoutParams()).b > 0.0F) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void k(View paramView) {
    b(paramView, true);
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.o = true;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    this.o = true;
  }
  
  public void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.E && this.y != null) {
      boolean bool;
      if (Build.VERSION.SDK_INT >= 21) {
        Object object = this.D;
        if (object != null) {
          bool = ((WindowInsets)object).getSystemWindowInsetTop();
        } else {
          bool = false;
        } 
      } else {
        bool = false;
      } 
      if (bool) {
        this.y.setBounds(0, 0, getWidth(), bool);
        this.y.draw(paramCanvas);
      } 
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore #4
    //   6: aload_0
    //   7: getfield i : Landroid/support/v4/widget/s;
    //   10: aload_1
    //   11: invokevirtual b : (Landroid/view/MotionEvent;)Z
    //   14: istore #9
    //   16: aload_0
    //   17: getfield j : Landroid/support/v4/widget/s;
    //   20: aload_1
    //   21: invokevirtual b : (Landroid/view/MotionEvent;)Z
    //   24: istore #8
    //   26: iconst_0
    //   27: istore #6
    //   29: iconst_0
    //   30: istore #5
    //   32: iconst_0
    //   33: istore #7
    //   35: iload #4
    //   37: ifeq -> 118
    //   40: iload #4
    //   42: iconst_1
    //   43: if_icmpeq -> 101
    //   46: iload #4
    //   48: iconst_2
    //   49: if_icmpeq -> 65
    //   52: iload #4
    //   54: iconst_3
    //   55: if_icmpeq -> 101
    //   58: iload #6
    //   60: istore #4
    //   62: goto -> 191
    //   65: iload #6
    //   67: istore #4
    //   69: aload_0
    //   70: getfield i : Landroid/support/v4/widget/s;
    //   73: iconst_3
    //   74: invokevirtual a : (I)Z
    //   77: ifeq -> 191
    //   80: aload_0
    //   81: getfield k : Landroid/support/v4/widget/DrawerLayout$g;
    //   84: invokevirtual b : ()V
    //   87: aload_0
    //   88: getfield l : Landroid/support/v4/widget/DrawerLayout$g;
    //   91: invokevirtual b : ()V
    //   94: iload #6
    //   96: istore #4
    //   98: goto -> 191
    //   101: aload_0
    //   102: iconst_1
    //   103: invokevirtual a : (Z)V
    //   106: aload_0
    //   107: iconst_0
    //   108: putfield t : Z
    //   111: iload #6
    //   113: istore #4
    //   115: goto -> 191
    //   118: aload_1
    //   119: invokevirtual getX : ()F
    //   122: fstore_2
    //   123: aload_1
    //   124: invokevirtual getY : ()F
    //   127: fstore_3
    //   128: aload_0
    //   129: fload_2
    //   130: putfield w : F
    //   133: aload_0
    //   134: fload_3
    //   135: putfield x : F
    //   138: iload #5
    //   140: istore #4
    //   142: aload_0
    //   143: getfield g : F
    //   146: fconst_0
    //   147: fcmpl
    //   148: ifle -> 186
    //   151: aload_0
    //   152: getfield i : Landroid/support/v4/widget/s;
    //   155: fload_2
    //   156: f2i
    //   157: fload_3
    //   158: f2i
    //   159: invokevirtual b : (II)Landroid/view/View;
    //   162: astore_1
    //   163: iload #5
    //   165: istore #4
    //   167: aload_1
    //   168: ifnull -> 186
    //   171: iload #5
    //   173: istore #4
    //   175: aload_0
    //   176: aload_1
    //   177: invokevirtual g : (Landroid/view/View;)Z
    //   180: ifeq -> 186
    //   183: iconst_1
    //   184: istore #4
    //   186: aload_0
    //   187: iconst_0
    //   188: putfield t : Z
    //   191: iload #9
    //   193: iload #8
    //   195: ior
    //   196: ifne -> 218
    //   199: iload #4
    //   201: ifne -> 218
    //   204: aload_0
    //   205: invokespecial e : ()Z
    //   208: ifne -> 218
    //   211: aload_0
    //   212: getfield t : Z
    //   215: ifeq -> 221
    //   218: iconst_1
    //   219: istore #7
    //   221: iload #7
    //   223: ireturn
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 4 && f()) {
      paramKeyEvent.startTracking();
      return true;
    } 
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    View view;
    if (paramInt == 4) {
      boolean bool;
      view = d();
      if (view != null && d(view) == 0)
        b(); 
      if (view != null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    } 
    return super.onKeyUp(paramInt, (KeyEvent)view);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.n = true;
    paramInt3 -= paramInt1;
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      if (view.getVisibility() != 8) {
        e e = (e)view.getLayoutParams();
        if (g(view)) {
          paramInt1 = e.leftMargin;
          view.layout(paramInt1, e.topMargin, view.getMeasuredWidth() + paramInt1, e.topMargin + view.getMeasuredHeight());
        } else {
          float f;
          int j;
          boolean bool;
          int k = view.getMeasuredWidth();
          int m = view.getMeasuredHeight();
          if (a(view, 3)) {
            j = -k + (int)(k * e.b);
            f = (k + j) / k;
          } else {
            j = paramInt3 - (int)(k * e.b);
            f = (paramInt3 - j) / k;
          } 
          if (f != e.b) {
            bool = true;
          } else {
            bool = false;
          } 
          paramInt1 = e.a & 0x70;
          if (paramInt1 != 16) {
            if (paramInt1 != 80) {
              paramInt1 = e.topMargin;
              view.layout(j, paramInt1, j + k, paramInt1 + m);
            } else {
              paramInt1 = paramInt4 - paramInt2;
              view.layout(j, paramInt1 - e.bottomMargin - view.getMeasuredHeight(), j + k, paramInt1 - e.bottomMargin);
            } 
          } else {
            int i1 = paramInt4 - paramInt2;
            int n = (i1 - m) / 2;
            if (n < e.topMargin) {
              paramInt1 = e.topMargin;
            } else {
              int i2 = e.bottomMargin;
              paramInt1 = n;
              if (n + m > i1 - i2)
                paramInt1 = i1 - i2 - m; 
            } 
            view.layout(j, paramInt1, j + k, paramInt1 + m);
          } 
          if (bool)
            c(view, f); 
          if (e.b > 0.0F) {
            paramInt1 = 0;
          } else {
            paramInt1 = 4;
          } 
          if (view.getVisibility() != paramInt1)
            view.setVisibility(paramInt1); 
        } 
      } 
    } 
    this.n = false;
    this.o = false;
  }
  
  @SuppressLint({"WrongConstant"})
  protected void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_1
    //   1: invokestatic getMode : (I)I
    //   4: istore #9
    //   6: iload_2
    //   7: invokestatic getMode : (I)I
    //   10: istore #13
    //   12: iload_1
    //   13: invokestatic getSize : (I)I
    //   16: istore #8
    //   18: iload_2
    //   19: invokestatic getSize : (I)I
    //   22: istore #12
    //   24: iload #9
    //   26: ldc_w 1073741824
    //   29: if_icmpne -> 56
    //   32: iload #9
    //   34: istore #7
    //   36: iload #13
    //   38: istore #5
    //   40: iload #8
    //   42: istore #10
    //   44: iload #12
    //   46: istore #11
    //   48: iload #13
    //   50: ldc_w 1073741824
    //   53: if_icmpeq -> 165
    //   56: aload_0
    //   57: invokevirtual isInEditMode : ()Z
    //   60: ifeq -> 873
    //   63: iload #9
    //   65: ldc_w -2147483648
    //   68: if_icmpne -> 79
    //   71: ldc_w 1073741824
    //   74: istore #6
    //   76: goto -> 98
    //   79: iload #9
    //   81: istore #6
    //   83: iload #9
    //   85: ifne -> 98
    //   88: ldc_w 1073741824
    //   91: istore #6
    //   93: sipush #300
    //   96: istore #8
    //   98: iload #13
    //   100: ldc_w -2147483648
    //   103: if_icmpne -> 126
    //   106: ldc_w 1073741824
    //   109: istore #5
    //   111: iload #6
    //   113: istore #7
    //   115: iload #8
    //   117: istore #10
    //   119: iload #12
    //   121: istore #11
    //   123: goto -> 165
    //   126: iload #6
    //   128: istore #7
    //   130: iload #13
    //   132: istore #5
    //   134: iload #8
    //   136: istore #10
    //   138: iload #12
    //   140: istore #11
    //   142: iload #13
    //   144: ifne -> 165
    //   147: ldc_w 1073741824
    //   150: istore #5
    //   152: sipush #300
    //   155: istore #11
    //   157: iload #8
    //   159: istore #10
    //   161: iload #6
    //   163: istore #7
    //   165: aload_0
    //   166: iload #10
    //   168: iload #11
    //   170: invokevirtual setMeasuredDimension : (II)V
    //   173: aload_0
    //   174: getfield D : Ljava/lang/Object;
    //   177: ifnull -> 193
    //   180: aload_0
    //   181: invokestatic h : (Landroid/view/View;)Z
    //   184: ifeq -> 193
    //   187: iconst_1
    //   188: istore #9
    //   190: goto -> 196
    //   193: iconst_0
    //   194: istore #9
    //   196: aload_0
    //   197: invokestatic k : (Landroid/view/View;)I
    //   200: istore #14
    //   202: iconst_0
    //   203: istore #8
    //   205: iconst_0
    //   206: istore #6
    //   208: aload_0
    //   209: invokevirtual getChildCount : ()I
    //   212: istore #15
    //   214: iconst_0
    //   215: istore #12
    //   217: iload #12
    //   219: iload #15
    //   221: if_icmpge -> 872
    //   224: aload_0
    //   225: iload #12
    //   227: invokevirtual getChildAt : (I)Landroid/view/View;
    //   230: astore #19
    //   232: aload #19
    //   234: invokevirtual getVisibility : ()I
    //   237: bipush #8
    //   239: if_icmpne -> 245
    //   242: goto -> 558
    //   245: aload #19
    //   247: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   250: checkcast android/support/v4/widget/DrawerLayout$e
    //   253: astore #20
    //   255: iload #9
    //   257: ifeq -> 504
    //   260: aload #20
    //   262: getfield a : I
    //   265: iload #14
    //   267: invokestatic a : (II)I
    //   270: istore #13
    //   272: aload #19
    //   274: invokestatic h : (Landroid/view/View;)Z
    //   277: ifeq -> 376
    //   280: getstatic android/os/Build$VERSION.SDK_INT : I
    //   283: bipush #21
    //   285: if_icmplt -> 373
    //   288: aload_0
    //   289: getfield D : Ljava/lang/Object;
    //   292: checkcast android/view/WindowInsets
    //   295: astore #18
    //   297: iload #13
    //   299: iconst_3
    //   300: if_icmpne -> 329
    //   303: aload #18
    //   305: aload #18
    //   307: invokevirtual getSystemWindowInsetLeft : ()I
    //   310: aload #18
    //   312: invokevirtual getSystemWindowInsetTop : ()I
    //   315: iconst_0
    //   316: aload #18
    //   318: invokevirtual getSystemWindowInsetBottom : ()I
    //   321: invokevirtual replaceSystemWindowInsets : (IIII)Landroid/view/WindowInsets;
    //   324: astore #17
    //   326: goto -> 362
    //   329: aload #18
    //   331: astore #17
    //   333: iload #13
    //   335: iconst_5
    //   336: if_icmpne -> 362
    //   339: aload #18
    //   341: iconst_0
    //   342: aload #18
    //   344: invokevirtual getSystemWindowInsetTop : ()I
    //   347: aload #18
    //   349: invokevirtual getSystemWindowInsetRight : ()I
    //   352: aload #18
    //   354: invokevirtual getSystemWindowInsetBottom : ()I
    //   357: invokevirtual replaceSystemWindowInsets : (IIII)Landroid/view/WindowInsets;
    //   360: astore #17
    //   362: aload #19
    //   364: aload #17
    //   366: invokevirtual dispatchApplyWindowInsets : (Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    //   369: pop
    //   370: goto -> 504
    //   373: goto -> 504
    //   376: getstatic android/os/Build$VERSION.SDK_INT : I
    //   379: bipush #21
    //   381: if_icmplt -> 501
    //   384: aload_0
    //   385: getfield D : Ljava/lang/Object;
    //   388: checkcast android/view/WindowInsets
    //   391: astore #18
    //   393: iload #13
    //   395: iconst_3
    //   396: if_icmpne -> 425
    //   399: aload #18
    //   401: aload #18
    //   403: invokevirtual getSystemWindowInsetLeft : ()I
    //   406: aload #18
    //   408: invokevirtual getSystemWindowInsetTop : ()I
    //   411: iconst_0
    //   412: aload #18
    //   414: invokevirtual getSystemWindowInsetBottom : ()I
    //   417: invokevirtual replaceSystemWindowInsets : (IIII)Landroid/view/WindowInsets;
    //   420: astore #17
    //   422: goto -> 458
    //   425: aload #18
    //   427: astore #17
    //   429: iload #13
    //   431: iconst_5
    //   432: if_icmpne -> 458
    //   435: aload #18
    //   437: iconst_0
    //   438: aload #18
    //   440: invokevirtual getSystemWindowInsetTop : ()I
    //   443: aload #18
    //   445: invokevirtual getSystemWindowInsetRight : ()I
    //   448: aload #18
    //   450: invokevirtual getSystemWindowInsetBottom : ()I
    //   453: invokevirtual replaceSystemWindowInsets : (IIII)Landroid/view/WindowInsets;
    //   456: astore #17
    //   458: aload #20
    //   460: aload #17
    //   462: invokevirtual getSystemWindowInsetLeft : ()I
    //   465: putfield leftMargin : I
    //   468: aload #20
    //   470: aload #17
    //   472: invokevirtual getSystemWindowInsetTop : ()I
    //   475: putfield topMargin : I
    //   478: aload #20
    //   480: aload #17
    //   482: invokevirtual getSystemWindowInsetRight : ()I
    //   485: putfield rightMargin : I
    //   488: aload #20
    //   490: aload #17
    //   492: invokevirtual getSystemWindowInsetBottom : ()I
    //   495: putfield bottomMargin : I
    //   498: goto -> 504
    //   501: goto -> 504
    //   504: aload_0
    //   505: aload #19
    //   507: invokevirtual g : (Landroid/view/View;)Z
    //   510: ifeq -> 561
    //   513: aload #19
    //   515: iload #10
    //   517: aload #20
    //   519: getfield leftMargin : I
    //   522: isub
    //   523: aload #20
    //   525: getfield rightMargin : I
    //   528: isub
    //   529: ldc_w 1073741824
    //   532: invokestatic makeMeasureSpec : (II)I
    //   535: iload #11
    //   537: aload #20
    //   539: getfield topMargin : I
    //   542: isub
    //   543: aload #20
    //   545: getfield bottomMargin : I
    //   548: isub
    //   549: ldc_w 1073741824
    //   552: invokestatic makeMeasureSpec : (II)I
    //   555: invokevirtual measure : (II)V
    //   558: goto -> 792
    //   561: aload_0
    //   562: aload #19
    //   564: invokevirtual i : (Landroid/view/View;)Z
    //   567: ifeq -> 798
    //   570: getstatic android/support/v4/widget/DrawerLayout.P : Z
    //   573: ifeq -> 601
    //   576: aload #19
    //   578: invokestatic g : (Landroid/view/View;)F
    //   581: fstore #4
    //   583: aload_0
    //   584: getfield d : F
    //   587: fstore_3
    //   588: fload #4
    //   590: fload_3
    //   591: fcmpl
    //   592: ifeq -> 601
    //   595: aload #19
    //   597: fload_3
    //   598: invokestatic a : (Landroid/view/View;F)V
    //   601: aload_0
    //   602: aload #19
    //   604: invokevirtual e : (Landroid/view/View;)I
    //   607: bipush #7
    //   609: iand
    //   610: istore #16
    //   612: iload #16
    //   614: iconst_3
    //   615: if_icmpne -> 624
    //   618: iconst_1
    //   619: istore #13
    //   621: goto -> 627
    //   624: iconst_0
    //   625: istore #13
    //   627: iload #13
    //   629: ifeq -> 637
    //   632: iload #8
    //   634: ifne -> 650
    //   637: iload #13
    //   639: ifne -> 728
    //   642: iload #6
    //   644: ifne -> 650
    //   647: goto -> 728
    //   650: new java/lang/StringBuilder
    //   653: dup
    //   654: invokespecial <init> : ()V
    //   657: astore #17
    //   659: aload #17
    //   661: ldc_w 'Child drawer has absolute gravity '
    //   664: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   667: pop
    //   668: aload #17
    //   670: iload #16
    //   672: invokestatic h : (I)Ljava/lang/String;
    //   675: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   678: pop
    //   679: aload #17
    //   681: ldc_w ' but this '
    //   684: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   687: pop
    //   688: aload #17
    //   690: ldc_w 'DrawerLayout'
    //   693: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   696: pop
    //   697: aload #17
    //   699: ldc_w ' already has a '
    //   702: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   705: pop
    //   706: aload #17
    //   708: ldc_w 'drawer view along that edge'
    //   711: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   714: pop
    //   715: new java/lang/IllegalStateException
    //   718: dup
    //   719: aload #17
    //   721: invokevirtual toString : ()Ljava/lang/String;
    //   724: invokespecial <init> : (Ljava/lang/String;)V
    //   727: athrow
    //   728: iload #13
    //   730: ifeq -> 739
    //   733: iconst_1
    //   734: istore #8
    //   736: goto -> 742
    //   739: iconst_1
    //   740: istore #6
    //   742: aload #19
    //   744: iload_1
    //   745: aload_0
    //   746: getfield e : I
    //   749: aload #20
    //   751: getfield leftMargin : I
    //   754: iadd
    //   755: aload #20
    //   757: getfield rightMargin : I
    //   760: iadd
    //   761: aload #20
    //   763: getfield width : I
    //   766: invokestatic getChildMeasureSpec : (III)I
    //   769: iload_2
    //   770: aload #20
    //   772: getfield topMargin : I
    //   775: aload #20
    //   777: getfield bottomMargin : I
    //   780: iadd
    //   781: aload #20
    //   783: getfield height : I
    //   786: invokestatic getChildMeasureSpec : (III)I
    //   789: invokevirtual measure : (II)V
    //   792: iinc #12, 1
    //   795: goto -> 217
    //   798: new java/lang/StringBuilder
    //   801: dup
    //   802: invokespecial <init> : ()V
    //   805: astore #17
    //   807: aload #17
    //   809: ldc_w 'Child '
    //   812: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   815: pop
    //   816: aload #17
    //   818: aload #19
    //   820: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   823: pop
    //   824: aload #17
    //   826: ldc_w ' at index '
    //   829: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   832: pop
    //   833: aload #17
    //   835: iload #12
    //   837: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   840: pop
    //   841: aload #17
    //   843: ldc_w ' does not have a valid layout_gravity - must be Gravity.LEFT, '
    //   846: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   849: pop
    //   850: aload #17
    //   852: ldc_w 'Gravity.RIGHT or Gravity.NO_GRAVITY'
    //   855: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   858: pop
    //   859: new java/lang/IllegalStateException
    //   862: dup
    //   863: aload #17
    //   865: invokevirtual toString : ()Ljava/lang/String;
    //   868: invokespecial <init> : (Ljava/lang/String;)V
    //   871: athrow
    //   872: return
    //   873: new java/lang/IllegalArgumentException
    //   876: dup
    //   877: ldc_w 'DrawerLayout must be measured with MeasureSpec.EXACTLY.'
    //   880: invokespecial <init> : (Ljava/lang/String;)V
    //   883: astore #17
    //   885: goto -> 891
    //   888: aload #17
    //   890: athrow
    //   891: goto -> 888
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof f)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    f f = (f)paramParcelable;
    super.onRestoreInstanceState(f.a());
    int i = f.e;
    if (i != 0) {
      View view = b(i);
      if (view != null)
        k(view); 
    } 
    i = f.f;
    if (i != 3)
      a(i, 3); 
    i = f.g;
    if (i != 3)
      a(i, 5); 
    i = f.h;
    if (i != 3)
      a(i, 8388611); 
    i = f.i;
    if (i != 3)
      a(i, 8388613); 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    i();
  }
  
  protected Parcelable onSaveInstanceState() {
    f f = new f(super.onSaveInstanceState());
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      e e = (e)getChildAt(b).getLayoutParams();
      int j = e.d;
      boolean bool = false;
      if (j == 1) {
        j = 1;
      } else {
        j = 0;
      } 
      if (e.d == 2)
        bool = true; 
      if (j != 0 || bool) {
        f.e = e.a;
        break;
      } 
    } 
    f.f = this.p;
    f.g = this.q;
    f.h = this.r;
    f.i = this.s;
    return (Parcelable)f;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    View view;
    this.i.a(paramMotionEvent);
    this.j.a(paramMotionEvent);
    int i = paramMotionEvent.getAction() & 0xFF;
    boolean bool = false;
    if (i != 0) {
      if (i != 1) {
        if (i == 3) {
          a(true);
          this.t = false;
        } 
      } else {
        float f2 = paramMotionEvent.getX();
        float f1 = paramMotionEvent.getY();
        boolean bool2 = true;
        view = this.i.b((int)f2, (int)f1);
        boolean bool1 = bool2;
        if (view != null) {
          bool1 = bool2;
          if (g(view)) {
            f2 -= this.w;
            f1 -= this.x;
            i = this.i.d();
            bool1 = bool2;
            if (f2 * f2 + f1 * f1 < (i * i)) {
              view = c();
              bool1 = bool2;
              if (view != null) {
                bool1 = bool;
                if (d(view) == 2)
                  bool1 = true; 
              } 
            } 
          } 
        } 
        a(bool1);
      } 
    } else {
      float f1 = view.getX();
      float f2 = view.getY();
      this.w = f1;
      this.x = f2;
      this.t = false;
    } 
    return true;
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    super.requestDisallowInterceptTouchEvent(paramBoolean);
    if (paramBoolean)
      a(true); 
  }
  
  public void requestLayout() {
    if (!this.n)
      super.requestLayout(); 
  }
  
  public void setDrawerElevation(float paramFloat) {
    this.d = paramFloat;
    for (byte b = 0; b < getChildCount(); b++) {
      View view = getChildAt(b);
      if (i(view))
        u.a(view, this.d); 
    } 
  }
  
  @Deprecated
  public void setDrawerListener(d paramd) {
    d d1 = this.u;
    if (d1 != null)
      b(d1); 
    if (paramd != null)
      a(paramd); 
    this.u = paramd;
  }
  
  public void setDrawerLockMode(int paramInt) {
    a(paramInt, 3);
    a(paramInt, 5);
  }
  
  public void setScrimColor(int paramInt) {
    this.f = paramInt;
    invalidate();
  }
  
  public void setStatusBarBackground(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = android.support.v4.content.a.c(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    this.y = drawable;
    invalidate();
  }
  
  public void setStatusBarBackground(Drawable paramDrawable) {
    this.y = paramDrawable;
    invalidate();
  }
  
  public void setStatusBarBackgroundColor(int paramInt) {
    this.y = (Drawable)new ColorDrawable(paramInt);
    invalidate();
  }
  
  static {
    boolean bool1;
    boolean bool2 = true;
  }
  
  class a implements View.OnApplyWindowInsetsListener {
    a(DrawerLayout this$0) {}
    
    public WindowInsets onApplyWindowInsets(View param1View, WindowInsets param1WindowInsets) {
      boolean bool;
      DrawerLayout drawerLayout = (DrawerLayout)param1View;
      if (param1WindowInsets.getSystemWindowInsetTop() > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      drawerLayout.a(param1WindowInsets, bool);
      return param1WindowInsets.consumeSystemWindowInsets();
    }
  }
  
  class b extends android.support.v4.view.b {
    private final Rect c = new Rect();
    
    final DrawerLayout d;
    
    b(DrawerLayout this$0) {}
    
    private void a(android.support.v4.view.d0.c param1c1, android.support.v4.view.d0.c param1c2) {
      Rect rect = this.c;
      param1c2.a(rect);
      param1c1.c(rect);
      param1c2.b(rect);
      param1c1.d(rect);
      param1c1.n(param1c2.t());
      param1c1.e(param1c2.f());
      param1c1.a(param1c2.c());
      param1c1.b(param1c2.d());
      param1c1.g(param1c2.m());
      param1c1.d(param1c2.l());
      param1c1.h(param1c2.n());
      param1c1.i(param1c2.o());
      param1c1.a(param1c2.i());
      param1c1.l(param1c2.s());
      param1c1.j(param1c2.p());
      param1c1.a(param1c2.a());
    }
    
    private void a(android.support.v4.view.d0.c param1c, ViewGroup param1ViewGroup) {
      int i = param1ViewGroup.getChildCount();
      for (byte b1 = 0; b1 < i; b1++) {
        View view = param1ViewGroup.getChildAt(b1);
        if (DrawerLayout.m(view))
          param1c.a(view); 
      } 
    }
    
    public void a(View param1View, android.support.v4.view.d0.c param1c) {
      if (DrawerLayout.O) {
        super.a(param1View, param1c);
      } else {
        android.support.v4.view.d0.c c1 = android.support.v4.view.d0.c.a(param1c);
        super.a(param1View, c1);
        param1c.c(param1View);
        ViewParent viewParent = u.p(param1View);
        if (viewParent instanceof View)
          param1c.b((View)viewParent); 
        a(param1c, c1);
        c1.u();
        a(param1c, (ViewGroup)param1View);
      } 
      param1c.a(DrawerLayout.class.getName());
      param1c.h(false);
      param1c.i(false);
      param1c.a(android.support.v4.view.d0.c.a.b);
      param1c.a(android.support.v4.view.d0.c.a.c);
    }
    
    public boolean a(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      List<CharSequence> list;
      CharSequence charSequence;
      if (param1AccessibilityEvent.getEventType() == 32) {
        list = param1AccessibilityEvent.getText();
        View view = this.d.d();
        if (view != null) {
          int i = this.d.e(view);
          charSequence = this.d.d(i);
          if (charSequence != null)
            list.add(charSequence); 
        } 
        return true;
      } 
      return super.a((View)list, (AccessibilityEvent)charSequence);
    }
    
    public boolean a(ViewGroup param1ViewGroup, View param1View, AccessibilityEvent param1AccessibilityEvent) {
      return (DrawerLayout.O || DrawerLayout.m(param1View)) ? super.a(param1ViewGroup, param1View, param1AccessibilityEvent) : false;
    }
    
    public void b(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      super.b(param1View, param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName(DrawerLayout.class.getName());
    }
  }
  
  static final class c extends android.support.v4.view.b {
    public void a(View param1View, android.support.v4.view.d0.c param1c) {
      super.a(param1View, param1c);
      if (!DrawerLayout.m(param1View))
        param1c.b(null); 
    }
  }
  
  public static interface d {
    void a(int param1Int);
    
    void a(View param1View);
    
    void a(View param1View, float param1Float);
    
    void b(View param1View);
  }
  
  public static class e extends ViewGroup.MarginLayoutParams {
    public int a = 0;
    
    float b;
    
    boolean c;
    
    int d;
    
    public e(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public e(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, DrawerLayout.N);
      this.a = typedArray.getInt(0, 0);
      typedArray.recycle();
    }
    
    public e(e param1e) {
      super(param1e);
      this.a = param1e.a;
    }
    
    public e(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public e(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
  }
  
  protected static class f extends android.support.v4.view.a {
    public static final Parcelable.Creator<f> CREATOR = (Parcelable.Creator<f>)new a();
    
    int e = 0;
    
    int f;
    
    int g;
    
    int h;
    
    int i;
    
    public f(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      this.e = param1Parcel.readInt();
      this.f = param1Parcel.readInt();
      this.g = param1Parcel.readInt();
      this.h = param1Parcel.readInt();
      this.i = param1Parcel.readInt();
    }
    
    public f(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.e);
      param1Parcel.writeInt(this.f);
      param1Parcel.writeInt(this.g);
      param1Parcel.writeInt(this.h);
      param1Parcel.writeInt(this.i);
    }
    
    static final class a implements Parcelable.ClassLoaderCreator<f> {
      public DrawerLayout.f createFromParcel(Parcel param2Parcel) {
        return new DrawerLayout.f(param2Parcel, null);
      }
      
      public DrawerLayout.f createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new DrawerLayout.f(param2Parcel, param2ClassLoader);
      }
      
      public DrawerLayout.f[] newArray(int param2Int) {
        return new DrawerLayout.f[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.ClassLoaderCreator<f> {
    public DrawerLayout.f createFromParcel(Parcel param1Parcel) {
      return new DrawerLayout.f(param1Parcel, null);
    }
    
    public DrawerLayout.f createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new DrawerLayout.f(param1Parcel, param1ClassLoader);
    }
    
    public DrawerLayout.f[] newArray(int param1Int) {
      return new DrawerLayout.f[param1Int];
    }
  }
  
  private class g extends s.c {
    private final int a;
    
    private s b;
    
    private final Runnable c = new a(this);
    
    final DrawerLayout d;
    
    g(DrawerLayout this$0, int param1Int) {
      this.a = param1Int;
    }
    
    private void c() {
      int i = this.a;
      byte b = 3;
      if (i == 3)
        b = 5; 
      View view = this.d.b(b);
      if (view != null)
        this.d.a(view); 
    }
    
    public int a(View param1View) {
      boolean bool;
      if (this.d.i(param1View)) {
        bool = param1View.getWidth();
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public int a(View param1View, int param1Int1, int param1Int2) {
      if (this.d.a(param1View, 3))
        return Math.max(-param1View.getWidth(), Math.min(param1Int1, 0)); 
      param1Int2 = this.d.getWidth();
      return Math.max(param1Int2 - param1View.getWidth(), Math.min(param1Int1, param1Int2));
    }
    
    void a() {
      View view;
      int k = this.b.c();
      int i = this.a;
      int j = 0;
      if (i == 3) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 0) {
        view = this.d.b(3);
        if (view != null)
          j = -view.getWidth(); 
        j += k;
      } else {
        view = this.d.b(5);
        j = this.d.getWidth() - k;
      } 
      if (view != null && ((i != 0 && view.getLeft() < j) || (i == 0 && view.getLeft() > j)) && this.d.d(view) == 0) {
        DrawerLayout.e e = (DrawerLayout.e)view.getLayoutParams();
        this.b.b(view, j, view.getTop());
        e.c = true;
        this.d.invalidate();
        c();
        this.d.a();
      } 
    }
    
    public void a(int param1Int1, int param1Int2) {
      View view;
      if ((param1Int1 & 0x1) == 1) {
        view = this.d.b(3);
      } else {
        view = this.d.b(5);
      } 
      if (view != null && this.d.d(view) == 0)
        this.b.a(view, param1Int2); 
    }
    
    public void a(s param1s) {
      this.b = param1s;
    }
    
    public void a(View param1View, float param1Float1, float param1Float2) {
      int i;
      param1Float2 = this.d.f(param1View);
      int j = param1View.getWidth();
      if (this.d.a(param1View, 3)) {
        if (param1Float1 > 0.0F || (param1Float1 == 0.0F && param1Float2 > 0.5F)) {
          i = 0;
        } else {
          i = -j;
        } 
      } else {
        i = this.d.getWidth();
        if (param1Float1 < 0.0F || (param1Float1 == 0.0F && param1Float2 > 0.5F))
          i -= j; 
      } 
      this.b.d(i, param1View.getTop());
      this.d.invalidate();
    }
    
    public void a(View param1View, int param1Int) {
      ((DrawerLayout.e)param1View.getLayoutParams()).c = false;
      c();
    }
    
    public void a(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      float f;
      param1Int2 = param1View.getWidth();
      if (this.d.a(param1View, 3)) {
        f = (param1Int2 + param1Int1) / param1Int2;
      } else {
        f = (this.d.getWidth() - param1Int1) / param1Int2;
      } 
      this.d.c(param1View, f);
      if (f == 0.0F) {
        param1Int1 = 4;
      } else {
        param1Int1 = 0;
      } 
      param1View.setVisibility(param1Int1);
      this.d.invalidate();
    }
    
    public int b(View param1View, int param1Int1, int param1Int2) {
      return param1View.getTop();
    }
    
    public void b() {
      this.d.removeCallbacks(this.c);
    }
    
    public void b(int param1Int1, int param1Int2) {
      this.d.postDelayed(this.c, 160L);
    }
    
    public boolean b(int param1Int) {
      return false;
    }
    
    public boolean b(View param1View, int param1Int) {
      boolean bool;
      if (this.d.i(param1View) && this.d.a(param1View, this.a) && this.d.d(param1View) == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public void c(int param1Int) {
      this.d.a(this.a, param1Int, this.b.b());
    }
    
    class a implements Runnable {
      final DrawerLayout.g c;
      
      a(DrawerLayout.g this$0) {}
      
      public void run() {
        this.c.a();
      }
    }
  }
  
  class a implements Runnable {
    final DrawerLayout.g c;
    
    a(DrawerLayout this$0) {}
    
    public void run() {
      this.c.a();
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\widget\DrawerLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */