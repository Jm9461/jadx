package android.support.v4.widget;

import android.content.Context;
import android.support.v4.view.u;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import android.widget.OverScroller;
import java.util.Arrays;

public class s {
  private static final Interpolator w = new a();
  
  private int a;
  
  private int b;
  
  private int c = -1;
  
  private float[] d;
  
  private float[] e;
  
  private float[] f;
  
  private float[] g;
  
  private int[] h;
  
  private int[] i;
  
  private int[] j;
  
  private int k;
  
  private VelocityTracker l;
  
  private float m;
  
  private float n;
  
  private int o;
  
  private int p;
  
  private OverScroller q;
  
  private final c r;
  
  private View s;
  
  private boolean t;
  
  private final ViewGroup u;
  
  private final Runnable v = new b(this);
  
  private s(Context paramContext, ViewGroup paramViewGroup, c paramc) {
    if (paramViewGroup != null) {
      if (paramc != null) {
        this.u = paramViewGroup;
        this.r = paramc;
        ViewConfiguration viewConfiguration = ViewConfiguration.get(paramContext);
        this.o = (int)(20.0F * (paramContext.getResources().getDisplayMetrics()).density + 0.5F);
        this.b = viewConfiguration.getScaledTouchSlop();
        this.m = viewConfiguration.getScaledMaximumFlingVelocity();
        this.n = viewConfiguration.getScaledMinimumFlingVelocity();
        this.q = new OverScroller(paramContext, w);
        return;
      } 
      throw new IllegalArgumentException("Callback may not be null");
    } 
    throw new IllegalArgumentException("Parent view may not be null");
  }
  
  private float a(float paramFloat1, float paramFloat2, float paramFloat3) {
    float f = Math.abs(paramFloat1);
    if (f < paramFloat2)
      return 0.0F; 
    if (f > paramFloat3) {
      if (paramFloat1 <= 0.0F)
        paramFloat3 = -paramFloat3; 
      return paramFloat3;
    } 
    return paramFloat1;
  }
  
  private int a(int paramInt1, int paramInt2, int paramInt3) {
    int i = Math.abs(paramInt1);
    if (i < paramInt2)
      return 0; 
    if (i > paramInt3) {
      if (paramInt1 <= 0)
        paramInt3 = -paramInt3; 
      return paramInt3;
    } 
    return paramInt1;
  }
  
  private int a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    float f1;
    float f2;
    paramInt3 = a(paramInt3, (int)this.n, (int)this.m);
    paramInt4 = a(paramInt4, (int)this.n, (int)this.m);
    int i1 = Math.abs(paramInt1);
    int m = Math.abs(paramInt2);
    int k = Math.abs(paramInt3);
    int i = Math.abs(paramInt4);
    int j = k + i;
    int n = i1 + m;
    if (paramInt3 != 0) {
      f1 = k;
      f2 = j;
    } else {
      f1 = i1;
      f2 = n;
    } 
    float f3 = f1 / f2;
    if (paramInt4 != 0) {
      f1 = i;
      f2 = j;
    } else {
      f1 = m;
      f2 = n;
    } 
    f1 /= f2;
    paramInt1 = b(paramInt1, paramInt3, this.r.a(paramView));
    paramInt2 = b(paramInt2, paramInt4, this.r.b(paramView));
    return (int)(paramInt1 * f3 + paramInt2 * f1);
  }
  
  public static s a(ViewGroup paramViewGroup, float paramFloat, c paramc) {
    s s1 = a(paramViewGroup, paramc);
    s1.b = (int)(s1.b * 1.0F / paramFloat);
    return s1;
  }
  
  public static s a(ViewGroup paramViewGroup, c paramc) {
    return new s(paramViewGroup.getContext(), paramViewGroup, paramc);
  }
  
  private void a(float paramFloat1, float paramFloat2) {
    this.t = true;
    this.r.a(this.s, paramFloat1, paramFloat2);
    this.t = false;
    if (this.a == 1)
      c(0); 
  }
  
  private void a(float paramFloat1, float paramFloat2, int paramInt) {
    int i = 0;
    if (a(paramFloat1, paramFloat2, paramInt, 1))
      i = false | true; 
    int j = i;
    if (a(paramFloat2, paramFloat1, paramInt, 4))
      j = i | 0x4; 
    i = j;
    if (a(paramFloat1, paramFloat2, paramInt, 2))
      i = j | 0x2; 
    j = i;
    if (a(paramFloat2, paramFloat1, paramInt, 8))
      j = i | 0x8; 
    if (j != 0) {
      int[] arrayOfInt = this.i;
      arrayOfInt[paramInt] = arrayOfInt[paramInt] | j;
      this.r.a(j, paramInt);
    } 
  }
  
  private void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int j = paramInt1;
    int i = paramInt2;
    int k = this.s.getLeft();
    int m = this.s.getTop();
    if (paramInt3 != 0) {
      paramInt1 = this.r.a(this.s, paramInt1, paramInt3);
      u.c(this.s, paramInt1 - k);
    } else {
      paramInt1 = j;
    } 
    if (paramInt4 != 0) {
      i = this.r.b(this.s, paramInt2, paramInt4);
      u.d(this.s, i - m);
    } 
    if (paramInt3 != 0 || paramInt4 != 0)
      this.r.a(this.s, paramInt1, i, paramInt1 - k, i - m); 
  }
  
  private boolean a(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2) {
    paramFloat1 = Math.abs(paramFloat1);
    paramFloat2 = Math.abs(paramFloat2);
    int i = this.h[paramInt1];
    boolean bool = false;
    if ((i & paramInt2) == paramInt2 && (this.p & paramInt2) != 0 && (this.j[paramInt1] & paramInt2) != paramInt2 && (this.i[paramInt1] & paramInt2) != paramInt2) {
      i = this.b;
      if (paramFloat1 > i || paramFloat2 > i) {
        if (paramFloat1 < 0.5F * paramFloat2 && this.r.b(paramInt2)) {
          int[] arrayOfInt = this.j;
          arrayOfInt[paramInt1] = arrayOfInt[paramInt1] | paramInt2;
          return false;
        } 
        boolean bool1 = bool;
        if ((this.i[paramInt1] & paramInt2) == 0) {
          bool1 = bool;
          if (paramFloat1 > this.b)
            bool1 = true; 
        } 
        return bool1;
      } 
    } 
    return false;
  }
  
  private boolean a(View paramView, float paramFloat1, float paramFloat2) {
    int i;
    boolean bool1;
    boolean bool4 = false;
    boolean bool2 = false;
    boolean bool3 = false;
    if (paramView == null)
      return false; 
    if (this.r.a(paramView) > 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (this.r.b(paramView) > 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (i && bool1) {
      i = this.b;
      bool2 = bool3;
      if (paramFloat1 * paramFloat1 + paramFloat2 * paramFloat2 > (i * i))
        bool2 = true; 
      return bool2;
    } 
    if (i != 0) {
      bool2 = bool4;
      if (Math.abs(paramFloat1) > this.b)
        bool2 = true; 
      return bool2;
    } 
    if (bool1) {
      if (Math.abs(paramFloat2) > this.b)
        bool2 = true; 
      return bool2;
    } 
    return false;
  }
  
  private float b(float paramFloat) {
    return (float)Math.sin(((paramFloat - 0.5F) * 0.47123894F));
  }
  
  private int b(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt1 == 0)
      return 0; 
    int i = this.u.getWidth();
    int j = i / 2;
    float f3 = Math.min(1.0F, Math.abs(paramInt1) / i);
    float f2 = j;
    float f1 = j;
    f3 = b(f3);
    paramInt2 = Math.abs(paramInt2);
    if (paramInt2 > 0) {
      paramInt1 = Math.round(Math.abs((f2 + f1 * f3) / paramInt2) * 1000.0F) * 4;
    } else {
      paramInt1 = (int)((1.0F + Math.abs(paramInt1) / paramInt3) * 256.0F);
    } 
    return Math.min(paramInt1, 600);
  }
  
  private void b(float paramFloat1, float paramFloat2, int paramInt) {
    f(paramInt);
    float[] arrayOfFloat = this.d;
    this.f[paramInt] = paramFloat1;
    arrayOfFloat[paramInt] = paramFloat1;
    arrayOfFloat = this.e;
    this.g[paramInt] = paramFloat2;
    arrayOfFloat[paramInt] = paramFloat2;
    this.h[paramInt] = e((int)paramFloat1, (int)paramFloat2);
    this.k |= 1 << paramInt;
  }
  
  private boolean b(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int j = this.s.getLeft();
    int i = this.s.getTop();
    paramInt1 -= j;
    paramInt2 -= i;
    if (paramInt1 == 0 && paramInt2 == 0) {
      this.q.abortAnimation();
      c(0);
      return false;
    } 
    paramInt3 = a(this.s, paramInt1, paramInt2, paramInt3, paramInt4);
    this.q.startScroll(j, i, paramInt1, paramInt2, paramInt3);
    c(2);
    return true;
  }
  
  private void c(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getPointerCount();
    for (byte b = 0; b < i; b++) {
      int j = paramMotionEvent.getPointerId(b);
      if (g(j)) {
        float f1 = paramMotionEvent.getX(b);
        float f2 = paramMotionEvent.getY(b);
        this.f[j] = f1;
        this.g[j] = f2;
      } 
    } 
  }
  
  private int e(int paramInt1, int paramInt2) {
    int i = 0;
    if (paramInt1 < this.u.getLeft() + this.o)
      i = false | true; 
    int j = i;
    if (paramInt2 < this.u.getTop() + this.o)
      j = i | 0x4; 
    i = j;
    if (paramInt1 > this.u.getRight() - this.o)
      i = j | 0x2; 
    paramInt1 = i;
    if (paramInt2 > this.u.getBottom() - this.o)
      paramInt1 = i | 0x8; 
    return paramInt1;
  }
  
  private void e(int paramInt) {
    if (this.d == null || !b(paramInt))
      return; 
    this.d[paramInt] = 0.0F;
    this.e[paramInt] = 0.0F;
    this.f[paramInt] = 0.0F;
    this.g[paramInt] = 0.0F;
    this.h[paramInt] = 0;
    this.i[paramInt] = 0;
    this.j[paramInt] = 0;
    this.k &= 1 << paramInt ^ 0xFFFFFFFF;
  }
  
  private void f() {
    float[] arrayOfFloat = this.d;
    if (arrayOfFloat == null)
      return; 
    Arrays.fill(arrayOfFloat, 0.0F);
    Arrays.fill(this.e, 0.0F);
    Arrays.fill(this.f, 0.0F);
    Arrays.fill(this.g, 0.0F);
    Arrays.fill(this.h, 0);
    Arrays.fill(this.i, 0);
    Arrays.fill(this.j, 0);
    this.k = 0;
  }
  
  private void f(int paramInt) {
    float[] arrayOfFloat = this.d;
    if (arrayOfFloat == null || arrayOfFloat.length <= paramInt) {
      float[] arrayOfFloat3 = new float[paramInt + 1];
      arrayOfFloat = new float[paramInt + 1];
      float[] arrayOfFloat2 = new float[paramInt + 1];
      float[] arrayOfFloat1 = new float[paramInt + 1];
      int[] arrayOfInt3 = new int[paramInt + 1];
      int[] arrayOfInt2 = new int[paramInt + 1];
      int[] arrayOfInt1 = new int[paramInt + 1];
      float[] arrayOfFloat4 = this.d;
      if (arrayOfFloat4 != null) {
        System.arraycopy(arrayOfFloat4, 0, arrayOfFloat3, 0, arrayOfFloat4.length);
        arrayOfFloat4 = this.e;
        System.arraycopy(arrayOfFloat4, 0, arrayOfFloat, 0, arrayOfFloat4.length);
        arrayOfFloat4 = this.f;
        System.arraycopy(arrayOfFloat4, 0, arrayOfFloat2, 0, arrayOfFloat4.length);
        arrayOfFloat4 = this.g;
        System.arraycopy(arrayOfFloat4, 0, arrayOfFloat1, 0, arrayOfFloat4.length);
        int[] arrayOfInt = this.h;
        System.arraycopy(arrayOfInt, 0, arrayOfInt3, 0, arrayOfInt.length);
        arrayOfInt = this.i;
        System.arraycopy(arrayOfInt, 0, arrayOfInt2, 0, arrayOfInt.length);
        arrayOfInt = this.j;
        System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
      } 
      this.d = arrayOfFloat3;
      this.e = arrayOfFloat;
      this.f = arrayOfFloat2;
      this.g = arrayOfFloat1;
      this.h = arrayOfInt3;
      this.i = arrayOfInt2;
      this.j = arrayOfInt1;
    } 
  }
  
  private void g() {
    this.l.computeCurrentVelocity(1000, this.m);
    a(a(this.l.getXVelocity(this.c), this.n, this.m), a(this.l.getYVelocity(this.c), this.n, this.m));
  }
  
  private boolean g(int paramInt) {
    if (!b(paramInt)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Ignoring pointerId=");
      stringBuilder.append(paramInt);
      stringBuilder.append(" because ACTION_DOWN was not received ");
      stringBuilder.append("for this pointer before ACTION_MOVE. It likely happened because ");
      stringBuilder.append(" ViewDragHelper did not receive all the events in the event stream.");
      Log.e("ViewDragHelper", stringBuilder.toString());
      return false;
    } 
    return true;
  }
  
  public void a() {
    this.c = -1;
    f();
    VelocityTracker velocityTracker = this.l;
    if (velocityTracker != null) {
      velocityTracker.recycle();
      this.l = null;
    } 
  }
  
  public void a(float paramFloat) {
    this.n = paramFloat;
  }
  
  public void a(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    int j = paramMotionEvent.getActionIndex();
    if (i == 0)
      a(); 
    if (this.l == null)
      this.l = VelocityTracker.obtain(); 
    this.l.addMovement(paramMotionEvent);
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i != 5) {
              if (i == 6) {
                int k = paramMotionEvent.getPointerId(j);
                if (this.a == 1 && k == this.c) {
                  byte b = -1;
                  int m = paramMotionEvent.getPointerCount();
                  i = 0;
                  while (true) {
                    j = b;
                    if (i < m) {
                      j = paramMotionEvent.getPointerId(i);
                      if (j != this.c) {
                        float f1 = paramMotionEvent.getX(i);
                        float f2 = paramMotionEvent.getY(i);
                        View view2 = b((int)f1, (int)f2);
                        View view1 = this.s;
                        if (view2 == view1 && b(view1, j)) {
                          j = this.c;
                          break;
                        } 
                      } 
                      i++;
                      continue;
                    } 
                    break;
                  } 
                  if (j == -1)
                    g(); 
                } 
                e(k);
              } 
            } else {
              i = paramMotionEvent.getPointerId(j);
              float f2 = paramMotionEvent.getX(j);
              float f1 = paramMotionEvent.getY(j);
              b(f2, f1, i);
              if (this.a == 0) {
                b(b((int)f2, (int)f1), i);
                int k = this.h[i];
                j = this.p;
                if ((k & j) != 0)
                  this.r.b(j & k, i); 
              } else if (c((int)f2, (int)f1)) {
                b(this.s, i);
              } 
            } 
          } else {
            if (this.a == 1)
              a(0.0F, 0.0F); 
            a();
          } 
        } else if (this.a == 1) {
          if (g(this.c)) {
            i = paramMotionEvent.findPointerIndex(this.c);
            float f1 = paramMotionEvent.getX(i);
            float f2 = paramMotionEvent.getY(i);
            float[] arrayOfFloat = this.f;
            j = this.c;
            i = (int)(f1 - arrayOfFloat[j]);
            j = (int)(f2 - this.g[j]);
            a(this.s.getLeft() + i, this.s.getTop() + j, i, j);
            c(paramMotionEvent);
          } 
        } else {
          j = paramMotionEvent.getPointerCount();
          for (i = 0; i < j; i++) {
            int k = paramMotionEvent.getPointerId(i);
            if (g(k)) {
              float f3 = paramMotionEvent.getX(i);
              float f1 = paramMotionEvent.getY(i);
              float f4 = f3 - this.d[k];
              float f2 = f1 - this.e[k];
              a(f4, f2, k);
              if (this.a == 1)
                break; 
              View view = b((int)f3, (int)f1);
              if (a(view, f4, f2) && b(view, k))
                break; 
            } 
          } 
          c(paramMotionEvent);
        } 
      } else {
        if (this.a == 1)
          g(); 
        a();
      } 
    } else {
      float f1 = paramMotionEvent.getX();
      float f2 = paramMotionEvent.getY();
      i = paramMotionEvent.getPointerId(0);
      View view = b((int)f1, (int)f2);
      b(f1, f2, i);
      b(view, i);
      j = this.h[i];
      int k = this.p;
      if ((j & k) != 0)
        this.r.b(k & j, i); 
    } 
  }
  
  public void a(View paramView, int paramInt) {
    if (paramView.getParent() == this.u) {
      this.s = paramView;
      this.c = paramInt;
      this.r.a(paramView, paramInt);
      c(1);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("captureChildView: parameter must be a descendant of the ViewDragHelper's tracked parent view (");
    stringBuilder.append(this.u);
    stringBuilder.append(")");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean a(int paramInt) {
    int i = this.d.length;
    for (byte b = 0; b < i; b++) {
      if (a(paramInt, b))
        return true; 
    } 
    return false;
  }
  
  public boolean a(int paramInt1, int paramInt2) {
    boolean bool1;
    boolean bool = b(paramInt2);
    boolean bool4 = false;
    boolean bool2 = false;
    boolean bool3 = false;
    if (!bool)
      return false; 
    if ((paramInt1 & 0x1) == 1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if ((paramInt1 & 0x2) == 2) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    float f1 = this.f[paramInt2] - this.d[paramInt2];
    float f2 = this.g[paramInt2] - this.e[paramInt2];
    if (bool1 && paramInt1 != 0) {
      paramInt1 = this.b;
      bool2 = bool3;
      if (f1 * f1 + f2 * f2 > (paramInt1 * paramInt1))
        bool2 = true; 
      return bool2;
    } 
    if (bool1) {
      bool2 = bool4;
      if (Math.abs(f1) > this.b)
        bool2 = true; 
      return bool2;
    } 
    if (paramInt1 != 0) {
      if (Math.abs(f2) > this.b)
        bool2 = true; 
      return bool2;
    } 
    return false;
  }
  
  public boolean a(View paramView, int paramInt1, int paramInt2) {
    boolean bool = false;
    if (paramView == null)
      return false; 
    if (paramInt1 >= paramView.getLeft() && paramInt1 < paramView.getRight() && paramInt2 >= paramView.getTop() && paramInt2 < paramView.getBottom())
      bool = true; 
    return bool;
  }
  
  public boolean a(boolean paramBoolean) {
    int i = this.a;
    boolean bool = false;
    if (i == 2) {
      boolean bool2 = this.q.computeScrollOffset();
      int j = this.q.getCurrX();
      int k = this.q.getCurrY();
      i = j - this.s.getLeft();
      int m = k - this.s.getTop();
      if (i != 0)
        u.c(this.s, i); 
      if (m != 0)
        u.d(this.s, m); 
      if (i != 0 || m != 0)
        this.r.a(this.s, j, k, i, m); 
      boolean bool1 = bool2;
      if (bool2) {
        bool1 = bool2;
        if (j == this.q.getFinalX()) {
          bool1 = bool2;
          if (k == this.q.getFinalY()) {
            this.q.abortAnimation();
            bool1 = false;
          } 
        } 
      } 
      if (!bool1)
        if (paramBoolean) {
          this.u.post(this.v);
        } else {
          c(0);
        }  
    } 
    paramBoolean = bool;
    if (this.a == 2)
      paramBoolean = true; 
    return paramBoolean;
  }
  
  public View b() {
    return this.s;
  }
  
  public View b(int paramInt1, int paramInt2) {
    for (int i = this.u.getChildCount() - 1; i >= 0; i--) {
      ViewGroup viewGroup = this.u;
      this.r.a(i);
      View view = viewGroup.getChildAt(i);
      if (paramInt1 >= view.getLeft() && paramInt1 < view.getRight() && paramInt2 >= view.getTop() && paramInt2 < view.getBottom())
        return view; 
    } 
    return null;
  }
  
  public boolean b(int paramInt) {
    int i = this.k;
    boolean bool = true;
    if ((i & 1 << paramInt) == 0)
      bool = false; 
    return bool;
  }
  
  public boolean b(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore #8
    //   6: aload_1
    //   7: invokevirtual getActionIndex : ()I
    //   10: istore #7
    //   12: iload #8
    //   14: ifne -> 21
    //   17: aload_0
    //   18: invokevirtual a : ()V
    //   21: aload_0
    //   22: getfield l : Landroid/view/VelocityTracker;
    //   25: ifnonnull -> 35
    //   28: aload_0
    //   29: invokestatic obtain : ()Landroid/view/VelocityTracker;
    //   32: putfield l : Landroid/view/VelocityTracker;
    //   35: aload_0
    //   36: getfield l : Landroid/view/VelocityTracker;
    //   39: aload_1
    //   40: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   43: iload #8
    //   45: ifeq -> 530
    //   48: iload #8
    //   50: iconst_1
    //   51: if_icmpeq -> 523
    //   54: iload #8
    //   56: iconst_2
    //   57: if_icmpeq -> 216
    //   60: iload #8
    //   62: iconst_3
    //   63: if_icmpeq -> 213
    //   66: iload #8
    //   68: iconst_5
    //   69: if_icmpeq -> 95
    //   72: iload #8
    //   74: bipush #6
    //   76: if_icmpeq -> 82
    //   79: goto -> 625
    //   82: aload_0
    //   83: aload_1
    //   84: iload #7
    //   86: invokevirtual getPointerId : (I)I
    //   89: invokespecial e : (I)V
    //   92: goto -> 625
    //   95: aload_1
    //   96: iload #7
    //   98: invokevirtual getPointerId : (I)I
    //   101: istore #6
    //   103: aload_1
    //   104: iload #7
    //   106: invokevirtual getX : (I)F
    //   109: fstore_3
    //   110: aload_1
    //   111: iload #7
    //   113: invokevirtual getY : (I)F
    //   116: fstore_2
    //   117: aload_0
    //   118: fload_3
    //   119: fload_2
    //   120: iload #6
    //   122: invokespecial b : (FFI)V
    //   125: aload_0
    //   126: getfield a : I
    //   129: istore #7
    //   131: iload #7
    //   133: ifne -> 176
    //   136: aload_0
    //   137: getfield h : [I
    //   140: iload #6
    //   142: iaload
    //   143: istore #8
    //   145: aload_0
    //   146: getfield p : I
    //   149: istore #7
    //   151: iload #8
    //   153: iload #7
    //   155: iand
    //   156: ifeq -> 210
    //   159: aload_0
    //   160: getfield r : Landroid/support/v4/widget/s$c;
    //   163: iload #7
    //   165: iload #8
    //   167: iand
    //   168: iload #6
    //   170: invokevirtual b : (II)V
    //   173: goto -> 210
    //   176: iload #7
    //   178: iconst_2
    //   179: if_icmpne -> 210
    //   182: aload_0
    //   183: fload_3
    //   184: f2i
    //   185: fload_2
    //   186: f2i
    //   187: invokevirtual b : (II)Landroid/view/View;
    //   190: astore_1
    //   191: aload_1
    //   192: aload_0
    //   193: getfield s : Landroid/view/View;
    //   196: if_acmpne -> 207
    //   199: aload_0
    //   200: aload_1
    //   201: iload #6
    //   203: invokevirtual b : (Landroid/view/View;I)Z
    //   206: pop
    //   207: goto -> 625
    //   210: goto -> 625
    //   213: goto -> 523
    //   216: aload_0
    //   217: getfield d : [F
    //   220: ifnull -> 520
    //   223: aload_0
    //   224: getfield e : [F
    //   227: ifnonnull -> 233
    //   230: goto -> 625
    //   233: aload_1
    //   234: invokevirtual getPointerCount : ()I
    //   237: istore #6
    //   239: iconst_0
    //   240: istore #9
    //   242: iload #9
    //   244: iload #6
    //   246: if_icmpge -> 512
    //   249: aload_1
    //   250: iload #9
    //   252: invokevirtual getPointerId : (I)I
    //   255: istore #11
    //   257: aload_0
    //   258: iload #11
    //   260: invokespecial g : (I)Z
    //   263: ifne -> 269
    //   266: goto -> 506
    //   269: aload_1
    //   270: iload #9
    //   272: invokevirtual getX : (I)F
    //   275: fstore #4
    //   277: aload_1
    //   278: iload #9
    //   280: invokevirtual getY : (I)F
    //   283: fstore_2
    //   284: fload #4
    //   286: aload_0
    //   287: getfield d : [F
    //   290: iload #11
    //   292: faload
    //   293: fsub
    //   294: fstore_3
    //   295: fload_2
    //   296: aload_0
    //   297: getfield e : [F
    //   300: iload #11
    //   302: faload
    //   303: fsub
    //   304: fstore #5
    //   306: aload_0
    //   307: fload #4
    //   309: f2i
    //   310: fload_2
    //   311: f2i
    //   312: invokevirtual b : (II)Landroid/view/View;
    //   315: astore #19
    //   317: aload #19
    //   319: ifnull -> 340
    //   322: aload_0
    //   323: aload #19
    //   325: fload_3
    //   326: fload #5
    //   328: invokespecial a : (Landroid/view/View;FF)Z
    //   331: ifeq -> 340
    //   334: iconst_1
    //   335: istore #10
    //   337: goto -> 343
    //   340: iconst_0
    //   341: istore #10
    //   343: iload #10
    //   345: ifeq -> 467
    //   348: aload #19
    //   350: invokevirtual getLeft : ()I
    //   353: istore #12
    //   355: fload_3
    //   356: f2i
    //   357: istore #13
    //   359: aload_0
    //   360: getfield r : Landroid/support/v4/widget/s$c;
    //   363: aload #19
    //   365: iload #13
    //   367: iload #12
    //   369: iadd
    //   370: fload_3
    //   371: f2i
    //   372: invokevirtual a : (Landroid/view/View;II)I
    //   375: istore #13
    //   377: aload #19
    //   379: invokevirtual getTop : ()I
    //   382: istore #14
    //   384: fload #5
    //   386: f2i
    //   387: istore #15
    //   389: aload_0
    //   390: getfield r : Landroid/support/v4/widget/s$c;
    //   393: aload #19
    //   395: iload #15
    //   397: iload #14
    //   399: iadd
    //   400: fload #5
    //   402: f2i
    //   403: invokevirtual b : (Landroid/view/View;II)I
    //   406: istore #16
    //   408: aload_0
    //   409: getfield r : Landroid/support/v4/widget/s$c;
    //   412: aload #19
    //   414: invokevirtual a : (Landroid/view/View;)I
    //   417: istore #15
    //   419: aload_0
    //   420: getfield r : Landroid/support/v4/widget/s$c;
    //   423: aload #19
    //   425: invokevirtual b : (Landroid/view/View;)I
    //   428: istore #17
    //   430: iload #15
    //   432: ifeq -> 447
    //   435: iload #15
    //   437: ifle -> 467
    //   440: iload #13
    //   442: iload #12
    //   444: if_icmpne -> 467
    //   447: iload #17
    //   449: ifeq -> 512
    //   452: iload #17
    //   454: ifle -> 467
    //   457: iload #16
    //   459: iload #14
    //   461: if_icmpne -> 467
    //   464: goto -> 512
    //   467: aload_0
    //   468: fload_3
    //   469: fload #5
    //   471: iload #11
    //   473: invokespecial a : (FFI)V
    //   476: aload_0
    //   477: getfield a : I
    //   480: iconst_1
    //   481: if_icmpne -> 487
    //   484: goto -> 512
    //   487: iload #10
    //   489: ifeq -> 506
    //   492: aload_0
    //   493: aload #19
    //   495: iload #11
    //   497: invokevirtual b : (Landroid/view/View;I)Z
    //   500: ifeq -> 506
    //   503: goto -> 512
    //   506: iinc #9, 1
    //   509: goto -> 242
    //   512: aload_0
    //   513: aload_1
    //   514: invokespecial c : (Landroid/view/MotionEvent;)V
    //   517: goto -> 625
    //   520: goto -> 625
    //   523: aload_0
    //   524: invokevirtual a : ()V
    //   527: goto -> 625
    //   530: aload_1
    //   531: invokevirtual getX : ()F
    //   534: fstore_3
    //   535: aload_1
    //   536: invokevirtual getY : ()F
    //   539: fstore_2
    //   540: aload_1
    //   541: iconst_0
    //   542: invokevirtual getPointerId : (I)I
    //   545: istore #8
    //   547: aload_0
    //   548: fload_3
    //   549: fload_2
    //   550: iload #8
    //   552: invokespecial b : (FFI)V
    //   555: aload_0
    //   556: fload_3
    //   557: f2i
    //   558: fload_2
    //   559: f2i
    //   560: invokevirtual b : (II)Landroid/view/View;
    //   563: astore_1
    //   564: aload_1
    //   565: aload_0
    //   566: getfield s : Landroid/view/View;
    //   569: if_acmpne -> 588
    //   572: aload_0
    //   573: getfield a : I
    //   576: iconst_2
    //   577: if_icmpne -> 588
    //   580: aload_0
    //   581: aload_1
    //   582: iload #8
    //   584: invokevirtual b : (Landroid/view/View;I)Z
    //   587: pop
    //   588: aload_0
    //   589: getfield h : [I
    //   592: iload #8
    //   594: iaload
    //   595: istore #6
    //   597: aload_0
    //   598: getfield p : I
    //   601: istore #7
    //   603: iload #6
    //   605: iload #7
    //   607: iand
    //   608: ifeq -> 625
    //   611: aload_0
    //   612: getfield r : Landroid/support/v4/widget/s$c;
    //   615: iload #7
    //   617: iload #6
    //   619: iand
    //   620: iload #8
    //   622: invokevirtual b : (II)V
    //   625: aload_0
    //   626: getfield a : I
    //   629: istore #6
    //   631: iconst_1
    //   632: istore #18
    //   634: iload #6
    //   636: iconst_1
    //   637: if_icmpne -> 643
    //   640: goto -> 646
    //   643: iconst_0
    //   644: istore #18
    //   646: iload #18
    //   648: ireturn
  }
  
  boolean b(View paramView, int paramInt) {
    if (paramView == this.s && this.c == paramInt)
      return true; 
    if (paramView != null && this.r.b(paramView, paramInt)) {
      this.c = paramInt;
      a(paramView, paramInt);
      return true;
    } 
    return false;
  }
  
  public boolean b(View paramView, int paramInt1, int paramInt2) {
    this.s = paramView;
    this.c = -1;
    boolean bool = b(paramInt1, paramInt2, 0, 0);
    if (!bool && this.a == 0 && this.s != null)
      this.s = null; 
    return bool;
  }
  
  public int c() {
    return this.o;
  }
  
  void c(int paramInt) {
    this.u.removeCallbacks(this.v);
    if (this.a != paramInt) {
      this.a = paramInt;
      this.r.c(paramInt);
      if (this.a == 0)
        this.s = null; 
    } 
  }
  
  public boolean c(int paramInt1, int paramInt2) {
    return a(this.s, paramInt1, paramInt2);
  }
  
  public int d() {
    return this.b;
  }
  
  public void d(int paramInt) {
    this.p = paramInt;
  }
  
  public boolean d(int paramInt1, int paramInt2) {
    if (this.t)
      return b(paramInt1, paramInt2, (int)this.l.getXVelocity(this.c), (int)this.l.getYVelocity(this.c)); 
    throw new IllegalStateException("Cannot settleCapturedViewAt outside of a call to Callback#onViewReleased");
  }
  
  public int e() {
    return this.a;
  }
  
  static final class a implements Interpolator {
    public float getInterpolation(float param1Float) {
      param1Float--;
      return param1Float * param1Float * param1Float * param1Float * param1Float + 1.0F;
    }
  }
  
  class b implements Runnable {
    final s c;
    
    b(s this$0) {}
    
    public void run() {
      this.c.c(0);
    }
  }
  
  public static abstract class c {
    public int a(int param1Int) {
      return param1Int;
    }
    
    public int a(View param1View) {
      return 0;
    }
    
    public abstract int a(View param1View, int param1Int1, int param1Int2);
    
    public void a(int param1Int1, int param1Int2) {}
    
    public abstract void a(View param1View, float param1Float1, float param1Float2);
    
    public void a(View param1View, int param1Int) {}
    
    public abstract void a(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4);
    
    public int b(View param1View) {
      return 0;
    }
    
    public abstract int b(View param1View, int param1Int1, int param1Int2);
    
    public void b(int param1Int1, int param1Int2) {}
    
    public boolean b(int param1Int) {
      return false;
    }
    
    public abstract boolean b(View param1View, int param1Int);
    
    public abstract void c(int param1Int);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\widget\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */