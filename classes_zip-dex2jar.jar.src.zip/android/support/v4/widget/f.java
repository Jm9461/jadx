package android.support.v4.widget;

import a.b.g.g.j;
import a.b.g.g.k;
import a.b.g.g.n;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public final class f<T> {
  private final j<ArrayList<T>> a = (j<ArrayList<T>>)new k(10);
  
  private final n<T, ArrayList<T>> b = new n();
  
  private final ArrayList<T> c = new ArrayList<T>();
  
  private final HashSet<T> d = new HashSet<T>();
  
  private void a(T paramT, ArrayList<T> paramArrayList, HashSet<T> paramHashSet) {
    if (paramArrayList.contains(paramT))
      return; 
    if (!paramHashSet.contains(paramT)) {
      paramHashSet.add(paramT);
      ArrayList<T> arrayList = (ArrayList)this.b.get(paramT);
      if (arrayList != null) {
        byte b = 0;
        int i = arrayList.size();
        while (b < i) {
          a(arrayList.get(b), paramArrayList, paramHashSet);
          b++;
        } 
      } 
      paramHashSet.remove(paramT);
      paramArrayList.add(paramT);
      return;
    } 
    RuntimeException runtimeException = new RuntimeException("This graph contains cyclic dependencies");
    throw runtimeException;
  }
  
  private void a(ArrayList<T> paramArrayList) {
    paramArrayList.clear();
    this.a.a(paramArrayList);
  }
  
  private ArrayList<T> c() {
    ArrayList<T> arrayList2 = (ArrayList)this.a.a();
    ArrayList<T> arrayList1 = arrayList2;
    if (arrayList2 == null)
      arrayList1 = new ArrayList(); 
    return arrayList1;
  }
  
  public void a() {
    byte b = 0;
    int i = this.b.size();
    while (b < i) {
      ArrayList<T> arrayList = (ArrayList)this.b.d(b);
      if (arrayList != null)
        a(arrayList); 
      b++;
    } 
    this.b.clear();
  }
  
  public void a(T paramT) {
    if (!this.b.containsKey(paramT))
      this.b.put(paramT, null); 
  }
  
  public void a(T paramT1, T paramT2) {
    if (this.b.containsKey(paramT1) && this.b.containsKey(paramT2)) {
      ArrayList<T> arrayList2 = (ArrayList)this.b.get(paramT1);
      ArrayList<T> arrayList1 = arrayList2;
      if (arrayList2 == null) {
        arrayList1 = c();
        this.b.put(paramT1, arrayList1);
      } 
      arrayList1.add(paramT2);
      return;
    } 
    throw new IllegalArgumentException("All nodes must be present in the graph before being added as an edge");
  }
  
  public ArrayList<T> b() {
    this.c.clear();
    this.d.clear();
    byte b = 0;
    int i = this.b.size();
    while (b < i) {
      a((T)this.b.b(b), this.c, this.d);
      b++;
    } 
    return this.c;
  }
  
  public boolean b(T paramT) {
    return this.b.containsKey(paramT);
  }
  
  public List c(T paramT) {
    return (List)this.b.get(paramT);
  }
  
  public List<T> d(T paramT) {
    ArrayList<Object> arrayList = null;
    byte b = 0;
    int i = this.b.size();
    while (b < i) {
      ArrayList arrayList2 = (ArrayList)this.b.d(b);
      ArrayList<Object> arrayList1 = arrayList;
      if (arrayList2 != null) {
        arrayList1 = arrayList;
        if (arrayList2.contains(paramT)) {
          arrayList1 = arrayList;
          if (arrayList == null)
            arrayList1 = new ArrayList(); 
          arrayList1.add(this.b.b(b));
        } 
      } 
      b++;
      arrayList = arrayList1;
    } 
    return arrayList;
  }
  
  public boolean e(T paramT) {
    byte b = 0;
    int i = this.b.size();
    while (b < i) {
      ArrayList arrayList = (ArrayList)this.b.d(b);
      if (arrayList != null && arrayList.contains(paramT))
        return true; 
      b++;
    } 
    return false;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\widget\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */