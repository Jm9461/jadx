package android.support.v4.content;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public final class c {
  private static final Object f = new Object();
  
  private static c g;
  
  private final Context a;
  
  private final HashMap<BroadcastReceiver, ArrayList<c>> b = new HashMap<BroadcastReceiver, ArrayList<c>>();
  
  private final HashMap<String, ArrayList<c>> c = new HashMap<String, ArrayList<c>>();
  
  private final ArrayList<b> d = new ArrayList<b>();
  
  private final Handler e;
  
  private c(Context paramContext) {
    this.a = paramContext;
    this.e = new a(this, paramContext.getMainLooper());
  }
  
  public static c a(Context paramContext) {
    synchronized (f) {
      if (g == null) {
        c c1 = new c();
        this(paramContext.getApplicationContext());
        g = c1;
      } 
      return g;
    } 
  }
  
  void a() {
    while (true) {
      Exception exception;
      c c1;
      HashMap<BroadcastReceiver, ArrayList<c>> hashMap = this.b;
      /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap<[ObjectType{android/content/BroadcastReceiver}, ObjectType{java/util/ArrayList<InnerObjectType{ObjectType{android/support/v4/content/c}.Landroid/support/v4/content/c$c;}>}]>}, name=null} */
      try {
        int i = this.d.size();
        if (i <= 0) {
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap<[ObjectType{android/content/BroadcastReceiver}, ObjectType{java/util/ArrayList<InnerObjectType{ObjectType{android/support/v4/content/c}.Landroid/support/v4/content/c$c;}>}]>}, name=null} */
          return;
        } 
        b[] arrayOfB = new b[i];
        try {
          this.d.toArray(arrayOfB);
          this.d.clear();
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap<[ObjectType{android/content/BroadcastReceiver}, ObjectType{java/util/ArrayList<InnerObjectType{ObjectType{android/support/v4/content/c}.Landroid/support/v4/content/c$c;}>}]>}, name=null} */
          for (i = 0; i < arrayOfB.length; i++) {
            b b1 = arrayOfB[i];
            int j = b1.b.size();
            for (byte b = 0; b < j; b++) {
              c1 = b1.b.get(b);
              if (!c1.d)
                c1.b.onReceive(this.a, b1.a); 
            } 
          } 
          continue;
        } finally {}
      } finally {}
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=InnerObjectType{ObjectType{android/support/v4/content/c}.Landroid/support/v4/content/c$c;}, name=null} */
      throw exception;
    } 
  }
  
  public void a(BroadcastReceiver paramBroadcastReceiver) {
    synchronized (this.b) {
      ArrayList<c> arrayList = this.b.remove(paramBroadcastReceiver);
      if (arrayList == null)
        return; 
      for (int i = arrayList.size() - 1; i >= 0; i--) {
        c c1 = arrayList.get(i);
        c1.d = true;
        for (byte b = 0; b < c1.a.countActions(); b++) {
          String str = c1.a.getAction(b);
          ArrayList<c> arrayList1 = this.c.get(str);
          if (arrayList1 != null) {
            for (int j = arrayList1.size() - 1; j >= 0; j--) {
              c c2 = arrayList1.get(j);
              if (c2.b == paramBroadcastReceiver) {
                c2.d = true;
                arrayList1.remove(j);
              } 
            } 
            if (arrayList1.size() <= 0)
              this.c.remove(str); 
          } 
        } 
      } 
      return;
    } 
  }
  
  public void a(BroadcastReceiver paramBroadcastReceiver, IntentFilter paramIntentFilter) {
    synchronized (this.b) {
      c c1 = new c();
      this(paramIntentFilter, paramBroadcastReceiver);
      ArrayList<c> arrayList2 = this.b.get(paramBroadcastReceiver);
      ArrayList<c> arrayList1 = arrayList2;
      if (arrayList2 == null) {
        arrayList1 = new ArrayList();
        this(1);
        this.b.put(paramBroadcastReceiver, arrayList1);
      } 
      arrayList1.add(c1);
      for (byte b = 0; b < paramIntentFilter.countActions(); b++) {
        String str = paramIntentFilter.getAction(b);
        arrayList1 = this.c.get(str);
        ArrayList<c> arrayList = arrayList1;
        if (arrayList1 == null) {
          arrayList = new ArrayList<c>();
          this(1);
          this.c.put(str, arrayList);
        } 
        arrayList.add(c1);
      } 
      return;
    } 
  }
  
  public boolean a(Intent paramIntent) {
    synchronized (this.b) {
      byte b;
      String str2 = paramIntent.getAction();
      String str1 = paramIntent.resolveTypeIfNeeded(this.a.getContentResolver());
      Uri uri = paramIntent.getData();
      String str3 = paramIntent.getScheme();
      Set set = paramIntent.getCategories();
      if ((paramIntent.getFlags() & 0x8) != 0) {
        b = 1;
      } else {
        b = 0;
      } 
      if (b) {
        StringBuilder stringBuilder = new StringBuilder();
        this();
        stringBuilder.append("Resolving type ");
        stringBuilder.append(str1);
        stringBuilder.append(" scheme ");
        stringBuilder.append(str3);
        stringBuilder.append(" of intent ");
        stringBuilder.append(paramIntent);
        Log.v("LocalBroadcastManager", stringBuilder.toString());
      } 
      ArrayList<c> arrayList = this.c.get(paramIntent.getAction());
      if (arrayList != null) {
        ArrayList<c> arrayList1;
        if (b) {
          StringBuilder stringBuilder = new StringBuilder();
          this();
          stringBuilder.append("Action list: ");
          stringBuilder.append(arrayList);
          Log.v("LocalBroadcastManager", stringBuilder.toString());
        } 
        IntentFilter intentFilter = null;
        for (byte b1 = 0; b1 < arrayList.size(); b1++) {
          c c1 = arrayList.get(b1);
          if (b) {
            StringBuilder stringBuilder = new StringBuilder();
            this();
            stringBuilder.append("Matching against filter ");
            stringBuilder.append(c1.a);
            Log.v("LocalBroadcastManager", stringBuilder.toString());
          } 
          if (c1.c) {
            if (b)
              Log.v("LocalBroadcastManager", "  Filter's target already added"); 
          } else {
            IntentFilter intentFilter1 = c1.a;
            IntentFilter intentFilter2 = intentFilter;
            int i = intentFilter1.match(str2, str1, str3, uri, set, "LocalBroadcastManager");
            if (i >= 0) {
              ArrayList<c> arrayList2;
              if (b) {
                StringBuilder stringBuilder = new StringBuilder();
                this();
                stringBuilder.append("  Filter matched!  match=0x");
                stringBuilder.append(Integer.toHexString(i));
                Log.v("LocalBroadcastManager", stringBuilder.toString());
              } 
              intentFilter1 = intentFilter2;
              if (intentFilter2 == null) {
                arrayList2 = new ArrayList();
                this();
              } 
              arrayList2.add(c1);
              c1.c = true;
              arrayList1 = arrayList2;
            } else if (b) {
              String str;
              if (i != -4) {
                if (i != -3) {
                  if (i != -2) {
                    if (i != -1) {
                      str = "unknown reason";
                    } else {
                      str = "type";
                    } 
                  } else {
                    str = "data";
                  } 
                } else {
                  str = "action";
                } 
              } else {
                str = "category";
              } 
              StringBuilder stringBuilder = new StringBuilder();
              this();
              stringBuilder.append("  Filter did not match: ");
              stringBuilder.append(str);
              Log.v("LocalBroadcastManager", stringBuilder.toString());
            } 
          } 
        } 
        if (arrayList1 != null) {
          for (b = 0; b < arrayList1.size(); b++)
            ((c)arrayList1.get(b)).c = false; 
          ArrayList<b> arrayList2 = this.d;
          b b2 = new b();
          this(paramIntent, arrayList1);
          arrayList2.add(b2);
          if (!this.e.hasMessages(1))
            this.e.sendEmptyMessage(1); 
          return true;
        } 
      } 
      return false;
    } 
  }
  
  class a extends Handler {
    final c a;
    
    a(c this$0, Looper param1Looper) {
      super(param1Looper);
    }
    
    public void handleMessage(Message param1Message) {
      if (param1Message.what != 1) {
        super.handleMessage(param1Message);
      } else {
        this.a.a();
      } 
    }
  }
  
  private static final class b {
    final Intent a;
    
    final ArrayList<c.c> b;
    
    b(Intent param1Intent, ArrayList<c.c> param1ArrayList) {
      this.a = param1Intent;
      this.b = param1ArrayList;
    }
  }
  
  private static final class c {
    final IntentFilter a;
    
    final BroadcastReceiver b;
    
    boolean c;
    
    boolean d;
    
    c(IntentFilter param1IntentFilter, BroadcastReceiver param1BroadcastReceiver) {
      this.a = param1IntentFilter;
      this.b = param1BroadcastReceiver;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder(128);
      stringBuilder.append("Receiver{");
      stringBuilder.append(this.b);
      stringBuilder.append(" filter=");
      stringBuilder.append(this.a);
      if (this.d)
        stringBuilder.append(" DEAD"); 
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\content\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */