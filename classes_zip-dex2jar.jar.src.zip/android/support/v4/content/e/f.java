package android.support.v4.content.e;

import a.b.g.a.c;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.TypedValue;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class f {
  public static Typeface a(Context paramContext, int paramInt1, TypedValue paramTypedValue, int paramInt2, a parama) {
    return paramContext.isRestricted() ? null : a(paramContext, paramInt1, paramTypedValue, paramInt2, parama, null, true);
  }
  
  private static Typeface a(Context paramContext, int paramInt1, TypedValue paramTypedValue, int paramInt2, a parama, Handler paramHandler, boolean paramBoolean) {
    Resources resources = paramContext.getResources();
    resources.getValue(paramInt1, paramTypedValue, true);
    Typeface typeface = a(paramContext, resources, paramTypedValue, paramInt1, paramInt2, parama, paramHandler, paramBoolean);
    if (typeface != null || parama != null)
      return typeface; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Font resource ID #0x");
    stringBuilder.append(Integer.toHexString(paramInt1));
    stringBuilder.append(" could not be retrieved.");
    throw new Resources.NotFoundException(stringBuilder.toString());
  }
  
  private static Typeface a(Context paramContext, Resources paramResources, TypedValue paramTypedValue, int paramInt1, int paramInt2, a parama, Handler paramHandler, boolean paramBoolean) {
    StringBuilder stringBuilder2;
    String str;
    CharSequence charSequence = paramTypedValue.string;
    if (charSequence != null) {
      str = charSequence.toString();
      if (!str.startsWith("res/")) {
        if (parama != null)
          parama.a(-3, paramHandler); 
        return null;
      } 
      Typeface typeface = c.b(paramResources, paramInt1, paramInt2);
      if (typeface != null) {
        if (parama != null)
          parama.a(typeface, paramHandler); 
        return typeface;
      } 
      try {
        boolean bool = str.toLowerCase().endsWith(".xml");
        if (bool) {
          try {
            XmlResourceParser xmlResourceParser = paramResources.getXml(paramInt1);
            c.a a1 = c.a((XmlPullParser)xmlResourceParser, paramResources);
            if (a1 == null) {
              try {
                Log.e("ResourcesCompat", "Failed to find font-family tag");
                if (parama != null)
                  parama.a(-3, paramHandler); 
                return null;
              } catch (XmlPullParserException xmlPullParserException) {
              
              } catch (IOException null) {}
            } else {
              try {
                return c.a((Context)iOException, a1, paramResources, paramInt1, paramInt2, parama, paramHandler, paramBoolean);
              } catch (XmlPullParserException xmlPullParserException) {
              
              } catch (IOException iOException1) {}
            } 
          } catch (XmlPullParserException xmlPullParserException) {
          
          } catch (IOException null) {}
        } else {
          try {
            Typeface typeface1 = c.a((Context)iOException, paramResources, paramInt1, str, paramInt2);
            if (parama != null)
              if (typeface1 != null) {
                try {
                  parama.a(typeface1, paramHandler);
                } catch (XmlPullParserException xmlPullParserException) {
                
                } catch (IOException iOException1) {}
              } else {
                parama.a(-3, paramHandler);
              }  
            return (Typeface)iOException1;
          } catch (XmlPullParserException xmlPullParserException) {
          
          } catch (IOException iOException1) {}
        } 
      } catch (XmlPullParserException xmlPullParserException) {
      
      } catch (IOException iOException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to read xml resource ");
        stringBuilder.append(str);
        Log.e("ResourcesCompat", stringBuilder.toString(), iOException);
      } 
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append("Failed to parse xml resource ");
      stringBuilder2.append(str);
      Log.e("ResourcesCompat", stringBuilder2.toString(), iOException);
      if (parama != null)
        parama.a(-3, paramHandler); 
      return null;
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Resource \"");
    stringBuilder1.append(stringBuilder2.getResourceName(paramInt1));
    stringBuilder1.append("\" (");
    stringBuilder1.append(Integer.toHexString(paramInt1));
    stringBuilder1.append(") is not a Font: ");
    stringBuilder1.append(str);
    throw new Resources.NotFoundException(stringBuilder1.toString());
  }
  
  public static Drawable a(Resources paramResources, int paramInt, Resources.Theme paramTheme) {
    return (Build.VERSION.SDK_INT >= 21) ? paramResources.getDrawable(paramInt, paramTheme) : paramResources.getDrawable(paramInt);
  }
  
  public static abstract class a {
    public abstract void a(int param1Int);
    
    public final void a(int param1Int, Handler param1Handler) {
      Handler handler = param1Handler;
      if (param1Handler == null)
        handler = new Handler(Looper.getMainLooper()); 
      handler.post(new b(this, param1Int));
    }
    
    public abstract void a(Typeface param1Typeface);
    
    public final void a(Typeface param1Typeface, Handler param1Handler) {
      Handler handler = param1Handler;
      if (param1Handler == null)
        handler = new Handler(Looper.getMainLooper()); 
      handler.post(new a(this, param1Typeface));
    }
    
    class a implements Runnable {
      final Typeface c;
      
      final f.a d;
      
      a(f.a this$0, Typeface param2Typeface) {}
      
      public void run() {
        this.d.a(this.c);
      }
    }
    
    class b implements Runnable {
      final int c;
      
      final f.a d;
      
      b(f.a this$0, int param2Int) {}
      
      public void run() {
        this.d.a(this.c);
      }
    }
  }
  
  class a implements Runnable {
    final Typeface c;
    
    final f.a d;
    
    a(f this$0, Typeface param1Typeface) {}
    
    public void run() {
      this.d.a(this.c);
    }
  }
  
  class b implements Runnable {
    final int c;
    
    final f.a d;
    
    b(f this$0, int param1Int) {}
    
    public void run() {
      this.d.a(this.c);
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\content\e\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */