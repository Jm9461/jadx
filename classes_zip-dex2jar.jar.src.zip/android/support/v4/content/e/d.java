package android.support.v4.content.e;

import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.LinearGradient;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

final class d {
  private static Shader.TileMode a(int paramInt) {
    return (paramInt != 1) ? ((paramInt != 2) ? Shader.TileMode.CLAMP : Shader.TileMode.MIRROR) : Shader.TileMode.REPEAT;
  }
  
  static Shader a(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    TypedArray typedArray;
    String str = paramXmlPullParser.getName();
    if (str.equals("gradient")) {
      typedArray = g.a(paramResources, paramTheme, paramAttributeSet, a.b.a.d.GradientColor);
      float f2 = g.a(typedArray, paramXmlPullParser, "startX", a.b.a.d.GradientColor_android_startX, 0.0F);
      float f7 = g.a(typedArray, paramXmlPullParser, "startY", a.b.a.d.GradientColor_android_startY, 0.0F);
      float f6 = g.a(typedArray, paramXmlPullParser, "endX", a.b.a.d.GradientColor_android_endX, 0.0F);
      float f4 = g.a(typedArray, paramXmlPullParser, "endY", a.b.a.d.GradientColor_android_endY, 0.0F);
      float f5 = g.a(typedArray, paramXmlPullParser, "centerX", a.b.a.d.GradientColor_android_centerX, 0.0F);
      float f1 = g.a(typedArray, paramXmlPullParser, "centerY", a.b.a.d.GradientColor_android_centerY, 0.0F);
      int m = g.b(typedArray, paramXmlPullParser, "type", a.b.a.d.GradientColor_android_type, 0);
      int i = g.a(typedArray, paramXmlPullParser, "startColor", a.b.a.d.GradientColor_android_startColor, 0);
      boolean bool = g.a(paramXmlPullParser, "centerColor");
      int n = g.a(typedArray, paramXmlPullParser, "centerColor", a.b.a.d.GradientColor_android_centerColor, 0);
      int k = g.a(typedArray, paramXmlPullParser, "endColor", a.b.a.d.GradientColor_android_endColor, 0);
      int j = g.b(typedArray, paramXmlPullParser, "tileMode", a.b.a.d.GradientColor_android_tileMode, 0);
      float f3 = g.a(typedArray, paramXmlPullParser, "gradientRadius", a.b.a.d.GradientColor_android_gradientRadius, 0.0F);
      typedArray.recycle();
      a a = a(b(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme), i, k, bool, n);
      if (m != 1)
        return (Shader)((m != 2) ? new LinearGradient(f2, f7, f6, f4, a.a, a.b, a(j)) : new SweepGradient(f5, f1, a.a, a.b)); 
      if (f3 > 0.0F)
        return (Shader)new RadialGradient(f5, f1, f3, a.a, a.b, a(j)); 
      throw new XmlPullParserException("<gradient> tag requires 'gradientRadius' attribute with radial type");
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramXmlPullParser.getPositionDescription());
    stringBuilder.append(": invalid gradient color tag ");
    stringBuilder.append((String)typedArray);
    throw new XmlPullParserException(stringBuilder.toString());
  }
  
  private static a a(a parama, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3) {
    return (parama != null) ? parama : (paramBoolean ? new a(paramInt1, paramInt3, paramInt2) : new a(paramInt1, paramInt2));
  }
  
  private static a b(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    int i = paramXmlPullParser.getDepth() + 1;
    ArrayList<Float> arrayList1 = new ArrayList(20);
    ArrayList<Integer> arrayList = new ArrayList(20);
    while (true) {
      int j = paramXmlPullParser.next();
      if (j != 1) {
        int k = paramXmlPullParser.getDepth();
        if (k >= i || j != 3) {
          if (j != 2 || k > i || !paramXmlPullParser.getName().equals("item"))
            continue; 
          TypedArray typedArray = g.a(paramResources, paramTheme, paramAttributeSet, a.b.a.d.GradientColorItem);
          boolean bool1 = typedArray.hasValue(a.b.a.d.GradientColorItem_android_color);
          boolean bool2 = typedArray.hasValue(a.b.a.d.GradientColorItem_android_offset);
          if (bool1 && bool2) {
            j = typedArray.getColor(a.b.a.d.GradientColorItem_android_color, 0);
            float f = typedArray.getFloat(a.b.a.d.GradientColorItem_android_offset, 0.0F);
            typedArray.recycle();
            arrayList.add(Integer.valueOf(j));
            arrayList1.add(Float.valueOf(f));
            continue;
          } 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramXmlPullParser.getPositionDescription());
          stringBuilder.append(": <item> tag requires a 'color' attribute and a 'offset' ");
          stringBuilder.append("attribute!");
          throw new XmlPullParserException(stringBuilder.toString());
        } 
      } 
      break;
    } 
    return (arrayList.size() > 0) ? new a(arrayList, arrayList1) : null;
  }
  
  static final class a {
    final int[] a;
    
    final float[] b;
    
    a(int param1Int1, int param1Int2) {
      this.a = new int[] { param1Int1, param1Int2 };
      this.b = new float[] { 0.0F, 1.0F };
    }
    
    a(int param1Int1, int param1Int2, int param1Int3) {
      this.a = new int[] { param1Int1, param1Int2, param1Int3 };
      this.b = new float[] { 0.0F, 0.5F, 1.0F };
    }
    
    a(List<Integer> param1List, List<Float> param1List1) {
      int i = param1List.size();
      this.a = new int[i];
      this.b = new float[i];
      for (byte b = 0; b < i; b++) {
        this.a[b] = ((Integer)param1List.get(b)).intValue();
        this.b[b] = ((Float)param1List1.get(b)).floatValue();
      } 
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\content\e\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */