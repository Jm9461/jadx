package android.support.v4.content;

import java.io.FileDescriptor;
import java.io.PrintWriter;

public class b<D> {
  @Deprecated
  public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    throw null;
  }
  
  public boolean a() {
    throw null;
  }
  
  public void b() {
    throw null;
  }
  
  public final void c() {
    throw null;
  }
  
  public void d() {
    throw null;
  }
  
  public static interface a<D> {}
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\content\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */