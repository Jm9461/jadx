package android.support.v4.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;

class d extends Drawable implements Drawable.Callback, c, b {
  static final PorterDuff.Mode i = PorterDuff.Mode.SRC_IN;
  
  private int c;
  
  private PorterDuff.Mode d;
  
  private boolean e;
  
  a f = c();
  
  private boolean g;
  
  Drawable h;
  
  d(Drawable paramDrawable) {
    a(paramDrawable);
  }
  
  d(a parama, Resources paramResources) {
    a(paramResources);
  }
  
  private void a(Resources paramResources) {
    a a1 = this.f;
    if (a1 != null) {
      Drawable.ConstantState constantState = a1.b;
      if (constantState != null)
        a(constantState.newDrawable(paramResources)); 
    } 
  }
  
  private boolean a(int[] paramArrayOfint) {
    if (!b())
      return false; 
    a a1 = this.f;
    ColorStateList colorStateList = a1.c;
    PorterDuff.Mode mode = a1.d;
    if (colorStateList != null && mode != null) {
      int i = colorStateList.getColorForState(paramArrayOfint, colorStateList.getDefaultColor());
      if (!this.e || i != this.c || mode != this.d) {
        setColorFilter(i, mode);
        this.c = i;
        this.d = mode;
        this.e = true;
        return true;
      } 
    } else {
      this.e = false;
      clearColorFilter();
    } 
    return false;
  }
  
  public final Drawable a() {
    return this.h;
  }
  
  public final void a(Drawable paramDrawable) {
    Drawable drawable = this.h;
    if (drawable != null)
      drawable.setCallback(null); 
    this.h = paramDrawable;
    if (paramDrawable != null) {
      paramDrawable.setCallback(this);
      setVisible(paramDrawable.isVisible(), true);
      setState(paramDrawable.getState());
      setLevel(paramDrawable.getLevel());
      setBounds(paramDrawable.getBounds());
      a a1 = this.f;
      if (a1 != null)
        a1.b = paramDrawable.getConstantState(); 
    } 
    invalidateSelf();
  }
  
  protected boolean b() {
    return true;
  }
  
  a c() {
    return new b(this.f, null);
  }
  
  public void draw(Canvas paramCanvas) {
    this.h.draw(paramCanvas);
  }
  
  public int getChangingConfigurations() {
    byte b1;
    int i = super.getChangingConfigurations();
    a a1 = this.f;
    if (a1 != null) {
      b1 = a1.getChangingConfigurations();
    } else {
      b1 = 0;
    } 
    return i | b1 | this.h.getChangingConfigurations();
  }
  
  public Drawable.ConstantState getConstantState() {
    a a1 = this.f;
    if (a1 != null && a1.a()) {
      this.f.a = getChangingConfigurations();
      return this.f;
    } 
    return null;
  }
  
  public Drawable getCurrent() {
    return this.h.getCurrent();
  }
  
  public int getIntrinsicHeight() {
    return this.h.getIntrinsicHeight();
  }
  
  public int getIntrinsicWidth() {
    return this.h.getIntrinsicWidth();
  }
  
  public int getMinimumHeight() {
    return this.h.getMinimumHeight();
  }
  
  public int getMinimumWidth() {
    return this.h.getMinimumWidth();
  }
  
  public int getOpacity() {
    return this.h.getOpacity();
  }
  
  public boolean getPadding(Rect paramRect) {
    return this.h.getPadding(paramRect);
  }
  
  public int[] getState() {
    return this.h.getState();
  }
  
  public Region getTransparentRegion() {
    return this.h.getTransparentRegion();
  }
  
  public void invalidateDrawable(Drawable paramDrawable) {
    invalidateSelf();
  }
  
  public boolean isAutoMirrored() {
    return this.h.isAutoMirrored();
  }
  
  public boolean isStateful() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual b : ()Z
    //   4: ifeq -> 24
    //   7: aload_0
    //   8: getfield f : Landroid/support/v4/graphics/drawable/d$a;
    //   11: astore_2
    //   12: aload_2
    //   13: ifnull -> 24
    //   16: aload_2
    //   17: getfield c : Landroid/content/res/ColorStateList;
    //   20: astore_2
    //   21: goto -> 26
    //   24: aconst_null
    //   25: astore_2
    //   26: aload_2
    //   27: ifnull -> 37
    //   30: aload_2
    //   31: invokevirtual isStateful : ()Z
    //   34: ifne -> 47
    //   37: aload_0
    //   38: getfield h : Landroid/graphics/drawable/Drawable;
    //   41: invokevirtual isStateful : ()Z
    //   44: ifeq -> 52
    //   47: iconst_1
    //   48: istore_1
    //   49: goto -> 54
    //   52: iconst_0
    //   53: istore_1
    //   54: iload_1
    //   55: ireturn
  }
  
  public void jumpToCurrentState() {
    this.h.jumpToCurrentState();
  }
  
  public Drawable mutate() {
    if (!this.g && super.mutate() == this) {
      this.f = c();
      Drawable drawable = this.h;
      if (drawable != null)
        drawable.mutate(); 
      a a1 = this.f;
      if (a1 != null) {
        drawable = this.h;
        if (drawable != null) {
          Drawable.ConstantState constantState = drawable.getConstantState();
        } else {
          drawable = null;
        } 
        a1.b = (Drawable.ConstantState)drawable;
      } 
      this.g = true;
    } 
    return this;
  }
  
  protected void onBoundsChange(Rect paramRect) {
    Drawable drawable = this.h;
    if (drawable != null)
      drawable.setBounds(paramRect); 
  }
  
  protected boolean onLevelChange(int paramInt) {
    return this.h.setLevel(paramInt);
  }
  
  public void scheduleDrawable(Drawable paramDrawable, Runnable paramRunnable, long paramLong) {
    scheduleSelf(paramRunnable, paramLong);
  }
  
  public void setAlpha(int paramInt) {
    this.h.setAlpha(paramInt);
  }
  
  public void setAutoMirrored(boolean paramBoolean) {
    this.h.setAutoMirrored(paramBoolean);
  }
  
  public void setChangingConfigurations(int paramInt) {
    this.h.setChangingConfigurations(paramInt);
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    this.h.setColorFilter(paramColorFilter);
  }
  
  public void setDither(boolean paramBoolean) {
    this.h.setDither(paramBoolean);
  }
  
  public void setFilterBitmap(boolean paramBoolean) {
    this.h.setFilterBitmap(paramBoolean);
  }
  
  public boolean setState(int[] paramArrayOfint) {
    null = this.h.setState(paramArrayOfint);
    return (a(paramArrayOfint) || null);
  }
  
  public void setTint(int paramInt) {
    setTintList(ColorStateList.valueOf(paramInt));
  }
  
  public void setTintList(ColorStateList paramColorStateList) {
    this.f.c = paramColorStateList;
    a(getState());
  }
  
  public void setTintMode(PorterDuff.Mode paramMode) {
    this.f.d = paramMode;
    a(getState());
  }
  
  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2) {
    return (super.setVisible(paramBoolean1, paramBoolean2) || this.h.setVisible(paramBoolean1, paramBoolean2));
  }
  
  public void unscheduleDrawable(Drawable paramDrawable, Runnable paramRunnable) {
    unscheduleSelf(paramRunnable);
  }
  
  protected static abstract class a extends Drawable.ConstantState {
    int a;
    
    Drawable.ConstantState b;
    
    ColorStateList c = null;
    
    PorterDuff.Mode d = d.i;
    
    a(a param1a, Resources param1Resources) {
      if (param1a != null) {
        this.a = param1a.a;
        this.b = param1a.b;
        this.c = param1a.c;
        this.d = param1a.d;
      } 
    }
    
    boolean a() {
      boolean bool;
      if (this.b != null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public int getChangingConfigurations() {
      byte b;
      int i = this.a;
      Drawable.ConstantState constantState = this.b;
      if (constantState != null) {
        b = constantState.getChangingConfigurations();
      } else {
        b = 0;
      } 
      return i | b;
    }
    
    public Drawable newDrawable() {
      return newDrawable(null);
    }
    
    public abstract Drawable newDrawable(Resources param1Resources);
  }
  
  private static class b extends a {
    b(d.a param1a, Resources param1Resources) {
      super(param1a, param1Resources);
    }
    
    public Drawable newDrawable(Resources param1Resources) {
      return new d(this, param1Resources);
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\v4\graphics\drawable\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */