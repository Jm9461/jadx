package android.support.constraint;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.util.Xml;
import android.view.View;
import android.view.ViewGroup;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class c {
  private static final int[] b = new int[] { 0, 4, 8 };
  
  private static SparseIntArray c = new SparseIntArray();
  
  private HashMap<Integer, b> a = new HashMap<Integer, b>();
  
  static {
    c.append(h.ConstraintSet_layout_constraintLeft_toLeftOf, 25);
    c.append(h.ConstraintSet_layout_constraintLeft_toRightOf, 26);
    c.append(h.ConstraintSet_layout_constraintRight_toLeftOf, 29);
    c.append(h.ConstraintSet_layout_constraintRight_toRightOf, 30);
    c.append(h.ConstraintSet_layout_constraintTop_toTopOf, 36);
    c.append(h.ConstraintSet_layout_constraintTop_toBottomOf, 35);
    c.append(h.ConstraintSet_layout_constraintBottom_toTopOf, 4);
    c.append(h.ConstraintSet_layout_constraintBottom_toBottomOf, 3);
    c.append(h.ConstraintSet_layout_constraintBaseline_toBaselineOf, 1);
    c.append(h.ConstraintSet_layout_editor_absoluteX, 6);
    c.append(h.ConstraintSet_layout_editor_absoluteY, 7);
    c.append(h.ConstraintSet_layout_constraintGuide_begin, 17);
    c.append(h.ConstraintSet_layout_constraintGuide_end, 18);
    c.append(h.ConstraintSet_layout_constraintGuide_percent, 19);
    c.append(h.ConstraintSet_android_orientation, 27);
    c.append(h.ConstraintSet_layout_constraintStart_toEndOf, 32);
    c.append(h.ConstraintSet_layout_constraintStart_toStartOf, 33);
    c.append(h.ConstraintSet_layout_constraintEnd_toStartOf, 10);
    c.append(h.ConstraintSet_layout_constraintEnd_toEndOf, 9);
    c.append(h.ConstraintSet_layout_goneMarginLeft, 13);
    c.append(h.ConstraintSet_layout_goneMarginTop, 16);
    c.append(h.ConstraintSet_layout_goneMarginRight, 14);
    c.append(h.ConstraintSet_layout_goneMarginBottom, 11);
    c.append(h.ConstraintSet_layout_goneMarginStart, 15);
    c.append(h.ConstraintSet_layout_goneMarginEnd, 12);
    c.append(h.ConstraintSet_layout_constraintVertical_weight, 40);
    c.append(h.ConstraintSet_layout_constraintHorizontal_weight, 39);
    c.append(h.ConstraintSet_layout_constraintHorizontal_chainStyle, 41);
    c.append(h.ConstraintSet_layout_constraintVertical_chainStyle, 42);
    c.append(h.ConstraintSet_layout_constraintHorizontal_bias, 20);
    c.append(h.ConstraintSet_layout_constraintVertical_bias, 37);
    c.append(h.ConstraintSet_layout_constraintDimensionRatio, 5);
    c.append(h.ConstraintSet_layout_constraintLeft_creator, 64);
    c.append(h.ConstraintSet_layout_constraintTop_creator, 64);
    c.append(h.ConstraintSet_layout_constraintRight_creator, 64);
    c.append(h.ConstraintSet_layout_constraintBottom_creator, 64);
    c.append(h.ConstraintSet_layout_constraintBaseline_creator, 64);
    c.append(h.ConstraintSet_android_layout_marginLeft, 24);
    c.append(h.ConstraintSet_android_layout_marginRight, 28);
    c.append(h.ConstraintSet_android_layout_marginStart, 31);
    c.append(h.ConstraintSet_android_layout_marginEnd, 8);
    c.append(h.ConstraintSet_android_layout_marginTop, 34);
    c.append(h.ConstraintSet_android_layout_marginBottom, 2);
    c.append(h.ConstraintSet_android_layout_width, 23);
    c.append(h.ConstraintSet_android_layout_height, 21);
    c.append(h.ConstraintSet_android_visibility, 22);
    c.append(h.ConstraintSet_android_alpha, 43);
    c.append(h.ConstraintSet_android_elevation, 44);
    c.append(h.ConstraintSet_android_rotationX, 45);
    c.append(h.ConstraintSet_android_rotationY, 46);
    c.append(h.ConstraintSet_android_rotation, 60);
    c.append(h.ConstraintSet_android_scaleX, 47);
    c.append(h.ConstraintSet_android_scaleY, 48);
    c.append(h.ConstraintSet_android_transformPivotX, 49);
    c.append(h.ConstraintSet_android_transformPivotY, 50);
    c.append(h.ConstraintSet_android_translationX, 51);
    c.append(h.ConstraintSet_android_translationY, 52);
    c.append(h.ConstraintSet_android_translationZ, 53);
    c.append(h.ConstraintSet_layout_constraintWidth_default, 54);
    c.append(h.ConstraintSet_layout_constraintHeight_default, 55);
    c.append(h.ConstraintSet_layout_constraintWidth_max, 56);
    c.append(h.ConstraintSet_layout_constraintHeight_max, 57);
    c.append(h.ConstraintSet_layout_constraintWidth_min, 58);
    c.append(h.ConstraintSet_layout_constraintHeight_min, 59);
    c.append(h.ConstraintSet_layout_constraintCircle, 61);
    c.append(h.ConstraintSet_layout_constraintCircleRadius, 62);
    c.append(h.ConstraintSet_layout_constraintCircleAngle, 63);
    c.append(h.ConstraintSet_android_id, 38);
  }
  
  private static int a(TypedArray paramTypedArray, int paramInt1, int paramInt2) {
    int i = paramTypedArray.getResourceId(paramInt1, paramInt2);
    paramInt2 = i;
    if (i == -1)
      paramInt2 = paramTypedArray.getInt(paramInt1, -1); 
    return paramInt2;
  }
  
  private b a(Context paramContext, AttributeSet paramAttributeSet) {
    b b = new b(null);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, h.ConstraintSet);
    a(b, typedArray);
    typedArray.recycle();
    return b;
  }
  
  private void a(b paramb, TypedArray paramTypedArray) {
    int i = paramTypedArray.getIndexCount();
    for (byte b1 = 0; b1 < i; b1++) {
      StringBuilder stringBuilder;
      int k = paramTypedArray.getIndex(b1);
      int j = c.get(k);
      switch (j) {
        default:
          switch (j) {
            default:
              stringBuilder = new StringBuilder();
              stringBuilder.append("Unknown attribute 0x");
              stringBuilder.append(Integer.toHexString(k));
              stringBuilder.append("   ");
              stringBuilder.append(c.get(k));
              Log.w("ConstraintSet", stringBuilder.toString());
              break;
            case 64:
              stringBuilder = new StringBuilder();
              stringBuilder.append("unused attribute 0x");
              stringBuilder.append(Integer.toHexString(k));
              stringBuilder.append("   ");
              stringBuilder.append(c.get(k));
              Log.w("ConstraintSet", stringBuilder.toString());
              break;
            case 63:
              paramb.z = paramTypedArray.getFloat(k, paramb.z);
              break;
            case 62:
              paramb.y = paramTypedArray.getDimensionPixelSize(k, paramb.y);
              break;
            case 61:
              paramb.x = a(paramTypedArray, k, paramb.x);
              break;
            case 60:
              break;
          } 
          paramb.X = paramTypedArray.getFloat(k, paramb.X);
          break;
        case 53:
          paramb.g0 = paramTypedArray.getDimension(k, paramb.g0);
          break;
        case 52:
          paramb.f0 = paramTypedArray.getDimension(k, paramb.f0);
          break;
        case 51:
          paramb.e0 = paramTypedArray.getDimension(k, paramb.e0);
          break;
        case 50:
          paramb.d0 = paramTypedArray.getFloat(k, paramb.d0);
          break;
        case 49:
          paramb.c0 = paramTypedArray.getFloat(k, paramb.c0);
          break;
        case 48:
          paramb.b0 = paramTypedArray.getFloat(k, paramb.b0);
          break;
        case 47:
          paramb.a0 = paramTypedArray.getFloat(k, paramb.a0);
          break;
        case 46:
          paramb.Z = paramTypedArray.getFloat(k, paramb.Z);
          break;
        case 45:
          paramb.Y = paramTypedArray.getFloat(k, paramb.Y);
          break;
        case 44:
          paramb.V = true;
          paramb.W = paramTypedArray.getDimension(k, paramb.W);
          break;
        case 43:
          paramb.U = paramTypedArray.getFloat(k, paramb.U);
          break;
        case 42:
          paramb.T = paramTypedArray.getInt(k, paramb.T);
          break;
        case 41:
          paramb.S = paramTypedArray.getInt(k, paramb.S);
          break;
        case 40:
          paramb.Q = paramTypedArray.getFloat(k, paramb.Q);
          break;
        case 39:
          paramb.R = paramTypedArray.getFloat(k, paramb.R);
          break;
        case 38:
          paramb.d = paramTypedArray.getResourceId(k, paramb.d);
          break;
        case 37:
          paramb.v = paramTypedArray.getFloat(k, paramb.v);
          break;
        case 36:
          paramb.l = a(paramTypedArray, k, paramb.l);
          break;
        case 35:
          paramb.m = a(paramTypedArray, k, paramb.m);
          break;
        case 34:
          paramb.F = paramTypedArray.getDimensionPixelSize(k, paramb.F);
          break;
        case 33:
          paramb.r = a(paramTypedArray, k, paramb.r);
          break;
        case 32:
          paramb.q = a(paramTypedArray, k, paramb.q);
          break;
        case 31:
          paramb.I = paramTypedArray.getDimensionPixelSize(k, paramb.I);
          break;
        case 30:
          paramb.k = a(paramTypedArray, k, paramb.k);
          break;
        case 29:
          paramb.j = a(paramTypedArray, k, paramb.j);
          break;
        case 28:
          paramb.E = paramTypedArray.getDimensionPixelSize(k, paramb.E);
          break;
        case 27:
          paramb.C = paramTypedArray.getInt(k, paramb.C);
          break;
        case 26:
          paramb.i = a(paramTypedArray, k, paramb.i);
          break;
        case 25:
          paramb.h = a(paramTypedArray, k, paramb.h);
          break;
        case 24:
          paramb.D = paramTypedArray.getDimensionPixelSize(k, paramb.D);
          break;
        case 23:
          paramb.b = paramTypedArray.getLayoutDimension(k, paramb.b);
          break;
        case 22:
          paramb.J = paramTypedArray.getInt(k, paramb.J);
          paramb.J = b[paramb.J];
          break;
        case 21:
          paramb.c = paramTypedArray.getLayoutDimension(k, paramb.c);
          break;
        case 20:
          paramb.u = paramTypedArray.getFloat(k, paramb.u);
          break;
        case 19:
          paramb.g = paramTypedArray.getFloat(k, paramb.g);
          break;
        case 18:
          paramb.f = paramTypedArray.getDimensionPixelOffset(k, paramb.f);
          break;
        case 17:
          paramb.e = paramTypedArray.getDimensionPixelOffset(k, paramb.e);
          break;
        case 16:
          paramb.L = paramTypedArray.getDimensionPixelSize(k, paramb.L);
          break;
        case 15:
          paramb.P = paramTypedArray.getDimensionPixelSize(k, paramb.P);
          break;
        case 14:
          paramb.M = paramTypedArray.getDimensionPixelSize(k, paramb.M);
          break;
        case 13:
          paramb.K = paramTypedArray.getDimensionPixelSize(k, paramb.K);
          break;
        case 12:
          paramb.O = paramTypedArray.getDimensionPixelSize(k, paramb.O);
          break;
        case 11:
          paramb.N = paramTypedArray.getDimensionPixelSize(k, paramb.N);
          break;
        case 10:
          paramb.s = a(paramTypedArray, k, paramb.s);
          break;
        case 9:
          paramb.t = a(paramTypedArray, k, paramb.t);
          break;
        case 8:
          paramb.H = paramTypedArray.getDimensionPixelSize(k, paramb.H);
          break;
        case 7:
          paramb.B = paramTypedArray.getDimensionPixelOffset(k, paramb.B);
          break;
        case 6:
          paramb.A = paramTypedArray.getDimensionPixelOffset(k, paramb.A);
          break;
        case 5:
          paramb.w = paramTypedArray.getString(k);
          break;
        case 4:
          paramb.n = a(paramTypedArray, k, paramb.n);
          break;
        case 3:
          paramb.o = a(paramTypedArray, k, paramb.o);
          break;
        case 2:
          paramb.G = paramTypedArray.getDimensionPixelSize(k, paramb.G);
          break;
        case 1:
          paramb.p = a(paramTypedArray, k, paramb.p);
          break;
      } 
    } 
  }
  
  public void a(Context paramContext, int paramInt) {
    XmlResourceParser xmlResourceParser = paramContext.getResources().getXml(paramInt);
    try {
      for (paramInt = xmlResourceParser.getEventType(); paramInt != 1; paramInt = xmlResourceParser.next()) {
        if (paramInt != 0) {
          if (paramInt != 2) {
            if (paramInt != 3);
          } else {
            String str = xmlResourceParser.getName();
            b b = a(paramContext, Xml.asAttributeSet((XmlPullParser)xmlResourceParser));
            if (str.equalsIgnoreCase("Guideline"))
              b.a = true; 
            this.a.put(Integer.valueOf(b.d), b);
          } 
        } else {
          xmlResourceParser.getName();
        } 
      } 
    } catch (XmlPullParserException xmlPullParserException) {
      xmlPullParserException.printStackTrace();
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
  }
  
  void a(ConstraintLayout paramConstraintLayout) {
    int j = paramConstraintLayout.getChildCount();
    HashSet hashSet = new HashSet(this.a.keySet());
    int i = 0;
    while (i < j) {
      View view = paramConstraintLayout.getChildAt(i);
      int k = view.getId();
      if (k != -1) {
        if (this.a.containsKey(Integer.valueOf(k))) {
          hashSet.remove(Integer.valueOf(k));
          b b = this.a.get(Integer.valueOf(k));
          int m = b.s0;
          if (m != -1 && m == 1) {
            a a1 = (a)view;
            a1.setId(k);
            a1.setReferencedIds(b.t0);
            a1.setType(b.r0);
            b.a(paramConstraintLayout.generateDefaultLayoutParams());
          } 
          ConstraintLayout.a a = (ConstraintLayout.a)view.getLayoutParams();
          b.a(a);
          view.setLayoutParams((ViewGroup.LayoutParams)a);
          view.setVisibility(b.J);
          if (Build.VERSION.SDK_INT >= 17) {
            view.setAlpha(b.U);
            view.setRotation(b.X);
            view.setRotationX(b.Y);
            view.setRotationY(b.Z);
            view.setScaleX(b.a0);
            view.setScaleY(b.b0);
            if (!Float.isNaN(b.c0))
              view.setPivotX(b.c0); 
            if (!Float.isNaN(b.d0))
              view.setPivotY(b.d0); 
            view.setTranslationX(b.e0);
            view.setTranslationY(b.f0);
            if (Build.VERSION.SDK_INT >= 21) {
              view.setTranslationZ(b.g0);
              if (b.V)
                view.setElevation(b.W); 
            } 
          } 
        } 
        i++;
        continue;
      } 
      throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
    } 
    for (Integer integer : hashSet) {
      b b = this.a.get(integer);
      i = b.s0;
      if (i != -1 && i == 1) {
        a a1 = new a(paramConstraintLayout.getContext());
        a1.setId(integer.intValue());
        a1.setReferencedIds(b.t0);
        a1.setType(b.r0);
        ConstraintLayout.a a = paramConstraintLayout.generateDefaultLayoutParams();
        b.a(a);
        paramConstraintLayout.addView(a1, (ViewGroup.LayoutParams)a);
      } 
      if (b.a) {
        e e = new e(paramConstraintLayout.getContext());
        e.setId(integer.intValue());
        ConstraintLayout.a a = paramConstraintLayout.generateDefaultLayoutParams();
        b.a(a);
        paramConstraintLayout.addView(e, (ViewGroup.LayoutParams)a);
      } 
    } 
  }
  
  public void a(d paramd) {
    int i = paramd.getChildCount();
    this.a.clear();
    byte b = 0;
    while (b < i) {
      View view = paramd.getChildAt(b);
      d.a a = (d.a)view.getLayoutParams();
      int j = view.getId();
      if (j != -1) {
        if (!this.a.containsKey(Integer.valueOf(j)))
          this.a.put(Integer.valueOf(j), new b(null)); 
        b b1 = this.a.get(Integer.valueOf(j));
        if (view instanceof b)
          b.a(b1, (b)view, j, a); 
        b.a(b1, j, a);
        b++;
        continue;
      } 
      throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
    } 
  }
  
  private static class b {
    public int A = -1;
    
    public int B = -1;
    
    public int C = -1;
    
    public int D = -1;
    
    public int E = -1;
    
    public int F = -1;
    
    public int G = -1;
    
    public int H = -1;
    
    public int I = -1;
    
    public int J = 0;
    
    public int K = -1;
    
    public int L = -1;
    
    public int M = -1;
    
    public int N = -1;
    
    public int O = -1;
    
    public int P = -1;
    
    public float Q = 0.0F;
    
    public float R = 0.0F;
    
    public int S = 0;
    
    public int T = 0;
    
    public float U = 1.0F;
    
    public boolean V = false;
    
    public float W = 0.0F;
    
    public float X = 0.0F;
    
    public float Y = 0.0F;
    
    public float Z = 0.0F;
    
    boolean a = false;
    
    public float a0 = 1.0F;
    
    public int b;
    
    public float b0 = 1.0F;
    
    public int c;
    
    public float c0 = Float.NaN;
    
    int d;
    
    public float d0 = Float.NaN;
    
    public int e = -1;
    
    public float e0 = 0.0F;
    
    public int f = -1;
    
    public float f0 = 0.0F;
    
    public float g = -1.0F;
    
    public float g0 = 0.0F;
    
    public int h = -1;
    
    public boolean h0 = false;
    
    public int i = -1;
    
    public boolean i0 = false;
    
    public int j = -1;
    
    public int j0 = 0;
    
    public int k = -1;
    
    public int k0 = 0;
    
    public int l = -1;
    
    public int l0 = -1;
    
    public int m = -1;
    
    public int m0 = -1;
    
    public int n = -1;
    
    public int n0 = -1;
    
    public int o = -1;
    
    public int o0 = -1;
    
    public int p = -1;
    
    public float p0 = 1.0F;
    
    public int q = -1;
    
    public float q0 = 1.0F;
    
    public int r = -1;
    
    public int r0 = -1;
    
    public int s = -1;
    
    public int s0 = -1;
    
    public int t = -1;
    
    public int[] t0;
    
    public float u = 0.5F;
    
    public float v = 0.5F;
    
    public String w = null;
    
    public int x = -1;
    
    public int y = 0;
    
    public float z = 0.0F;
    
    private b() {}
    
    private void a(int param1Int, ConstraintLayout.a param1a) {
      this.d = param1Int;
      this.h = param1a.d;
      this.i = param1a.e;
      this.j = param1a.f;
      this.k = param1a.g;
      this.l = param1a.h;
      this.m = param1a.i;
      this.n = param1a.j;
      this.o = param1a.k;
      this.p = param1a.l;
      this.q = param1a.p;
      this.r = param1a.q;
      this.s = param1a.r;
      this.t = param1a.s;
      this.u = param1a.z;
      this.v = param1a.A;
      this.w = param1a.B;
      this.x = param1a.m;
      this.y = param1a.n;
      this.z = param1a.o;
      this.A = param1a.P;
      this.B = param1a.Q;
      this.C = param1a.R;
      this.g = param1a.c;
      this.e = param1a.a;
      this.f = param1a.b;
      this.b = param1a.width;
      this.c = param1a.height;
      this.D = param1a.leftMargin;
      this.E = param1a.rightMargin;
      this.F = param1a.topMargin;
      this.G = param1a.bottomMargin;
      this.Q = param1a.E;
      this.R = param1a.D;
      this.T = param1a.G;
      this.S = param1a.F;
      boolean bool = param1a.S;
      this.h0 = bool;
      this.i0 = param1a.T;
      this.j0 = param1a.H;
      this.k0 = param1a.I;
      this.h0 = bool;
      this.l0 = param1a.L;
      this.m0 = param1a.M;
      this.n0 = param1a.J;
      this.o0 = param1a.K;
      this.p0 = param1a.N;
      this.q0 = param1a.O;
      if (Build.VERSION.SDK_INT >= 17) {
        this.H = param1a.getMarginEnd();
        this.I = param1a.getMarginStart();
      } 
    }
    
    private void a(int param1Int, d.a param1a) {
      a(param1Int, param1a);
      this.U = param1a.m0;
      this.X = param1a.p0;
      this.Y = param1a.q0;
      this.Z = param1a.r0;
      this.a0 = param1a.s0;
      this.b0 = param1a.t0;
      this.c0 = param1a.u0;
      this.d0 = param1a.v0;
      this.e0 = param1a.w0;
      this.f0 = param1a.x0;
      this.g0 = param1a.y0;
      this.W = param1a.o0;
      this.V = param1a.n0;
    }
    
    private void a(b param1b, int param1Int, d.a param1a) {
      a(param1Int, param1a);
      if (param1b instanceof a) {
        this.s0 = 1;
        param1b = param1b;
        this.r0 = param1b.getType();
        this.t0 = param1b.getReferencedIds();
      } 
    }
    
    public void a(ConstraintLayout.a param1a) {
      param1a.d = this.h;
      param1a.e = this.i;
      param1a.f = this.j;
      param1a.g = this.k;
      param1a.h = this.l;
      param1a.i = this.m;
      param1a.j = this.n;
      param1a.k = this.o;
      param1a.l = this.p;
      param1a.p = this.q;
      param1a.q = this.r;
      param1a.r = this.s;
      param1a.s = this.t;
      param1a.leftMargin = this.D;
      param1a.rightMargin = this.E;
      param1a.topMargin = this.F;
      param1a.bottomMargin = this.G;
      param1a.x = this.P;
      param1a.y = this.O;
      param1a.z = this.u;
      param1a.A = this.v;
      param1a.m = this.x;
      param1a.n = this.y;
      param1a.o = this.z;
      param1a.B = this.w;
      param1a.P = this.A;
      param1a.Q = this.B;
      param1a.E = this.Q;
      param1a.D = this.R;
      param1a.G = this.T;
      param1a.F = this.S;
      param1a.S = this.h0;
      param1a.T = this.i0;
      param1a.H = this.j0;
      param1a.I = this.k0;
      param1a.L = this.l0;
      param1a.M = this.m0;
      param1a.J = this.n0;
      param1a.K = this.o0;
      param1a.N = this.p0;
      param1a.O = this.q0;
      param1a.R = this.C;
      param1a.c = this.g;
      param1a.a = this.e;
      param1a.b = this.f;
      param1a.width = this.b;
      param1a.height = this.c;
      if (Build.VERSION.SDK_INT >= 17) {
        param1a.setMarginStart(this.I);
        param1a.setMarginEnd(this.H);
      } 
      param1a.a();
    }
    
    public b clone() {
      b b1 = new b();
      b1.a = this.a;
      b1.b = this.b;
      b1.c = this.c;
      b1.e = this.e;
      b1.f = this.f;
      b1.g = this.g;
      b1.h = this.h;
      b1.i = this.i;
      b1.j = this.j;
      b1.k = this.k;
      b1.l = this.l;
      b1.m = this.m;
      b1.n = this.n;
      b1.o = this.o;
      b1.p = this.p;
      b1.q = this.q;
      b1.r = this.r;
      b1.s = this.s;
      b1.t = this.t;
      b1.u = this.u;
      b1.v = this.v;
      b1.w = this.w;
      b1.A = this.A;
      b1.B = this.B;
      b1.u = this.u;
      b1.u = this.u;
      b1.u = this.u;
      b1.u = this.u;
      b1.u = this.u;
      b1.C = this.C;
      b1.D = this.D;
      b1.E = this.E;
      b1.F = this.F;
      b1.G = this.G;
      b1.H = this.H;
      b1.I = this.I;
      b1.J = this.J;
      b1.K = this.K;
      b1.L = this.L;
      b1.M = this.M;
      b1.N = this.N;
      b1.O = this.O;
      b1.P = this.P;
      b1.Q = this.Q;
      b1.R = this.R;
      b1.S = this.S;
      b1.T = this.T;
      b1.U = this.U;
      b1.V = this.V;
      b1.W = this.W;
      b1.X = this.X;
      b1.Y = this.Y;
      b1.Z = this.Z;
      b1.a0 = this.a0;
      b1.b0 = this.b0;
      b1.c0 = this.c0;
      b1.d0 = this.d0;
      b1.e0 = this.e0;
      b1.f0 = this.f0;
      b1.g0 = this.g0;
      b1.h0 = this.h0;
      b1.i0 = this.i0;
      b1.j0 = this.j0;
      b1.k0 = this.k0;
      b1.l0 = this.l0;
      b1.m0 = this.m0;
      b1.n0 = this.n0;
      b1.o0 = this.o0;
      b1.p0 = this.p0;
      b1.q0 = this.q0;
      b1.r0 = this.r0;
      b1.s0 = this.s0;
      int[] arrayOfInt = this.t0;
      if (arrayOfInt != null)
        b1.t0 = Arrays.copyOf(arrayOfInt, arrayOfInt.length); 
      b1.x = this.x;
      b1.y = this.y;
      b1.z = this.z;
      return b1;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */