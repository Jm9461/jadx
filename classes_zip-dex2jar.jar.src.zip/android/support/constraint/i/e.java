package android.support.constraint.i;

import android.support.constraint.i.j.d;
import android.support.constraint.i.j.e;
import java.util.Arrays;
import java.util.HashMap;

public class e {
  private static int p = 1000;
  
  public static f q;
  
  int a = 0;
  
  private HashMap<String, i> b = null;
  
  private a c;
  
  private int d = 32;
  
  private int e;
  
  b[] f;
  
  public boolean g;
  
  private boolean[] h;
  
  int i;
  
  int j;
  
  private int k;
  
  final c l;
  
  private i[] m;
  
  private int n;
  
  private final a o;
  
  public e() {
    int j = this.d;
    this.e = j;
    this.f = null;
    this.g = false;
    this.h = new boolean[j];
    this.i = 1;
    this.j = 0;
    this.k = j;
    this.m = new i[p];
    this.n = 0;
    b[] arrayOfB = new b[j];
    this.f = new b[j];
    j();
    this.l = new c();
    this.c = new d(this.l);
    this.o = new b(this.l);
  }
  
  private final int a(a parama, boolean paramBoolean) {
    int j;
    int k;
    f f1 = q;
    if (f1 != null)
      f1.h++; 
    int n = 0;
    int i1 = 0;
    int m = 0;
    while (true) {
      j = n;
      k = i1;
      if (m < this.i) {
        this.h[m] = false;
        m++;
        continue;
      } 
      break;
    } 
    while (!j) {
      f1 = q;
      if (f1 != null)
        f1.i++; 
      i1 = k + 1;
      if (i1 >= this.i * 2)
        return i1; 
      if (parama.getKey() != null)
        this.h[(parama.getKey()).b] = true; 
      i i2 = parama.a(this, this.h);
      if (i2 != null) {
        boolean[] arrayOfBoolean = this.h;
        k = i2.b;
        if (arrayOfBoolean[k])
          return i1; 
        arrayOfBoolean[k] = true;
      } 
      if (i2 != null) {
        float f2 = Float.MAX_VALUE;
        n = -1;
        k = 0;
        while (k < this.j) {
          float f3;
          b b1 = this.f[k];
          if (b1.a.g == i.a.c) {
            f3 = f2;
            m = n;
          } else if (b1.e) {
            f3 = f2;
            m = n;
          } else {
            f3 = f2;
            m = n;
            if (b1.b(i2)) {
              float f4 = b1.d.b(i2);
              f3 = f2;
              m = n;
              if (f4 < 0.0F) {
                f4 = -b1.b / f4;
                f3 = f2;
                m = n;
                if (f4 < f2) {
                  f3 = f4;
                  m = k;
                } 
              } 
            } 
          } 
          k++;
          f2 = f3;
          n = m;
        } 
        if (n > -1) {
          b b1 = this.f[n];
          b1.a.c = -1;
          f f3 = q;
          if (f3 != null)
            f3.j++; 
          b1.d(i2);
          i2 = b1.a;
          i2.c = n;
          i2.c(b1);
        } else {
          j = 1;
        } 
      } else {
        j = 1;
      } 
      k = i1;
    } 
    return k;
  }
  
  public static b a(e parame, i parami1, i parami2, i parami3, float paramFloat, boolean paramBoolean) {
    b b1 = parame.b();
    if (paramBoolean)
      parame.b(b1); 
    b1.a(parami1, parami2, parami3, paramFloat);
    return b1;
  }
  
  private i a(i.a parama, String paramString) {
    i i1;
    i i2 = this.l.b.a();
    if (i2 == null) {
      i2 = new i(parama, paramString);
      i2.a(parama, paramString);
      i1 = i2;
    } else {
      i2.a();
      i2.a((i.a)i1, paramString);
      i1 = i2;
    } 
    int k = this.n;
    int j = p;
    if (k >= j) {
      p = j * 2;
      this.m = Arrays.<i>copyOf(this.m, p);
    } 
    i[] arrayOfI = this.m;
    j = this.n;
    this.n = j + 1;
    arrayOfI[j] = i1;
    return i1;
  }
  
  private int b(a parama) {
    int j;
    int m = 0;
    byte b1 = 0;
    int k = 0;
    while (true) {
      j = b1;
      if (k < this.j) {
        b[] arrayOfB = this.f;
        if ((arrayOfB[k]).a.g != i.a.c && (arrayOfB[k]).b < 0.0F) {
          j = 1;
          break;
        } 
        k++;
        continue;
      } 
      break;
    } 
    k = m;
    if (j) {
      b1 = 0;
      j = 0;
      while (true) {
        k = j;
        if (!b1) {
          f f1 = q;
          if (f1 != null)
            f1.k++; 
          int n = j + 1;
          float f2 = Float.MAX_VALUE;
          j = 0;
          k = -1;
          m = -1;
          byte b2 = 0;
          while (b2 < this.j) {
            float f3;
            Object object2;
            int i1;
            int i2;
            b b3 = this.f[b2];
            if (b3.a.g == i.a.c) {
              f3 = f2;
              int i3 = j;
              i1 = k;
              i2 = m;
            } else if (b3.e) {
              f3 = f2;
              int i3 = j;
              i1 = k;
              i2 = m;
            } else {
              f3 = f2;
              int i3 = j;
              i1 = k;
              i2 = m;
              if (b3.b < 0.0F) {
                Object object;
                byte b4 = 1;
                while (true) {
                  f3 = f2;
                  i3 = j;
                  Object object3 = object;
                  i2 = m;
                  if (b4 < this.i) {
                    i i4 = this.l.c[b4];
                    float f4 = b3.d.b(i4);
                    if (f4 <= 0.0F) {
                      f3 = f2;
                      i2 = j;
                      Object object4 = object;
                      int i6 = m;
                      continue;
                    } 
                    i1 = 0;
                    object2 = object;
                    int i5 = j;
                    j = i1;
                    while (true) {
                      f3 = f2;
                      i2 = i5;
                      Object object4 = object2;
                      i1 = m;
                      j++;
                      i5 = i1;
                    } 
                    continue;
                  } 
                  break;
                  b4++;
                  f2 = f3;
                  j = i2;
                  object = SYNTHETIC_LOCAL_VARIABLE_14;
                  m = i1;
                } 
              } 
            } 
            b2++;
            f2 = f3;
            Object object1 = object2;
            k = i1;
            m = i2;
          } 
          if (k != -1) {
            b b3 = this.f[k];
            b3.a.c = -1;
            f f3 = q;
            if (f3 != null)
              f3.j++; 
            b3.d(this.l.c[m]);
            i i1 = b3.a;
            i1.c = k;
            i1.c(b3);
          } else {
            b1 = 1;
          } 
          if (n > this.i / 2)
            b1 = 1; 
          j = n;
          continue;
        } 
        break;
      } 
    } 
    return k;
  }
  
  private void b(b paramb) {
    paramb.a(this, 0);
  }
  
  private final void c(b paramb) {
    b[] arrayOfB = this.f;
    int j = this.j;
    if (arrayOfB[j] != null)
      this.l.a.a(arrayOfB[j]); 
    arrayOfB = this.f;
    j = this.j;
    arrayOfB[j] = paramb;
    i i1 = paramb.a;
    i1.c = j;
    this.j = j + 1;
    i1.c(paramb);
  }
  
  private final void d(b paramb) {
    if (this.j > 0) {
      paramb.d.a(paramb, this.f);
      if (paramb.d.a == 0)
        paramb.e = true; 
    } 
  }
  
  private void g() {
    for (byte b1 = 0; b1 < this.j; b1++) {
      b b2 = this.f[b1];
      b2.a.e = b2.b;
    } 
  }
  
  public static f h() {
    return q;
  }
  
  private void i() {
    this.d *= 2;
    this.f = Arrays.<b>copyOf(this.f, this.d);
    c c1 = this.l;
    c1.c = Arrays.<i>copyOf(c1.c, this.d);
    int j = this.d;
    this.h = new boolean[j];
    this.e = j;
    this.k = j;
    f f1 = q;
    if (f1 != null) {
      f1.d++;
      f1.o = Math.max(f1.o, j);
      f1 = q;
      f1.A = f1.o;
    } 
  }
  
  private void j() {
    byte b1 = 0;
    while (true) {
      b[] arrayOfB = this.f;
      if (b1 < arrayOfB.length) {
        b b2 = arrayOfB[b1];
        if (b2 != null)
          this.l.a.a(b2); 
        this.f[b1] = null;
        b1++;
        continue;
      } 
      break;
    } 
  }
  
  public b a(i parami1, i parami2, int paramInt1, int paramInt2) {
    b b1 = b();
    b1.a(parami1, parami2, paramInt1);
    if (paramInt2 != 6)
      b1.a(this, paramInt2); 
    a(b1);
    return b1;
  }
  
  public i a() {
    f f1 = q;
    if (f1 != null)
      f1.n++; 
    if (this.i + 1 >= this.e)
      i(); 
    i i1 = a(i.a.e, (String)null);
    this.a++;
    this.i++;
    int j = this.a;
    i1.b = j;
    this.l.c[j] = i1;
    return i1;
  }
  
  public i a(int paramInt, String paramString) {
    f f1 = q;
    if (f1 != null)
      f1.l++; 
    if (this.i + 1 >= this.e)
      i(); 
    i i1 = a(i.a.f, paramString);
    this.a++;
    this.i++;
    int j = this.a;
    i1.b = j;
    i1.d = paramInt;
    this.l.c[j] = i1;
    this.c.a(i1);
    return i1;
  }
  
  public i a(Object paramObject) {
    i i1;
    if (paramObject == null)
      return null; 
    if (this.i + 1 >= this.e)
      i(); 
    null = null;
    if (paramObject instanceof d) {
      null = ((d)paramObject).e();
      i1 = null;
      if (null == null) {
        ((d)paramObject).a(this.l);
        i1 = ((d)paramObject).e();
      } 
      int k = i1.b;
      if (k != -1 && k <= this.a) {
        null = i1;
        if (this.l.c[k] == null) {
          if (i1.b != -1)
            i1.a(); 
          this.a++;
          this.i++;
          k = this.a;
          i1.b = k;
          i1.g = i.a.c;
          this.l.c[k] = i1;
          return i1;
        } 
        return null;
      } 
    } else {
      return null;
    } 
    if (i1.b != -1)
      i1.a(); 
    this.a++;
    this.i++;
    int j = this.a;
    i1.b = j;
    i1.g = i.a.c;
    this.l.c[j] = i1;
    return i1;
  }
  
  public void a(b paramb) {
    if (paramb == null)
      return; 
    f f1 = q;
    if (f1 != null) {
      f1.f++;
      if (paramb.e)
        f1.g++; 
    } 
    if (this.j + 1 >= this.k || this.i + 1 >= this.e)
      i(); 
    boolean bool1 = false;
    boolean bool2 = false;
    if (!paramb.e) {
      d(paramb);
      if (paramb.c())
        return; 
      paramb.a();
      bool1 = bool2;
      if (paramb.a(this)) {
        i i1 = a();
        paramb.a = i1;
        c(paramb);
        bool2 = true;
        this.o.a(paramb);
        a(this.o, true);
        bool1 = bool2;
        if (i1.c == -1) {
          if (paramb.a == i1) {
            i i2 = paramb.c(i1);
            if (i2 != null) {
              f f2 = q;
              if (f2 != null)
                f2.j++; 
              paramb.d(i2);
            } 
          } 
          if (!paramb.e)
            paramb.a.c(paramb); 
          this.j--;
          bool1 = bool2;
        } 
      } 
      if (!paramb.b())
        return; 
    } 
    if (!bool1)
      c(paramb); 
  }
  
  void a(b paramb, int paramInt1, int paramInt2) {
    paramb.a(a(paramInt2, (String)null), paramInt1);
  }
  
  void a(a parama) {
    f f1 = q;
    if (f1 != null) {
      f1.s++;
      f1.t = Math.max(f1.t, this.i);
      f1 = q;
      f1.u = Math.max(f1.u, this.j);
    } 
    d((b)parama);
    b(parama);
    a(parama, false);
    g();
  }
  
  public void a(i parami, int paramInt) {
    int j = parami.c;
    if (parami.c != -1) {
      b b1 = this.f[j];
      if (b1.e) {
        b1.b = paramInt;
      } else if (b1.d.a == 0) {
        b1.e = true;
        b1.b = paramInt;
      } else {
        b1 = b();
        b1.c(parami, paramInt);
        a(b1);
      } 
    } else {
      b b1 = b();
      b1.b(parami, paramInt);
      a(b1);
    } 
  }
  
  public void a(i parami1, i parami2, int paramInt1, float paramFloat, i parami3, i parami4, int paramInt2, int paramInt3) {
    b b1 = b();
    b1.a(parami1, parami2, paramInt1, paramFloat, parami3, parami4, paramInt2);
    if (paramInt3 != 6)
      b1.a(this, paramInt3); 
    a(b1);
  }
  
  public void a(i parami1, i parami2, i parami3, i parami4, float paramFloat, int paramInt) {
    b b1 = b();
    b1.a(parami1, parami2, parami3, parami4, paramFloat);
    if (paramInt != 6)
      b1.a(this, paramInt); 
    a(b1);
  }
  
  public void a(i parami1, i parami2, boolean paramBoolean) {
    b b1 = b();
    i i1 = c();
    i1.d = 0;
    b1.a(parami1, parami2, i1, 0);
    if (paramBoolean)
      a(b1, (int)(-1.0F * b1.d.b(i1)), 1); 
    a(b1);
  }
  
  public void a(e parame1, e parame2, float paramFloat, int paramInt) {
    i i4 = a(parame1.a(d.d.d));
    i i6 = a(parame1.a(d.d.e));
    i i3 = a(parame1.a(d.d.f));
    i i7 = a(parame1.a(d.d.g));
    i i5 = a(parame2.a(d.d.d));
    i i8 = a(parame2.a(d.d.e));
    i i1 = a(parame2.a(d.d.f));
    i i2 = a(parame2.a(d.d.g));
    b b2 = b();
    double d1 = Math.sin(paramFloat);
    double d2 = paramInt;
    Double.isNaN(d2);
    b2.b(i6, i7, i8, i2, (float)(d1 * d2));
    a(b2);
    b b1 = b();
    d1 = Math.cos(paramFloat);
    d2 = paramInt;
    Double.isNaN(d2);
    b1.b(i4, i3, i5, i1, (float)(d1 * d2));
    a(b1);
  }
  
  public int b(Object paramObject) {
    paramObject = ((d)paramObject).e();
    return (paramObject != null) ? (int)(((i)paramObject).e + 0.5F) : 0;
  }
  
  public b b() {
    b b1 = this.l.a.a();
    if (b1 == null) {
      b1 = new b(this.l);
    } else {
      b1.d();
    } 
    i.b();
    return b1;
  }
  
  public void b(i parami1, i parami2, int paramInt1, int paramInt2) {
    b b1 = b();
    i i1 = c();
    i1.d = 0;
    b1.a(parami1, parami2, i1, paramInt1);
    if (paramInt2 != 6)
      a(b1, (int)(-1.0F * b1.d.b(i1)), paramInt2); 
    a(b1);
  }
  
  public void b(i parami1, i parami2, boolean paramBoolean) {
    b b1 = b();
    i i1 = c();
    i1.d = 0;
    b1.b(parami1, parami2, i1, 0);
    if (paramBoolean)
      a(b1, (int)(-1.0F * b1.d.b(i1)), 1); 
    a(b1);
  }
  
  public i c() {
    f f1 = q;
    if (f1 != null)
      f1.m++; 
    if (this.i + 1 >= this.e)
      i(); 
    i i1 = a(i.a.e, (String)null);
    this.a++;
    this.i++;
    int j = this.a;
    i1.b = j;
    this.l.c[j] = i1;
    return i1;
  }
  
  public void c(i parami1, i parami2, int paramInt1, int paramInt2) {
    b b1 = b();
    i i1 = c();
    i1.d = 0;
    b1.b(parami1, parami2, i1, paramInt1);
    if (paramInt2 != 6)
      a(b1, (int)(-1.0F * b1.d.b(i1)), paramInt2); 
    a(b1);
  }
  
  public c d() {
    return this.l;
  }
  
  public void e() {
    f f1 = q;
    if (f1 != null)
      f1.e++; 
    if (this.g) {
      boolean bool1;
      f1 = q;
      if (f1 != null)
        f1.q++; 
      boolean bool2 = true;
      byte b1 = 0;
      while (true) {
        bool1 = bool2;
        if (b1 < this.j) {
          if (!(this.f[b1]).e) {
            bool1 = false;
            break;
          } 
          b1++;
          continue;
        } 
        break;
      } 
      if (!bool1) {
        a(this.c);
      } else {
        f1 = q;
        if (f1 != null)
          f1.p++; 
        g();
      } 
    } else {
      a(this.c);
    } 
  }
  
  public void f() {
    byte b1 = 0;
    while (true) {
      i i1;
      c c1 = this.l;
      i[] arrayOfI = c1.c;
      if (b1 < arrayOfI.length) {
        i1 = arrayOfI[b1];
        if (i1 != null)
          i1.a(); 
        b1++;
        continue;
      } 
      ((c)i1).b.a(this.m, this.n);
      this.n = 0;
      Arrays.fill((Object[])this.l.c, (Object)null);
      HashMap<String, i> hashMap = this.b;
      if (hashMap != null)
        hashMap.clear(); 
      this.a = 0;
      this.c.clear();
      this.i = 1;
      for (b1 = 0; b1 < this.j; b1++)
        (this.f[b1]).c = false; 
      j();
      this.j = 0;
      return;
    } 
  }
  
  static interface a {
    i a(e param1e, boolean[] param1ArrayOfboolean);
    
    void a(a param1a);
    
    void a(i param1i);
    
    void clear();
    
    i getKey();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\i\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */