package android.support.constraint.i;

import java.util.Arrays;

public class i {
  private static int k = 1;
  
  private String a;
  
  public int b = -1;
  
  int c = -1;
  
  public int d = 0;
  
  public float e;
  
  float[] f = new float[7];
  
  a g;
  
  b[] h = new b[8];
  
  int i = 0;
  
  public int j = 0;
  
  public i(a parama, String paramString) {
    this.g = parama;
  }
  
  static void b() {
    k++;
  }
  
  public void a() {
    this.a = null;
    this.g = a.g;
    this.d = 0;
    this.b = -1;
    this.c = -1;
    this.e = 0.0F;
    this.i = 0;
    this.j = 0;
  }
  
  public final void a(b paramb) {
    int j = 0;
    while (true) {
      int k = this.i;
      if (j < k) {
        if (this.h[j] == paramb)
          return; 
        j++;
        continue;
      } 
      b[] arrayOfB = this.h;
      if (k >= arrayOfB.length)
        this.h = Arrays.<b>copyOf(arrayOfB, arrayOfB.length * 2); 
      arrayOfB = this.h;
      j = this.i;
      arrayOfB[j] = paramb;
      this.i = j + 1;
      return;
    } 
  }
  
  public void a(a parama, String paramString) {
    this.g = parama;
  }
  
  public final void b(b paramb) {
    int j = this.i;
    for (byte b1 = 0; b1 < j; b1++) {
      if (this.h[b1] == paramb) {
        for (byte b2 = 0; b2 < j - b1 - 1; b2++) {
          b[] arrayOfB = this.h;
          arrayOfB[b1 + b2] = arrayOfB[b1 + b2 + 1];
        } 
        this.i--;
        return;
      } 
    } 
  }
  
  public final void c(b paramb) {
    int j = this.i;
    for (byte b1 = 0; b1 < j; b1++) {
      b[] arrayOfB = this.h;
      (arrayOfB[b1]).d.a(arrayOfB[b1], paramb, false);
    } 
    this.i = 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("");
    stringBuilder.append(this.a);
    return stringBuilder.toString();
  }
  
  public enum a {
    c, d, e, f, g;
    
    private static final a[] h = new a[] { c, d, e, f, g };
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\i\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */