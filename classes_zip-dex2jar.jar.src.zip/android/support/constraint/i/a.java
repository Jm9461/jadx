package android.support.constraint.i;

import java.util.Arrays;

public class a {
  int a = 0;
  
  private final b b;
  
  private final c c;
  
  private int d = 8;
  
  private i e = null;
  
  private int[] f;
  
  private int[] g;
  
  private float[] h;
  
  private int i;
  
  private int j;
  
  private boolean k;
  
  a(b paramb, c paramc) {
    int j = this.d;
    this.f = new int[j];
    this.g = new int[j];
    this.h = new float[j];
    this.i = -1;
    this.j = -1;
    this.k = false;
    this.b = paramb;
    this.c = paramc;
  }
  
  private boolean a(i parami, e parame) {
    int j = parami.j;
    boolean bool = true;
    if (j > 1)
      bool = false; 
    return bool;
  }
  
  public final float a(i parami, boolean paramBoolean) {
    if (this.e == parami)
      this.e = null; 
    if (this.i == -1)
      return 0.0F; 
    int j = this.i;
    int k = -1;
    for (byte b1 = 0; j != -1 && b1 < this.a; b1++) {
      if (this.f[j] == parami.b) {
        if (j == this.i) {
          this.i = this.g[j];
        } else {
          int[] arrayOfInt = this.g;
          arrayOfInt[k] = arrayOfInt[j];
        } 
        if (paramBoolean)
          parami.b(this.b); 
        parami.j--;
        this.a--;
        this.f[j] = -1;
        if (this.k)
          this.j = j; 
        return this.h[j];
      } 
      k = j;
      j = this.g[j];
    } 
    return 0.0F;
  }
  
  final i a(int paramInt) {
    int j = this.i;
    for (byte b1 = 0; j != -1 && b1 < this.a; b1++) {
      if (b1 == paramInt)
        return this.c.c[this.f[j]]; 
      j = this.g[j];
    } 
    return null;
  }
  
  i a(e parame) {
    i i2;
    float[] arrayOfFloat = null;
    i i1 = null;
    float f2 = 0.0F;
    float f1 = 0.0F;
    boolean bool2 = false;
    boolean bool1 = false;
    int j = this.i;
    byte b1 = 0;
    while (j != -1 && b1 < this.a) {
      i i4;
      float[] arrayOfFloat1 = this.h;
      float f3 = arrayOfFloat1[j];
      i i3 = this.c.c[this.f[j]];
      if (f3 < 0.0F) {
        if (f3 > -0.001F) {
          arrayOfFloat1[j] = 0.0F;
          f3 = 0.0F;
          i3.b(this.b);
        } 
      } else if (f3 < 0.001F) {
        arrayOfFloat1[j] = 0.0F;
        f3 = 0.0F;
        i3.b(this.b);
      } 
      arrayOfFloat1 = arrayOfFloat;
      i i5 = i1;
      float f4 = f2;
      float f5 = f1;
      boolean bool3 = bool2;
      boolean bool4 = bool1;
      if (f3 != 0.0F)
        if (i3.g == i.a.c) {
          if (i1 == null) {
            i5 = i3;
            bool3 = a(i3, parame);
            arrayOfFloat1 = arrayOfFloat;
            f4 = f3;
            f5 = f1;
            bool4 = bool1;
          } else if (f2 > f3) {
            i5 = i3;
            bool3 = a(i3, parame);
            arrayOfFloat1 = arrayOfFloat;
            f4 = f3;
            f5 = f1;
            bool4 = bool1;
          } else {
            arrayOfFloat1 = arrayOfFloat;
            i5 = i1;
            f4 = f2;
            f5 = f1;
            bool3 = bool2;
            bool4 = bool1;
            if (!bool2) {
              arrayOfFloat1 = arrayOfFloat;
              i5 = i1;
              f4 = f2;
              f5 = f1;
              bool3 = bool2;
              bool4 = bool1;
              if (a(i3, parame)) {
                bool3 = true;
                arrayOfFloat1 = arrayOfFloat;
                i5 = i3;
                f4 = f3;
                f5 = f1;
                bool4 = bool1;
              } 
            } 
          } 
        } else {
          arrayOfFloat1 = arrayOfFloat;
          i5 = i1;
          f4 = f2;
          f5 = f1;
          bool3 = bool2;
          bool4 = bool1;
          if (i1 == null) {
            arrayOfFloat1 = arrayOfFloat;
            i5 = i1;
            f4 = f2;
            f5 = f1;
            bool3 = bool2;
            bool4 = bool1;
            if (f3 < 0.0F)
              if (arrayOfFloat == null) {
                i4 = i3;
                bool4 = a(i3, parame);
                i5 = i1;
                f4 = f2;
                f5 = f3;
                bool3 = bool2;
              } else if (f1 > f3) {
                i4 = i3;
                bool4 = a(i3, parame);
                i5 = i1;
                f4 = f2;
                f5 = f3;
                bool3 = bool2;
              } else {
                arrayOfFloat1 = arrayOfFloat;
                i5 = i1;
                f4 = f2;
                f5 = f1;
                bool3 = bool2;
                bool4 = bool1;
                if (!bool1) {
                  arrayOfFloat1 = arrayOfFloat;
                  i5 = i1;
                  f4 = f2;
                  f5 = f1;
                  bool3 = bool2;
                  bool4 = bool1;
                  if (a(i3, parame)) {
                    bool4 = true;
                    bool3 = bool2;
                    f5 = f3;
                    f4 = f2;
                    i5 = i1;
                    i4 = i3;
                  } 
                } 
              }  
          } 
        }  
      j = this.g[j];
      b1++;
      i2 = i4;
      i1 = i5;
      f2 = f4;
      f1 = f5;
      bool2 = bool3;
      bool1 = bool4;
    } 
    return (i1 != null) ? i1 : i2;
  }
  
  i a(boolean[] paramArrayOfboolean, i parami) {
    // Byte code:
    //   0: aload_0
    //   1: getfield i : I
    //   4: istore #7
    //   6: iconst_0
    //   7: istore #6
    //   9: aconst_null
    //   10: astore #8
    //   12: fconst_0
    //   13: fstore_3
    //   14: iload #7
    //   16: iconst_m1
    //   17: if_icmpeq -> 182
    //   20: iload #6
    //   22: aload_0
    //   23: getfield a : I
    //   26: if_icmpge -> 182
    //   29: aload #8
    //   31: astore #9
    //   33: fload_3
    //   34: fstore #4
    //   36: aload_0
    //   37: getfield h : [F
    //   40: iload #7
    //   42: faload
    //   43: fconst_0
    //   44: fcmpg
    //   45: ifge -> 160
    //   48: aload_0
    //   49: getfield c : Landroid/support/constraint/i/c;
    //   52: getfield c : [Landroid/support/constraint/i/i;
    //   55: aload_0
    //   56: getfield f : [I
    //   59: iload #7
    //   61: iaload
    //   62: aaload
    //   63: astore #10
    //   65: aload_1
    //   66: ifnull -> 86
    //   69: aload #8
    //   71: astore #9
    //   73: fload_3
    //   74: fstore #4
    //   76: aload_1
    //   77: aload #10
    //   79: getfield b : I
    //   82: baload
    //   83: ifne -> 160
    //   86: aload #8
    //   88: astore #9
    //   90: fload_3
    //   91: fstore #4
    //   93: aload #10
    //   95: aload_2
    //   96: if_acmpeq -> 160
    //   99: aload #10
    //   101: getfield g : Landroid/support/constraint/i/i$a;
    //   104: astore #11
    //   106: aload #11
    //   108: getstatic android/support/constraint/i/i$a.e : Landroid/support/constraint/i/i$a;
    //   111: if_acmpeq -> 129
    //   114: aload #8
    //   116: astore #9
    //   118: fload_3
    //   119: fstore #4
    //   121: aload #11
    //   123: getstatic android/support/constraint/i/i$a.f : Landroid/support/constraint/i/i$a;
    //   126: if_acmpne -> 160
    //   129: aload_0
    //   130: getfield h : [F
    //   133: iload #7
    //   135: faload
    //   136: fstore #5
    //   138: aload #8
    //   140: astore #9
    //   142: fload_3
    //   143: fstore #4
    //   145: fload #5
    //   147: fload_3
    //   148: fcmpg
    //   149: ifge -> 160
    //   152: fload #5
    //   154: fstore #4
    //   156: aload #10
    //   158: astore #9
    //   160: aload_0
    //   161: getfield g : [I
    //   164: iload #7
    //   166: iaload
    //   167: istore #7
    //   169: iinc #6, 1
    //   172: aload #9
    //   174: astore #8
    //   176: fload #4
    //   178: fstore_3
    //   179: goto -> 14
    //   182: aload #8
    //   184: areturn
  }
  
  public final void a() {
    int j = this.i;
    for (byte b1 = 0; j != -1 && b1 < this.a; b1++) {
      i i1 = this.c.c[this.f[j]];
      if (i1 != null)
        i1.b(this.b); 
      j = this.g[j];
    } 
    this.i = -1;
    this.j = -1;
    this.k = false;
    this.a = 0;
  }
  
  void a(float paramFloat) {
    int j = this.i;
    for (byte b1 = 0; j != -1 && b1 < this.a; b1++) {
      float[] arrayOfFloat = this.h;
      arrayOfFloat[j] = arrayOfFloat[j] / paramFloat;
      j = this.g[j];
    } 
  }
  
  final void a(b paramb1, b paramb2, boolean paramBoolean) {
    int j = this.i;
    for (byte b1 = 0; j != -1 && b1 < this.a; b1++) {
      int k = this.f[j];
      i i1 = paramb2.a;
      if (k == i1.b) {
        float f = this.h[j];
        a(i1, paramBoolean);
        a a1 = paramb2.d;
        j = a1.i;
        for (b1 = 0; j != -1 && b1 < a1.a; b1++) {
          a(this.c.c[a1.f[j]], a1.h[j] * f, paramBoolean);
          j = a1.g[j];
        } 
        paramb1.b += paramb2.b * f;
        if (paramBoolean)
          paramb2.a.b(paramb1); 
        j = this.i;
        b1 = 0;
        continue;
      } 
      j = this.g[j];
    } 
  }
  
  void a(b paramb, b[] paramArrayOfb) {
    int j = this.i;
    for (int k = 0; j != -1 && k < this.a; k++) {
      i i1 = this.c.c[this.f[j]];
      if (i1.c != -1) {
        float f = this.h[j];
        a(i1, true);
        b b1 = paramArrayOfb[i1.c];
        if (!b1.e) {
          a a1 = b1.d;
          k = a1.i;
          for (j = 0; k != -1 && j < a1.a; j++) {
            a(this.c.c[a1.f[k]], a1.h[k] * f, true);
            k = a1.g[k];
          } 
        } 
        paramb.b += b1.b * f;
        b1.a.b(paramb);
        j = this.i;
        k = 0;
        continue;
      } 
      j = this.g[j];
    } 
  }
  
  public final void a(i parami, float paramFloat) {
    if (paramFloat == 0.0F) {
      a(parami, true);
      return;
    } 
    if (this.i == -1) {
      this.i = 0;
      float[] arrayOfFloat = this.h;
      int n = this.i;
      arrayOfFloat[n] = paramFloat;
      this.f[n] = parami.b;
      this.g[n] = -1;
      parami.j++;
      parami.a(this.b);
      this.a++;
      if (!this.k) {
        n = ++this.j;
        arrayOfInt1 = this.f;
        if (n >= arrayOfInt1.length) {
          this.k = true;
          this.j = arrayOfInt1.length - 1;
        } 
      } 
      return;
    } 
    int j = this.i;
    int m = -1;
    int k;
    for (k = 0; j != -1 && k < this.a; k++) {
      int[] arrayOfInt = this.f;
      int i1 = arrayOfInt[j];
      int n = ((i)arrayOfInt1).b;
      if (i1 == n) {
        this.h[j] = paramFloat;
        return;
      } 
      if (arrayOfInt[j] < n)
        m = j; 
      j = this.g[j];
    } 
    k = this.j;
    j = k + 1;
    if (this.k) {
      int[] arrayOfInt = this.f;
      if (arrayOfInt[k] == -1) {
        j = this.j;
      } else {
        j = arrayOfInt.length;
      } 
    } 
    int[] arrayOfInt2 = this.f;
    k = j;
    if (j >= arrayOfInt2.length) {
      k = j;
      if (this.a < arrayOfInt2.length) {
        byte b1 = 0;
        while (true) {
          arrayOfInt2 = this.f;
          k = j;
          if (b1 < arrayOfInt2.length) {
            if (arrayOfInt2[b1] == -1) {
              k = b1;
              break;
            } 
            b1++;
            continue;
          } 
          break;
        } 
      } 
    } 
    arrayOfInt2 = this.f;
    j = k;
    if (k >= arrayOfInt2.length) {
      j = arrayOfInt2.length;
      this.d *= 2;
      this.k = false;
      this.j = j - 1;
      this.h = Arrays.copyOf(this.h, this.d);
      this.f = Arrays.copyOf(this.f, this.d);
      this.g = Arrays.copyOf(this.g, this.d);
    } 
    this.f[j] = ((i)arrayOfInt1).b;
    this.h[j] = paramFloat;
    if (m != -1) {
      arrayOfInt2 = this.g;
      arrayOfInt2[j] = arrayOfInt2[m];
      arrayOfInt2[m] = j;
    } else {
      this.g[j] = this.i;
      this.i = j;
    } 
    ((i)arrayOfInt1).j++;
    arrayOfInt1.a(this.b);
    this.a++;
    if (!this.k)
      this.j++; 
    if (this.a >= this.f.length)
      this.k = true; 
    j = this.j;
    int[] arrayOfInt1 = this.f;
    if (j >= arrayOfInt1.length) {
      this.k = true;
      this.j = arrayOfInt1.length - 1;
    } 
  }
  
  final void a(i parami, float paramFloat, boolean paramBoolean) {
    if (paramFloat == 0.0F)
      return; 
    if (this.i == -1) {
      this.i = 0;
      float[] arrayOfFloat = this.h;
      int n = this.i;
      arrayOfFloat[n] = paramFloat;
      this.f[n] = parami.b;
      this.g[n] = -1;
      parami.j++;
      parami.a(this.b);
      this.a++;
      if (!this.k) {
        n = ++this.j;
        arrayOfInt1 = this.f;
        if (n >= arrayOfInt1.length) {
          this.k = true;
          this.j = arrayOfInt1.length - 1;
        } 
      } 
      return;
    } 
    int j = this.i;
    int m = -1;
    int k;
    for (k = 0; j != -1 && k < this.a; k++) {
      int[] arrayOfInt = this.f;
      int i1 = arrayOfInt[j];
      int n = ((i)arrayOfInt1).b;
      if (i1 == n) {
        float[] arrayOfFloat = this.h;
        arrayOfFloat[j] = arrayOfFloat[j] + paramFloat;
        if (arrayOfFloat[j] == 0.0F) {
          if (j == this.i) {
            this.i = this.g[j];
          } else {
            arrayOfInt = this.g;
            arrayOfInt[m] = arrayOfInt[j];
          } 
          if (paramBoolean)
            arrayOfInt1.b(this.b); 
          if (this.k)
            this.j = j; 
          ((i)arrayOfInt1).j--;
          this.a--;
        } 
        return;
      } 
      if (arrayOfInt[j] < n)
        m = j; 
      j = this.g[j];
    } 
    k = this.j;
    j = k + 1;
    if (this.k) {
      int[] arrayOfInt = this.f;
      if (arrayOfInt[k] == -1) {
        j = this.j;
      } else {
        j = arrayOfInt.length;
      } 
    } 
    int[] arrayOfInt2 = this.f;
    k = j;
    if (j >= arrayOfInt2.length) {
      k = j;
      if (this.a < arrayOfInt2.length) {
        byte b1 = 0;
        while (true) {
          arrayOfInt2 = this.f;
          k = j;
          if (b1 < arrayOfInt2.length) {
            if (arrayOfInt2[b1] == -1) {
              k = b1;
              break;
            } 
            b1++;
            continue;
          } 
          break;
        } 
      } 
    } 
    arrayOfInt2 = this.f;
    j = k;
    if (k >= arrayOfInt2.length) {
      j = arrayOfInt2.length;
      this.d *= 2;
      this.k = false;
      this.j = j - 1;
      this.h = Arrays.copyOf(this.h, this.d);
      this.f = Arrays.copyOf(this.f, this.d);
      this.g = Arrays.copyOf(this.g, this.d);
    } 
    this.f[j] = ((i)arrayOfInt1).b;
    this.h[j] = paramFloat;
    if (m != -1) {
      arrayOfInt2 = this.g;
      arrayOfInt2[j] = arrayOfInt2[m];
      arrayOfInt2[m] = j;
    } else {
      this.g[j] = this.i;
      this.i = j;
    } 
    ((i)arrayOfInt1).j++;
    arrayOfInt1.a(this.b);
    this.a++;
    if (!this.k)
      this.j++; 
    j = this.j;
    int[] arrayOfInt1 = this.f;
    if (j >= arrayOfInt1.length) {
      this.k = true;
      this.j = arrayOfInt1.length - 1;
    } 
  }
  
  final boolean a(i parami) {
    if (this.i == -1)
      return false; 
    int j = this.i;
    for (byte b1 = 0; j != -1 && b1 < this.a; b1++) {
      if (this.f[j] == parami.b)
        return true; 
      j = this.g[j];
    } 
    return false;
  }
  
  final float b(int paramInt) {
    int j = this.i;
    for (byte b1 = 0; j != -1 && b1 < this.a; b1++) {
      if (b1 == paramInt)
        return this.h[j]; 
      j = this.g[j];
    } 
    return 0.0F;
  }
  
  public final float b(i parami) {
    int j = this.i;
    for (byte b1 = 0; j != -1 && b1 < this.a; b1++) {
      if (this.f[j] == parami.b)
        return this.h[j]; 
      j = this.g[j];
    } 
    return 0.0F;
  }
  
  void b() {
    int j = this.i;
    for (byte b1 = 0; j != -1 && b1 < this.a; b1++) {
      float[] arrayOfFloat = this.h;
      arrayOfFloat[j] = arrayOfFloat[j] * -1.0F;
      j = this.g[j];
    } 
  }
  
  public String toString() {
    String str = "";
    int j = this.i;
    for (byte b1 = 0; j != -1 && b1 < this.a; b1++) {
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str);
      stringBuilder2.append(" -> ");
      str = stringBuilder2.toString();
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str);
      stringBuilder2.append(this.h[j]);
      stringBuilder2.append(" : ");
      String str1 = stringBuilder2.toString();
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str1);
      stringBuilder1.append(this.c.c[this.f[j]]);
      str = stringBuilder1.toString();
      j = this.g[j];
    } 
    return str;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\i\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */