package android.support.constraint.i;

public class b implements e.a {
  i a = null;
  
  float b = 0.0F;
  
  boolean c;
  
  public final a d;
  
  boolean e = false;
  
  public b(c paramc) {
    this.d = new a(this, paramc);
  }
  
  public b a(float paramFloat1, float paramFloat2, float paramFloat3, i parami1, i parami2, i parami3, i parami4) {
    this.b = 0.0F;
    if (paramFloat2 == 0.0F || paramFloat1 == paramFloat3) {
      this.d.a(parami1, 1.0F);
      this.d.a(parami2, -1.0F);
      this.d.a(parami4, 1.0F);
      this.d.a(parami3, -1.0F);
      return this;
    } 
    if (paramFloat1 == 0.0F) {
      this.d.a(parami1, 1.0F);
      this.d.a(parami2, -1.0F);
    } else if (paramFloat3 == 0.0F) {
      this.d.a(parami3, 1.0F);
      this.d.a(parami4, -1.0F);
    } else {
      paramFloat1 = paramFloat1 / paramFloat2 / paramFloat3 / paramFloat2;
      this.d.a(parami1, 1.0F);
      this.d.a(parami2, -1.0F);
      this.d.a(parami4, paramFloat1);
      this.d.a(parami3, -paramFloat1);
    } 
    return this;
  }
  
  public b a(e parame, int paramInt) {
    this.d.a(parame.a(paramInt, "ep"), 1.0F);
    this.d.a(parame.a(paramInt, "em"), -1.0F);
    return this;
  }
  
  b a(i parami, int paramInt) {
    this.d.a(parami, paramInt);
    return this;
  }
  
  public b a(i parami1, i parami2, int paramInt) {
    int j = 0;
    boolean bool = false;
    if (paramInt != 0) {
      int k = paramInt;
      paramInt = bool;
      j = k;
      if (k < 0) {
        j = k * -1;
        paramInt = 1;
      } 
      this.b = j;
      j = paramInt;
    } 
    if (j == 0) {
      this.d.a(parami1, -1.0F);
      this.d.a(parami2, 1.0F);
    } else {
      this.d.a(parami1, 1.0F);
      this.d.a(parami2, -1.0F);
    } 
    return this;
  }
  
  b a(i parami1, i parami2, int paramInt1, float paramFloat, i parami3, i parami4, int paramInt2) {
    if (parami2 == parami3) {
      this.d.a(parami1, 1.0F);
      this.d.a(parami4, 1.0F);
      this.d.a(parami2, -2.0F);
      return this;
    } 
    if (paramFloat == 0.5F) {
      this.d.a(parami1, 1.0F);
      this.d.a(parami2, -1.0F);
      this.d.a(parami3, -1.0F);
      this.d.a(parami4, 1.0F);
      if (paramInt1 > 0 || paramInt2 > 0)
        this.b = (-paramInt1 + paramInt2); 
    } else if (paramFloat <= 0.0F) {
      this.d.a(parami1, -1.0F);
      this.d.a(parami2, 1.0F);
      this.b = paramInt1;
    } else if (paramFloat >= 1.0F) {
      this.d.a(parami3, -1.0F);
      this.d.a(parami4, 1.0F);
      this.b = paramInt2;
    } else {
      this.d.a(parami1, (1.0F - paramFloat) * 1.0F);
      this.d.a(parami2, (1.0F - paramFloat) * -1.0F);
      this.d.a(parami3, -1.0F * paramFloat);
      this.d.a(parami4, paramFloat * 1.0F);
      if (paramInt1 > 0 || paramInt2 > 0)
        this.b = -paramInt1 * (1.0F - paramFloat) + paramInt2 * paramFloat; 
    } 
    return this;
  }
  
  b a(i parami1, i parami2, i parami3, float paramFloat) {
    this.d.a(parami1, -1.0F);
    this.d.a(parami2, 1.0F - paramFloat);
    this.d.a(parami3, paramFloat);
    return this;
  }
  
  public b a(i parami1, i parami2, i parami3, int paramInt) {
    int j = 0;
    int k = 0;
    if (paramInt != 0) {
      j = paramInt;
      paramInt = k;
      k = j;
      if (j < 0) {
        k = j * -1;
        paramInt = 1;
      } 
      this.b = k;
      j = paramInt;
    } 
    if (j == 0) {
      this.d.a(parami1, -1.0F);
      this.d.a(parami2, 1.0F);
      this.d.a(parami3, 1.0F);
    } else {
      this.d.a(parami1, 1.0F);
      this.d.a(parami2, -1.0F);
      this.d.a(parami3, -1.0F);
    } 
    return this;
  }
  
  public b a(i parami1, i parami2, i parami3, i parami4, float paramFloat) {
    this.d.a(parami1, -1.0F);
    this.d.a(parami2, 1.0F);
    this.d.a(parami3, paramFloat);
    this.d.a(parami4, -paramFloat);
    return this;
  }
  
  public i a(e parame, boolean[] paramArrayOfboolean) {
    return this.d.a(paramArrayOfboolean, (i)null);
  }
  
  void a() {
    float f = this.b;
    if (f < 0.0F) {
      this.b = f * -1.0F;
      this.d.b();
    } 
  }
  
  public void a(e.a parama) {
    if (parama instanceof b) {
      parama = parama;
      this.a = null;
      this.d.a();
      byte b1 = 0;
      while (true) {
        a a1 = ((b)parama).d;
        if (b1 < a1.a) {
          i i1 = a1.a(b1);
          float f = ((b)parama).d.b(b1);
          this.d.a(i1, f, true);
          b1++;
          continue;
        } 
        break;
      } 
    } 
  }
  
  public void a(i parami) {
    float f = 1.0F;
    int j = parami.d;
    if (j == 1) {
      f = 1.0F;
    } else if (j == 2) {
      f = 1000.0F;
    } else if (j == 3) {
      f = 1000000.0F;
    } else if (j == 4) {
      f = 1.0E9F;
    } else if (j == 5) {
      f = 1.0E12F;
    } 
    this.d.a(parami, f);
  }
  
  boolean a(e parame) {
    boolean bool = false;
    i i1 = this.d.a(parame);
    if (i1 == null) {
      bool = true;
    } else {
      d(i1);
    } 
    if (this.d.a == 0)
      this.e = true; 
    return bool;
  }
  
  b b(i parami, int paramInt) {
    this.a = parami;
    parami.e = paramInt;
    this.b = paramInt;
    this.e = true;
    return this;
  }
  
  public b b(i parami1, i parami2, i parami3, int paramInt) {
    int j = 0;
    boolean bool = false;
    if (paramInt != 0) {
      int k = paramInt;
      paramInt = bool;
      j = k;
      if (k < 0) {
        j = k * -1;
        paramInt = 1;
      } 
      this.b = j;
      j = paramInt;
    } 
    if (j == 0) {
      this.d.a(parami1, -1.0F);
      this.d.a(parami2, 1.0F);
      this.d.a(parami3, -1.0F);
    } else {
      this.d.a(parami1, 1.0F);
      this.d.a(parami2, -1.0F);
      this.d.a(parami3, 1.0F);
    } 
    return this;
  }
  
  public b b(i parami1, i parami2, i parami3, i parami4, float paramFloat) {
    this.d.a(parami3, 0.5F);
    this.d.a(parami4, 0.5F);
    this.d.a(parami1, -0.5F);
    this.d.a(parami2, -0.5F);
    this.b = -paramFloat;
    return this;
  }
  
  boolean b() {
    boolean bool;
    i i1 = this.a;
    if (i1 != null && (i1.g == i.a.c || this.b >= 0.0F)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  boolean b(i parami) {
    return this.d.a(parami);
  }
  
  public b c(i parami, int paramInt) {
    if (paramInt < 0) {
      this.b = (paramInt * -1);
      this.d.a(parami, 1.0F);
    } else {
      this.b = paramInt;
      this.d.a(parami, -1.0F);
    } 
    return this;
  }
  
  i c(i parami) {
    return this.d.a((boolean[])null, parami);
  }
  
  public boolean c() {
    boolean bool;
    if (this.a == null && this.b == 0.0F && this.d.a == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void clear() {
    this.d.a();
    this.a = null;
    this.b = 0.0F;
  }
  
  public void d() {
    this.a = null;
    this.d.a();
    this.b = 0.0F;
    this.e = false;
  }
  
  void d(i parami) {
    i i1 = this.a;
    if (i1 != null) {
      this.d.a(i1, -1.0F);
      this.a = null;
    } 
    float f = this.d.a(parami, true) * -1.0F;
    this.a = parami;
    if (f == 1.0F)
      return; 
    this.b /= f;
    this.d.a(f);
  }
  
  String e() {
    if (this.a == null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("");
      stringBuilder1.append("0");
      str1 = stringBuilder1.toString();
    } else {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("");
      stringBuilder1.append(this.a);
      str1 = stringBuilder1.toString();
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(str1);
    stringBuilder.append(" = ");
    String str2 = stringBuilder.toString();
    boolean bool = false;
    String str1 = str2;
    if (this.b != 0.0F) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str2);
      stringBuilder1.append(this.b);
      str1 = stringBuilder1.toString();
      bool = true;
    } 
    int j = this.d.a;
    for (byte b1 = 0; b1 < j; b1++) {
      i i1 = this.d.a(b1);
      if (i1 != null) {
        float f = this.d.b(b1);
        if (f != 0.0F) {
          float f1;
          String str3;
          String str4 = i1.toString();
          if (!bool) {
            str3 = str1;
            f1 = f;
            if (f < 0.0F) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append(str1);
              stringBuilder1.append("- ");
              String str = stringBuilder1.toString();
              f1 = f * -1.0F;
            } 
          } else if (f > 0.0F) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append(str1);
            stringBuilder1.append(" + ");
            str3 = stringBuilder1.toString();
            f1 = f;
          } else {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append(str1);
            stringBuilder1.append(" - ");
            str3 = stringBuilder1.toString();
            f1 = f * -1.0F;
          } 
          if (f1 == 1.0F) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append(str3);
            stringBuilder1.append(str4);
            String str = stringBuilder1.toString();
          } else {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append(str3);
            stringBuilder1.append(f1);
            stringBuilder1.append(" ");
            stringBuilder1.append(str4);
            str1 = stringBuilder1.toString();
          } 
          bool = true;
        } 
      } 
    } 
    str2 = str1;
    if (!bool) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str1);
      stringBuilder1.append("0.0");
      str2 = stringBuilder1.toString();
    } 
    return str2;
  }
  
  public i getKey() {
    return this.a;
  }
  
  public String toString() {
    return e();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\i\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */