package android.support.constraint.i.j;

import android.support.constraint.i.e;
import java.io.PrintStream;
import java.util.Arrays;

public class f extends o {
  private boolean f0 = false;
  
  protected e g0 = new e();
  
  private n h0;
  
  int i0;
  
  int j0;
  
  int k0;
  
  int l0;
  
  int m0 = 0;
  
  int n0 = 0;
  
  c[] o0 = new c[4];
  
  c[] p0 = new c[4];
  
  private int q0 = 3;
  
  private boolean r0 = false;
  
  private boolean s0 = false;
  
  private void T() {
    this.m0 = 0;
    this.n0 = 0;
  }
  
  private void d(e parame) {
    int i = this.m0;
    c[] arrayOfC = this.p0;
    if (i + 1 >= arrayOfC.length)
      this.p0 = Arrays.<c>copyOf(arrayOfC, arrayOfC.length * 2); 
    this.p0[this.m0] = new c(parame, 0, N());
    this.m0++;
  }
  
  private void e(e parame) {
    int i = this.n0;
    c[] arrayOfC = this.o0;
    if (i + 1 >= arrayOfC.length)
      this.o0 = Arrays.<c>copyOf(arrayOfC, arrayOfC.length * 2); 
    this.o0[this.n0] = new c(parame, 1, N());
    this.n0++;
  }
  
  public void B() {
    this.g0.f();
    this.i0 = 0;
    this.k0 = 0;
    this.j0 = 0;
    this.l0 = 0;
    super.B();
  }
  
  public void I() {
    int m = this.H;
    int i2 = this.I;
    int i3 = Math.max(0, t());
    int k = Math.max(0, i());
    this.r0 = false;
    this.s0 = false;
    if (this.C != null) {
      if (this.h0 == null)
        this.h0 = new n(this); 
      this.h0.b(this);
      n(this.i0);
      o(this.j0);
      C();
      a(this.g0.d());
    } else {
      this.H = 0;
      this.I = 0;
    } 
    if (this.q0 != 0) {
      if (!p(8))
        Q(); 
      P();
      this.g0.g = true;
    } else {
      this.g0.g = false;
    } 
    e.b[] arrayOfB = this.B;
    e.b b1 = arrayOfB[1];
    e.b b2 = arrayOfB[0];
    T();
    int i1 = this.e0.size();
    int i;
    for (i = 0; i < i1; i++) {
      e e1 = this.e0.get(i);
      if (e1 instanceof o)
        ((o)e1).I(); 
    } 
    boolean bool = true;
    int j = 0;
    i = 0;
    while (bool) {
      int i5 = j + 1;
      boolean bool1 = bool;
      try {
        this.g0.f();
        bool1 = bool;
        b(this.g0);
        for (j = 0; j < i1; j++) {
          bool1 = bool;
          ((e)this.e0.get(j)).b(this.g0);
        } 
        bool1 = bool;
        bool = d(this.g0);
        if (bool) {
          bool1 = bool;
          this.g0.e();
        } 
        bool1 = bool;
      } catch (Exception exception) {
        exception.printStackTrace();
        PrintStream printStream = System.out;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("EXCEPTION : ");
        stringBuilder.append(exception);
        printStream.println(stringBuilder.toString());
      } 
      if (bool1) {
        a(this.g0, i.a);
      } else {
        c(this.g0);
        for (j = 0; j < i1; j++) {
          e e1 = this.e0.get(j);
          if (e1.B[0] == e.b.e && e1.t() < e1.v()) {
            i.a[2] = true;
            break;
          } 
          if (e1.B[1] == e.b.e && e1.i() < e1.u()) {
            i.a[2] = true;
            break;
          } 
        } 
      } 
      bool = false;
      boolean bool2 = false;
      bool1 = bool;
      j = i;
      if (i5 < 8) {
        bool1 = bool;
        j = i;
        if (i.a[2]) {
          int i7 = 0;
          j = 0;
          int i6;
          for (i6 = 0; i6 < i1; i6++) {
            e e1 = this.e0.get(i6);
            i7 = Math.max(i7, e1.H + e1.t());
            j = Math.max(j, e1.I + e1.i());
          } 
          int i8 = Math.max(this.O, i7);
          i7 = Math.max(this.P, j);
          bool = bool2;
          i6 = i;
          if (b2 == e.b.d) {
            bool = bool2;
            i6 = i;
            if (t() < i8) {
              k(i8);
              this.B[0] = e.b.d;
              i6 = 1;
              bool = true;
            } 
          } 
          bool1 = bool;
          j = i6;
          if (b1 == e.b.d) {
            bool1 = bool;
            j = i6;
            if (i() < i7) {
              c(i7);
              this.B[1] = e.b.d;
              j = 1;
              bool1 = true;
            } 
          } 
        } 
      } 
      int i4 = Math.max(this.O, t());
      i = j;
      if (i4 > t()) {
        k(i4);
        this.B[0] = e.b.c;
        i = 1;
        bool1 = true;
      } 
      j = Math.max(this.P, i());
      if (j > i()) {
        c(j);
        this.B[1] = e.b.c;
        i = 1;
        bool1 = true;
      } 
      if (i == 0) {
        bool = bool1;
        j = i;
        if (this.B[0] == e.b.d) {
          bool = bool1;
          j = i;
          if (i3 > 0) {
            bool = bool1;
            j = i;
            if (t() > i3) {
              this.r0 = true;
              j = 1;
              this.B[0] = e.b.c;
              k(i3);
              bool = true;
            } 
          } 
        } 
        if (this.B[1] == e.b.d && k > 0 && i() > k) {
          this.s0 = true;
          this.B[1] = e.b.c;
          c(k);
          bool1 = true;
          i = 1;
        } else {
          bool1 = bool;
          i = j;
        } 
      } 
      bool = bool1;
      j = i5;
    } 
    if (this.C != null) {
      j = Math.max(this.O, t());
      int i4 = Math.max(this.P, i());
      this.h0.a(this);
      k(this.i0 + j + this.k0);
      c(this.j0 + i4 + this.l0);
    } else {
      this.H = m;
      this.I = i2;
    } 
    if (i != 0) {
      e.b[] arrayOfB1 = this.B;
      arrayOfB1[0] = b2;
      arrayOfB1[1] = b1;
    } 
    a(this.g0.d());
    if (this == H())
      F(); 
  }
  
  public int K() {
    return this.q0;
  }
  
  public boolean L() {
    return false;
  }
  
  public boolean M() {
    return this.s0;
  }
  
  public boolean N() {
    return this.f0;
  }
  
  public boolean O() {
    return this.r0;
  }
  
  public void P() {
    if (!p(8))
      a(this.q0); 
    S();
  }
  
  public void Q() {
    int i = this.e0.size();
    D();
    for (byte b = 0; b < i; b++)
      ((e)this.e0.get(b)).D(); 
  }
  
  public void R() {
    Q();
    a(this.q0);
  }
  
  public void S() {
    k k2 = a(d.d.d).d();
    k k1 = a(d.d.e).d();
    k2.a((k)null, 0.0F);
    k1.a((k)null, 0.0F);
  }
  
  public void a(int paramInt) {
    super.a(paramInt);
    int i = this.e0.size();
    for (byte b = 0; b < i; b++)
      ((e)this.e0.get(b)).a(paramInt); 
  }
  
  public void a(e parame, boolean[] paramArrayOfboolean) {
    paramArrayOfboolean[2] = false;
    c(parame);
    int i = this.e0.size();
    for (byte b = 0; b < i; b++) {
      e e1 = this.e0.get(b);
      e1.c(parame);
      if (e1.B[0] == e.b.e && e1.t() < e1.v())
        paramArrayOfboolean[2] = true; 
      if (e1.B[1] == e.b.e && e1.i() < e1.u())
        paramArrayOfboolean[2] = true; 
    } 
  }
  
  void a(e parame, int paramInt) {
    if (paramInt == 0) {
      d(parame);
    } else if (paramInt == 1) {
      e(parame);
    } 
  }
  
  public void c(boolean paramBoolean) {
    this.f0 = paramBoolean;
  }
  
  public boolean d(e parame) {
    a(parame);
    int i = this.e0.size();
    for (byte b = 0; b < i; b++) {
      e e1 = this.e0.get(b);
      if (e1 instanceof f) {
        e.b[] arrayOfB = e1.B;
        e.b b1 = arrayOfB[0];
        e.b b2 = arrayOfB[1];
        if (b1 == e.b.d)
          e1.a(e.b.c); 
        if (b2 == e.b.d)
          e1.b(e.b.c); 
        e1.a(parame);
        if (b1 == e.b.d)
          e1.a(b1); 
        if (b2 == e.b.d)
          e1.b(b2); 
      } else {
        i.a(this, parame, e1);
        e1.a(parame);
      } 
    } 
    if (this.m0 > 0)
      b.a(this, parame, 0); 
    if (this.n0 > 0)
      b.a(this, parame, 1); 
    return true;
  }
  
  public void e(int paramInt1, int paramInt2) {
    if (this.B[0] != e.b.d) {
      l l = this.c;
      if (l != null)
        l.a(paramInt1); 
    } 
    if (this.B[1] != e.b.d) {
      l l = this.d;
      if (l != null)
        l.a(paramInt2); 
    } 
  }
  
  public boolean p(int paramInt) {
    boolean bool;
    if ((this.q0 & paramInt) == paramInt) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void q(int paramInt) {
    this.q0 = paramInt;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\i\j\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */