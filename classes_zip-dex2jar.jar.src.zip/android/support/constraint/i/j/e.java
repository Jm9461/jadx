package android.support.constraint.i.j;

import android.support.constraint.i.c;
import android.support.constraint.i.i;
import java.util.ArrayList;

public class e {
  public static float d0 = 0.5F;
  
  protected ArrayList<d> A = new ArrayList<d>();
  
  protected b[] B;
  
  e C;
  
  int D;
  
  int E;
  
  protected float F;
  
  protected int G;
  
  protected int H;
  
  protected int I;
  
  private int J;
  
  private int K;
  
  protected int L;
  
  protected int M;
  
  int N;
  
  protected int O;
  
  protected int P;
  
  private int Q;
  
  private int R;
  
  float S;
  
  float T;
  
  private Object U;
  
  private int V;
  
  private String W;
  
  private String X;
  
  int Y;
  
  int Z;
  
  public int a = -1;
  
  float[] a0;
  
  public int b = -1;
  
  protected e[] b0;
  
  l c;
  
  protected e[] c0;
  
  l d;
  
  int e = 0;
  
  int f = 0;
  
  int[] g = new int[2];
  
  int h = 0;
  
  int i = 0;
  
  float j = 1.0F;
  
  int k = 0;
  
  int l = 0;
  
  float m = 1.0F;
  
  int n = -1;
  
  float o = 1.0F;
  
  private int[] p = new int[] { Integer.MAX_VALUE, Integer.MAX_VALUE };
  
  private float q = 0.0F;
  
  d r = new d(this, d.d.d);
  
  d s = new d(this, d.d.e);
  
  d t = new d(this, d.d.f);
  
  d u = new d(this, d.d.g);
  
  d v = new d(this, d.d.h);
  
  d w = new d(this, d.d.j);
  
  d x = new d(this, d.d.k);
  
  d y = new d(this, d.d.i);
  
  protected d[] z = new d[] { this.r, this.t, this.s, this.u, this.v, this.y };
  
  public e() {
    b b1 = b.c;
    this.B = new b[] { b1, b1 };
    this.C = null;
    this.D = 0;
    this.E = 0;
    this.F = 0.0F;
    this.G = -1;
    this.H = 0;
    this.I = 0;
    this.J = 0;
    this.K = 0;
    this.L = 0;
    this.M = 0;
    this.N = 0;
    float f = d0;
    this.S = f;
    this.T = f;
    this.V = 0;
    this.W = null;
    this.X = null;
    this.Y = 0;
    this.Z = 0;
    this.a0 = new float[] { -1.0F, -1.0F };
    this.b0 = new e[] { null, null };
    this.c0 = new e[] { null, null };
    H();
  }
  
  private void H() {
    this.A.add(this.r);
    this.A.add(this.s);
    this.A.add(this.t);
    this.A.add(this.u);
    this.A.add(this.w);
    this.A.add(this.x);
    this.A.add(this.y);
    this.A.add(this.v);
  }
  
  private void a(android.support.constraint.i.e parame, boolean paramBoolean1, i parami1, i parami2, b paramb, boolean paramBoolean2, d paramd1, d paramd2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, boolean paramBoolean3, boolean paramBoolean4, int paramInt5, int paramInt6, int paramInt7, float paramFloat2, boolean paramBoolean5) {
    // Byte code:
    //   0: aload_1
    //   1: aload #7
    //   3: invokevirtual a : (Ljava/lang/Object;)Landroid/support/constraint/i/i;
    //   6: astore #30
    //   8: aload_1
    //   9: aload #8
    //   11: invokevirtual a : (Ljava/lang/Object;)Landroid/support/constraint/i/i;
    //   14: astore #28
    //   16: aload_1
    //   17: aload #7
    //   19: invokevirtual g : ()Landroid/support/constraint/i/j/d;
    //   22: invokevirtual a : (Ljava/lang/Object;)Landroid/support/constraint/i/i;
    //   25: astore #31
    //   27: aload_1
    //   28: aload #8
    //   30: invokevirtual g : ()Landroid/support/constraint/i/j/d;
    //   33: invokevirtual a : (Ljava/lang/Object;)Landroid/support/constraint/i/i;
    //   36: astore #32
    //   38: aload_1
    //   39: getfield g : Z
    //   42: ifeq -> 128
    //   45: aload #7
    //   47: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   50: getfield b : I
    //   53: iconst_1
    //   54: if_icmpne -> 128
    //   57: aload #8
    //   59: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   62: getfield b : I
    //   65: iconst_1
    //   66: if_icmpne -> 128
    //   69: invokestatic h : ()Landroid/support/constraint/i/f;
    //   72: ifnull -> 89
    //   75: invokestatic h : ()Landroid/support/constraint/i/f;
    //   78: astore_3
    //   79: aload_3
    //   80: aload_3
    //   81: getfield r : J
    //   84: lconst_1
    //   85: ladd
    //   86: putfield r : J
    //   89: aload #7
    //   91: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   94: aload_1
    //   95: invokevirtual a : (Landroid/support/constraint/i/e;)V
    //   98: aload #8
    //   100: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   103: aload_1
    //   104: invokevirtual a : (Landroid/support/constraint/i/e;)V
    //   107: iload #15
    //   109: ifne -> 127
    //   112: iload_2
    //   113: ifeq -> 127
    //   116: aload_1
    //   117: aload #4
    //   119: aload #28
    //   121: iconst_0
    //   122: bipush #6
    //   124: invokevirtual b : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   127: return
    //   128: invokestatic h : ()Landroid/support/constraint/i/f;
    //   131: ifnull -> 151
    //   134: invokestatic h : ()Landroid/support/constraint/i/f;
    //   137: astore #29
    //   139: aload #29
    //   141: aload #29
    //   143: getfield z : J
    //   146: lconst_1
    //   147: ladd
    //   148: putfield z : J
    //   151: aload #7
    //   153: invokevirtual i : ()Z
    //   156: istore #25
    //   158: aload #8
    //   160: invokevirtual i : ()Z
    //   163: istore #26
    //   165: aload_0
    //   166: getfield y : Landroid/support/constraint/i/j/d;
    //   169: invokevirtual i : ()Z
    //   172: istore #27
    //   174: iconst_0
    //   175: istore #22
    //   177: iload #25
    //   179: ifeq -> 187
    //   182: iconst_0
    //   183: iconst_1
    //   184: iadd
    //   185: istore #22
    //   187: iload #22
    //   189: istore #21
    //   191: iload #26
    //   193: ifeq -> 202
    //   196: iload #22
    //   198: iconst_1
    //   199: iadd
    //   200: istore #21
    //   202: iload #21
    //   204: istore #22
    //   206: iload #27
    //   208: ifeq -> 217
    //   211: iload #21
    //   213: iconst_1
    //   214: iadd
    //   215: istore #22
    //   217: iload #14
    //   219: ifeq -> 228
    //   222: iconst_3
    //   223: istore #21
    //   225: goto -> 232
    //   228: iload #16
    //   230: istore #21
    //   232: getstatic android/support/constraint/i/j/e$a.b : [I
    //   235: aload #5
    //   237: invokevirtual ordinal : ()I
    //   240: iaload
    //   241: istore #16
    //   243: iload #16
    //   245: iconst_1
    //   246: if_icmpeq -> 303
    //   249: iload #16
    //   251: iconst_2
    //   252: if_icmpeq -> 297
    //   255: iload #16
    //   257: iconst_3
    //   258: if_icmpeq -> 291
    //   261: iload #16
    //   263: iconst_4
    //   264: if_icmpeq -> 273
    //   267: iconst_0
    //   268: istore #16
    //   270: goto -> 306
    //   273: iload #21
    //   275: iconst_4
    //   276: if_icmpne -> 285
    //   279: iconst_0
    //   280: istore #16
    //   282: goto -> 306
    //   285: iconst_1
    //   286: istore #16
    //   288: goto -> 306
    //   291: iconst_0
    //   292: istore #16
    //   294: goto -> 306
    //   297: iconst_0
    //   298: istore #16
    //   300: goto -> 306
    //   303: iconst_0
    //   304: istore #16
    //   306: aload_0
    //   307: getfield V : I
    //   310: bipush #8
    //   312: if_icmpne -> 324
    //   315: iconst_0
    //   316: istore #10
    //   318: iconst_0
    //   319: istore #16
    //   321: goto -> 324
    //   324: iload #20
    //   326: ifeq -> 381
    //   329: iload #25
    //   331: ifne -> 355
    //   334: iload #26
    //   336: ifne -> 355
    //   339: iload #27
    //   341: ifne -> 355
    //   344: aload_1
    //   345: aload #30
    //   347: iload #9
    //   349: invokevirtual a : (Landroid/support/constraint/i/i;I)V
    //   352: goto -> 381
    //   355: iload #25
    //   357: ifeq -> 381
    //   360: iload #26
    //   362: ifne -> 381
    //   365: aload_1
    //   366: aload #30
    //   368: aload #31
    //   370: aload #7
    //   372: invokevirtual b : ()I
    //   375: bipush #6
    //   377: invokevirtual a : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)Landroid/support/constraint/i/b;
    //   380: pop
    //   381: iload #16
    //   383: ifne -> 476
    //   386: iload #6
    //   388: ifeq -> 444
    //   391: aload_1
    //   392: aload #28
    //   394: aload #30
    //   396: iconst_0
    //   397: iconst_3
    //   398: invokevirtual a : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)Landroid/support/constraint/i/b;
    //   401: pop
    //   402: iload #11
    //   404: ifle -> 422
    //   407: aload_1
    //   408: aload #28
    //   410: aload #30
    //   412: iload #11
    //   414: bipush #6
    //   416: invokevirtual b : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   419: goto -> 422
    //   422: iload #12
    //   424: ldc 2147483647
    //   426: if_icmpge -> 457
    //   429: aload_1
    //   430: aload #28
    //   432: aload #30
    //   434: iload #12
    //   436: bipush #6
    //   438: invokevirtual c : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   441: goto -> 457
    //   444: aload_1
    //   445: aload #28
    //   447: aload #30
    //   449: iload #10
    //   451: bipush #6
    //   453: invokevirtual a : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)Landroid/support/constraint/i/b;
    //   456: pop
    //   457: iload #17
    //   459: istore #12
    //   461: iload #10
    //   463: istore #24
    //   465: iload #18
    //   467: istore #10
    //   469: iload #16
    //   471: istore #9
    //   473: goto -> 934
    //   476: iload #17
    //   478: istore #9
    //   480: iload #17
    //   482: bipush #-2
    //   484: if_icmpne -> 491
    //   487: iload #10
    //   489: istore #9
    //   491: iload #18
    //   493: istore #12
    //   495: iload #18
    //   497: bipush #-2
    //   499: if_icmpne -> 506
    //   502: iload #10
    //   504: istore #12
    //   506: iload #10
    //   508: istore #17
    //   510: iload #9
    //   512: ifle -> 555
    //   515: iload_2
    //   516: ifeq -> 534
    //   519: aload_1
    //   520: aload #28
    //   522: aload #30
    //   524: iload #9
    //   526: bipush #6
    //   528: invokevirtual b : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   531: goto -> 546
    //   534: aload_1
    //   535: aload #28
    //   537: aload #30
    //   539: iload #9
    //   541: bipush #6
    //   543: invokevirtual b : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   546: iload #10
    //   548: iload #9
    //   550: invokestatic max : (II)I
    //   553: istore #17
    //   555: iload #12
    //   557: ifle -> 602
    //   560: iload_2
    //   561: ifeq -> 578
    //   564: aload_1
    //   565: aload #28
    //   567: aload #30
    //   569: iload #12
    //   571: iconst_1
    //   572: invokevirtual c : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   575: goto -> 590
    //   578: aload_1
    //   579: aload #28
    //   581: aload #30
    //   583: iload #12
    //   585: bipush #6
    //   587: invokevirtual c : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   590: iload #17
    //   592: iload #12
    //   594: invokestatic min : (II)I
    //   597: istore #10
    //   599: goto -> 606
    //   602: iload #17
    //   604: istore #10
    //   606: iload #21
    //   608: iconst_1
    //   609: if_icmpne -> 667
    //   612: iload_2
    //   613: ifeq -> 632
    //   616: aload_1
    //   617: aload #28
    //   619: aload #30
    //   621: iload #10
    //   623: bipush #6
    //   625: invokevirtual a : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)Landroid/support/constraint/i/b;
    //   628: pop
    //   629: goto -> 799
    //   632: iload #15
    //   634: ifeq -> 652
    //   637: aload_1
    //   638: aload #28
    //   640: aload #30
    //   642: iload #10
    //   644: iconst_4
    //   645: invokevirtual a : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)Landroid/support/constraint/i/b;
    //   648: pop
    //   649: goto -> 799
    //   652: aload_1
    //   653: aload #28
    //   655: aload #30
    //   657: iload #10
    //   659: iconst_1
    //   660: invokevirtual a : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)Landroid/support/constraint/i/b;
    //   663: pop
    //   664: goto -> 799
    //   667: iload #21
    //   669: iconst_2
    //   670: if_icmpne -> 799
    //   673: aload #7
    //   675: invokevirtual h : ()Landroid/support/constraint/i/j/d$d;
    //   678: getstatic android/support/constraint/i/j/d$d.e : Landroid/support/constraint/i/j/d$d;
    //   681: if_acmpeq -> 733
    //   684: aload #7
    //   686: invokevirtual h : ()Landroid/support/constraint/i/j/d$d;
    //   689: getstatic android/support/constraint/i/j/d$d.g : Landroid/support/constraint/i/j/d$d;
    //   692: if_acmpne -> 698
    //   695: goto -> 733
    //   698: aload_1
    //   699: aload_0
    //   700: getfield C : Landroid/support/constraint/i/j/e;
    //   703: getstatic android/support/constraint/i/j/d$d.d : Landroid/support/constraint/i/j/d$d;
    //   706: invokevirtual a : (Landroid/support/constraint/i/j/d$d;)Landroid/support/constraint/i/j/d;
    //   709: invokevirtual a : (Ljava/lang/Object;)Landroid/support/constraint/i/i;
    //   712: astore #5
    //   714: aload_1
    //   715: aload_0
    //   716: getfield C : Landroid/support/constraint/i/j/e;
    //   719: getstatic android/support/constraint/i/j/d$d.f : Landroid/support/constraint/i/j/d$d;
    //   722: invokevirtual a : (Landroid/support/constraint/i/j/d$d;)Landroid/support/constraint/i/j/d;
    //   725: invokevirtual a : (Ljava/lang/Object;)Landroid/support/constraint/i/i;
    //   728: astore #29
    //   730: goto -> 765
    //   733: aload_1
    //   734: aload_0
    //   735: getfield C : Landroid/support/constraint/i/j/e;
    //   738: getstatic android/support/constraint/i/j/d$d.e : Landroid/support/constraint/i/j/d$d;
    //   741: invokevirtual a : (Landroid/support/constraint/i/j/d$d;)Landroid/support/constraint/i/j/d;
    //   744: invokevirtual a : (Ljava/lang/Object;)Landroid/support/constraint/i/i;
    //   747: astore #5
    //   749: aload_1
    //   750: aload_0
    //   751: getfield C : Landroid/support/constraint/i/j/e;
    //   754: getstatic android/support/constraint/i/j/d$d.g : Landroid/support/constraint/i/j/d$d;
    //   757: invokevirtual a : (Landroid/support/constraint/i/j/d$d;)Landroid/support/constraint/i/j/d;
    //   760: invokevirtual a : (Ljava/lang/Object;)Landroid/support/constraint/i/i;
    //   763: astore #29
    //   765: aload_1
    //   766: invokevirtual b : ()Landroid/support/constraint/i/b;
    //   769: astore #33
    //   771: aload #33
    //   773: aload #28
    //   775: aload #30
    //   777: aload #29
    //   779: aload #5
    //   781: fload #19
    //   783: invokevirtual a : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;F)Landroid/support/constraint/i/b;
    //   786: pop
    //   787: aload_1
    //   788: aload #33
    //   790: invokevirtual a : (Landroid/support/constraint/i/b;)V
    //   793: iconst_0
    //   794: istore #16
    //   796: goto -> 799
    //   799: iload #10
    //   801: istore #17
    //   803: iload #12
    //   805: istore #18
    //   807: iload #9
    //   809: istore #23
    //   811: iload #23
    //   813: istore #12
    //   815: iload #18
    //   817: istore #10
    //   819: iload #17
    //   821: istore #24
    //   823: iload #16
    //   825: istore #9
    //   827: iload #16
    //   829: ifeq -> 934
    //   832: iload #23
    //   834: istore #12
    //   836: iload #18
    //   838: istore #10
    //   840: iload #17
    //   842: istore #24
    //   844: iload #16
    //   846: istore #9
    //   848: iload #22
    //   850: iconst_2
    //   851: if_icmpeq -> 934
    //   854: iload #23
    //   856: istore #12
    //   858: iload #18
    //   860: istore #10
    //   862: iload #17
    //   864: istore #24
    //   866: iload #16
    //   868: istore #9
    //   870: iload #14
    //   872: ifne -> 934
    //   875: iconst_0
    //   876: istore #10
    //   878: iload #23
    //   880: iload #17
    //   882: invokestatic max : (II)I
    //   885: istore #12
    //   887: iload #12
    //   889: istore #9
    //   891: iload #18
    //   893: ifle -> 905
    //   896: iload #18
    //   898: iload #12
    //   900: invokestatic min : (II)I
    //   903: istore #9
    //   905: aload_1
    //   906: aload #28
    //   908: aload #30
    //   910: iload #9
    //   912: bipush #6
    //   914: invokevirtual a : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)Landroid/support/constraint/i/b;
    //   917: pop
    //   918: iload #10
    //   920: istore #9
    //   922: iload #17
    //   924: istore #24
    //   926: iload #18
    //   928: istore #10
    //   930: iload #23
    //   932: istore #12
    //   934: iload #20
    //   936: ifeq -> 1481
    //   939: iload #15
    //   941: ifeq -> 947
    //   944: goto -> 1481
    //   947: iload #25
    //   949: ifne -> 988
    //   952: iload #26
    //   954: ifne -> 988
    //   957: iload #27
    //   959: ifne -> 988
    //   962: iload_2
    //   963: ifeq -> 982
    //   966: aload_1
    //   967: aload #4
    //   969: aload #28
    //   971: iconst_0
    //   972: iconst_5
    //   973: invokevirtual b : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   976: aload #28
    //   978: astore_3
    //   979: goto -> 1465
    //   982: aload #28
    //   984: astore_3
    //   985: goto -> 1465
    //   988: iload #25
    //   990: ifeq -> 1024
    //   993: iload #26
    //   995: ifne -> 1024
    //   998: iload_2
    //   999: ifeq -> 1018
    //   1002: aload_1
    //   1003: aload #4
    //   1005: aload #28
    //   1007: iconst_0
    //   1008: iconst_5
    //   1009: invokevirtual b : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   1012: aload #28
    //   1014: astore_3
    //   1015: goto -> 1465
    //   1018: aload #28
    //   1020: astore_3
    //   1021: goto -> 1465
    //   1024: iload #25
    //   1026: ifne -> 1076
    //   1029: iload #26
    //   1031: ifeq -> 1076
    //   1034: aload_1
    //   1035: aload #28
    //   1037: aload #32
    //   1039: aload #8
    //   1041: invokevirtual b : ()I
    //   1044: ineg
    //   1045: bipush #6
    //   1047: invokevirtual a : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)Landroid/support/constraint/i/b;
    //   1050: pop
    //   1051: iload_2
    //   1052: ifeq -> 1070
    //   1055: aload_1
    //   1056: aload #30
    //   1058: aload_3
    //   1059: iconst_0
    //   1060: iconst_5
    //   1061: invokevirtual b : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   1064: aload #28
    //   1066: astore_3
    //   1067: goto -> 1465
    //   1070: aload #28
    //   1072: astore_3
    //   1073: goto -> 1465
    //   1076: iload #25
    //   1078: ifeq -> 1462
    //   1081: iload #26
    //   1083: ifeq -> 1462
    //   1086: iconst_0
    //   1087: istore #17
    //   1089: iconst_0
    //   1090: istore #16
    //   1092: iload #9
    //   1094: ifeq -> 1323
    //   1097: iload_2
    //   1098: ifeq -> 1120
    //   1101: iload #11
    //   1103: ifne -> 1120
    //   1106: aload_1
    //   1107: aload #28
    //   1109: aload #30
    //   1111: iconst_0
    //   1112: bipush #6
    //   1114: invokevirtual b : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   1117: goto -> 1120
    //   1120: iload #21
    //   1122: ifne -> 1213
    //   1125: bipush #6
    //   1127: istore #11
    //   1129: iload #10
    //   1131: ifgt -> 1143
    //   1134: iload #17
    //   1136: istore #9
    //   1138: iload #12
    //   1140: ifle -> 1149
    //   1143: iconst_4
    //   1144: istore #11
    //   1146: iconst_1
    //   1147: istore #9
    //   1149: aload_1
    //   1150: aload #30
    //   1152: aload #31
    //   1154: aload #7
    //   1156: invokevirtual b : ()I
    //   1159: iload #11
    //   1161: invokevirtual a : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)Landroid/support/constraint/i/b;
    //   1164: pop
    //   1165: aload_1
    //   1166: aload #28
    //   1168: aload #32
    //   1170: aload #8
    //   1172: invokevirtual b : ()I
    //   1175: ineg
    //   1176: iload #11
    //   1178: invokevirtual a : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)Landroid/support/constraint/i/b;
    //   1181: pop
    //   1182: iload #10
    //   1184: ifgt -> 1196
    //   1187: iload #16
    //   1189: istore #10
    //   1191: iload #12
    //   1193: ifle -> 1199
    //   1196: iconst_1
    //   1197: istore #10
    //   1199: iload #9
    //   1201: istore #11
    //   1203: iload #10
    //   1205: istore #9
    //   1207: iconst_5
    //   1208: istore #10
    //   1210: goto -> 1365
    //   1213: iload #21
    //   1215: iconst_1
    //   1216: if_icmpne -> 1232
    //   1219: bipush #6
    //   1221: istore #10
    //   1223: iconst_1
    //   1224: istore #11
    //   1226: iconst_1
    //   1227: istore #9
    //   1229: goto -> 1365
    //   1232: iload #21
    //   1234: iconst_3
    //   1235: if_icmpne -> 1311
    //   1238: iload #14
    //   1240: ifne -> 1263
    //   1243: aload_0
    //   1244: getfield n : I
    //   1247: iconst_m1
    //   1248: if_icmpeq -> 1263
    //   1251: iload #10
    //   1253: ifgt -> 1263
    //   1256: bipush #6
    //   1258: istore #9
    //   1260: goto -> 1266
    //   1263: iconst_4
    //   1264: istore #9
    //   1266: aload_1
    //   1267: aload #30
    //   1269: aload #31
    //   1271: aload #7
    //   1273: invokevirtual b : ()I
    //   1276: iload #9
    //   1278: invokevirtual a : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)Landroid/support/constraint/i/b;
    //   1281: pop
    //   1282: aload_1
    //   1283: aload #28
    //   1285: aload #32
    //   1287: aload #8
    //   1289: invokevirtual b : ()I
    //   1292: ineg
    //   1293: iload #9
    //   1295: invokevirtual a : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)Landroid/support/constraint/i/b;
    //   1298: pop
    //   1299: iconst_1
    //   1300: istore #11
    //   1302: iconst_1
    //   1303: istore #9
    //   1305: iconst_5
    //   1306: istore #10
    //   1308: goto -> 1365
    //   1311: iconst_0
    //   1312: istore #11
    //   1314: iconst_0
    //   1315: istore #9
    //   1317: iconst_5
    //   1318: istore #10
    //   1320: goto -> 1365
    //   1323: iload_2
    //   1324: ifeq -> 1356
    //   1327: aload_1
    //   1328: aload #30
    //   1330: aload #31
    //   1332: aload #7
    //   1334: invokevirtual b : ()I
    //   1337: iconst_5
    //   1338: invokevirtual b : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   1341: aload_1
    //   1342: aload #28
    //   1344: aload #32
    //   1346: aload #8
    //   1348: invokevirtual b : ()I
    //   1351: ineg
    //   1352: iconst_5
    //   1353: invokevirtual c : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   1356: iconst_0
    //   1357: istore #11
    //   1359: iconst_1
    //   1360: istore #9
    //   1362: iconst_5
    //   1363: istore #10
    //   1365: iload #9
    //   1367: ifeq -> 1399
    //   1370: aload_1
    //   1371: aload #30
    //   1373: aload #31
    //   1375: aload #7
    //   1377: invokevirtual b : ()I
    //   1380: fload #13
    //   1382: aload #32
    //   1384: aload #28
    //   1386: aload #8
    //   1388: invokevirtual b : ()I
    //   1391: iload #10
    //   1393: invokevirtual a : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;IFLandroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   1396: goto -> 1399
    //   1399: iload #11
    //   1401: ifeq -> 1438
    //   1404: aload_1
    //   1405: aload #30
    //   1407: aload #31
    //   1409: aload #7
    //   1411: invokevirtual b : ()I
    //   1414: bipush #6
    //   1416: invokevirtual b : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   1419: aload_1
    //   1420: aload #28
    //   1422: aload #32
    //   1424: aload #8
    //   1426: invokevirtual b : ()I
    //   1429: ineg
    //   1430: bipush #6
    //   1432: invokevirtual c : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   1435: goto -> 1438
    //   1438: aload #28
    //   1440: astore #5
    //   1442: iload_2
    //   1443: ifeq -> 1459
    //   1446: aload_1
    //   1447: aload #30
    //   1449: aload_3
    //   1450: iconst_0
    //   1451: bipush #6
    //   1453: invokevirtual b : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   1456: goto -> 1465
    //   1459: goto -> 1465
    //   1462: aload #28
    //   1464: astore_3
    //   1465: iload_2
    //   1466: ifeq -> 1480
    //   1469: aload_1
    //   1470: aload #4
    //   1472: aload #28
    //   1474: iconst_0
    //   1475: bipush #6
    //   1477: invokevirtual b : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   1480: return
    //   1481: iload #22
    //   1483: iconst_2
    //   1484: if_icmpge -> 1512
    //   1487: iload_2
    //   1488: ifeq -> 1512
    //   1491: aload_1
    //   1492: aload #30
    //   1494: aload_3
    //   1495: iconst_0
    //   1496: bipush #6
    //   1498: invokevirtual b : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   1501: aload_1
    //   1502: aload #4
    //   1504: aload #28
    //   1506: iconst_0
    //   1507: bipush #6
    //   1509: invokevirtual b : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   1512: return
  }
  
  public boolean A() {
    int i = this.e;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i == 0) {
      bool1 = bool2;
      if (this.F == 0.0F) {
        bool1 = bool2;
        if (this.h == 0) {
          bool1 = bool2;
          if (this.i == 0) {
            bool1 = bool2;
            if (this.B[0] == b.e)
              bool1 = true; 
          } 
        } 
      } 
    } 
    return bool1;
  }
  
  public void B() {
    this.r.j();
    this.s.j();
    this.t.j();
    this.u.j();
    this.v.j();
    this.w.j();
    this.x.j();
    this.y.j();
    this.C = null;
    this.q = 0.0F;
    this.D = 0;
    this.E = 0;
    this.F = 0.0F;
    this.G = -1;
    this.H = 0;
    this.I = 0;
    this.J = 0;
    this.K = 0;
    this.L = 0;
    this.M = 0;
    this.N = 0;
    this.O = 0;
    this.P = 0;
    this.Q = 0;
    this.R = 0;
    float f = d0;
    this.S = f;
    this.T = f;
    b[] arrayOfB = this.B;
    b b1 = b.c;
    arrayOfB[0] = b1;
    arrayOfB[1] = b1;
    this.U = null;
    this.V = 0;
    this.X = null;
    this.Y = 0;
    this.Z = 0;
    float[] arrayOfFloat = this.a0;
    arrayOfFloat[0] = -1.0F;
    arrayOfFloat[1] = -1.0F;
    this.a = -1;
    this.b = -1;
    int[] arrayOfInt = this.p;
    arrayOfInt[0] = Integer.MAX_VALUE;
    arrayOfInt[1] = Integer.MAX_VALUE;
    this.e = 0;
    this.f = 0;
    this.j = 1.0F;
    this.m = 1.0F;
    this.i = Integer.MAX_VALUE;
    this.l = Integer.MAX_VALUE;
    this.h = 0;
    this.k = 0;
    this.n = -1;
    this.o = 1.0F;
    l l1 = this.c;
    if (l1 != null)
      l1.d(); 
    l1 = this.d;
    if (l1 != null)
      l1.d(); 
  }
  
  public void C() {
    e e1 = l();
    if (e1 != null && e1 instanceof f && ((f)l()).L())
      return; 
    byte b1 = 0;
    int i = this.A.size();
    while (b1 < i) {
      ((d)this.A.get(b1)).j();
      b1++;
    } 
  }
  
  public void D() {
    for (byte b1 = 0; b1 < 6; b1++)
      this.z[b1].d().d(); 
  }
  
  public void E() {}
  
  public void F() {
    int j = this.H;
    int i = this.I;
    int k = this.H;
    k = this.D;
    k = this.I;
    k = this.E;
    this.J = j;
    this.K = i;
  }
  
  public void G() {
    for (byte b1 = 0; b1 < 6; b1++)
      this.z[b1].d().g(); 
  }
  
  public d a(d.d paramd) {
    switch (a.a[paramd.ordinal()]) {
      default:
        throw new AssertionError(paramd.name());
      case 9:
        return null;
      case 8:
        return this.x;
      case 7:
        return this.w;
      case 6:
        return this.y;
      case 5:
        return this.v;
      case 4:
        return this.u;
      case 3:
        return this.t;
      case 2:
        return this.s;
      case 1:
        break;
    } 
    return this.r;
  }
  
  public void a(float paramFloat) {
    this.S = paramFloat;
  }
  
  public void a(int paramInt) {
    i.a(paramInt, this);
  }
  
  public void a(int paramInt1, int paramInt2) {
    this.H = paramInt1;
    this.D = paramInt2 - paramInt1;
    paramInt1 = this.D;
    paramInt2 = this.O;
    if (paramInt1 < paramInt2)
      this.D = paramInt2; 
  }
  
  public void a(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.e = paramInt1;
    this.h = paramInt2;
    this.i = paramInt3;
    this.j = paramFloat;
    if (paramFloat < 1.0F && this.e == 0)
      this.e = 2; 
  }
  
  public void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = paramInt3 - paramInt1;
    paramInt3 = paramInt4 - paramInt2;
    this.H = paramInt1;
    this.I = paramInt2;
    if (this.V == 8) {
      this.D = 0;
      this.E = 0;
      return;
    } 
    paramInt1 = i;
    if (this.B[0] == b.c) {
      paramInt1 = i;
      if (i < this.D)
        paramInt1 = this.D; 
    } 
    paramInt2 = paramInt3;
    if (this.B[1] == b.c) {
      paramInt2 = paramInt3;
      if (paramInt3 < this.E)
        paramInt2 = this.E; 
    } 
    this.D = paramInt1;
    this.E = paramInt2;
    paramInt1 = this.E;
    paramInt2 = this.P;
    if (paramInt1 < paramInt2)
      this.E = paramInt2; 
    paramInt2 = this.D;
    paramInt1 = this.O;
    if (paramInt2 < paramInt1)
      this.D = paramInt1; 
  }
  
  public void a(c paramc) {
    this.r.a(paramc);
    this.s.a(paramc);
    this.t.a(paramc);
    this.u.a(paramc);
    this.v.a(paramc);
    this.y.a(paramc);
    this.w.a(paramc);
    this.x.a(paramc);
  }
  
  public void a(android.support.constraint.i.e parame) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: getfield r : Landroid/support/constraint/i/j/d;
    //   5: invokevirtual a : (Ljava/lang/Object;)Landroid/support/constraint/i/i;
    //   8: astore #20
    //   10: aload_1
    //   11: aload_0
    //   12: getfield t : Landroid/support/constraint/i/j/d;
    //   15: invokevirtual a : (Ljava/lang/Object;)Landroid/support/constraint/i/i;
    //   18: astore #22
    //   20: aload_1
    //   21: aload_0
    //   22: getfield s : Landroid/support/constraint/i/j/d;
    //   25: invokevirtual a : (Ljava/lang/Object;)Landroid/support/constraint/i/i;
    //   28: astore #21
    //   30: aload_1
    //   31: aload_0
    //   32: getfield u : Landroid/support/constraint/i/j/d;
    //   35: invokevirtual a : (Ljava/lang/Object;)Landroid/support/constraint/i/i;
    //   38: astore #23
    //   40: aload_1
    //   41: aload_0
    //   42: getfield v : Landroid/support/constraint/i/j/d;
    //   45: invokevirtual a : (Ljava/lang/Object;)Landroid/support/constraint/i/i;
    //   48: astore #24
    //   50: iconst_0
    //   51: istore #14
    //   53: iconst_0
    //   54: istore #15
    //   56: aload_0
    //   57: getfield C : Landroid/support/constraint/i/j/e;
    //   60: astore #18
    //   62: aload #18
    //   64: ifnull -> 533
    //   67: aload #18
    //   69: ifnull -> 91
    //   72: aload #18
    //   74: getfield B : [Landroid/support/constraint/i/j/e$b;
    //   77: iconst_0
    //   78: aaload
    //   79: getstatic android/support/constraint/i/j/e$b.d : Landroid/support/constraint/i/j/e$b;
    //   82: if_acmpne -> 91
    //   85: iconst_1
    //   86: istore #11
    //   88: goto -> 94
    //   91: iconst_0
    //   92: istore #11
    //   94: aload_0
    //   95: getfield C : Landroid/support/constraint/i/j/e;
    //   98: astore #18
    //   100: aload #18
    //   102: ifnull -> 124
    //   105: aload #18
    //   107: getfield B : [Landroid/support/constraint/i/j/e$b;
    //   110: iconst_1
    //   111: aaload
    //   112: getstatic android/support/constraint/i/j/e$b.d : Landroid/support/constraint/i/j/e$b;
    //   115: if_acmpne -> 124
    //   118: iconst_1
    //   119: istore #12
    //   121: goto -> 127
    //   124: iconst_0
    //   125: istore #12
    //   127: aload_0
    //   128: getfield r : Landroid/support/constraint/i/j/d;
    //   131: astore #18
    //   133: aload #18
    //   135: getfield d : Landroid/support/constraint/i/j/d;
    //   138: astore #19
    //   140: aload #19
    //   142: ifnull -> 195
    //   145: aload #19
    //   147: getfield d : Landroid/support/constraint/i/j/d;
    //   150: aload #18
    //   152: if_acmpeq -> 195
    //   155: aload_0
    //   156: getfield t : Landroid/support/constraint/i/j/d;
    //   159: astore #18
    //   161: aload #18
    //   163: getfield d : Landroid/support/constraint/i/j/d;
    //   166: astore #19
    //   168: aload #19
    //   170: ifnull -> 195
    //   173: aload #19
    //   175: getfield d : Landroid/support/constraint/i/j/d;
    //   178: aload #18
    //   180: if_acmpne -> 195
    //   183: aload_0
    //   184: getfield C : Landroid/support/constraint/i/j/e;
    //   187: checkcast android/support/constraint/i/j/f
    //   190: aload_0
    //   191: iconst_0
    //   192: invokevirtual a : (Landroid/support/constraint/i/j/e;I)V
    //   195: aload_0
    //   196: getfield r : Landroid/support/constraint/i/j/d;
    //   199: astore #18
    //   201: aload #18
    //   203: getfield d : Landroid/support/constraint/i/j/d;
    //   206: astore #19
    //   208: aload #19
    //   210: ifnull -> 223
    //   213: aload #19
    //   215: getfield d : Landroid/support/constraint/i/j/d;
    //   218: aload #18
    //   220: if_acmpeq -> 259
    //   223: aload_0
    //   224: getfield t : Landroid/support/constraint/i/j/d;
    //   227: astore #18
    //   229: aload #18
    //   231: getfield d : Landroid/support/constraint/i/j/d;
    //   234: astore #19
    //   236: iload #14
    //   238: istore #13
    //   240: aload #19
    //   242: ifnull -> 262
    //   245: iload #14
    //   247: istore #13
    //   249: aload #19
    //   251: getfield d : Landroid/support/constraint/i/j/d;
    //   254: aload #18
    //   256: if_acmpne -> 262
    //   259: iconst_1
    //   260: istore #13
    //   262: aload_0
    //   263: getfield s : Landroid/support/constraint/i/j/d;
    //   266: astore #19
    //   268: aload #19
    //   270: getfield d : Landroid/support/constraint/i/j/d;
    //   273: astore #18
    //   275: aload #18
    //   277: ifnull -> 330
    //   280: aload #18
    //   282: getfield d : Landroid/support/constraint/i/j/d;
    //   285: aload #19
    //   287: if_acmpeq -> 330
    //   290: aload_0
    //   291: getfield u : Landroid/support/constraint/i/j/d;
    //   294: astore #19
    //   296: aload #19
    //   298: getfield d : Landroid/support/constraint/i/j/d;
    //   301: astore #18
    //   303: aload #18
    //   305: ifnull -> 330
    //   308: aload #18
    //   310: getfield d : Landroid/support/constraint/i/j/d;
    //   313: aload #19
    //   315: if_acmpne -> 330
    //   318: aload_0
    //   319: getfield C : Landroid/support/constraint/i/j/e;
    //   322: checkcast android/support/constraint/i/j/f
    //   325: aload_0
    //   326: iconst_1
    //   327: invokevirtual a : (Landroid/support/constraint/i/j/e;I)V
    //   330: aload_0
    //   331: getfield s : Landroid/support/constraint/i/j/d;
    //   334: astore #19
    //   336: aload #19
    //   338: getfield d : Landroid/support/constraint/i/j/d;
    //   341: astore #18
    //   343: aload #18
    //   345: ifnull -> 358
    //   348: aload #18
    //   350: getfield d : Landroid/support/constraint/i/j/d;
    //   353: aload #19
    //   355: if_acmpeq -> 394
    //   358: aload_0
    //   359: getfield u : Landroid/support/constraint/i/j/d;
    //   362: astore #18
    //   364: aload #18
    //   366: getfield d : Landroid/support/constraint/i/j/d;
    //   369: astore #19
    //   371: iload #15
    //   373: istore #14
    //   375: aload #19
    //   377: ifnull -> 397
    //   380: iload #15
    //   382: istore #14
    //   384: aload #19
    //   386: getfield d : Landroid/support/constraint/i/j/d;
    //   389: aload #18
    //   391: if_acmpne -> 397
    //   394: iconst_1
    //   395: istore #14
    //   397: iload #11
    //   399: ifeq -> 450
    //   402: aload_0
    //   403: getfield V : I
    //   406: bipush #8
    //   408: if_icmpeq -> 450
    //   411: aload_0
    //   412: getfield r : Landroid/support/constraint/i/j/d;
    //   415: getfield d : Landroid/support/constraint/i/j/d;
    //   418: ifnonnull -> 450
    //   421: aload_0
    //   422: getfield t : Landroid/support/constraint/i/j/d;
    //   425: getfield d : Landroid/support/constraint/i/j/d;
    //   428: ifnonnull -> 450
    //   431: aload_1
    //   432: aload_1
    //   433: aload_0
    //   434: getfield C : Landroid/support/constraint/i/j/e;
    //   437: getfield t : Landroid/support/constraint/i/j/d;
    //   440: invokevirtual a : (Ljava/lang/Object;)Landroid/support/constraint/i/i;
    //   443: aload #22
    //   445: iconst_0
    //   446: iconst_1
    //   447: invokevirtual b : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   450: iload #12
    //   452: ifeq -> 510
    //   455: aload_0
    //   456: getfield V : I
    //   459: bipush #8
    //   461: if_icmpeq -> 510
    //   464: aload_0
    //   465: getfield s : Landroid/support/constraint/i/j/d;
    //   468: getfield d : Landroid/support/constraint/i/j/d;
    //   471: ifnonnull -> 510
    //   474: aload_0
    //   475: getfield u : Landroid/support/constraint/i/j/d;
    //   478: getfield d : Landroid/support/constraint/i/j/d;
    //   481: ifnonnull -> 510
    //   484: aload_0
    //   485: getfield v : Landroid/support/constraint/i/j/d;
    //   488: ifnonnull -> 510
    //   491: aload_1
    //   492: aload_1
    //   493: aload_0
    //   494: getfield C : Landroid/support/constraint/i/j/e;
    //   497: getfield u : Landroid/support/constraint/i/j/d;
    //   500: invokevirtual a : (Ljava/lang/Object;)Landroid/support/constraint/i/i;
    //   503: aload #23
    //   505: iconst_0
    //   506: iconst_1
    //   507: invokevirtual b : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)V
    //   510: iload #13
    //   512: istore #15
    //   514: iload #14
    //   516: istore #16
    //   518: iload #12
    //   520: istore #13
    //   522: iload #11
    //   524: istore #14
    //   526: iload #16
    //   528: istore #12
    //   530: goto -> 545
    //   533: iconst_0
    //   534: istore #15
    //   536: iconst_0
    //   537: istore #12
    //   539: iconst_0
    //   540: istore #14
    //   542: iconst_0
    //   543: istore #13
    //   545: aload_0
    //   546: getfield D : I
    //   549: istore_3
    //   550: iload_3
    //   551: istore #5
    //   553: iload_3
    //   554: aload_0
    //   555: getfield O : I
    //   558: if_icmpge -> 567
    //   561: aload_0
    //   562: getfield O : I
    //   565: istore #5
    //   567: aload_0
    //   568: getfield E : I
    //   571: istore_3
    //   572: iload_3
    //   573: istore #6
    //   575: iload_3
    //   576: aload_0
    //   577: getfield P : I
    //   580: if_icmpge -> 589
    //   583: aload_0
    //   584: getfield P : I
    //   587: istore #6
    //   589: aload_0
    //   590: getfield B : [Landroid/support/constraint/i/j/e$b;
    //   593: iconst_0
    //   594: aaload
    //   595: getstatic android/support/constraint/i/j/e$b.e : Landroid/support/constraint/i/j/e$b;
    //   598: if_acmpeq -> 607
    //   601: iconst_1
    //   602: istore #11
    //   604: goto -> 610
    //   607: iconst_0
    //   608: istore #11
    //   610: aload_0
    //   611: getfield B : [Landroid/support/constraint/i/j/e$b;
    //   614: iconst_1
    //   615: aaload
    //   616: getstatic android/support/constraint/i/j/e$b.e : Landroid/support/constraint/i/j/e$b;
    //   619: if_acmpeq -> 628
    //   622: iconst_1
    //   623: istore #16
    //   625: goto -> 631
    //   628: iconst_0
    //   629: istore #16
    //   631: iconst_0
    //   632: istore #7
    //   634: aload_0
    //   635: aload_0
    //   636: getfield G : I
    //   639: putfield n : I
    //   642: aload_0
    //   643: getfield F : F
    //   646: fstore_2
    //   647: aload_0
    //   648: fload_2
    //   649: putfield o : F
    //   652: aload_0
    //   653: getfield e : I
    //   656: istore #8
    //   658: aload_0
    //   659: getfield f : I
    //   662: istore #9
    //   664: fload_2
    //   665: fconst_0
    //   666: fcmpl
    //   667: ifle -> 1010
    //   670: aload_0
    //   671: getfield V : I
    //   674: bipush #8
    //   676: if_icmpeq -> 1010
    //   679: iconst_1
    //   680: istore #10
    //   682: iload #8
    //   684: istore_3
    //   685: aload_0
    //   686: getfield B : [Landroid/support/constraint/i/j/e$b;
    //   689: iconst_0
    //   690: aaload
    //   691: getstatic android/support/constraint/i/j/e$b.e : Landroid/support/constraint/i/j/e$b;
    //   694: if_acmpne -> 707
    //   697: iload #8
    //   699: istore_3
    //   700: iload #8
    //   702: ifne -> 707
    //   705: iconst_3
    //   706: istore_3
    //   707: iload #9
    //   709: istore #4
    //   711: aload_0
    //   712: getfield B : [Landroid/support/constraint/i/j/e$b;
    //   715: iconst_1
    //   716: aaload
    //   717: getstatic android/support/constraint/i/j/e$b.e : Landroid/support/constraint/i/j/e$b;
    //   720: if_acmpne -> 735
    //   723: iload #9
    //   725: istore #4
    //   727: iload #9
    //   729: ifne -> 735
    //   732: iconst_3
    //   733: istore #4
    //   735: aload_0
    //   736: getfield B : [Landroid/support/constraint/i/j/e$b;
    //   739: astore #25
    //   741: aload #25
    //   743: iconst_0
    //   744: aaload
    //   745: astore #19
    //   747: getstatic android/support/constraint/i/j/e$b.e : Landroid/support/constraint/i/j/e$b;
    //   750: astore #18
    //   752: aload #19
    //   754: aload #18
    //   756: if_acmpne -> 805
    //   759: aload #25
    //   761: iconst_1
    //   762: aaload
    //   763: aload #18
    //   765: if_acmpne -> 805
    //   768: iload_3
    //   769: iconst_3
    //   770: if_icmpne -> 805
    //   773: iload #4
    //   775: iconst_3
    //   776: if_icmpne -> 805
    //   779: aload_0
    //   780: iload #14
    //   782: iload #13
    //   784: iload #11
    //   786: iload #16
    //   788: invokevirtual a : (ZZZZ)V
    //   791: iload #4
    //   793: istore #9
    //   795: iload_3
    //   796: istore #8
    //   798: iload #10
    //   800: istore #7
    //   802: goto -> 1010
    //   805: aload_0
    //   806: getfield B : [Landroid/support/constraint/i/j/e$b;
    //   809: astore #19
    //   811: aload #19
    //   813: iconst_0
    //   814: aaload
    //   815: astore #25
    //   817: getstatic android/support/constraint/i/j/e$b.e : Landroid/support/constraint/i/j/e$b;
    //   820: astore #18
    //   822: aload #25
    //   824: aload #18
    //   826: if_acmpne -> 899
    //   829: iload_3
    //   830: iconst_3
    //   831: if_icmpne -> 899
    //   834: aload_0
    //   835: iconst_0
    //   836: putfield n : I
    //   839: aload_0
    //   840: getfield o : F
    //   843: aload_0
    //   844: getfield E : I
    //   847: i2f
    //   848: fmul
    //   849: f2i
    //   850: istore #7
    //   852: aload #19
    //   854: iconst_1
    //   855: aaload
    //   856: aload #18
    //   858: if_acmpeq -> 881
    //   861: iconst_4
    //   862: istore_3
    //   863: iload #7
    //   865: istore #8
    //   867: iload #6
    //   869: istore #7
    //   871: iconst_0
    //   872: istore #5
    //   874: iload #8
    //   876: istore #6
    //   878: goto -> 1033
    //   881: iload #6
    //   883: istore #8
    //   885: iconst_1
    //   886: istore #5
    //   888: iload #7
    //   890: istore #6
    //   892: iload #8
    //   894: istore #7
    //   896: goto -> 1033
    //   899: iload #4
    //   901: istore #9
    //   903: iload_3
    //   904: istore #8
    //   906: iload #10
    //   908: istore #7
    //   910: aload_0
    //   911: getfield B : [Landroid/support/constraint/i/j/e$b;
    //   914: iconst_1
    //   915: aaload
    //   916: getstatic android/support/constraint/i/j/e$b.e : Landroid/support/constraint/i/j/e$b;
    //   919: if_acmpne -> 1010
    //   922: iload #4
    //   924: istore #9
    //   926: iload_3
    //   927: istore #8
    //   929: iload #10
    //   931: istore #7
    //   933: iload #4
    //   935: iconst_3
    //   936: if_icmpne -> 1010
    //   939: aload_0
    //   940: iconst_1
    //   941: putfield n : I
    //   944: aload_0
    //   945: getfield G : I
    //   948: iconst_m1
    //   949: if_icmpne -> 962
    //   952: aload_0
    //   953: fconst_1
    //   954: aload_0
    //   955: getfield o : F
    //   958: fdiv
    //   959: putfield o : F
    //   962: aload_0
    //   963: getfield o : F
    //   966: aload_0
    //   967: getfield D : I
    //   970: i2f
    //   971: fmul
    //   972: f2i
    //   973: istore #7
    //   975: aload_0
    //   976: getfield B : [Landroid/support/constraint/i/j/e$b;
    //   979: iconst_0
    //   980: aaload
    //   981: getstatic android/support/constraint/i/j/e$b.e : Landroid/support/constraint/i/j/e$b;
    //   984: if_acmpeq -> 1000
    //   987: iconst_4
    //   988: istore #4
    //   990: iload #5
    //   992: istore #6
    //   994: iconst_0
    //   995: istore #5
    //   997: goto -> 1033
    //   1000: iload #5
    //   1002: istore #6
    //   1004: iconst_1
    //   1005: istore #5
    //   1007: goto -> 1033
    //   1010: iload #9
    //   1012: istore #4
    //   1014: iload #8
    //   1016: istore_3
    //   1017: iload #7
    //   1019: istore #8
    //   1021: iload #6
    //   1023: istore #7
    //   1025: iload #5
    //   1027: istore #6
    //   1029: iload #8
    //   1031: istore #5
    //   1033: aload_0
    //   1034: getfield g : [I
    //   1037: astore #18
    //   1039: aload #18
    //   1041: iconst_0
    //   1042: iload_3
    //   1043: iastore
    //   1044: aload #18
    //   1046: iconst_1
    //   1047: iload #4
    //   1049: iastore
    //   1050: iload #5
    //   1052: ifeq -> 1081
    //   1055: aload_0
    //   1056: getfield n : I
    //   1059: istore #8
    //   1061: iload #8
    //   1063: ifeq -> 1075
    //   1066: iload #8
    //   1068: iconst_m1
    //   1069: if_icmpne -> 1081
    //   1072: goto -> 1075
    //   1075: iconst_1
    //   1076: istore #16
    //   1078: goto -> 1084
    //   1081: iconst_0
    //   1082: istore #16
    //   1084: aload_0
    //   1085: getfield B : [Landroid/support/constraint/i/j/e$b;
    //   1088: iconst_0
    //   1089: aaload
    //   1090: getstatic android/support/constraint/i/j/e$b.d : Landroid/support/constraint/i/j/e$b;
    //   1093: if_acmpne -> 1109
    //   1096: aload_0
    //   1097: instanceof android/support/constraint/i/j/f
    //   1100: ifeq -> 1109
    //   1103: iconst_1
    //   1104: istore #17
    //   1106: goto -> 1112
    //   1109: iconst_0
    //   1110: istore #17
    //   1112: aload_0
    //   1113: getfield y : Landroid/support/constraint/i/j/d;
    //   1116: invokevirtual i : ()Z
    //   1119: ifeq -> 1128
    //   1122: iconst_0
    //   1123: istore #11
    //   1125: goto -> 1131
    //   1128: iconst_1
    //   1129: istore #11
    //   1131: aload_0
    //   1132: getfield a : I
    //   1135: iconst_2
    //   1136: if_icmpeq -> 1264
    //   1139: aload_0
    //   1140: getfield C : Landroid/support/constraint/i/j/e;
    //   1143: astore #18
    //   1145: aload #18
    //   1147: ifnull -> 1164
    //   1150: aload_1
    //   1151: aload #18
    //   1153: getfield t : Landroid/support/constraint/i/j/d;
    //   1156: invokevirtual a : (Ljava/lang/Object;)Landroid/support/constraint/i/i;
    //   1159: astore #18
    //   1161: goto -> 1167
    //   1164: aconst_null
    //   1165: astore #18
    //   1167: aload_0
    //   1168: getfield C : Landroid/support/constraint/i/j/e;
    //   1171: astore #19
    //   1173: aload #19
    //   1175: ifnull -> 1192
    //   1178: aload_1
    //   1179: aload #19
    //   1181: getfield r : Landroid/support/constraint/i/j/d;
    //   1184: invokevirtual a : (Ljava/lang/Object;)Landroid/support/constraint/i/i;
    //   1187: astore #19
    //   1189: goto -> 1195
    //   1192: aconst_null
    //   1193: astore #19
    //   1195: aload_0
    //   1196: aload_1
    //   1197: iload #14
    //   1199: aload #19
    //   1201: aload #18
    //   1203: aload_0
    //   1204: getfield B : [Landroid/support/constraint/i/j/e$b;
    //   1207: iconst_0
    //   1208: aaload
    //   1209: iload #17
    //   1211: aload_0
    //   1212: getfield r : Landroid/support/constraint/i/j/d;
    //   1215: aload_0
    //   1216: getfield t : Landroid/support/constraint/i/j/d;
    //   1219: aload_0
    //   1220: getfield H : I
    //   1223: iload #6
    //   1225: aload_0
    //   1226: getfield O : I
    //   1229: aload_0
    //   1230: getfield p : [I
    //   1233: iconst_0
    //   1234: iaload
    //   1235: aload_0
    //   1236: getfield S : F
    //   1239: iload #16
    //   1241: iload #15
    //   1243: iload_3
    //   1244: aload_0
    //   1245: getfield h : I
    //   1248: aload_0
    //   1249: getfield i : I
    //   1252: aload_0
    //   1253: getfield j : F
    //   1256: iload #11
    //   1258: invokespecial a : (Landroid/support/constraint/i/e;ZLandroid/support/constraint/i/i;Landroid/support/constraint/i/i;Landroid/support/constraint/i/j/e$b;ZLandroid/support/constraint/i/j/d;Landroid/support/constraint/i/j/d;IIIIFZZIIIFZ)V
    //   1261: goto -> 1264
    //   1264: aload_0
    //   1265: getfield b : I
    //   1268: iconst_2
    //   1269: if_icmpne -> 1273
    //   1272: return
    //   1273: aload_0
    //   1274: getfield B : [Landroid/support/constraint/i/j/e$b;
    //   1277: iconst_1
    //   1278: aaload
    //   1279: getstatic android/support/constraint/i/j/e$b.d : Landroid/support/constraint/i/j/e$b;
    //   1282: if_acmpne -> 1298
    //   1285: aload_0
    //   1286: instanceof android/support/constraint/i/j/f
    //   1289: ifeq -> 1298
    //   1292: iconst_1
    //   1293: istore #14
    //   1295: goto -> 1301
    //   1298: iconst_0
    //   1299: istore #14
    //   1301: iload #5
    //   1303: ifeq -> 1327
    //   1306: aload_0
    //   1307: getfield n : I
    //   1310: istore_3
    //   1311: iload_3
    //   1312: iconst_1
    //   1313: if_icmpeq -> 1321
    //   1316: iload_3
    //   1317: iconst_m1
    //   1318: if_icmpne -> 1327
    //   1321: iconst_1
    //   1322: istore #15
    //   1324: goto -> 1330
    //   1327: iconst_0
    //   1328: istore #15
    //   1330: aload_0
    //   1331: getfield N : I
    //   1334: ifle -> 1416
    //   1337: aload_0
    //   1338: getfield v : Landroid/support/constraint/i/j/d;
    //   1341: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   1344: getfield b : I
    //   1347: iconst_1
    //   1348: if_icmpne -> 1365
    //   1351: aload_0
    //   1352: getfield v : Landroid/support/constraint/i/j/d;
    //   1355: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   1358: aload_1
    //   1359: invokevirtual a : (Landroid/support/constraint/i/e;)V
    //   1362: goto -> 1416
    //   1365: aload_1
    //   1366: aload #24
    //   1368: aload #21
    //   1370: aload_0
    //   1371: invokevirtual c : ()I
    //   1374: bipush #6
    //   1376: invokevirtual a : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)Landroid/support/constraint/i/b;
    //   1379: pop
    //   1380: aload_0
    //   1381: getfield v : Landroid/support/constraint/i/j/d;
    //   1384: getfield d : Landroid/support/constraint/i/j/d;
    //   1387: astore #18
    //   1389: aload #18
    //   1391: ifnull -> 1416
    //   1394: aload_1
    //   1395: aload #24
    //   1397: aload_1
    //   1398: aload #18
    //   1400: invokevirtual a : (Ljava/lang/Object;)Landroid/support/constraint/i/i;
    //   1403: iconst_0
    //   1404: bipush #6
    //   1406: invokevirtual a : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;II)Landroid/support/constraint/i/b;
    //   1409: pop
    //   1410: iconst_0
    //   1411: istore #11
    //   1413: goto -> 1416
    //   1416: aload_0
    //   1417: getfield C : Landroid/support/constraint/i/j/e;
    //   1420: astore #18
    //   1422: aload #18
    //   1424: ifnull -> 1441
    //   1427: aload_1
    //   1428: aload #18
    //   1430: getfield u : Landroid/support/constraint/i/j/d;
    //   1433: invokevirtual a : (Ljava/lang/Object;)Landroid/support/constraint/i/i;
    //   1436: astore #18
    //   1438: goto -> 1444
    //   1441: aconst_null
    //   1442: astore #18
    //   1444: aload_0
    //   1445: getfield C : Landroid/support/constraint/i/j/e;
    //   1448: astore #19
    //   1450: aload #19
    //   1452: ifnull -> 1469
    //   1455: aload_1
    //   1456: aload #19
    //   1458: getfield s : Landroid/support/constraint/i/j/d;
    //   1461: invokevirtual a : (Ljava/lang/Object;)Landroid/support/constraint/i/i;
    //   1464: astore #19
    //   1466: goto -> 1472
    //   1469: aconst_null
    //   1470: astore #19
    //   1472: aload_0
    //   1473: aload_1
    //   1474: iload #13
    //   1476: aload #19
    //   1478: aload #18
    //   1480: aload_0
    //   1481: getfield B : [Landroid/support/constraint/i/j/e$b;
    //   1484: iconst_1
    //   1485: aaload
    //   1486: iload #14
    //   1488: aload_0
    //   1489: getfield s : Landroid/support/constraint/i/j/d;
    //   1492: aload_0
    //   1493: getfield u : Landroid/support/constraint/i/j/d;
    //   1496: aload_0
    //   1497: getfield I : I
    //   1500: iload #7
    //   1502: aload_0
    //   1503: getfield P : I
    //   1506: aload_0
    //   1507: getfield p : [I
    //   1510: iconst_1
    //   1511: iaload
    //   1512: aload_0
    //   1513: getfield T : F
    //   1516: iload #15
    //   1518: iload #12
    //   1520: iload #4
    //   1522: aload_0
    //   1523: getfield k : I
    //   1526: aload_0
    //   1527: getfield l : I
    //   1530: aload_0
    //   1531: getfield m : F
    //   1534: iload #11
    //   1536: invokespecial a : (Landroid/support/constraint/i/e;ZLandroid/support/constraint/i/i;Landroid/support/constraint/i/i;Landroid/support/constraint/i/j/e$b;ZLandroid/support/constraint/i/j/d;Landroid/support/constraint/i/j/d;IIIIFZZIIIFZ)V
    //   1539: iload #5
    //   1541: ifeq -> 1591
    //   1544: aload_0
    //   1545: getfield n : I
    //   1548: iconst_1
    //   1549: if_icmpne -> 1573
    //   1552: aload_1
    //   1553: aload #23
    //   1555: aload #21
    //   1557: aload #22
    //   1559: aload #20
    //   1561: aload_0
    //   1562: getfield o : F
    //   1565: bipush #6
    //   1567: invokevirtual a : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;FI)V
    //   1570: goto -> 1591
    //   1573: aload_1
    //   1574: aload #22
    //   1576: aload #20
    //   1578: aload #23
    //   1580: aload #21
    //   1582: aload_0
    //   1583: getfield o : F
    //   1586: bipush #6
    //   1588: invokevirtual a : (Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;Landroid/support/constraint/i/i;FI)V
    //   1591: aload_0
    //   1592: getfield y : Landroid/support/constraint/i/j/d;
    //   1595: invokevirtual i : ()Z
    //   1598: ifeq -> 1636
    //   1601: aload_1
    //   1602: aload_0
    //   1603: aload_0
    //   1604: getfield y : Landroid/support/constraint/i/j/d;
    //   1607: invokevirtual g : ()Landroid/support/constraint/i/j/d;
    //   1610: invokevirtual c : ()Landroid/support/constraint/i/j/e;
    //   1613: aload_0
    //   1614: getfield q : F
    //   1617: ldc_w 90.0
    //   1620: fadd
    //   1621: f2d
    //   1622: invokestatic toRadians : (D)D
    //   1625: d2f
    //   1626: aload_0
    //   1627: getfield y : Landroid/support/constraint/i/j/d;
    //   1630: invokevirtual b : ()I
    //   1633: invokevirtual a : (Landroid/support/constraint/i/j/e;Landroid/support/constraint/i/j/e;FI)V
    //   1636: return
  }
  
  public void a(d.d paramd1, e parame, d.d paramd2, int paramInt1, int paramInt2) {
    a(paramd1).a(parame.a(paramd2), paramInt1, paramInt2, d.c.d, 0, true);
  }
  
  public void a(b paramb) {
    this.B[0] = paramb;
    if (paramb == b.d)
      k(this.Q); 
  }
  
  public void a(e parame) {
    this.C = parame;
  }
  
  public void a(e parame, float paramFloat, int paramInt) {
    d.d d1 = d.d.i;
    a(d1, parame, d1, paramInt, 0);
    this.q = paramFloat;
  }
  
  public void a(Object paramObject) {
    this.U = paramObject;
  }
  
  public void a(String paramString) {
    this.W = paramString;
  }
  
  public void a(boolean paramBoolean) {}
  
  public void a(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    if (this.n == -1)
      if (paramBoolean3 && !paramBoolean4) {
        this.n = 0;
      } else if (!paramBoolean3 && paramBoolean4) {
        this.n = 1;
        if (this.G == -1)
          this.o = 1.0F / this.o; 
      }  
    if (this.n == 0 && (!this.s.i() || !this.u.i())) {
      this.n = 1;
    } else if (this.n == 1 && (!this.r.i() || !this.t.i())) {
      this.n = 0;
    } 
    if (this.n == -1 && (!this.s.i() || !this.u.i() || !this.r.i() || !this.t.i()))
      if (this.s.i() && this.u.i()) {
        this.n = 0;
      } else if (this.r.i() && this.t.i()) {
        this.o = 1.0F / this.o;
        this.n = 1;
      }  
    if (this.n == -1)
      if (paramBoolean1 && !paramBoolean2) {
        this.n = 0;
      } else if (!paramBoolean1 && paramBoolean2) {
        this.o = 1.0F / this.o;
        this.n = 1;
      }  
    if (this.n == -1)
      if (this.h > 0 && this.k == 0) {
        this.n = 0;
      } else if (this.h == 0 && this.k > 0) {
        this.o = 1.0F / this.o;
        this.n = 1;
      }  
    if (this.n == -1 && paramBoolean1 && paramBoolean2) {
      this.o = 1.0F / this.o;
      this.n = 1;
    } 
  }
  
  public boolean a() {
    boolean bool;
    if (this.V != 8) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public ArrayList<d> b() {
    return this.A;
  }
  
  public void b(float paramFloat) {
    this.a0[0] = paramFloat;
  }
  
  public void b(int paramInt) {
    this.N = paramInt;
  }
  
  public void b(int paramInt1, int paramInt2) {
    this.L = paramInt1;
    this.M = paramInt2;
  }
  
  public void b(int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
    this.f = paramInt1;
    this.k = paramInt2;
    this.l = paramInt3;
    this.m = paramFloat;
    if (paramFloat < 1.0F && this.f == 0)
      this.f = 2; 
  }
  
  public void b(android.support.constraint.i.e parame) {
    parame.a(this.r);
    parame.a(this.s);
    parame.a(this.t);
    parame.a(this.u);
    if (this.N > 0)
      parame.a(this.v); 
  }
  
  public void b(b paramb) {
    this.B[1] = paramb;
    if (paramb == b.d)
      c(this.R); 
  }
  
  public void b(String paramString) {
    float f1;
    if (paramString == null || paramString.length() == 0) {
      this.F = 0.0F;
      return;
    } 
    byte b1 = -1;
    float f2 = 0.0F;
    float f4 = 0.0F;
    float f3 = 0.0F;
    int j = paramString.length();
    int i = paramString.indexOf(',');
    if (i > 0 && i < j - 1) {
      String str = paramString.substring(0, i);
      if (str.equalsIgnoreCase("W")) {
        b1 = 0;
      } else if (str.equalsIgnoreCase("H")) {
        b1 = 1;
      } 
      i++;
    } else {
      i = 0;
    } 
    int k = paramString.indexOf(':');
    if (k >= 0 && k < j - 1) {
      String str = paramString.substring(i, k);
      paramString = paramString.substring(k + 1);
      f1 = f2;
      if (str.length() > 0) {
        f1 = f2;
        if (paramString.length() > 0)
          try {
            float f = Float.parseFloat(str);
            f4 = Float.parseFloat(paramString);
            f1 = f3;
            if (f > 0.0F) {
              f1 = f3;
              if (f4 > 0.0F)
                if (b1 == 1) {
                  f1 = Math.abs(f4 / f);
                } else {
                  f1 = Math.abs(f / f4);
                }  
            } 
          } catch (NumberFormatException numberFormatException) {
            f1 = f2;
          }  
      } 
    } else {
      String str = numberFormatException.substring(i);
      f1 = f4;
      if (str.length() > 0)
        try {
          f1 = Float.parseFloat(str);
        } catch (NumberFormatException numberFormatException1) {
          f1 = f4;
        }  
    } 
    if (f1 > 0.0F) {
      this.F = f1;
      this.G = b1;
    } 
  }
  
  public void b(boolean paramBoolean) {}
  
  public int c() {
    return this.N;
  }
  
  public void c(float paramFloat) {
    this.T = paramFloat;
  }
  
  public void c(int paramInt) {
    this.E = paramInt;
    int i = this.E;
    paramInt = this.P;
    if (i < paramInt)
      this.E = paramInt; 
  }
  
  public void c(int paramInt1, int paramInt2) {
    this.H = paramInt1;
    this.I = paramInt2;
  }
  
  public void c(android.support.constraint.i.e parame) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: getfield r : Landroid/support/constraint/i/j/d;
    //   5: invokevirtual b : (Ljava/lang/Object;)I
    //   8: istore_3
    //   9: aload_1
    //   10: aload_0
    //   11: getfield s : Landroid/support/constraint/i/j/d;
    //   14: invokevirtual b : (Ljava/lang/Object;)I
    //   17: istore #5
    //   19: aload_1
    //   20: aload_0
    //   21: getfield t : Landroid/support/constraint/i/j/d;
    //   24: invokevirtual b : (Ljava/lang/Object;)I
    //   27: istore #4
    //   29: aload_1
    //   30: aload_0
    //   31: getfield u : Landroid/support/constraint/i/j/d;
    //   34: invokevirtual b : (Ljava/lang/Object;)I
    //   37: istore #6
    //   39: iload #4
    //   41: iload_3
    //   42: isub
    //   43: iflt -> 115
    //   46: iload #6
    //   48: iload #5
    //   50: isub
    //   51: iflt -> 115
    //   54: iload_3
    //   55: ldc_w -2147483648
    //   58: if_icmpeq -> 115
    //   61: iload_3
    //   62: ldc 2147483647
    //   64: if_icmpeq -> 115
    //   67: iload #5
    //   69: ldc_w -2147483648
    //   72: if_icmpeq -> 115
    //   75: iload #5
    //   77: ldc 2147483647
    //   79: if_icmpeq -> 115
    //   82: iload #4
    //   84: ldc_w -2147483648
    //   87: if_icmpeq -> 115
    //   90: iload #4
    //   92: ldc 2147483647
    //   94: if_icmpeq -> 115
    //   97: iload #6
    //   99: ldc_w -2147483648
    //   102: if_icmpeq -> 115
    //   105: iload #6
    //   107: istore_2
    //   108: iload #6
    //   110: ldc 2147483647
    //   112: if_icmpne -> 125
    //   115: iconst_0
    //   116: istore_3
    //   117: iconst_0
    //   118: istore #5
    //   120: iconst_0
    //   121: istore #4
    //   123: iconst_0
    //   124: istore_2
    //   125: aload_0
    //   126: iload_3
    //   127: iload #5
    //   129: iload #4
    //   131: iload_2
    //   132: invokevirtual a : (IIII)V
    //   135: return
  }
  
  public int d() {
    return x() + this.E;
  }
  
  public void d(float paramFloat) {
    this.a0[1] = paramFloat;
  }
  
  public void d(int paramInt) {
    this.Y = paramInt;
  }
  
  public void d(int paramInt1, int paramInt2) {
    this.I = paramInt1;
    this.E = paramInt2 - paramInt1;
    paramInt2 = this.E;
    paramInt1 = this.P;
    if (paramInt2 < paramInt1)
      this.E = paramInt1; 
  }
  
  public Object e() {
    return this.U;
  }
  
  public void e(int paramInt) {
    this.p[1] = paramInt;
  }
  
  public String f() {
    return this.W;
  }
  
  public void f(int paramInt) {
    this.p[0] = paramInt;
  }
  
  public int g() {
    return this.J + this.L;
  }
  
  public void g(int paramInt) {
    if (paramInt < 0) {
      this.P = 0;
    } else {
      this.P = paramInt;
    } 
  }
  
  public int h() {
    return this.K + this.M;
  }
  
  public void h(int paramInt) {
    if (paramInt < 0) {
      this.O = 0;
    } else {
      this.O = paramInt;
    } 
  }
  
  public int i() {
    return (this.V == 8) ? 0 : this.E;
  }
  
  public void i(int paramInt) {
    this.Z = paramInt;
  }
  
  public float j() {
    return this.S;
  }
  
  public void j(int paramInt) {
    this.V = paramInt;
  }
  
  public b k() {
    return this.B[0];
  }
  
  public void k(int paramInt) {
    this.D = paramInt;
    paramInt = this.D;
    int i = this.O;
    if (paramInt < i)
      this.D = i; 
  }
  
  public e l() {
    return this.C;
  }
  
  public void l(int paramInt) {
    this.R = paramInt;
  }
  
  public l m() {
    if (this.d == null)
      this.d = new l(); 
    return this.d;
  }
  
  public void m(int paramInt) {
    this.Q = paramInt;
  }
  
  public l n() {
    if (this.c == null)
      this.c = new l(); 
    return this.c;
  }
  
  public void n(int paramInt) {
    this.H = paramInt;
  }
  
  public int o() {
    return w() + this.D;
  }
  
  public void o(int paramInt) {
    this.I = paramInt;
  }
  
  protected int p() {
    return this.H + this.L;
  }
  
  protected int q() {
    return this.I + this.M;
  }
  
  public b r() {
    return this.B[1];
  }
  
  public int s() {
    return this.V;
  }
  
  public int t() {
    return (this.V == 8) ? 0 : this.D;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    String str1 = this.X;
    String str2 = "";
    if (str1 != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("type: ");
      stringBuilder1.append(this.X);
      stringBuilder1.append(" ");
      String str = stringBuilder1.toString();
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    str1 = str2;
    if (this.W != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("id: ");
      stringBuilder1.append(this.W);
      stringBuilder1.append(" ");
      str1 = stringBuilder1.toString();
    } 
    stringBuilder.append(str1);
    stringBuilder.append("(");
    stringBuilder.append(this.H);
    stringBuilder.append(", ");
    stringBuilder.append(this.I);
    stringBuilder.append(") - (");
    stringBuilder.append(this.D);
    stringBuilder.append(" x ");
    stringBuilder.append(this.E);
    stringBuilder.append(") wrap: (");
    stringBuilder.append(this.Q);
    stringBuilder.append(" x ");
    stringBuilder.append(this.R);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  public int u() {
    return this.R;
  }
  
  public int v() {
    return this.Q;
  }
  
  public int w() {
    return this.H;
  }
  
  public int x() {
    return this.I;
  }
  
  public boolean y() {
    boolean bool;
    if (this.N > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean z() {
    int i = this.f;
    boolean bool = true;
    if (i != 0 || this.F != 0.0F || this.k != 0 || this.l != 0 || this.B[1] != b.e)
      bool = false; 
    return bool;
  }
  
  public enum b {
    c, d, e, f;
    
    private static final b[] g = new b[] { c, d, e, f };
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\i\j\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */