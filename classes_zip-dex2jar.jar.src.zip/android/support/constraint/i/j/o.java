package android.support.constraint.i.j;

import android.support.constraint.i.c;
import java.util.ArrayList;

public class o extends e {
  protected ArrayList<e> e0 = new ArrayList<e>();
  
  public void B() {
    this.e0.clear();
    super.B();
  }
  
  public void F() {
    super.F();
    ArrayList<e> arrayList = this.e0;
    if (arrayList == null)
      return; 
    int i = arrayList.size();
    for (byte b = 0; b < i; b++) {
      e e1 = this.e0.get(b);
      e1.b(g(), h());
      if (!(e1 instanceof f))
        e1.F(); 
    } 
  }
  
  public f H() {
    e e2 = l();
    f f = null;
    e e1 = e2;
    if (this instanceof f) {
      f = (f)this;
      e1 = e2;
    } 
    while (true) {
      e e3 = e1;
      if (e3 != null) {
        e2 = e3.l();
        e1 = e2;
        if (e3 instanceof f) {
          f = (f)e3;
          e1 = e2;
        } 
        continue;
      } 
      return f;
    } 
  }
  
  public void I() {
    F();
    ArrayList<e> arrayList = this.e0;
    if (arrayList == null)
      return; 
    int i = arrayList.size();
    for (byte b = 0; b < i; b++) {
      e e1 = this.e0.get(b);
      if (e1 instanceof o)
        ((o)e1).I(); 
    } 
  }
  
  public void J() {
    this.e0.clear();
  }
  
  public void a(c paramc) {
    super.a(paramc);
    int i = this.e0.size();
    for (byte b = 0; b < i; b++)
      ((e)this.e0.get(b)).a(paramc); 
  }
  
  public void b(int paramInt1, int paramInt2) {
    super.b(paramInt1, paramInt2);
    paramInt2 = this.e0.size();
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++)
      ((e)this.e0.get(paramInt1)).b(p(), q()); 
  }
  
  public void b(e parame) {
    this.e0.add(parame);
    if (parame.l() != null)
      ((o)parame.l()).c(parame); 
    parame.a(this);
  }
  
  public void c(e parame) {
    this.e0.remove(parame);
    parame.a((e)null);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\i\j\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */