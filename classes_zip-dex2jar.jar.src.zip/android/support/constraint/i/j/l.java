package android.support.constraint.i.j;

public class l extends m {
  float c = 0.0F;
  
  public void a(int paramInt) {
    if (this.b == 0 || this.c != paramInt) {
      this.c = paramInt;
      if (this.b == 1)
        b(); 
      a();
    } 
  }
  
  public void d() {
    super.d();
    this.c = 0.0F;
  }
  
  public void f() {
    this.b = 2;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\i\j\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */