package android.support.constraint.i.j;

import android.support.constraint.i.e;
import android.support.constraint.i.f;
import android.support.constraint.i.i;
import java.util.ArrayList;

public class a extends h {
  private int g0 = 0;
  
  private ArrayList<k> h0 = new ArrayList<k>(4);
  
  private boolean i0 = true;
  
  public void D() {
    super.D();
    this.h0.clear();
  }
  
  public void E() {
    k k1;
    float f1 = 0.0F;
    int i = this.g0;
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i != 3)
            return; 
          k1 = this.u.d();
        } else {
          k1 = this.s.d();
          f1 = Float.MAX_VALUE;
        } 
      } else {
        k1 = this.t.d();
      } 
    } else {
      k1 = this.r.d();
      f1 = Float.MAX_VALUE;
    } 
    int j = this.h0.size();
    k k2 = null;
    i = 0;
    float f2;
    for (f2 = f1; i < j; f2 = f1) {
      k k3 = this.h0.get(i);
      if (k3.b != 1)
        return; 
      int k = this.g0;
      if (k == 0 || k == 2) {
        f1 = f2;
        if (k3.g < f2) {
          f1 = k3.g;
          k2 = k3.f;
        } 
      } else {
        f1 = f2;
        if (k3.g > f2) {
          f1 = k3.g;
          k2 = k3.f;
        } 
      } 
      i++;
    } 
    if (e.h() != null) {
      f f = e.h();
      f.y++;
    } 
    k1.f = k2;
    k1.g = f2;
    k1.a();
    i = this.g0;
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i != 3)
            return; 
          this.s.d().a(k2, f2);
        } else {
          this.u.d().a(k2, f2);
        } 
      } else {
        this.r.d().a(k2, f2);
      } 
    } else {
      this.t.d().a(k2, f2);
    } 
  }
  
  public void a(int paramInt) {
    k k;
    e e = this.C;
    if (e == null)
      return; 
    if (!((f)e).p(2))
      return; 
    paramInt = this.g0;
    if (paramInt != 0) {
      if (paramInt != 1) {
        if (paramInt != 2) {
          if (paramInt != 3)
            return; 
          k = this.u.d();
        } else {
          k = this.s.d();
        } 
      } else {
        k = this.t.d();
      } 
    } else {
      k = this.r.d();
    } 
    k.b(5);
    paramInt = this.g0;
    if (paramInt == 0 || paramInt == 1) {
      this.s.d().a((k)null, 0.0F);
      this.u.d().a((k)null, 0.0F);
    } else {
      this.r.d().a((k)null, 0.0F);
      this.t.d().a((k)null, 0.0F);
    } 
    this.h0.clear();
    for (paramInt = 0; paramInt < this.f0; paramInt++) {
      e e1 = this.e0[paramInt];
      if (this.i0 || e1.a()) {
        k k1;
        e = null;
        int i = this.g0;
        if (i != 0) {
          if (i != 1) {
            if (i != 2) {
              if (i == 3)
                k1 = e1.u.d(); 
            } else {
              k1 = e1.s.d();
            } 
          } else {
            k1 = e1.t.d();
          } 
        } else {
          k1 = e1.r.d();
        } 
        if (k1 != null) {
          this.h0.add(k1);
          k1.a(k);
        } 
      } 
    } 
  }
  
  public void a(e parame) {
    d[] arrayOfD = this.z;
    arrayOfD[0] = this.r;
    arrayOfD[2] = this.s;
    arrayOfD[1] = this.t;
    arrayOfD[3] = this.u;
    int i = 0;
    while (true) {
      arrayOfD = this.z;
      if (i < arrayOfD.length) {
        (arrayOfD[i]).i = parame.a(arrayOfD[i]);
        i++;
        continue;
      } 
      i = this.g0;
      if (i >= 0 && i < 4) {
        boolean bool1;
        d d = arrayOfD[i];
        boolean bool2 = false;
        i = 0;
        while (true) {
          bool1 = bool2;
          if (i < this.f0) {
            e e1 = this.e0[i];
            if (this.i0 || e1.a()) {
              int j = this.g0;
              if ((j == 0 || j == 1) && e1.k() == e.b.e) {
                bool1 = true;
                break;
              } 
              j = this.g0;
              if ((j == 2 || j == 3) && e1.r() == e.b.e) {
                bool1 = true;
                break;
              } 
            } 
            i++;
            continue;
          } 
          break;
        } 
        i = this.g0;
        if (i == 0 || i == 1) {
          if (l().k() == e.b.d)
            bool1 = false; 
        } else if (l().r() == e.b.d) {
          bool1 = false;
        } 
        for (i = 0; i < this.f0; i++) {
          e e1 = this.e0[i];
          if (this.i0 || e1.a()) {
            i i1 = parame.a(e1.z[this.g0]);
            d[] arrayOfD1 = e1.z;
            int j = this.g0;
            (arrayOfD1[j]).i = i1;
            if (j == 0 || j == 2) {
              parame.b(d.i, i1, bool1);
            } else {
              parame.a(d.i, i1, bool1);
            } 
          } 
        } 
        i = this.g0;
        if (i == 0) {
          parame.a(this.t.i, this.r.i, 0, 6);
          if (!bool1)
            parame.a(this.r.i, this.C.t.i, 0, 5); 
        } else if (i == 1) {
          parame.a(this.r.i, this.t.i, 0, 6);
          if (!bool1)
            parame.a(this.r.i, this.C.r.i, 0, 5); 
        } else if (i == 2) {
          parame.a(this.u.i, this.s.i, 0, 6);
          if (!bool1)
            parame.a(this.s.i, this.C.u.i, 0, 5); 
        } else if (i == 3) {
          parame.a(this.s.i, this.u.i, 0, 6);
          if (!bool1)
            parame.a(this.s.i, this.C.s.i, 0, 5); 
        } 
        return;
      } 
      return;
    } 
  }
  
  public boolean a() {
    return true;
  }
  
  public void c(boolean paramBoolean) {
    this.i0 = paramBoolean;
  }
  
  public void p(int paramInt) {
    this.g0 = paramInt;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\i\j\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */