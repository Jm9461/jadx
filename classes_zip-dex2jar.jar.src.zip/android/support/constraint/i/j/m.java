package android.support.constraint.i.j;

import java.util.HashSet;
import java.util.Iterator;

public class m {
  HashSet<m> a = new HashSet<m>(2);
  
  int b = 0;
  
  public void a() {
    this.b = 1;
    Iterator<m> iterator = this.a.iterator();
    while (iterator.hasNext())
      ((m)iterator.next()).e(); 
  }
  
  public void a(m paramm) {
    this.a.add(paramm);
  }
  
  public void b() {
    this.b = 0;
    Iterator<m> iterator = this.a.iterator();
    while (iterator.hasNext())
      ((m)iterator.next()).b(); 
  }
  
  public boolean c() {
    int i = this.b;
    boolean bool = true;
    if (i != 1)
      bool = false; 
    return bool;
  }
  
  public void d() {
    this.b = 0;
    this.a.clear();
  }
  
  public void e() {}
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\i\j\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */