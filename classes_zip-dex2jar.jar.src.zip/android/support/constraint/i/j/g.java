package android.support.constraint.i.j;

import android.support.constraint.i.e;
import android.support.constraint.i.i;
import java.util.ArrayList;

public class g extends e {
  protected float e0 = -1.0F;
  
  protected int f0 = -1;
  
  protected int g0 = -1;
  
  private d h0 = this.s;
  
  private int i0 = 0;
  
  private boolean j0 = false;
  
  public g() {
    new j();
    this.A.clear();
    this.A.add(this.h0);
    int i = this.z.length;
    for (byte b = 0; b < i; b++)
      this.z[b] = this.h0; 
  }
  
  public int H() {
    return this.i0;
  }
  
  public d a(d.d paramd) {
    switch (a.a[paramd.ordinal()]) {
      default:
        throw new AssertionError(paramd.name());
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
        return null;
      case 3:
      case 4:
        if (this.i0 == 0)
          return this.h0; 
      case 1:
      case 2:
        break;
    } 
    if (this.i0 == 1)
      return this.h0; 
  }
  
  public void a(int paramInt) {
    e e1 = l();
    if (e1 == null)
      return; 
    if (H() == 1) {
      this.s.d().a(1, e1.s.d(), 0);
      this.u.d().a(1, e1.s.d(), 0);
      if (this.f0 != -1) {
        this.r.d().a(1, e1.r.d(), this.f0);
        this.t.d().a(1, e1.r.d(), this.f0);
      } else if (this.g0 != -1) {
        this.r.d().a(1, e1.t.d(), -this.g0);
        this.t.d().a(1, e1.t.d(), -this.g0);
      } else if (this.e0 != -1.0F && e1.k() == e.b.c) {
        paramInt = (int)(e1.D * this.e0);
        this.r.d().a(1, e1.r.d(), paramInt);
        this.t.d().a(1, e1.r.d(), paramInt);
      } 
    } else {
      this.r.d().a(1, e1.r.d(), 0);
      this.t.d().a(1, e1.r.d(), 0);
      if (this.f0 != -1) {
        this.s.d().a(1, e1.s.d(), this.f0);
        this.u.d().a(1, e1.s.d(), this.f0);
      } else if (this.g0 != -1) {
        this.s.d().a(1, e1.u.d(), -this.g0);
        this.u.d().a(1, e1.u.d(), -this.g0);
      } else if (this.e0 != -1.0F && e1.r() == e.b.c) {
        paramInt = (int)(e1.E * this.e0);
        this.s.d().a(1, e1.s.d(), paramInt);
        this.u.d().a(1, e1.s.d(), paramInt);
      } 
    } 
  }
  
  public void a(e parame) {
    boolean bool1;
    f f = (f)l();
    if (f == null)
      return; 
    d d1 = f.a(d.d.d);
    d d2 = f.a(d.d.f);
    e e1 = this.C;
    boolean bool2 = true;
    if (e1 != null && e1.B[0] == e.b.d) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (this.i0 == 0) {
      d1 = f.a(d.d.e);
      d2 = f.a(d.d.g);
      e e2 = this.C;
      if (e2 != null && e2.B[1] == e.b.d) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
    } 
    if (this.f0 != -1) {
      i i = parame.a(this.h0);
      parame.a(i, parame.a(d1), this.f0, 6);
      if (bool1)
        parame.b(parame.a(d2), i, 0, 5); 
    } else {
      i i;
      if (this.g0 != -1) {
        i i1 = parame.a(this.h0);
        i = parame.a(d2);
        parame.a(i1, i, -this.g0, 6);
        if (bool1) {
          parame.b(i1, parame.a(d1), 0, 5);
          parame.b(i, i1, 0, 5);
        } 
      } else if (this.e0 != -1.0F) {
        parame.a(e.a(parame, parame.a(this.h0), parame.a(d1), parame.a(i), this.e0, this.j0));
      } 
    } 
  }
  
  public boolean a() {
    return true;
  }
  
  public ArrayList<d> b() {
    return this.A;
  }
  
  public void c(e parame) {
    if (l() == null)
      return; 
    int i = parame.b(this.h0);
    if (this.i0 == 1) {
      n(i);
      o(0);
      c(l().i());
      k(0);
    } else {
      n(0);
      o(i);
      k(l().t());
      c(0);
    } 
  }
  
  public void e(float paramFloat) {
    if (paramFloat > -1.0F) {
      this.e0 = paramFloat;
      this.f0 = -1;
      this.g0 = -1;
    } 
  }
  
  public void p(int paramInt) {
    if (paramInt > -1) {
      this.e0 = -1.0F;
      this.f0 = paramInt;
      this.g0 = -1;
    } 
  }
  
  public void q(int paramInt) {
    if (paramInt > -1) {
      this.e0 = -1.0F;
      this.f0 = -1;
      this.g0 = paramInt;
    } 
  }
  
  public void r(int paramInt) {
    if (this.i0 == paramInt)
      return; 
    this.i0 = paramInt;
    this.A.clear();
    if (this.i0 == 1) {
      this.h0 = this.r;
    } else {
      this.h0 = this.s;
    } 
    this.A.add(this.h0);
    int i = this.z.length;
    for (paramInt = 0; paramInt < i; paramInt++)
      this.z[paramInt] = this.h0; 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\i\j\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */