package android.support.constraint.i.j;

import android.support.constraint.i.e;

public class i {
  static boolean[] a = new boolean[3];
  
  static void a(int paramInt, e parame) {
    int j;
    parame.G();
    k k4 = parame.r.d();
    k k1 = parame.s.d();
    k k2 = parame.t.d();
    k k3 = parame.u.d();
    if ((paramInt & 0x8) == 8) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (parame.B[0] == e.b.e && a(parame, 0)) {
      j = 1;
    } else {
      j = 0;
    } 
    if (k4.h != 4 && k2.h != 4)
      if (parame.B[0] == e.b.c || (j && parame.s() == 8)) {
        if (parame.r.d == null && parame.t.d == null) {
          k4.b(1);
          k2.b(1);
          if (paramInt != 0) {
            k2.a(k4, 1, parame.n());
          } else {
            k2.a(k4, parame.t());
          } 
        } else if (parame.r.d != null && parame.t.d == null) {
          k4.b(1);
          k2.b(1);
          if (paramInt != 0) {
            k2.a(k4, 1, parame.n());
          } else {
            k2.a(k4, parame.t());
          } 
        } else if (parame.r.d == null && parame.t.d != null) {
          k4.b(1);
          k2.b(1);
          k4.a(k2, -parame.t());
          if (paramInt != 0) {
            k4.a(k2, -1, parame.n());
          } else {
            k4.a(k2, -parame.t());
          } 
        } else if (parame.r.d != null && parame.t.d != null) {
          k4.b(2);
          k2.b(2);
          if (paramInt != 0) {
            parame.n().a(k4);
            parame.n().a(k2);
            k4.b(k2, -1, parame.n());
            k2.b(k4, 1, parame.n());
          } else {
            k4.b(k2, -parame.t());
            k2.b(k4, parame.t());
          } 
        } 
      } else if (j) {
        j = parame.t();
        k4.b(1);
        k2.b(1);
        if (parame.r.d == null && parame.t.d == null) {
          if (paramInt != 0) {
            k2.a(k4, 1, parame.n());
          } else {
            k2.a(k4, j);
          } 
        } else if (parame.r.d != null && parame.t.d == null) {
          if (paramInt != 0) {
            k2.a(k4, 1, parame.n());
          } else {
            k2.a(k4, j);
          } 
        } else if (parame.r.d == null && parame.t.d != null) {
          if (paramInt != 0) {
            k4.a(k2, -1, parame.n());
          } else {
            k4.a(k2, -j);
          } 
        } else if (parame.r.d != null && parame.t.d != null) {
          if (paramInt != 0) {
            parame.n().a(k4);
            parame.n().a(k2);
          } 
          if (parame.F == 0.0F) {
            k4.b(3);
            k2.b(3);
            k4.b(k2, 0.0F);
            k2.b(k4, 0.0F);
          } else {
            k4.b(2);
            k2.b(2);
            k4.b(k2, -j);
            k2.b(k4, j);
            parame.k(j);
          } 
        } 
      }  
    if (parame.B[1] == e.b.e && a(parame, 1)) {
      j = 1;
    } else {
      j = 0;
    } 
    if (k1.h != 4 && k3.h != 4) {
      if (parame.B[1] == e.b.c || (j != 0 && parame.s() == 8)) {
        if (parame.s.d == null && parame.u.d == null) {
          k1.b(1);
          k3.b(1);
          if (paramInt != 0) {
            k3.a(k1, 1, parame.m());
          } else {
            k3.a(k1, parame.i());
          } 
          d d = parame.v;
          if (d.d != null) {
            d.d().b(1);
            k1.a(1, parame.v.d(), -parame.N);
          } 
        } else if (parame.s.d != null && parame.u.d == null) {
          k1.b(1);
          k3.b(1);
          if (paramInt != 0) {
            k3.a(k1, 1, parame.m());
          } else {
            k3.a(k1, parame.i());
          } 
          if (parame.N > 0)
            parame.v.d().a(1, k1, parame.N); 
        } else if (parame.s.d == null && parame.u.d != null) {
          k1.b(1);
          k3.b(1);
          if (paramInt != 0) {
            k1.a(k3, -1, parame.m());
          } else {
            k1.a(k3, -parame.i());
          } 
          if (parame.N > 0)
            parame.v.d().a(1, k1, parame.N); 
        } else if (parame.s.d != null && parame.u.d != null) {
          k1.b(2);
          k3.b(2);
          if (paramInt != 0) {
            k1.b(k3, -1, parame.m());
            k3.b(k1, 1, parame.m());
            parame.m().a(k1);
            parame.n().a(k3);
          } else {
            k1.b(k3, -parame.i());
            k3.b(k1, parame.i());
          } 
          if (parame.N > 0)
            parame.v.d().a(1, k1, parame.N); 
        } 
        return;
      } 
      if (j != 0) {
        j = parame.i();
        k1.b(1);
        k3.b(1);
        if (parame.s.d == null && parame.u.d == null) {
          if (paramInt != 0) {
            k3.a(k1, 1, parame.m());
          } else {
            k3.a(k1, j);
          } 
        } else if (parame.s.d != null && parame.u.d == null) {
          if (paramInt != 0) {
            k3.a(k1, 1, parame.m());
          } else {
            k3.a(k1, j);
          } 
        } else if (parame.s.d == null && parame.u.d != null) {
          if (paramInt != 0) {
            k1.a(k3, -1, parame.m());
          } else {
            k1.a(k3, -j);
          } 
        } else if (parame.s.d != null && parame.u.d != null) {
          if (paramInt != 0) {
            parame.m().a(k1);
            parame.n().a(k3);
          } 
          if (parame.F == 0.0F) {
            k1.b(3);
            k3.b(3);
            k1.b(k3, 0.0F);
            k3.b(k1, 0.0F);
          } else {
            k1.b(2);
            k3.b(2);
            k1.b(k3, -j);
            k3.b(k1, j);
            parame.c(j);
            if (parame.N > 0)
              parame.v.d().a(1, k1, parame.N); 
          } 
        } 
      } 
    } 
  }
  
  static void a(f paramf, e parame, e parame1) {
    if (paramf.B[0] != e.b.d && parame1.B[0] == e.b.f) {
      int k = parame1.r.e;
      int j = paramf.t() - parame1.t.e;
      d d = parame1.r;
      d.i = parame.a(d);
      d = parame1.t;
      d.i = parame.a(d);
      parame.a(parame1.r.i, k);
      parame.a(parame1.t.i, j);
      parame1.a = 2;
      parame1.a(k, j);
    } 
    if (paramf.B[1] != e.b.d && parame1.B[1] == e.b.f) {
      int j = parame1.s.e;
      int k = paramf.i() - parame1.u.e;
      d d = parame1.s;
      d.i = parame.a(d);
      d = parame1.u;
      d.i = parame.a(d);
      parame.a(parame1.s.i, j);
      parame.a(parame1.u.i, k);
      if (parame1.N > 0 || parame1.s() == 8) {
        d = parame1.v;
        d.i = parame.a(d);
        parame.a(parame1.v.i, parame1.N + j);
      } 
      parame1.b = 2;
      parame1.d(j, k);
    } 
  }
  
  private static boolean a(e parame, int paramInt) {
    e.b[] arrayOfB = parame.B;
    if (arrayOfB[paramInt] != e.b.e)
      return false; 
    float f = parame.F;
    boolean bool = true;
    if (f != 0.0F) {
      if (paramInt == 0) {
        paramInt = bool;
      } else {
        paramInt = 0;
      } 
      return (arrayOfB[paramInt] == e.b.e) ? false : false;
    } 
    if (paramInt == 0) {
      if (parame.e != 0)
        return false; 
      if (parame.h != 0 || parame.i != 0)
        return false; 
    } else {
      if (parame.f != 0)
        return false; 
      if (parame.k != 0 || parame.l != 0)
        return false; 
    } 
    return true;
  }
  
  static boolean a(f paramf, e parame, int paramInt1, int paramInt2, c paramc) {
    // Byte code:
    //   0: aload #4
    //   2: getfield a : Landroid/support/constraint/i/j/e;
    //   5: astore #21
    //   7: aload #4
    //   9: getfield c : Landroid/support/constraint/i/j/e;
    //   12: astore #24
    //   14: aload #4
    //   16: getfield b : Landroid/support/constraint/i/j/e;
    //   19: astore #20
    //   21: aload #4
    //   23: getfield d : Landroid/support/constraint/i/j/e;
    //   26: astore #23
    //   28: aload #4
    //   30: getfield e : Landroid/support/constraint/i/j/e;
    //   33: astore #25
    //   35: iconst_0
    //   36: istore #14
    //   38: aload #4
    //   40: getfield k : F
    //   43: fstore #7
    //   45: aload #4
    //   47: getfield f : Landroid/support/constraint/i/j/e;
    //   50: astore #22
    //   52: aload #4
    //   54: getfield g : Landroid/support/constraint/i/j/e;
    //   57: astore #4
    //   59: aload_0
    //   60: getfield B : [Landroid/support/constraint/i/j/e$b;
    //   63: iload_2
    //   64: aaload
    //   65: getstatic android/support/constraint/i/j/e$b.d : Landroid/support/constraint/i/j/e$b;
    //   68: if_acmpne -> 77
    //   71: iconst_1
    //   72: istore #19
    //   74: goto -> 80
    //   77: iconst_0
    //   78: istore #19
    //   80: iload_2
    //   81: ifne -> 152
    //   84: aload #25
    //   86: getfield Y : I
    //   89: ifne -> 98
    //   92: iconst_1
    //   93: istore #13
    //   95: goto -> 101
    //   98: iconst_0
    //   99: istore #13
    //   101: aload #25
    //   103: getfield Y : I
    //   106: iconst_1
    //   107: if_icmpne -> 116
    //   110: iconst_1
    //   111: istore #12
    //   113: goto -> 119
    //   116: iconst_0
    //   117: istore #12
    //   119: aload #25
    //   121: getfield Y : I
    //   124: istore #15
    //   126: iload #12
    //   128: istore #17
    //   130: iload #15
    //   132: iconst_2
    //   133: if_icmpne -> 142
    //   136: iconst_1
    //   137: istore #12
    //   139: goto -> 145
    //   142: iconst_0
    //   143: istore #12
    //   145: iload #13
    //   147: istore #16
    //   149: goto -> 217
    //   152: aload #25
    //   154: getfield Z : I
    //   157: ifne -> 166
    //   160: iconst_1
    //   161: istore #12
    //   163: goto -> 169
    //   166: iconst_0
    //   167: istore #12
    //   169: iload #12
    //   171: istore #16
    //   173: aload #25
    //   175: getfield Z : I
    //   178: iconst_1
    //   179: if_icmpne -> 188
    //   182: iconst_1
    //   183: istore #12
    //   185: goto -> 191
    //   188: iconst_0
    //   189: istore #12
    //   191: aload #25
    //   193: getfield Z : I
    //   196: istore #13
    //   198: iload #12
    //   200: istore #17
    //   202: iload #13
    //   204: iconst_2
    //   205: if_icmpne -> 214
    //   208: iconst_1
    //   209: istore #12
    //   211: goto -> 217
    //   214: iconst_0
    //   215: istore #12
    //   217: iconst_0
    //   218: istore #13
    //   220: iconst_0
    //   221: istore #15
    //   223: fconst_0
    //   224: fstore #8
    //   226: fconst_0
    //   227: fstore #9
    //   229: aload #21
    //   231: astore #4
    //   233: iload #14
    //   235: ifne -> 555
    //   238: iload #15
    //   240: istore #18
    //   242: fload #9
    //   244: fstore #5
    //   246: fload #8
    //   248: fstore #6
    //   250: aload #4
    //   252: invokevirtual s : ()I
    //   255: bipush #8
    //   257: if_icmpeq -> 352
    //   260: iload #15
    //   262: iconst_1
    //   263: iadd
    //   264: istore #18
    //   266: iload_2
    //   267: ifne -> 284
    //   270: fload #9
    //   272: aload #4
    //   274: invokevirtual t : ()I
    //   277: i2f
    //   278: fadd
    //   279: fstore #6
    //   281: goto -> 295
    //   284: fload #9
    //   286: aload #4
    //   288: invokevirtual i : ()I
    //   291: i2f
    //   292: fadd
    //   293: fstore #6
    //   295: fload #6
    //   297: fstore #5
    //   299: aload #4
    //   301: aload #20
    //   303: if_acmpeq -> 322
    //   306: fload #6
    //   308: aload #4
    //   310: getfield z : [Landroid/support/constraint/i/j/d;
    //   313: iload_3
    //   314: aaload
    //   315: invokevirtual b : ()I
    //   318: i2f
    //   319: fadd
    //   320: fstore #5
    //   322: fload #8
    //   324: aload #4
    //   326: getfield z : [Landroid/support/constraint/i/j/d;
    //   329: iload_3
    //   330: aaload
    //   331: invokevirtual b : ()I
    //   334: i2f
    //   335: fadd
    //   336: aload #4
    //   338: getfield z : [Landroid/support/constraint/i/j/d;
    //   341: iload_3
    //   342: iconst_1
    //   343: iadd
    //   344: aaload
    //   345: invokevirtual b : ()I
    //   348: i2f
    //   349: fadd
    //   350: fstore #6
    //   352: aload #4
    //   354: getfield z : [Landroid/support/constraint/i/j/d;
    //   357: iload_3
    //   358: aaload
    //   359: astore_0
    //   360: iload #13
    //   362: istore #15
    //   364: aload #4
    //   366: invokevirtual s : ()I
    //   369: bipush #8
    //   371: if_icmpeq -> 457
    //   374: iload #13
    //   376: istore #15
    //   378: aload #4
    //   380: getfield B : [Landroid/support/constraint/i/j/e$b;
    //   383: iload_2
    //   384: aaload
    //   385: getstatic android/support/constraint/i/j/e$b.e : Landroid/support/constraint/i/j/e$b;
    //   388: if_acmpne -> 457
    //   391: iload #13
    //   393: iconst_1
    //   394: iadd
    //   395: istore #15
    //   397: iload_2
    //   398: ifne -> 429
    //   401: aload #4
    //   403: getfield e : I
    //   406: ifeq -> 411
    //   409: iconst_0
    //   410: ireturn
    //   411: aload #4
    //   413: getfield h : I
    //   416: ifne -> 427
    //   419: aload #4
    //   421: getfield i : I
    //   424: ifeq -> 457
    //   427: iconst_0
    //   428: ireturn
    //   429: aload #4
    //   431: getfield f : I
    //   434: ifeq -> 439
    //   437: iconst_0
    //   438: ireturn
    //   439: aload #4
    //   441: getfield k : I
    //   444: ifne -> 455
    //   447: aload #4
    //   449: getfield l : I
    //   452: ifeq -> 457
    //   455: iconst_0
    //   456: ireturn
    //   457: aload #4
    //   459: getfield z : [Landroid/support/constraint/i/j/d;
    //   462: iload_3
    //   463: iconst_1
    //   464: iadd
    //   465: aaload
    //   466: getfield d : Landroid/support/constraint/i/j/d;
    //   469: astore_0
    //   470: aload_0
    //   471: ifnull -> 521
    //   474: aload_0
    //   475: getfield b : Landroid/support/constraint/i/j/e;
    //   478: astore_0
    //   479: aload_0
    //   480: getfield z : [Landroid/support/constraint/i/j/d;
    //   483: astore #25
    //   485: aload #25
    //   487: iload_3
    //   488: aaload
    //   489: getfield d : Landroid/support/constraint/i/j/d;
    //   492: ifnull -> 516
    //   495: aload #25
    //   497: iload_3
    //   498: aaload
    //   499: getfield d : Landroid/support/constraint/i/j/d;
    //   502: getfield b : Landroid/support/constraint/i/j/e;
    //   505: aload #4
    //   507: if_acmpeq -> 513
    //   510: goto -> 516
    //   513: goto -> 523
    //   516: aconst_null
    //   517: astore_0
    //   518: goto -> 523
    //   521: aconst_null
    //   522: astore_0
    //   523: aload_0
    //   524: ifnull -> 533
    //   527: aload_0
    //   528: astore #4
    //   530: goto -> 536
    //   533: iconst_1
    //   534: istore #14
    //   536: iload #15
    //   538: istore #13
    //   540: iload #18
    //   542: istore #15
    //   544: fload #5
    //   546: fstore #9
    //   548: fload #6
    //   550: fstore #8
    //   552: goto -> 233
    //   555: aload #21
    //   557: getfield z : [Landroid/support/constraint/i/j/d;
    //   560: iload_3
    //   561: aaload
    //   562: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   565: astore #22
    //   567: aload #24
    //   569: getfield z : [Landroid/support/constraint/i/j/d;
    //   572: iload_3
    //   573: iconst_1
    //   574: iadd
    //   575: aaload
    //   576: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   579: astore #24
    //   581: aload #22
    //   583: getfield d : Landroid/support/constraint/i/j/k;
    //   586: astore_0
    //   587: aload_0
    //   588: ifnull -> 1778
    //   591: aload #24
    //   593: getfield d : Landroid/support/constraint/i/j/k;
    //   596: astore #25
    //   598: aload #25
    //   600: ifnonnull -> 606
    //   603: goto -> 1778
    //   606: aload_0
    //   607: getfield b : I
    //   610: iconst_1
    //   611: if_icmpeq -> 625
    //   614: aload #25
    //   616: getfield b : I
    //   619: iconst_1
    //   620: if_icmpeq -> 625
    //   623: iconst_0
    //   624: ireturn
    //   625: iload #13
    //   627: ifle -> 639
    //   630: iload #13
    //   632: iload #15
    //   634: if_icmpeq -> 639
    //   637: iconst_0
    //   638: ireturn
    //   639: fconst_0
    //   640: fstore #5
    //   642: fconst_0
    //   643: fstore #6
    //   645: iload #12
    //   647: ifne -> 660
    //   650: iload #16
    //   652: ifne -> 660
    //   655: iload #17
    //   657: ifeq -> 705
    //   660: aload #20
    //   662: ifnull -> 678
    //   665: aload #20
    //   667: getfield z : [Landroid/support/constraint/i/j/d;
    //   670: iload_3
    //   671: aaload
    //   672: invokevirtual b : ()I
    //   675: i2f
    //   676: fstore #6
    //   678: fload #6
    //   680: fstore #5
    //   682: aload #23
    //   684: ifnull -> 705
    //   687: fload #6
    //   689: aload #23
    //   691: getfield z : [Landroid/support/constraint/i/j/d;
    //   694: iload_3
    //   695: iconst_1
    //   696: iadd
    //   697: aaload
    //   698: invokevirtual b : ()I
    //   701: i2f
    //   702: fadd
    //   703: fstore #5
    //   705: aload #22
    //   707: getfield d : Landroid/support/constraint/i/j/k;
    //   710: getfield g : F
    //   713: fstore #10
    //   715: aload #24
    //   717: getfield d : Landroid/support/constraint/i/j/k;
    //   720: getfield g : F
    //   723: fstore #6
    //   725: fload #10
    //   727: fload #6
    //   729: fcmpg
    //   730: ifge -> 746
    //   733: fload #6
    //   735: fload #10
    //   737: fsub
    //   738: fload #9
    //   740: fsub
    //   741: fstore #6
    //   743: goto -> 756
    //   746: fload #10
    //   748: fload #6
    //   750: fsub
    //   751: fload #9
    //   753: fsub
    //   754: fstore #6
    //   756: iload #13
    //   758: ifle -> 1164
    //   761: iload #13
    //   763: iload #15
    //   765: if_icmpne -> 1164
    //   768: aload #4
    //   770: invokevirtual l : ()Landroid/support/constraint/i/j/e;
    //   773: ifnull -> 794
    //   776: aload #4
    //   778: invokevirtual l : ()Landroid/support/constraint/i/j/e;
    //   781: getfield B : [Landroid/support/constraint/i/j/e$b;
    //   784: iload_2
    //   785: aaload
    //   786: getstatic android/support/constraint/i/j/e$b.d : Landroid/support/constraint/i/j/e$b;
    //   789: if_acmpne -> 794
    //   792: iconst_0
    //   793: ireturn
    //   794: fload #6
    //   796: fload #9
    //   798: fadd
    //   799: fload #8
    //   801: fsub
    //   802: fstore #11
    //   804: fload #10
    //   806: fstore #6
    //   808: fload #11
    //   810: fstore #9
    //   812: iload #16
    //   814: ifeq -> 827
    //   817: fload #11
    //   819: fload #8
    //   821: fload #5
    //   823: fsub
    //   824: fsub
    //   825: fstore #9
    //   827: iload #16
    //   829: ifeq -> 917
    //   832: fload #6
    //   834: aload #20
    //   836: getfield z : [Landroid/support/constraint/i/j/d;
    //   839: iload_3
    //   840: iconst_1
    //   841: iadd
    //   842: aaload
    //   843: invokevirtual b : ()I
    //   846: i2f
    //   847: fadd
    //   848: fstore #10
    //   850: aload #20
    //   852: getfield c0 : [Landroid/support/constraint/i/j/e;
    //   855: iload_2
    //   856: aaload
    //   857: astore #24
    //   859: aload #21
    //   861: astore_0
    //   862: fload #5
    //   864: fstore #8
    //   866: iload #13
    //   868: istore #12
    //   870: aload #20
    //   872: astore #4
    //   874: fload #10
    //   876: fstore #6
    //   878: aload #24
    //   880: ifnull -> 932
    //   883: fload #10
    //   885: aload #24
    //   887: getfield z : [Landroid/support/constraint/i/j/d;
    //   890: iload_3
    //   891: aaload
    //   892: invokevirtual b : ()I
    //   895: i2f
    //   896: fadd
    //   897: fstore #6
    //   899: aload #21
    //   901: astore_0
    //   902: fload #5
    //   904: fstore #8
    //   906: iload #13
    //   908: istore #12
    //   910: aload #20
    //   912: astore #4
    //   914: goto -> 932
    //   917: aload #20
    //   919: astore #4
    //   921: iload #13
    //   923: istore #12
    //   925: fload #5
    //   927: fstore #8
    //   929: aload #21
    //   931: astore_0
    //   932: aload #4
    //   934: ifnull -> 1162
    //   937: getstatic android/support/constraint/i/e.q : Landroid/support/constraint/i/f;
    //   940: astore #20
    //   942: aload #20
    //   944: ifnull -> 986
    //   947: aload #20
    //   949: aload #20
    //   951: getfield z : J
    //   954: lconst_1
    //   955: lsub
    //   956: putfield z : J
    //   959: aload #20
    //   961: aload #20
    //   963: getfield r : J
    //   966: lconst_1
    //   967: ladd
    //   968: putfield r : J
    //   971: aload #20
    //   973: aload #20
    //   975: getfield x : J
    //   978: lconst_1
    //   979: ladd
    //   980: putfield x : J
    //   983: goto -> 986
    //   986: aload #4
    //   988: getfield c0 : [Landroid/support/constraint/i/j/e;
    //   991: iload_2
    //   992: aaload
    //   993: astore #20
    //   995: aload #20
    //   997: ifnonnull -> 1013
    //   1000: aload #4
    //   1002: aload #23
    //   1004: if_acmpne -> 1010
    //   1007: goto -> 1013
    //   1010: goto -> 1155
    //   1013: fload #9
    //   1015: iload #12
    //   1017: i2f
    //   1018: fdiv
    //   1019: fstore #5
    //   1021: fload #7
    //   1023: fconst_0
    //   1024: fcmpl
    //   1025: ifle -> 1043
    //   1028: aload #4
    //   1030: getfield a0 : [F
    //   1033: iload_2
    //   1034: faload
    //   1035: fload #9
    //   1037: fmul
    //   1038: fload #7
    //   1040: fdiv
    //   1041: fstore #5
    //   1043: fload #6
    //   1045: aload #4
    //   1047: getfield z : [Landroid/support/constraint/i/j/d;
    //   1050: iload_3
    //   1051: aaload
    //   1052: invokevirtual b : ()I
    //   1055: i2f
    //   1056: fadd
    //   1057: fstore #6
    //   1059: aload #4
    //   1061: getfield z : [Landroid/support/constraint/i/j/d;
    //   1064: iload_3
    //   1065: aaload
    //   1066: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   1069: aload #22
    //   1071: getfield f : Landroid/support/constraint/i/j/k;
    //   1074: fload #6
    //   1076: invokevirtual a : (Landroid/support/constraint/i/j/k;F)V
    //   1079: aload #4
    //   1081: getfield z : [Landroid/support/constraint/i/j/d;
    //   1084: iload_3
    //   1085: iconst_1
    //   1086: iadd
    //   1087: aaload
    //   1088: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   1091: aload #22
    //   1093: getfield f : Landroid/support/constraint/i/j/k;
    //   1096: fload #6
    //   1098: fload #5
    //   1100: fadd
    //   1101: invokevirtual a : (Landroid/support/constraint/i/j/k;F)V
    //   1104: aload #4
    //   1106: getfield z : [Landroid/support/constraint/i/j/d;
    //   1109: iload_3
    //   1110: aaload
    //   1111: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   1114: aload_1
    //   1115: invokevirtual a : (Landroid/support/constraint/i/e;)V
    //   1118: aload #4
    //   1120: getfield z : [Landroid/support/constraint/i/j/d;
    //   1123: iload_3
    //   1124: iconst_1
    //   1125: iadd
    //   1126: aaload
    //   1127: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   1130: aload_1
    //   1131: invokevirtual a : (Landroid/support/constraint/i/e;)V
    //   1134: fload #6
    //   1136: fload #5
    //   1138: fadd
    //   1139: aload #4
    //   1141: getfield z : [Landroid/support/constraint/i/j/d;
    //   1144: iload_3
    //   1145: iconst_1
    //   1146: iadd
    //   1147: aaload
    //   1148: invokevirtual b : ()I
    //   1151: i2f
    //   1152: fadd
    //   1153: fstore #6
    //   1155: aload #20
    //   1157: astore #4
    //   1159: goto -> 932
    //   1162: iconst_1
    //   1163: ireturn
    //   1164: fload #6
    //   1166: fload #9
    //   1168: fcmpg
    //   1169: ifge -> 1174
    //   1172: iconst_0
    //   1173: ireturn
    //   1174: iload #12
    //   1176: ifeq -> 1418
    //   1179: aload #21
    //   1181: invokevirtual j : ()F
    //   1184: fstore #8
    //   1186: aload #20
    //   1188: astore_0
    //   1189: fload #8
    //   1191: fload #6
    //   1193: fload #5
    //   1195: fsub
    //   1196: fmul
    //   1197: fload #10
    //   1199: fadd
    //   1200: fstore #5
    //   1202: aload_0
    //   1203: ifnull -> 1415
    //   1206: getstatic android/support/constraint/i/e.q : Landroid/support/constraint/i/f;
    //   1209: astore #4
    //   1211: aload #4
    //   1213: ifnull -> 1255
    //   1216: aload #4
    //   1218: aload #4
    //   1220: getfield z : J
    //   1223: lconst_1
    //   1224: lsub
    //   1225: putfield z : J
    //   1228: aload #4
    //   1230: aload #4
    //   1232: getfield r : J
    //   1235: lconst_1
    //   1236: ladd
    //   1237: putfield r : J
    //   1240: aload #4
    //   1242: aload #4
    //   1244: getfield x : J
    //   1247: lconst_1
    //   1248: ladd
    //   1249: putfield x : J
    //   1252: goto -> 1255
    //   1255: aload_0
    //   1256: getfield c0 : [Landroid/support/constraint/i/j/e;
    //   1259: iload_2
    //   1260: aaload
    //   1261: astore #4
    //   1263: aload #4
    //   1265: ifnonnull -> 1278
    //   1268: fload #5
    //   1270: fstore #6
    //   1272: aload_0
    //   1273: aload #23
    //   1275: if_acmpne -> 1405
    //   1278: iload_2
    //   1279: ifne -> 1292
    //   1282: aload_0
    //   1283: invokevirtual t : ()I
    //   1286: i2f
    //   1287: fstore #6
    //   1289: goto -> 1299
    //   1292: aload_0
    //   1293: invokevirtual i : ()I
    //   1296: i2f
    //   1297: fstore #6
    //   1299: fload #5
    //   1301: aload_0
    //   1302: getfield z : [Landroid/support/constraint/i/j/d;
    //   1305: iload_3
    //   1306: aaload
    //   1307: invokevirtual b : ()I
    //   1310: i2f
    //   1311: fadd
    //   1312: fstore #5
    //   1314: aload_0
    //   1315: getfield z : [Landroid/support/constraint/i/j/d;
    //   1318: iload_3
    //   1319: aaload
    //   1320: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   1323: aload #22
    //   1325: getfield f : Landroid/support/constraint/i/j/k;
    //   1328: fload #5
    //   1330: invokevirtual a : (Landroid/support/constraint/i/j/k;F)V
    //   1333: aload_0
    //   1334: getfield z : [Landroid/support/constraint/i/j/d;
    //   1337: iload_3
    //   1338: iconst_1
    //   1339: iadd
    //   1340: aaload
    //   1341: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   1344: aload #22
    //   1346: getfield f : Landroid/support/constraint/i/j/k;
    //   1349: fload #5
    //   1351: fload #6
    //   1353: fadd
    //   1354: invokevirtual a : (Landroid/support/constraint/i/j/k;F)V
    //   1357: aload_0
    //   1358: getfield z : [Landroid/support/constraint/i/j/d;
    //   1361: iload_3
    //   1362: aaload
    //   1363: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   1366: aload_1
    //   1367: invokevirtual a : (Landroid/support/constraint/i/e;)V
    //   1370: aload_0
    //   1371: getfield z : [Landroid/support/constraint/i/j/d;
    //   1374: iload_3
    //   1375: iconst_1
    //   1376: iadd
    //   1377: aaload
    //   1378: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   1381: aload_1
    //   1382: invokevirtual a : (Landroid/support/constraint/i/e;)V
    //   1385: fload #5
    //   1387: fload #6
    //   1389: fadd
    //   1390: aload_0
    //   1391: getfield z : [Landroid/support/constraint/i/j/d;
    //   1394: iload_3
    //   1395: iconst_1
    //   1396: iadd
    //   1397: aaload
    //   1398: invokevirtual b : ()I
    //   1401: i2f
    //   1402: fadd
    //   1403: fstore #6
    //   1405: aload #4
    //   1407: astore_0
    //   1408: fload #6
    //   1410: fstore #5
    //   1412: goto -> 1202
    //   1415: goto -> 1776
    //   1418: fload #7
    //   1420: fstore #8
    //   1422: iload #16
    //   1424: ifne -> 1438
    //   1427: iload #17
    //   1429: ifeq -> 1435
    //   1432: goto -> 1438
    //   1435: goto -> 1776
    //   1438: iload #16
    //   1440: ifeq -> 1453
    //   1443: fload #6
    //   1445: fload #5
    //   1447: fsub
    //   1448: fstore #7
    //   1450: goto -> 1469
    //   1453: fload #6
    //   1455: fstore #7
    //   1457: iload #17
    //   1459: ifeq -> 1469
    //   1462: fload #6
    //   1464: fload #5
    //   1466: fsub
    //   1467: fstore #7
    //   1469: fload #7
    //   1471: iload #15
    //   1473: iconst_1
    //   1474: iadd
    //   1475: i2f
    //   1476: fdiv
    //   1477: fstore #5
    //   1479: iload #17
    //   1481: ifeq -> 1509
    //   1484: iload #15
    //   1486: iconst_1
    //   1487: if_icmple -> 1503
    //   1490: fload #7
    //   1492: iload #15
    //   1494: iconst_1
    //   1495: isub
    //   1496: i2f
    //   1497: fdiv
    //   1498: fstore #5
    //   1500: goto -> 1509
    //   1503: fload #7
    //   1505: fconst_2
    //   1506: fdiv
    //   1507: fstore #5
    //   1509: fload #10
    //   1511: fload #5
    //   1513: fadd
    //   1514: fstore #7
    //   1516: fload #7
    //   1518: fstore #6
    //   1520: iload #17
    //   1522: ifeq -> 1551
    //   1525: fload #7
    //   1527: fstore #6
    //   1529: iload #15
    //   1531: iconst_1
    //   1532: if_icmple -> 1551
    //   1535: fload #10
    //   1537: aload #20
    //   1539: getfield z : [Landroid/support/constraint/i/j/d;
    //   1542: iload_3
    //   1543: aaload
    //   1544: invokevirtual b : ()I
    //   1547: i2f
    //   1548: fadd
    //   1549: fstore #6
    //   1551: iload #16
    //   1553: ifeq -> 1587
    //   1556: aload #20
    //   1558: ifnull -> 1587
    //   1561: aload #20
    //   1563: getfield z : [Landroid/support/constraint/i/j/d;
    //   1566: iload_3
    //   1567: aaload
    //   1568: invokevirtual b : ()I
    //   1571: i2f
    //   1572: fstore #7
    //   1574: aload #20
    //   1576: astore_0
    //   1577: fload #6
    //   1579: fload #7
    //   1581: fadd
    //   1582: fstore #6
    //   1584: goto -> 1590
    //   1587: aload #20
    //   1589: astore_0
    //   1590: aload_0
    //   1591: ifnull -> 1776
    //   1594: getstatic android/support/constraint/i/e.q : Landroid/support/constraint/i/f;
    //   1597: astore #4
    //   1599: aload #4
    //   1601: ifnull -> 1643
    //   1604: aload #4
    //   1606: aload #4
    //   1608: getfield z : J
    //   1611: lconst_1
    //   1612: lsub
    //   1613: putfield z : J
    //   1616: aload #4
    //   1618: aload #4
    //   1620: getfield r : J
    //   1623: lconst_1
    //   1624: ladd
    //   1625: putfield r : J
    //   1628: aload #4
    //   1630: aload #4
    //   1632: getfield x : J
    //   1635: lconst_1
    //   1636: ladd
    //   1637: putfield x : J
    //   1640: goto -> 1643
    //   1643: aload_0
    //   1644: getfield c0 : [Landroid/support/constraint/i/j/e;
    //   1647: iload_2
    //   1648: aaload
    //   1649: astore #4
    //   1651: aload #4
    //   1653: ifnonnull -> 1668
    //   1656: aload_0
    //   1657: aload #23
    //   1659: if_acmpne -> 1665
    //   1662: goto -> 1668
    //   1665: goto -> 1770
    //   1668: iload_2
    //   1669: ifne -> 1682
    //   1672: aload_0
    //   1673: invokevirtual t : ()I
    //   1676: i2f
    //   1677: fstore #7
    //   1679: goto -> 1689
    //   1682: aload_0
    //   1683: invokevirtual i : ()I
    //   1686: i2f
    //   1687: fstore #7
    //   1689: aload_0
    //   1690: getfield z : [Landroid/support/constraint/i/j/d;
    //   1693: iload_3
    //   1694: aaload
    //   1695: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   1698: aload #22
    //   1700: getfield f : Landroid/support/constraint/i/j/k;
    //   1703: fload #6
    //   1705: invokevirtual a : (Landroid/support/constraint/i/j/k;F)V
    //   1708: aload_0
    //   1709: getfield z : [Landroid/support/constraint/i/j/d;
    //   1712: iload_3
    //   1713: iconst_1
    //   1714: iadd
    //   1715: aaload
    //   1716: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   1719: aload #22
    //   1721: getfield f : Landroid/support/constraint/i/j/k;
    //   1724: fload #6
    //   1726: fload #7
    //   1728: fadd
    //   1729: invokevirtual a : (Landroid/support/constraint/i/j/k;F)V
    //   1732: aload_0
    //   1733: getfield z : [Landroid/support/constraint/i/j/d;
    //   1736: iload_3
    //   1737: aaload
    //   1738: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   1741: aload_1
    //   1742: invokevirtual a : (Landroid/support/constraint/i/e;)V
    //   1745: aload_0
    //   1746: getfield z : [Landroid/support/constraint/i/j/d;
    //   1749: iload_3
    //   1750: iconst_1
    //   1751: iadd
    //   1752: aaload
    //   1753: invokevirtual d : ()Landroid/support/constraint/i/j/k;
    //   1756: aload_1
    //   1757: invokevirtual a : (Landroid/support/constraint/i/e;)V
    //   1760: fload #6
    //   1762: fload #7
    //   1764: fload #5
    //   1766: fadd
    //   1767: fadd
    //   1768: fstore #6
    //   1770: aload #4
    //   1772: astore_0
    //   1773: goto -> 1590
    //   1776: iconst_1
    //   1777: ireturn
    //   1778: iconst_0
    //   1779: ireturn
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\i\j\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */