package android.support.constraint.i;

public class d extends b {
  public d(c paramc) {
    super(paramc);
  }
  
  public void a(i parami) {
    super.a(parami);
    parami.j--;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\i\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */