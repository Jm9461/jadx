package android.support.constraint.i;

interface g<T> {
  T a();
  
  void a(T[] paramArrayOfT, int paramInt);
  
  boolean a(T paramT);
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\i\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */