package android.support.constraint;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.support.constraint.i.j.a;
import android.support.constraint.i.j.h;
import android.util.AttributeSet;

public class a extends b {
  private int i = 0;
  
  private int j = 0;
  
  private a k;
  
  public a(Context paramContext) {
    super(paramContext);
    setVisibility(8);
  }
  
  protected void a(AttributeSet paramAttributeSet) {
    super.a(paramAttributeSet);
    this.k = new a();
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, h.ConstraintLayout_Layout);
      int i = typedArray.getIndexCount();
      for (byte b1 = 0; b1 < i; b1++) {
        int j = typedArray.getIndex(b1);
        if (j == h.ConstraintLayout_Layout_barrierDirection) {
          setType(typedArray.getInt(j, 0));
        } else if (j == h.ConstraintLayout_Layout_barrierAllowsGoneWidgets) {
          this.k.c(typedArray.getBoolean(j, true));
        } 
      } 
    } 
    this.f = (h)this.k;
    a();
  }
  
  public int getType() {
    return this.i;
  }
  
  public void setType(int paramInt) {
    this.i = paramInt;
    this.j = paramInt;
    if (Build.VERSION.SDK_INT < 17) {
      paramInt = this.i;
      if (paramInt == 5) {
        this.j = 0;
      } else if (paramInt == 6) {
        this.j = 1;
      } 
    } else {
      if (1 == getResources().getConfiguration().getLayoutDirection()) {
        paramInt = 1;
      } else {
        paramInt = 0;
      } 
      if (paramInt != 0) {
        paramInt = this.i;
        if (paramInt == 5) {
          this.j = 1;
        } else if (paramInt == 6) {
          this.j = 0;
        } 
      } else {
        paramInt = this.i;
        if (paramInt == 5) {
          this.j = 0;
        } else if (paramInt == 6) {
          this.j = 1;
        } 
      } 
    } 
    this.k.p(this.j);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */