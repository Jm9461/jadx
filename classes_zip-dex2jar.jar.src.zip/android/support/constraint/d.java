package android.support.constraint;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.ViewGroup;

public class d extends ViewGroup {
  c c;
  
  protected a generateDefaultLayoutParams() {
    return new a(-2, -2);
  }
  
  public a generateLayoutParams(AttributeSet paramAttributeSet) {
    return new a(getContext(), paramAttributeSet);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new ConstraintLayout.a(paramLayoutParams);
  }
  
  public c getConstraintSet() {
    if (this.c == null)
      this.c = new c(); 
    this.c.a(this);
    return this.c;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public static class a extends ConstraintLayout.a {
    public float m0 = 1.0F;
    
    public boolean n0 = false;
    
    public float o0 = 0.0F;
    
    public float p0 = 0.0F;
    
    public float q0 = 0.0F;
    
    public float r0 = 0.0F;
    
    public float s0 = 1.0F;
    
    public float t0 = 1.0F;
    
    public float u0 = 0.0F;
    
    public float v0 = 0.0F;
    
    public float w0 = 0.0F;
    
    public float x0 = 0.0F;
    
    public float y0 = 0.0F;
    
    public a(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public a(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, h.ConstraintSet);
      int i = typedArray.getIndexCount();
      for (byte b = 0; b < i; b++) {
        int j = typedArray.getIndex(b);
        if (j == h.ConstraintSet_android_alpha) {
          this.m0 = typedArray.getFloat(j, this.m0);
        } else if (j == h.ConstraintSet_android_elevation) {
          this.o0 = typedArray.getFloat(j, this.o0);
          this.n0 = true;
        } else if (j == h.ConstraintSet_android_rotationX) {
          this.q0 = typedArray.getFloat(j, this.q0);
        } else if (j == h.ConstraintSet_android_rotationY) {
          this.r0 = typedArray.getFloat(j, this.r0);
        } else if (j == h.ConstraintSet_android_rotation) {
          this.p0 = typedArray.getFloat(j, this.p0);
        } else if (j == h.ConstraintSet_android_scaleX) {
          this.s0 = typedArray.getFloat(j, this.s0);
        } else if (j == h.ConstraintSet_android_scaleY) {
          this.t0 = typedArray.getFloat(j, this.t0);
        } else if (j == h.ConstraintSet_android_transformPivotX) {
          this.u0 = typedArray.getFloat(j, this.u0);
        } else if (j == h.ConstraintSet_android_transformPivotY) {
          this.v0 = typedArray.getFloat(j, this.v0);
        } else if (j == h.ConstraintSet_android_translationX) {
          this.w0 = typedArray.getFloat(j, this.w0);
        } else if (j == h.ConstraintSet_android_translationY) {
          this.x0 = typedArray.getFloat(j, this.x0);
        } else if (j == h.ConstraintSet_android_translationZ) {
          this.w0 = typedArray.getFloat(j, this.y0);
        } 
      } 
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */