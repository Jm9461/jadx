package android.support.constraint;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Build;
import android.support.constraint.i.f;
import android.support.constraint.i.j.d;
import android.support.constraint.i.j.e;
import android.support.constraint.i.j.f;
import android.support.constraint.i.j.g;
import android.support.constraint.i.j.k;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.HashMap;

public class ConstraintLayout extends ViewGroup {
  SparseArray<View> c = new SparseArray();
  
  private ArrayList<b> d = new ArrayList<b>(4);
  
  private final ArrayList<e> e = new ArrayList<e>(100);
  
  f f = new f();
  
  private int g = 0;
  
  private int h = 0;
  
  private int i = Integer.MAX_VALUE;
  
  private int j = Integer.MAX_VALUE;
  
  private boolean k = true;
  
  private int l = 3;
  
  private c m = null;
  
  private int n = -1;
  
  private HashMap<String, Integer> o = new HashMap<String, Integer>();
  
  private int p = -1;
  
  private int q = -1;
  
  int r = -1;
  
  int s = -1;
  
  int t = 0;
  
  int u = 0;
  
  private f v;
  
  public ConstraintLayout(Context paramContext) {
    super(paramContext);
    a((AttributeSet)null);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    a(paramAttributeSet);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    a(paramAttributeSet);
  }
  
  private final e a(int paramInt) {
    e e;
    if (paramInt == 0)
      return (e)this.f; 
    View view = (View)this.c.get(paramInt);
    if (view == this)
      return (e)this.f; 
    if (view == null) {
      view = null;
    } else {
      e = ((a)view.getLayoutParams()).k0;
    } 
    return e;
  }
  
  private void a() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual isInEditMode : ()Z
    //   4: istore #12
    //   6: aload_0
    //   7: invokevirtual getChildCount : ()I
    //   10: istore #9
    //   12: iload #12
    //   14: ifeq -> 113
    //   17: iconst_0
    //   18: istore_2
    //   19: iload_2
    //   20: iload #9
    //   22: if_icmpge -> 113
    //   25: aload_0
    //   26: iload_2
    //   27: invokevirtual getChildAt : (I)Landroid/view/View;
    //   30: astore #15
    //   32: aload_0
    //   33: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   36: aload #15
    //   38: invokevirtual getId : ()I
    //   41: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   44: astore #14
    //   46: aload_0
    //   47: iconst_0
    //   48: aload #14
    //   50: aload #15
    //   52: invokevirtual getId : ()I
    //   55: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   58: invokevirtual a : (ILjava/lang/Object;Ljava/lang/Object;)V
    //   61: aload #14
    //   63: bipush #47
    //   65: invokevirtual indexOf : (I)I
    //   68: istore_3
    //   69: aload #14
    //   71: astore #13
    //   73: iload_3
    //   74: iconst_m1
    //   75: if_icmpeq -> 88
    //   78: aload #14
    //   80: iload_3
    //   81: iconst_1
    //   82: iadd
    //   83: invokevirtual substring : (I)Ljava/lang/String;
    //   86: astore #13
    //   88: aload_0
    //   89: aload #15
    //   91: invokevirtual getId : ()I
    //   94: invokespecial a : (I)Landroid/support/constraint/i/j/e;
    //   97: aload #13
    //   99: invokevirtual a : (Ljava/lang/String;)V
    //   102: goto -> 107
    //   105: astore #13
    //   107: iinc #2, 1
    //   110: goto -> 19
    //   113: iconst_0
    //   114: istore_2
    //   115: iload_2
    //   116: iload #9
    //   118: if_icmpge -> 151
    //   121: aload_0
    //   122: aload_0
    //   123: iload_2
    //   124: invokevirtual getChildAt : (I)Landroid/view/View;
    //   127: invokevirtual a : (Landroid/view/View;)Landroid/support/constraint/i/j/e;
    //   130: astore #13
    //   132: aload #13
    //   134: ifnonnull -> 140
    //   137: goto -> 145
    //   140: aload #13
    //   142: invokevirtual B : ()V
    //   145: iinc #2, 1
    //   148: goto -> 115
    //   151: aload_0
    //   152: getfield n : I
    //   155: iconst_m1
    //   156: if_icmpeq -> 212
    //   159: iconst_0
    //   160: istore_2
    //   161: iload_2
    //   162: iload #9
    //   164: if_icmpge -> 212
    //   167: aload_0
    //   168: iload_2
    //   169: invokevirtual getChildAt : (I)Landroid/view/View;
    //   172: astore #13
    //   174: aload #13
    //   176: invokevirtual getId : ()I
    //   179: aload_0
    //   180: getfield n : I
    //   183: if_icmpne -> 206
    //   186: aload #13
    //   188: instanceof android/support/constraint/d
    //   191: ifeq -> 206
    //   194: aload_0
    //   195: aload #13
    //   197: checkcast android/support/constraint/d
    //   200: invokevirtual getConstraintSet : ()Landroid/support/constraint/c;
    //   203: putfield m : Landroid/support/constraint/c;
    //   206: iinc #2, 1
    //   209: goto -> 161
    //   212: aload_0
    //   213: getfield m : Landroid/support/constraint/c;
    //   216: astore #13
    //   218: aload #13
    //   220: ifnull -> 229
    //   223: aload #13
    //   225: aload_0
    //   226: invokevirtual a : (Landroid/support/constraint/ConstraintLayout;)V
    //   229: aload_0
    //   230: getfield f : Landroid/support/constraint/i/j/f;
    //   233: invokevirtual J : ()V
    //   236: aload_0
    //   237: getfield d : Ljava/util/ArrayList;
    //   240: invokevirtual size : ()I
    //   243: istore #8
    //   245: iload #8
    //   247: ifle -> 279
    //   250: iconst_0
    //   251: istore_2
    //   252: iload_2
    //   253: iload #8
    //   255: if_icmpge -> 279
    //   258: aload_0
    //   259: getfield d : Ljava/util/ArrayList;
    //   262: iload_2
    //   263: invokevirtual get : (I)Ljava/lang/Object;
    //   266: checkcast android/support/constraint/b
    //   269: aload_0
    //   270: invokevirtual c : (Landroid/support/constraint/ConstraintLayout;)V
    //   273: iinc #2, 1
    //   276: goto -> 252
    //   279: iconst_0
    //   280: istore_2
    //   281: iload_2
    //   282: iload #9
    //   284: if_icmpge -> 317
    //   287: aload_0
    //   288: iload_2
    //   289: invokevirtual getChildAt : (I)Landroid/view/View;
    //   292: astore #13
    //   294: aload #13
    //   296: instanceof android/support/constraint/f
    //   299: ifeq -> 311
    //   302: aload #13
    //   304: checkcast android/support/constraint/f
    //   307: aload_0
    //   308: invokevirtual b : (Landroid/support/constraint/ConstraintLayout;)V
    //   311: iinc #2, 1
    //   314: goto -> 281
    //   317: iconst_0
    //   318: istore #10
    //   320: iload #10
    //   322: iload #9
    //   324: if_icmpge -> 1956
    //   327: aload_0
    //   328: iload #10
    //   330: invokevirtual getChildAt : (I)Landroid/view/View;
    //   333: astore #15
    //   335: aload_0
    //   336: aload #15
    //   338: invokevirtual a : (Landroid/view/View;)Landroid/support/constraint/i/j/e;
    //   341: astore #14
    //   343: aload #14
    //   345: ifnonnull -> 351
    //   348: goto -> 1950
    //   351: aload #15
    //   353: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   356: checkcast android/support/constraint/ConstraintLayout$a
    //   359: astore #13
    //   361: aload #13
    //   363: invokevirtual a : ()V
    //   366: aload #13
    //   368: getfield l0 : Z
    //   371: ifeq -> 383
    //   374: aload #13
    //   376: iconst_0
    //   377: putfield l0 : Z
    //   380: goto -> 452
    //   383: iload #12
    //   385: ifeq -> 452
    //   388: aload_0
    //   389: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   392: aload #15
    //   394: invokevirtual getId : ()I
    //   397: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   400: astore #16
    //   402: aload_0
    //   403: iconst_0
    //   404: aload #16
    //   406: aload #15
    //   408: invokevirtual getId : ()I
    //   411: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   414: invokevirtual a : (ILjava/lang/Object;Ljava/lang/Object;)V
    //   417: aload #16
    //   419: aload #16
    //   421: ldc 'id/'
    //   423: invokevirtual indexOf : (Ljava/lang/String;)I
    //   426: iconst_3
    //   427: iadd
    //   428: invokevirtual substring : (I)Ljava/lang/String;
    //   431: astore #16
    //   433: aload_0
    //   434: aload #15
    //   436: invokevirtual getId : ()I
    //   439: invokespecial a : (I)Landroid/support/constraint/i/j/e;
    //   442: aload #16
    //   444: invokevirtual a : (Ljava/lang/String;)V
    //   447: goto -> 452
    //   450: astore #16
    //   452: aload #14
    //   454: aload #15
    //   456: invokevirtual getVisibility : ()I
    //   459: invokevirtual j : (I)V
    //   462: aload #13
    //   464: getfield Z : Z
    //   467: ifeq -> 477
    //   470: aload #14
    //   472: bipush #8
    //   474: invokevirtual j : (I)V
    //   477: aload #14
    //   479: aload #15
    //   481: invokevirtual a : (Ljava/lang/Object;)V
    //   484: aload_0
    //   485: getfield f : Landroid/support/constraint/i/j/f;
    //   488: aload #14
    //   490: invokevirtual b : (Landroid/support/constraint/i/j/e;)V
    //   493: aload #13
    //   495: getfield V : Z
    //   498: ifeq -> 509
    //   501: aload #13
    //   503: getfield U : Z
    //   506: ifne -> 519
    //   509: aload_0
    //   510: getfield e : Ljava/util/ArrayList;
    //   513: aload #14
    //   515: invokevirtual add : (Ljava/lang/Object;)Z
    //   518: pop
    //   519: aload #13
    //   521: getfield X : Z
    //   524: ifeq -> 623
    //   527: aload #14
    //   529: checkcast android/support/constraint/i/j/g
    //   532: astore #14
    //   534: aload #13
    //   536: getfield h0 : I
    //   539: istore_3
    //   540: aload #13
    //   542: getfield i0 : I
    //   545: istore_2
    //   546: aload #13
    //   548: getfield j0 : F
    //   551: fstore_1
    //   552: getstatic android/os/Build$VERSION.SDK_INT : I
    //   555: bipush #17
    //   557: if_icmpge -> 578
    //   560: aload #13
    //   562: getfield a : I
    //   565: istore_3
    //   566: aload #13
    //   568: getfield b : I
    //   571: istore_2
    //   572: aload #13
    //   574: getfield c : F
    //   577: fstore_1
    //   578: fload_1
    //   579: ldc_w -1.0
    //   582: fcmpl
    //   583: ifeq -> 595
    //   586: aload #14
    //   588: fload_1
    //   589: invokevirtual e : (F)V
    //   592: goto -> 620
    //   595: iload_3
    //   596: iconst_m1
    //   597: if_icmpeq -> 609
    //   600: aload #14
    //   602: iload_3
    //   603: invokevirtual p : (I)V
    //   606: goto -> 620
    //   609: iload_2
    //   610: iconst_m1
    //   611: if_icmpeq -> 620
    //   614: aload #14
    //   616: iload_2
    //   617: invokevirtual q : (I)V
    //   620: goto -> 1950
    //   623: aload #13
    //   625: getfield d : I
    //   628: iconst_m1
    //   629: if_icmpne -> 785
    //   632: aload #13
    //   634: getfield e : I
    //   637: iconst_m1
    //   638: if_icmpne -> 785
    //   641: aload #13
    //   643: getfield f : I
    //   646: iconst_m1
    //   647: if_icmpne -> 785
    //   650: aload #13
    //   652: getfield g : I
    //   655: iconst_m1
    //   656: if_icmpne -> 785
    //   659: aload #13
    //   661: getfield q : I
    //   664: iconst_m1
    //   665: if_icmpne -> 785
    //   668: aload #13
    //   670: getfield p : I
    //   673: iconst_m1
    //   674: if_icmpne -> 785
    //   677: aload #13
    //   679: getfield r : I
    //   682: iconst_m1
    //   683: if_icmpne -> 785
    //   686: aload #13
    //   688: getfield s : I
    //   691: iconst_m1
    //   692: if_icmpne -> 785
    //   695: aload #13
    //   697: getfield h : I
    //   700: iconst_m1
    //   701: if_icmpne -> 785
    //   704: aload #13
    //   706: getfield i : I
    //   709: iconst_m1
    //   710: if_icmpne -> 785
    //   713: aload #13
    //   715: getfield j : I
    //   718: iconst_m1
    //   719: if_icmpne -> 785
    //   722: aload #13
    //   724: getfield k : I
    //   727: iconst_m1
    //   728: if_icmpne -> 785
    //   731: aload #13
    //   733: getfield l : I
    //   736: iconst_m1
    //   737: if_icmpne -> 785
    //   740: aload #13
    //   742: getfield P : I
    //   745: iconst_m1
    //   746: if_icmpne -> 785
    //   749: aload #13
    //   751: getfield Q : I
    //   754: iconst_m1
    //   755: if_icmpne -> 785
    //   758: aload #13
    //   760: getfield m : I
    //   763: iconst_m1
    //   764: if_icmpne -> 785
    //   767: aload #13
    //   769: getfield width : I
    //   772: iconst_m1
    //   773: if_icmpeq -> 785
    //   776: aload #13
    //   778: getfield height : I
    //   781: iconst_m1
    //   782: if_icmpne -> 620
    //   785: aload #13
    //   787: getfield a0 : I
    //   790: istore_2
    //   791: aload #13
    //   793: getfield b0 : I
    //   796: istore_3
    //   797: aload #13
    //   799: getfield c0 : I
    //   802: istore #5
    //   804: aload #13
    //   806: getfield d0 : I
    //   809: istore #7
    //   811: aload #13
    //   813: getfield e0 : I
    //   816: istore #4
    //   818: aload #13
    //   820: getfield f0 : I
    //   823: istore #6
    //   825: aload #13
    //   827: getfield g0 : F
    //   830: fstore_1
    //   831: getstatic android/os/Build$VERSION.SDK_INT : I
    //   834: bipush #17
    //   836: if_icmpge -> 1016
    //   839: aload #13
    //   841: getfield d : I
    //   844: istore_2
    //   845: aload #13
    //   847: getfield e : I
    //   850: istore_3
    //   851: aload #13
    //   853: getfield f : I
    //   856: istore #6
    //   858: aload #13
    //   860: getfield g : I
    //   863: istore #7
    //   865: aload #13
    //   867: getfield t : I
    //   870: istore #4
    //   872: aload #13
    //   874: getfield v : I
    //   877: istore #5
    //   879: aload #13
    //   881: getfield z : F
    //   884: fstore_1
    //   885: iload_2
    //   886: iconst_m1
    //   887: if_icmpne -> 931
    //   890: iload_3
    //   891: iconst_m1
    //   892: if_icmpne -> 931
    //   895: aload #13
    //   897: getfield q : I
    //   900: iconst_m1
    //   901: if_icmpeq -> 913
    //   904: aload #13
    //   906: getfield q : I
    //   909: istore_2
    //   910: goto -> 931
    //   913: aload #13
    //   915: getfield p : I
    //   918: iconst_m1
    //   919: if_icmpeq -> 931
    //   922: aload #13
    //   924: getfield p : I
    //   927: istore_3
    //   928: goto -> 931
    //   931: iload #6
    //   933: iconst_m1
    //   934: if_icmpne -> 1001
    //   937: iload #7
    //   939: iconst_m1
    //   940: if_icmpne -> 1001
    //   943: aload #13
    //   945: getfield r : I
    //   948: iconst_m1
    //   949: if_icmpeq -> 970
    //   952: aload #13
    //   954: getfield r : I
    //   957: istore #11
    //   959: iload #5
    //   961: istore #6
    //   963: iload #11
    //   965: istore #5
    //   967: goto -> 1016
    //   970: aload #13
    //   972: getfield s : I
    //   975: iconst_m1
    //   976: if_icmpeq -> 1001
    //   979: aload #13
    //   981: getfield s : I
    //   984: istore #7
    //   986: iload #5
    //   988: istore #11
    //   990: iload #6
    //   992: istore #5
    //   994: iload #11
    //   996: istore #6
    //   998: goto -> 1016
    //   1001: iload #5
    //   1003: istore #11
    //   1005: iload #6
    //   1007: istore #5
    //   1009: iload #11
    //   1011: istore #6
    //   1013: goto -> 1016
    //   1016: aload #13
    //   1018: getfield m : I
    //   1021: istore #11
    //   1023: iload #11
    //   1025: iconst_m1
    //   1026: if_icmpeq -> 1065
    //   1029: aload_0
    //   1030: iload #11
    //   1032: invokespecial a : (I)Landroid/support/constraint/i/j/e;
    //   1035: astore #15
    //   1037: aload #15
    //   1039: ifnull -> 1062
    //   1042: aload #14
    //   1044: aload #15
    //   1046: aload #13
    //   1048: getfield o : F
    //   1051: aload #13
    //   1053: getfield n : I
    //   1056: invokevirtual a : (Landroid/support/constraint/i/j/e;FI)V
    //   1059: goto -> 1062
    //   1062: goto -> 1613
    //   1065: iload_2
    //   1066: iconst_m1
    //   1067: if_icmpeq -> 1111
    //   1070: aload_0
    //   1071: iload_2
    //   1072: invokespecial a : (I)Landroid/support/constraint/i/j/e;
    //   1075: astore #16
    //   1077: aload #16
    //   1079: ifnull -> 1108
    //   1082: getstatic android/support/constraint/i/j/d$d.d : Landroid/support/constraint/i/j/d$d;
    //   1085: astore #15
    //   1087: aload #14
    //   1089: aload #15
    //   1091: aload #16
    //   1093: aload #15
    //   1095: aload #13
    //   1097: getfield leftMargin : I
    //   1100: iload #4
    //   1102: invokevirtual a : (Landroid/support/constraint/i/j/d$d;Landroid/support/constraint/i/j/e;Landroid/support/constraint/i/j/d$d;II)V
    //   1105: goto -> 1151
    //   1108: goto -> 1151
    //   1111: iload_3
    //   1112: iconst_m1
    //   1113: if_icmpeq -> 1151
    //   1116: aload_0
    //   1117: iload_3
    //   1118: invokespecial a : (I)Landroid/support/constraint/i/j/e;
    //   1121: astore #15
    //   1123: aload #15
    //   1125: ifnull -> 1151
    //   1128: aload #14
    //   1130: getstatic android/support/constraint/i/j/d$d.d : Landroid/support/constraint/i/j/d$d;
    //   1133: aload #15
    //   1135: getstatic android/support/constraint/i/j/d$d.f : Landroid/support/constraint/i/j/d$d;
    //   1138: aload #13
    //   1140: getfield leftMargin : I
    //   1143: iload #4
    //   1145: invokevirtual a : (Landroid/support/constraint/i/j/d$d;Landroid/support/constraint/i/j/e;Landroid/support/constraint/i/j/d$d;II)V
    //   1148: goto -> 1151
    //   1151: iload #5
    //   1153: iconst_m1
    //   1154: if_icmpeq -> 1193
    //   1157: aload_0
    //   1158: iload #5
    //   1160: invokespecial a : (I)Landroid/support/constraint/i/j/e;
    //   1163: astore #15
    //   1165: aload #15
    //   1167: ifnull -> 1238
    //   1170: aload #14
    //   1172: getstatic android/support/constraint/i/j/d$d.f : Landroid/support/constraint/i/j/d$d;
    //   1175: aload #15
    //   1177: getstatic android/support/constraint/i/j/d$d.d : Landroid/support/constraint/i/j/d$d;
    //   1180: aload #13
    //   1182: getfield rightMargin : I
    //   1185: iload #6
    //   1187: invokevirtual a : (Landroid/support/constraint/i/j/d$d;Landroid/support/constraint/i/j/e;Landroid/support/constraint/i/j/d$d;II)V
    //   1190: goto -> 1238
    //   1193: iload #7
    //   1195: iconst_m1
    //   1196: if_icmpeq -> 1238
    //   1199: aload_0
    //   1200: iload #7
    //   1202: invokespecial a : (I)Landroid/support/constraint/i/j/e;
    //   1205: astore #16
    //   1207: aload #16
    //   1209: ifnull -> 1238
    //   1212: getstatic android/support/constraint/i/j/d$d.f : Landroid/support/constraint/i/j/d$d;
    //   1215: astore #15
    //   1217: aload #14
    //   1219: aload #15
    //   1221: aload #16
    //   1223: aload #15
    //   1225: aload #13
    //   1227: getfield rightMargin : I
    //   1230: iload #6
    //   1232: invokevirtual a : (Landroid/support/constraint/i/j/d$d;Landroid/support/constraint/i/j/e;Landroid/support/constraint/i/j/d$d;II)V
    //   1235: goto -> 1238
    //   1238: aload #13
    //   1240: getfield h : I
    //   1243: istore_2
    //   1244: iload_2
    //   1245: iconst_m1
    //   1246: if_icmpeq -> 1290
    //   1249: aload_0
    //   1250: iload_2
    //   1251: invokespecial a : (I)Landroid/support/constraint/i/j/e;
    //   1254: astore #15
    //   1256: aload #15
    //   1258: ifnull -> 1339
    //   1261: getstatic android/support/constraint/i/j/d$d.e : Landroid/support/constraint/i/j/d$d;
    //   1264: astore #16
    //   1266: aload #14
    //   1268: aload #16
    //   1270: aload #15
    //   1272: aload #16
    //   1274: aload #13
    //   1276: getfield topMargin : I
    //   1279: aload #13
    //   1281: getfield u : I
    //   1284: invokevirtual a : (Landroid/support/constraint/i/j/d$d;Landroid/support/constraint/i/j/e;Landroid/support/constraint/i/j/d$d;II)V
    //   1287: goto -> 1339
    //   1290: aload #13
    //   1292: getfield i : I
    //   1295: istore_2
    //   1296: iload_2
    //   1297: iconst_m1
    //   1298: if_icmpeq -> 1339
    //   1301: aload_0
    //   1302: iload_2
    //   1303: invokespecial a : (I)Landroid/support/constraint/i/j/e;
    //   1306: astore #15
    //   1308: aload #15
    //   1310: ifnull -> 1339
    //   1313: aload #14
    //   1315: getstatic android/support/constraint/i/j/d$d.e : Landroid/support/constraint/i/j/d$d;
    //   1318: aload #15
    //   1320: getstatic android/support/constraint/i/j/d$d.g : Landroid/support/constraint/i/j/d$d;
    //   1323: aload #13
    //   1325: getfield topMargin : I
    //   1328: aload #13
    //   1330: getfield u : I
    //   1333: invokevirtual a : (Landroid/support/constraint/i/j/d$d;Landroid/support/constraint/i/j/e;Landroid/support/constraint/i/j/d$d;II)V
    //   1336: goto -> 1339
    //   1339: aload #13
    //   1341: getfield j : I
    //   1344: istore_2
    //   1345: iload_2
    //   1346: iconst_m1
    //   1347: if_icmpeq -> 1388
    //   1350: aload_0
    //   1351: iload_2
    //   1352: invokespecial a : (I)Landroid/support/constraint/i/j/e;
    //   1355: astore #15
    //   1357: aload #15
    //   1359: ifnull -> 1440
    //   1362: aload #14
    //   1364: getstatic android/support/constraint/i/j/d$d.g : Landroid/support/constraint/i/j/d$d;
    //   1367: aload #15
    //   1369: getstatic android/support/constraint/i/j/d$d.e : Landroid/support/constraint/i/j/d$d;
    //   1372: aload #13
    //   1374: getfield bottomMargin : I
    //   1377: aload #13
    //   1379: getfield w : I
    //   1382: invokevirtual a : (Landroid/support/constraint/i/j/d$d;Landroid/support/constraint/i/j/e;Landroid/support/constraint/i/j/d$d;II)V
    //   1385: goto -> 1440
    //   1388: aload #13
    //   1390: getfield k : I
    //   1393: istore_2
    //   1394: iload_2
    //   1395: iconst_m1
    //   1396: if_icmpeq -> 1440
    //   1399: aload_0
    //   1400: iload_2
    //   1401: invokespecial a : (I)Landroid/support/constraint/i/j/e;
    //   1404: astore #16
    //   1406: aload #16
    //   1408: ifnull -> 1440
    //   1411: getstatic android/support/constraint/i/j/d$d.g : Landroid/support/constraint/i/j/d$d;
    //   1414: astore #15
    //   1416: aload #14
    //   1418: aload #15
    //   1420: aload #16
    //   1422: aload #15
    //   1424: aload #13
    //   1426: getfield bottomMargin : I
    //   1429: aload #13
    //   1431: getfield w : I
    //   1434: invokevirtual a : (Landroid/support/constraint/i/j/d$d;Landroid/support/constraint/i/j/e;Landroid/support/constraint/i/j/d$d;II)V
    //   1437: goto -> 1440
    //   1440: aload #13
    //   1442: getfield l : I
    //   1445: istore_2
    //   1446: iload_2
    //   1447: iconst_m1
    //   1448: if_icmpeq -> 1567
    //   1451: aload_0
    //   1452: getfield c : Landroid/util/SparseArray;
    //   1455: iload_2
    //   1456: invokevirtual get : (I)Ljava/lang/Object;
    //   1459: checkcast android/view/View
    //   1462: astore #16
    //   1464: aload_0
    //   1465: aload #13
    //   1467: getfield l : I
    //   1470: invokespecial a : (I)Landroid/support/constraint/i/j/e;
    //   1473: astore #15
    //   1475: aload #15
    //   1477: ifnull -> 1567
    //   1480: aload #16
    //   1482: ifnull -> 1567
    //   1485: aload #16
    //   1487: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1490: instanceof android/support/constraint/ConstraintLayout$a
    //   1493: ifeq -> 1567
    //   1496: aload #16
    //   1498: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1501: checkcast android/support/constraint/ConstraintLayout$a
    //   1504: astore #16
    //   1506: aload #13
    //   1508: iconst_1
    //   1509: putfield W : Z
    //   1512: aload #16
    //   1514: iconst_1
    //   1515: putfield W : Z
    //   1518: aload #14
    //   1520: getstatic android/support/constraint/i/j/d$d.h : Landroid/support/constraint/i/j/d$d;
    //   1523: invokevirtual a : (Landroid/support/constraint/i/j/d$d;)Landroid/support/constraint/i/j/d;
    //   1526: aload #15
    //   1528: getstatic android/support/constraint/i/j/d$d.h : Landroid/support/constraint/i/j/d$d;
    //   1531: invokevirtual a : (Landroid/support/constraint/i/j/d$d;)Landroid/support/constraint/i/j/d;
    //   1534: iconst_0
    //   1535: iconst_m1
    //   1536: getstatic android/support/constraint/i/j/d$c.d : Landroid/support/constraint/i/j/d$c;
    //   1539: iconst_0
    //   1540: iconst_1
    //   1541: invokevirtual a : (Landroid/support/constraint/i/j/d;IILandroid/support/constraint/i/j/d$c;IZ)Z
    //   1544: pop
    //   1545: aload #14
    //   1547: getstatic android/support/constraint/i/j/d$d.e : Landroid/support/constraint/i/j/d$d;
    //   1550: invokevirtual a : (Landroid/support/constraint/i/j/d$d;)Landroid/support/constraint/i/j/d;
    //   1553: invokevirtual j : ()V
    //   1556: aload #14
    //   1558: getstatic android/support/constraint/i/j/d$d.g : Landroid/support/constraint/i/j/d$d;
    //   1561: invokevirtual a : (Landroid/support/constraint/i/j/d$d;)Landroid/support/constraint/i/j/d;
    //   1564: invokevirtual j : ()V
    //   1567: fload_1
    //   1568: fconst_0
    //   1569: fcmpl
    //   1570: iflt -> 1587
    //   1573: fload_1
    //   1574: ldc_w 0.5
    //   1577: fcmpl
    //   1578: ifeq -> 1587
    //   1581: aload #14
    //   1583: fload_1
    //   1584: invokevirtual a : (F)V
    //   1587: aload #13
    //   1589: getfield A : F
    //   1592: fstore_1
    //   1593: fload_1
    //   1594: fconst_0
    //   1595: fcmpl
    //   1596: iflt -> 1613
    //   1599: fload_1
    //   1600: ldc_w 0.5
    //   1603: fcmpl
    //   1604: ifeq -> 1613
    //   1607: aload #14
    //   1609: fload_1
    //   1610: invokevirtual c : (F)V
    //   1613: iload #12
    //   1615: ifeq -> 1651
    //   1618: aload #13
    //   1620: getfield P : I
    //   1623: iconst_m1
    //   1624: if_icmpne -> 1636
    //   1627: aload #13
    //   1629: getfield Q : I
    //   1632: iconst_m1
    //   1633: if_icmpeq -> 1651
    //   1636: aload #14
    //   1638: aload #13
    //   1640: getfield P : I
    //   1643: aload #13
    //   1645: getfield Q : I
    //   1648: invokevirtual c : (II)V
    //   1651: aload #13
    //   1653: getfield U : Z
    //   1656: ifne -> 1728
    //   1659: aload #13
    //   1661: getfield width : I
    //   1664: iconst_m1
    //   1665: if_icmpne -> 1711
    //   1668: aload #14
    //   1670: getstatic android/support/constraint/i/j/e$b.f : Landroid/support/constraint/i/j/e$b;
    //   1673: invokevirtual a : (Landroid/support/constraint/i/j/e$b;)V
    //   1676: aload #14
    //   1678: getstatic android/support/constraint/i/j/d$d.d : Landroid/support/constraint/i/j/d$d;
    //   1681: invokevirtual a : (Landroid/support/constraint/i/j/d$d;)Landroid/support/constraint/i/j/d;
    //   1684: aload #13
    //   1686: getfield leftMargin : I
    //   1689: putfield e : I
    //   1692: aload #14
    //   1694: getstatic android/support/constraint/i/j/d$d.f : Landroid/support/constraint/i/j/d$d;
    //   1697: invokevirtual a : (Landroid/support/constraint/i/j/d$d;)Landroid/support/constraint/i/j/d;
    //   1700: aload #13
    //   1702: getfield rightMargin : I
    //   1705: putfield e : I
    //   1708: goto -> 1746
    //   1711: aload #14
    //   1713: getstatic android/support/constraint/i/j/e$b.e : Landroid/support/constraint/i/j/e$b;
    //   1716: invokevirtual a : (Landroid/support/constraint/i/j/e$b;)V
    //   1719: aload #14
    //   1721: iconst_0
    //   1722: invokevirtual k : (I)V
    //   1725: goto -> 1746
    //   1728: aload #14
    //   1730: getstatic android/support/constraint/i/j/e$b.c : Landroid/support/constraint/i/j/e$b;
    //   1733: invokevirtual a : (Landroid/support/constraint/i/j/e$b;)V
    //   1736: aload #14
    //   1738: aload #13
    //   1740: getfield width : I
    //   1743: invokevirtual k : (I)V
    //   1746: aload #13
    //   1748: getfield V : Z
    //   1751: ifne -> 1823
    //   1754: aload #13
    //   1756: getfield height : I
    //   1759: iconst_m1
    //   1760: if_icmpne -> 1806
    //   1763: aload #14
    //   1765: getstatic android/support/constraint/i/j/e$b.f : Landroid/support/constraint/i/j/e$b;
    //   1768: invokevirtual b : (Landroid/support/constraint/i/j/e$b;)V
    //   1771: aload #14
    //   1773: getstatic android/support/constraint/i/j/d$d.e : Landroid/support/constraint/i/j/d$d;
    //   1776: invokevirtual a : (Landroid/support/constraint/i/j/d$d;)Landroid/support/constraint/i/j/d;
    //   1779: aload #13
    //   1781: getfield topMargin : I
    //   1784: putfield e : I
    //   1787: aload #14
    //   1789: getstatic android/support/constraint/i/j/d$d.g : Landroid/support/constraint/i/j/d$d;
    //   1792: invokevirtual a : (Landroid/support/constraint/i/j/d$d;)Landroid/support/constraint/i/j/d;
    //   1795: aload #13
    //   1797: getfield bottomMargin : I
    //   1800: putfield e : I
    //   1803: goto -> 1841
    //   1806: aload #14
    //   1808: getstatic android/support/constraint/i/j/e$b.e : Landroid/support/constraint/i/j/e$b;
    //   1811: invokevirtual b : (Landroid/support/constraint/i/j/e$b;)V
    //   1814: aload #14
    //   1816: iconst_0
    //   1817: invokevirtual c : (I)V
    //   1820: goto -> 1841
    //   1823: aload #14
    //   1825: getstatic android/support/constraint/i/j/e$b.c : Landroid/support/constraint/i/j/e$b;
    //   1828: invokevirtual b : (Landroid/support/constraint/i/j/e$b;)V
    //   1831: aload #14
    //   1833: aload #13
    //   1835: getfield height : I
    //   1838: invokevirtual c : (I)V
    //   1841: aload #13
    //   1843: getfield B : Ljava/lang/String;
    //   1846: astore #15
    //   1848: aload #15
    //   1850: ifnull -> 1860
    //   1853: aload #14
    //   1855: aload #15
    //   1857: invokevirtual b : (Ljava/lang/String;)V
    //   1860: aload #14
    //   1862: aload #13
    //   1864: getfield D : F
    //   1867: invokevirtual b : (F)V
    //   1870: aload #14
    //   1872: aload #13
    //   1874: getfield E : F
    //   1877: invokevirtual d : (F)V
    //   1880: aload #14
    //   1882: aload #13
    //   1884: getfield F : I
    //   1887: invokevirtual d : (I)V
    //   1890: aload #14
    //   1892: aload #13
    //   1894: getfield G : I
    //   1897: invokevirtual i : (I)V
    //   1900: aload #14
    //   1902: aload #13
    //   1904: getfield H : I
    //   1907: aload #13
    //   1909: getfield J : I
    //   1912: aload #13
    //   1914: getfield L : I
    //   1917: aload #13
    //   1919: getfield N : F
    //   1922: invokevirtual a : (IIIF)V
    //   1925: aload #14
    //   1927: aload #13
    //   1929: getfield I : I
    //   1932: aload #13
    //   1934: getfield K : I
    //   1937: aload #13
    //   1939: getfield M : I
    //   1942: aload #13
    //   1944: getfield O : F
    //   1947: invokevirtual b : (IIIF)V
    //   1950: iinc #10, 1
    //   1953: goto -> 320
    //   1956: return
    // Exception table:
    //   from	to	target	type
    //   32	69	105	android/content/res/Resources$NotFoundException
    //   78	88	105	android/content/res/Resources$NotFoundException
    //   88	102	105	android/content/res/Resources$NotFoundException
    //   388	447	450	android/content/res/Resources$NotFoundException
  }
  
  private void a(int paramInt1, int paramInt2) {
    int k = getPaddingTop() + getPaddingBottom();
    int i = getPaddingLeft() + getPaddingRight();
    int j = getChildCount();
    for (byte b = 0; b < j; b++) {
      View view = getChildAt(b);
      if (view.getVisibility() != 8) {
        a a = (a)view.getLayoutParams();
        e e = a.k0;
        if (!a.X && !a.Y) {
          int i2;
          e.j(view.getVisibility());
          int i3 = a.width;
          int i4 = a.height;
          boolean bool = a.U;
          if (bool || a.V || (!bool && a.H == 1) || a.width == -1 || (!a.V && (a.I == 1 || a.height == -1))) {
            i2 = 1;
          } else {
            i2 = 0;
          } 
          int n = 0;
          boolean bool4 = false;
          boolean bool2 = false;
          boolean bool1 = false;
          boolean bool3 = false;
          int i1 = i3;
          int m = i4;
          if (i2) {
            if (i3 == 0) {
              n = ViewGroup.getChildMeasureSpec(paramInt1, i, -2);
              m = 1;
            } else if (i3 == -1) {
              n = ViewGroup.getChildMeasureSpec(paramInt1, i, -1);
              m = 0;
            } else {
              m = bool4;
              if (i3 == -2)
                m = 1; 
              n = ViewGroup.getChildMeasureSpec(paramInt1, i, i3);
            } 
            if (i4 == 0) {
              i1 = ViewGroup.getChildMeasureSpec(paramInt2, k, -2);
              bool1 = true;
            } else if (i4 == -1) {
              i1 = ViewGroup.getChildMeasureSpec(paramInt2, k, -1);
              bool1 = bool2;
            } else {
              bool1 = bool3;
              if (i4 == -2)
                bool1 = true; 
              i1 = ViewGroup.getChildMeasureSpec(paramInt2, k, i4);
            } 
            view.measure(n, i1);
            f f1 = this.v;
            if (f1 != null)
              f1.a++; 
            if (i3 == -2) {
              bool = true;
            } else {
              bool = false;
            } 
            e.b(bool);
            if (i4 == -2) {
              bool = true;
            } else {
              bool = false;
            } 
            e.a(bool);
            i1 = view.getMeasuredWidth();
            i2 = view.getMeasuredHeight();
            n = m;
            m = i2;
          } 
          e.k(i1);
          e.c(m);
          if (n != 0)
            e.m(i1); 
          if (bool1)
            e.l(m); 
          if (a.W) {
            m = view.getBaseline();
            if (m != -1)
              e.b(m); 
          } 
        } 
      } 
    } 
  }
  
  private void a(AttributeSet paramAttributeSet) {
    this.f.a(this);
    this.c.put(getId(), this);
    this.m = null;
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, h.ConstraintLayout_Layout);
      int i = typedArray.getIndexCount();
      for (byte b = 0; b < i; b++) {
        int j = typedArray.getIndex(b);
        if (j == h.ConstraintLayout_Layout_android_minWidth) {
          this.g = typedArray.getDimensionPixelOffset(j, this.g);
        } else if (j == h.ConstraintLayout_Layout_android_minHeight) {
          this.h = typedArray.getDimensionPixelOffset(j, this.h);
        } else if (j == h.ConstraintLayout_Layout_android_maxWidth) {
          this.i = typedArray.getDimensionPixelOffset(j, this.i);
        } else if (j == h.ConstraintLayout_Layout_android_maxHeight) {
          this.j = typedArray.getDimensionPixelOffset(j, this.j);
        } else if (j == h.ConstraintLayout_Layout_layout_optimizationLevel) {
          this.l = typedArray.getInt(j, this.l);
        } else if (j == h.ConstraintLayout_Layout_constraintSet) {
          j = typedArray.getResourceId(j, 0);
          try {
            c c1 = new c();
            this();
            this.m = c1;
            this.m.a(getContext(), j);
          } catch (android.content.res.Resources.NotFoundException notFoundException) {
            this.m = null;
          } 
          this.n = j;
        } 
      } 
      typedArray.recycle();
    } 
    this.f.q(this.l);
  }
  
  private void b() {
    boolean bool1;
    int i = getChildCount();
    boolean bool2 = false;
    byte b = 0;
    while (true) {
      bool1 = bool2;
      if (b < i) {
        if (getChildAt(b).isLayoutRequested()) {
          bool1 = true;
          break;
        } 
        b++;
        continue;
      } 
      break;
    } 
    if (bool1) {
      this.e.clear();
      a();
    } 
  }
  
  private void b(int paramInt1, int paramInt2) {
    ConstraintLayout constraintLayout = this;
    int j = getPaddingTop() + getPaddingBottom();
    int k = getPaddingLeft() + getPaddingRight();
    int m = getChildCount();
    int i;
    for (i = 0; i < m; i++) {
      View view = constraintLayout.getChildAt(i);
      if (view.getVisibility() != 8) {
        a a = (a)view.getLayoutParams();
        e e = a.k0;
        if (!a.X && !a.Y) {
          e.j(view.getVisibility());
          int i1 = a.width;
          int n = a.height;
          if (i1 == 0 || n == 0) {
            e.n().b();
            e.m().b();
          } else {
            boolean bool2;
            int i2 = 0;
            boolean bool1 = false;
            if (i1 == -2)
              i2 = 1; 
            int i3 = ViewGroup.getChildMeasureSpec(paramInt1, k, i1);
            if (n == -2)
              bool1 = true; 
            view.measure(i3, ViewGroup.getChildMeasureSpec(paramInt2, j, n));
            f f1 = constraintLayout.v;
            if (f1 != null)
              f1.a++; 
            if (i1 == -2) {
              bool2 = true;
            } else {
              bool2 = false;
            } 
            e.b(bool2);
            if (n == -2) {
              bool2 = true;
            } else {
              bool2 = false;
            } 
            e.a(bool2);
            i1 = view.getMeasuredWidth();
            n = view.getMeasuredHeight();
            e.k(i1);
            e.c(n);
            if (i2)
              e.m(i1); 
            if (bool1)
              e.l(n); 
            if (a.W) {
              i2 = view.getBaseline();
              if (i2 != -1)
                e.b(i2); 
            } 
            if (a.U && a.V) {
              e.n().a(i1);
              e.m().a(n);
            } 
          } 
        } 
      } 
    } 
    constraintLayout.f.S();
    byte b = 0;
    while (b < m) {
      ConstraintLayout constraintLayout1;
      View view = constraintLayout.getChildAt(b);
      if (view.getVisibility() == 8) {
        constraintLayout1 = constraintLayout;
      } else {
        a a = (a)view.getLayoutParams();
        e e = a.k0;
        if (!a.X) {
          if (a.Y) {
            constraintLayout1 = constraintLayout;
          } else {
            e.j(view.getVisibility());
            int n = ((ViewGroup.MarginLayoutParams)constraintLayout1).width;
            int i1 = ((ViewGroup.MarginLayoutParams)constraintLayout1).height;
            if (n != 0 && i1 != 0) {
              constraintLayout1 = constraintLayout;
            } else {
              int i2;
              k k1 = e.a(d.d.d).d();
              k k3 = e.a(d.d.f).d();
              if (e.a(d.d.d).g() != null && e.a(d.d.f).g() != null) {
                i = 1;
              } else {
                i = 0;
              } 
              k k4 = e.a(d.d.e).d();
              k k2 = e.a(d.d.g).d();
              if (e.a(d.d.e).g() != null && e.a(d.d.g).g() != null) {
                i2 = 1;
              } else {
                i2 = 0;
              } 
              if (n == 0 && i1 == 0 && i != 0 && i2) {
                constraintLayout1 = constraintLayout;
              } else {
                boolean bool2;
                boolean bool6;
                boolean bool1 = false;
                boolean bool3 = false;
                boolean bool4 = false;
                boolean bool5 = false;
                if (constraintLayout.f.k() != e.b.d) {
                  bool2 = true;
                } else {
                  bool2 = false;
                } 
                if (constraintLayout.f.r() != e.b.d) {
                  i3 = 1;
                } else {
                  i3 = 0;
                } 
                if (!bool2)
                  e.n().b(); 
                if (!i3)
                  e.m().b(); 
                if (n == 0) {
                  if (bool2 && e.A() && i != 0 && k1.c() && k3.c()) {
                    n = (int)(k3.f() - k1.f());
                    e.n().a(n);
                    i = ViewGroup.getChildMeasureSpec(paramInt1, k, n);
                    bool3 = bool2;
                  } else {
                    i = ViewGroup.getChildMeasureSpec(paramInt1, k, -2);
                    bool1 = true;
                    bool3 = false;
                  } 
                } else if (n == -1) {
                  i = ViewGroup.getChildMeasureSpec(paramInt1, k, -1);
                  bool3 = bool2;
                } else {
                  bool1 = bool3;
                  if (n == -2)
                    bool1 = true; 
                  i = ViewGroup.getChildMeasureSpec(paramInt1, k, n);
                  bool3 = bool2;
                } 
                if (i1 == 0) {
                  if (i3 && e.z() && i2 && k4.c() && k2.c()) {
                    float f3 = k2.f();
                    float f2 = k4.f();
                    i2 = i3;
                    i1 = (int)(f3 - f2);
                    e.m().a(i1);
                    i3 = ViewGroup.getChildMeasureSpec(paramInt2, j, i1);
                    bool2 = bool4;
                  } else {
                    i3 = ViewGroup.getChildMeasureSpec(paramInt2, j, -2);
                    bool2 = true;
                    i2 = 0;
                  } 
                } else {
                  i2 = i3;
                  if (i1 == -1) {
                    i3 = ViewGroup.getChildMeasureSpec(paramInt2, j, -1);
                    bool2 = bool4;
                  } else {
                    bool2 = bool5;
                    if (i1 == -2)
                      bool2 = true; 
                    i3 = ViewGroup.getChildMeasureSpec(paramInt2, j, i1);
                  } 
                } 
                view.measure(i, i3);
                constraintLayout = this;
                f f1 = constraintLayout.v;
                if (f1 != null)
                  f1.a++; 
                if (n == -2) {
                  bool6 = true;
                } else {
                  bool6 = false;
                } 
                e.b(bool6);
                if (i1 == -2) {
                  bool6 = true;
                } else {
                  bool6 = false;
                } 
                e.a(bool6);
                int i3 = view.getMeasuredWidth();
                i = view.getMeasuredHeight();
                e.k(i3);
                e.c(i);
                if (bool1)
                  e.m(i3); 
                if (bool2)
                  e.l(i); 
                if (bool3) {
                  e.n().a(i3);
                } else {
                  e.n().f();
                } 
                if (i2 != 0) {
                  e.m().a(i);
                } else {
                  e.m().f();
                } 
                if (((a)constraintLayout1).W) {
                  i = view.getBaseline();
                  constraintLayout1 = constraintLayout;
                  if (i != -1) {
                    e.b(i);
                    constraintLayout1 = constraintLayout;
                  } 
                } else {
                  constraintLayout1 = constraintLayout;
                } 
              } 
            } 
          } 
        } else {
          constraintLayout1 = constraintLayout;
        } 
      } 
      b++;
      constraintLayout = constraintLayout1;
    } 
  }
  
  private void c() {
    int i = getChildCount();
    byte b;
    for (b = 0; b < i; b++) {
      View view = getChildAt(b);
      if (view instanceof f)
        ((f)view).a(this); 
    } 
    i = this.d.size();
    if (i > 0)
      for (b = 0; b < i; b++)
        ((b)this.d.get(b)).b(this);  
  }
  
  private void c(int paramInt1, int paramInt2) {
    int n = View.MeasureSpec.getMode(paramInt1);
    paramInt1 = View.MeasureSpec.getSize(paramInt1);
    int j = View.MeasureSpec.getMode(paramInt2);
    int i = View.MeasureSpec.getSize(paramInt2);
    int k = getPaddingTop();
    int m = getPaddingBottom();
    int i2 = getPaddingLeft();
    int i1 = getPaddingRight();
    e.b b1 = e.b.c;
    e.b b2 = e.b.c;
    boolean bool = false;
    paramInt2 = 0;
    getLayoutParams();
    if (n != Integer.MIN_VALUE) {
      if (n != 0) {
        if (n != 1073741824) {
          paramInt1 = bool;
        } else {
          paramInt1 = Math.min(this.i, paramInt1) - i2 + i1;
        } 
      } else {
        b1 = e.b.d;
        paramInt1 = bool;
      } 
    } else {
      b1 = e.b.d;
    } 
    if (j != Integer.MIN_VALUE) {
      if (j != 0) {
        if (j == 1073741824)
          paramInt2 = Math.min(this.j, i) - k + m; 
      } else {
        b2 = e.b.d;
      } 
    } else {
      b2 = e.b.d;
      paramInt2 = i;
    } 
    this.f.h(0);
    this.f.g(0);
    this.f.a(b1);
    this.f.k(paramInt1);
    this.f.b(b2);
    this.f.c(paramInt2);
    this.f.h(this.g - getPaddingLeft() - getPaddingRight());
    this.f.g(this.h - getPaddingTop() - getPaddingBottom());
  }
  
  public final e a(View paramView) {
    e e;
    if (paramView == this)
      return (e)this.f; 
    if (paramView == null) {
      paramView = null;
    } else {
      e = ((a)paramView.getLayoutParams()).k0;
    } 
    return e;
  }
  
  public Object a(int paramInt, Object paramObject) {
    if (paramInt == 0 && paramObject instanceof String) {
      paramObject = paramObject;
      HashMap<String, Integer> hashMap = this.o;
      if (hashMap != null && hashMap.containsKey(paramObject))
        return this.o.get(paramObject); 
    } 
    return null;
  }
  
  public void a(int paramInt, Object paramObject1, Object paramObject2) {
    if (paramInt == 0 && paramObject1 instanceof String && paramObject2 instanceof Integer) {
      if (this.o == null)
        this.o = new HashMap<String, Integer>(); 
      String str = (String)paramObject1;
      paramInt = str.indexOf("/");
      paramObject1 = str;
      if (paramInt != -1)
        paramObject1 = str.substring(paramInt + 1); 
      paramInt = ((Integer)paramObject2).intValue();
      this.o.put(paramObject1, Integer.valueOf(paramInt));
    } 
  }
  
  protected void a(String paramString) {
    this.f.I();
    f f1 = this.v;
    if (f1 != null)
      f1.c++; 
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    super.addView(paramView, paramInt, paramLayoutParams);
    if (Build.VERSION.SDK_INT < 14)
      onViewAdded(paramView); 
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof a;
  }
  
  public void dispatchDraw(Canvas paramCanvas) {
    super.dispatchDraw(paramCanvas);
    if (isInEditMode()) {
      int i = getChildCount();
      float f3 = getWidth();
      float f2 = getHeight();
      float f1 = 1080.0F;
      for (byte b = 0; b < i; b++) {
        View view = getChildAt(b);
        if (view.getVisibility() != 8) {
          Object object = view.getTag();
          if (object != null && object instanceof String) {
            object = ((String)object).split(",");
            if (object.length == 4) {
              int k = Integer.parseInt((String)object[0]);
              int m = Integer.parseInt((String)object[1]);
              int n = Integer.parseInt((String)object[2]);
              int j = Integer.parseInt((String)object[3]);
              k = (int)(k / f1 * f3);
              m = (int)(m / 1920.0F * f2);
              n = (int)(n / f1 * f3);
              j = (int)(j / 1920.0F * f2);
              object = new Paint();
              object.setColor(-65536);
              paramCanvas.drawLine(k, m, (k + n), m, (Paint)object);
              paramCanvas.drawLine((k + n), m, (k + n), (m + j), (Paint)object);
              paramCanvas.drawLine((k + n), (m + j), k, (m + j), (Paint)object);
              paramCanvas.drawLine(k, (m + j), k, m, (Paint)object);
              object.setColor(-16711936);
              paramCanvas.drawLine(k, m, (k + n), (m + j), (Paint)object);
              paramCanvas.drawLine(k, (m + j), (k + n), m, (Paint)object);
            } 
          } 
        } 
      } 
    } 
  }
  
  protected a generateDefaultLayoutParams() {
    return new a(-2, -2);
  }
  
  public a generateLayoutParams(AttributeSet paramAttributeSet) {
    return new a(getContext(), paramAttributeSet);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new a(paramLayoutParams);
  }
  
  public int getMaxHeight() {
    return this.j;
  }
  
  public int getMaxWidth() {
    return this.i;
  }
  
  public int getMinHeight() {
    return this.h;
  }
  
  public int getMinWidth() {
    return this.g;
  }
  
  public int getOptimizationLevel() {
    return this.f.K();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt2 = getChildCount();
    paramBoolean = isInEditMode();
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
      View view = getChildAt(paramInt1);
      a a = (a)view.getLayoutParams();
      e e = a.k0;
      if ((view.getVisibility() != 8 || a.X || a.Y || paramBoolean) && !a.Z) {
        int i = e.g();
        paramInt4 = e.h();
        paramInt3 = e.t() + i;
        int j = e.i() + paramInt4;
        view.layout(i, paramInt4, paramInt3, j);
        if (view instanceof f) {
          View view1 = ((f)view).getContent();
          if (view1 != null) {
            view1.setVisibility(0);
            view1.layout(i, paramInt4, paramInt3, j);
          } 
        } 
      } 
    } 
    paramInt2 = this.d.size();
    if (paramInt2 > 0)
      for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++)
        ((b)this.d.get(paramInt1)).a(this);  
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    System.currentTimeMillis();
    int m = View.MeasureSpec.getMode(paramInt1);
    int j = View.MeasureSpec.getSize(paramInt1);
    int n = View.MeasureSpec.getMode(paramInt2);
    int k = View.MeasureSpec.getSize(paramInt2);
    if (this.p != -1 && this.q != -1) {
      boolean bool = true;
    } else {
      boolean bool = false;
    } 
    if (m == 1073741824 && n == 1073741824 && j == this.p && k == this.q) {
      boolean bool = true;
    } else {
      boolean bool = false;
    } 
    if (m == this.t && n == this.u) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i && j == this.r && k == this.s) {
      boolean bool = true;
    } else {
      boolean bool = false;
    } 
    if (i && m == Integer.MIN_VALUE && n == 1073741824 && j >= this.p && k == this.q) {
      boolean bool = true;
    } else {
      boolean bool = false;
    } 
    if (i && m == 1073741824 && n == Integer.MIN_VALUE && j == this.p && k >= this.q) {
      boolean bool = true;
    } else {
      boolean bool = false;
    } 
    this.t = m;
    this.u = n;
    this.r = j;
    this.s = k;
    int i = getPaddingLeft();
    j = getPaddingTop();
    int i4 = 0;
    this.f.n(i);
    this.f.o(j);
    this.f.f(this.i);
    this.f.e(this.j);
    if (Build.VERSION.SDK_INT >= 17) {
      boolean bool;
      f f1 = this.f;
      if (getLayoutDirection() == 1) {
        bool = true;
      } else {
        bool = false;
      } 
      f1.c(bool);
    } 
    c(paramInt1, paramInt2);
    int i1 = this.f.t();
    int i2 = this.f.i();
    if (this.k) {
      this.k = false;
      b();
    } 
    if ((this.l & 0x8) == 8) {
      k = 1;
    } else {
      k = 0;
    } 
    if (k != 0) {
      this.f.R();
      this.f.e(i1, i2);
      b(paramInt1, paramInt2);
    } else {
      a(paramInt1, paramInt2);
    } 
    c();
    if (getChildCount() > 0)
      a("First pass"); 
    int i3 = this.e.size();
    int i5 = j + getPaddingBottom();
    int i6 = i + getPaddingRight();
    if (i3 > 0) {
      boolean bool;
      int i7 = 0;
      if (this.f.k() == e.b.d) {
        m = 1;
      } else {
        m = 0;
      } 
      if (this.f.r() == e.b.d) {
        bool = true;
      } else {
        bool = false;
      } 
      j = Math.max(this.f.t(), this.g);
      i = Math.max(this.f.i(), this.h);
      byte b = 0;
      n = 0;
      while (b < i3) {
        int i8;
        int i9;
        int i10;
        int i11;
        e e = this.e.get(b);
        View view = (View)e.e();
        if (view == null) {
          i8 = j;
          i10 = i;
          i9 = n;
          i11 = i7;
        } else {
          a a = (a)view.getLayoutParams();
          if (!a.Y) {
            if (a.X) {
              i8 = j;
              i10 = i;
              i9 = n;
              i11 = i7;
            } else if (view.getVisibility() == 8) {
              i8 = j;
              i10 = i;
              i9 = n;
              i11 = i7;
            } else if (k != 0 && e.n().c() && e.m().c()) {
              i8 = j;
              i10 = i;
              i9 = n;
              i11 = i7;
            } else {
              if (a.width == -2 && a.U) {
                i8 = ViewGroup.getChildMeasureSpec(paramInt1, i6, a.width);
              } else {
                i8 = View.MeasureSpec.makeMeasureSpec(e.t(), 1073741824);
              } 
              if (a.height == -2 && a.V) {
                i9 = ViewGroup.getChildMeasureSpec(paramInt2, i5, a.height);
              } else {
                i9 = View.MeasureSpec.makeMeasureSpec(e.i(), 1073741824);
              } 
              view.measure(i8, i9);
              f f1 = this.v;
              if (f1 != null)
                f1.b++; 
              int i12 = i4 + 1;
              i4 = view.getMeasuredWidth();
              i8 = view.getMeasuredHeight();
              if (i4 != e.t()) {
                e.k(i4);
                if (k != 0)
                  e.n().a(i4); 
                if (m != 0 && e.o() > j)
                  j = Math.max(j, e.o() + e.a(d.d.f).b()); 
                i4 = 1;
              } else {
                i4 = i7;
              } 
              i7 = i;
              if (i8 != e.i()) {
                e.c(i8);
                if (k != 0)
                  e.m().a(i8); 
                i7 = i;
                if (bool) {
                  i7 = i;
                  if (e.d() > i)
                    i7 = Math.max(i, e.d() + e.a(d.d.g).b()); 
                } 
                i4 = 1;
              } 
              i = i4;
              if (a.W) {
                i8 = view.getBaseline();
                i = i4;
                if (i8 != -1) {
                  i = i4;
                  if (i8 != e.c()) {
                    e.b(i8);
                    i = 1;
                  } 
                } 
              } 
              i8 = j;
              i10 = i7;
              i9 = n;
              i4 = i12;
              i11 = i;
              if (Build.VERSION.SDK_INT >= 11) {
                i9 = ViewGroup.combineMeasuredStates(n, view.getMeasuredState());
                i8 = j;
                i10 = i7;
                i4 = i12;
                i11 = i;
              } 
            } 
          } else {
            i11 = i7;
            i9 = n;
            i10 = i;
            i8 = j;
          } 
        } 
        b++;
        j = i8;
        i = i10;
        n = i9;
        i7 = i11;
      } 
      i4 = i3;
      if (i7 != 0) {
        this.f.k(i1);
        this.f.c(i2);
        if (k != 0)
          this.f.S(); 
        a("2nd pass");
        i3 = 0;
        if (this.f.t() < j) {
          this.f.k(j);
          i3 = 1;
        } 
        if (this.f.i() < i) {
          this.f.c(i);
          i3 = 1;
        } 
        if (i3 != 0)
          a("3rd pass"); 
      } 
      j = i2;
      i2 = 0;
      i3 = 0;
      i = i4;
      while (i2 < i) {
        e e = this.e.get(i2);
        View view = (View)e.e();
        if (view != null && (view.getMeasuredWidth() != e.t() || view.getMeasuredHeight() != e.i()) && e.s() != 8) {
          view.measure(View.MeasureSpec.makeMeasureSpec(e.t(), 1073741824), View.MeasureSpec.makeMeasureSpec(e.i(), 1073741824));
          f f1 = this.v;
          if (f1 != null)
            f1.b++; 
          i3++;
        } 
        i2++;
      } 
    } else {
      n = 0;
    } 
    j = this.f.t() + i6;
    i = this.f.i() + i5;
    if (Build.VERSION.SDK_INT >= 11) {
      paramInt1 = ViewGroup.resolveSizeAndState(j, paramInt1, n);
      i = ViewGroup.resolveSizeAndState(i, paramInt2, n << 16);
      paramInt2 = Math.min(this.i, paramInt1 & 0xFFFFFF);
      i = Math.min(this.j, i & 0xFFFFFF);
      paramInt1 = paramInt2;
      if (this.f.O())
        paramInt1 = paramInt2 | 0x1000000; 
      paramInt2 = i;
      if (this.f.M())
        paramInt2 = i | 0x1000000; 
      setMeasuredDimension(paramInt1, paramInt2);
      this.p = paramInt1;
      this.q = paramInt2;
    } else {
      setMeasuredDimension(j, i);
      this.p = j;
      this.q = i;
    } 
  }
  
  public void onViewAdded(View paramView) {
    if (Build.VERSION.SDK_INT >= 14)
      super.onViewAdded(paramView); 
    e e = a(paramView);
    if (paramView instanceof e && !(e instanceof g)) {
      a a = (a)paramView.getLayoutParams();
      a.k0 = (e)new g();
      a.X = true;
      ((g)a.k0).r(a.R);
    } 
    if (paramView instanceof b) {
      b b = (b)paramView;
      b.a();
      ((a)paramView.getLayoutParams()).Y = true;
      if (!this.d.contains(b))
        this.d.add(b); 
    } 
    this.c.put(paramView.getId(), paramView);
    this.k = true;
  }
  
  public void onViewRemoved(View paramView) {
    if (Build.VERSION.SDK_INT >= 14)
      super.onViewRemoved(paramView); 
    this.c.remove(paramView.getId());
    e e = a(paramView);
    this.f.c(e);
    this.d.remove(paramView);
    this.e.remove(e);
    this.k = true;
  }
  
  public void removeView(View paramView) {
    super.removeView(paramView);
    if (Build.VERSION.SDK_INT < 14)
      onViewRemoved(paramView); 
  }
  
  public void requestLayout() {
    super.requestLayout();
    this.k = true;
    this.p = -1;
    this.q = -1;
    this.r = -1;
    this.s = -1;
    this.t = 0;
    this.u = 0;
  }
  
  public void setConstraintSet(c paramc) {
    this.m = paramc;
  }
  
  public void setId(int paramInt) {
    this.c.remove(getId());
    super.setId(paramInt);
    this.c.put(getId(), this);
  }
  
  public void setMaxHeight(int paramInt) {
    if (paramInt == this.j)
      return; 
    this.j = paramInt;
    requestLayout();
  }
  
  public void setMaxWidth(int paramInt) {
    if (paramInt == this.i)
      return; 
    this.i = paramInt;
    requestLayout();
  }
  
  public void setMinHeight(int paramInt) {
    if (paramInt == this.h)
      return; 
    this.h = paramInt;
    requestLayout();
  }
  
  public void setMinWidth(int paramInt) {
    if (paramInt == this.g)
      return; 
    this.g = paramInt;
    requestLayout();
  }
  
  public void setOptimizationLevel(int paramInt) {
    this.f.q(paramInt);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public static class a extends ViewGroup.MarginLayoutParams {
    public float A = 0.5F;
    
    public String B = null;
    
    int C = 1;
    
    public float D = -1.0F;
    
    public float E = -1.0F;
    
    public int F = 0;
    
    public int G = 0;
    
    public int H = 0;
    
    public int I = 0;
    
    public int J = 0;
    
    public int K = 0;
    
    public int L = 0;
    
    public int M = 0;
    
    public float N = 1.0F;
    
    public float O = 1.0F;
    
    public int P = -1;
    
    public int Q = -1;
    
    public int R = -1;
    
    public boolean S = false;
    
    public boolean T = false;
    
    boolean U = true;
    
    boolean V = true;
    
    boolean W = false;
    
    boolean X = false;
    
    boolean Y = false;
    
    boolean Z = false;
    
    public int a = -1;
    
    int a0 = -1;
    
    public int b = -1;
    
    int b0 = -1;
    
    public float c = -1.0F;
    
    int c0 = -1;
    
    public int d = -1;
    
    int d0 = -1;
    
    public int e = -1;
    
    int e0 = -1;
    
    public int f = -1;
    
    int f0 = -1;
    
    public int g = -1;
    
    float g0 = 0.5F;
    
    public int h = -1;
    
    int h0;
    
    public int i = -1;
    
    int i0;
    
    public int j = -1;
    
    float j0;
    
    public int k = -1;
    
    e k0 = new e();
    
    public int l = -1;
    
    public boolean l0 = false;
    
    public int m = -1;
    
    public int n = 0;
    
    public float o = 0.0F;
    
    public int p = -1;
    
    public int q = -1;
    
    public int r = -1;
    
    public int s = -1;
    
    public int t = -1;
    
    public int u = -1;
    
    public int v = -1;
    
    public int w = -1;
    
    public int x = -1;
    
    public int y = -1;
    
    public float z = 0.5F;
    
    public a(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public a(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, h.ConstraintLayout_Layout);
      int i = typedArray.getIndexCount();
      for (byte b = 0; b < i; b++) {
        String str;
        float f;
        int j = typedArray.getIndex(b);
        switch (a.a.get(j)) {
          case 50:
            this.Q = typedArray.getDimensionPixelOffset(j, this.Q);
            break;
          case 49:
            this.P = typedArray.getDimensionPixelOffset(j, this.P);
            break;
          case 48:
            this.G = typedArray.getInt(j, 0);
            break;
          case 47:
            this.F = typedArray.getInt(j, 0);
            break;
          case 46:
            this.E = typedArray.getFloat(j, this.E);
            break;
          case 45:
            this.D = typedArray.getFloat(j, this.D);
            break;
          case 44:
            this.B = typedArray.getString(j);
            this.C = -1;
            str = this.B;
            if (str != null) {
              int k = str.length();
              j = this.B.indexOf(',');
              if (j > 0 && j < k - 1) {
                str = this.B.substring(0, j);
                if (str.equalsIgnoreCase("W")) {
                  this.C = 0;
                } else if (str.equalsIgnoreCase("H")) {
                  this.C = 1;
                } 
                j++;
              } else {
                j = 0;
              } 
              int m = this.B.indexOf(':');
              if (m >= 0 && m < k - 1) {
                String str1 = this.B.substring(j, m);
                str = this.B.substring(m + 1);
                if (str1.length() > 0 && str.length() > 0)
                  try {
                    float f1 = Float.parseFloat(str1);
                    float f2 = Float.parseFloat(str);
                    if (f1 > 0.0F && f2 > 0.0F) {
                      if (this.C == 1) {
                        Math.abs(f2 / f1);
                        break;
                      } 
                      Math.abs(f1 / f2);
                    } 
                  } catch (NumberFormatException numberFormatException) {} 
                break;
              } 
              str = this.B.substring(j);
              if (str.length() > 0)
                try {
                  Float.parseFloat(str);
                } catch (NumberFormatException numberFormatException) {} 
            } 
            break;
          case 38:
            this.O = Math.max(0.0F, typedArray.getFloat(j, this.O));
            break;
          case 37:
            try {
              this.M = typedArray.getDimensionPixelSize(j, this.M);
            } catch (Exception exception) {
              if (typedArray.getInt(j, this.M) == -2)
                this.M = -2; 
            } 
            break;
          case 36:
            try {
              this.K = typedArray.getDimensionPixelSize(j, this.K);
            } catch (Exception exception) {
              if (typedArray.getInt(j, this.K) == -2)
                this.K = -2; 
            } 
            break;
          case 35:
            this.N = Math.max(0.0F, typedArray.getFloat(j, this.N));
            break;
          case 34:
            try {
              this.L = typedArray.getDimensionPixelSize(j, this.L);
            } catch (Exception exception) {
              if (typedArray.getInt(j, this.L) == -2)
                this.L = -2; 
            } 
            break;
          case 33:
            try {
              this.J = typedArray.getDimensionPixelSize(j, this.J);
            } catch (Exception exception) {
              if (typedArray.getInt(j, this.J) == -2)
                this.J = -2; 
            } 
            break;
          case 32:
            this.I = typedArray.getInt(j, 0);
            if (this.I == 1)
              Log.e("ConstraintLayout", "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead."); 
            break;
          case 31:
            this.H = typedArray.getInt(j, 0);
            if (this.H == 1)
              Log.e("ConstraintLayout", "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead."); 
            break;
          case 30:
            this.A = typedArray.getFloat(j, this.A);
            break;
          case 29:
            this.z = typedArray.getFloat(j, this.z);
            break;
          case 28:
            this.T = typedArray.getBoolean(j, this.T);
            break;
          case 27:
            this.S = typedArray.getBoolean(j, this.S);
            break;
          case 26:
            this.y = typedArray.getDimensionPixelSize(j, this.y);
            break;
          case 25:
            this.x = typedArray.getDimensionPixelSize(j, this.x);
            break;
          case 24:
            this.w = typedArray.getDimensionPixelSize(j, this.w);
            break;
          case 23:
            this.v = typedArray.getDimensionPixelSize(j, this.v);
            break;
          case 22:
            this.u = typedArray.getDimensionPixelSize(j, this.u);
            break;
          case 21:
            this.t = typedArray.getDimensionPixelSize(j, this.t);
            break;
          case 20:
            this.s = typedArray.getResourceId(j, this.s);
            if (this.s == -1)
              this.s = typedArray.getInt(j, -1); 
            break;
          case 19:
            this.r = typedArray.getResourceId(j, this.r);
            if (this.r == -1)
              this.r = typedArray.getInt(j, -1); 
            break;
          case 18:
            this.q = typedArray.getResourceId(j, this.q);
            if (this.q == -1)
              this.q = typedArray.getInt(j, -1); 
            break;
          case 17:
            this.p = typedArray.getResourceId(j, this.p);
            if (this.p == -1)
              this.p = typedArray.getInt(j, -1); 
            break;
          case 16:
            this.l = typedArray.getResourceId(j, this.l);
            if (this.l == -1)
              this.l = typedArray.getInt(j, -1); 
            break;
          case 15:
            this.k = typedArray.getResourceId(j, this.k);
            if (this.k == -1)
              this.k = typedArray.getInt(j, -1); 
            break;
          case 14:
            this.j = typedArray.getResourceId(j, this.j);
            if (this.j == -1)
              this.j = typedArray.getInt(j, -1); 
            break;
          case 13:
            this.i = typedArray.getResourceId(j, this.i);
            if (this.i == -1)
              this.i = typedArray.getInt(j, -1); 
            break;
          case 12:
            this.h = typedArray.getResourceId(j, this.h);
            if (this.h == -1)
              this.h = typedArray.getInt(j, -1); 
            break;
          case 11:
            this.g = typedArray.getResourceId(j, this.g);
            if (this.g == -1)
              this.g = typedArray.getInt(j, -1); 
            break;
          case 10:
            this.f = typedArray.getResourceId(j, this.f);
            if (this.f == -1)
              this.f = typedArray.getInt(j, -1); 
            break;
          case 9:
            this.e = typedArray.getResourceId(j, this.e);
            if (this.e == -1)
              this.e = typedArray.getInt(j, -1); 
            break;
          case 8:
            this.d = typedArray.getResourceId(j, this.d);
            if (this.d == -1)
              this.d = typedArray.getInt(j, -1); 
            break;
          case 7:
            this.c = typedArray.getFloat(j, this.c);
            break;
          case 6:
            this.b = typedArray.getDimensionPixelOffset(j, this.b);
            break;
          case 5:
            this.a = typedArray.getDimensionPixelOffset(j, this.a);
            break;
          case 4:
            this.o = typedArray.getFloat(j, this.o) % 360.0F;
            f = this.o;
            if (f < 0.0F)
              this.o = (360.0F - f) % 360.0F; 
            break;
          case 3:
            this.n = typedArray.getDimensionPixelSize(j, this.n);
            break;
          case 2:
            this.m = typedArray.getResourceId(j, this.m);
            if (this.m == -1)
              this.m = typedArray.getInt(j, -1); 
            break;
          case 1:
            this.R = typedArray.getInt(j, this.R);
            break;
        } 
      } 
      typedArray.recycle();
      a();
    }
    
    public a(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public void a() {
      this.X = false;
      this.U = true;
      this.V = true;
      if (this.width == -2 && this.S) {
        this.U = false;
        this.H = 1;
      } 
      if (this.height == -2 && this.T) {
        this.V = false;
        this.I = 1;
      } 
      if (this.width == 0 || this.width == -1) {
        this.U = false;
        if (this.width == 0 && this.H == 1) {
          this.width = -2;
          this.S = true;
        } 
      } 
      if (this.height == 0 || this.height == -1) {
        this.V = false;
        if (this.height == 0 && this.I == 1) {
          this.height = -2;
          this.T = true;
        } 
      } 
      if (this.c != -1.0F || this.a != -1 || this.b != -1) {
        this.X = true;
        this.U = true;
        this.V = true;
        if (!(this.k0 instanceof g))
          this.k0 = (e)new g(); 
        ((g)this.k0).r(this.R);
      } 
    }
    
    @TargetApi(17)
    public void resolveLayoutDirection(int param1Int) {
      int i = this.leftMargin;
      int j = this.rightMargin;
      super.resolveLayoutDirection(param1Int);
      this.c0 = -1;
      this.d0 = -1;
      this.a0 = -1;
      this.b0 = -1;
      this.e0 = -1;
      this.f0 = -1;
      this.e0 = this.t;
      this.f0 = this.v;
      this.g0 = this.z;
      this.h0 = this.a;
      this.i0 = this.b;
      this.j0 = this.c;
      if (1 == getLayoutDirection()) {
        param1Int = 1;
      } else {
        param1Int = 0;
      } 
      if (param1Int != 0) {
        param1Int = 0;
        int k = this.p;
        if (k != -1) {
          this.c0 = k;
          param1Int = 1;
        } else {
          k = this.q;
          if (k != -1) {
            this.d0 = k;
            param1Int = 1;
          } 
        } 
        k = this.r;
        if (k != -1) {
          this.b0 = k;
          param1Int = 1;
        } 
        k = this.s;
        if (k != -1) {
          this.a0 = k;
          param1Int = 1;
        } 
        k = this.x;
        if (k != -1)
          this.f0 = k; 
        k = this.y;
        if (k != -1)
          this.e0 = k; 
        if (param1Int != 0)
          this.g0 = 1.0F - this.z; 
        if (this.X && this.R == 1) {
          float f = this.c;
          if (f != -1.0F) {
            this.j0 = 1.0F - f;
            this.h0 = -1;
            this.i0 = -1;
          } else {
            param1Int = this.a;
            if (param1Int != -1) {
              this.i0 = param1Int;
              this.h0 = -1;
              this.j0 = -1.0F;
            } else {
              param1Int = this.b;
              if (param1Int != -1) {
                this.h0 = param1Int;
                this.i0 = -1;
                this.j0 = -1.0F;
              } 
            } 
          } 
        } 
      } else {
        param1Int = this.p;
        if (param1Int != -1)
          this.b0 = param1Int; 
        param1Int = this.q;
        if (param1Int != -1)
          this.a0 = param1Int; 
        param1Int = this.r;
        if (param1Int != -1)
          this.c0 = param1Int; 
        param1Int = this.s;
        if (param1Int != -1)
          this.d0 = param1Int; 
        param1Int = this.x;
        if (param1Int != -1)
          this.e0 = param1Int; 
        param1Int = this.y;
        if (param1Int != -1)
          this.f0 = param1Int; 
      } 
      if (this.r == -1 && this.s == -1 && this.q == -1 && this.p == -1) {
        param1Int = this.f;
        if (param1Int != -1) {
          this.c0 = param1Int;
          if (this.rightMargin <= 0 && j > 0)
            this.rightMargin = j; 
        } else {
          param1Int = this.g;
          if (param1Int != -1) {
            this.d0 = param1Int;
            if (this.rightMargin <= 0 && j > 0)
              this.rightMargin = j; 
          } 
        } 
        param1Int = this.d;
        if (param1Int != -1) {
          this.a0 = param1Int;
          if (this.leftMargin <= 0 && i > 0)
            this.leftMargin = i; 
        } else {
          param1Int = this.e;
          if (param1Int != -1) {
            this.b0 = param1Int;
            if (this.leftMargin <= 0 && i > 0)
              this.leftMargin = i; 
          } 
        } 
      } 
    }
    
    private static class a {
      public static final SparseIntArray a = new SparseIntArray();
      
      static {
        a.append(h.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
        a.append(h.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
        a.append(h.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
        a.append(h.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
        a.append(h.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
        a.append(h.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
        a.append(h.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
        a.append(h.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
        a.append(h.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
        a.append(h.ConstraintLayout_Layout_layout_constraintCircle, 2);
        a.append(h.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
        a.append(h.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
        a.append(h.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
        a.append(h.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
        a.append(h.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
        a.append(h.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
        a.append(h.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
        a.append(h.ConstraintLayout_Layout_android_orientation, 1);
        a.append(h.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
        a.append(h.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
        a.append(h.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
        a.append(h.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
        a.append(h.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
        a.append(h.ConstraintLayout_Layout_layout_goneMarginTop, 22);
        a.append(h.ConstraintLayout_Layout_layout_goneMarginRight, 23);
        a.append(h.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
        a.append(h.ConstraintLayout_Layout_layout_goneMarginStart, 25);
        a.append(h.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
        a.append(h.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
        a.append(h.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
        a.append(h.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
        a.append(h.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
        a.append(h.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
        a.append(h.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
        a.append(h.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
        a.append(h.ConstraintLayout_Layout_layout_constrainedWidth, 27);
        a.append(h.ConstraintLayout_Layout_layout_constrainedHeight, 28);
        a.append(h.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
        a.append(h.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
        a.append(h.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
        a.append(h.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
        a.append(h.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
        a.append(h.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
        a.append(h.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
        a.append(h.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
        a.append(h.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
        a.append(h.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
        a.append(h.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
        a.append(h.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
        a.append(h.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
      }
    }
  }
  
  private static class a {
    public static final SparseIntArray a = new SparseIntArray();
    
    static {
      a.append(h.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
      a.append(h.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
      a.append(h.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
      a.append(h.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
      a.append(h.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
      a.append(h.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
      a.append(h.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
      a.append(h.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
      a.append(h.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
      a.append(h.ConstraintLayout_Layout_layout_constraintCircle, 2);
      a.append(h.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
      a.append(h.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
      a.append(h.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
      a.append(h.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
      a.append(h.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
      a.append(h.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
      a.append(h.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
      a.append(h.ConstraintLayout_Layout_android_orientation, 1);
      a.append(h.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
      a.append(h.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
      a.append(h.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
      a.append(h.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
      a.append(h.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
      a.append(h.ConstraintLayout_Layout_layout_goneMarginTop, 22);
      a.append(h.ConstraintLayout_Layout_layout_goneMarginRight, 23);
      a.append(h.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
      a.append(h.ConstraintLayout_Layout_layout_goneMarginStart, 25);
      a.append(h.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
      a.append(h.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
      a.append(h.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
      a.append(h.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
      a.append(h.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
      a.append(h.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
      a.append(h.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
      a.append(h.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
      a.append(h.ConstraintLayout_Layout_layout_constrainedWidth, 27);
      a.append(h.ConstraintLayout_Layout_layout_constrainedHeight, 28);
      a.append(h.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
      a.append(h.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
      a.append(h.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
      a.append(h.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
      a.append(h.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
      a.append(h.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
      a.append(h.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
      a.append(h.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
      a.append(h.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
      a.append(h.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
      a.append(h.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
      a.append(h.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
      a.append(h.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\constraint\ConstraintLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */