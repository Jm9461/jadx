package android.support.design.internal;

import a.b.c.j;
import a.b.c.k;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.v4.view.c0;
import android.support.v4.view.p;
import android.support.v4.view.u;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;

public class f extends FrameLayout {
  Drawable c;
  
  Rect d;
  
  private Rect e = new Rect();
  
  public f(Context paramContext) {
    this(paramContext, null);
  }
  
  public f(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public f(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TypedArray typedArray = g.c(paramContext, paramAttributeSet, k.ScrimInsetsFrameLayout, paramInt, j.Widget_Design_ScrimInsetsFrameLayout, new int[0]);
    this.c = typedArray.getDrawable(k.ScrimInsetsFrameLayout_insetForeground);
    typedArray.recycle();
    setWillNotDraw(true);
    u.a((View)this, new a(this));
  }
  
  protected void a(c0 paramc0) {
    throw null;
  }
  
  public void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
    int i = getWidth();
    int j = getHeight();
    if (this.d != null && this.c != null) {
      int k = paramCanvas.save();
      paramCanvas.translate(getScrollX(), getScrollY());
      this.e.set(0, 0, i, this.d.top);
      this.c.setBounds(this.e);
      this.c.draw(paramCanvas);
      this.e.set(0, j - this.d.bottom, i, j);
      this.c.setBounds(this.e);
      this.c.draw(paramCanvas);
      Rect rect2 = this.e;
      Rect rect1 = this.d;
      rect2.set(0, rect1.top, rect1.left, j - rect1.bottom);
      this.c.setBounds(this.e);
      this.c.draw(paramCanvas);
      rect1 = this.e;
      rect2 = this.d;
      rect1.set(i - rect2.right, rect2.top, i, j - rect2.bottom);
      this.c.setBounds(this.e);
      this.c.draw(paramCanvas);
      paramCanvas.restoreToCount(k);
    } 
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    Drawable drawable = this.c;
    if (drawable != null)
      drawable.setCallback((Drawable.Callback)this); 
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    Drawable drawable = this.c;
    if (drawable != null)
      drawable.setCallback(null); 
  }
  
  class a implements p {
    final f a;
    
    a(f this$0) {}
    
    public c0 a(View param1View, c0 param1c0) {
      f f1 = this.a;
      if (f1.d == null)
        f1.d = new Rect(); 
      this.a.d.set(param1c0.c(), param1c0.e(), param1c0.d(), param1c0.b());
      this.a.a(param1c0);
      f1 = this.a;
      if (!param1c0.f() || this.a.c == null) {
        boolean bool1 = true;
        f1.setWillNotDraw(bool1);
        u.B((View)this.a);
        return param1c0.a();
      } 
      boolean bool = false;
      f1.setWillNotDraw(bool);
      u.B((View)this.a);
      return param1c0.a();
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\internal\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */