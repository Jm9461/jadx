package android.support.design.internal;

import android.content.Context;
import android.support.v7.view.menu.h;
import android.support.v7.view.menu.k;
import android.view.SubMenu;

public class b extends h {
  public b(Context paramContext) {
    super(paramContext);
  }
  
  public SubMenu addSubMenu(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    k k = (k)a(paramInt1, paramInt2, paramInt3, paramCharSequence);
    d d = new d(e(), this, k);
    k.a(d);
    return (SubMenu)d;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\internal\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */