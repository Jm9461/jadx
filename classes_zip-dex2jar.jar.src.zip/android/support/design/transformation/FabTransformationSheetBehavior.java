package android.support.design.transformation;

import a.b.c.a;
import a.b.c.l.h;
import a.b.c.l.j;
import android.content.Context;
import android.os.Build;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.view.u;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewParent;
import java.util.HashMap;
import java.util.Map;

public class FabTransformationSheetBehavior extends FabTransformationBehavior {
  private Map<View, Integer> g;
  
  public FabTransformationSheetBehavior() {}
  
  public FabTransformationSheetBehavior(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  private void a(View paramView, boolean paramBoolean) {
    ViewParent viewParent = paramView.getParent();
    if (!(viewParent instanceof CoordinatorLayout))
      return; 
    CoordinatorLayout coordinatorLayout = (CoordinatorLayout)viewParent;
    int i = coordinatorLayout.getChildCount();
    if (Build.VERSION.SDK_INT >= 16 && paramBoolean)
      this.g = new HashMap<View, Integer>(i); 
    for (byte b = 0; b < i; b++) {
      boolean bool;
      View view = coordinatorLayout.getChildAt(b);
      if (view.getLayoutParams() instanceof CoordinatorLayout.f && ((CoordinatorLayout.f)view.getLayoutParams()).d() instanceof FabTransformationScrimBehavior) {
        bool = true;
      } else {
        bool = false;
      } 
      if (view != paramView && !bool)
        if (!paramBoolean) {
          Map<View, Integer> map = this.g;
          if (map != null && map.containsKey(view))
            u.f(view, ((Integer)this.g.get(view)).intValue()); 
        } else {
          if (Build.VERSION.SDK_INT >= 16)
            this.g.put(view, Integer.valueOf(view.getImportantForAccessibility())); 
          u.f(view, 4);
        }  
    } 
    if (!paramBoolean)
      this.g = null; 
  }
  
  protected FabTransformationBehavior.e a(Context paramContext, boolean paramBoolean) {
    int i;
    if (paramBoolean) {
      i = a.mtrl_fab_transformation_sheet_expand_spec;
    } else {
      i = a.mtrl_fab_transformation_sheet_collapse_spec;
    } 
    FabTransformationBehavior.e e = new FabTransformationBehavior.e();
    e.a = h.a(paramContext, i);
    e.b = new j(17, 0.0F, 0.0F);
    return e;
  }
  
  protected boolean a(View paramView1, View paramView2, boolean paramBoolean1, boolean paramBoolean2) {
    a(paramView2, paramBoolean1);
    return super.a(paramView1, paramView2, paramBoolean1, paramBoolean2);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\transformation\FabTransformationSheetBehavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */