package android.support.design.transformation;

import a.b.c.f;
import a.b.c.l.h;
import a.b.c.l.i;
import a.b.c.l.j;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.q;
import android.support.v4.view.u;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewGroup;
import android.widget.ImageView;
import java.util.ArrayList;
import java.util.List;

public abstract class FabTransformationBehavior extends ExpandableTransformationBehavior {
  private final Rect c = new Rect();
  
  private final RectF d = new RectF();
  
  private final RectF e = new RectF();
  
  private final int[] f = new int[2];
  
  public FabTransformationBehavior() {}
  
  public FabTransformationBehavior(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  private float a(e parame, i parami, float paramFloat1, float paramFloat2) {
    long l1 = parami.a();
    long l2 = parami.b();
    i i1 = parame.a.a("expansion");
    float f = (float)(i1.a() + i1.b() + 17L - l1) / (float)l2;
    return a.b.c.l.a.a(paramFloat1, paramFloat2, parami.c().getInterpolation(f));
  }
  
  private float a(View paramView1, View paramView2, j paramj) {
    RectF rectF1 = this.d;
    RectF rectF2 = this.e;
    a(paramView1, rectF1);
    a(paramView2, rectF2);
    rectF2.offset(-c(paramView1, paramView2, paramj), 0.0F);
    return rectF1.centerX() - rectF2.left;
  }
  
  private ViewGroup a(View paramView) {
    View view = paramView.findViewById(f.mtrl_child_content_container);
    return (view != null) ? c(view) : ((paramView instanceof b || paramView instanceof a) ? c(((ViewGroup)paramView).getChildAt(0)) : c(paramView));
  }
  
  private void a(View paramView, long paramLong, int paramInt1, int paramInt2, float paramFloat, List<Animator> paramList) {
    if (Build.VERSION.SDK_INT >= 21 && paramLong > 0L) {
      Animator animator = ViewAnimationUtils.createCircularReveal(paramView, paramInt1, paramInt2, paramFloat, paramFloat);
      animator.setStartDelay(0L);
      animator.setDuration(paramLong);
      paramList.add(animator);
    } 
  }
  
  private void a(View paramView, long paramLong1, long paramLong2, long paramLong3, int paramInt1, int paramInt2, float paramFloat, List<Animator> paramList) {
    if (Build.VERSION.SDK_INT >= 21 && paramLong1 + paramLong2 < paramLong3) {
      Animator animator = ViewAnimationUtils.createCircularReveal(paramView, paramInt1, paramInt2, paramFloat, paramFloat);
      animator.setStartDelay(paramLong1 + paramLong2);
      animator.setDuration(paramLong3 - paramLong1 + paramLong2);
      paramList.add(animator);
    } 
  }
  
  private void a(View paramView, RectF paramRectF) {
    paramRectF.set(0.0F, 0.0F, paramView.getWidth(), paramView.getHeight());
    int[] arrayOfInt = this.f;
    paramView.getLocationInWindow(arrayOfInt);
    paramRectF.offsetTo(arrayOfInt[0], arrayOfInt[1]);
    paramRectF.offset((int)-paramView.getTranslationX(), (int)-paramView.getTranslationY());
  }
  
  private void a(View paramView, e parame, i parami1, i parami2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, RectF paramRectF) {
    paramFloat1 = a(parame, parami1, paramFloat1, paramFloat3);
    paramFloat2 = a(parame, parami2, paramFloat2, paramFloat4);
    Rect rect = this.c;
    paramView.getWindowVisibleDisplayFrame(rect);
    RectF rectF1 = this.d;
    rectF1.set(rect);
    RectF rectF2 = this.e;
    a(paramView, rectF2);
    rectF2.offset(paramFloat1, paramFloat2);
    rectF2.intersect(rectF1);
    paramRectF.set(rectF2);
  }
  
  private void a(View paramView1, View paramView2, boolean paramBoolean1, boolean paramBoolean2, e parame, float paramFloat1, float paramFloat2, List<Animator> paramList, List<Animator.AnimatorListener> paramList1) {
    Animator animator;
    if (!(paramView2 instanceof a.b.c.n.d))
      return; 
    a.b.c.n.d d = (a.b.c.n.d)paramView2;
    float f3 = a(paramView1, paramView2, parame.b);
    float f2 = b(paramView1, paramView2, parame.b);
    ((FloatingActionButton)paramView1).a(this.c);
    float f1 = this.c.width() / 2.0F;
    i i = parame.a.a("expansion");
    if (paramBoolean1) {
      if (!paramBoolean2)
        d.setRevealInfo(new a.b.c.n.d.e(f3, f2, f1)); 
      if (paramBoolean2)
        f1 = (d.getRevealInfo()).c; 
      paramFloat1 = q.a(f3, f2, 0.0F, 0.0F, paramFloat1, paramFloat2);
      animator = a.b.c.n.a.a(d, f3, f2, paramFloat1);
      animator.addListener((Animator.AnimatorListener)new d(this, d));
      a(paramView2, i.a(), (int)f3, (int)f2, f1, paramList);
    } else {
      paramFloat1 = (d.getRevealInfo()).c;
      animator = a.b.c.n.a.a(d, f3, f2, f1);
      a(paramView2, i.a(), (int)f3, (int)f2, paramFloat1, paramList);
      a(paramView2, i.a(), i.b(), parame.a.a(), (int)f3, (int)f2, f1, paramList);
    } 
    i.a(animator);
    paramList.add(animator);
    paramList1.add(a.b.c.n.a.a(d));
  }
  
  private void a(View paramView1, View paramView2, boolean paramBoolean1, boolean paramBoolean2, e parame, List<Animator> paramList, List<Animator.AnimatorListener> paramList1) {
    ObjectAnimator objectAnimator;
    if (!(paramView2 instanceof ViewGroup))
      return; 
    if (paramView2 instanceof a.b.c.n.d && a.b.c.n.c.a == 0)
      return; 
    ViewGroup viewGroup = a(paramView2);
    if (viewGroup == null)
      return; 
    if (paramBoolean1) {
      if (!paramBoolean2)
        a.b.c.l.d.a.set(viewGroup, Float.valueOf(0.0F)); 
      objectAnimator = ObjectAnimator.ofFloat(viewGroup, a.b.c.l.d.a, new float[] { 1.0F });
    } else {
      objectAnimator = ObjectAnimator.ofFloat(objectAnimator, a.b.c.l.d.a, new float[] { 0.0F });
    } 
    parame.a.a("contentFade").a((Animator)objectAnimator);
    paramList.add(objectAnimator);
  }
  
  private void a(View paramView1, View paramView2, boolean paramBoolean1, boolean paramBoolean2, e parame, List<Animator> paramList, List<Animator.AnimatorListener> paramList1, RectF paramRectF) {
    i i1;
    ObjectAnimator objectAnimator1;
    ObjectAnimator objectAnimator2;
    i i2;
    ObjectAnimator objectAnimator3;
    float f1 = c(paramView1, paramView2, parame.b);
    float f2 = d(paramView1, paramView2, parame.b);
    if (f1 == 0.0F || f2 == 0.0F) {
      i2 = parame.a.a("translationXLinear");
      i1 = parame.a.a("translationYLinear");
    } else if ((paramBoolean1 && f2 < 0.0F) || (!paramBoolean1 && f2 > 0.0F)) {
      i2 = parame.a.a("translationXCurveUpwards");
      i1 = parame.a.a("translationYCurveUpwards");
    } else {
      i2 = parame.a.a("translationXCurveDownwards");
      i1 = parame.a.a("translationYCurveDownwards");
    } 
    if (paramBoolean1) {
      if (!paramBoolean2) {
        paramView2.setTranslationX(-f1);
        paramView2.setTranslationY(-f2);
      } 
      ObjectAnimator objectAnimator5 = ObjectAnimator.ofFloat(paramView2, View.TRANSLATION_X, new float[] { 0.0F });
      ObjectAnimator objectAnimator4 = ObjectAnimator.ofFloat(paramView2, View.TRANSLATION_Y, new float[] { 0.0F });
      a(paramView2, parame, i2, i1, -f1, -f2, 0.0F, 0.0F, paramRectF);
      objectAnimator2 = objectAnimator5;
      objectAnimator1 = objectAnimator4;
      objectAnimator3 = objectAnimator1;
    } else {
      objectAnimator2 = ObjectAnimator.ofFloat(objectAnimator1, View.TRANSLATION_X, new float[] { -f1 });
      objectAnimator3 = ObjectAnimator.ofFloat(objectAnimator1, View.TRANSLATION_Y, new float[] { -f2 });
      objectAnimator1 = objectAnimator2;
      objectAnimator2 = objectAnimator1;
    } 
    i2.a((Animator)objectAnimator2);
    i1.a((Animator)objectAnimator3);
    paramList.add(objectAnimator2);
    paramList.add(objectAnimator3);
  }
  
  private float b(View paramView1, View paramView2, j paramj) {
    RectF rectF2 = this.d;
    RectF rectF1 = this.e;
    a(paramView1, rectF2);
    a(paramView2, rectF1);
    rectF1.offset(0.0F, -d(paramView1, paramView2, paramj));
    return rectF2.centerY() - rectF1.top;
  }
  
  private int b(View paramView) {
    ColorStateList colorStateList = u.c(paramView);
    return (colorStateList != null) ? colorStateList.getColorForState(paramView.getDrawableState(), colorStateList.getDefaultColor()) : 0;
  }
  
  private void b(View paramView1, View paramView2, boolean paramBoolean1, boolean paramBoolean2, e parame, List<Animator> paramList, List<Animator.AnimatorListener> paramList1) {
    ObjectAnimator objectAnimator;
    if (!(paramView2 instanceof a.b.c.n.d))
      return; 
    a.b.c.n.d d = (a.b.c.n.d)paramView2;
    int i = b(paramView1);
    if (paramBoolean1) {
      if (!paramBoolean2)
        d.setCircularRevealScrimColor(i); 
      objectAnimator = ObjectAnimator.ofInt(d, a.b.c.n.d.d.a, new int[] { 0xFFFFFF & i });
    } else {
      objectAnimator = ObjectAnimator.ofInt(d, a.b.c.n.d.d.a, new int[] { i });
    } 
    objectAnimator.setEvaluator((TypeEvaluator)a.b.c.l.c.a());
    parame.a.a("color").a((Animator)objectAnimator);
    paramList.add(objectAnimator);
  }
  
  private float c(View paramView1, View paramView2, j paramj) {
    RectF rectF2 = this.d;
    RectF rectF1 = this.e;
    a(paramView1, rectF2);
    a(paramView2, rectF1);
    float f = 0.0F;
    int i = paramj.a & 0x7;
    if (i != 1) {
      if (i != 3) {
        if (i == 5)
          f = rectF1.right - rectF2.right; 
      } else {
        f = rectF1.left - rectF2.left;
      } 
    } else {
      f = rectF1.centerX() - rectF2.centerX();
    } 
    return f + paramj.b;
  }
  
  private ViewGroup c(View paramView) {
    return (paramView instanceof ViewGroup) ? (ViewGroup)paramView : null;
  }
  
  @TargetApi(21)
  private void c(View paramView1, View paramView2, boolean paramBoolean1, boolean paramBoolean2, e parame, List<Animator> paramList, List<Animator.AnimatorListener> paramList1) {
    ObjectAnimator objectAnimator;
    float f = u.g(paramView2) - u.g(paramView1);
    if (paramBoolean1) {
      if (!paramBoolean2)
        paramView2.setTranslationZ(-f); 
      objectAnimator = ObjectAnimator.ofFloat(paramView2, View.TRANSLATION_Z, new float[] { 0.0F });
    } else {
      objectAnimator = ObjectAnimator.ofFloat(paramView2, View.TRANSLATION_Z, new float[] { -f });
    } 
    parame.a.a("elevation").a((Animator)objectAnimator);
    paramList.add(objectAnimator);
  }
  
  private float d(View paramView1, View paramView2, j paramj) {
    RectF rectF1 = this.d;
    RectF rectF2 = this.e;
    a(paramView1, rectF1);
    a(paramView2, rectF2);
    float f = 0.0F;
    int i = paramj.a & 0x70;
    if (i != 16) {
      if (i != 48) {
        if (i == 80)
          f = rectF2.bottom - rectF1.bottom; 
      } else {
        f = rectF2.top - rectF1.top;
      } 
    } else {
      f = rectF2.centerY() - rectF1.centerY();
    } 
    return f + paramj.c;
  }
  
  private void d(View paramView1, View paramView2, boolean paramBoolean1, boolean paramBoolean2, e parame, List<Animator> paramList, List<Animator.AnimatorListener> paramList1) {
    ObjectAnimator objectAnimator;
    if (!(paramView2 instanceof a.b.c.n.d) || !(paramView1 instanceof ImageView))
      return; 
    a.b.c.n.d d = (a.b.c.n.d)paramView2;
    Drawable drawable = ((ImageView)paramView1).getDrawable();
    if (drawable == null)
      return; 
    drawable.mutate();
    if (paramBoolean1) {
      if (!paramBoolean2)
        drawable.setAlpha(255); 
      objectAnimator = ObjectAnimator.ofInt(drawable, a.b.c.l.e.b, new int[] { 0 });
    } else {
      objectAnimator = ObjectAnimator.ofInt(drawable, a.b.c.l.e.b, new int[] { 255 });
    } 
    objectAnimator.addUpdateListener(new b(this, paramView2));
    parame.a.a("iconFade").a((Animator)objectAnimator);
    paramList.add(objectAnimator);
    paramList1.add(new c(this, d, drawable));
  }
  
  protected abstract e a(Context paramContext, boolean paramBoolean);
  
  public void a(CoordinatorLayout.f paramf) {
    if (paramf.h == 0)
      paramf.h = 80; 
  }
  
  public boolean a(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2) {
    if (paramView1.getVisibility() != 8) {
      boolean bool1 = paramView2 instanceof FloatingActionButton;
      boolean bool = false;
      if (bool1) {
        int i = ((FloatingActionButton)paramView2).getExpandedComponentIdHint();
        if (i == 0 || i == paramView1.getId())
          bool = true; 
        return bool;
      } 
      return false;
    } 
    throw new IllegalStateException("This behavior cannot be attached to a GONE view. Set the view to INVISIBLE instead.");
  }
  
  protected AnimatorSet b(View paramView1, View paramView2, boolean paramBoolean1, boolean paramBoolean2) {
    e e = a(paramView2.getContext(), paramBoolean1);
    ArrayList<Animator> arrayList1 = new ArrayList();
    ArrayList<Animator.AnimatorListener> arrayList = new ArrayList();
    if (Build.VERSION.SDK_INT >= 21)
      c(paramView1, paramView2, paramBoolean1, paramBoolean2, e, arrayList1, arrayList); 
    RectF rectF = this.d;
    a(paramView1, paramView2, paramBoolean1, paramBoolean2, e, arrayList1, arrayList, rectF);
    float f1 = rectF.width();
    float f2 = rectF.height();
    d(paramView1, paramView2, paramBoolean1, paramBoolean2, e, arrayList1, arrayList);
    a(paramView1, paramView2, paramBoolean1, paramBoolean2, e, f1, f2, arrayList1, arrayList);
    b(paramView1, paramView2, paramBoolean1, paramBoolean2, e, arrayList1, arrayList);
    a(paramView1, paramView2, paramBoolean1, paramBoolean2, e, arrayList1, arrayList);
    AnimatorSet animatorSet = new AnimatorSet();
    a.b.c.l.b.a(animatorSet, arrayList1);
    animatorSet.addListener((Animator.AnimatorListener)new a(this, paramBoolean1, paramView2, paramView1));
    byte b = 0;
    int i = arrayList.size();
    while (b < i) {
      animatorSet.addListener(arrayList.get(b));
      b++;
    } 
    return animatorSet;
  }
  
  class a extends AnimatorListenerAdapter {
    final boolean a;
    
    final View b;
    
    final View c;
    
    a(FabTransformationBehavior this$0, boolean param1Boolean, View param1View1, View param1View2) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      if (!this.a) {
        this.b.setVisibility(4);
        this.c.setAlpha(1.0F);
        this.c.setVisibility(0);
      } 
    }
    
    public void onAnimationStart(Animator param1Animator) {
      if (this.a) {
        this.b.setVisibility(0);
        this.c.setAlpha(0.0F);
        this.c.setVisibility(4);
      } 
    }
  }
  
  class b implements ValueAnimator.AnimatorUpdateListener {
    final View a;
    
    b(FabTransformationBehavior this$0, View param1View) {}
    
    public void onAnimationUpdate(ValueAnimator param1ValueAnimator) {
      this.a.invalidate();
    }
  }
  
  class c extends AnimatorListenerAdapter {
    final a.b.c.n.d a;
    
    final Drawable b;
    
    c(FabTransformationBehavior this$0, a.b.c.n.d param1d, Drawable param1Drawable) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.setCircularRevealOverlayDrawable(null);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.a.setCircularRevealOverlayDrawable(this.b);
    }
  }
  
  class d extends AnimatorListenerAdapter {
    final a.b.c.n.d a;
    
    d(FabTransformationBehavior this$0, a.b.c.n.d param1d) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      a.b.c.n.d.e e = this.a.getRevealInfo();
      e.c = Float.MAX_VALUE;
      this.a.setRevealInfo(e);
    }
  }
  
  protected static class e {
    public h a;
    
    public j b;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\transformation\FabTransformationBehavior.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */