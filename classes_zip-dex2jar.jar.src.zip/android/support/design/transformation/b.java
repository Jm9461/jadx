package android.support.design.transformation;

import a.b.c.n.b;

public class b extends b {}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\transformation\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */