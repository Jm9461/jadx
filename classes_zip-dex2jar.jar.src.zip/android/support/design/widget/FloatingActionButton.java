package android.support.design.widget;

import a.b.c.d;
import a.b.c.j;
import a.b.c.k;
import a.b.c.l.h;
import a.b.c.o.a;
import android.animation.Animator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.design.internal.g;
import android.support.design.internal.h;
import android.support.v4.view.t;
import android.support.v4.view.u;
import android.support.v4.widget.r;
import android.support.v7.widget.j;
import android.support.v7.widget.n;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import java.util.List;

@d(FloatingActionButton.Behavior.class)
public class FloatingActionButton extends a0 implements t, r, a {
  private ColorStateList d;
  
  private PorterDuff.Mode e;
  
  private ColorStateList f;
  
  private PorterDuff.Mode g;
  
  private int h;
  
  private ColorStateList i;
  
  private int j;
  
  private int k;
  
  private int l;
  
  private int m;
  
  boolean n;
  
  final Rect o = new Rect();
  
  private final Rect p = new Rect();
  
  private final n q;
  
  private final a.b.c.o.c r;
  
  private l s;
  
  public FloatingActionButton(Context paramContext) {
    this(paramContext, null);
  }
  
  public FloatingActionButton(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.b.c.b.floatingActionButtonStyle);
  }
  
  public FloatingActionButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TypedArray typedArray = g.c(paramContext, paramAttributeSet, k.FloatingActionButton, paramInt, j.Widget_Design_FloatingActionButton, new int[0]);
    this.d = a.b.c.p.a.a(paramContext, typedArray, k.FloatingActionButton_backgroundTint);
    this.e = h.a(typedArray.getInt(k.FloatingActionButton_backgroundTintMode, -1), null);
    this.i = a.b.c.p.a.a(paramContext, typedArray, k.FloatingActionButton_rippleColor);
    this.j = typedArray.getInt(k.FloatingActionButton_fabSize, -1);
    this.k = typedArray.getDimensionPixelSize(k.FloatingActionButton_fabCustomSize, 0);
    this.h = typedArray.getDimensionPixelSize(k.FloatingActionButton_borderWidth, 0);
    float f1 = typedArray.getDimension(k.FloatingActionButton_elevation, 0.0F);
    float f2 = typedArray.getDimension(k.FloatingActionButton_hoveredFocusedTranslationZ, 0.0F);
    float f3 = typedArray.getDimension(k.FloatingActionButton_pressedTranslationZ, 0.0F);
    this.n = typedArray.getBoolean(k.FloatingActionButton_useCompatPadding, false);
    this.m = typedArray.getDimensionPixelSize(k.FloatingActionButton_maxImageSize, 0);
    h h2 = h.a(paramContext, typedArray, k.FloatingActionButton_showMotionSpec);
    h h1 = h.a(paramContext, typedArray, k.FloatingActionButton_hideMotionSpec);
    typedArray.recycle();
    this.q = new n((ImageView)this);
    this.q.a(paramAttributeSet, paramInt);
    this.r = new a.b.c.o.c((a.b.c.o.b)this);
    getImpl().a(this.d, this.e, this.i, this.h);
    getImpl().a(f1);
    getImpl().b(f2);
    getImpl().d(f3);
    getImpl().a(this.m);
    getImpl().b(h2);
    getImpl().a(h1);
    setScaleType(ImageView.ScaleType.MATRIX);
  }
  
  private int a(int paramInt) {
    int i = this.k;
    if (i != 0)
      return i; 
    Resources resources = getResources();
    if (paramInt != -1)
      return (paramInt != 1) ? resources.getDimensionPixelSize(d.design_fab_size_normal) : resources.getDimensionPixelSize(d.design_fab_size_mini); 
    if (Math.max((resources.getConfiguration()).screenWidthDp, (resources.getConfiguration()).screenHeightDp) < 470) {
      paramInt = a(1);
    } else {
      paramInt = a(0);
    } 
    return paramInt;
  }
  
  private static int a(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.getMode(paramInt2);
    paramInt2 = View.MeasureSpec.getSize(paramInt2);
    if (i != Integer.MIN_VALUE) {
      if (i != 0)
        if (i == 1073741824) {
          paramInt1 = paramInt2;
        } else {
          throw new IllegalArgumentException();
        }  
    } else {
      paramInt1 = Math.min(paramInt1, paramInt2);
    } 
    return paramInt1;
  }
  
  private l.g a(b paramb) {
    return (paramb == null) ? null : new a(this, paramb);
  }
  
  private l c() {
    return (Build.VERSION.SDK_INT >= 21) ? new m(this, new c(this)) : new l(this, new c(this));
  }
  
  private void c(Rect paramRect) {
    int i = paramRect.left;
    Rect rect = this.o;
    paramRect.left = i + rect.left;
    paramRect.top += rect.top;
    paramRect.right -= rect.right;
    paramRect.bottom -= rect.bottom;
  }
  
  private void d() {
    Drawable drawable = getDrawable();
    if (drawable == null)
      return; 
    ColorStateList colorStateList = this.f;
    if (colorStateList == null) {
      android.support.v4.graphics.drawable.a.b(drawable);
      return;
    } 
    int i = colorStateList.getColorForState(getDrawableState(), 0);
    PorterDuff.Mode mode2 = this.g;
    PorterDuff.Mode mode1 = mode2;
    if (mode2 == null)
      mode1 = PorterDuff.Mode.SRC_IN; 
    drawable.mutate().setColorFilter((ColorFilter)j.a(i, mode1));
  }
  
  private l getImpl() {
    if (this.s == null)
      this.s = c(); 
    return this.s;
  }
  
  public void a(Animator.AnimatorListener paramAnimatorListener) {
    getImpl().a(paramAnimatorListener);
  }
  
  void a(b paramb, boolean paramBoolean) {
    getImpl().a(a(paramb), paramBoolean);
  }
  
  public boolean a() {
    return this.r.b();
  }
  
  @Deprecated
  public boolean a(Rect paramRect) {
    if (u.y((View)this)) {
      paramRect.set(0, 0, getWidth(), getHeight());
      c(paramRect);
      return true;
    } 
    return false;
  }
  
  public void b(Animator.AnimatorListener paramAnimatorListener) {
    getImpl().b(paramAnimatorListener);
  }
  
  public void b(Rect paramRect) {
    paramRect.set(0, 0, getMeasuredWidth(), getMeasuredHeight());
    c(paramRect);
  }
  
  void b(b paramb, boolean paramBoolean) {
    getImpl().b(a(paramb), paramBoolean);
  }
  
  public boolean b() {
    return getImpl().i();
  }
  
  public void c(Animator.AnimatorListener paramAnimatorListener) {
    getImpl().c(paramAnimatorListener);
  }
  
  public void d(Animator.AnimatorListener paramAnimatorListener) {
    getImpl().d(paramAnimatorListener);
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    getImpl().a(getDrawableState());
  }
  
  public ColorStateList getBackgroundTintList() {
    return this.d;
  }
  
  public PorterDuff.Mode getBackgroundTintMode() {
    return this.e;
  }
  
  public float getCompatElevation() {
    return getImpl().c();
  }
  
  public float getCompatHoveredFocusedTranslationZ() {
    return getImpl().e();
  }
  
  public float getCompatPressedTranslationZ() {
    return getImpl().f();
  }
  
  public Drawable getContentBackground() {
    return getImpl().b();
  }
  
  public int getCustomSize() {
    return this.k;
  }
  
  public int getExpandedComponentIdHint() {
    return this.r.a();
  }
  
  public h getHideMotionSpec() {
    return getImpl().d();
  }
  
  @Deprecated
  public int getRippleColor() {
    boolean bool;
    ColorStateList colorStateList = this.i;
    if (colorStateList != null) {
      bool = colorStateList.getDefaultColor();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public ColorStateList getRippleColorStateList() {
    return this.i;
  }
  
  public h getShowMotionSpec() {
    return getImpl().g();
  }
  
  public int getSize() {
    return this.j;
  }
  
  int getSizeDimension() {
    return a(this.j);
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    return getBackgroundTintList();
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    return getBackgroundTintMode();
  }
  
  public ColorStateList getSupportImageTintList() {
    return this.f;
  }
  
  public PorterDuff.Mode getSupportImageTintMode() {
    return this.g;
  }
  
  public boolean getUseCompatPadding() {
    return this.n;
  }
  
  public void jumpDrawablesToCurrentState() {
    super.jumpDrawablesToCurrentState();
    getImpl().j();
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    getImpl().m();
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    getImpl().o();
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i = getSizeDimension();
    this.l = (i - this.m) / 2;
    getImpl().s();
    paramInt1 = Math.min(a(i, paramInt1), a(i, paramInt2));
    Rect rect = this.o;
    setMeasuredDimension(rect.left + paramInt1 + rect.right, rect.top + paramInt1 + rect.bottom);
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof a.b.c.t.a)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    a.b.c.t.a a1 = (a.b.c.t.a)paramParcelable;
    super.onRestoreInstanceState(a1.a());
    this.r.a((Bundle)a1.e.get("expandableWidgetHelper"));
  }
  
  protected Parcelable onSaveInstanceState() {
    a.b.c.t.a a1 = new a.b.c.t.a(super.onSaveInstanceState());
    a1.e.put("expandableWidgetHelper", this.r.c());
    return (Parcelable)a1;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    return (paramMotionEvent.getAction() == 0 && a(this.p) && !this.p.contains((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY())) ? false : super.onTouchEvent(paramMotionEvent);
  }
  
  public void setBackgroundColor(int paramInt) {
    Log.i("FloatingActionButton", "Setting a custom background is not supported.");
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    Log.i("FloatingActionButton", "Setting a custom background is not supported.");
  }
  
  public void setBackgroundResource(int paramInt) {
    Log.i("FloatingActionButton", "Setting a custom background is not supported.");
  }
  
  public void setBackgroundTintList(ColorStateList paramColorStateList) {
    if (this.d != paramColorStateList) {
      this.d = paramColorStateList;
      getImpl().a(paramColorStateList);
    } 
  }
  
  public void setBackgroundTintMode(PorterDuff.Mode paramMode) {
    if (this.e != paramMode) {
      this.e = paramMode;
      getImpl().a(paramMode);
    } 
  }
  
  public void setCompatElevation(float paramFloat) {
    getImpl().a(paramFloat);
  }
  
  public void setCompatElevationResource(int paramInt) {
    setCompatElevation(getResources().getDimension(paramInt));
  }
  
  public void setCompatHoveredFocusedTranslationZ(float paramFloat) {
    getImpl().b(paramFloat);
  }
  
  public void setCompatHoveredFocusedTranslationZResource(int paramInt) {
    setCompatHoveredFocusedTranslationZ(getResources().getDimension(paramInt));
  }
  
  public void setCompatPressedTranslationZ(float paramFloat) {
    getImpl().d(paramFloat);
  }
  
  public void setCompatPressedTranslationZResource(int paramInt) {
    setCompatPressedTranslationZ(getResources().getDimension(paramInt));
  }
  
  public void setCustomSize(int paramInt) {
    if (paramInt >= 0) {
      this.k = paramInt;
      return;
    } 
    throw new IllegalArgumentException("Custom size must be non-negative");
  }
  
  public void setExpandedComponentIdHint(int paramInt) {
    this.r.a(paramInt);
  }
  
  public void setHideMotionSpec(h paramh) {
    getImpl().a(paramh);
  }
  
  public void setHideMotionSpecResource(int paramInt) {
    setHideMotionSpec(h.a(getContext(), paramInt));
  }
  
  public void setImageDrawable(Drawable paramDrawable) {
    super.setImageDrawable(paramDrawable);
    getImpl().r();
  }
  
  public void setImageResource(int paramInt) {
    this.q.a(paramInt);
  }
  
  public void setRippleColor(int paramInt) {
    setRippleColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setRippleColor(ColorStateList paramColorStateList) {
    if (this.i != paramColorStateList) {
      this.i = paramColorStateList;
      getImpl().b(this.i);
    } 
  }
  
  public void setShowMotionSpec(h paramh) {
    getImpl().b(paramh);
  }
  
  public void setShowMotionSpecResource(int paramInt) {
    setShowMotionSpec(h.a(getContext(), paramInt));
  }
  
  public void setSize(int paramInt) {
    this.k = 0;
    if (paramInt != this.j) {
      this.j = paramInt;
      requestLayout();
    } 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    setBackgroundTintList(paramColorStateList);
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    setBackgroundTintMode(paramMode);
  }
  
  public void setSupportImageTintList(ColorStateList paramColorStateList) {
    if (this.f != paramColorStateList) {
      this.f = paramColorStateList;
      d();
    } 
  }
  
  public void setSupportImageTintMode(PorterDuff.Mode paramMode) {
    if (this.g != paramMode) {
      this.g = paramMode;
      d();
    } 
  }
  
  public void setUseCompatPadding(boolean paramBoolean) {
    if (this.n != paramBoolean) {
      this.n = paramBoolean;
      getImpl().n();
    } 
  }
  
  protected static class BaseBehavior<T extends FloatingActionButton> extends CoordinatorLayout.c<T> {
    private Rect a;
    
    private FloatingActionButton.b b;
    
    private boolean c;
    
    public BaseBehavior() {
      this.c = true;
    }
    
    public BaseBehavior(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, k.FloatingActionButton_Behavior_Layout);
      this.c = typedArray.getBoolean(k.FloatingActionButton_Behavior_Layout_behavior_autoHide, true);
      typedArray.recycle();
    }
    
    private void a(CoordinatorLayout param1CoordinatorLayout, FloatingActionButton param1FloatingActionButton) {
      Rect rect = param1FloatingActionButton.o;
      if (rect != null && rect.centerX() > 0 && rect.centerY() > 0) {
        CoordinatorLayout.f f = (CoordinatorLayout.f)param1FloatingActionButton.getLayoutParams();
        int j = 0;
        int i = 0;
        if (param1FloatingActionButton.getRight() >= param1CoordinatorLayout.getWidth() - f.rightMargin) {
          i = rect.right;
        } else if (param1FloatingActionButton.getLeft() <= f.leftMargin) {
          i = -rect.left;
        } 
        if (param1FloatingActionButton.getBottom() >= param1CoordinatorLayout.getHeight() - f.bottomMargin) {
          j = rect.bottom;
        } else if (param1FloatingActionButton.getTop() <= f.topMargin) {
          j = -rect.top;
        } 
        if (j != 0)
          u.d((View)param1FloatingActionButton, j); 
        if (i != 0)
          u.c((View)param1FloatingActionButton, i); 
      } 
    }
    
    private boolean a(CoordinatorLayout param1CoordinatorLayout, AppBarLayout param1AppBarLayout, FloatingActionButton param1FloatingActionButton) {
      if (!a((View)param1AppBarLayout, param1FloatingActionButton))
        return false; 
      if (this.a == null)
        this.a = new Rect(); 
      Rect rect = this.a;
      j.a(param1CoordinatorLayout, (View)param1AppBarLayout, rect);
      if (rect.bottom <= param1AppBarLayout.getMinimumHeightForVisibleOverlappingContent()) {
        param1FloatingActionButton.a(this.b, false);
      } else {
        param1FloatingActionButton.b(this.b, false);
      } 
      return true;
    }
    
    private static boolean a(View param1View) {
      ViewGroup.LayoutParams layoutParams = param1View.getLayoutParams();
      return (layoutParams instanceof CoordinatorLayout.f) ? (((CoordinatorLayout.f)layoutParams).d() instanceof BottomSheetBehavior) : false;
    }
    
    private boolean a(View param1View, FloatingActionButton param1FloatingActionButton) {
      CoordinatorLayout.f f = (CoordinatorLayout.f)param1FloatingActionButton.getLayoutParams();
      return !this.c ? false : ((f.c() != param1View.getId()) ? false : (!(param1FloatingActionButton.getUserSetVisibility() != 0)));
    }
    
    private boolean b(View param1View, FloatingActionButton param1FloatingActionButton) {
      if (!a(param1View, param1FloatingActionButton))
        return false; 
      CoordinatorLayout.f f = (CoordinatorLayout.f)param1FloatingActionButton.getLayoutParams();
      if (param1View.getTop() < param1FloatingActionButton.getHeight() / 2 + f.topMargin) {
        param1FloatingActionButton.a(this.b, false);
      } else {
        param1FloatingActionButton.b(this.b, false);
      } 
      return true;
    }
    
    public void a(CoordinatorLayout.f param1f) {
      if (param1f.h == 0)
        param1f.h = 80; 
    }
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, FloatingActionButton param1FloatingActionButton, int param1Int) {
      List<View> list = param1CoordinatorLayout.b((View)param1FloatingActionButton);
      byte b1 = 0;
      int i = list.size();
      while (b1 < i) {
        View view = list.get(b1);
        if ((view instanceof AppBarLayout) ? a(param1CoordinatorLayout, (AppBarLayout)view, param1FloatingActionButton) : (a(view) && b(view, param1FloatingActionButton)))
          break; 
        b1++;
      } 
      param1CoordinatorLayout.c((View)param1FloatingActionButton, param1Int);
      a(param1CoordinatorLayout, param1FloatingActionButton);
      return true;
    }
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, FloatingActionButton param1FloatingActionButton, Rect param1Rect) {
      Rect rect = param1FloatingActionButton.o;
      param1Rect.set(param1FloatingActionButton.getLeft() + rect.left, param1FloatingActionButton.getTop() + rect.top, param1FloatingActionButton.getRight() - rect.right, param1FloatingActionButton.getBottom() - rect.bottom);
      return true;
    }
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, FloatingActionButton param1FloatingActionButton, View param1View) {
      if (param1View instanceof AppBarLayout) {
        a(param1CoordinatorLayout, (AppBarLayout)param1View, param1FloatingActionButton);
      } else if (a(param1View)) {
        b(param1View, param1FloatingActionButton);
      } 
      return false;
    }
  }
  
  public static class Behavior extends BaseBehavior<FloatingActionButton> {
    public Behavior() {}
    
    public Behavior(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
  }
  
  class a implements l.g {
    final FloatingActionButton.b a;
    
    final FloatingActionButton b;
    
    a(FloatingActionButton this$0, FloatingActionButton.b param1b) {}
    
    public void a() {
      this.a.b(this.b);
    }
    
    public void b() {
      this.a.a(this.b);
    }
  }
  
  public static abstract class b {
    public abstract void a(FloatingActionButton param1FloatingActionButton);
    
    public abstract void b(FloatingActionButton param1FloatingActionButton);
  }
  
  private class c implements s {
    final FloatingActionButton a;
    
    c(FloatingActionButton this$0) {}
    
    public float a() {
      return this.a.getSizeDimension() / 2.0F;
    }
    
    public void a(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.a.o.set(param1Int1, param1Int2, param1Int3, param1Int4);
      FloatingActionButton floatingActionButton = this.a;
      floatingActionButton.setPadding(FloatingActionButton.a(floatingActionButton) + param1Int1, FloatingActionButton.a(this.a) + param1Int2, FloatingActionButton.a(this.a) + param1Int3, FloatingActionButton.a(this.a) + param1Int4);
    }
    
    public void a(Drawable param1Drawable) {
      FloatingActionButton.a(this.a, param1Drawable);
    }
    
    public boolean b() {
      return this.a.n;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\FloatingActionButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */