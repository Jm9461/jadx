package android.support.design.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageButton;

public class a0 extends ImageButton {
  private int c = getVisibility();
  
  public a0(Context paramContext) {
    this(paramContext, null);
  }
  
  public a0(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public a0(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  public final void a(int paramInt, boolean paramBoolean) {
    super.setVisibility(paramInt);
    if (paramBoolean)
      this.c = paramInt; 
  }
  
  public final int getUserSetVisibility() {
    return this.c;
  }
  
  public void setVisibility(int paramInt) {
    a(paramInt, true);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */