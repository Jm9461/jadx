package android.support.design.widget;

import a.b.c.j;
import a.b.c.k;
import a.b.h.f.g;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.design.internal.f;
import android.support.design.internal.g;
import android.support.v4.view.c0;
import android.support.v4.view.u;
import android.support.v7.view.menu.h;
import android.support.v7.view.menu.k;
import android.support.v7.view.menu.p;
import android.support.v7.widget.j1;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

public class NavigationView extends f {
  private static final int[] k = new int[] { 16842912 };
  
  private static final int[] l = new int[] { -16842910 };
  
  private final android.support.design.internal.b f;
  
  private final android.support.design.internal.c g;
  
  b h;
  
  private final int i;
  
  private MenuInflater j;
  
  public NavigationView(Context paramContext) {
    this(paramContext, null);
  }
  
  public NavigationView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.b.c.b.navigationViewStyle);
  }
  
  public NavigationView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    ColorStateList colorStateList1;
    ColorStateList colorStateList2;
    this.g = new android.support.design.internal.c();
    this.f = new android.support.design.internal.b(paramContext);
    j1 j1 = g.d(paramContext, paramAttributeSet, k.NavigationView, paramInt, j.Widget_Design_NavigationView, new int[0]);
    u.a((View)this, j1.b(k.NavigationView_android_background));
    if (j1.g(k.NavigationView_elevation))
      u.a((View)this, j1.c(k.NavigationView_elevation, 0)); 
    u.a((View)this, j1.a(k.NavigationView_android_fitsSystemWindows, false));
    this.i = j1.c(k.NavigationView_android_maxWidth, 0);
    if (j1.g(k.NavigationView_itemIconTint)) {
      colorStateList2 = j1.a(k.NavigationView_itemIconTint);
    } else {
      colorStateList2 = c(16842808);
    } 
    paramInt = 0;
    int i = 0;
    if (j1.g(k.NavigationView_itemTextAppearance)) {
      i = j1.g(k.NavigationView_itemTextAppearance, 0);
      paramInt = 1;
    } 
    paramAttributeSet = null;
    if (j1.g(k.NavigationView_itemTextColor))
      colorStateList1 = j1.a(k.NavigationView_itemTextColor); 
    ColorStateList colorStateList3 = colorStateList1;
    if (paramInt == 0) {
      colorStateList3 = colorStateList1;
      if (colorStateList1 == null)
        colorStateList3 = c(16842806); 
    } 
    Drawable drawable = j1.b(k.NavigationView_itemBackground);
    if (j1.g(k.NavigationView_itemHorizontalPadding)) {
      int k = j1.c(k.NavigationView_itemHorizontalPadding, 0);
      this.g.c(k);
    } 
    int j = j1.c(k.NavigationView_itemIconPadding, 0);
    this.f.a(new a(this));
    this.g.b(1);
    this.g.a(paramContext, (h)this.f);
    this.g.a(colorStateList2);
    if (paramInt != 0)
      this.g.e(i); 
    this.g.b(colorStateList3);
    this.g.a(drawable);
    this.g.d(j);
    this.f.a((p)this.g);
    addView((View)this.g.a((ViewGroup)this));
    if (j1.g(k.NavigationView_menu))
      b(j1.g(k.NavigationView_menu, 0)); 
    if (j1.g(k.NavigationView_headerLayout))
      a(j1.g(k.NavigationView_headerLayout, 0)); 
    j1.a();
  }
  
  private ColorStateList c(int paramInt) {
    TypedValue typedValue = new TypedValue();
    if (!getContext().getTheme().resolveAttribute(paramInt, typedValue, true))
      return null; 
    ColorStateList colorStateList = a.b.h.c.a.a.b(getContext(), typedValue.resourceId);
    if (!getContext().getTheme().resolveAttribute(a.b.h.a.a.colorPrimary, typedValue, true))
      return null; 
    int i = typedValue.data;
    paramInt = colorStateList.getDefaultColor();
    int[] arrayOfInt2 = l;
    int[] arrayOfInt3 = k;
    int[] arrayOfInt1 = FrameLayout.EMPTY_STATE_SET;
    int j = colorStateList.getColorForState(l, paramInt);
    return new ColorStateList(new int[][] { arrayOfInt2, arrayOfInt3, arrayOfInt1 }, new int[] { j, i, paramInt });
  }
  
  private MenuInflater getMenuInflater() {
    if (this.j == null)
      this.j = (MenuInflater)new g(getContext()); 
    return this.j;
  }
  
  public View a(int paramInt) {
    return this.g.a(paramInt);
  }
  
  protected void a(c0 paramc0) {
    this.g.a(paramc0);
  }
  
  public void b(int paramInt) {
    this.g.b(true);
    getMenuInflater().inflate(paramInt, (Menu)this.f);
    this.g.b(false);
    this.g.a(false);
  }
  
  public MenuItem getCheckedItem() {
    return (MenuItem)this.g.d();
  }
  
  public int getHeaderCount() {
    return this.g.e();
  }
  
  public Drawable getItemBackground() {
    return this.g.f();
  }
  
  public int getItemHorizontalPadding() {
    return this.g.g();
  }
  
  public int getItemIconPadding() {
    return this.g.h();
  }
  
  public ColorStateList getItemIconTintList() {
    return this.g.j();
  }
  
  public ColorStateList getItemTextColor() {
    return this.g.i();
  }
  
  public Menu getMenu() {
    return (Menu)this.f;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.getMode(paramInt1);
    if (i != Integer.MIN_VALUE) {
      if (i != 0) {
        if (i != 1073741824);
      } else {
        paramInt1 = View.MeasureSpec.makeMeasureSpec(this.i, 1073741824);
      } 
    } else {
      paramInt1 = View.MeasureSpec.makeMeasureSpec(Math.min(View.MeasureSpec.getSize(paramInt1), this.i), 1073741824);
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof c)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    c c1 = (c)paramParcelable;
    super.onRestoreInstanceState(c1.a());
    this.f.b(c1.e);
  }
  
  protected Parcelable onSaveInstanceState() {
    c c1 = new c(super.onSaveInstanceState());
    c1.e = new Bundle();
    this.f.d(c1.e);
    return (Parcelable)c1;
  }
  
  public void setCheckedItem(int paramInt) {
    MenuItem menuItem = this.f.findItem(paramInt);
    if (menuItem != null)
      this.g.a((k)menuItem); 
  }
  
  public void setCheckedItem(MenuItem paramMenuItem) {
    paramMenuItem = this.f.findItem(paramMenuItem.getItemId());
    if (paramMenuItem != null) {
      this.g.a((k)paramMenuItem);
      return;
    } 
    throw new IllegalArgumentException("Called setCheckedItem(MenuItem) with an item that is not in the current menu.");
  }
  
  public void setItemBackground(Drawable paramDrawable) {
    this.g.a(paramDrawable);
  }
  
  public void setItemBackgroundResource(int paramInt) {
    setItemBackground(android.support.v4.content.a.c(getContext(), paramInt));
  }
  
  public void setItemHorizontalPadding(int paramInt) {
    this.g.c(paramInt);
  }
  
  public void setItemHorizontalPaddingResource(int paramInt) {
    this.g.c(getResources().getDimensionPixelSize(paramInt));
  }
  
  public void setItemIconPadding(int paramInt) {
    this.g.d(paramInt);
  }
  
  public void setItemIconPaddingResource(int paramInt) {
    this.g.d(getResources().getDimensionPixelSize(paramInt));
  }
  
  public void setItemIconTintList(ColorStateList paramColorStateList) {
    this.g.a(paramColorStateList);
  }
  
  public void setItemTextAppearance(int paramInt) {
    this.g.e(paramInt);
  }
  
  public void setItemTextColor(ColorStateList paramColorStateList) {
    this.g.b(paramColorStateList);
  }
  
  public void setNavigationItemSelectedListener(b paramb) {
    this.h = paramb;
  }
  
  class a implements h.a {
    final NavigationView c;
    
    a(NavigationView this$0) {}
    
    public void a(h param1h) {}
    
    public boolean a(h param1h, MenuItem param1MenuItem) {
      boolean bool;
      NavigationView.b b = this.c.h;
      if (b != null && b.a(param1MenuItem)) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
  }
  
  public static interface b {
    boolean a(MenuItem param1MenuItem);
  }
  
  public static class c extends android.support.v4.view.a {
    public static final Parcelable.Creator<c> CREATOR = (Parcelable.Creator<c>)new a();
    
    public Bundle e;
    
    public c(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      this.e = param1Parcel.readBundle(param1ClassLoader);
    }
    
    public c(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeBundle(this.e);
    }
    
    static final class a implements Parcelable.ClassLoaderCreator<c> {
      public NavigationView.c createFromParcel(Parcel param2Parcel) {
        return new NavigationView.c(param2Parcel, null);
      }
      
      public NavigationView.c createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new NavigationView.c(param2Parcel, param2ClassLoader);
      }
      
      public NavigationView.c[] newArray(int param2Int) {
        return new NavigationView.c[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.ClassLoaderCreator<c> {
    public NavigationView.c createFromParcel(Parcel param1Parcel) {
      return new NavigationView.c(param1Parcel, null);
    }
    
    public NavigationView.c createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new NavigationView.c(param1Parcel, param1ClassLoader);
    }
    
    public NavigationView.c[] newArray(int param1Int) {
      return new NavigationView.c[param1Int];
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\NavigationView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */