package android.support.design.widget;

import a.b.c.d;
import a.b.c.f;
import a.b.c.k;
import a.b.c.s.a;
import android.content.Context;
import android.content.res.TypedArray;
import android.support.v4.view.u;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SnackbarContentLayout extends LinearLayout implements a {
  private TextView c;
  
  private Button d;
  
  private int e;
  
  private int f;
  
  public SnackbarContentLayout(Context paramContext) {
    this(paramContext, null);
  }
  
  public SnackbarContentLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, k.SnackbarLayout);
    this.e = typedArray.getDimensionPixelSize(k.SnackbarLayout_android_maxWidth, -1);
    this.f = typedArray.getDimensionPixelSize(k.SnackbarLayout_maxActionInlineWidth, -1);
    typedArray.recycle();
  }
  
  private static void a(View paramView, int paramInt1, int paramInt2) {
    if (u.A(paramView)) {
      u.a(paramView, u.o(paramView), paramInt1, u.n(paramView), paramInt2);
    } else {
      paramView.setPadding(paramView.getPaddingLeft(), paramInt1, paramView.getPaddingRight(), paramInt2);
    } 
  }
  
  private boolean a(int paramInt1, int paramInt2, int paramInt3) {
    boolean bool = false;
    if (paramInt1 != getOrientation()) {
      setOrientation(paramInt1);
      bool = true;
    } 
    if (this.c.getPaddingTop() != paramInt2 || this.c.getPaddingBottom() != paramInt3) {
      a((View)this.c, paramInt2, paramInt3);
      bool = true;
    } 
    return bool;
  }
  
  public Button getActionView() {
    return this.d;
  }
  
  public TextView getMessageView() {
    return this.c;
  }
  
  protected void onFinishInflate() {
    super.onFinishInflate();
    this.c = (TextView)findViewById(f.snackbar_text);
    this.d = (Button)findViewById(f.snackbar_action);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    int i = paramInt1;
    if (this.e > 0) {
      int n = getMeasuredWidth();
      int m = this.e;
      i = paramInt1;
      if (n > m) {
        i = View.MeasureSpec.makeMeasureSpec(m, 1073741824);
        super.onMeasure(i, paramInt2);
      } 
    } 
    int k = getResources().getDimensionPixelSize(d.design_snackbar_padding_vertical_2lines);
    int j = getResources().getDimensionPixelSize(d.design_snackbar_padding_vertical);
    if (this.c.getLayout().getLineCount() > 1) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    boolean bool = false;
    if (paramInt1 != 0 && this.f > 0 && this.d.getMeasuredWidth() > this.f) {
      paramInt1 = bool;
      if (a(1, k, k - j))
        paramInt1 = 1; 
    } else {
      if (paramInt1 != 0)
        j = k; 
      paramInt1 = bool;
      if (a(0, j, j))
        paramInt1 = 1; 
    } 
    if (paramInt1 != 0)
      super.onMeasure(i, paramInt2); 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\SnackbarContentLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */