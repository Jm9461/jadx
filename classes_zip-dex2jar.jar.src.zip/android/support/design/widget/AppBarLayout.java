package android.support.design.widget;

import a.b.c.j;
import a.b.c.k;
import a.b.g.g.i;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.design.internal.g;
import android.support.v4.view.c0;
import android.support.v4.view.p;
import android.support.v4.view.u;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import java.lang.ref.WeakReference;
import java.util.List;

@d(AppBarLayout.Behavior.class)
public class AppBarLayout extends LinearLayout {
  private int c = -1;
  
  private int d = -1;
  
  private int e = -1;
  
  private boolean f;
  
  private int g = 0;
  
  private c0 h;
  
  private List<b> i;
  
  private boolean j;
  
  private boolean k;
  
  private boolean l;
  
  private boolean m;
  
  private int[] n;
  
  public AppBarLayout(Context paramContext) {
    this(paramContext, null);
  }
  
  public AppBarLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setOrientation(1);
    if (Build.VERSION.SDK_INT >= 21) {
      z.a((View)this);
      z.a((View)this, paramAttributeSet, 0, j.Widget_Design_AppBarLayout);
    } 
    TypedArray typedArray = g.c(paramContext, paramAttributeSet, k.AppBarLayout, 0, j.Widget_Design_AppBarLayout, new int[0]);
    u.a((View)this, typedArray.getDrawable(k.AppBarLayout_android_background));
    if (typedArray.hasValue(k.AppBarLayout_expanded))
      a(typedArray.getBoolean(k.AppBarLayout_expanded, false), false, false); 
    if (Build.VERSION.SDK_INT >= 21 && typedArray.hasValue(k.AppBarLayout_elevation))
      z.a((View)this, typedArray.getDimensionPixelSize(k.AppBarLayout_elevation, 0)); 
    if (Build.VERSION.SDK_INT >= 26) {
      if (typedArray.hasValue(k.AppBarLayout_android_keyboardNavigationCluster))
        setKeyboardNavigationCluster(typedArray.getBoolean(k.AppBarLayout_android_keyboardNavigationCluster, false)); 
      if (typedArray.hasValue(k.AppBarLayout_android_touchscreenBlocksFocus))
        setTouchscreenBlocksFocus(typedArray.getBoolean(k.AppBarLayout_android_touchscreenBlocksFocus, false)); 
    } 
    this.m = typedArray.getBoolean(k.AppBarLayout_liftOnScroll, false);
    typedArray.recycle();
    u.a((View)this, new a(this));
  }
  
  private void a(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    byte b1;
    byte b2;
    if (paramBoolean1) {
      b1 = 1;
    } else {
      b1 = 2;
    } 
    byte b3 = 0;
    if (paramBoolean2) {
      b2 = 4;
    } else {
      b2 = 0;
    } 
    if (paramBoolean3)
      b3 = 8; 
    this.g = b1 | b2 | b3;
    requestLayout();
  }
  
  private boolean b(boolean paramBoolean) {
    if (this.k != paramBoolean) {
      this.k = paramBoolean;
      refreshDrawableState();
      return true;
    } 
    return false;
  }
  
  private boolean e() {
    byte b = 0;
    int i = getChildCount();
    while (b < i) {
      if (((c)getChildAt(b).getLayoutParams()).c())
        return true; 
      b++;
    } 
    return false;
  }
  
  private void f() {
    this.c = -1;
    this.d = -1;
    this.e = -1;
  }
  
  c0 a(c0 paramc0) {
    c0 c01 = null;
    if (u.h((View)this))
      c01 = paramc0; 
    if (!i.a(this.h, c01)) {
      this.h = c01;
      f();
    } 
    return paramc0;
  }
  
  void a(int paramInt) {
    List<b> list = this.i;
    if (list != null) {
      byte b = 0;
      int i = list.size();
      while (b < i) {
        b<AppBarLayout> b1 = this.i.get(b);
        if (b1 != null)
          b1.a(this, paramInt); 
        b++;
      } 
    } 
  }
  
  public void a(boolean paramBoolean1, boolean paramBoolean2) {
    a(paramBoolean1, paramBoolean2, true);
  }
  
  boolean a() {
    return this.f;
  }
  
  boolean a(boolean paramBoolean) {
    if (this.l != paramBoolean) {
      this.l = paramBoolean;
      refreshDrawableState();
      return true;
    } 
    return false;
  }
  
  boolean b() {
    boolean bool;
    if (getTotalScrollRange() != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean c() {
    return this.m;
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof c;
  }
  
  void d() {
    this.g = 0;
  }
  
  protected c generateDefaultLayoutParams() {
    return new c(-1, -2);
  }
  
  public c generateLayoutParams(AttributeSet paramAttributeSet) {
    return new c(getContext(), paramAttributeSet);
  }
  
  protected c generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (Build.VERSION.SDK_INT >= 19 && paramLayoutParams instanceof LinearLayout.LayoutParams) ? new c((LinearLayout.LayoutParams)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new c((ViewGroup.MarginLayoutParams)paramLayoutParams) : new c(paramLayoutParams));
  }
  
  int getDownNestedPreScrollRange() {
    int i = this.d;
    if (i != -1)
      return i; 
    int k = 0;
    int j = getChildCount() - 1;
    while (j >= 0) {
      View view = getChildAt(j);
      c c = (c)view.getLayoutParams();
      i = view.getMeasuredHeight();
      int m = c.a;
      if ((m & 0x5) == 5) {
        k += c.topMargin + c.bottomMargin;
        if ((m & 0x8) != 0) {
          i = k + u.l(view);
        } else if ((m & 0x2) != 0) {
          i = k + i - u.l(view);
        } else {
          i = k + i - getTopInset();
        } 
      } else {
        i = k;
        if (k > 0)
          break; 
      } 
      j--;
      k = i;
    } 
    i = Math.max(0, k);
    this.d = i;
    return i;
  }
  
  int getDownNestedScrollRange() {
    int j;
    int i = this.e;
    if (i != -1)
      return i; 
    i = 0;
    byte b = 0;
    int k = getChildCount();
    while (true) {
      j = i;
      if (b < k) {
        View view = getChildAt(b);
        c c = (c)view.getLayoutParams();
        int n = view.getMeasuredHeight();
        int i1 = c.topMargin;
        int i2 = c.bottomMargin;
        int m = c.a;
        j = i;
        if ((m & 0x1) != 0) {
          i += n + i1 + i2;
          if ((m & 0x2) != 0) {
            j = i - u.l(view) + getTopInset();
            break;
          } 
          b++;
          continue;
        } 
      } 
      break;
    } 
    i = Math.max(0, j);
    this.e = i;
    return i;
  }
  
  public final int getMinimumHeightForVisibleOverlappingContent() {
    int j = getTopInset();
    int i = u.l((View)this);
    if (i != 0)
      return i * 2 + j; 
    i = getChildCount();
    if (i >= 1) {
      i = u.l(getChildAt(i - 1));
    } else {
      i = 0;
    } 
    return (i != 0) ? (i * 2 + j) : (getHeight() / 3);
  }
  
  int getPendingAction() {
    return this.g;
  }
  
  @Deprecated
  public float getTargetElevation() {
    return 0.0F;
  }
  
  final int getTopInset() {
    boolean bool;
    c0 c01 = this.h;
    if (c01 != null) {
      bool = c01.e();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final int getTotalScrollRange() {
    int j;
    int i = this.c;
    if (i != -1)
      return i; 
    i = 0;
    byte b = 0;
    int k = getChildCount();
    while (true) {
      j = i;
      if (b < k) {
        View view = getChildAt(b);
        c c = (c)view.getLayoutParams();
        int n = view.getMeasuredHeight();
        int m = c.a;
        j = i;
        if ((m & 0x1) != 0) {
          i += c.topMargin + n + c.bottomMargin;
          if ((m & 0x2) != 0) {
            j = i - u.l(view);
            break;
          } 
          b++;
          continue;
        } 
      } 
      break;
    } 
    i = Math.max(0, j - getTopInset());
    this.c = i;
    return i;
  }
  
  int getUpNestedPreScrollRange() {
    return getTotalScrollRange();
  }
  
  protected int[] onCreateDrawableState(int paramInt) {
    if (this.n == null)
      this.n = new int[4]; 
    int[] arrayOfInt1 = this.n;
    int[] arrayOfInt2 = super.onCreateDrawableState(arrayOfInt1.length + paramInt);
    if (this.k) {
      paramInt = a.b.c.b.state_liftable;
    } else {
      paramInt = -a.b.c.b.state_liftable;
    } 
    arrayOfInt1[0] = paramInt;
    if (this.k && this.l) {
      paramInt = a.b.c.b.state_lifted;
    } else {
      paramInt = -a.b.c.b.state_lifted;
    } 
    arrayOfInt1[1] = paramInt;
    if (this.k) {
      paramInt = a.b.c.b.state_collapsible;
    } else {
      paramInt = -a.b.c.b.state_collapsible;
    } 
    arrayOfInt1[2] = paramInt;
    if (this.k && this.l) {
      paramInt = a.b.c.b.state_collapsed;
    } else {
      paramInt = -a.b.c.b.state_collapsed;
    } 
    arrayOfInt1[3] = paramInt;
    return LinearLayout.mergeDrawableStates(arrayOfInt2, arrayOfInt1);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    f();
    paramBoolean = false;
    this.f = false;
    paramInt1 = 0;
    paramInt2 = getChildCount();
    while (paramInt1 < paramInt2) {
      if (((c)getChildAt(paramInt1).getLayoutParams()).b() != null) {
        this.f = true;
        break;
      } 
      paramInt1++;
    } 
    if (!this.j) {
      if (this.m || e())
        paramBoolean = true; 
      b(paramBoolean);
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    f();
  }
  
  public void setExpanded(boolean paramBoolean) {
    a(paramBoolean, u.y((View)this));
  }
  
  public void setLiftOnScroll(boolean paramBoolean) {
    this.m = paramBoolean;
  }
  
  public void setOrientation(int paramInt) {
    if (paramInt == 1) {
      super.setOrientation(paramInt);
      return;
    } 
    throw new IllegalArgumentException("AppBarLayout is always vertical and does not support horizontal orientation");
  }
  
  @Deprecated
  public void setTargetElevation(float paramFloat) {
    if (Build.VERSION.SDK_INT >= 21)
      z.a((View)this, paramFloat); 
  }
  
  protected static class BaseBehavior<T extends AppBarLayout> extends n<T> {
    private int k;
    
    private int l;
    
    private ValueAnimator m;
    
    private int n = -1;
    
    private boolean o;
    
    private float p;
    
    private WeakReference<View> q;
    
    private b r;
    
    public BaseBehavior() {}
    
    public BaseBehavior(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    private static View a(AppBarLayout param1AppBarLayout, int param1Int) {
      int i = Math.abs(param1Int);
      param1Int = 0;
      int j = param1AppBarLayout.getChildCount();
      while (param1Int < j) {
        View view = param1AppBarLayout.getChildAt(param1Int);
        if (i >= view.getTop() && i <= view.getBottom())
          return view; 
        param1Int++;
      } 
      return null;
    }
    
    private View a(CoordinatorLayout param1CoordinatorLayout) {
      byte b1 = 0;
      int i = param1CoordinatorLayout.getChildCount();
      while (b1 < i) {
        View view = param1CoordinatorLayout.getChildAt(b1);
        if (view instanceof android.support.v4.view.k)
          return view; 
        b1++;
      } 
      return null;
    }
    
    private void a(int param1Int1, T param1T, View param1View, int param1Int2) {
      if (param1Int2 == 1) {
        param1Int2 = c();
        if ((param1Int1 < 0 && param1Int2 == 0) || (param1Int1 > 0 && param1Int2 == -param1T.getDownNestedScrollRange()))
          u.h(param1View, 1); 
      } 
    }
    
    private void a(CoordinatorLayout param1CoordinatorLayout, T param1T, int param1Int, float param1Float) {
      int i = Math.abs(c() - param1Int);
      param1Float = Math.abs(param1Float);
      if (param1Float > 0.0F) {
        i = Math.round(i / param1Float * 1000.0F) * 3;
      } else {
        i = (int)((1.0F + i / param1T.getHeight()) * 150.0F);
      } 
      a(param1CoordinatorLayout, param1T, param1Int, i);
    }
    
    private void a(CoordinatorLayout param1CoordinatorLayout, T param1T, int param1Int1, int param1Int2) {
      ValueAnimator valueAnimator1;
      int i = c();
      if (i == param1Int1) {
        valueAnimator1 = this.m;
        if (valueAnimator1 != null && valueAnimator1.isRunning())
          this.m.cancel(); 
        return;
      } 
      ValueAnimator valueAnimator2 = this.m;
      if (valueAnimator2 == null) {
        this.m = new ValueAnimator();
        this.m.setInterpolator(a.b.c.l.a.e);
        this.m.addUpdateListener(new a(this, (CoordinatorLayout)valueAnimator1, (AppBarLayout)param1T));
      } else {
        valueAnimator2.cancel();
      } 
      this.m.setDuration(Math.min(param1Int2, 600));
      this.m.setIntValues(new int[] { i, param1Int1 });
      this.m.start();
    }
    
    private void a(CoordinatorLayout param1CoordinatorLayout, T param1T, int param1Int1, int param1Int2, boolean param1Boolean) {
      View view = a((AppBarLayout)param1T, param1Int1);
      if (view != null) {
        int i = ((AppBarLayout.c)view.getLayoutParams()).a();
        boolean bool2 = false;
        boolean bool3 = false;
        boolean bool1 = bool2;
        if ((i & 0x1) != 0) {
          int j = u.l(view);
          if (param1Int2 > 0 && (i & 0xC) != 0) {
            if (-param1Int1 >= view.getBottom() - j - param1T.getTopInset()) {
              bool1 = true;
            } else {
              bool1 = false;
            } 
          } else {
            bool1 = bool2;
            if ((i & 0x2) != 0)
              if (-param1Int1 >= view.getBottom() - j - param1T.getTopInset()) {
                bool1 = true;
              } else {
                bool1 = false;
              }  
          } 
        } 
        bool2 = bool1;
        if (param1T.c()) {
          view = a(param1CoordinatorLayout);
          bool2 = bool1;
          if (view != null) {
            bool1 = bool3;
            if (view.getScrollY() > 0)
              bool1 = true; 
            bool2 = bool1;
          } 
        } 
        bool1 = param1T.a(bool2);
        if (Build.VERSION.SDK_INT >= 11 && (param1Boolean || (bool1 && c(param1CoordinatorLayout, param1T))))
          param1T.jumpDrawablesToCurrentState(); 
      } 
    }
    
    private static boolean a(int param1Int1, int param1Int2) {
      boolean bool;
      if ((param1Int1 & param1Int2) == param1Int2) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    private boolean a(CoordinatorLayout param1CoordinatorLayout, T param1T, View param1View) {
      boolean bool;
      if (param1T.b() && param1CoordinatorLayout.getHeight() - param1View.getHeight() <= param1T.getHeight()) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    private int b(T param1T, int param1Int) {
      byte b1 = 0;
      int i = param1T.getChildCount();
      while (b1 < i) {
        View view = param1T.getChildAt(b1);
        int i1 = view.getTop();
        int m = view.getBottom();
        AppBarLayout.c c = (AppBarLayout.c)view.getLayoutParams();
        int k = i1;
        int j = m;
        if (a(c.a(), 32)) {
          k = i1 - c.topMargin;
          j = m + c.bottomMargin;
        } 
        if (k <= -param1Int && j >= -param1Int)
          return b1; 
        b1++;
      } 
      return -1;
    }
    
    private int c(T param1T, int param1Int) {
      int k = Math.abs(param1Int);
      int i = 0;
      int j = param1T.getChildCount();
      while (i < j) {
        View view = param1T.getChildAt(i);
        AppBarLayout.c c = (AppBarLayout.c)view.getLayoutParams();
        Interpolator interpolator = c.b();
        if (k >= view.getTop() && k <= view.getBottom()) {
          if (interpolator != null) {
            i = 0;
            int m = c.a();
            if ((m & 0x1) != 0) {
              j = 0 + view.getHeight() + c.topMargin + c.bottomMargin;
              i = j;
              if ((m & 0x2) != 0)
                i = j - u.l(view); 
            } 
            j = i;
            if (u.h(view))
              j = i - param1T.getTopInset(); 
            if (j > 0) {
              i = view.getTop();
              i = Math.round(j * interpolator.getInterpolation((k - i) / j));
              return Integer.signum(param1Int) * (view.getTop() + i);
            } 
          } 
          break;
        } 
        i++;
      } 
      return param1Int;
    }
    
    private boolean c(CoordinatorLayout param1CoordinatorLayout, T param1T) {
      List<View> list = param1CoordinatorLayout.c((View)param1T);
      byte b1 = 0;
      int i = list.size();
      while (true) {
        boolean bool = false;
        if (b1 < i) {
          View view = list.get(b1);
          CoordinatorLayout.c c = ((CoordinatorLayout.f)view.getLayoutParams()).d();
          if (c instanceof AppBarLayout.ScrollingViewBehavior) {
            if (((AppBarLayout.ScrollingViewBehavior)c).c() != 0)
              bool = true; 
            return bool;
          } 
          b1++;
          continue;
        } 
        return false;
      } 
    }
    
    private void d(CoordinatorLayout param1CoordinatorLayout, T param1T) {
      int j = c();
      int i = b(param1T, j);
      if (i >= 0) {
        View view = param1T.getChildAt(i);
        AppBarLayout.c c = (AppBarLayout.c)view.getLayoutParams();
        int k = c.a();
        if ((k & 0x11) == 17) {
          int i2 = -view.getTop();
          int m = -view.getBottom();
          int i1 = m;
          if (i == param1T.getChildCount() - 1)
            i1 = m + param1T.getTopInset(); 
          if (a(k, 2)) {
            m = i1 + u.l(view);
            i = i2;
          } else {
            i = i2;
            m = i1;
            if (a(k, 5)) {
              m = u.l(view) + i1;
              if (j < m) {
                i = m;
                m = i1;
              } else {
                i = i2;
              } 
            } 
          } 
          i2 = i;
          i1 = m;
          if (a(k, 32)) {
            i2 = i + c.topMargin;
            i1 = m - c.bottomMargin;
          } 
          if (j >= (i1 + i2) / 2)
            i1 = i2; 
          a(param1CoordinatorLayout, param1T, a.b.g.c.a.a(i1, -param1T.getTotalScrollRange(), 0), 0.0F);
        } 
      } 
    }
    
    int a(CoordinatorLayout param1CoordinatorLayout, T param1T, int param1Int1, int param1Int2, int param1Int3) {
      int i = c();
      boolean bool = false;
      if (param1Int2 != 0 && i >= param1Int2 && i <= param1Int3) {
        param1Int2 = a.b.g.c.a.a(param1Int1, param1Int2, param1Int3);
        param1Int1 = bool;
        if (i != param1Int2) {
          if (param1T.a()) {
            param1Int1 = c(param1T, param1Int2);
          } else {
            param1Int1 = param1Int2;
          } 
          boolean bool1 = a(param1Int1);
          param1Int3 = i - param1Int2;
          this.k = param1Int2 - param1Int1;
          if (!bool1 && param1T.a())
            param1CoordinatorLayout.a((View)param1T); 
          param1T.a(b());
          if (param1Int2 < i) {
            param1Int1 = -1;
          } else {
            param1Int1 = 1;
          } 
          a(param1CoordinatorLayout, param1T, param1Int2, param1Int1, false);
          param1Int1 = param1Int3;
        } 
      } else {
        this.k = 0;
        param1Int1 = bool;
      } 
      return param1Int1;
    }
    
    void a(CoordinatorLayout param1CoordinatorLayout, T param1T) {
      d(param1CoordinatorLayout, param1T);
    }
    
    public void a(CoordinatorLayout param1CoordinatorLayout, T param1T, Parcelable param1Parcelable) {
      c c;
      if (param1Parcelable instanceof c) {
        c = (c)param1Parcelable;
        super.a(param1CoordinatorLayout, param1T, c.a());
        this.n = c.e;
        this.p = c.f;
        this.o = c.g;
      } else {
        super.a(param1CoordinatorLayout, param1T, (Parcelable)c);
        this.n = -1;
      } 
    }
    
    public void a(CoordinatorLayout param1CoordinatorLayout, T param1T, View param1View, int param1Int) {
      if (this.l == 0 || param1Int == 1)
        d(param1CoordinatorLayout, param1T); 
      this.q = new WeakReference<View>(param1View);
    }
    
    public void a(CoordinatorLayout param1CoordinatorLayout, T param1T, View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5) {
      if (param1Int4 < 0) {
        a(param1CoordinatorLayout, (V)param1T, param1Int4, -param1T.getDownNestedScrollRange(), 0);
        a(param1Int4, param1T, param1View, param1Int5);
      } 
      if (param1T.c()) {
        boolean bool;
        if (param1View.getScrollY() > 0) {
          bool = true;
        } else {
          bool = false;
        } 
        param1T.a(bool);
      } 
    }
    
    public void a(CoordinatorLayout param1CoordinatorLayout, T param1T, View param1View, int param1Int1, int param1Int2, int[] param1ArrayOfint, int param1Int3) {
      if (param1Int2 != 0) {
        int i;
        if (param1Int2 < 0) {
          i = -param1T.getTotalScrollRange();
          int j = param1T.getDownNestedPreScrollRange();
          param1Int1 = i;
          j += i;
          i = param1Int1;
          param1Int1 = j;
        } else {
          i = -param1T.getUpNestedPreScrollRange();
          param1Int1 = 0;
        } 
        if (i != param1Int1) {
          param1ArrayOfint[1] = a(param1CoordinatorLayout, (V)param1T, param1Int2, i, param1Int1);
          a(param1Int2, param1T, param1View, param1Int3);
        } 
      } 
    }
    
    boolean a(T param1T) {
      b<T> b1 = this.r;
      if (b1 != null)
        return b1.a(param1T); 
      WeakReference<View> weakReference = this.q;
      boolean bool = true;
      if (weakReference != null) {
        View view = weakReference.get();
        if (view == null || !view.isShown() || view.canScrollVertically(-1))
          bool = false; 
        return bool;
      } 
      return true;
    }
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, T param1T, int param1Int) {
      boolean bool = super.a(param1CoordinatorLayout, param1T, param1Int);
      int i = param1T.getPendingAction();
      param1Int = this.n;
      if (param1Int >= 0 && (i & 0x8) == 0) {
        View view = param1T.getChildAt(param1Int);
        param1Int = -view.getBottom();
        if (this.o) {
          param1Int += u.l(view) + param1T.getTopInset();
        } else {
          param1Int += Math.round(view.getHeight() * this.p);
        } 
        c(param1CoordinatorLayout, (V)param1T, param1Int);
      } else if (i != 0) {
        if ((i & 0x4) != 0) {
          param1Int = 1;
        } else {
          param1Int = 0;
        } 
        if ((i & 0x2) != 0) {
          i = -param1T.getUpNestedPreScrollRange();
          if (param1Int != 0) {
            a(param1CoordinatorLayout, param1T, i, 0.0F);
          } else {
            c(param1CoordinatorLayout, (V)param1T, i);
          } 
        } else if ((i & 0x1) != 0) {
          if (param1Int != 0) {
            a(param1CoordinatorLayout, param1T, 0, 0.0F);
          } else {
            c(param1CoordinatorLayout, (V)param1T, 0);
          } 
        } 
      } 
      param1T.d();
      this.n = -1;
      a(a.b.g.c.a.a(b(), -param1T.getTotalScrollRange(), 0));
      a(param1CoordinatorLayout, param1T, b(), 0, true);
      param1T.a(b());
      return bool;
    }
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, T param1T, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      if (((CoordinatorLayout.f)param1T.getLayoutParams()).height == -2) {
        param1CoordinatorLayout.a((View)param1T, param1Int1, param1Int2, View.MeasureSpec.makeMeasureSpec(0, 0), param1Int4);
        return true;
      } 
      return super.a(param1CoordinatorLayout, param1T, param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, T param1T, View param1View1, View param1View2, int param1Int1, int param1Int2) {
      boolean bool;
      if ((param1Int1 & 0x2) != 0 && (param1T.c() || a(param1CoordinatorLayout, param1T, param1View1))) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        ValueAnimator valueAnimator = this.m;
        if (valueAnimator != null)
          valueAnimator.cancel(); 
      } 
      this.q = null;
      this.l = param1Int2;
      return bool;
    }
    
    int b(T param1T) {
      return -param1T.getDownNestedScrollRange();
    }
    
    public Parcelable b(CoordinatorLayout param1CoordinatorLayout, T param1T) {
      c c;
      Parcelable parcelable = super.d(param1CoordinatorLayout, param1T);
      int i = b();
      byte b1 = 0;
      int j = param1T.getChildCount();
      while (b1 < j) {
        View view = param1T.getChildAt(b1);
        int k = view.getBottom() + i;
        if (view.getTop() + i <= 0 && k >= 0) {
          boolean bool;
          c = new c(parcelable);
          c.e = b1;
          if (k == u.l(view) + param1T.getTopInset()) {
            bool = true;
          } else {
            bool = false;
          } 
          c.g = bool;
          c.f = k / view.getHeight();
          return (Parcelable)c;
        } 
        b1++;
      } 
      return (Parcelable)c;
    }
    
    int c() {
      return b() + this.k;
    }
    
    int c(T param1T) {
      return param1T.getTotalScrollRange();
    }
    
    class a implements ValueAnimator.AnimatorUpdateListener {
      final CoordinatorLayout a;
      
      final AppBarLayout b;
      
      final AppBarLayout.BaseBehavior c;
      
      a(AppBarLayout.BaseBehavior this$0, CoordinatorLayout param2CoordinatorLayout, AppBarLayout param2AppBarLayout) {}
      
      public void onAnimationUpdate(ValueAnimator param2ValueAnimator) {
        this.c.c(this.a, this.b, ((Integer)param2ValueAnimator.getAnimatedValue()).intValue());
      }
    }
    
    public static abstract class b<T extends AppBarLayout> {
      public abstract boolean a(T param2T);
    }
    
    protected static class c extends android.support.v4.view.a {
      public static final Parcelable.Creator<c> CREATOR = (Parcelable.Creator<c>)new a();
      
      int e;
      
      float f;
      
      boolean g;
      
      public c(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        super(param2Parcel, param2ClassLoader);
        boolean bool;
        this.e = param2Parcel.readInt();
        this.f = param2Parcel.readFloat();
        if (param2Parcel.readByte() != 0) {
          bool = true;
        } else {
          bool = false;
        } 
        this.g = bool;
      }
      
      public c(Parcelable param2Parcelable) {
        super(param2Parcelable);
      }
      
      public void writeToParcel(Parcel param2Parcel, int param2Int) {
        super.writeToParcel(param2Parcel, param2Int);
        param2Parcel.writeInt(this.e);
        param2Parcel.writeFloat(this.f);
        param2Parcel.writeByte((byte)this.g);
      }
      
      static final class a implements Parcelable.ClassLoaderCreator<c> {
        public AppBarLayout.BaseBehavior.c createFromParcel(Parcel param3Parcel) {
          return new AppBarLayout.BaseBehavior.c(param3Parcel, null);
        }
        
        public AppBarLayout.BaseBehavior.c createFromParcel(Parcel param3Parcel, ClassLoader param3ClassLoader) {
          return new AppBarLayout.BaseBehavior.c(param3Parcel, param3ClassLoader);
        }
        
        public AppBarLayout.BaseBehavior.c[] newArray(int param3Int) {
          return new AppBarLayout.BaseBehavior.c[param3Int];
        }
      }
    }
    
    static final class a implements Parcelable.ClassLoaderCreator<c> {
      public AppBarLayout.BaseBehavior.c createFromParcel(Parcel param2Parcel) {
        return new AppBarLayout.BaseBehavior.c(param2Parcel, null);
      }
      
      public AppBarLayout.BaseBehavior.c createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new AppBarLayout.BaseBehavior.c(param2Parcel, param2ClassLoader);
      }
      
      public AppBarLayout.BaseBehavior.c[] newArray(int param2Int) {
        return new AppBarLayout.BaseBehavior.c[param2Int];
      }
    }
  }
  
  class a implements ValueAnimator.AnimatorUpdateListener {
    final CoordinatorLayout a;
    
    final AppBarLayout b;
    
    final AppBarLayout.BaseBehavior c;
    
    a(AppBarLayout this$0, CoordinatorLayout param1CoordinatorLayout, AppBarLayout param1AppBarLayout) {}
    
    public void onAnimationUpdate(ValueAnimator param1ValueAnimator) {
      this.c.c(this.a, this.b, ((Integer)param1ValueAnimator.getAnimatedValue()).intValue());
    }
  }
  
  public static abstract class b<T extends AppBarLayout> {
    public abstract boolean a(T param1T);
  }
  
  protected static class c extends android.support.v4.view.a {
    public static final Parcelable.Creator<c> CREATOR = (Parcelable.Creator<c>)new a();
    
    int e;
    
    float f;
    
    boolean g;
    
    public c(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      boolean bool;
      this.e = param1Parcel.readInt();
      this.f = param1Parcel.readFloat();
      if (param1Parcel.readByte() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.g = bool;
    }
    
    public c(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.e);
      param1Parcel.writeFloat(this.f);
      param1Parcel.writeByte((byte)this.g);
    }
    
    static final class a implements Parcelable.ClassLoaderCreator<c> {
      public AppBarLayout.BaseBehavior.c createFromParcel(Parcel param3Parcel) {
        return new AppBarLayout.BaseBehavior.c(param3Parcel, null);
      }
      
      public AppBarLayout.BaseBehavior.c createFromParcel(Parcel param3Parcel, ClassLoader param3ClassLoader) {
        return new AppBarLayout.BaseBehavior.c(param3Parcel, param3ClassLoader);
      }
      
      public AppBarLayout.BaseBehavior.c[] newArray(int param3Int) {
        return new AppBarLayout.BaseBehavior.c[param3Int];
      }
    }
  }
  
  static final class a implements Parcelable.ClassLoaderCreator<BaseBehavior.c> {
    public AppBarLayout.BaseBehavior.c createFromParcel(Parcel param1Parcel) {
      return new AppBarLayout.BaseBehavior.c(param1Parcel, null);
    }
    
    public AppBarLayout.BaseBehavior.c createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new AppBarLayout.BaseBehavior.c(param1Parcel, param1ClassLoader);
    }
    
    public AppBarLayout.BaseBehavior.c[] newArray(int param1Int) {
      return new AppBarLayout.BaseBehavior.c[param1Int];
    }
  }
  
  public static class Behavior extends BaseBehavior<AppBarLayout> {
    public Behavior() {}
    
    public Behavior(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
  }
  
  public static class ScrollingViewBehavior extends o {
    public ScrollingViewBehavior() {}
    
    public ScrollingViewBehavior(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, k.ScrollingViewBehavior_Layout);
      b(typedArray.getDimensionPixelSize(k.ScrollingViewBehavior_Layout_behavior_overlapTop, 0));
      typedArray.recycle();
    }
    
    private static int a(AppBarLayout param1AppBarLayout) {
      CoordinatorLayout.c c = ((CoordinatorLayout.f)param1AppBarLayout.getLayoutParams()).d();
      return (c instanceof AppBarLayout.BaseBehavior) ? ((AppBarLayout.BaseBehavior)c).c() : 0;
    }
    
    private void a(View param1View1, View param1View2) {
      CoordinatorLayout.c c = ((CoordinatorLayout.f)param1View2.getLayoutParams()).d();
      if (c instanceof AppBarLayout.BaseBehavior) {
        c = c;
        u.d(param1View1, param1View2.getBottom() - param1View1.getTop() + AppBarLayout.BaseBehavior.a((AppBarLayout.BaseBehavior)c) + d() - a(param1View2));
      } 
    }
    
    private void b(View param1View1, View param1View2) {
      if (param1View2 instanceof AppBarLayout) {
        AppBarLayout appBarLayout = (AppBarLayout)param1View2;
        if (appBarLayout.c()) {
          boolean bool;
          if (param1View1.getScrollY() > 0) {
            bool = true;
          } else {
            bool = false;
          } 
          appBarLayout.a(bool);
        } 
      } 
    }
    
    AppBarLayout a(List<View> param1List) {
      byte b = 0;
      int i = param1List.size();
      while (b < i) {
        View view = param1List.get(b);
        if (view instanceof AppBarLayout)
          return (AppBarLayout)view; 
        b++;
      } 
      return null;
    }
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, View param1View, Rect param1Rect, boolean param1Boolean) {
      AppBarLayout appBarLayout = a(param1CoordinatorLayout.b(param1View));
      if (appBarLayout != null) {
        param1Rect.offset(param1View.getLeft(), param1View.getTop());
        Rect rect = this.d;
        rect.set(0, 0, param1CoordinatorLayout.getWidth(), param1CoordinatorLayout.getHeight());
        if (!rect.contains(param1Rect)) {
          appBarLayout.a(false, param1Boolean ^ true);
          return true;
        } 
      } 
      return false;
    }
    
    public boolean a(CoordinatorLayout param1CoordinatorLayout, View param1View1, View param1View2) {
      return param1View2 instanceof AppBarLayout;
    }
    
    float b(View param1View) {
      if (param1View instanceof AppBarLayout) {
        AppBarLayout appBarLayout = (AppBarLayout)param1View;
        int k = appBarLayout.getTotalScrollRange();
        int j = appBarLayout.getDownNestedPreScrollRange();
        int i = a(appBarLayout);
        if (j != 0 && k + i <= j)
          return 0.0F; 
        j = k - j;
        if (j != 0)
          return i / j + 1.0F; 
      } 
      return 0.0F;
    }
    
    public boolean b(CoordinatorLayout param1CoordinatorLayout, View param1View1, View param1View2) {
      a(param1View1, param1View2);
      b(param1View1, param1View2);
      return false;
    }
    
    int c(View param1View) {
      return (param1View instanceof AppBarLayout) ? ((AppBarLayout)param1View).getTotalScrollRange() : super.c(param1View);
    }
  }
  
  class a implements p {
    final AppBarLayout a;
    
    a(AppBarLayout this$0) {}
    
    public c0 a(View param1View, c0 param1c0) {
      return this.a.a(param1c0);
    }
  }
  
  public static interface b<T extends AppBarLayout> {
    void a(T param1T, int param1Int);
  }
  
  public static class c extends LinearLayout.LayoutParams {
    int a = 1;
    
    Interpolator b;
    
    public c(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public c(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, k.AppBarLayout_Layout);
      this.a = typedArray.getInt(k.AppBarLayout_Layout_layout_scrollFlags, 0);
      if (typedArray.hasValue(k.AppBarLayout_Layout_layout_scrollInterpolator))
        this.b = AnimationUtils.loadInterpolator(param1Context, typedArray.getResourceId(k.AppBarLayout_Layout_layout_scrollInterpolator, 0)); 
      typedArray.recycle();
    }
    
    public c(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public c(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public c(LinearLayout.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public int a() {
      return this.a;
    }
    
    public Interpolator b() {
      return this.b;
    }
    
    boolean c() {
      int i = this.a;
      boolean bool = true;
      if ((i & 0x1) != 1 || (i & 0xA) == 0)
        bool = false; 
      return bool;
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\AppBarLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */