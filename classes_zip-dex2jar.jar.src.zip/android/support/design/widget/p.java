package android.support.design.widget;

import a.b.c.d;
import a.b.c.f;
import a.b.c.l.b;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.support.v4.view.u;
import android.support.v4.widget.Space;
import android.support.v7.widget.AppCompatTextView;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

final class p {
  private final Context a;
  
  private final TextInputLayout b;
  
  private LinearLayout c;
  
  private int d;
  
  private FrameLayout e;
  
  private int f;
  
  private Animator g;
  
  private final float h;
  
  private int i;
  
  private int j;
  
  private CharSequence k;
  
  private boolean l;
  
  private TextView m;
  
  private int n;
  
  private CharSequence o;
  
  private boolean p;
  
  private TextView q;
  
  private int r;
  
  private Typeface s;
  
  public p(TextInputLayout paramTextInputLayout) {
    this.a = paramTextInputLayout.getContext();
    this.b = paramTextInputLayout;
    this.h = this.a.getResources().getDimensionPixelSize(d.design_textinput_caption_translate_y);
  }
  
  private ObjectAnimator a(TextView paramTextView) {
    ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(paramTextView, View.TRANSLATION_Y, new float[] { -this.h, 0.0F });
    objectAnimator.setDuration(217L);
    objectAnimator.setInterpolator(a.b.c.l.a.d);
    return objectAnimator;
  }
  
  private ObjectAnimator a(TextView paramTextView, boolean paramBoolean) {
    float f;
    if (paramBoolean) {
      f = 1.0F;
    } else {
      f = 0.0F;
    } 
    ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(paramTextView, View.ALPHA, new float[] { f });
    objectAnimator.setDuration(167L);
    objectAnimator.setInterpolator(a.b.c.l.a.a);
    return objectAnimator;
  }
  
  private void a(int paramInt1, int paramInt2) {
    if (paramInt1 == paramInt2)
      return; 
    if (paramInt2 != 0) {
      TextView textView = d(paramInt2);
      if (textView != null) {
        textView.setVisibility(0);
        textView.setAlpha(1.0F);
      } 
    } 
    if (paramInt1 != 0) {
      TextView textView = d(paramInt1);
      if (textView != null) {
        textView.setVisibility(4);
        if (paramInt1 == 1)
          textView.setText(null); 
      } 
    } 
    this.i = paramInt2;
  }
  
  private void a(int paramInt1, int paramInt2, boolean paramBoolean) {
    if (paramBoolean) {
      AnimatorSet animatorSet = new AnimatorSet();
      this.g = (Animator)animatorSet;
      ArrayList<Animator> arrayList = new ArrayList();
      a(arrayList, this.p, this.q, 2, paramInt1, paramInt2);
      a(arrayList, this.l, this.m, 1, paramInt1, paramInt2);
      b.a(animatorSet, arrayList);
      animatorSet.addListener((Animator.AnimatorListener)new a(this, paramInt2, d(paramInt1), paramInt1, d(paramInt2)));
      animatorSet.start();
    } else {
      a(paramInt1, paramInt2);
    } 
    this.b.c();
    this.b.b(paramBoolean);
    this.b.d();
  }
  
  private void a(ViewGroup paramViewGroup, int paramInt) {
    if (paramInt == 0)
      paramViewGroup.setVisibility(8); 
  }
  
  private void a(TextView paramTextView, Typeface paramTypeface) {
    if (paramTextView != null)
      paramTextView.setTypeface(paramTypeface); 
  }
  
  private void a(List<Animator> paramList, boolean paramBoolean, TextView paramTextView, int paramInt1, int paramInt2, int paramInt3) {
    if (paramTextView == null || !paramBoolean)
      return; 
    if (paramInt1 == paramInt3 || paramInt1 == paramInt2) {
      if (paramInt3 == paramInt1) {
        paramBoolean = true;
      } else {
        paramBoolean = false;
      } 
      paramList.add(a(paramTextView, paramBoolean));
      if (paramInt3 == paramInt1)
        paramList.add(a(paramTextView)); 
    } 
  }
  
  private boolean a(TextView paramTextView, CharSequence paramCharSequence) {
    boolean bool;
    if (u.y((View)this.b) && this.b.isEnabled() && (this.j != this.i || paramTextView == null || !TextUtils.equals(paramTextView.getText(), paramCharSequence))) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private TextView d(int paramInt) {
    return (paramInt != 1) ? ((paramInt != 2) ? null : this.q) : this.m;
  }
  
  private boolean e(int paramInt) {
    boolean bool = true;
    if (paramInt != 1 || this.m == null || TextUtils.isEmpty(this.k))
      bool = false; 
    return bool;
  }
  
  private boolean m() {
    boolean bool;
    if (this.c != null && this.b.getEditText() != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  void a() {
    if (m())
      u.a((View)this.c, u.o((View)this.b.getEditText()), 0, u.n((View)this.b.getEditText()), 0); 
  }
  
  void a(ColorStateList paramColorStateList) {
    TextView textView = this.m;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  void a(Typeface paramTypeface) {
    if (paramTypeface != this.s) {
      this.s = paramTypeface;
      a(this.m, paramTypeface);
      a(this.q, paramTypeface);
    } 
  }
  
  void a(TextView paramTextView, int paramInt) {
    if (this.c == null && this.e == null) {
      this.c = new LinearLayout(this.a);
      this.c.setOrientation(0);
      this.b.addView((View)this.c, -1, -2);
      this.e = new FrameLayout(this.a);
      this.c.addView((View)this.e, -1, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-2, -2));
      Space space = new Space(this.a);
      LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, 0, 1.0F);
      this.c.addView((View)space, (ViewGroup.LayoutParams)layoutParams);
      if (this.b.getEditText() != null)
        a(); 
    } 
    if (a(paramInt)) {
      this.e.setVisibility(0);
      this.e.addView((View)paramTextView);
      this.f++;
    } else {
      this.c.addView((View)paramTextView, paramInt);
    } 
    this.c.setVisibility(0);
    this.d++;
  }
  
  void a(CharSequence paramCharSequence) {
    b();
    this.k = paramCharSequence;
    this.m.setText(paramCharSequence);
    if (this.i != 1)
      this.j = 1; 
    a(this.i, this.j, a(this.m, paramCharSequence));
  }
  
  void a(boolean paramBoolean) {
    if (this.l == paramBoolean)
      return; 
    b();
    if (paramBoolean) {
      this.m = (TextView)new AppCompatTextView(this.a);
      this.m.setId(f.textinput_error);
      Typeface typeface = this.s;
      if (typeface != null)
        this.m.setTypeface(typeface); 
      b(this.n);
      this.m.setVisibility(4);
      u.e((View)this.m, 1);
      a(this.m, 0);
    } else {
      i();
      b(this.m, 0);
      this.m = null;
      this.b.c();
      this.b.d();
    } 
    this.l = paramBoolean;
  }
  
  boolean a(int paramInt) {
    boolean bool2 = true;
    boolean bool1 = bool2;
    if (paramInt != 0)
      if (paramInt == 1) {
        bool1 = bool2;
      } else {
        bool1 = false;
      }  
    return bool1;
  }
  
  void b() {
    Animator animator = this.g;
    if (animator != null)
      animator.cancel(); 
  }
  
  void b(int paramInt) {
    this.n = paramInt;
    TextView textView = this.m;
    if (textView != null)
      this.b.a(textView, paramInt); 
  }
  
  void b(ColorStateList paramColorStateList) {
    TextView textView = this.q;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  void b(TextView paramTextView, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Landroid/widget/LinearLayout;
    //   4: ifnonnull -> 8
    //   7: return
    //   8: aload_0
    //   9: iload_2
    //   10: invokevirtual a : (I)Z
    //   13: ifeq -> 55
    //   16: aload_0
    //   17: getfield e : Landroid/widget/FrameLayout;
    //   20: astore_3
    //   21: aload_3
    //   22: ifnull -> 55
    //   25: aload_0
    //   26: aload_0
    //   27: getfield f : I
    //   30: iconst_1
    //   31: isub
    //   32: putfield f : I
    //   35: aload_0
    //   36: aload_3
    //   37: aload_0
    //   38: getfield f : I
    //   41: invokespecial a : (Landroid/view/ViewGroup;I)V
    //   44: aload_0
    //   45: getfield e : Landroid/widget/FrameLayout;
    //   48: aload_1
    //   49: invokevirtual removeView : (Landroid/view/View;)V
    //   52: goto -> 63
    //   55: aload_0
    //   56: getfield c : Landroid/widget/LinearLayout;
    //   59: aload_1
    //   60: invokevirtual removeView : (Landroid/view/View;)V
    //   63: aload_0
    //   64: aload_0
    //   65: getfield d : I
    //   68: iconst_1
    //   69: isub
    //   70: putfield d : I
    //   73: aload_0
    //   74: aload_0
    //   75: getfield c : Landroid/widget/LinearLayout;
    //   78: aload_0
    //   79: getfield d : I
    //   82: invokespecial a : (Landroid/view/ViewGroup;I)V
    //   85: return
  }
  
  void b(CharSequence paramCharSequence) {
    b();
    this.o = paramCharSequence;
    this.q.setText(paramCharSequence);
    if (this.i != 2)
      this.j = 2; 
    a(this.i, this.j, a(this.q, paramCharSequence));
  }
  
  void b(boolean paramBoolean) {
    if (this.p == paramBoolean)
      return; 
    b();
    if (paramBoolean) {
      this.q = (TextView)new AppCompatTextView(this.a);
      this.q.setId(f.textinput_helper_text);
      Typeface typeface = this.s;
      if (typeface != null)
        this.q.setTypeface(typeface); 
      this.q.setVisibility(4);
      u.e((View)this.q, 1);
      c(this.r);
      a(this.q, 1);
    } else {
      j();
      b(this.q, 1);
      this.q = null;
      this.b.c();
      this.b.d();
    } 
    this.p = paramBoolean;
  }
  
  void c(int paramInt) {
    this.r = paramInt;
    TextView textView = this.q;
    if (textView != null)
      android.support.v4.widget.p.d(textView, paramInt); 
  }
  
  boolean c() {
    return e(this.j);
  }
  
  CharSequence d() {
    return this.k;
  }
  
  int e() {
    byte b;
    TextView textView = this.m;
    if (textView != null) {
      b = textView.getCurrentTextColor();
    } else {
      b = -1;
    } 
    return b;
  }
  
  ColorStateList f() {
    TextView textView = this.m;
    if (textView != null) {
      ColorStateList colorStateList = textView.getTextColors();
    } else {
      textView = null;
    } 
    return (ColorStateList)textView;
  }
  
  CharSequence g() {
    return this.o;
  }
  
  int h() {
    byte b;
    TextView textView = this.q;
    if (textView != null) {
      b = textView.getCurrentTextColor();
    } else {
      b = -1;
    } 
    return b;
  }
  
  void i() {
    this.k = null;
    b();
    if (this.i == 1)
      if (this.p && !TextUtils.isEmpty(this.o)) {
        this.j = 2;
      } else {
        this.j = 0;
      }  
    a(this.i, this.j, a(this.m, (CharSequence)null));
  }
  
  void j() {
    b();
    if (this.i == 2)
      this.j = 0; 
    a(this.i, this.j, a(this.q, (CharSequence)null));
  }
  
  boolean k() {
    return this.l;
  }
  
  boolean l() {
    return this.p;
  }
  
  class a extends AnimatorListenerAdapter {
    final int a;
    
    final TextView b;
    
    final int c;
    
    final TextView d;
    
    final p e;
    
    a(p this$0, int param1Int1, TextView param1TextView1, int param1Int2, TextView param1TextView2) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      p.a(this.e, this.a);
      p.a(this.e, (Animator)null);
      TextView textView = this.b;
      if (textView != null) {
        textView.setVisibility(4);
        if (this.c == 1 && p.a(this.e) != null)
          p.a(this.e).setText(null); 
      } 
    }
    
    public void onAnimationStart(Animator param1Animator) {
      TextView textView = this.d;
      if (textView != null)
        textView.setVisibility(0); 
    }
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */