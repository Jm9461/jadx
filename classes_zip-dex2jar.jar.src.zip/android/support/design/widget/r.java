package android.support.design.widget;

import a.b.c.c;
import a.b.h.d.a.c;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.support.v4.content.a;

public class r extends c {
  static final double s = Math.cos(Math.toRadians(45.0D));
  
  final Paint d;
  
  final Paint e;
  
  final RectF f;
  
  float g;
  
  Path h;
  
  float i;
  
  float j;
  
  float k;
  
  private boolean l = true;
  
  private final int m;
  
  private final int n;
  
  private final int o;
  
  private boolean p = true;
  
  private float q;
  
  private boolean r = false;
  
  public r(Context paramContext, Drawable paramDrawable, float paramFloat1, float paramFloat2, float paramFloat3) {
    super(paramDrawable);
    this.m = a.a(paramContext, c.design_fab_shadow_start_color);
    this.n = a.a(paramContext, c.design_fab_shadow_mid_color);
    this.o = a.a(paramContext, c.design_fab_shadow_end_color);
    this.d = new Paint(5);
    this.d.setStyle(Paint.Style.FILL);
    this.g = Math.round(paramFloat1);
    this.f = new RectF();
    this.e = new Paint(this.d);
    this.e.setAntiAlias(false);
    a(paramFloat2, paramFloat3);
  }
  
  public static float a(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    if (paramBoolean) {
      double d1 = paramFloat1;
      double d3 = s;
      double d2 = paramFloat2;
      Double.isNaN(d2);
      Double.isNaN(d1);
      return (float)(d1 + (1.0D - d3) * d2);
    } 
    return paramFloat1;
  }
  
  private void a(Canvas paramCanvas) {
    int j = paramCanvas.save();
    paramCanvas.rotate(this.q, this.f.centerX(), this.f.centerY());
    float f1 = -this.g - this.j;
    float f2 = this.g;
    float f3 = this.f.width();
    boolean bool = true;
    if (f3 - f2 * 2.0F > 0.0F) {
      i = 1;
    } else {
      i = 0;
    } 
    if (this.f.height() - f2 * 2.0F <= 0.0F)
      bool = false; 
    float f5 = this.k;
    f3 = f2 / (f2 + f5 - 0.5F * f5);
    float f4 = f2 / (f2 + f5 - 0.25F * f5);
    f5 = f2 / (f2 + f5 - f5 * 1.0F);
    int k = paramCanvas.save();
    RectF rectF = this.f;
    paramCanvas.translate(rectF.left + f2, rectF.top + f2);
    paramCanvas.scale(f3, f4);
    paramCanvas.drawPath(this.h, this.d);
    if (i) {
      paramCanvas.scale(1.0F / f3, 1.0F);
      paramCanvas.drawRect(0.0F, f1, this.f.width() - f2 * 2.0F, -this.g, this.e);
    } 
    paramCanvas.restoreToCount(k);
    k = paramCanvas.save();
    rectF = this.f;
    paramCanvas.translate(rectF.right - f2, rectF.bottom - f2);
    paramCanvas.scale(f3, f5);
    paramCanvas.rotate(180.0F);
    paramCanvas.drawPath(this.h, this.d);
    if (i) {
      paramCanvas.scale(1.0F / f3, 1.0F);
      paramCanvas.drawRect(0.0F, f1, this.f.width() - f2 * 2.0F, -this.g + this.j, this.e);
    } 
    paramCanvas.restoreToCount(k);
    int i = paramCanvas.save();
    rectF = this.f;
    paramCanvas.translate(rectF.left + f2, rectF.bottom - f2);
    paramCanvas.scale(f3, f5);
    paramCanvas.rotate(270.0F);
    paramCanvas.drawPath(this.h, this.d);
    if (bool) {
      paramCanvas.scale(1.0F / f5, 1.0F);
      paramCanvas.drawRect(0.0F, f1, this.f.height() - f2 * 2.0F, -this.g, this.e);
    } 
    paramCanvas.restoreToCount(i);
    i = paramCanvas.save();
    rectF = this.f;
    paramCanvas.translate(rectF.right - f2, rectF.top + f2);
    paramCanvas.scale(f3, f4);
    paramCanvas.rotate(90.0F);
    paramCanvas.drawPath(this.h, this.d);
    if (bool) {
      paramCanvas.scale(1.0F / f4, 1.0F);
      paramCanvas.drawRect(0.0F, f1, this.f.height() - 2.0F * f2, -this.g, this.e);
    } 
    paramCanvas.restoreToCount(i);
    paramCanvas.restoreToCount(j);
  }
  
  private void a(Rect paramRect) {
    float f1 = this.i;
    float f2 = 1.5F * f1;
    this.f.set(paramRect.left + f1, paramRect.top + f2, paramRect.right - f1, paramRect.bottom - f2);
    Drawable drawable = a();
    RectF rectF = this.f;
    drawable.setBounds((int)rectF.left, (int)rectF.top, (int)rectF.right, (int)rectF.bottom);
    c();
  }
  
  public static float b(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    if (paramBoolean) {
      double d2 = (1.5F * paramFloat1);
      double d3 = s;
      double d1 = paramFloat2;
      Double.isNaN(d1);
      Double.isNaN(d2);
      return (float)(d2 + (1.0D - d3) * d1);
    } 
    return 1.5F * paramFloat1;
  }
  
  private static int c(float paramFloat) {
    int i = Math.round(paramFloat);
    if (i % 2 == 1)
      i--; 
    return i;
  }
  
  private void c() {
    float f1 = this.g;
    RectF rectF2 = new RectF(-f1, -f1, f1, f1);
    RectF rectF1 = new RectF(rectF2);
    f1 = this.j;
    rectF1.inset(-f1, -f1);
    Path path = this.h;
    if (path == null) {
      this.h = new Path();
    } else {
      path.reset();
    } 
    this.h.setFillType(Path.FillType.EVEN_ODD);
    this.h.moveTo(-this.g, 0.0F);
    this.h.rLineTo(-this.j, 0.0F);
    this.h.arcTo(rectF1, 180.0F, 90.0F, false);
    this.h.arcTo(rectF2, 270.0F, -90.0F, false);
    this.h.close();
    float f3 = -rectF1.top;
    if (f3 > 0.0F) {
      float f = this.g / f3;
      f1 = (1.0F - f) / 2.0F;
      Paint paint1 = this.d;
      int m = this.m;
      int n = this.n;
      int i1 = this.o;
      Shader.TileMode tileMode1 = Shader.TileMode.CLAMP;
      paint1.setShader((Shader)new RadialGradient(0.0F, 0.0F, f3, new int[] { 0, m, n, i1 }, new float[] { 0.0F, f, f + f1, 1.0F }, tileMode1));
    } 
    Paint paint = this.e;
    float f2 = rectF2.top;
    f1 = rectF1.top;
    int k = this.m;
    int i = this.n;
    int j = this.o;
    Shader.TileMode tileMode = Shader.TileMode.CLAMP;
    paint.setShader((Shader)new LinearGradient(0.0F, f2, 0.0F, f1, new int[] { k, i, j }, new float[] { 0.0F, 0.5F, 1.0F }, tileMode));
    this.e.setAntiAlias(false);
  }
  
  public final void a(float paramFloat) {
    if (this.q != paramFloat) {
      this.q = paramFloat;
      invalidateSelf();
    } 
  }
  
  public void a(float paramFloat1, float paramFloat2) {
    if (paramFloat1 >= 0.0F && paramFloat2 >= 0.0F) {
      float f2 = c(paramFloat1);
      float f1 = c(paramFloat2);
      paramFloat1 = f2;
      if (f2 > f1) {
        paramFloat2 = f1;
        paramFloat1 = paramFloat2;
        if (!this.r) {
          this.r = true;
          paramFloat1 = paramFloat2;
        } 
      } 
      if (this.k == paramFloat1 && this.i == f1)
        return; 
      this.k = paramFloat1;
      this.i = f1;
      this.j = Math.round(1.5F * paramFloat1);
      this.l = true;
      invalidateSelf();
      return;
    } 
    throw new IllegalArgumentException("invalid shadow size");
  }
  
  public void a(boolean paramBoolean) {
    this.p = paramBoolean;
    invalidateSelf();
  }
  
  public float b() {
    return this.k;
  }
  
  public void b(float paramFloat) {
    a(paramFloat, this.i);
  }
  
  public void draw(Canvas paramCanvas) {
    if (this.l) {
      a(getBounds());
      this.l = false;
    } 
    a(paramCanvas);
    super.draw(paramCanvas);
  }
  
  public int getOpacity() {
    return -3;
  }
  
  public boolean getPadding(Rect paramRect) {
    int i = (int)Math.ceil(b(this.i, this.g, this.p));
    int j = (int)Math.ceil(a(this.i, this.g, this.p));
    paramRect.set(j, i, j, i);
    return true;
  }
  
  protected void onBoundsChange(Rect paramRect) {
    this.l = true;
  }
  
  public void setAlpha(int paramInt) {
    super.setAlpha(paramInt);
    this.d.setAlpha(paramInt);
    this.e.setAlpha(paramInt);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */