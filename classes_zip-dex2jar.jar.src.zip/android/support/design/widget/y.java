package android.support.design.widget;

import android.support.v4.view.u;
import android.view.View;

class y {
  private final View a;
  
  private int b;
  
  private int c;
  
  private int d;
  
  private int e;
  
  public y(View paramView) {
    this.a = paramView;
  }
  
  private void c() {
    View view = this.a;
    u.d(view, this.d - view.getTop() - this.b);
    view = this.a;
    u.c(view, this.e - view.getLeft() - this.c);
  }
  
  public int a() {
    return this.d;
  }
  
  public boolean a(int paramInt) {
    if (this.e != paramInt) {
      this.e = paramInt;
      c();
      return true;
    } 
    return false;
  }
  
  public void b() {
    this.b = this.a.getTop();
    this.c = this.a.getLeft();
    c();
  }
  
  public boolean b(int paramInt) {
    if (this.d != paramInt) {
      this.d = paramInt;
      c();
      return true;
    } 
    return false;
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */