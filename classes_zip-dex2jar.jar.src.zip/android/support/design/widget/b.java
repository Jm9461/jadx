package android.support.design.widget;

import android.view.View;

public interface b {
  void onViewAttachedToWindow(View paramView);
  
  void onViewDetachedFromWindow(View paramView);
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */