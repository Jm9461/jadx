package android.support.design.widget;

import android.graphics.drawable.Drawable;
import android.view.View;

public class v extends View {
  public final CharSequence c;
  
  public final Drawable d;
  
  public final int e;
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */