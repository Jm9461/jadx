package android.support.design.widget;

import a.b.c.k;
import a.b.g.g.k;
import a.b.g.g.l;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.e;
import android.support.v4.view.q;
import android.support.v4.view.r;
import android.support.v4.view.u;
import android.support.v4.widget.p;
import android.support.v7.widget.l1;
import android.text.Layout;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;

@e
public class TabLayout extends HorizontalScrollView {
  private static final a.b.g.g.j<g> Q = (a.b.g.g.j<g>)new l(16);
  
  int A;
  
  int B;
  
  boolean C;
  
  boolean D;
  
  boolean E;
  
  private c F;
  
  private final ArrayList<c> G = new ArrayList<c>();
  
  private c H;
  
  private ValueAnimator I;
  
  ViewPager J;
  
  private q K;
  
  private DataSetObserver L;
  
  private h M;
  
  private b N;
  
  private boolean O;
  
  private final a.b.g.g.j<i> P = (a.b.g.g.j<i>)new k(12);
  
  private final ArrayList<g> c = new ArrayList<g>();
  
  private g d;
  
  private final RectF e = new RectF();
  
  private final f f;
  
  int g;
  
  int h;
  
  int i;
  
  int j;
  
  int k;
  
  ColorStateList l;
  
  ColorStateList m;
  
  ColorStateList n;
  
  Drawable o;
  
  PorterDuff.Mode p;
  
  float q;
  
  float r;
  
  final int s;
  
  int t = Integer.MAX_VALUE;
  
  private final int u;
  
  private final int v;
  
  private final int w;
  
  private int x;
  
  int y;
  
  int z;
  
  public TabLayout(Context paramContext) {
    this(paramContext, null);
  }
  
  public TabLayout(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.b.c.b.tabStyle);
  }
  
  public TabLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    setHorizontalScrollBarEnabled(false);
    this.f = new f(this, paramContext);
    super.addView((View)this.f, 0, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-2, -1));
    TypedArray typedArray2 = android.support.design.internal.g.c(paramContext, paramAttributeSet, k.TabLayout, paramInt, a.b.c.j.Widget_Design_TabLayout, new int[] { k.TabLayout_tabTextAppearance });
    this.f.b(typedArray2.getDimensionPixelSize(k.TabLayout_tabIndicatorHeight, -1));
    this.f.a(typedArray2.getColor(k.TabLayout_tabIndicatorColor, 0));
    setSelectedTabIndicator(a.b.c.p.a.b(paramContext, typedArray2, k.TabLayout_tabIndicator));
    setSelectedTabIndicatorGravity(typedArray2.getInt(k.TabLayout_tabIndicatorGravity, 0));
    setTabIndicatorFullWidth(typedArray2.getBoolean(k.TabLayout_tabIndicatorFullWidth, true));
    paramInt = typedArray2.getDimensionPixelSize(k.TabLayout_tabPadding, 0);
    this.j = paramInt;
    this.i = paramInt;
    this.h = paramInt;
    this.g = paramInt;
    this.g = typedArray2.getDimensionPixelSize(k.TabLayout_tabPaddingStart, this.g);
    this.h = typedArray2.getDimensionPixelSize(k.TabLayout_tabPaddingTop, this.h);
    this.i = typedArray2.getDimensionPixelSize(k.TabLayout_tabPaddingEnd, this.i);
    this.j = typedArray2.getDimensionPixelSize(k.TabLayout_tabPaddingBottom, this.j);
    this.k = typedArray2.getResourceId(k.TabLayout_tabTextAppearance, a.b.c.j.TextAppearance_Design_Tab);
    TypedArray typedArray1 = paramContext.obtainStyledAttributes(this.k, a.b.h.a.j.TextAppearance);
    try {
      this.q = typedArray1.getDimensionPixelSize(a.b.h.a.j.TextAppearance_android_textSize, 0);
      this.l = a.b.c.p.a.a(paramContext, typedArray1, a.b.h.a.j.TextAppearance_android_textColor);
      typedArray1.recycle();
      if (typedArray2.hasValue(k.TabLayout_tabTextColor))
        this.l = a.b.c.p.a.a(paramContext, typedArray2, k.TabLayout_tabTextColor); 
      if (typedArray2.hasValue(k.TabLayout_tabSelectedTextColor)) {
        paramInt = typedArray2.getColor(k.TabLayout_tabSelectedTextColor, 0);
        this.l = a(this.l.getDefaultColor(), paramInt);
      } 
      this.m = a.b.c.p.a.a(paramContext, typedArray2, k.TabLayout_tabIconTint);
      this.p = android.support.design.internal.h.a(typedArray2.getInt(k.TabLayout_tabIconTintMode, -1), null);
      this.n = a.b.c.p.a.a(paramContext, typedArray2, k.TabLayout_tabRippleColor);
      this.z = typedArray2.getInt(k.TabLayout_tabIndicatorAnimationDuration, 300);
      this.u = typedArray2.getDimensionPixelSize(k.TabLayout_tabMinWidth, -1);
      this.v = typedArray2.getDimensionPixelSize(k.TabLayout_tabMaxWidth, -1);
      this.s = typedArray2.getResourceId(k.TabLayout_tabBackground, 0);
      this.x = typedArray2.getDimensionPixelSize(k.TabLayout_tabContentStart, 0);
      this.B = typedArray2.getInt(k.TabLayout_tabMode, 1);
      this.y = typedArray2.getInt(k.TabLayout_tabGravity, 0);
      this.C = typedArray2.getBoolean(k.TabLayout_tabInlineLabel, false);
      this.E = typedArray2.getBoolean(k.TabLayout_tabUnboundedRipple, false);
      typedArray2.recycle();
      Resources resources = getResources();
      this.r = resources.getDimensionPixelSize(a.b.c.d.design_tab_text_size_2line);
      this.w = resources.getDimensionPixelSize(a.b.c.d.design_tab_scrollable_min_width);
      return;
    } finally {
      typedArray1.recycle();
    } 
  }
  
  private int a(int paramInt, float paramFloat) {
    int k = this.B;
    int i = 0;
    if (k == 0) {
      View view1;
      View view2 = this.f.getChildAt(paramInt);
      if (paramInt + 1 < this.f.getChildCount()) {
        view1 = this.f.getChildAt(paramInt + 1);
      } else {
        view1 = null;
      } 
      if (view2 != null) {
        paramInt = view2.getWidth();
      } else {
        paramInt = 0;
      } 
      if (view1 != null)
        i = view1.getWidth(); 
      k = view2.getLeft() + paramInt / 2 - getWidth() / 2;
      paramInt = (int)((paramInt + i) * 0.5F * paramFloat);
      if (u.k((View)this) == 0) {
        paramInt = k + paramInt;
      } else {
        paramInt = k - paramInt;
      } 
      return paramInt;
    } 
    return 0;
  }
  
  private static ColorStateList a(int paramInt1, int paramInt2) {
    int[][] arrayOfInt1 = new int[2][];
    int[] arrayOfInt = new int[2];
    arrayOfInt1[0] = HorizontalScrollView.SELECTED_STATE_SET;
    arrayOfInt[0] = paramInt2;
    paramInt2 = 0 + 1;
    arrayOfInt1[paramInt2] = HorizontalScrollView.EMPTY_STATE_SET;
    arrayOfInt[paramInt2] = paramInt1;
    return new ColorStateList(arrayOfInt1, arrayOfInt);
  }
  
  private void a(g paramg, int paramInt) {
    paramg.b(paramInt);
    this.c.add(paramInt, paramg);
    int i = this.c.size();
    while (++paramInt < i) {
      ((g)this.c.get(paramInt)).b(paramInt);
      paramInt++;
    } 
  }
  
  private void a(v paramv) {
    g g1 = b();
    CharSequence charSequence = paramv.c;
    if (charSequence != null)
      g1.b(charSequence); 
    Drawable drawable = paramv.d;
    if (drawable != null)
      g1.a(drawable); 
    int i = paramv.e;
    if (i != 0)
      g1.a(i); 
    if (!TextUtils.isEmpty(paramv.getContentDescription()))
      g1.a(paramv.getContentDescription()); 
    a(g1);
  }
  
  private void a(ViewPager paramViewPager, boolean paramBoolean1, boolean paramBoolean2) {
    ViewPager viewPager = this.J;
    if (viewPager != null) {
      h h1 = this.M;
      if (h1 != null)
        viewPager.b(h1); 
      b b1 = this.N;
      if (b1 != null)
        this.J.b(b1); 
    } 
    c c1 = this.H;
    if (c1 != null) {
      b(c1);
      this.H = null;
    } 
    if (paramViewPager != null) {
      this.J = paramViewPager;
      if (this.M == null)
        this.M = new h(this); 
      this.M.a();
      paramViewPager.a(this.M);
      this.H = new j(paramViewPager);
      a(this.H);
      q q1 = paramViewPager.getAdapter();
      if (q1 != null)
        a(q1, paramBoolean1); 
      if (this.N == null)
        this.N = new b(this); 
      this.N.a(paramBoolean1);
      paramViewPager.a(this.N);
      a(paramViewPager.getCurrentItem(), 0.0F, true);
    } else {
      this.J = null;
      a((q)null, false);
    } 
    this.O = paramBoolean2;
  }
  
  private void a(View paramView) {
    if (paramView instanceof v) {
      a((v)paramView);
      return;
    } 
    throw new IllegalArgumentException("Only TabItem instances can be added to TabLayout");
  }
  
  private void a(LinearLayout.LayoutParams paramLayoutParams) {
    if (this.B == 1 && this.y == 0) {
      paramLayoutParams.width = 0;
      paramLayoutParams.weight = 1.0F;
    } else {
      paramLayoutParams.width = -2;
      paramLayoutParams.weight = 0.0F;
    } 
  }
  
  private void c(int paramInt) {
    if (paramInt == -1)
      return; 
    if (getWindowToken() == null || !u.y((View)this) || this.f.a()) {
      a(paramInt, 0.0F, true);
      return;
    } 
    int i = getScrollX();
    int k = a(paramInt, 0.0F);
    if (i != k) {
      g();
      this.I.setIntValues(new int[] { i, k });
      this.I.start();
    } 
    this.f.a(paramInt, this.z);
  }
  
  private void d(int paramInt) {
    i i = (i)this.f.getChildAt(paramInt);
    this.f.removeViewAt(paramInt);
    if (i != null) {
      i.a();
      this.P.a(i);
    } 
    requestLayout();
  }
  
  private void d(g paramg) {
    i i = paramg.g;
    this.f.addView((View)i, paramg.c(), (ViewGroup.LayoutParams)f());
  }
  
  private i e(g paramg) {
    i i;
    a.b.g.g.j<i> j1 = this.P;
    if (j1 != null) {
      i i1 = (i)j1.a();
    } else {
      j1 = null;
    } 
    a.b.g.g.j<i> j2 = j1;
    if (j1 == null)
      i = new i(this, getContext()); 
    i.a(paramg);
    i.setFocusable(true);
    i.setMinimumWidth(getTabMinWidth());
    if (TextUtils.isEmpty(g.a(paramg))) {
      i.setContentDescription(g.b(paramg));
    } else {
      i.setContentDescription(g.a(paramg));
    } 
    return i;
  }
  
  private void e() {
    int i = 0;
    if (this.B == 0)
      i = Math.max(0, this.x - this.g); 
    u.a((View)this.f, i, 0, 0, 0);
    i = this.B;
    if (i != 0) {
      if (i == 1)
        this.f.setGravity(1); 
    } else {
      this.f.setGravity(8388611);
    } 
    a(true);
  }
  
  private LinearLayout.LayoutParams f() {
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -1);
    a(layoutParams);
    return layoutParams;
  }
  
  private void f(g paramg) {
    for (int i = this.G.size() - 1; i >= 0; i--)
      ((c<g>)this.G.get(i)).b(paramg); 
  }
  
  private void g() {
    if (this.I == null) {
      this.I = new ValueAnimator();
      this.I.setInterpolator(a.b.c.l.a.b);
      this.I.setDuration(this.z);
      this.I.addUpdateListener(new a(this));
    } 
  }
  
  private void g(g paramg) {
    for (int i = this.G.size() - 1; i >= 0; i--)
      ((c<g>)this.G.get(i)).a(paramg); 
  }
  
  private int getDefaultHeight() {
    boolean bool1;
    boolean bool2 = false;
    byte b1 = 0;
    int i = this.c.size();
    while (true) {
      bool1 = bool2;
      if (b1 < i) {
        g g1 = this.c.get(b1);
        if (g1 != null && g1.b() != null && !TextUtils.isEmpty(g1.d())) {
          bool1 = true;
          break;
        } 
        b1++;
        continue;
      } 
      break;
    } 
    if (bool1 && !this.C) {
      b1 = 72;
    } else {
      b1 = 48;
    } 
    return b1;
  }
  
  private int getTabMinWidth() {
    int i = this.u;
    if (i != -1)
      return i; 
    if (this.B == 0) {
      i = this.w;
    } else {
      i = 0;
    } 
    return i;
  }
  
  private int getTabScrollRange() {
    return Math.max(0, this.f.getWidth() - getWidth() - getPaddingLeft() - getPaddingRight());
  }
  
  private void h() {
    byte b1 = 0;
    int i = this.c.size();
    while (b1 < i) {
      ((g)this.c.get(b1)).h();
      b1++;
    } 
  }
  
  private void h(g paramg) {
    for (int i = this.G.size() - 1; i >= 0; i--)
      ((c<g>)this.G.get(i)).c(paramg); 
  }
  
  private void setSelectedTabView(int paramInt) {
    int i = this.f.getChildCount();
    if (paramInt < i)
      for (byte b1 = 0; b1 < i; b1++) {
        View view = this.f.getChildAt(b1);
        boolean bool2 = false;
        if (b1 == paramInt) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        view.setSelected(bool1);
        boolean bool1 = bool2;
        if (b1 == paramInt)
          bool1 = true; 
        view.setActivated(bool1);
      }  
  }
  
  int a(int paramInt) {
    return Math.round((getResources().getDisplayMetrics()).density * paramInt);
  }
  
  protected g a() {
    g g2 = (g)Q.a();
    g g1 = g2;
    if (g2 == null)
      g1 = new g(); 
    return g1;
  }
  
  public void a(int paramInt, float paramFloat, boolean paramBoolean) {
    a(paramInt, paramFloat, paramBoolean, true);
  }
  
  void a(int paramInt, float paramFloat, boolean paramBoolean1, boolean paramBoolean2) {
    int i = Math.round(paramInt + paramFloat);
    if (i < 0 || i >= this.f.getChildCount())
      return; 
    if (paramBoolean2)
      this.f.a(paramInt, paramFloat); 
    ValueAnimator valueAnimator = this.I;
    if (valueAnimator != null && valueAnimator.isRunning())
      this.I.cancel(); 
    scrollTo(a(paramInt, paramFloat), 0);
    if (paramBoolean1)
      setSelectedTabView(i); 
  }
  
  public void a(c paramc) {
    if (!this.G.contains(paramc))
      this.G.add(paramc); 
  }
  
  public void a(g paramg) {
    a(paramg, this.c.isEmpty());
  }
  
  public void a(g paramg, int paramInt, boolean paramBoolean) {
    if (paramg.f == this) {
      a(paramg, paramInt);
      d(paramg);
      if (paramBoolean)
        paramg.g(); 
      return;
    } 
    throw new IllegalArgumentException("Tab belongs to a different TabLayout.");
  }
  
  public void a(g paramg, boolean paramBoolean) {
    a(paramg, this.c.size(), paramBoolean);
  }
  
  public void a(ViewPager paramViewPager, boolean paramBoolean) {
    a(paramViewPager, paramBoolean, false);
  }
  
  void a(q paramq, boolean paramBoolean) {
    q q1 = this.K;
    if (q1 != null) {
      DataSetObserver dataSetObserver = this.L;
      if (dataSetObserver != null)
        q1.c(dataSetObserver); 
    } 
    this.K = paramq;
    if (paramBoolean && paramq != null) {
      if (this.L == null)
        this.L = new e(this); 
      paramq.a(this.L);
    } 
    c();
  }
  
  void a(boolean paramBoolean) {
    for (byte b1 = 0; b1 < this.f.getChildCount(); b1++) {
      View view = this.f.getChildAt(b1);
      view.setMinimumWidth(getTabMinWidth());
      a((LinearLayout.LayoutParams)view.getLayoutParams());
      if (paramBoolean)
        view.requestLayout(); 
    } 
  }
  
  public void addView(View paramView) {
    a(paramView);
  }
  
  public void addView(View paramView, int paramInt) {
    a(paramView);
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    a(paramView);
  }
  
  public void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    a(paramView);
  }
  
  public g b() {
    g g1 = a();
    g1.f = this;
    g1.g = e(g1);
    return g1;
  }
  
  public g b(int paramInt) {
    return (paramInt < 0 || paramInt >= getTabCount()) ? null : this.c.get(paramInt);
  }
  
  public void b(c paramc) {
    this.G.remove(paramc);
  }
  
  void b(g paramg, boolean paramBoolean) {
    g g1 = this.d;
    if (g1 == paramg) {
      if (g1 != null) {
        f(paramg);
        c(paramg.c());
      } 
    } else {
      byte b1;
      if (paramg != null) {
        b1 = paramg.c();
      } else {
        b1 = -1;
      } 
      if (paramBoolean) {
        if ((g1 == null || g1.c() == -1) && b1 != -1) {
          a(b1, 0.0F, true);
        } else {
          c(b1);
        } 
        if (b1 != -1)
          setSelectedTabView(b1); 
      } 
      this.d = paramg;
      if (g1 != null)
        h(g1); 
      if (paramg != null)
        g(paramg); 
    } 
  }
  
  protected boolean b(g paramg) {
    return Q.a(paramg);
  }
  
  void c() {
    d();
    q q1 = this.K;
    if (q1 != null) {
      int k = q1.a();
      int i;
      for (i = 0; i < k; i++) {
        g g1 = b();
        g1.b(this.K.a(i));
        a(g1, false);
      } 
      ViewPager viewPager = this.J;
      if (viewPager != null && k > 0) {
        i = viewPager.getCurrentItem();
        if (i != getSelectedTabPosition() && i < getTabCount())
          c(b(i)); 
      } 
    } 
  }
  
  void c(g paramg) {
    b(paramg, true);
  }
  
  public void d() {
    for (int i = this.f.getChildCount() - 1; i >= 0; i--)
      d(i); 
    Iterator<g> iterator = this.c.iterator();
    while (iterator.hasNext()) {
      g g1 = iterator.next();
      iterator.remove();
      g1.f();
      b(g1);
    } 
    this.d = null;
  }
  
  public FrameLayout.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return generateDefaultLayoutParams();
  }
  
  public int getSelectedTabPosition() {
    byte b1;
    g g1 = this.d;
    if (g1 != null) {
      b1 = g1.c();
    } else {
      b1 = -1;
    } 
    return b1;
  }
  
  public int getTabCount() {
    return this.c.size();
  }
  
  public int getTabGravity() {
    return this.y;
  }
  
  public ColorStateList getTabIconTint() {
    return this.m;
  }
  
  public int getTabIndicatorGravity() {
    return this.A;
  }
  
  int getTabMaxWidth() {
    return this.t;
  }
  
  public int getTabMode() {
    return this.B;
  }
  
  public ColorStateList getTabRippleColor() {
    return this.n;
  }
  
  public Drawable getTabSelectedIndicator() {
    return this.o;
  }
  
  public ColorStateList getTabTextColors() {
    return this.l;
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (this.J == null) {
      ViewParent viewParent = getParent();
      if (viewParent instanceof ViewPager)
        a((ViewPager)viewParent, true, true); 
    } 
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    if (this.O) {
      setupWithViewPager(null);
      this.O = false;
    } 
  }
  
  protected void onDraw(Canvas paramCanvas) {
    for (byte b1 = 0; b1 < this.f.getChildCount(); b1++) {
      View view = this.f.getChildAt(b1);
      if (view instanceof i)
        i.a((i)view, paramCanvas); 
    } 
    super.onDraw(paramCanvas);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i = a(getDefaultHeight()) + getPaddingTop() + getPaddingBottom();
    int k = View.MeasureSpec.getMode(paramInt2);
    if (k != Integer.MIN_VALUE) {
      if (k == 0)
        paramInt2 = View.MeasureSpec.makeMeasureSpec(i, 1073741824); 
    } else {
      paramInt2 = View.MeasureSpec.makeMeasureSpec(Math.min(i, View.MeasureSpec.getSize(paramInt2)), 1073741824);
    } 
    k = View.MeasureSpec.getSize(paramInt1);
    if (View.MeasureSpec.getMode(paramInt1) != 0) {
      i = this.v;
      if (i <= 0)
        i = k - a(56); 
      this.t = i;
    } 
    super.onMeasure(paramInt1, paramInt2);
    if (getChildCount() == 1) {
      paramInt1 = 0;
      k = 0;
      View view = getChildAt(0);
      i = 0;
      int m = this.B;
      if (m != 0) {
        if (m != 1) {
          paramInt1 = i;
        } else {
          paramInt1 = k;
          if (view.getMeasuredWidth() != getMeasuredWidth())
            paramInt1 = 1; 
        } 
      } else if (view.getMeasuredWidth() < getMeasuredWidth()) {
        paramInt1 = 1;
      } 
      if (paramInt1 != 0) {
        paramInt1 = HorizontalScrollView.getChildMeasureSpec(paramInt2, getPaddingTop() + getPaddingBottom(), (view.getLayoutParams()).height);
        view.measure(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), paramInt1);
      } 
    } 
  }
  
  public void setInlineLabel(boolean paramBoolean) {
    if (this.C != paramBoolean) {
      this.C = paramBoolean;
      for (byte b1 = 0; b1 < this.f.getChildCount(); b1++) {
        View view = this.f.getChildAt(b1);
        if (view instanceof i)
          ((i)view).c(); 
      } 
      e();
    } 
  }
  
  public void setInlineLabelResource(int paramInt) {
    setInlineLabel(getResources().getBoolean(paramInt));
  }
  
  @Deprecated
  public void setOnTabSelectedListener(c paramc) {
    c c1 = this.F;
    if (c1 != null)
      b(c1); 
    this.F = paramc;
    if (paramc != null)
      a(paramc); 
  }
  
  void setScrollAnimatorListener(Animator.AnimatorListener paramAnimatorListener) {
    g();
    this.I.addListener(paramAnimatorListener);
  }
  
  public void setSelectedTabIndicator(int paramInt) {
    if (paramInt != 0) {
      setSelectedTabIndicator(a.b.h.c.a.a.c(getContext(), paramInt));
    } else {
      setSelectedTabIndicator((Drawable)null);
    } 
  }
  
  public void setSelectedTabIndicator(Drawable paramDrawable) {
    if (this.o != paramDrawable) {
      this.o = paramDrawable;
      u.B((View)this.f);
    } 
  }
  
  public void setSelectedTabIndicatorColor(int paramInt) {
    this.f.a(paramInt);
  }
  
  public void setSelectedTabIndicatorGravity(int paramInt) {
    if (this.A != paramInt) {
      this.A = paramInt;
      u.B((View)this.f);
    } 
  }
  
  @Deprecated
  public void setSelectedTabIndicatorHeight(int paramInt) {
    this.f.b(paramInt);
  }
  
  public void setTabGravity(int paramInt) {
    if (this.y != paramInt) {
      this.y = paramInt;
      e();
    } 
  }
  
  public void setTabIconTint(ColorStateList paramColorStateList) {
    if (this.m != paramColorStateList) {
      this.m = paramColorStateList;
      h();
    } 
  }
  
  public void setTabIconTintResource(int paramInt) {
    setTabIconTint(a.b.h.c.a.a.b(getContext(), paramInt));
  }
  
  public void setTabIndicatorFullWidth(boolean paramBoolean) {
    this.D = paramBoolean;
    u.B((View)this.f);
  }
  
  public void setTabMode(int paramInt) {
    if (paramInt != this.B) {
      this.B = paramInt;
      e();
    } 
  }
  
  public void setTabRippleColor(ColorStateList paramColorStateList) {
    if (this.n != paramColorStateList) {
      this.n = paramColorStateList;
      for (byte b1 = 0; b1 < this.f.getChildCount(); b1++) {
        View view = this.f.getChildAt(b1);
        if (view instanceof i)
          i.a((i)view, getContext()); 
      } 
    } 
  }
  
  public void setTabRippleColorResource(int paramInt) {
    setTabRippleColor(a.b.h.c.a.a.b(getContext(), paramInt));
  }
  
  public void setTabTextColors(ColorStateList paramColorStateList) {
    if (this.l != paramColorStateList) {
      this.l = paramColorStateList;
      h();
    } 
  }
  
  @Deprecated
  public void setTabsFromPagerAdapter(q paramq) {
    a(paramq, false);
  }
  
  public void setUnboundedRipple(boolean paramBoolean) {
    if (this.E != paramBoolean) {
      this.E = paramBoolean;
      for (byte b1 = 0; b1 < this.f.getChildCount(); b1++) {
        View view = this.f.getChildAt(b1);
        if (view instanceof i)
          i.a((i)view, getContext()); 
      } 
    } 
  }
  
  public void setUnboundedRippleResource(int paramInt) {
    setUnboundedRipple(getResources().getBoolean(paramInt));
  }
  
  public void setupWithViewPager(ViewPager paramViewPager) {
    a(paramViewPager, true);
  }
  
  public boolean shouldDelayChildPressedState() {
    boolean bool;
    if (getTabScrollRange() > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  class a implements ValueAnimator.AnimatorUpdateListener {
    final TabLayout a;
    
    a(TabLayout this$0) {}
    
    public void onAnimationUpdate(ValueAnimator param1ValueAnimator) {
      this.a.scrollTo(((Integer)param1ValueAnimator.getAnimatedValue()).intValue(), 0);
    }
  }
  
  private class b implements ViewPager.i {
    private boolean a;
    
    final TabLayout b;
    
    b(TabLayout this$0) {}
    
    public void a(ViewPager param1ViewPager, q param1q1, q param1q2) {
      TabLayout tabLayout = this.b;
      if (tabLayout.J == param1ViewPager)
        tabLayout.a(param1q2, this.a); 
    }
    
    void a(boolean param1Boolean) {
      this.a = param1Boolean;
    }
  }
  
  public static interface c<T extends g> {
    void a(T param1T);
    
    void b(T param1T);
    
    void c(T param1T);
  }
  
  public static interface d extends c<g> {}
  
  private class e extends DataSetObserver {
    final TabLayout a;
    
    e(TabLayout this$0) {}
    
    public void onChanged() {
      this.a.c();
    }
    
    public void onInvalidated() {
      this.a.c();
    }
  }
  
  private class f extends LinearLayout {
    private int c;
    
    private final Paint d;
    
    private final GradientDrawable e;
    
    int f = -1;
    
    float g;
    
    private int h = -1;
    
    private int i = -1;
    
    private int j = -1;
    
    private ValueAnimator k;
    
    final TabLayout l;
    
    f(TabLayout this$0, Context param1Context) {
      super(param1Context);
      setWillNotDraw(false);
      this.d = new Paint();
      this.e = new GradientDrawable();
    }
    
    private void a(TabLayout.i param1i, RectF param1RectF) {
      int k = TabLayout.i.a(param1i);
      int j = k;
      if (k < this.l.a(24))
        j = this.l.a(24); 
      k = (param1i.getLeft() + param1i.getRight()) / 2;
      int m = j / 2;
      j /= 2;
      param1RectF.set((k - m), 0.0F, (j + k), 0.0F);
    }
    
    private void b() {
      byte b1;
      byte b2;
      View view = getChildAt(this.f);
      if (view != null && view.getWidth() > 0) {
        b2 = view.getLeft();
        b1 = view.getRight();
        TabLayout tabLayout = this.l;
        int j = b2;
        int i = b1;
        if (!tabLayout.D) {
          j = b2;
          i = b1;
          if (view instanceof TabLayout.i) {
            a((TabLayout.i)view, TabLayout.a(tabLayout));
            j = (int)(TabLayout.a(this.l)).left;
            i = (int)(TabLayout.a(this.l)).right;
          } 
        } 
        b1 = j;
        b2 = i;
        if (this.g > 0.0F) {
          b1 = j;
          b2 = i;
          if (this.f < getChildCount() - 1) {
            View view1 = getChildAt(this.f + 1);
            int m = view1.getLeft();
            int k = view1.getRight();
            TabLayout tabLayout1 = this.l;
            b2 = m;
            b1 = k;
            if (!tabLayout1.D) {
              b2 = m;
              b1 = k;
              if (view1 instanceof TabLayout.i) {
                a((TabLayout.i)view1, TabLayout.a(tabLayout1));
                b2 = (int)(TabLayout.a(this.l)).left;
                b1 = (int)(TabLayout.a(this.l)).right;
              } 
            } 
            float f1 = this.g;
            j = (int)(b2 * f1 + (1.0F - f1) * j);
            b2 = (int)(b1 * f1 + (1.0F - f1) * i);
            b1 = j;
          } 
        } 
      } else {
        b1 = -1;
        b2 = -1;
      } 
      b(b1, b2);
    }
    
    void a(int param1Int) {
      if (this.d.getColor() != param1Int) {
        this.d.setColor(param1Int);
        u.B((View)this);
      } 
    }
    
    void a(int param1Int, float param1Float) {
      ValueAnimator valueAnimator = this.k;
      if (valueAnimator != null && valueAnimator.isRunning())
        this.k.cancel(); 
      this.f = param1Int;
      this.g = param1Float;
      b();
    }
    
    void a(int param1Int1, int param1Int2) {
      ValueAnimator valueAnimator = this.k;
      if (valueAnimator != null && valueAnimator.isRunning())
        this.k.cancel(); 
      View view = getChildAt(param1Int1);
      if (view == null) {
        b();
        return;
      } 
      int j = view.getLeft();
      int i = view.getRight();
      TabLayout tabLayout = this.l;
      if (!tabLayout.D && view instanceof TabLayout.i) {
        a((TabLayout.i)view, TabLayout.a(tabLayout));
        j = (int)(TabLayout.a(this.l)).left;
        i = (int)(TabLayout.a(this.l)).right;
      } 
      int m = this.i;
      int k = this.j;
      if (m != j || k != i) {
        ValueAnimator valueAnimator1 = new ValueAnimator();
        this.k = valueAnimator1;
        valueAnimator1.setInterpolator(a.b.c.l.a.b);
        valueAnimator1.setDuration(param1Int2);
        valueAnimator1.setFloatValues(new float[] { 0.0F, 1.0F });
        valueAnimator1.addUpdateListener(new a(this, m, j, k, i));
        valueAnimator1.addListener((Animator.AnimatorListener)new b(this, param1Int1));
        valueAnimator1.start();
      } 
    }
    
    boolean a() {
      byte b = 0;
      int i = getChildCount();
      while (b < i) {
        if (getChildAt(b).getWidth() <= 0)
          return true; 
        b++;
      } 
      return false;
    }
    
    void b(int param1Int) {
      if (this.c != param1Int) {
        this.c = param1Int;
        u.B((View)this);
      } 
    }
    
    void b(int param1Int1, int param1Int2) {
      if (param1Int1 != this.i || param1Int2 != this.j) {
        this.i = param1Int1;
        this.j = param1Int2;
        u.B((View)this);
      } 
    }
    
    public void draw(Canvas param1Canvas) {
      int i = 0;
      Drawable drawable = this.l.o;
      if (drawable != null)
        i = drawable.getIntrinsicHeight(); 
      if (this.c >= 0)
        i = this.c; 
      int k = 0;
      int j = 0;
      int m = this.l.A;
      if (m != 0) {
        if (m != 1) {
          if (m != 2) {
            if (m != 3) {
              i = k;
            } else {
              i = 0;
              j = getHeight();
            } 
          } else {
            k = 0;
            j = i;
            i = k;
          } 
        } else {
          k = (getHeight() - i) / 2;
          j = (getHeight() + i) / 2;
          i = k;
        } 
      } else {
        i = getHeight() - i;
        j = getHeight();
      } 
      k = this.i;
      if (k >= 0 && this.j > k) {
        GradientDrawable gradientDrawable;
        drawable = this.l.o;
        if (drawable == null)
          gradientDrawable = this.e; 
        Drawable drawable1 = android.support.v4.graphics.drawable.a.h((Drawable)gradientDrawable);
        drawable1.setBounds(this.i, i, this.j, j);
        Paint paint = this.d;
        if (paint != null)
          if (Build.VERSION.SDK_INT == 21) {
            drawable1.setColorFilter(paint.getColor(), PorterDuff.Mode.SRC_IN);
          } else {
            android.support.v4.graphics.drawable.a.b(drawable1, paint.getColor());
          }  
        drawable1.draw(param1Canvas);
      } 
      super.draw(param1Canvas);
    }
    
    protected void onLayout(boolean param1Boolean, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      super.onLayout(param1Boolean, param1Int1, param1Int2, param1Int3, param1Int4);
      ValueAnimator valueAnimator = this.k;
      if (valueAnimator != null && valueAnimator.isRunning()) {
        this.k.cancel();
        long l = this.k.getDuration();
        a(this.f, Math.round((1.0F - this.k.getAnimatedFraction()) * (float)l));
      } else {
        b();
      } 
    }
    
    protected void onMeasure(int param1Int1, int param1Int2) {
      super.onMeasure(param1Int1, param1Int2);
      if (View.MeasureSpec.getMode(param1Int1) != 1073741824)
        return; 
      TabLayout tabLayout = this.l;
      if (tabLayout.B == 1 && tabLayout.y == 1) {
        int k = getChildCount();
        int i = 0;
        byte b = 0;
        while (b < k) {
          View view = getChildAt(b);
          int m = i;
          if (view.getVisibility() == 0)
            m = Math.max(i, view.getMeasuredWidth()); 
          b++;
          i = m;
        } 
        if (i <= 0)
          return; 
        int j = this.l.a(16);
        b = 0;
        if (i * k <= getMeasuredWidth() - j * 2) {
          for (j = 0; j < k; j++) {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)getChildAt(j).getLayoutParams();
            if (layoutParams.width != i || layoutParams.weight != 0.0F) {
              layoutParams.width = i;
              layoutParams.weight = 0.0F;
              b = 1;
            } 
          } 
        } else {
          tabLayout = this.l;
          tabLayout.y = 0;
          tabLayout.a(false);
          b = 1;
        } 
        if (b != 0)
          super.onMeasure(param1Int1, param1Int2); 
      } 
    }
    
    public void onRtlPropertiesChanged(int param1Int) {
      super.onRtlPropertiesChanged(param1Int);
      if (Build.VERSION.SDK_INT < 23 && this.h != param1Int) {
        requestLayout();
        this.h = param1Int;
      } 
    }
    
    class a implements ValueAnimator.AnimatorUpdateListener {
      final int a;
      
      final int b;
      
      final int c;
      
      final int d;
      
      final TabLayout.f e;
      
      a(TabLayout.f this$0, int param2Int1, int param2Int2, int param2Int3, int param2Int4) {}
      
      public void onAnimationUpdate(ValueAnimator param2ValueAnimator) {
        float f1 = param2ValueAnimator.getAnimatedFraction();
        this.e.b(a.b.c.l.a.a(this.a, this.b, f1), a.b.c.l.a.a(this.c, this.d, f1));
      }
    }
    
    class b extends AnimatorListenerAdapter {
      final int a;
      
      final TabLayout.f b;
      
      b(TabLayout.f this$0, int param2Int) {}
      
      public void onAnimationEnd(Animator param2Animator) {
        TabLayout.f f1 = this.b;
        f1.f = this.a;
        f1.g = 0.0F;
      }
    }
  }
  
  class a implements ValueAnimator.AnimatorUpdateListener {
    final int a;
    
    final int b;
    
    final int c;
    
    final int d;
    
    final TabLayout.f e;
    
    a(TabLayout this$0, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {}
    
    public void onAnimationUpdate(ValueAnimator param1ValueAnimator) {
      float f1 = param1ValueAnimator.getAnimatedFraction();
      this.e.b(a.b.c.l.a.a(this.a, this.b, f1), a.b.c.l.a.a(this.c, this.d, f1));
    }
  }
  
  class b extends AnimatorListenerAdapter {
    final int a;
    
    final TabLayout.f b;
    
    b(TabLayout this$0, int param1Int) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      TabLayout.f f1 = this.b;
      f1.f = this.a;
      f1.g = 0.0F;
    }
  }
  
  public static class g {
    private Drawable a;
    
    private CharSequence b;
    
    private CharSequence c;
    
    private int d = -1;
    
    private View e;
    
    public TabLayout f;
    
    public TabLayout.i g;
    
    public g a(int param1Int) {
      a(LayoutInflater.from(this.g.getContext()).inflate(param1Int, (ViewGroup)this.g, false));
      return this;
    }
    
    public g a(Drawable param1Drawable) {
      this.a = param1Drawable;
      h();
      return this;
    }
    
    public g a(View param1View) {
      this.e = param1View;
      h();
      return this;
    }
    
    public g a(CharSequence param1CharSequence) {
      this.c = param1CharSequence;
      h();
      return this;
    }
    
    public View a() {
      return this.e;
    }
    
    public Drawable b() {
      return this.a;
    }
    
    public g b(CharSequence param1CharSequence) {
      if (TextUtils.isEmpty(this.c) && !TextUtils.isEmpty(param1CharSequence))
        this.g.setContentDescription(param1CharSequence); 
      this.b = param1CharSequence;
      h();
      return this;
    }
    
    void b(int param1Int) {
      this.d = param1Int;
    }
    
    public int c() {
      return this.d;
    }
    
    public CharSequence d() {
      return this.b;
    }
    
    public boolean e() {
      TabLayout tabLayout = this.f;
      if (tabLayout != null) {
        boolean bool;
        if (tabLayout.getSelectedTabPosition() == this.d) {
          bool = true;
        } else {
          bool = false;
        } 
        return bool;
      } 
      throw new IllegalArgumentException("Tab not attached to a TabLayout");
    }
    
    void f() {
      this.f = null;
      this.g = null;
      this.a = null;
      this.b = null;
      this.c = null;
      this.d = -1;
      this.e = null;
    }
    
    public void g() {
      TabLayout tabLayout = this.f;
      if (tabLayout != null) {
        tabLayout.c(this);
        return;
      } 
      throw new IllegalArgumentException("Tab not attached to a TabLayout");
    }
    
    void h() {
      TabLayout.i i1 = this.g;
      if (i1 != null)
        i1.b(); 
    }
  }
  
  public static class h implements ViewPager.j {
    private final WeakReference<TabLayout> c;
    
    private int d;
    
    private int e;
    
    public h(TabLayout param1TabLayout) {
      this.c = new WeakReference<TabLayout>(param1TabLayout);
    }
    
    void a() {
      this.e = 0;
      this.d = 0;
    }
    
    public void a(int param1Int) {
      this.d = this.e;
      this.e = param1Int;
    }
    
    public void a(int param1Int1, float param1Float, int param1Int2) {
      TabLayout tabLayout = this.c.get();
      if (tabLayout != null) {
        boolean bool1;
        param1Int2 = this.e;
        boolean bool2 = false;
        if (param1Int2 != 2 || this.d == 1) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (this.e != 2 || this.d != 0)
          bool2 = true; 
        tabLayout.a(param1Int1, param1Float, bool1, bool2);
      } 
    }
    
    public void b(int param1Int) {
      TabLayout tabLayout = this.c.get();
      if (tabLayout != null && tabLayout.getSelectedTabPosition() != param1Int && param1Int < tabLayout.getTabCount()) {
        boolean bool;
        int i = this.e;
        if (i == 0 || (i == 2 && this.d == 0)) {
          bool = true;
        } else {
          bool = false;
        } 
        tabLayout.b(tabLayout.b(param1Int), bool);
      } 
    }
  }
  
  class i extends LinearLayout {
    private TabLayout.g c;
    
    private TextView d;
    
    private ImageView e;
    
    private View f;
    
    private TextView g;
    
    private ImageView h;
    
    private Drawable i;
    
    private int j = 2;
    
    final TabLayout k;
    
    public i(TabLayout this$0, Context param1Context) {
      super(param1Context);
      a(param1Context);
      u.a((View)this, this$0.g, this$0.h, this$0.i, this$0.j);
      setGravity(17);
      setOrientation(this$0.C ^ true);
      setClickable(true);
      u.a((View)this, r.a(getContext(), 1002));
    }
    
    private float a(Layout param1Layout, int param1Int, float param1Float) {
      return param1Layout.getLineWidth(param1Int) * param1Float / param1Layout.getPaint().getTextSize();
    }
    
    private void a(Context param1Context) {
      LayerDrawable layerDrawable;
      int j = this.k.s;
      GradientDrawable gradientDrawable2 = null;
      if (j != 0) {
        this.i = a.b.h.c.a.a.c(param1Context, j);
        Drawable drawable = this.i;
        if (drawable != null && drawable.isStateful())
          this.i.setState(getDrawableState()); 
      } else {
        this.i = null;
      } 
      GradientDrawable gradientDrawable1 = new GradientDrawable();
      gradientDrawable1.setColor(0);
      if (this.k.n != null) {
        RippleDrawable rippleDrawable;
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(1.0E-5F);
        gradientDrawable.setColor(-1);
        ColorStateList colorStateList = a.b.c.q.a.a(this.k.n);
        if (Build.VERSION.SDK_INT >= 21) {
          if (this.k.E)
            gradientDrawable1 = null; 
          if (!this.k.E)
            gradientDrawable2 = gradientDrawable; 
          rippleDrawable = new RippleDrawable(colorStateList, (Drawable)gradientDrawable1, (Drawable)gradientDrawable2);
        } else {
          Drawable drawable = android.support.v4.graphics.drawable.a.h((Drawable)gradientDrawable);
          android.support.v4.graphics.drawable.a.a(drawable, colorStateList);
          layerDrawable = new LayerDrawable(new Drawable[] { (Drawable)rippleDrawable, drawable });
        } 
      } 
      u.a((View)this, (Drawable)layerDrawable);
      this.k.invalidate();
    }
    
    private void a(Canvas param1Canvas) {
      Drawable drawable = this.i;
      if (drawable != null) {
        drawable.setBounds(getLeft(), getTop(), getRight(), getBottom());
        this.i.draw(param1Canvas);
      } 
    }
    
    private void a(TextView param1TextView, ImageView param1ImageView) {
      TabLayout.g g2 = this.c;
      TabLayout.g g4 = null;
      if (g2 != null && g2.b() != null) {
        Drawable drawable = android.support.v4.graphics.drawable.a.h(this.c.b()).mutate();
      } else {
        g2 = null;
      } 
      TabLayout.g g3 = this.c;
      if (g3 != null) {
        CharSequence charSequence = g3.d();
      } else {
        g3 = null;
      } 
      if (param1ImageView != null)
        if (g2 != null) {
          param1ImageView.setImageDrawable((Drawable)g2);
          param1ImageView.setVisibility(0);
          setVisibility(0);
        } else {
          param1ImageView.setVisibility(8);
          param1ImageView.setImageDrawable(null);
        }  
      int j = TextUtils.isEmpty((CharSequence)g3) ^ true;
      if (param1TextView != null)
        if (j != 0) {
          param1TextView.setText((CharSequence)g3);
          param1TextView.setVisibility(0);
          setVisibility(0);
        } else {
          param1TextView.setVisibility(8);
          param1TextView.setText(null);
        }  
      if (param1ImageView != null) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)param1ImageView.getLayoutParams();
        byte b = 0;
        int k = b;
        if (j != 0) {
          k = b;
          if (param1ImageView.getVisibility() == 0)
            k = this.k.a(8); 
        } 
        if (this.k.C) {
          if (k != android.support.v4.view.g.a(marginLayoutParams)) {
            android.support.v4.view.g.a(marginLayoutParams, k);
            marginLayoutParams.bottomMargin = 0;
            param1ImageView.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams);
            param1ImageView.requestLayout();
          } 
        } else if (k != marginLayoutParams.bottomMargin) {
          marginLayoutParams.bottomMargin = k;
          android.support.v4.view.g.a(marginLayoutParams, 0);
          param1ImageView.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams);
          param1ImageView.requestLayout();
        } 
      } 
      TabLayout.g g1 = this.c;
      if (g1 != null) {
        CharSequence charSequence = TabLayout.g.a(g1);
      } else {
        g1 = null;
      } 
      if (j != 0)
        g1 = g4; 
      l1.a((View)this, (CharSequence)g1);
    }
    
    private int d() {
      boolean bool = false;
      int k = 0;
      int j = 0;
      View[] arrayOfView = new View[3];
      TextView textView = this.d;
      byte b = 0;
      arrayOfView[0] = (View)textView;
      arrayOfView[1] = (View)this.e;
      arrayOfView[2] = this.f;
      int m = arrayOfView.length;
      while (b < m) {
        View view = arrayOfView[b];
        boolean bool1 = bool;
        int i1 = k;
        int n = j;
        if (view != null) {
          bool1 = bool;
          i1 = k;
          n = j;
          if (view.getVisibility() == 0) {
            i1 = view.getLeft();
            n = i1;
            if (bool)
              n = Math.min(k, i1); 
            k = n;
            i1 = view.getRight();
            n = i1;
            if (bool)
              n = Math.max(j, i1); 
            bool1 = true;
            i1 = k;
          } 
        } 
        b++;
        bool = bool1;
        k = i1;
        j = n;
      } 
      return j - k;
    }
    
    void a() {
      a((TabLayout.g)null);
      setSelected(false);
    }
    
    void a(TabLayout.g param1g) {
      if (param1g != this.c) {
        this.c = param1g;
        b();
      } 
    }
    
    final void b() {
      TabLayout.g g1 = this.c;
      View view2 = null;
      if (g1 != null) {
        view1 = g1.a();
      } else {
        view1 = null;
      } 
      if (view1 != null) {
        ViewParent viewParent = view1.getParent();
        if (viewParent != this) {
          if (viewParent != null)
            ((ViewGroup)viewParent).removeView(view1); 
          addView(view1);
        } 
        this.f = view1;
        TextView textView2 = this.d;
        if (textView2 != null)
          textView2.setVisibility(8); 
        ImageView imageView = this.e;
        if (imageView != null) {
          imageView.setVisibility(8);
          this.e.setImageDrawable(null);
        } 
        this.g = (TextView)view1.findViewById(16908308);
        TextView textView1 = this.g;
        if (textView1 != null)
          this.j = p.d(textView1); 
        this.h = (ImageView)view1.findViewById(16908294);
      } else {
        view1 = this.f;
        if (view1 != null) {
          removeView(view1);
          this.f = null;
        } 
        this.g = null;
        this.h = null;
      } 
      View view1 = this.f;
      boolean bool2 = false;
      if (view1 == null) {
        if (this.e == null) {
          ImageView imageView = (ImageView)LayoutInflater.from(getContext()).inflate(a.b.c.h.design_layout_tab_icon, (ViewGroup)this, false);
          addView((View)imageView, 0);
          this.e = imageView;
        } 
        if (g1 != null && g1.b() != null) {
          Drawable drawable = android.support.v4.graphics.drawable.a.h(g1.b()).mutate();
        } else {
          view1 = view2;
        } 
        if (view1 != null) {
          android.support.v4.graphics.drawable.a.a((Drawable)view1, this.k.m);
          PorterDuff.Mode mode = this.k.p;
          if (mode != null)
            android.support.v4.graphics.drawable.a.a((Drawable)view1, mode); 
        } 
        if (this.d == null) {
          TextView textView = (TextView)LayoutInflater.from(getContext()).inflate(a.b.c.h.design_layout_tab_text, (ViewGroup)this, false);
          addView((View)textView);
          this.d = textView;
          this.j = p.d(this.d);
        } 
        p.d(this.d, this.k.k);
        ColorStateList colorStateList = this.k.l;
        if (colorStateList != null)
          this.d.setTextColor(colorStateList); 
        a(this.d, this.e);
      } else if (this.g != null || this.h != null) {
        a(this.g, this.h);
      } 
      if (g1 != null && !TextUtils.isEmpty(TabLayout.g.a(g1)))
        setContentDescription(TabLayout.g.a(g1)); 
      boolean bool1 = bool2;
      if (g1 != null) {
        bool1 = bool2;
        if (g1.e())
          bool1 = true; 
      } 
      setSelected(bool1);
    }
    
    final void c() {
      setOrientation(this.k.C ^ true);
      if (this.g != null || this.h != null) {
        a(this.g, this.h);
        return;
      } 
      a(this.d, this.e);
    }
    
    protected void drawableStateChanged() {
      super.drawableStateChanged();
      byte b = 0;
      int[] arrayOfInt = getDrawableState();
      Drawable drawable = this.i;
      int j = b;
      if (drawable != null) {
        j = b;
        if (drawable.isStateful())
          j = false | this.i.setState(arrayOfInt); 
      } 
      if (j != 0) {
        invalidate();
        this.k.invalidate();
      } 
    }
    
    public void onInitializeAccessibilityEvent(AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName(android.support.v7.app.a.c.class.getName());
    }
    
    @TargetApi(14)
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo param1AccessibilityNodeInfo) {
      super.onInitializeAccessibilityNodeInfo(param1AccessibilityNodeInfo);
      param1AccessibilityNodeInfo.setClassName(android.support.v7.app.a.c.class.getName());
    }
    
    public void onMeasure(int param1Int1, int param1Int2) {
      // Byte code:
      //   0: iload_1
      //   1: invokestatic getSize : (I)I
      //   4: istore #5
      //   6: iload_1
      //   7: invokestatic getMode : (I)I
      //   10: istore #7
      //   12: aload_0
      //   13: getfield k : Landroid/support/design/widget/TabLayout;
      //   16: invokevirtual getTabMaxWidth : ()I
      //   19: istore #6
      //   21: iload #6
      //   23: ifle -> 55
      //   26: iload #7
      //   28: ifeq -> 38
      //   31: iload #5
      //   33: iload #6
      //   35: if_icmple -> 55
      //   38: aload_0
      //   39: getfield k : Landroid/support/design/widget/TabLayout;
      //   42: getfield t : I
      //   45: ldc_w -2147483648
      //   48: invokestatic makeMeasureSpec : (II)I
      //   51: istore_1
      //   52: goto -> 55
      //   55: aload_0
      //   56: iload_1
      //   57: iload_2
      //   58: invokespecial onMeasure : (II)V
      //   61: aload_0
      //   62: getfield d : Landroid/widget/TextView;
      //   65: ifnull -> 319
      //   68: aload_0
      //   69: getfield k : Landroid/support/design/widget/TabLayout;
      //   72: getfield q : F
      //   75: fstore #4
      //   77: aload_0
      //   78: getfield j : I
      //   81: istore #6
      //   83: aload_0
      //   84: getfield e : Landroid/widget/ImageView;
      //   87: astore #9
      //   89: aload #9
      //   91: ifnull -> 111
      //   94: aload #9
      //   96: invokevirtual getVisibility : ()I
      //   99: ifne -> 111
      //   102: iconst_1
      //   103: istore #5
      //   105: fload #4
      //   107: fstore_3
      //   108: goto -> 157
      //   111: aload_0
      //   112: getfield d : Landroid/widget/TextView;
      //   115: astore #9
      //   117: fload #4
      //   119: fstore_3
      //   120: iload #6
      //   122: istore #5
      //   124: aload #9
      //   126: ifnull -> 157
      //   129: fload #4
      //   131: fstore_3
      //   132: iload #6
      //   134: istore #5
      //   136: aload #9
      //   138: invokevirtual getLineCount : ()I
      //   141: iconst_1
      //   142: if_icmple -> 157
      //   145: aload_0
      //   146: getfield k : Landroid/support/design/widget/TabLayout;
      //   149: getfield r : F
      //   152: fstore_3
      //   153: iload #6
      //   155: istore #5
      //   157: aload_0
      //   158: getfield d : Landroid/widget/TextView;
      //   161: invokevirtual getTextSize : ()F
      //   164: fstore #4
      //   166: aload_0
      //   167: getfield d : Landroid/widget/TextView;
      //   170: invokevirtual getLineCount : ()I
      //   173: istore #8
      //   175: aload_0
      //   176: getfield d : Landroid/widget/TextView;
      //   179: invokestatic d : (Landroid/widget/TextView;)I
      //   182: istore #6
      //   184: fload_3
      //   185: fload #4
      //   187: fcmpl
      //   188: ifne -> 203
      //   191: iload #6
      //   193: iflt -> 319
      //   196: iload #5
      //   198: iload #6
      //   200: if_icmpeq -> 319
      //   203: iconst_1
      //   204: istore #7
      //   206: iload #7
      //   208: istore #6
      //   210: aload_0
      //   211: getfield k : Landroid/support/design/widget/TabLayout;
      //   214: getfield B : I
      //   217: iconst_1
      //   218: if_icmpne -> 290
      //   221: iload #7
      //   223: istore #6
      //   225: fload_3
      //   226: fload #4
      //   228: fcmpl
      //   229: ifle -> 290
      //   232: iload #7
      //   234: istore #6
      //   236: iload #8
      //   238: iconst_1
      //   239: if_icmpne -> 290
      //   242: aload_0
      //   243: getfield d : Landroid/widget/TextView;
      //   246: invokevirtual getLayout : ()Landroid/text/Layout;
      //   249: astore #9
      //   251: aload #9
      //   253: ifnull -> 287
      //   256: iload #7
      //   258: istore #6
      //   260: aload_0
      //   261: aload #9
      //   263: iconst_0
      //   264: fload_3
      //   265: invokespecial a : (Landroid/text/Layout;IF)F
      //   268: aload_0
      //   269: invokevirtual getMeasuredWidth : ()I
      //   272: aload_0
      //   273: invokevirtual getPaddingLeft : ()I
      //   276: isub
      //   277: aload_0
      //   278: invokevirtual getPaddingRight : ()I
      //   281: isub
      //   282: i2f
      //   283: fcmpl
      //   284: ifle -> 290
      //   287: iconst_0
      //   288: istore #6
      //   290: iload #6
      //   292: ifeq -> 319
      //   295: aload_0
      //   296: getfield d : Landroid/widget/TextView;
      //   299: iconst_0
      //   300: fload_3
      //   301: invokevirtual setTextSize : (IF)V
      //   304: aload_0
      //   305: getfield d : Landroid/widget/TextView;
      //   308: iload #5
      //   310: invokevirtual setMaxLines : (I)V
      //   313: aload_0
      //   314: iload_1
      //   315: iload_2
      //   316: invokespecial onMeasure : (II)V
      //   319: return
    }
    
    public boolean performClick() {
      boolean bool = super.performClick();
      if (this.c != null) {
        if (!bool)
          playSoundEffect(0); 
        this.c.g();
        return true;
      } 
      return bool;
    }
    
    public void setSelected(boolean param1Boolean) {
      boolean bool;
      if (isSelected() != param1Boolean) {
        bool = true;
      } else {
        bool = false;
      } 
      super.setSelected(param1Boolean);
      if (bool && param1Boolean && Build.VERSION.SDK_INT < 16)
        sendAccessibilityEvent(4); 
      TextView textView = this.d;
      if (textView != null)
        textView.setSelected(param1Boolean); 
      ImageView imageView = this.e;
      if (imageView != null)
        imageView.setSelected(param1Boolean); 
      View view = this.f;
      if (view != null)
        view.setSelected(param1Boolean); 
    }
  }
  
  public static class j implements d {
    private final ViewPager a;
    
    public j(ViewPager param1ViewPager) {
      this.a = param1ViewPager;
    }
    
    public void a(TabLayout.g param1g) {
      this.a.setCurrentItem(param1g.c());
    }
    
    public void b(TabLayout.g param1g) {}
    
    public void c(TabLayout.g param1g) {}
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\TabLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */