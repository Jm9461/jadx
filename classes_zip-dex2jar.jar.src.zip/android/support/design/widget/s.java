package android.support.design.widget;

import android.graphics.drawable.Drawable;

public interface s {
  float a();
  
  void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void a(Drawable paramDrawable);
  
  boolean b();
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\widget\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */