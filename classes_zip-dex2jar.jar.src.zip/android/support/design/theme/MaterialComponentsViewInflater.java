package android.support.design.theme;

import a.b.c.m.a;
import android.content.Context;
import android.support.annotation.Keep;
import android.support.v7.app.AppCompatViewInflater;
import android.support.v7.widget.g;
import android.util.AttributeSet;

@Keep
public class MaterialComponentsViewInflater extends AppCompatViewInflater {
  protected g createButton(Context paramContext, AttributeSet paramAttributeSet) {
    return (g)new a(paramContext, paramAttributeSet);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\support\design\theme\MaterialComponentsViewInflater.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */