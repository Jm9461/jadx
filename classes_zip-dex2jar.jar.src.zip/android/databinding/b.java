package android.databinding;

public class b<C, T, A> implements Cloneable {
  public void a(T paramT, int paramInt, A paramA) {
    throw null;
  }
  
  public static abstract class a<C, T, A> {}
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\databinding\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */