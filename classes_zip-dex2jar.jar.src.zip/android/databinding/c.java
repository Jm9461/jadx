package android.databinding;

import java.util.Collections;
import java.util.List;

public abstract class c {
  public List<c> a() {
    return Collections.emptyList();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\databinding\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */