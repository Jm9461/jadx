package android.databinding;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

public class MergedDataBinderMapper extends c {
  private Set<Class<? extends c>> a = new HashSet<Class<? extends c>>();
  
  private List<c> b = new CopyOnWriteArrayList<c>();
  
  public MergedDataBinderMapper() {
    new CopyOnWriteArrayList();
  }
  
  public void a(c paramc) {
    Class<?> clazz = paramc.getClass();
    if (this.a.add(clazz)) {
      this.b.add(paramc);
      Iterator<c> iterator = paramc.a().iterator();
      while (iterator.hasNext())
        a(iterator.next()); 
    } 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\databinding\MergedDataBinderMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */