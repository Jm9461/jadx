package android.databinding;

public class a implements d {}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\databinding\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */