package android.arch.lifecycle;

import java.util.Map;

public abstract class LiveData<T> {
  private static final Object i = new Object();
  
  private final Object a = new Object();
  
  private a.a.a.b.b<k<T>, b> b = new a.a.a.b.b();
  
  private int c = 0;
  
  private volatile Object d;
  
  private volatile Object e;
  
  private int f;
  
  private boolean g;
  
  private boolean h;
  
  public LiveData() {
    Object object = i;
    this.d = object;
    this.e = object;
    this.f = -1;
    new a(this);
  }
  
  private void a(b paramb) {
    if (!paramb.b)
      return; 
    if (!paramb.b()) {
      paramb.a(false);
      return;
    } 
    int i = paramb.c;
    int j = this.f;
    if (i >= j)
      return; 
    paramb.c = j;
    paramb.a.a((T)this.d);
  }
  
  private static void a(String paramString) {
    if (a.a.a.a.a.b().a())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot invoke ");
    stringBuilder.append(paramString);
    stringBuilder.append(" on a background");
    stringBuilder.append(" thread");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void b(b paramb) {
    if (this.g) {
      this.h = true;
      return;
    } 
    this.g = true;
    while (true) {
      b b1;
      this.h = false;
      if (paramb != null) {
        a(paramb);
        b1 = null;
      } else {
        a.a.a.b.b.e<Map.Entry> e = this.b.c();
        while (true) {
          b1 = paramb;
          if (e.hasNext()) {
            a((b)((Map.Entry)e.next()).getValue());
            if (this.h) {
              b1 = paramb;
              break;
            } 
            continue;
          } 
          break;
        } 
      } 
      if (!this.h) {
        this.g = false;
        return;
      } 
      paramb = b1;
    } 
  }
  
  protected void a() {}
  
  public void a(e parame, k<T> paramk) {
    if (parame.a().a() == c.b.c)
      return; 
    LifecycleBoundObserver lifecycleBoundObserver = new LifecycleBoundObserver(this, parame, paramk);
    b b1 = (b)this.b.b(paramk, lifecycleBoundObserver);
    if (b1 == null || b1.a(parame)) {
      if (b1 != null)
        return; 
      parame.a().a(lifecycleBoundObserver);
      return;
    } 
    throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
  }
  
  public void a(k<T> paramk) {
    a("removeObserver");
    b b1 = (b)this.b.remove(paramk);
    if (b1 == null)
      return; 
    b1.a();
    b1.a(false);
  }
  
  protected void a(T paramT) {
    a("setValue");
    this.f++;
    this.d = paramT;
    b((b)null);
  }
  
  protected void b() {}
  
  class LifecycleBoundObserver extends b implements GenericLifecycleObserver {
    final e e;
    
    final LiveData f;
    
    LifecycleBoundObserver(LiveData this$0, e param1e, k<T> param1k) {
      super(this$0, param1k);
      this.e = param1e;
    }
    
    void a() {
      this.e.a().b(this);
    }
    
    public void a(e param1e, c.a param1a) {
      if (this.e.a().a() == c.b.c) {
        this.f.a(this.a);
        return;
      } 
      a(b());
    }
    
    boolean a(e param1e) {
      boolean bool;
      if (this.e == param1e) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    boolean b() {
      return this.e.a().a().a(c.b.f);
    }
  }
  
  class a implements Runnable {
    final LiveData c;
    
    a(LiveData this$0) {}
    
    public void run() {
      Object object1;
      Object object2 = LiveData.a(this.c);
      /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
      try {
        object1 = LiveData.b(this.c);
        try {
          LiveData.a(this.c, LiveData.c());
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          this.c.a(object1);
          return;
        } finally {}
      } finally {}
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
      throw object1;
    }
  }
  
  private abstract class b {
    final k<T> a;
    
    boolean b;
    
    int c = -1;
    
    final LiveData d;
    
    b(LiveData this$0, k<T> param1k) {
      this.a = param1k;
    }
    
    void a() {}
    
    void a(boolean param1Boolean) {
      if (param1Boolean == this.b)
        return; 
      this.b = param1Boolean;
      int i = LiveData.c(this.d);
      byte b1 = 1;
      if (i == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      LiveData liveData = this.d;
      int j = LiveData.c(liveData);
      if (!this.b)
        b1 = -1; 
      LiveData.a(liveData, j + b1);
      if (i != 0 && this.b)
        this.d.a(); 
      if (LiveData.c(this.d) == 0 && !this.b)
        this.d.b(); 
      if (this.b)
        LiveData.a(this.d, this); 
    }
    
    boolean a(e param1e) {
      return false;
    }
    
    abstract boolean b();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\arch\lifecycle\LiveData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */