package android.arch.lifecycle;

class FullLifecycleObserverAdapter implements GenericLifecycleObserver {
  private final FullLifecycleObserver a;
  
  FullLifecycleObserverAdapter(FullLifecycleObserver paramFullLifecycleObserver) {
    this.a = paramFullLifecycleObserver;
  }
  
  public void a(e parame, c.a parama) {
    switch (a.a[parama.ordinal()]) {
      default:
        return;
      case 7:
        throw new IllegalArgumentException("ON_ANY must not been send by anybody");
      case 6:
        this.a.a(parame);
      case 5:
        this.a.b(parame);
      case 4:
        this.a.e(parame);
      case 3:
        this.a.f(parame);
      case 2:
        this.a.c(parame);
      case 1:
        break;
    } 
    this.a.d(parame);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\arch\lifecycle\FullLifecycleObserverAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */