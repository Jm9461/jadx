package android.arch.lifecycle;

public class AndroidViewModel extends n {}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\arch\lifecycle\AndroidViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */