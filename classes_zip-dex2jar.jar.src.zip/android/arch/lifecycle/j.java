package android.arch.lifecycle;

public class j<T> extends LiveData<T> {
  public void a(T paramT) {
    super.a(paramT);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\arch\lifecycle\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */