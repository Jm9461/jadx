package android.arch.lifecycle;

public class CompositeGeneratedAdaptersObserver implements GenericLifecycleObserver {
  private final b[] a;
  
  CompositeGeneratedAdaptersObserver(b[] paramArrayOfb) {
    this.a = paramArrayOfb;
  }
  
  public void a(e parame, c.a parama) {
    i i1 = new i();
    b[] arrayOfB = this.a;
    int i = arrayOfB.length;
    boolean bool = false;
    byte b1;
    for (b1 = 0; b1 < i; b1++)
      arrayOfB[b1].a(parame, parama, false, i1); 
    arrayOfB = this.a;
    i = arrayOfB.length;
    for (b1 = bool; b1 < i; b1++)
      arrayOfB[b1].a(parame, parama, true, i1); 
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\arch\lifecycle\CompositeGeneratedAdaptersObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */