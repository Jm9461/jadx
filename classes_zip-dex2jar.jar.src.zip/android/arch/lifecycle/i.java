package android.arch.lifecycle;

import java.util.HashMap;

public class i {
  public i() {
    new HashMap<Object, Object>();
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\arch\lifecycle\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */