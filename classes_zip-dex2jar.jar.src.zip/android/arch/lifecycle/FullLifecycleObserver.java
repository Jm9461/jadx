package android.arch.lifecycle;

interface FullLifecycleObserver extends d {
  void a(e parame);
  
  void b(e parame);
  
  void c(e parame);
  
  void d(e parame);
  
  void e(e parame);
  
  void f(e parame);
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\arch\lifecycle\FullLifecycleObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */