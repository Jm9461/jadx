package android.arch.lifecycle;

public interface b {
  void a(e parame, c.a parama, boolean paramBoolean, i parami);
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\arch\lifecycle\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */