package android.arch.lifecycle;

public class o {
  private final a a;
  
  private final p b;
  
  public o(p paramp, a parama) {
    this.a = parama;
    this.b = paramp;
  }
  
  public <T extends n> T a(Class<T> paramClass) {
    String str = paramClass.getCanonicalName();
    if (str != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("android.arch.lifecycle.ViewModelProvider.DefaultKey:");
      stringBuilder.append(str);
      return a(stringBuilder.toString(), paramClass);
    } 
    throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
  }
  
  public <T extends n> T a(String paramString, Class<T> paramClass) {
    n n = this.b.a(paramString);
    if (paramClass.isInstance(n))
      return (T)n; 
    paramClass = this.a.a((Class)paramClass);
    this.b.a(paramString, (n)paramClass);
    return (T)paramClass;
  }
  
  public static interface a {
    <T extends n> T a(Class<T> param1Class);
  }
}


/* Location:              C:\apktool\dex-tools-v2.4\classes_zip-dex2jar.jar!\android\arch\lifecycle\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */